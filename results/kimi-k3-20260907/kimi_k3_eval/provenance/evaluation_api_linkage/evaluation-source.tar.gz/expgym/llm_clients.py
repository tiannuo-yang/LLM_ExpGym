"""LLM backend implementations that assume OpenAI-compatible APIs.

All real backends share the same message schema. Use ``base_url`` to target vendors
such as Gemini that offer OpenAI-compatible endpoints.
"""
from __future__ import annotations

import http.client
import json
import logging
import os
import socket
import ssl
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from email.message import Message
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple, Union

from expgym.react_loop import LLMBackend, LLMOutput

logger = logging.getLogger("expgym")

Transport = Callable[[urllib.request.Request, float], bytes]
DEFAULT_OPENAI_URL = "https://api.openai.com/v1/chat/completions"
DEFAULT_GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions"
DEFAULT_VLLM_URL = "http://localhost:8000/v1/chat/completions"
DEFAULT_SUB2API_URL = "http://127.0.0.1:8080/v1/chat/completions"
DEFAULT_RETRY_HTTP_STATUSES = (429, 500, 502, 503, 504)


def _normalize_chat_completions_url(base_url: str) -> str:
    """Accept either an OpenAI-compatible base URL or the full chat endpoint."""
    parsed = urllib.parse.urlparse(base_url.rstrip("/"))
    path = parsed.path.rstrip("/")
    if path.endswith("/chat/completions"):
        return urllib.parse.urlunparse(parsed)
    if path in ("", "/"):
        path = "/v1/chat/completions"
    elif path.endswith("/v1") or path.endswith("/api/v1") or path.endswith("/openai"):
        path = f"{path}/chat/completions"
    else:
        return base_url
    return urllib.parse.urlunparse(parsed._replace(path=path))


def _default_transport(request: urllib.request.Request, timeout: float) -> bytes:
    """Direct HTTPS transport (no tunnel)."""
    with urllib.request.urlopen(request, timeout=timeout) as response:  # type: ignore[no-untyped-call]
        return response.read()


def build_tunnel_transport(
    tunnel_port: int = 8443,
    remote_host: str = "openrouter.ai",
) -> Transport:
    """Build a transport that routes HTTPS through a local SSH tunnel.

    Expects ``scripts/tunnel_keepalive.sh`` to be running, forwarding
    ``localhost:<tunnel_port>`` to ``<remote_host>:443`` via a login node.

    The transport creates a raw TCP socket to localhost, wraps it with TLS
    using the correct SNI hostname, and sends the HTTP request manually.
    This avoids the SNI mismatch that urllib would cause.
    """
    try:
        import certifi
        _ca_file = certifi.where()
    except ImportError:
        _ca_file = None

    def _tunnel_transport(request: urllib.request.Request, timeout: float) -> bytes:
        ctx = ssl.create_default_context(cafile=_ca_file)
        sock = socket.create_connection(("localhost", tunnel_port), timeout=timeout)
        try:
            ssock = ctx.wrap_socket(sock, server_hostname=remote_host)
        except Exception:
            sock.close()
            raise

        parsed = urllib.parse.urlparse(request.full_url)
        path = parsed.path
        if parsed.query:
            path += "?" + parsed.query

        conn = http.client.HTTPSConnection("localhost", tunnel_port)
        conn.sock = ssock

        headers = dict(request.headers)
        headers["Host"] = remote_host

        try:
            conn.request(request.get_method(), path, body=request.data, headers=headers)
            resp = conn.getresponse()
            body = resp.read()
            if resp.status >= 400:
                import io
                raise urllib.error.HTTPError(
                    request.full_url, resp.status, resp.reason,
                    resp.msg, io.BytesIO(body),
                )
            return body
        finally:
            conn.close()

    return _tunnel_transport


@dataclass
class OpenAIConfig:
    api_key: str
    model: str
    system_prompt: Optional[str]
    temperature: float
    top_p: float
    seed: Optional[int]
    chat_template_kwargs: Dict[str, object]
    timeout: float
    base_url: str
    extra_headers: Dict[str, str]
    top_k: Optional[int] = None
    provider: Optional[Dict[str, object]] = None
    reasoning: Optional[Dict[str, object]] = None
    max_tokens: Optional[int] = None
    nothink_prefix: bool = False
    prompt_cache_key: Optional[str] = None
    max_retries: int = 10
    retry_base_seconds: float = 3.0
    retry_max_seconds: float = 120.0
    retry_http_statuses: Tuple[int, ...] = DEFAULT_RETRY_HTTP_STATUSES


class OpenAICompatibleLLM(LLMBackend):
    """LLMBackend that speaks the OpenAI Chat Completions protocol.

    Accepts either a messages list (multi-turn) or a plain string (legacy).
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "gpt-4o-mini",
        temperature: float = 0.0,
        top_p: float = 1.0,
        seed: Optional[int] = None,
        chat_template_kwargs: Optional[Dict[str, object]] = None,
        system_prompt: Optional[str] = None,
        timeout: float = 600.0,
        base_url: Optional[str] = None,
        extra_headers: Optional[Dict[str, str]] = None,
        transport: Transport = _default_transport,
        top_k: Optional[int] = None,
        provider: Optional[Dict[str, object]] = None,
        reasoning: Optional[Dict[str, object]] = None,
        max_tokens: Optional[int] = None,
        nothink_prefix: bool = False,
        prompt_cache_key: Optional[str] = None,
        max_retries: int = 10,
        retry_base_seconds: float = 3.0,
        retry_max_seconds: float = 120.0,
        retry_http_statuses: Tuple[int, ...] = DEFAULT_RETRY_HTTP_STATUSES,
        dump_context: Optional[Dict[str, object]] = None,
    ) -> None:
        key = api_key or os.getenv("OPENAI_API_KEY") or os.getenv("GEMINI_API_KEY")
        if not key:
            raise ValueError("An API key is required for OpenAICompatibleLLM")
        if max_retries < 0:
            raise ValueError("max_retries must be non-negative")
        if retry_base_seconds < 0 or retry_max_seconds < 0:
            raise ValueError("retry delays must be non-negative")
        if max_tokens is not None and (
            isinstance(max_tokens, bool) or not isinstance(max_tokens, int) or max_tokens < 1
        ):
            raise ValueError("max_tokens must be a positive integer")
        if chat_template_kwargs is not None and not isinstance(chat_template_kwargs, dict):
            raise ValueError("chat_template_kwargs must be a JSON object")
        self.config = OpenAIConfig(
            api_key=key,
            model=model,
            system_prompt=system_prompt,
            temperature=temperature,
            top_p=top_p,
            seed=seed,
            chat_template_kwargs=chat_template_kwargs or {},
            timeout=timeout,
            base_url=_normalize_chat_completions_url(base_url or DEFAULT_OPENAI_URL),
            extra_headers=extra_headers or {},
            top_k=top_k,
            provider=provider,
            reasoning=reasoning,
            max_tokens=max_tokens,
            nothink_prefix=nothink_prefix,
            prompt_cache_key=(
                prompt_cache_key.strip() if prompt_cache_key and prompt_cache_key.strip() else None
            ),
            max_retries=max_retries,
            retry_base_seconds=retry_base_seconds,
            retry_max_seconds=retry_max_seconds,
            retry_http_statuses=tuple(retry_http_statuses),
        )
        self._transport = transport
        dump_directory = os.getenv("EXPGYM_API_DUMP_DIR")
        self._dump_directory = Path(dump_directory) if dump_directory else None
        self._dump_run_id = os.getenv("EXPGYM_RUN_ID")
        self._dump_context = dict(dump_context or {})
        self._dump_client_id = uuid.uuid4().hex

    @property
    def dump_metadata(self) -> Optional[Dict[str, object]]:
        """Public audit identity, independent of generation and resume settings."""
        if self._dump_directory is None:
            return None
        return {
            "schema_version": "expgym.api_attempt.v1",
            "client_id": self._dump_client_id,
            "run_id": self._dump_run_id,
        }

    @staticmethod
    def _is_secret_field(name: str) -> bool:
        normalized = name.lower().replace("-", "_")
        return normalized in {
            "authorization", "proxy_authorization", "api_key", "apikey", "x_api_key",
            "access_token", "refresh_token", "password", "secret", "client_secret",
        } or normalized.endswith(("_api_key", "_access_token", "_secret"))

    def _redact_dump_value(self, value: object) -> object:
        """Exclude credential fields and any echoed configured credentials."""
        if isinstance(value, dict):
            return {
                key: "[REDACTED]" if self._is_secret_field(str(key)) else self._redact_dump_value(item)
                for key, item in value.items()
            }
        if isinstance(value, (list, tuple)):
            return [self._redact_dump_value(item) for item in value]
        if isinstance(value, str):
            secrets = [self.config.api_key]
            secrets.extend(
                header_value for name, header_value in self.config.extra_headers.items()
                if self._is_secret_field(name)
            )
            for secret in sorted(set(secrets), key=len, reverse=True):
                if secret:
                    value = value.replace(secret, "[REDACTED]")
            return value
        return value

    def _dump_attempt(
        self,
        metadata: Dict[str, object],
        payload: Dict[str, object],
        started: float,
        *,
        state: str,
        raw: Optional[bytes] = None,
        error: Optional[Exception] = None,
        http_status: Optional[int] = None,
        retry_delay: Optional[float] = None,
    ) -> None:
        """Atomically record each HTTP attempt, including failed and pending ones.

        Dump failures propagate so an explicitly audited run cannot silently lose
        requests. Transport headers are never serialized. Non-JSON response bytes
        are decoded with backslash escapes so malformed responses remain inspectable.
        """
        if self._dump_directory is None:
            return
        parsed_url = urllib.parse.urlsplit(self.config.base_url)
        endpoint = urllib.parse.urlunsplit((
            parsed_url.scheme, parsed_url.netloc.rsplit("@", 1)[-1], parsed_url.path, "", "",
        ))
        response_text = raw.decode("utf-8", "backslashreplace") if raw is not None else None
        response_json = None
        if raw is not None:
            try:
                response_json = json.loads(raw.decode("utf-8"))
            except (ValueError, UnicodeDecodeError):
                pass
        safe_response = self._redact_dump_value(response_json)
        if safe_response != response_json:
            # A provider may echo a credential in its error body. Keep a redacted
            # equivalent instead of persisting that credential in the raw string.
            response_text = json.dumps(safe_response, ensure_ascii=False)
        record = {
            "schema_version": "expgym.api_attempt.v1",
            **metadata,
            "run_id": self._dump_run_id,
            "client_id": self._dump_client_id,
            "context": self._dump_context,
            "pid": os.getpid(),
            "thread_id": threading.get_ident(),
            "thread_name": threading.current_thread().name,
            "state": state,
            "finished_at_utc": None if state == "in_progress" else datetime.now(timezone.utc).isoformat(),
            "wall_time_seconds": time.monotonic() - started,
            "endpoint": endpoint,
            "request_payload": payload,
            "response_raw": response_text,
            "response_json": safe_response,
            "http_status": http_status,
            "error": {"type": type(error).__name__, "message": str(error)} if error else None,
            "will_retry": retry_delay is not None,
            "retry_delay_seconds": retry_delay,
        }
        self._dump_directory.mkdir(parents=True, exist_ok=True)
        destination = self._dump_directory / (str(metadata["request_id"]) + ".json")
        handle = tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=str(self._dump_directory),
            prefix=".api-attempt-", suffix=".tmp", delete=False,
        )
        temporary = Path(handle.name)
        try:
            with handle:
                json.dump(self._redact_dump_value(record), handle, ensure_ascii=False, indent=2)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(str(temporary), str(destination))
        except BaseException:
            if temporary.exists():
                temporary.unlink()
            raise

    def _build_request(self, payload: Dict[str, object]) -> urllib.request.Request:
        return urllib.request.Request(
            self.config.base_url,
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {self.config.api_key}",
                "Content-Type": "application/json",
                **self.config.extra_headers,
            },
            method="POST",
        )

    def _retry_delay(self, attempt: int, headers: Optional[Message] = None) -> float:
        """Return a bounded exponential delay, honoring numeric Retry-After."""
        if headers is not None:
            retry_after = headers.get("Retry-After")
            if retry_after:
                try:
                    return max(
                        0.0,
                        min(float(retry_after), self.config.retry_max_seconds),
                    )
                except ValueError:
                    pass
        exponential = self.config.retry_base_seconds * (2 ** attempt)
        return min(exponential, self.config.retry_max_seconds)

    @staticmethod
    def _decode_response(raw: bytes) -> Tuple[Dict[str, object], str]:
        try:
            data = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("API returned invalid JSON") from exc
        if not isinstance(data, dict):
            raise ValueError("API response is not an object")
        choices = data.get("choices") or []
        if not isinstance(choices, list) or not choices or not isinstance(choices[0], dict):
            raise ValueError("API returned no choices")
        message = choices[0].get("message")
        if not isinstance(message, dict) or "content" not in message:
            raise ValueError("API choice missing message content")
        content = message.get("content")
        if isinstance(content, str):
            text = content.strip()
        elif isinstance(content, list):
            text = "\n".join(
                str(part.get("text", ""))
                for part in content
                if isinstance(part, dict) and part.get("type") == "text"
            ).strip()
        else:
            text = ""
        if not text:
            raise ValueError("API choice missing message content")
        return data, text

    def generate(self, messages: Union[str, List[Dict[str, str]]]) -> LLMOutput:
        if isinstance(messages, str):
            # Legacy: wrap plain string into messages list
            msgs: List[Dict[str, str]] = []
            if self.config.system_prompt:
                msgs.append({"role": "system", "content": self.config.system_prompt})
            msgs.append({"role": "user", "content": messages})
        else:
            msgs = list(messages)

        # Prepend /nothink to system message for Qwen3 thinking suppression
        if (self.config.nothink_prefix
                and "qwen" in self.config.model.lower()
                and msgs and msgs[0]["role"] == "system"):
            content = msgs[0]["content"]
            if not content.startswith("/nothink"):
                msgs[0] = {**msgs[0], "content": "/nothink\n" + content}

        payload: Dict[str, object] = {
            "model": self.config.model,
            "messages": msgs,
            "temperature": self.config.temperature,
            "top_p": self.config.top_p,
        }
        if self.config.seed is not None:
            payload["seed"] = self.config.seed
        if self.config.max_tokens is not None:
            payload["max_tokens"] = self.config.max_tokens
        if self.config.top_k is not None:
            payload["top_k"] = self.config.top_k
        if self.config.provider is not None:
            payload["provider"] = self.config.provider
        if self.config.reasoning is not None:
            payload["reasoning"] = self.config.reasoning
        if self.config.chat_template_kwargs:
            payload["chat_template_kwargs"] = self.config.chat_template_kwargs
        if self.config.prompt_cache_key is not None:
            payload["prompt_cache_key"] = self.config.prompt_cache_key
        generation_id = uuid.uuid4().hex
        for attempt in range(self.config.max_retries + 1):
            request = self._build_request(payload)
            started = time.monotonic()
            metadata = {
                "generation_id": generation_id,
                "request_id": uuid.uuid4().hex,
                "attempt": attempt + 1,
                "max_attempts": self.config.max_retries + 1,
                "started_at_utc": datetime.now(timezone.utc).isoformat(),
            }
            self._dump_attempt(metadata, payload, started, state="in_progress")
            try:
                raw = self._transport(request, self.config.timeout)
            except urllib.error.HTTPError as exc:
                code = exc.code
                raw_error = exc.read()
                body = raw_error.decode("utf-8", "ignore")
                will_retry = code in self.config.retry_http_statuses and attempt < self.config.max_retries
                wait = self._retry_delay(attempt, exc.headers) if will_retry else None
                self._dump_attempt(
                    metadata, payload, started, state="error", raw=raw_error,
                    error=exc, http_status=code, retry_delay=wait,
                )
                if (
                    code in self.config.retry_http_statuses
                    and attempt < self.config.max_retries
                ):
                    wait = self._retry_delay(attempt, exc.headers)
                    logger.warning(
                        "HTTP %d, retry %d/%d in %.1fs",
                        code,
                        attempt + 1,
                        self.config.max_retries,
                        wait,
                    )
                    import time as _time
                    _time.sleep(wait)
                    continue
                raise RuntimeError(f"API error: {body}") from exc
            except (urllib.error.URLError, TimeoutError, ConnectionError) as exc:
                wait = self._retry_delay(attempt) if attempt < self.config.max_retries else None
                self._dump_attempt(
                    metadata, payload, started, state="error", error=exc, retry_delay=wait,
                )
                if attempt < self.config.max_retries:
                    wait = self._retry_delay(attempt)
                    logger.warning(
                        "URLError, retry %d/%d in %.1fs: %s",
                        attempt + 1,
                        self.config.max_retries,
                        wait,
                        exc,
                    )
                    import time as _time
                    _time.sleep(wait)
                    continue
                raise RuntimeError(f"API connection failed: {exc}") from exc
            except Exception as exc:
                self._dump_attempt(metadata, payload, started, state="error", error=exc)
                raise
            try:
                data, text = self._decode_response(raw)
            except ValueError as exc:
                wait = self._retry_delay(attempt) if attempt < self.config.max_retries else None
                self._dump_attempt(
                    metadata, payload, started, state="malformed_response", raw=raw,
                    error=exc, retry_delay=wait,
                )
                if attempt < self.config.max_retries:
                    wait = self._retry_delay(attempt)
                    logger.warning(
                        "%s, retry %d/%d in %.1fs",
                        exc,
                        attempt + 1,
                        self.config.max_retries,
                        wait,
                    )
                    import time as _time
                    _time.sleep(wait)
                    continue
                raise RuntimeError(str(exc)) from exc
            self._dump_attempt(metadata, payload, started, state="success", raw=raw)
            break

        usage = data.get("usage") or {}
        prompt_tokens = usage.get("prompt_tokens", usage.get("input_tokens"))
        completion_tokens = usage.get("completion_tokens", usage.get("output_tokens"))
        prompt_token_details = (
            usage.get("prompt_tokens_details")
            or usage.get("input_tokens_details")
            or {}
        )
        cached_prompt_tokens = (
            prompt_token_details.get("cached_tokens")
            if isinstance(prompt_token_details, dict)
            else None
        )
        cache_write_prompt_tokens = (
            prompt_token_details.get("cache_write_tokens")
            if isinstance(prompt_token_details, dict)
            else None
        )
        return LLMOutput(
            text=text,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            cached_prompt_tokens=cached_prompt_tokens,
            cache_write_prompt_tokens=cache_write_prompt_tokens,
            request_attempts=attempt + 1,
        )


def build_gemini_client(**kwargs) -> OpenAICompatibleLLM:
    """Helper that instantiates the OpenAI client for Gemini endpoints."""
    api_key = kwargs.pop("api_key", None) or os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise ValueError("GEMINI_API_KEY is required for the Gemini backend")
    base_url = kwargs.pop("base_url", None) or DEFAULT_GEMINI_URL
    return OpenAICompatibleLLM(
        api_key=api_key,
        base_url=base_url,
        **kwargs,
    )


DEFAULT_OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"


def build_openrouter_client(
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    referer: Optional[str] = None,
    title: Optional[str] = None,
    require_parameters: bool = False,
    disable_thinking: bool = True,
    **kwargs,
) -> OpenAICompatibleLLM:
    key = api_key or os.getenv("OPENROUTER_API_KEY")
    if not key:
        raise ValueError("OPENROUTER_API_KEY is required for the OpenRouter backend")
    headers: Dict[str, str] = {}
    if referer:
        headers["HTTP-Referer"] = referer
    if title:
        headers["X-Title"] = title
    # Build provider preferences for deterministic routing
    provider = kwargs.pop("provider", None)
    if provider is None and require_parameters:
        provider = {"require_parameters": True}
    # Disable thinking by default for deterministic output
    reasoning = kwargs.pop("reasoning", None)
    if reasoning is None and disable_thinking:
        reasoning = {"enabled": False}
    return OpenAICompatibleLLM(
        api_key=key,
        base_url=base_url or DEFAULT_OPENROUTER_URL,
        extra_headers=headers,
        provider=provider,
        reasoning=reasoning,
        **kwargs,
    )


def build_vllm_client(
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    chat_template_kwargs: Optional[Dict[str, object]] = None,
    **kwargs,
) -> OpenAICompatibleLLM:
    key = api_key or os.getenv("VLLM_API_KEY") or "EMPTY"
    return OpenAICompatibleLLM(
        api_key=key,
        base_url=base_url or DEFAULT_VLLM_URL,
        chat_template_kwargs=chat_template_kwargs,
        **kwargs,
    )


def build_sub2api_client(
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    **kwargs,
) -> OpenAICompatibleLLM:
    """Build a client for a local or remote Sub2API deployment."""
    key = api_key or os.getenv("SUB2API_API_KEY")
    if not key:
        raise ValueError("SUB2API_API_KEY is required for the Sub2API backend")
    endpoint = base_url or os.getenv("SUB2API_BASE_URL") or DEFAULT_SUB2API_URL
    return OpenAICompatibleLLM(
        api_key=key,
        base_url=endpoint,
        **kwargs,
    )
