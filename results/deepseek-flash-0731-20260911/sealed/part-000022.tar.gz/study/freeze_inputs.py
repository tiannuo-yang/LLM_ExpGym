#!/usr/bin/env python3
"""Explicit pre-execution identities; never read or hash weight payloads.

Supply the runtime inputs and the actual runtime-used encoding files explicitly.
A checkpoint without chat_template.jinja is valid; an unspecified encoder is not.
This metadata record is not proof of readiness or a completed scientific study.
"""
import argparse
import hashlib
import json
from pathlib import Path
import stat
import subprocess
import sys

from build_matrix import MODEL, validate_profile

MAX_METADATA_BYTES = 256 * 1024 * 1024


def require(condition, message):
    if not condition:
        raise ValueError(message)


def within(path, root):
    """Do not accept ../ or a symlink escape into another live study."""
    path, root = Path(path), Path(root)
    return path.is_absolute() and path.resolve().is_relative_to(root.resolve())


def file_record(path):
    path = Path(path).absolute()
    require(path.suffix not in {'.safetensors', '.bin', '.pt', '.pth'},
            'Refusing weight payload hash: ' + str(path))
    before = path.stat()
    require(stat.S_ISREG(before.st_mode) and before.st_size <= MAX_METADATA_BYTES,
            'Expected bounded metadata file: ' + str(path))
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    after = path.stat()
    identity = lambda value: (value.st_size, value.st_mtime_ns, value.st_ino, value.st_dev)
    require(identity(before) == identity(after), 'Input changed during freeze: ' + str(path))
    return {'path': str(path), 'bytes': before.st_size, 'sha256': digest.hexdigest()}


def checkpoint_record(checkpoint, metadata_paths, encoding_paths):
    checkpoint = checkpoint.absolute()
    metadata = [Path(p).absolute() for p in metadata_paths]
    encodings = [Path(p).absolute() for p in encoding_paths]
    require(metadata and len(metadata) == len(set(metadata)), 'Duplicate or absent checkpoint metadata')
    require(encodings and len(encodings) == len(set(encodings)), 'Actual runtime encoding files must be explicit')
    require(all(within(p, checkpoint) for p in metadata), 'Checkpoint metadata outside checkpoint')
    index_path = checkpoint / 'model.safetensors.index.json'
    require({checkpoint / 'config.json', index_path} <= set(metadata),
            'Checkpoint metadata must include config.json and weight index')
    records = [file_record(path) for path in metadata]
    index_raw = index_path.read_bytes()
    index_record = next(r for r in records if r['path'] == str(index_path))
    require(hashlib.sha256(index_raw).hexdigest() == index_record['sha256'], 'Weight index changed')
    weight_index = json.loads(index_raw)
    shards = []
    for name in sorted(set(weight_index['weight_map'].values())):
        require(isinstance(name, str) and Path(name).name == name and name.endswith('.safetensors'),
                'Unexpected weight shard path')
        path = checkpoint / name
        value = path.stat()
        require(stat.S_ISREG(value.st_mode) and value.st_size > 0, 'Missing or empty weight shard')
        shards.append({'name': name, 'bytes': value.st_size, 'mtime_ns': value.st_mtime_ns,
                       'inode': value.st_ino, 'device': value.st_dev})
    require(shards, 'No indexed weight shards')
    declared = weight_index['metadata']['total_size']
    require(type(declared) is int and declared > 0, 'Invalid declared weight tensor bytes')
    return {'checkpoint_path': str(checkpoint), 'checkpoint_metadata': records,
            'runtime_encoding_files': [file_record(path) for path in encodings],
            'encoding_scope': 'Operator-supplied actual runtime-used encoding files; must be verified against runtime before execution',
            'weight_shards': shards, 'weight_index_declared_tensor_bytes': declared,
            'weight_shard_bytes': sum(s['bytes'] for s in shards),
            'weight_payload_hashes_verified': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--study-root', type=Path, required=True)
    parser.add_argument('--source-repo', type=Path, required=True)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--matrix-dir', type=Path, required=True)
    parser.add_argument('--launch-dir', type=Path, required=True)
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--checkpoint-metadata', type=Path, action='append', required=True,
                        help='Explicit checkpoint metadata paths; repeat; config and weight index required')
    parser.add_argument('--encoding-file', type=Path, action='append', required=True,
                        help='Actual runtime-used encoding file path; repeat for its required implementation/data files')
    parser.add_argument('--runtime-dir', type=Path, required=True)
    parser.add_argument('--runtime-input', type=Path, action='append', required=True,
                        help='Explicit nonsecret runtime identity files; repeat; e.g. uv.lock and runtime-env.sh')
    parser.add_argument('--model-profile', type=Path, required=True)
    parser.add_argument('--model', default=MODEL)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    root, repo = args.study_root.absolute(), args.source_repo.absolute()
    runtime, checkpoint = args.runtime_dir.absolute(), args.checkpoint.absolute()
    launch = args.launch_dir.absolute()
    require(args.model == MODEL, 'Unexpected study model')
    require(within(runtime, root) and within(launch, root),
            'Runtime and launch must belong to this isolated study root')
    require(not args.output.exists(), 'Output exists; use a fresh identity record')
    profile = validate_profile(json.loads(args.model_profile.read_text()))
    plan = json.loads(args.plan.read_text())
    require(plan['schema'] == 'expgym.study-queue-plan.v1' and len(plan['jobs']) == 783,
            'Expected complete formal queue plan, not smoke')
    require(plan['study_id'].startswith('deepseek-flash-'), 'Wrong study namespace')
    require(within(plan['output_root'], root), 'Queue output is outside this study')
    require(not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True).strip(),
            'Execution source worktree must be clean')
    sys.path.insert(0, str(repo))
    from expgym.trace_v2 import source_tree_sha256
    require(source_tree_sha256(repo) == plan['source_tree_sha256'], 'Execution source changed since queue freeze')
    server = json.loads((launch / 'plan.json').read_text())
    deployment = json.loads((launch / 'deployment.json').read_text())
    require(Path(server['checkpoint']).absolute() == checkpoint and server['model'] == args.model,
            'Serving checkpoint/model differs from explicit inputs')
    require(within(server['sglang_bin'], runtime) and within(server['runtime_env'], runtime),
            'Serving executable/environment does not belong to isolated runtime')
    for job in plan['jobs']:
        require(job['endpoints'] == deployment['endpoints'], 'Queue endpoint differs from recorded allocation')
        value = job['args']
        require(value.get('models', value.get('model')) == args.model,
                'Queue model differs from explicit profile')
        require(value['reasoning_effort'] == profile['reasoning_effort']
                and value['chat_template_kwargs'] == profile['chat_template_kwargs']
                and value['top_k'] is None, 'Queue thinking/top-k differs from profile')
        require(within(value['output_dir'], root), 'Job output is outside this study')
        require(within(job['python'], root / 'study'), 'Job wrapper belongs to another study')
    runtime_inputs = [p.absolute() for p in args.runtime_input]
    require(len(runtime_inputs) == len(set(runtime_inputs)), 'Duplicate runtime input')
    require(all(within(p, runtime) for p in runtime_inputs), 'Runtime input outside isolated runtime')
    inputs = [args.plan, args.matrix_dir / 'matrix.json', args.matrix_dir / 'coverage.json',
              args.matrix_dir / 'runtime_environment.json', root / 'study/data_inventory.json',
              args.model_profile, *runtime_inputs, launch / 'plan.json', launch / 'deployment.json',
              root / 'study/python_main', root / 'study/python_hpo', root / 'study/cpu_runtime.py',
              root / 'study/build_matrix.py', repo / 'configs/audit_hypothesis_orders.json',
              repo / 'configs/hpobench_tasks.yaml', repo / 'data/hpo_tuning/oracle3.json']
    require(len({p.absolute() for p in inputs}) == len(inputs), 'Duplicate input path')
    coverage = json.loads((args.matrix_dir / 'coverage.json').read_text())
    profile_record = file_record(args.model_profile)
    require(coverage['model_profile']['sha256'] == profile_record['sha256']
            and coverage['model_profile']['value'] == profile, 'Coverage profile differs from explicit profile')
    require(all(job['args']['request_timeout'] == coverage['request_timeout_seconds'] for job in plan['jobs']),
            'Queue transport timeout differs from matrix coverage')
    result = {'schema': 'deepseek-flash.run-inputs.v1', 'model': args.model,
              'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
              'source_tree_sha256': plan['source_tree_sha256'], 'study_id': plan['study_id'],
              'queue_jobs': len(plan['jobs']), 'gpu_job_id': deployment['job_id'],
              'runtime_dir': str(runtime), 'inputs': [file_record(p) for p in inputs],
              **checkpoint_record(checkpoint, args.checkpoint_metadata, args.encoding_file),
              'data_payload_verification': 'Inherited completed copy+SHA validation from study/data_inventory.json; not repeated here',
              'scope': 'Identity record only; not inference readiness, scientific completion, or publication safety validation'}
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'output': str(args.output), 'queue_jobs': len(plan['jobs']),
                      'weight_shards': len(result['weight_shards']), 'weight_payloads_hashed': False}))


if __name__ == '__main__':
    main()
