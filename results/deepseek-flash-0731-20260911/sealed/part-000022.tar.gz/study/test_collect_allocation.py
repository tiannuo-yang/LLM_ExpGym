"""Bounded synthetic accounting fixtures; no real sacct or GPU calls."""
import copy
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

import collect_allocation as accounting


def row(job="1204605", **changes):
    value = {"JobIDRaw": job, "JobID": job, "Cluster": "fixture-cluster", "Account": "k2p",
             "Partition": "higherprio", "JobName": "unfamiliar-model", "State": "COMPLETED",
             "Submit": "2026-09-11T00:00:00", "Start": "2026-09-11T00:01:00", "End": "2026-09-11T01:01:00",
             "ElapsedRaw": "3600", "AllocNodes": "4", "AllocTRES": "billing=384,cpu=384,gres/gpu=32,node=4",
             "NodeList": "fixture-[1-4]", "ExitCode": "0:0"}
    value.update(changes)
    return "|".join(value[name] for name in accounting.FIELDS) + "\n"


def binding(job="1204605"):
    return {"job_id": job, "model": "unfamiliar-model", "planned_account": "k2p",
            "planned_partition": "higherprio", "planned_nodes": 4, "planned_gpus": 32, "model_replicas": 4}


class AllocationTests(unittest.TestCase):
    def parse(self, text, ids=("1204605",)):
        return accounting.parse_allocations(text, {job: binding(job) for job in ids})

    def test_four_replicas_are_one_job_and_actual_32_gpus(self):
        value = self.parse(row())
        self.assertEqual((value["expected_allocations"], value["known_allocations"]), (1, 1))
        self.assertEqual(value["allocation_gpu_hours"], 32)
        self.assertEqual(value["allocations"][0]["model_replicas"], 4)
        self.assertTrue(value["allocations"][0]["allocation_matches_plan"])

    def test_running_observed_elapsed_never_becomes_final_cost(self):
        value = self.parse(row(State="RUNNING", End="Unknown", ElapsedRaw="9999"))
        actual = value["allocations"][0]
        self.assertEqual(actual["observed_elapsed_seconds"], 9999)
        self.assertIsNone(actual["final_elapsed_seconds"])
        self.assertIsNone(actual["allocation_gpu_hours"])
        self.assertIsNone(value["allocation_gpu_hours"])
        self.assertEqual(value["known_allocations"], 0)

    def test_failed_job_preserved_and_expected_jobs_added_explicitly(self):
        value = self.parse(row() + row("1204610", State="FAILED", ElapsedRaw="1800", End="2026-09-11T00:31:00"),
                           ("1204605", "1204610"))
        self.assertEqual(value["allocation_gpu_hours"], 48)
        self.assertEqual(value["allocations"][1]["state"], "FAILED")
        self.assertEqual(value["expected_allocations"], 2)

    def test_identical_duplicate_and_steps_retained_but_not_counted(self):
        text = row() + row() + row("1204605.batch") + row("1204605.extern")
        value = self.parse(text)
        self.assertEqual(value["allocation_gpu_hours"], 32)
        self.assertEqual(len(value["sacct_rows"]), 4)
        self.assertEqual(len(value["excluded_rows"]), 3)
        self.assertEqual(len(value["allocations"]), 1)

    def test_conflicting_duplicates_unrequested_or_array_jobs_rejected(self):
        for text in (row() + row(ElapsedRaw="3601"), row("1204610"), row("1204605_1")):
            with self.subTest(text=text), self.assertRaises(ValueError):
                self.parse(text)

    def test_generic_plus_typed_gpu_tres_not_double_counted(self):
        self.assertEqual(accounting.gpu_count("gres/gpu=32,gres/gpu:h200=32,cpu=384"), 32)
        self.assertEqual(accounting.gpu_count("gres/gpu:a=16,gres/gpu:b=16,cpu=384"), 32)
        for text in ("gres/gpu=32,gres/gpu:a=16", "gres/gpu=32,gres/gpu=32", "gres/gpu=-1"):
            with self.subTest(text=text), self.assertRaises(ValueError):
                accounting.gpu_count(text)

    def test_missing_actual_gpus_does_not_fall_back_to_planned(self):
        value = self.parse(row(AllocTRES="cpu=384,node=4"))
        self.assertIsNone(value["allocations"][0]["allocated_gpus"])
        self.assertIsNone(value["allocation_gpu_hours"])

    def test_actual_resource_mismatch_is_visible_not_replaced(self):
        value = self.parse(row(AllocTRES="gres/gpu=16,node=2", AllocNodes="2"))
        self.assertEqual(value["allocation_gpu_hours"], 16)
        self.assertFalse(value["allocations"][0]["allocation_matches_plan"])

    def test_missing_job_or_terminal_timestamp_remains_unknown(self):
        for text in ("", row(End="Unknown"), row(Start="Unknown"), row(ElapsedRaw="Unknown")):
            with self.subTest(text=text):
                value = self.parse(text)
                self.assertIsNone(value["allocation_gpu_hours"])
                self.assertEqual(value["expected_allocations"], 1)
        self.assertEqual(self.parse("")["allocations"][0]["state"], "MISSING")

    def test_elapsedraw_not_inferred_from_start_end_or_now(self):
        value = self.parse(row(ElapsedRaw="1800"))
        actual = value["allocations"][0]
        self.assertEqual(actual["timestamp_span_seconds"], 3600)
        self.assertFalse(actual["elapsed_matches_timestamp_span"])
        self.assertEqual(value["allocation_gpu_hours"], 16)

    def test_cancel_actor_is_retained_and_invalid_time_rejected(self):
        value = self.parse(row(State="CANCELLED by 123"))
        self.assertEqual(value["allocations"][0]["state"], "CANCELLED")
        self.assertEqual(value["sacct_rows"][0]["State"], "CANCELLED by 123")
        for text in (row(State="RUNNING"), row(End="2026-09-10T00:00:00"), row(Start="2026-09-11T00:01:00+08:00")):
            with self.subTest(text=text), self.assertRaises(ValueError):
                self.parse(text)

    def prepare(self):
        temp = tempfile.TemporaryDirectory(prefix="deepseek-allocation-test-")
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)
        (root / "study").mkdir()
        launch = root / "serving" / "launch01"
        launch.mkdir(parents=True)
        plan = {"model": "unfamiliar-model", "config": {"slurm": {
            "account": "k2p", "partition": "higherprio", "nodes": 4, "gpus_per_node": 8},
            "topology": {"replicas": 4}}}
        raw = json.dumps(plan).encode()
        (launch / "plan.json").write_bytes(raw)
        plan_sha = accounting.sha(raw)
        raw = json.dumps({"job_id": "1204605", "plan_sha256": plan_sha}).encode()
        (launch / "deployment.json").write_bytes(raw)
        job = ["1204605", str(launch), plan_sha, "deployment.json", accounting.sha(raw)]
        return root, launch, job

    def test_fresh_json_and_table_capture_exact_sacct_command_and_rows(self):
        root, launch, job = self.prepare()
        text = row(State="RUNNING", End="Unknown", ElapsedRaw="409")
        result = subprocess.CompletedProcess([], 0, stdout=text, stderr="fixture diagnostic\n")
        with patch.object(accounting.subprocess, "run", return_value=result) as run:
            record = accounting.collect(root, [job], "2026-09-11T00:00:00", root / "study" / "accounting")
        run.assert_called_once()
        command = run.call_args.args[0]
        self.assertEqual(command[:4], ["sacct", "-X", "-P", "-n"])
        self.assertIn("--jobs=1204605", command)
        self.assertEqual(run.call_args.kwargs["env"]["TZ"], "UTC")
        self.assertEqual(record["sacct_stdout"], text)
        self.assertEqual(record["sacct_stderr"], "fixture diagnostic\n")
        self.assertEqual(record["command"], command)
        output = root / "study" / "accounting"
        self.assertEqual({p.name for p in output.iterdir()}, {"ACCOUNTING.json", "ACCOUNTING.md"})
        self.assertIsNone(json.loads((output / "ACCOUNTING.json").read_text())["allocation_gpu_hours"])
        self.assertIn("unknown", (output / "ACCOUNTING.md").read_text())
        with patch.object(accounting.subprocess, "run") as run, self.assertRaises(ValueError):
            accounting.collect(root, [job], "2026-09-11T00:00:00", output)
        run.assert_not_called()

    def test_launch_pins_job_identity_and_private_names_fail_before_query(self):
        root, launch, job = self.prepare()
        variants = []
        for index, value in ((0, "1204610"), (2, "0" * 64), (3, "private.json"), (4, "0" * 64)):
            changed = list(job)
            changed[index] = value
            variants.append([changed])
        variants.append([job, job])
        for jobs in variants:
            with self.subTest(jobs=jobs), patch.object(accounting.subprocess, "run") as run, self.assertRaises(ValueError):
                accounting.collect(root, jobs, "2026-09-11T00:00:00", root / "study" / "not-created")
            run.assert_not_called()

    def test_early_startup_submission_can_bind_allocation_without_deployment(self):
        root, launch, job = self.prepare()
        raw = json.dumps({"exit_code": 0, "stdout": "1204605;fixture-cluster\n", "stderr": ""}).encode()
        (launch / "submission.json").write_bytes(raw)
        job[3:] = ["submission.json", accounting.sha(raw)]
        values = accounting.bindings_for(root, [job])
        self.assertEqual(set(values), {"1204605"})
        self.assertEqual(values["1204605"]["plan_binding"], "operator_explicit_plan_pin_not_proven_by_submission")

    def test_nonzero_timeout_and_launch_failure_keep_evidence_and_unknown_cost(self):
        root, launch, job = self.prepare()
        examples = [
            subprocess.CompletedProcess([], 1, stdout=row(), stderr="fixture sacct error\n"),
            subprocess.TimeoutExpired(["sacct"], 60, output=row().encode(), stderr=b"fixture partial error"),
            FileNotFoundError("fixture sacct executable missing"),
        ]
        for index, example in enumerate(examples):
            mock_args = {"side_effect": example} if isinstance(example, Exception) else {"return_value": example}
            with self.subTest(example=index), patch.object(accounting.subprocess, "run", **mock_args):
                value = accounting.collect(root, [job], "2026-09-11T00:00:00", root / "study" / ("failed-%d" % index))
            self.assertEqual(value["collection_status"], "failed")
            self.assertEqual(value["parse_status"], "not_attempted")
            self.assertIsNone(value["allocation_gpu_hours"])
            self.assertTrue(value["sacct_stderr"])
            self.assertEqual(value["sacct_stdout"], row() if index < 2 else "")
            self.assertTrue((root / "study" / ("failed-%d" % index) / "ACCOUNTING.json").is_file())

    def test_bad_rows_and_contradictory_duplicates_are_preserved_on_parse_failure(self):
        root, launch, job = self.prepare()
        for index, text in enumerate(("unexpected|bad|row\n", row() + row(ElapsedRaw="3601"))):
            response = subprocess.CompletedProcess([], 0, stdout=text, stderr="")
            with patch.object(accounting.subprocess, "run", return_value=response):
                value = accounting.collect(root, [job], "2026-09-11T00:00:00", root / "study" / ("parse-failed-%d" % index))
            self.assertEqual(value["query_status"], "passed")
            self.assertEqual(value["parse_status"], "failed")
            self.assertEqual(value["collection_status"], "failed")
            self.assertEqual(value["sacct_stdout"], text)
            self.assertEqual(value["sacct_raw_lines"], text.splitlines())
            self.assertIsNone(value["allocation_gpu_hours"])

    def test_private_and_runtime_ancestors_blocked_before_metadata_open(self):
        root, launch, job = self.prepare()
        for name in ("private", "uv-cache", "runtime", ".venv", "secrets"):
            directory = root / "serving" / name
            directory.mkdir()
            changed = list(job)
            changed[1] = str(directory)
            with self.subTest(name=name), patch.object(Path, "read_bytes") as read, self.assertRaisesRegex(ValueError, "forbidden"):
                accounting.bindings_for(root, [changed])
            read.assert_not_called()

    def test_failed_query_cli_returns_nonzero_after_writing_evidence(self):
        root, launch, job = self.prepare()
        argv = ["collect_allocation.py", "--study-root", str(root), "--since", "2026-09-11T00:00:00",
                "--job", *job, "--output-dir", str(root / "study" / "cli-failed")]
        response = subprocess.CompletedProcess([], 1, stdout="partial stdout\n", stderr="fixture error\n")
        with patch("sys.argv", argv), patch.object(accounting.subprocess, "run", return_value=response), patch("builtins.print"):
            self.assertEqual(accounting.main(), 1)
        self.assertTrue((root / "study" / "cli-failed" / "ACCOUNTING.json").is_file())

    def test_output_and_launch_symlinks_or_cross_study_paths_rejected(self):
        root, launch, job = self.prepare()
        other = root / "other-model"
        other.mkdir()
        (root / "study" / "escape").symlink_to(other, target_is_directory=True)
        for target in (other / "accounting", root / "study" / "escape" / "accounting"):
            with self.subTest(target=target), patch.object(accounting.subprocess, "run") as run, self.assertRaises(ValueError):
                accounting.collect(root, [job], "2026-09-11T00:00:00", target)
            run.assert_not_called()
        (launch / "other.json").write_text("{}")
        (launch / "deployment.json").unlink()
        (launch / "deployment.json").symlink_to(launch / "other.json")
        with self.assertRaises(ValueError):
            accounting.bindings_for(root, [job])


if __name__ == "__main__":
    unittest.main(verbosity=2)
