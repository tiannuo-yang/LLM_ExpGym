"""Focused synthetic artifact tests; no serving imports, model or HTTP calls."""
from __future__ import annotations

import copy
import importlib.util
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest

SPEC = importlib.util.spec_from_file_location("native_contract", Path(__file__).with_name("replay_native_contract.py"))
CHECKS = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CHECKS)
SOURCE = Path(__file__).resolve().parents[2] / "LLM_ExpGym-deepseek-flash-20260911"


def fixture(decoder, name="auto", dictionary_arguments=False):
    """Build explicit synthetic wire/results, never invoke a model client."""
    config = {"model": "deepseek-v4-flash-0731", "temperature": 1.0, "top_p": 0.95,
              "seed": 2200, "max_tokens": 32768, "reasoning_effort": "max",
              "chat_template_kwargs": {"thinking": True}, "max_retries": 2,
              "base_url": "http://fixture.invalid:8000/v1", "prompt_cache_key_field": "cache_salt"}
    choice = "auto" if name == "auto" else {"type": "function", "function": {"name": "read_note"}}
    spec = {"label": name, "note": "SMOKE_NOTE_fixture", "tool_choice": choice}
    initial = [{"role": "system", "content": "Use the provided tool to retrieve the run note. Do not invent its contents."},
               {"role": "user", "content": "Read the note with label " + name + ". After receiving it, answer with its exact text."}]
    arguments = {"label": name} if dictionary_arguments else json.dumps({"label": name})
    assistant = {"role": "assistant", "content": None, "reasoning_content": "prior reasoning sentinel",
                 "tool_calls": [{"id": "native-call", "type": "function", "function": {"name": "read_note", "arguments": arguments}}],
                 "provider_extension": {"preserve": True}}
    payload = {key: copy.deepcopy(config[key]) for key in ("model", "temperature", "top_p", "seed", "max_tokens", "reasoning_effort", "chat_template_kwargs")}
    payload.update(messages=initial, tools=copy.deepcopy(CHECKS.TOOLS), tool_choice=choice,
                   parallel_tool_calls=False, cache_salt="deepseek-flash-native-smoke-" + name)
    records = {}

    def decision(index, request, message, finish):
        usage = {"prompt_tokens": 111 + index, "completion_tokens": 12,
                 "prompt_tokens_details": {"cached_tokens": 4, "cache_write_tokens": 2}}
        response = {"choices": [{"message": message, "finish_reason": finish}], "usage": usage}
        raw = json.dumps(response)
        _, text, calls, saved, saved_finish = decoder._decode_response(raw.encode())
        request_id = name + "-request-" + str(index)
        ledger = {"attempt": 1, "request_id": request_id, "generation_id": name + "-generation-" + str(index),
                  "state": "success", "http_status": None, "usage": copy.deepcopy(usage)}
        records[request_id] = {"schema_version": "expgym.api_attempt.v1", **copy.deepcopy(ledger),
                               "client_id": name + "-client", "max_attempts": 3,
                               "finished_at_utc": "2026-09-11T00:00:00+00:00", "run_id": "deepseek-flash-native-smoke-" + name,
                               "endpoint": decoder.normalize_endpoint(config["base_url"]), "request_payload": copy.deepcopy(request),
                               "will_retry": False, "response_json": response, "response_raw": raw}
        return {"text": text, "tool_calls": calls, "assistant_message": saved, "finish_reason": saved_finish,
                "prompt_tokens": usage["prompt_tokens"], "completion_tokens": 12, "cached_prompt_tokens": 4,
                "cache_write_prompt_tokens": 2, "request_attempts": 1, "attempt_usage": [ledger]}

    first = decision(1, payload, assistant, "tool_calls")
    final_payload = copy.deepcopy(payload)
    final_payload.update(tool_choice="none", messages=initial + [copy.deepcopy(assistant),
        {"role": "tool", "tool_call_id": "native-call", "name": "read_note", "content": spec["note"]},
        {"role": "user", "content": CHECKS.FORCED_FINAL}])
    # Deliberately empty/length-limited: semantic quality is never a replay gate.
    final = decision(2, final_payload, {"role": "assistant", "content": "", "reasoning_content": "unfinished thought"}, "length")
    result = {"first": first, "final": final, "delivered_without_exception": True,
              "multi_turn_exercised": True, "input_messages_unchanged": True,
              "continuation_messages_unchanged": True, "final_has_no_tool_calls": True,
              "nonce_match_descriptive_only": False}
    return spec, result, records, config


class WireContractTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.inputs = CHECKS.Inputs()
        cls.decoder = CHECKS.load_decoder(cls.inputs, SOURCE)

    def check(self, values, name="auto"):
        spec, result, records, config = values
        return CHECKS.wire_contract(name, spec, result, records, config, self.decoder)

    def test_auto_and_named_preserve_typed_arguments_and_empty_final(self):
        for name in ("auto", "named-tool"):
            for typed in (False, True):
                with self.subTest(name=name, typed=typed):
                    values = fixture(self.decoder, name, typed)
                    original = copy.deepcopy(values)
                    self.assertEqual(len(self.check(values, name)), 2)
                    self.assertEqual(values, original)
                    self.assertFalse(values[1]["nonce_match_descriptive_only"])
        self.assertEqual(len(self.inputs.finish()), 1)

    def test_transport_retry_with_json_list_error_is_retained(self):
        values = fixture(self.decoder)
        _, result, records, _ = values
        success = records["auto-request-1"]
        success["attempt"] = 2
        result["first"]["attempt_usage"][0]["attempt"] = 2
        result["first"]["request_attempts"] = 2
        error = copy.deepcopy(success)
        error.update(request_id="retry-request", attempt=1, state="error", http_status=503,
                     will_retry=True, response_raw='["unavailable"]', response_json=["unavailable"],
                     error={"type": "HTTPError", "message": "unavailable"})
        records["retry-request"] = error
        result["first"]["attempt_usage"].insert(0, {"attempt": 1, "request_id": "retry-request",
            "generation_id": success["generation_id"], "state": "error", "http_status": 503, "usage": None})
        self.assertEqual(len(self.check(values)), 2)
        self.assertEqual(len(records), 3)
        error.update(http_status=None, response_raw=None, response_json=None,
                     error={"type": "ConnectionResetError", "message": "reset"})
        result["first"]["attempt_usage"][0]["http_status"] = None
        self.assertEqual(len(self.check(values)), 2)

    def test_tampered_artifacts_are_rejected(self):
        mutations = {
            "lost schema": lambda s, r, d, c: d["auto-request-2"]["request_payload"].pop("tools"),
            "changed reasoning": lambda s, r, d, c: d["auto-request-2"]["request_payload"]["messages"][2].update(reasoning_content="lost"),
            "changed raw": lambda s, r, d, c: d["auto-request-1"].update(response_raw="{}"),
            "changed final decoded text": lambda s, r, d, c: r["final"].update(text="not in response"),
            "changed usage": lambda s, r, d, c: r["first"].update(prompt_tokens=0),
            "changed endpoint": lambda s, r, d, c: d["auto-request-1"].update(endpoint="http://other.invalid/v1/chat/completions"),
            "changed client": lambda s, r, d, c: d["auto-request-2"].update(client_id="other"),
            "changed salt": lambda s, r, d, c: d["auto-request-2"]["request_payload"].update(cache_salt="different"),
            "changed max": lambda s, r, d, c: d["auto-request-1"]["request_payload"].update(reasoning_effort="high"),
            "changed thinking": lambda s, r, d, c: d["auto-request-1"]["request_payload"].update(chat_template_kwargs={"thinking": False}),
            "extra pretokenized input": lambda s, r, d, c: d["auto-request-1"]["request_payload"].update(input_ids=[1, 2, 3]),
            "in-flight": lambda s, r, d, c: d["auto-request-1"].update(finished_at_utc=None),
            "missing ledger": lambda s, r, d, c: r["first"].update(attempt_usage=[]),
            "extra attempt": lambda s, r, d, c: d.update(extra=copy.deepcopy(d["auto-request-1"])),
            "same generation": lambda s, r, d, c: r["final"]["attempt_usage"][0].update(generation_id=r["first"]["attempt_usage"][0]["generation_id"]),
            "not exercised": lambda s, r, d, c: r.update(multi_turn_exercised=False),
        }
        for label, mutate in mutations.items():
            with self.subTest(label=label):
                values = fixture(self.decoder)
                mutate(*values)
                with self.assertRaises((ValueError, KeyError)):
                    self.check(values)

    def test_pinned_decoder_normalizes_only_execution_copy(self):
        values = fixture(self.decoder, dictionary_arguments=True)
        self.check(values)
        message = values[1]["first"]["assistant_message"]
        self.assertIsInstance(message["tool_calls"][0]["function"]["arguments"], dict)
        self.assertIsInstance(values[1]["first"]["tool_calls"][0]["function"]["arguments"], str)
        self.assertEqual(self.decoder.normalize_endpoint("http://fixture.invalid/v1"), "http://fixture.invalid/v1/chat/completions")

    def test_invalid_retry_usage_remains_unknown(self):
        for usage in ({"prompt_tokens": True}, {"prompt_tokens": -1}, {"extension": float("nan")}, [1]):
            with self.subTest(usage=usage):
                self.assertIsNone(CHECKS.accepted_usage({"response_json": {"usage": usage}}, self.decoder))

    def test_reference_flattens_parts_and_preserves_reasoning_without_mutation(self):
        values = fixture(self.decoder, dictionary_arguments=True)
        payload = values[2]["auto-request-2"]["request_payload"]
        payload["messages"][2]["content"] = [{"type": "text", "text": "alpha"}, {"type": "input_text", "text": "beta"}]
        before = copy.deepcopy(payload)
        messages = CHECKS.reference_messages(payload, CHECKS.TOOLS)
        self.assertEqual(messages[2]["content"], "alpha beta")
        self.assertEqual(messages[2]["reasoning_content"], "prior reasoning sentinel")
        self.assertIsInstance(messages[2]["tool_calls"][0]["function"]["arguments"], str)
        self.assertEqual(payload, before)


class MetadataTest(unittest.TestCase):
    def test_inputs_pin_symlink_and_mutation(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory).resolve()
            path = root / "input.json"
            path.write_bytes(b"{}\n")
            inputs = CHECKS.Inputs()
            self.assertEqual(inputs.json(path, CHECKS.digest(b"{}\n")), {})
            with self.assertRaisesRegex(ValueError, "SHA mismatch"):
                inputs.read(path, "0" * 64)
            link = root / "link.json"
            link.symlink_to(path)
            with self.assertRaisesRegex(ValueError, "symlinks"):
                inputs.read(link)
            path.write_bytes(b'{"changed": true}\n')
            with self.assertRaisesRegex(ValueError, "changed after read"):
                inputs.finish()

    def test_outputs_are_fresh_and_cannot_touch_inputs_or_runtime(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory).resolve()
            study = root / "study"
            study.mkdir()
            native, runtime = study / "native", study / "runtime"
            native.mkdir()
            runtime.mkdir()
            output = study / "replay.json"
            CHECKS.write_fresh(output, {"passed": True}, study, [native])
            self.assertTrue(json.loads(output.read_text())["passed"])
            for blocked in (output, native / "new.json", runtime / "new.json", root / "escape.json"):
                with self.subTest(path=blocked), self.assertRaises(ValueError):
                    CHECKS.write_fresh(blocked, {}, study, [native])

    def test_collection_binds_all_saved_files_without_resampling(self):
        decoder = CHECKS.load_decoder(CHECKS.Inputs(), SOURCE)
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory).resolve()
            cases = []
            config = None
            for name in ("auto", "named-tool"):
                spec, result, records, config = fixture(decoder, name)
                case = root / name
                (case / "api_dump").mkdir(parents=True)
                (case / "case.json").write_text(json.dumps(spec))
                (case / "result.json").write_text(json.dumps(result))
                for request_id, record in records.items():
                    (case / "api_dump" / (request_id + ".json")).write_text(json.dumps(record))
                cases.append(result)
            script_sha = CHECKS.digest(Path(CHECKS.__file__).with_name("native_smoke.py").read_bytes())
            plan = {"config": config, "planned_cases": ["auto", "named-tool"], "script_sha256": script_sha}
            (root / "plan.json").write_text(json.dumps(plan))
            summary = {"passed": True, "planned_cases": 2, "cases": cases}
            (root / "summary.json").write_text(json.dumps(summary))
            pin = CHECKS.digest((root / "summary.json").read_bytes())
            inputs = CHECKS.Inputs()
            data = CHECKS.collect_native(inputs, root, pin, decoder)
            self.assertEqual(len(data["all_attempts"]), 4)
            self.assertEqual(len(inputs.finish()), 11)
            self.assertFalse(data["cases"][0]["nonce_match_descriptive_only"])
            summary["passed"] = False
            (root / "summary.json").write_text(json.dumps(summary))
            new_pin = CHECKS.digest((root / "summary.json").read_bytes())
            with self.assertRaisesRegex(ValueError, "do not resample"):
                CHECKS.collect_native(CHECKS.Inputs(), root, new_pin, decoder)


class ReplayTest(unittest.TestCase):
    def test_replay_evidence_and_token_count_gate_with_cpu_stubs(self):
        """Unit-test glue; these stubs do not count as a real runtime acceptance."""
        decoder = CHECKS.load_decoder(CHECKS.Inputs(), SOURCE)
        record = CHECKS.wire_contract("auto", *fixture(decoder), decoder)[1]
        rendered = "BOS MAX Available Tool Schemas prior reasoning sentinel SMOKE_NOTE_fixture"
        tokenizer = SimpleNamespace(encode=lambda value: list(value.encode()))
        class Request:
            def __init__(self, **payload):
                self.payload = copy.deepcopy(payload)
                self.tool_choice = payload["tool_choice"]
                self.tools = [SimpleNamespace(model_dump=lambda tool=tool: copy.deepcopy(tool)) for tool in payload["tools"]]
            def model_dump(self):
                return copy.deepcopy(self.payload)
        replay = CHECKS.Renderer.__new__(CHECKS.Renderer)
        replay.request_type, replay.tokenizer, replay.prefix = Request, tokenizer, " MAX"
        replay.reference = {"bos_token": "BOS", "encode_messages": lambda *args, **kwargs: rendered}
        replay.renderer = SimpleNamespace(_apply_jinja_template=lambda *args: SimpleNamespace(prompt_ids=tokenizer.encode(rendered)))
        record["response_json"]["usage"]["prompt_tokens"] = len(tokenizer.encode(rendered))
        record["response_raw"] = json.dumps(record["response_json"])
        evidence = replay.replay(record)
        self.assertTrue(evidence["maximum_prefix_present"])
        self.assertEqual(evidence["server_prompt_tokens"], evidence["replayed_prompt_tokens"])
        self.assertEqual(len(evidence["history"]), 2)
        record["response_json"]["usage"]["prompt_tokens"] += 1
        with self.assertRaisesRegex(ValueError, "prompt_tokens"):
            replay.replay(record)


if __name__ == "__main__":
    unittest.main()
