"""CPU-only acceptance for this fixed DeepSeek study, not a native/GPU smoke.

Run from the isolated runtime after sourcing runtime-env.sh, with
CUDA_VISIBLE_DEVICES='' and --checkpoint pointing at the recorded 0731 model.
No server/client is constructed and network connection attempts are forbidden.
--output is optional, must be fresh, and is confined to this runtime directory.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.metadata
import inspect
import json
import os
from pathlib import Path
import sys
from types import SimpleNamespace


BASE_COMMIT = "29481685462732237d80d86076d6563e1f658102"
PATCH_COMMIT = "059269594c5f245f77dad711631843c299d7713f"
PATCHED_SOURCES = {
    "chat_encoding.py": "4cc93655ba72dabc45b40a23a107c76c2208cb7c5c612193f6832388fe2c624c",
    "encoding_dsv4.py": "764dcfb28a57c3196975475747cb525ccacb4110556e3d9d35f038d6283ca527",
    "serving_chat.py": "c6b6d725b96e6a9fd924a39bf7702af0fbe1c657aa0678c0a48841e73b018603",
}
CONFIG_SHA256 = "6c8f3d2d3b48707541b88f32f22ef3f0f8a6b57d8523281e2b8d3cdb0ae9a023"
ENCODER_SHA256 = "abc0d26120250dda0ae077dc64aa28836026e61e970854aaeb792445e6a0dde6"
FIXED_VERSIONS = {
    "sglang": "0.5.17",
    "torch": "2.11.0+cu129",
    "torchaudio": "2.11.0+cu129",
    "torchvision": "0.26.0+cu129",
    "flashinfer-python": "0.6.15.post1",
    "sglang-kernel": "0.4.5+cu129",
    "sgl-deep-gemm": "0.1.5.post1+cu129",
    "quack-kernels": "0.6.1",
}


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def file_identity(path, expected=None, limit=16 << 20):
    path = Path(path)
    require(path.is_file(), f"Missing required file: {path}")
    require(path.stat().st_size <= limit, f"Refusing oversized metadata: {path}")
    data = path.read_bytes()
    digest = sha256(data)
    require(expected is None or digest == expected, f"Source identity mismatch: {path}")
    return {"path": str(path.resolve()), "bytes": len(data), "sha256": digest}


def load_reference_encoder(path):
    # Execute only the exact inspected, standard-library-only vendor encoder.
    identity = file_identity(path, ENCODER_SHA256, limit=1 << 20)
    source = Path(path).read_bytes()
    require(sha256(source) == ENCODER_SHA256, "Reference encoder changed before loading")
    namespace = {"__name__": "deepseek0731_fixed_reference_encoder"}
    exec(compile(source, str(path), "exec"), namespace)
    return namespace, identity


def synthetic_dialogs():
    spec = {
        "type": "function",
        "function": {
            "name": "observe",
            "description": "Return a synthetic observation, not benchmark data.",
            "parameters": {
                "type": "object",
                "properties": {
                    "trial": {"type": "integer"},
                    "label": {"type": "string"},
                    "enabled": {"type": "boolean"},
                    "values": {"type": "array", "items": {"type": "integer"}},
                },
                "required": ["trial", "label", "enabled", "values"],
            },
        },
    }
    args = {"trial": 2, "label": "synthetic-label", "enabled": True, "values": [1, 3]}
    base = [
        {"role": "system", "content": "Synthetic system sentinel."},
        {"role": "user", "content": "Synthetic question sentinel."},
    ]
    history = copy.deepcopy(base) + [
        {
            "role": "assistant", "content": "", "reasoning_content": "old_reasoning_sentinel",
            "tool_calls": [{"id": "call_synthetic", "type": "function", "function": {
                "name": "observe", "arguments": json.dumps(args),
            }}],
        },
        {"role": "tool", "tool_call_id": "call_synthetic", "content": "tool_result_sentinel"},
        {"role": "user", "content": "final_instruction_sentinel"},
    ]
    dialogs = [
        ("plain", base, None, "auto"),
        ("tool_start", copy.deepcopy(base), [spec], "auto"),
        ("tool_history_forced_final", history, [spec], "none"),
    ]
    return dialogs, spec, args


def json_string_arguments(messages):
    """Adapt only the reference's documented JSON-string input boundary."""
    result = copy.deepcopy(messages)
    for message in result:
        for call in message.get("tool_calls") or []:
            function = call["function"]
            if isinstance(function.get("arguments"), dict):
                function["arguments"] = json.dumps(function["arguments"], ensure_ascii=False)
    return result


def write_fresh_result(path, result, root):
    path, root = Path(path), Path(root).resolve()
    require(path.is_absolute(), "--output must be absolute")
    require(path.parent.is_dir(), "--output parent must already exist")
    require(path.parent.resolve().is_relative_to(root), "--output must be inside this runtime")
    require(not path.exists() and not path.is_symlink(), "Refusing to overwrite an output")
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
    payload = (json.dumps(result, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
    with os.fdopen(os.open(path, flags, 0o644), "wb") as handle:
        handle.write(payload)


def run_checks(checkpoint):
    require(os.environ.get("CUDA_VISIBLE_DEVICES") == "", "Set CUDA_VISIBLE_DEVICES='' first")
    require(sys.version_info[:2] == (3, 12), "Use the isolated Python 3.12 runtime")
    require(os.environ.get("HF_HUB_OFFLINE") == "1", "Set HF_HUB_OFFLINE=1 first")
    require(os.environ.get("TRANSFORMERS_OFFLINE") == "1", "Set TRANSFORMERS_OFFLINE=1 first")
    sys.dont_write_bytecode = True
    network_attempts = []

    def deny_network(event, arguments):
        if event in ("socket.connect", "socket.getaddrinfo"):
            network_attempts.append(event)
            raise RuntimeError("Network access forbidden during CPU acceptance")

    sys.addaudithook(deny_network)
    checkpoint = Path(checkpoint).resolve(strict=True)
    runtime_root = Path(__file__).resolve().parent
    require(Path(sys.prefix).resolve() == runtime_root / ".venv", "Wrong runtime interpreter")
    config_identity = file_identity(checkpoint / "config.json", CONFIG_SHA256)
    reference, encoder_identity = load_reference_encoder(checkpoint / "encoding/encoding_dsv4.py")
    fixed_versions = {name: importlib.metadata.version(name) for name in FIXED_VERSIONS}
    require(fixed_versions == FIXED_VERSIONS, "Fixed runtime distribution versions differ")

    import torch
    import sglang
    from transformers import AutoConfig, AutoTokenizer
    from sglang.srt.entrypoints.openai import chat_encoding, encoding_dsv4, serving_chat
    from sglang.srt.entrypoints.openai.protocol import ChatCompletionRequest, Tool
    from sglang.srt.entrypoints.openai.serving_base import OpenAIServingBase
    from sglang.srt.function_call.deepseekv4_detector import DeepSeekV4Detector
    from sglang.srt.mem_cache.radix_cache import RadixKey
    from sglang.srt.models.registry import ModelRegistry
    from sglang.srt.parser.reasoning_parser import ReasoningParser

    require(not torch.cuda.is_initialized(), "Imports initialized CUDA")
    source_root = Path(sglang.__file__).resolve().parent
    require(source_root.is_relative_to(runtime_root / ".venv"), "SGLang imported outside this runtime")
    patched = {
        name: file_identity(source_root / "srt/entrypoints/openai" / name, expected)
        for name, expected in PATCHED_SOURCES.items()
    }
    config = AutoConfig.from_pretrained(checkpoint, local_files_only=True, trust_remote_code=False)
    require(config.architectures == ["DeepseekV4ForCausalLM"], "Unexpected model architecture")
    require(config.expert_dtype == "fp4", "Not the native FP4 checkpoint")
    require(config.quantization_config["quant_method"] == "fp8", "Unexpected dense quantization")
    require((config.hidden_size, config.num_hidden_layers, config.o_groups) == (4096, 43, 8), "Unexpected model geometry")
    require(config.num_attention_heads % 8 == 0 and config.o_groups % 8 == 0, "TP8 geometry mismatch")
    require(config.moe_intermediate_size // 8 % 32 == 0, "Marlin TP8 group misalignment")
    tokenizer = AutoTokenizer.from_pretrained(checkpoint, local_files_only=True, trust_remote_code=False)
    require(tokenizer.chat_template is None, "Expected dedicated Python encoder, not Jinja")
    profile = chat_encoding.resolve_dsv4_reasoning_effort_profile(model_path=str(checkpoint))
    require(profile == "official", "Checkpoint did not resolve to official effort profile")
    require(chat_encoding.resolve_chat_encoding_spec(hf_config=config, tokenizer=tokenizer, tool_call_parser="deepseekv4") == "dsv4", "Wrong encoding dispatch")
    require(encoding_dsv4.REASONING_EFFORT_PROFILES[profile] == reference["REASONING_EFFORT_PROMPTS"], "Effort mapping differs from checkpoint")
    prefix = encoding_dsv4.REASONING_EFFORT_PROFILES[profile]["max"]
    prefix_ids = tokenizer.encode(prefix, add_special_tokens=False)

    # Invoke the actual serving renderer, with only its tokenizer/config holders
    # supplied. __init__ is deliberately bypassed: no server, engine or client.
    renderer = serving_chat.OpenAIServingChat.__new__(serving_chat.OpenAIServingChat)
    renderer.chat_encoding_spec = "dsv4"
    renderer._dsv4_reasoning_effort_profile = profile
    renderer.template_manager = SimpleNamespace(jinja_template_content_format="string")
    renderer.tokenizer_manager = SimpleNamespace(tokenizer=tokenizer)
    dialogs, tool_spec, expected_args = synthetic_dialogs()
    comparisons = []
    for case, messages, tools, choice in dialogs:
        for effort in ("low", "high", "max"):
            request = ChatCompletionRequest(
                model="synthetic-non-name-dispatch-id", messages=copy.deepcopy(messages),
                tools=copy.deepcopy(tools), tool_choice=choice,
                reasoning_effort=effort, chat_template_kwargs={"thinking": True},
                cache_salt=f"deepseek_cpu_{case}_{effort}",
            )
            require(request.chat_template_kwargs["thinking"] is True, "Thinking disabled")
            require(request.chat_template_kwargs["enable_thinking"] is True, "Effort validator did not enable thinking")
            before = request.model_dump()
            tool_arg = None if choice == "none" or not tools else [tool.model_dump() for tool in request.tools]
            actual = renderer._apply_jinja_template(request, tool_arg, False)
            require(request.model_dump() == before, "Renderer mutated the input request")
            expected_messages = json_string_arguments(messages)
            if tools:
                expected_messages[0]["tools"] = [tool.model_dump() for tool in request.tools]
            expected_prompt = reference["encode_messages"](
                copy.deepcopy(expected_messages), thinking_mode="thinking", reasoning_effort=effort,
            )
            normalized_messages = copy.deepcopy(expected_messages)
            for message in normalized_messages:
                for call in message.get("tool_calls") or []:
                    call["function"]["arguments"] = json.loads(call["function"]["arguments"])
            runtime_prompt = encoding_dsv4.encode_messages(
                normalized_messages, thinking_mode="thinking", reasoning_effort=effort,
                reasoning_effort_profile=profile,
            )
            require(runtime_prompt == expected_prompt, f"Reference string differs: {case}/{effort}")
            expected_ids = tokenizer.encode(expected_prompt)
            require(actual.prompt_ids == expected_ids, f"Actual serving token IDs differ: {case}/{effort}")
            if tools:
                require("Available Tool Schemas" in runtime_prompt and "observe" in runtime_prompt, "Tool schema lost")
            if choice == "none":
                for sentinel in ("old_reasoning_sentinel", "tool_result_sentinel", "final_instruction_sentinel"):
                    require(sentinel in runtime_prompt, f"Forced-final history lost: {sentinel}")
            salt = OpenAIServingBase._compute_extra_key(renderer, request)
            require(salt == request.cache_salt, "cache_salt did not become extra_key")
            comparisons.append({
                "dialog": case, "reasoning_effort": effort, "tool_choice": choice,
                "characters": len(runtime_prompt), "prompt_tokens": len(expected_ids),
                "prompt_utf8_sha256": sha256(runtime_prompt.encode("utf-8")),
                "token_ids_json_sha256": sha256(json.dumps(expected_ids, separators=(",", ":")).encode()),
                "reference_exact_match": True, "actual_serving_token_match": True,
                "tool_definitions_retained": bool(tools),
            })

    dsml = (
        '<｜DSML｜tool_calls>\n<｜DSML｜invoke name="observe">\n'
        '<｜DSML｜parameter name="trial" string="false">2</｜DSML｜parameter>\n'
        '<｜DSML｜parameter name="label" string="true">synthetic-label</｜DSML｜parameter>\n'
        '<｜DSML｜parameter name="enabled" string="false">true</｜DSML｜parameter>\n'
        '<｜DSML｜parameter name="values" string="false">[1, 3]</｜DSML｜parameter>\n'
        '</｜DSML｜invoke>\n</｜DSML｜tool_calls>'
    )
    parsed = DeepSeekV4Detector().detect_and_parse(dsml, [Tool(**tool_spec)])
    require(len(parsed.calls) == 1 and parsed.calls[0].name == "observe", "Tool parser name/count mismatch")
    require(json.loads(parsed.calls[0].parameters) == expected_args, "Tool parser changed typed arguments")
    reason, final = ReasoningParser(model_type="deepseek-v4").parse_non_stream(
        "<think>synthetic_reasoning_segment</think>synthetic_final_segment"
    )
    require(reason.strip() == "synthetic_reasoning_segment" and final.strip() == "synthetic_final_segment", "Reasoning/final parser mismatch")
    tokens = list(range(256))
    a, b, same = RadixKey(tokens, "salt_a"), RadixKey(tokens, "salt_b"), RadixKey(tokens, "salt_a")
    require(a.child_key(256) != b.child_key(256), "Cross-salt page alias")
    require(a.child_key(256) == same.child_key(256), "Same-salt page mismatch")
    require(a[:128].extra_key == "salt_a", "Slicing lost cache salt")
    require(a.match(same, page_size=256) == 256, "Same-salt match failed")
    try:
        a.match(b, page_size=256)
    except ValueError:
        pass
    else:
        raise AssertionError("Cross-salt prefix matching unexpectedly allowed")
    model_class, arch = ModelRegistry.resolve_model_cls(config.architectures)
    require(model_class.__name__ == "DeepseekV4ForCausalLM", "Wrong native model registry class")
    require(model_class.__module__ == "sglang.srt.models.deepseek_v4", "Transformers fallback or wrong registry module")
    require(not torch.cuda.is_initialized(), "CPU checks initialized CUDA")
    require(not network_attempts, "A network connection was attempted")
    metadata = {}
    for name in ("config.json", "generation_config.json", "tokenizer_config.json", "tokenizer.json", "model.safetensors.index.json", "README.md", "encoding/encoding_dsv4.py"):
        metadata[name] = file_identity(checkpoint / name)
    require(metadata["config.json"] == config_identity, "Config changed during CPU checks")
    require(metadata["encoding/encoding_dsv4.py"] == encoder_identity, "Encoder changed during CPU checks")
    runtime_inputs = {name: file_identity(runtime_root / name) for name in ("uv.lock", "pyproject.toml", "runtime-env.sh", "verify_cpu.py")}
    checked_sources = {
        "model_registry_class": file_identity(inspect.getsourcefile(model_class)),
        "radix_key": file_identity(inspect.getsourcefile(RadixKey)),
        "tool_parser": file_identity(inspect.getsourcefile(DeepSeekV4Detector)),
        "reasoning_parser": file_identity(inspect.getsourcefile(ReasoningParser)),
        "cache_extra_key": file_identity(inspect.getsourcefile(OpenAIServingBase)),
    }
    return {
        "schema": "deepseek0731.cpu-acceptance.v1", "status": "passed_cpu_only_not_native_or_gpu_validation",
        "python": sys.version, "executable": sys.executable, "checkpoint": str(checkpoint),
        "sglang_base_commit": BASE_COMMIT, "upstream_effort_patch_commit": PATCH_COMMIT,
        "fixed_distribution_versions": fixed_versions,
        "distributions": dict(sorted((dist.metadata["Name"], dist.version) for dist in importlib.metadata.distributions())),
        "torch_cuda_wheel": torch.version.cuda, "cuda_initialized": torch.cuda.is_initialized(),
        "network_connection_attempts": len(network_attempts), "api_requests": 0,
        "model_tensors_loaded": False, "checkpoint_tensor_payloads_hashed": False,
        "encoder_comparison_cases": comparisons, "cpu_serving_renderer_calls": len(comparisons),
        "effort_profile": profile,
        "maximum_effort_prefix": {"utf8_bytes": len(prefix.encode()), "sha256": sha256(prefix.encode()), "token_count": len(prefix_ids), "token_ids": prefix_ids},
        "typed_tool_parser": {"passed": True, "arguments": expected_args},
        "reasoning_final_split": True, "cache_salt_cpu_checks": 5,
        "native_model_registry": {"architecture": arch, "module": model_class.__module__, "class": model_class.__name__},
        "patched_sources": patched, "checked_sources": checked_sources,
        "runtime_inputs": runtime_inputs, "model_metadata": metadata,
        "limitations": [
            "Synthetic CPU rendering/parser checks are not native HTTP or model correctness evidence.",
            "No CUDA kernels, model weights, runtime cache implementation selection or concurrent inference were exercised.",
            "tool_choice=none still renders definitions in the fixed dsv4 provider encoder; history is retained.",
            "Maximum effort profile does not imply any particular request output-token budget.",
        ],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.output and (args.output.exists() or args.output.is_symlink()):
        parser.error("--output must be fresh; no existing result is overwritten")
    result = run_checks(args.checkpoint)
    if args.output:
        write_fresh_result(args.output, result, Path(__file__).resolve().parent)
    print(json.dumps({
        "status": result["status"], "cpu_serving_renderer_calls": result["cpu_serving_renderer_calls"],
        "effort_profile": result["effort_profile"], "cuda_initialized": result["cuda_initialized"],
        "api_requests": 0, "output": str(args.output) if args.output else None,
        "result": result if args.output is None else None,
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
