"""Small helper tests; these do not import a serving runtime or load a model."""

import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

SPEC = importlib.util.spec_from_file_location("deepseek_cpu_checks", Path(__file__).with_name("verify_cpu.py"))
CHECKS = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CHECKS)


class CpuAcceptanceHelpersTest(unittest.TestCase):
    def test_metadata_identity_and_guard(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "metadata.json"
            path.write_bytes(b"{}\n")
            digest = CHECKS.sha256(b"{}\n")
            self.assertEqual(CHECKS.file_identity(path, digest)["bytes"], 3)
            with self.assertRaisesRegex(AssertionError, "identity mismatch"):
                CHECKS.file_identity(path, "0" * 64)
            with self.assertRaisesRegex(AssertionError, "oversized"):
                CHECKS.file_identity(path, limit=2)

    def test_reference_encoder_rejects_unknown_source(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "encoder.py"
            path.write_text("raise RuntimeError('must never execute')\n")
            with self.assertRaisesRegex(AssertionError, "identity mismatch"):
                CHECKS.load_reference_encoder(path)

    def test_dialogs_and_reference_boundary(self):
        dialogs, spec, expected = CHECKS.synthetic_dialogs()
        self.assertEqual(len(dialogs), 3)
        self.assertEqual(dialogs[-1][-1], "none")
        messages = copy.deepcopy(dialogs[-1][1])
        call = messages[2]["tool_calls"][0]["function"]
        call["arguments"] = expected
        before = copy.deepcopy(messages)
        normalized = CHECKS.json_string_arguments(messages)
        self.assertEqual(json.loads(normalized[2]["tool_calls"][0]["function"]["arguments"]), expected)
        self.assertEqual(messages, before)
        self.assertEqual(normalized[2]["reasoning_content"], "old_reasoning_sentinel")
        self.assertEqual(spec["function"]["name"], "observe")

    def test_fresh_result_and_overwrite_rejection(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            output = root / "result.json"
            CHECKS.write_fresh_result(output, {"cpu_only": True}, root)
            self.assertEqual(json.loads(output.read_text()), {"cpu_only": True})
            original = output.read_bytes()
            with self.assertRaisesRegex(AssertionError, "overwrite"):
                CHECKS.write_fresh_result(output, {"cpu_only": False}, root)
            self.assertEqual(output.read_bytes(), original)

    def test_output_escape_and_symlink_rejection(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            allowed, other = root / "allowed", root / "other"
            allowed.mkdir()
            other.mkdir()
            with self.assertRaisesRegex(AssertionError, "inside this runtime"):
                CHECKS.write_fresh_result(other / "result.json", {}, allowed)
            link = allowed / "result.json"
            link.symlink_to(other / "missing.json")
            with self.assertRaisesRegex(AssertionError, "overwrite"):
                CHECKS.write_fresh_result(link, {}, allowed)
            self.assertFalse((other / "missing.json").exists())

    def test_fixed_identity_schema(self):
        self.assertEqual(len(CHECKS.PATCHED_SOURCES), 3)
        self.assertTrue(all(len(value) == 64 for value in CHECKS.PATCHED_SOURCES.values()))
        self.assertEqual(CHECKS.FIXED_VERSIONS["sglang"], "0.5.17")
        self.assertEqual(CHECKS.FIXED_VERSIONS["torch"], "2.11.0+cu129")


if __name__ == "__main__":
    unittest.main()
