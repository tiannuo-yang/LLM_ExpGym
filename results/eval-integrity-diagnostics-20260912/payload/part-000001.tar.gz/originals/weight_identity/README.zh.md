# DeepSeek checkpoint payload 一次性完整性核验

这是本地下载记录一致性检查，不是模型生成验证，也不是独立远端真实性认证。

核验对象：`/lustrefs/users/runner/chufan.shi/tau_vision/ckpts/DeepSeek-V4-Flash-0731`。
预检确认连续完整的 48 个 safetensors shards，总计 166,886,535,336 bytes。
每个文件的预期 SHA256 来自其 `.cache/huggingface/download/<filename>.metadata`；
所有记录指向 commit `7872f01b1d1fe23eabc4c98b48bffcef5a386062`。
这些 metadata 不是本检查从独立可信渠道获得的签名清单。

执行限制：在已授权 Slurm job `1205016` 的
`azure-uk-hpc-H200-instance-012` 节点上，用一个顺序流式读取进程、8 MiB buffer，
每个 payload 只做一遍 SHA256。无模型调用、GPU 计算、并发 payload 扫描、自动重试、
checkpoint 写入、缓存删除或环境安装；任何 I/O 错误、内容不匹配或文件身份变化均停止。
这会读取约 166.9 GB 共享存储，可能与同节点模型加载竞争或共享页缓存；
不能据此声称它加快了模型启动。

本次已完成：**48/48 SHA256 全部匹配**，一次顺序读取 166,886,535,336 bytes，
耗时 174.519 秒，进程用户/系统 CPU 时间分别为 117.729 / 51.669 秒。
Slurm step `1205016.12`，进程正常退出（exit 0），未发现 I/O 错误或文件身份变化。
结束后仅复核小型输出清单、98 条事件及 summary，没有第二遍扫描 payload。

文件索引：

- `verify_checkpoint.py`：只读 checkpoint 的核验程序；输出仅限本目录。
- `inventory.json`：预检后的文件名、尺寸、mtime、预期 SHA256 和 metadata 原文件 SHA256。
  本次 SHA256：`566b2742147a75d93e20153de56067390b3393d19e9427539b2992f182d203b5`。
- `events.jsonl`：逐 shard 开始/结束、累计执行终态；执行中持续写入。
- `summary.json`：完整核验完成或首个受控失败时生成；不存在时不能宣称完成。
  本次 SHA256：`4bc5871bbdd5ce6aa5235a7fedb82d90f36a57fe02e6b93bb500725ee4f5e426`。

所有输出 create-only；不得把未完的核验重新运行到同一目录。最终通过只排除
“当前 payload 与这些本地下载 SHA256 不一致”，不排除上游权重本身问题、
runtime/kernel 数值问题、加载后内存问题、模板问题或模型真实能力差异。
