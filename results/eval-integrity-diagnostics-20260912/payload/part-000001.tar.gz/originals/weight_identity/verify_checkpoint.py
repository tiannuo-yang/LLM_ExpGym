#!/usr/bin/env python3
"""Single sequential payload pass against frozen local HF download metadata.

No remote authenticity claim, checkpoint mutation, model import, or retry.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import resource
import socket
import stat
import sys
import time


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def create_json(path, value):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def inventory(root, expected_count=48):
    paths = sorted(root.glob("*.safetensors"))
    expected = [f"model-{i:05d}-of-{expected_count:05d}.safetensors"
                for i in range(1, expected_count + 1)]
    if [path.name for path in paths] != expected:
        raise ValueError("Shard names/count do not match the complete expected set")
    entries = []
    for path in paths:
        before = path.stat()
        if not stat.S_ISREG(before.st_mode) or before.st_size <= 0:
            raise ValueError(f"Not a nonempty regular payload: {path.name}")
        meta = root / ".cache/huggingface/download" / (path.name + ".metadata")
        raw = meta.read_bytes()
        lines = raw.decode("utf-8").splitlines()
        if len(lines) != 3 or not re.fullmatch(r"[0-9a-f]{40}", lines[0]):
            raise ValueError(f"Unexpected metadata commit/format: {path.name}")
        if not re.fullmatch(r"[0-9a-f]{64}", lines[1]):
            raise ValueError(f"Expected SHA256 digest missing: {path.name}")
        timestamp = float(lines[2])
        if not math.isfinite(timestamp) or timestamp <= 0:
            raise ValueError(f"Unexpected metadata timestamp: {path.name}")
        entries.append({"name": path.name, "size_bytes": before.st_size,
                        "mtime_ns": before.st_mtime_ns,
                        "metadata_path": str(meta),
                        "metadata_sha256": sha256(raw),
                        "recorded_commit": lines[0],
                        "expected_sha256": lines[1],
                        "download_timestamp": timestamp})
    commits = sorted(set(item["recorded_commit"] for item in entries))
    if len(commits) != 1:
        raise ValueError("Payload metadata is not bound to one recorded commit")
    return {"schema": "local-hf-payload-identity-v1", "checkpoint": str(root),
            "scope": "SHA256 consistency with local download records; not independent remote authenticity",
            "count": len(entries), "total_bytes": sum(item["size_bytes"] for item in entries),
            "recorded_commits": commits, "entries": entries}


def verify(frozen, output):
    root = Path(frozen["checkpoint"])
    if inventory(root, frozen["count"]) != frozen:
        raise ValueError("Inventory changed since preflight")
    start = time.monotonic()
    usage_start = resource.getrusage(resource.RUSAGE_SELF)
    completed = []
    total_bytes = 0
    failure = None
    fd = os.open(output / "events.jsonl", os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w", buffering=1) as log:
        def emit(event):
            log.write(json.dumps(event, sort_keys=True) + "\n")
        emit({"event": "verification_start", "utc_epoch": time.time(),
              "hostname": socket.gethostname(), "pid": os.getpid(),
              "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
              "slurm_step_id": os.environ.get("SLURM_STEP_ID"),
              "count": frozen["count"], "total_bytes": frozen["total_bytes"],
              "script_sha256": sha256(Path(__file__).read_bytes()),
              "algorithm": "SHA256", "concurrency": 1, "buffer_bytes": 8 * 1024 * 1024})
        for item in frozen["entries"]:
            began = time.monotonic()
            read_bytes = 0
            digest = hashlib.sha256()
            emit({"event": "shard_start", "name": item["name"], "utc_epoch": time.time()})
            try:
                with (root / item["name"]).open("rb", buffering=0) as stream:
                    buffer = bytearray(8 * 1024 * 1024)
                    while size := stream.readinto(buffer):
                        digest.update(memoryview(buffer)[:size])
                        read_bytes += size
                        total_bytes += size
                    after = os.fstat(stream.fileno())
                actual = digest.hexdigest()
                if read_bytes != item["size_bytes"] or after.st_size != item["size_bytes"] or after.st_mtime_ns != item["mtime_ns"]:
                    raise ValueError("Payload size/mtime changed during verification")
                if sha256(Path(item["metadata_path"]).read_bytes()) != item["metadata_sha256"]:
                    raise ValueError("Local download metadata changed during verification")
                if actual != item["expected_sha256"]:
                    raise ValueError("Payload SHA256 mismatch against local download metadata")
                result = {"event": "shard_complete", "name": item["name"],
                          "utc_epoch": time.time(), "bytes_read": read_bytes,
                          "elapsed_seconds": time.monotonic() - began,
                          "expected_sha256": item["expected_sha256"],
                          "actual_sha256": actual, "metadata_sha256": item["metadata_sha256"],
                          "status": "match"}
                completed.append(result)
                emit(result)
                print(f"{len(completed)}/{frozen['count']} {item['name']} MATCH {read_bytes} bytes {result['elapsed_seconds']:.1f}s", flush=True)
            except (OSError, ValueError) as exc:
                failure = {"event": "shard_failed", "name": item["name"],
                           "utc_epoch": time.time(), "bytes_read": read_bytes,
                           "elapsed_seconds": time.monotonic() - began,
                           "expected_sha256": item["expected_sha256"],
                           "actual_partial_or_full_sha256": digest.hexdigest(),
                           "error_type": type(exc).__name__, "error": str(exc)}
                emit(failure)
                break
        usage_end = resource.getrusage(resource.RUSAGE_SELF)
        summary = {"schema": "local-hf-payload-verification-v1", "scope": frozen["scope"],
                   "hostname": socket.gethostname(), "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
                   "expected_count": frozen["count"], "matched_count": len(completed),
                   "planned_bytes": frozen["total_bytes"], "bytes_read": total_bytes,
                   "elapsed_seconds": time.monotonic() - start,
                   "cpu_user_seconds": usage_end.ru_utime - usage_start.ru_utime,
                   "cpu_system_seconds": usage_end.ru_stime - usage_start.ru_stime,
                   "status": "passed" if failure is None else "failed", "failure": failure,
                   "script_sha256": sha256(Path(__file__).read_bytes()),
                   "inventory_sha256": sha256((output / "inventory.json").read_bytes()),
                   "results": completed}
        emit({"event": "verification_end", "utc_epoch": time.time(),
              "status": summary["status"], "matched_count": len(completed),
              "bytes_read": total_bytes, "elapsed_seconds": summary["elapsed_seconds"]})
    create_json(output / "summary.json", summary)
    return 0 if failure is None else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("operation", choices=("preflight", "verify"))
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--inventory-sha256")
    args = parser.parse_args()
    if args.operation == "preflight":
        frozen = inventory(args.checkpoint)
        create_json(args.output / "inventory.json", frozen)
        print(json.dumps({key: value for key, value in frozen.items() if key != "entries"}, sort_keys=True))
        print("inventory_sha256=" + sha256((args.output / "inventory.json").read_bytes()))
        return 0
    raw = (args.output / "inventory.json").read_bytes()
    if not args.inventory_sha256 or sha256(raw) != args.inventory_sha256:
        raise ValueError("Explicit preflight inventory hash is required and must match")
    frozen = json.loads(raw)
    if frozen["checkpoint"] != str(args.checkpoint):
        raise ValueError("Checkpoint differs from frozen inventory")
    return verify(frozen, args.output)


if __name__ == "__main__":
    sys.exit(main())
