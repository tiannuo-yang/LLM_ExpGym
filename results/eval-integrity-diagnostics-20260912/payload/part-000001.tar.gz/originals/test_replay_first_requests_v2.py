"""CPU-only v2 ordered-wire and no-retry regression tests."""
import copy
import json
from pathlib import Path
import tempfile
import unittest

import replay_first_requests as v1
import replay_first_requests_v2 as v2
from test_replay_first_requests import Opener, response, CALL


def payload():
    return {"model": "unfamiliar-model", "messages": [{"role": "system", "content": "中文"}, {"role": "user", "content": "b"}],
            "tools": [{"type": "function", "function": {"name": "audit", "parameters": {"type": "object", "properties": {"nda_id": {"type": "string"}, "evidence_ids": {"type": "array", "items": {"type": "integer"}}}, "required": ["nda_id", "evidence_ids"], "additionalProperties": False}}}],
            "tool_choice": "auto", "parallel_tool_calls": False, "seed": 2202, "max_tokens": 32768,
            "temperature": 1.0, "top_p": .95, "reasoning_effort": "max", "chat_template_kwargs": {"thinking": True}}


class OrderedWireTests(unittest.TestCase):
    def test_wire_is_exact_frozen_client_expression(self):
        original = payload()
        wire = v2.wire_body(original)
        self.assertEqual(wire, json.dumps(original).encode("utf-8"))
        self.assertIn(b"\\u4e2d\\u6587", wire)
        self.assertIn(b'"model": "unfamiliar-model", "messages":', wire)
        self.assertNotEqual(wire, v1.canonical(original))

    def test_nested_property_order_survives_transport(self):
        original = payload()
        opener = Opener(json.dumps(response()).encode())
        with tempfile.TemporaryDirectory() as temp:
            target = Path(temp)/"attempt"
            record, _ = v2.one_request(original, "evidence_audit", "http://localhost", target, {}, 1, opener=opener)
            wire = opener.requests[0][0].data
            self.assertEqual((target/"request.json").read_bytes(), wire)
            self.assertEqual(wire, json.dumps(original).encode("utf-8"))
            properties = json.loads(wire)["tools"][0]["function"]["parameters"]["properties"]
            self.assertEqual(list(properties), ["nda_id", "evidence_ids"])
            self.assertEqual(record["request_wire_sha256"], v1.sha(wire))
            self.assertEqual(record["request_semantic_canonical_sha256"], v1.sha(v1.canonical(original)))

    def test_key_reordering_semantic_equal_but_wire_not_equal(self):
        original = payload()
        reordered = json.loads(v1.canonical(original))
        self.assertEqual(original, reordered)
        self.assertEqual(v1.canonical(original), v1.canonical(reordered))
        self.assertNotEqual(v2.wire_body(original), v2.wire_body(reordered))
        self.assertNotEqual(list(original["tools"][0]["function"]["parameters"]["properties"]), list(reordered["tools"][0]["function"]["parameters"]["properties"]))

    def test_payload_unchanged_and_bad_delivery_not_retried(self):
        original = payload()
        snapshot = copy.deepcopy(original)
        opener = Opener(b'{"choices": []}')
        with tempfile.TemporaryDirectory() as temp:
            target = Path(temp)/"attempt"
            record, _ = v2.one_request(original, "evidence_audit", "http://localhost", target, {}, 1, opener=opener)
            with self.assertRaises(FileExistsError):
                v2.one_request(original, "evidence_audit", "http://localhost", target, {}, 1, opener=opener)
        self.assertEqual(original, snapshot)
        self.assertEqual(len(opener.requests), 1)
        self.assertEqual(record["state"], "delivered")
        self.assertFalse(record["will_retry"])

    def test_frozen_originals_match_independent_wire_render_audit(self):
        manifest, payloads, _ = v2.checked_cases(v2.ROOT / "INPUTS.v2.json")
        self.assertEqual([case["expected_prompt_tokens"] for case in manifest["cases"]], [1974, 2824, 1860, 730])
        for case in manifest["cases"]:
            self.assertEqual(v1.sha(v2.wire_body(payloads[case["case_id"]])), case["ordered_wire_sha256"])
            self.assertTrue(case["expected_rendered_prompt_utf8_sha256"])
        self.assertEqual(v2.identify(v2.ROOT / "INPUTS.json")["sha256"], v2.V1_INPUTS_SHA)
        self.assertEqual(v2.identify(v2.ROOT / "replay_first_requests.py")["sha256"], v2.V1_HELPER_SHA)

    def test_multiple_schema_valid_tools_not_exactly_one(self):
        from test_replay_first_requests import PAYLOAD
        opener = Opener(json.dumps(response(calls=[CALL, {**CALL, "id": "other"}])).encode())
        with tempfile.TemporaryDirectory() as temp:
            record, _ = v2.one_request(PAYLOAD, "evidence_audit", "http://localhost", Path(temp)/"attempt", {}, 1, opener=opener)
        self.assertEqual(record["shape"]["valid_tool_calls"], 2)
        self.assertEqual(record["native_raw_tool_call_count"], 2)
        self.assertFalse(record["native_exactly_one_schema_valid_tool_call"])
        self.assertTrue(record["schema_shape_flag_is_not_runner_acceptance"])


if __name__ == "__main__":
    unittest.main()
