# 有限 smoke 比较导出器（已准备，不启动实验）

`spec.json` 保留 GLM baseline 六槽、DeepSeek streamoff 六池，并将另一个 GLM Audit continuation 三池单独绑定；新 continuation 的实际 plans/bindings 填齐前不能导出。原 Deep baseline PoolAct 不复用。
源身份冻结为 `e9657547…`。根 agent 在实验/validation 完成并停止写入后，更新 spec 中实际批准但未开始状态、额外 candidate replay SUMMARY 路径，然后执行一次：

```bash
/lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python -B \
  /lustrefs/users/chufan.shi/codex_space_tn/eval_diagnostics_20260912/reporting/compare_smokes.py \
  --spec /lustrefs/users/chufan.shi/codex_space_tn/eval_diagnostics_20260912/reporting/spec.json \
  --output /lustrefs/users/chufan.shi/codex_space_tn/eval_diagnostics_20260912/reporting/final_v1
```

输出目录必须不存在。七个产物：`per_pool.csv`、`per_agent.csv`、`comparisons.csv`、`physical_attempts.csv`、`costs.csv`、`INDEX.json`、`ARCHIVE_INDEX.md`。不生成主报告/详细报告正文，不改旧 reports，不运行模型/评分器。

NAS 报告保存的 raw accuracy MI/BoN，任一必要成员缺配置则完整端点未知，不自动新增 Gap0。Audit EA/LA 分别读取 `answer_metrics`，MI 平均全部保存成员分，MV 用保存 aggregate；不能把 label `answer_perf` 当 EA。所有差值均 target−control，负值保留。

只有 `validation.json` 已验证 source/config/result 身份后，分数才能进入比较。保存的 `score_check` 是既有评分证据，本导出不重新调用它。未开始、待批准、失败、等待验证、评分不完整分别保留；默认未开始，可在 `unstarted_status_by_job` 显式声明 `pending_approval` 或 `cancelled_before_start`，也可用 `{"status":"not_started_infra_budget","reason":"..."}` 记录因基础设施时限未启动。已有 execution 标志优先，声明与原因仍保留，不给未知成本补零。

`comparison_role_by_job` 接受 `{"role":"superseded_for_matched","reason":"..."}`，未声明默认为 `primary`。同一 cohort 三策略必须同角色；同模型/任务/预算/N/seed 不能有两个 primary cohort。GLM 旧 Audit 三槽全部 superseded（旧 Pool 成绩保留，两 controls 未启动），新 continuation 独立三策略才是主比较；NAS 仍用旧 cohort。`comparisons.csv` 同时保留两类，主报告只使用 `comparison_role=primary`，不跨 cohort 拼分。原池、成员、物理尝试和费用不因 superseded 删除；INDEX 分别给出全槽与 primary 完整性。

读取本 cohort 的 validation inventory 中物理 API attempts；未验证/失败 job 仅查看其精确 dump 目录一层，不递归扫描旧 raw。失败或缺少 usage 保留 unknown、已知子总和另列。reasoning 包含于 output、cached input 包含于 input，不重复相加。请求墙钟之和不是实验总历时或 GPU-hours。

物理状态采用显式 taxonomy：`success/delivered` 为成功；`error/failed/transport_error/http_error/transport_failure/http_failure/malformed_response` 为已知失败；`started/pending/in_progress/running` 为未结束，其余（含缺字段）未知。未结束、未知或记录数未覆盖计划/结果时，`failed_attempts` 与完整成本保持 unknown，`known_failed_attempts` 仅表示已知失败子计数。原 state 及分类均保留。

逐成员另保留原 `api_calls`、`answer_source`、`protocol_failure_count` 与原 `protocol_failures` 内容（`protocol_failure_reasons` JSON列）。HTTP 成功但模型多工具调用违反协议，不计作 transport/HTTP 失败；不会由这些字段推断“修复成功”。

Replay v1/v2/candidate 的 `SUMMARY.json` 通过 spec 的显式列表加入，成本 scope=`api_replay`，与 task_smoke 分开。只读现有 SUMMARY，不重发请求。candidate 初轮 `multistream-off-v2-c4/SUMMARY.json` 和末轮 `multistream-off-v2-c4-after-smokes/SUMMARY.json` 各计划 8 请求；SUMMARY 尚未存在时记录 `pending_or_missing_summary`，请求数、费用、失败数全部未知，不当作 0 或默默省略。文件已存在但缺计划记录则明确 partial。此工具不自己证明实际 serving 连续性；计划绑定及原文件索引供最终复核，端点相同不是因果同部署证明。

本目录 tests 只使用临时 synthetic fixtures：

```bash
cd /lustrefs/users/chufan.shi/codex_space_tn/eval_diagnostics_20260912/reporting
/lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python -B -m unittest test_compare_smokes
```

原数据仍为本地索引，输出不意味着公开扫描通过。由根 agent 写主/详细报告后做一次独立最终数值/逻辑复核。
