import copy
import json
from pathlib import Path
import tempfile
import unittest

import compare_smokes as report


def agent(aid, perf=.8, ea=.2):
    return {'agent_id': aid, 'answer': '{}', 'answer_perf': perf,
            'answer_metrics': {'label_acc': perf, 'evidence_acc': ea},
            'score_status': 'scored_final_answer', 'score_check': {'ok': True},
            'total_overhead': 3, 'http_request_attempts': 1, 'api_calls': 1,
            'answer_source': 'forced_model_answer',
            'protocol_failures': ['Exactly one native tool call is allowed per decision.'] if aid else []}


def result(scenario, missing=False):
    agents = [agent(0), agent(1, .6, .4)]
    aggregate = {'answer_metrics': {'label_acc': .9, 'evidence_acc': .1},
                 'mean_individual_perf': .7, 'answer_perf': .8}
    if missing:
        agents[1].update(answer=None, answer_perf=None,
                         score_status='unscorable_missing_configuration')
        aggregate.update(mean_individual_perf=None, answer_perf=None)
    return {'agent_results': agents, 'aggregate': aggregate,
            'terminal_status': {'score_complete': not missing, 'execution_complete': True}}


class Arithmetic(unittest.TestCase):
    def test_audit_ea_is_not_label_answer_perf(self):
        values = report.endpoint_values(result('evidence_audit'), 'evidence_audit', 2)
        self.assertAlmostEqual(values['ea_mi'], .3)
        self.assertAlmostEqual(values['la_mi'], .7)
        self.assertEqual((values['ea_mv'], values['la_mv']), (.1, .9))

    def test_nas_missing_member_means_both_full_endpoints_unknown(self):
        self.assertEqual(report.endpoint_values(result('tuning', missing=True), 'tuning', 2),
                         {'nas_raw_mi': None, 'nas_raw_bon': None})

    def test_nas_available_subset_cannot_pose_as_full(self):
        r = result('tuning', missing=True)
        r['aggregate']['answer_perf'] = .8
        with self.assertRaisesRegex(ValueError, 'aggregate'):
            report.endpoint_values(r, 'tuning', 2)

    def test_nas_saved_aggregate_and_zero_are_preserved(self):
        r = result('tuning')
        r['agent_results'][1]['answer_perf'] = 0
        r['aggregate']['mean_individual_perf'] = .4
        self.assertEqual(report.endpoint_values(r, 'tuning', 2),
                         {'nas_raw_mi': .4, 'nas_raw_bon': .8})

    def test_wrong_agent_count_is_rejected(self):
        with self.assertRaisesRegex(ValueError, 'count'):
            report.endpoint_values(result('tuning'), 'tuning', 4)

    def test_cost_missing_failure_usage_is_unknown_not_zero(self):
        calls = [dict(state='success', input_tokens=100, output_tokens=10,
                      reasoning_tokens=8, cached_input_tokens=50, wall_time_seconds=2),
                 dict(state='error', input_tokens=None, output_tokens=None,
                      reasoning_tokens=None, cached_input_tokens=None, wall_time_seconds=3)]
        c = report.cost_row('task_smoke', 'job', calls, 2)
        self.assertEqual(c['output_tokens_known_subtotal'], 10)
        self.assertEqual(c['output_tokens_unknown_attempts'], 1)
        self.assertIsNone(c['output_tokens_complete_total'])
        self.assertEqual(c['wall_time_seconds_complete_total'], 5)
        self.assertEqual(c['failed_attempts'], 1)

    def test_usage_subcategories_not_added(self):
        self.assertEqual(report.usage_fields({'prompt_tokens': 100, 'completion_tokens': 20,
                          'reasoning_tokens': 15, 'prompt_tokens_details': {'cached_tokens': 50}}),
                         dict(input_tokens=100, output_tokens=20, reasoning_tokens=15, cached_input_tokens=50))

    def test_started_physical_attempt_is_not_called_a_failure(self):
        row = report.cost_row('task_smoke', 'x', [{'state': 'started'}], None)
        self.assertIsNone(row['failed_attempts'])
        self.assertEqual(row['known_failed_attempts'], 0)
        self.assertEqual(row['pending_attempts'], 1)
        self.assertFalse(row['attempt_ledger_complete'])
        self.assertIsNone(row['output_tokens_complete_total'])

    def test_real_v2_transport_http_and_client_malformed_failures(self):
        for state in ('transport_failure', 'http_failure', 'malformed_response'):
            with self.subTest(state=state):
                row = report.cost_row('api_replay', 'x', [{'state': state, 'wall_time_seconds': 3}], 1)
                self.assertEqual(row['known_failed_attempts'], 1)
                self.assertEqual(row['failed_attempts'], 1)
                self.assertTrue(row['attempt_ledger_complete'])
                self.assertEqual(row['wall_time_seconds_complete_total'], 3)
                self.assertIsNone(row['output_tokens_complete_total'])

    def test_unknown_and_pending_with_usage_are_not_complete_costs(self):
        for state, category in (('new_unrecognized_state', 'unknown'), (None, 'unknown'),
                                ('in_progress', 'pending'), ('pending', 'pending')):
            with self.subTest(state=state):
                attempt = dict(state=state, input_tokens=100, output_tokens=20, wall_time_seconds=3)
                row = report.cost_row('task_smoke', 'x', [attempt], 1)
                self.assertEqual(report.attempt_state_class(state), category)
                self.assertIsNone(row['failed_attempts'])
                self.assertEqual(row['output_tokens_known_subtotal'], 20)
                self.assertIsNone(row['output_tokens_complete_total'])
                self.assertFalse(row['all_recorded_attempt_states_terminal'])
                self.assertFalse(row['attempt_ledger_complete'])

    def test_partial_ledger_keeps_failure_total_unknown(self):
        row = report.cost_row('api_replay', 'x', [{'state': 'http_failure', 'wall_time_seconds': 3}], 2)
        self.assertEqual(row['known_failed_attempts'], 1)
        self.assertIsNone(row['failed_attempts'])
        self.assertIsNone(row['wall_time_seconds_complete_total'])

    def test_comparisons_negative_and_unknown(self):
        base = dict(cohort='c', model='unfamiliar', scenario='tuning', item='A',
                    budget='tight', N=2, seed=3, comparison_signature='same', status='done')
        rows = [dict(base, strategy=s, nas_raw_mi=v, nas_raw_bon=None)
                for s, v in [('naive', .8), ('cached', .9), ('poolact', .7)]]
        out = report.comparison_rows(rows)
        self.assertAlmostEqual(out[0]['poolact_minus_naive'], -.1)
        self.assertIsNone(out[1]['poolact_minus_naive'])
        rows[1]['comparison_signature'] = 'different-deployment'
        with self.assertRaisesRegex(ValueError, 'bindings differ'):
            report.comparison_rows(rows)

    def test_two_primary_cohorts_cannot_double_count_same_comparison(self):
        base = dict(model='unfamiliar', scenario='tuning', item='A', budget='tight',
                    N=2, seed=3, comparison_signature='same', status='done')
        rows = [dict(base, cohort=c, strategy=s, nas_raw_mi=.7, nas_raw_bon=.8)
                for c in ('original', 'continuation') for s in ('naive', 'cached', 'poolact')]
        with self.assertRaisesRegex(ValueError, 'duplicate primary'):
            report.comparison_rows(rows)
        for row in rows[:3]:
            row['comparison_role'] = 'superseded_for_matched'
        output = report.comparison_rows(rows)
        self.assertEqual(len(output), 4)
        self.assertEqual(sum(r['comparison_role'] == 'primary' for r in output), 2)

    def test_strategy_group_cannot_mix_comparison_roles(self):
        base = dict(cohort='c', model='unfamiliar', scenario='tuning', item='A', budget='tight',
                    N=2, seed=3, comparison_signature='same', status='done')
        rows = [dict(base, strategy=s) for s in ('naive', 'cached', 'poolact')]
        rows[0]['comparison_role'] = 'superseded_for_matched'
        with self.assertRaisesRegex(ValueError, 'roles differ'):
            report.comparison_rows(rows)


class FrozenShapes(unittest.TestCase):
    def fixture(self, root):
        def write(path, value):
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(value))
            return path
        deployment = write(root / 'deployment.json', {})
        binding = write(root / 'binding.json', {'unfamiliar': {
            'deployment_file': str(deployment), 'sha256': report.sha(deployment.read_bytes())}})
        jobs = []
        for strategy in ('naive', 'cached', 'poolact'):
            config = dict(model='unfamiliar', scenario='evidence_audit', tuning_task='unused',
                          cc_split='frozen-docs', question_index=0, cost_regime='cost_tight',
                          strategies=[strategy], agents=2, seed=2200, prompt_cache_key=strategy)
            job_root = root / strategy
            jobs.append(dict(id=strategy, root=str(job_root), dump=str(job_root / 'api_dump'), config=config))
        plan = write(root / 'plan.json', {'source_tree_sha256': 'source', 'jobs': jobs})
        spec = write(root / 'spec.json', {'expected_source_tree_sha256': 'source', 'cohorts': [{
            'id': 'cohort', 'model': 'unfamiliar', 'serving_bindings': str(binding),
            'plans': [str(plan)], 'expected_jobs': 3}],
            'unstarted_status_by_job': {'cached': 'pending_approval'}, 'api_replay_summaries': []})
        return write, jobs, spec

    def complete(self, write, job):
        root = Path(job['root'])
        r = result('evidence_audit')
        r.update(config=job['config'], implementation_sha256={'source_tree': 'source'})
        path = write(root / 'result' / job['config']['strategies'][0] / 'result.json', r)
        write(root / 'execution_started.json', {'job': job})
        write(root / 'execution_finished.json', {'returncode': 0})
        inventory = {}
        for aid in (0, 1):
            dump = write(root / 'api_dump' / f'{aid}.json', {
                'run_id': job['id'], 'context': {'agent_id': aid}, 'request_id': f'{job["id"]}-{aid}',
                'attempt': 1, 'state': 'success', 'wall_time_seconds': 2,
                'response_json': {'usage': {'prompt_tokens': 100, 'completion_tokens': 10}}})
            inventory[str(dump.relative_to(root))] = {'sha256': report.sha(dump.read_bytes()),
                                                     'bytes': dump.stat().st_size}
        write(root / 'validation.json', {'job_id': job['id'], 'result_sha256': report.sha(path.read_bytes()),
              'score_check': {'execution_complete': True, 'score_complete': True},
              'raw_attempt_count': 2, 'inventory': inventory})

    def test_unstarted_pending_and_failed_keep_planned_denominators(self):
        with tempfile.TemporaryDirectory() as tmp:
            write, jobs, spec = self.fixture(Path(tmp))
            write(Path(jobs[0]['root']) / 'execution_finished.json', {'returncode': 2})
            pools, agents, comparisons, attempts, costs, index = report.collect(spec)
            self.assertEqual([p['status'] for p in pools], ['failed', 'pending_approval', 'not_started'])
            self.assertEqual(len(agents), 6)
            self.assertEqual(len(comparisons), 4)
            self.assertFalse(index['all_execution_validated'])
            self.assertIsNone(comparisons[0]['naive'])
            self.assertEqual(attempts, [])

    def test_complete_saved_result_and_physical_attempts(self):
        with tempfile.TemporaryDirectory() as tmp:
            write, jobs, spec = self.fixture(Path(tmp))
            for job in jobs:
                self.complete(write, job)
            pools, agents, comparisons, attempts, costs, index = report.collect(spec)
            self.assertTrue(index['all_scores_complete'])
            self.assertEqual(len(attempts), 6)
            self.assertTrue(all(c['input_tokens_complete_total'] == 200 for c in costs))
            self.assertTrue(all(c['failed_attempts'] == 0 for c in costs))
            self.assertEqual(agents[1]['api_calls'], 1)
            self.assertEqual(agents[1]['answer_source'], 'forced_model_answer')
            self.assertEqual(agents[1]['protocol_failure_count'], 1)
            self.assertEqual(json.loads(agents[1]['protocol_failure_reasons']),
                             ['Exactly one native tool call is allowed per decision.'])
            self.assertTrue(all(a['state_class'] == 'success' for a in attempts))
            self.assertAlmostEqual(comparisons[0]['poolact_minus_cached'], 0)
            self.assertAlmostEqual(pools[0]['ea_mi'], .3)

    def test_changed_dump_is_not_accepted_under_existing_receipt(self):
        with tempfile.TemporaryDirectory() as tmp:
            write, jobs, spec = self.fixture(Path(tmp))
            self.complete(write, jobs[0])
            (Path(jobs[0]['dump']) / '0.json').write_text('{}')
            with self.assertRaisesRegex(ValueError, 'identity mismatch'):
                report.collect(spec)

    def test_result_without_validation_does_not_supply_formal_comparison(self):
        with tempfile.TemporaryDirectory() as tmp:
            write, jobs, spec = self.fixture(Path(tmp))
            self.complete(write, jobs[0])
            (Path(jobs[0]['root']) / 'validation.json').unlink()
            pools, _, comparisons, attempts, _, _ = report.collect(spec)
            self.assertEqual(pools[0]['status'], 'awaiting_validation')
            self.assertIsNone(comparisons[0]['naive'])
            self.assertEqual(len(attempts), 2)

    def test_replay_costs_remain_separate_and_do_not_complete_task_scores(self):
        with tempfile.TemporaryDirectory() as tmp:
            write, _, spec = self.fixture(Path(tmp))
            replay = write(Path(tmp) / 'SUMMARY.json', {
                'schema': 'expgym.private-serving-diagnostic-summary.v2', 'run_id': 'replay',
                'completed_attempt_records': 1, 'planned_calls': 2,
                'records': [{'variant': 'candidate', 'state': 'delivered', 'wall_seconds': 3,
                             'transport_attempt': 1, 'shape': {'usage': {'prompt_tokens': 20,
                                                                    'completion_tokens': 5}}}]})
            data = json.loads(spec.read_text())
            data['api_replay_summaries'] = [str(replay)]
            write(spec, data)
            _, _, comparisons, attempts, costs, index = report.collect(spec)
            self.assertEqual(attempts[0]['cost_scope'], 'api_replay')
            self.assertEqual(costs[-1]['output_tokens_known_subtotal'], 5)
            self.assertIsNone(costs[-1]['output_tokens_complete_total'])
            self.assertIsNone(comparisons[0]['poolact'])
            self.assertFalse(index['all_execution_validated'])

    def test_candidate_summary_not_run_is_unknown_not_zero(self):
        with tempfile.TemporaryDirectory() as tmp:
            write, _, spec = self.fixture(Path(tmp))
            data = json.loads(spec.read_text())
            data['api_replay_summaries'] = [{'path': str(Path(tmp) / 'candidate/SUMMARY.json'),
                                            'planned_calls': 8}]
            write(spec, data)
            _, _, _, attempts, costs, index = report.collect(spec)
            self.assertEqual(attempts, [])
            self.assertEqual(costs[-1]['status'], 'pending_or_missing_summary')
            self.assertIsNone(costs[-1]['physical_attempts_recorded'])
            self.assertIsNone(costs[-1]['failed_attempts'])
            self.assertIsNone(costs[-1]['output_tokens_complete_total'])
            self.assertEqual(index['api_replay_archives'][0]['planned_calls'], 8)

    def test_replay_record_count_alone_does_not_make_unknown_state_complete(self):
        with tempfile.TemporaryDirectory() as tmp:
            write, _, spec = self.fixture(Path(tmp))
            replay = write(Path(tmp) / 'SUMMARY.json', {
                'schema': 'expgym.private-serving-diagnostic-summary.v2', 'run_id': 'replay',
                'completed_attempt_records': 1, 'planned_calls': 1,
                'records': [{'state': 'unknown_future_state', 'wall_seconds': 3,
                             'shape': {'usage': {'prompt_tokens': 20, 'completion_tokens': 5}}}]})
            data = json.loads(spec.read_text())
            data['api_replay_summaries'] = [str(replay)]
            write(spec, data)
            _, _, _, _, costs, index = report.collect(spec)
            self.assertEqual(index['api_replay_archives'][0]['status'], 'summary_read_unresolved_states')
            self.assertFalse(index['all_physical_attempt_ledgers_complete'])
            self.assertIsNone(costs[-1]['failed_attempts'])
            self.assertIsNone(costs[-1]['output_tokens_complete_total'])

    def test_infra_continuation_preserves_old_results_costs_and_separate_primary(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            write, jobs, spec = self.fixture(root)
            self.complete(write, jobs[2])
            data = json.loads(spec.read_text())
            data['unstarted_status_by_job'] = {job['id']: {
                'status': 'not_started_infra_budget', 'reason': 'infra_budget; decided before old Pool score'}
                for job in jobs[:2]}
            data['comparison_role_by_job'] = {job['id']: {
                'role': 'superseded_for_matched', 'reason': 'new complete cohort after infrastructure time limit'}
                for job in jobs}
            continued = []
            for job in jobs:
                new = copy.deepcopy(job)
                new['id'] += '-continuation'
                new['root'] = str(root / new['id'])
                new['dump'] = str(Path(new['root']) / 'api_dump')
                self.complete(write, new)
                continued.append(new)
            plan = write(root / 'continuation_plan.json', {'source_tree_sha256': 'source', 'jobs': continued})
            cohort = copy.deepcopy(data['cohorts'][0])
            cohort.update(id='continuation', plans=[str(plan)])
            deployment = write(root / 'continuation_deployment.json', {'slurm_job': 'new'})
            cohort['serving_bindings'] = str(write(root / 'continuation_binding.json', {'unfamiliar': {
                'deployment_file': str(deployment), 'sha256': report.sha(deployment.read_bytes())}}))
            data['cohorts'].append(cohort)
            write(spec, data)
            pools, agents, comparisons, attempts, costs, index = report.collect(spec)
            self.assertEqual(len(pools), 6)
            self.assertEqual(len(agents), 12)
            self.assertEqual(len(attempts), 8)
            self.assertEqual(index['primary_expected_pools'], 3)
            self.assertTrue(index['all_primary_scores_complete'])
            self.assertFalse(index['all_scores_complete'])
            self.assertEqual(index['comparison_role_pool_counts'], {'superseded_for_matched': 3, 'primary': 3})
            self.assertEqual([p['status'] for p in pools[:3]],
                             ['not_started_infra_budget', 'not_started_infra_budget', 'validated_complete'])
            self.assertIn('infra_budget', pools[0]['planned_unstarted_reason'])
            self.assertIsNone(costs[0]['failed_attempts'])
            self.assertIsNone(costs[0]['output_tokens_complete_total'])
            self.assertEqual(costs[2]['output_tokens_complete_total'], 20)
            self.assertEqual(sum(c['output_tokens_known_subtotal'] or 0 for c in costs), 80)
            self.assertEqual(len(comparisons), 8)
            prior = [r for r in comparisons if r['comparison_role'] == 'superseded_for_matched']
            primary = [r for r in comparisons if r['comparison_role'] == 'primary']
            self.assertTrue(all(r['naive'] is None and r['poolact'] is not None for r in prior))
            self.assertTrue(all(r['poolact_minus_naive'] is None for r in prior))
            self.assertTrue(all(r['poolact_minus_naive'] == 0 for r in primary))
            self.assertTrue(all(a['comparison_role'] == 'superseded_for_matched' for a in agents[:6]))

    def test_infra_status_needs_reason_and_execution_marker_takes_precedence(self):
        with tempfile.TemporaryDirectory() as tmp:
            write, jobs, spec = self.fixture(Path(tmp))
            data = json.loads(spec.read_text())
            data['unstarted_status_by_job'] = {'naive': {'status': 'not_started_infra_budget'}}
            write(spec, data)
            with self.assertRaisesRegex(ValueError, 'requires a recorded reason'):
                report.collect(spec)
            data['unstarted_status_by_job']['naive']['reason'] = 'infra_budget'
            write(spec, data)
            write(Path(jobs[0]['root']) / 'execution_started.json', {'job': jobs[0]})
            pools, *_ = report.collect(spec)
            self.assertEqual(pools[0]['status'], 'running_or_interrupted')
            self.assertEqual(pools[0]['planned_unstarted_status'], 'not_started_infra_budget')
            self.assertEqual(pools[0]['planned_unstarted_reason'], 'infra_budget')

    def test_unselected_role_override_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            write, _, spec = self.fixture(Path(tmp))
            data = json.loads(spec.read_text())
            data['comparison_role_by_job'] = {'typo-job': {'role': 'superseded_for_matched', 'reason': 'infra'}}
            write(spec, data)
            with self.assertRaisesRegex(ValueError, 'unselected job IDs'):
                report.collect(spec)


if __name__ == '__main__':
    unittest.main()
