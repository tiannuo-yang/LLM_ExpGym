# 最终报告独立数值与逻辑复核

结论：**通过。本次限定范围内未发现需修正的数值差异、cohort 拼接、指标替换或过度结论。** 复核日期为 2026-09-12 UTC，报告版本和实读证据身份列于下文。

本复核由 `/root/final_diagnostic_report_review` 执行；并行只读分支 `cost_protocol_check` 核对成本、执行账簿与协议计数。两者均未参与修改被复核报告或固定导出。本次唯一新增文件为本记录。

## 复核范围与方法

全文阅读 `reporting/public_v1/README.zh.md`、`DETAILS.zh.md`，核对 `reporting/final_v1/` 的七项固定导出；必要证据限于图碰撞 census、GLM/DeepSeek 已完成全文复核说明、四份 serving 释放记录及已存在的旧五模型主报告。对 CSV 只做保存值之间的对应、求和、均值、最大值、差值与显示精度检查；Audit MV 沿用保存的聚合值，不重新投票或评分。

未调用模型、GPU、网络、decoder、runner 或 scorer；未读 API 原始正文、大权重或重算旧矩阵；未重封旧档案。INDEX 内列出的原件 SHA、已有 validation 和分类属于继承证据，本复核没有将其说成重新实读了全部原件。

## 具体检查结果

| 检查 | 结果与依据 |
| --- | --- |
| 主报告数值与显示口径 | 主表 8 行的 40 个数值单元逐项匹配 primary `comparisons.csv`；fraction 乘 100，差值为百分点。先用未四舍五入的源值相减再显示，因此不要求已显示两位小数相减仍与差值末位一致。 |
| 详细端点 | 详细得分表的 36 个数值单元匹配 9 位小数的保存值；与主表合计 76 个报告数值单元全部通过。EA、LA 分列，NAS 为 raw accuracy MI/BoN，没有替换成旧 Gap0。 |
| 导出内部一致性 | 16 个比较端点的 48 个策略值及 48 个差值/unknown，与对应 cohort、场景、任务、预算、N、seed 的逐池行一致；另核对 26 个保存成员聚合值，共 122 项一致性断言通过。未重新计算 Audit MV。 |
| 同 cohort 对照 | GLM NAS 使用 `glm-baseline-1205018`；新 GLM Audit 使用 `glm_audit_continuation_v1`；DeepSeek 六池使用 `deepseek-streamoff-1205022`。旧 GLM Audit 的四个端点独立标为 `superseded_for_matched`，naive/cached 及差值保持 unknown，没有拼接新 controls。 |
| 正、零、负差 | GLM NAS 全部持平；DeepSeek NAS 的 PoolAct−naive/cached 为 MI +1.62、BoN +3.24pp；DeepSeek Audit EA-MI 为 −5.88/−5.88pp，EA-MV 为 0/−5.88pp。新 GLM Audit EA-MI 为 +8.82/+11.76pp、EA-MV 为 +11.76/+17.65pp，但 LA-MI 为 −2.94/0pp、LA-MV 为 −5.88/0pp，正文均保留。 |
| 池与成员分母 | 15 个计划槽为 12 primary、3 superseded；13 实际完成池对应 26 有效评分成员，其中 primary 为 12 池/24 成员。另 2 旧未启动槽对应 4 个占位成员，未计为实际完成或零分。 |
| 请求及协议计数 | 101 task = 旧 GLM 29 + 新 GLM 25 + DeepSeek 47；另 40 replay，合计 141。primary 为 93 task，旧 Audit 的 8 次仍在总账。141 条物理状态均为 success/delivered；10 次任务协议违规为 9 次多调用、1 次 length，独立于 transport/HTTP 失败。 |
| 费用与 unknown | `costs.csv` 的 20 行逐组匹配物理账：18 条实际请求账完整，2 条未启动账 unknown。141 条 cached-input 用量全部未知，未补零。reasoning 包含于 output，cached input 包含于 input，没有二次相加；INDEX 的计划槽完整性 false 不被误读为已发生调用漏账。 |
| token 与 HTTP wall | task 为 input 1,145,618 / output 504,817 / reasoning 465,296 / HTTP 7,792.49 秒；replay 为 73,874 / 169,547 / 162,568 / 1,917.97 秒；总计 1,219,492 / 674,364 / 627,864 / 9,710.46 秒。primary input/output 为 1,011,567/415,214。新 GLM 三池各项 HTTP wall/token 与成本表一致，合计 input/output/reasoning 为 530,723/287,703/283,206。 |
| GPU 费用与释放解释 | 文中 allocation 合计 70.37778 GPU-hours，6437×16/3600=28.60889 的算术正确；未将 job steps、请求 wall 或模拟反馈秒叠加成 allocation 费用。四份 RELEASE 对完成请求与最终 flush 的记录支持正文的主动收尾解释。GLM continuation 明确保留 −15/−9 退出码及 `provider_quiescence_proven=false`；排空依据为已完成请求与控制 flush，不从退出码、Slurm End 或清理耗时推断排空。 |
| 旧结论与冠军 | 先确认旧主报告存在，再核对其既有结果：Search 降幅 26.89–48.46，Audit 16.29–37.86，DeepSeek Gap0 61.09→75.81；六家族 Free/Tight 冠军逐项相符，确为 whatis 和 NAS101 两处换位，即 2/6。没有用新 Tight smoke 重建旧预算曲线或改写旧冠军。 |
| 图影响范围 | census 的 90 NAS/130 Audit、80 NAS 碰撞池、五模型分项及完整键/前缀数均与详表一致；Audit 最长键 54/56/54/54/57、220 池 pending 为 0。正文区分协作输入/轨迹问题与保存 scalar score，未从碰撞频率推导收益。 |
| 输出保真与外推 | DeepSeek 已有全文检查为 47 条中 46 连贯、1 语义循环、0 明显乱码；新 GLM Audit PoolAct 为 8 条中 1 连贯、7 语义重复、0 明显乱码，与两份复核说明一致。正文没有把这一范围推广为旧 GLM 29 条或新 GLM controls 的全文验收，也没有把协议接受、HTTP 成功或有效得分替代文本保真。 |
| 因果与科学边界 | 保留 N=2、每策略一个池、两个固定任务、Tight/短决策上限的限制；没有显著性、总体优势、等成本性价比或严格 kernel 根因声明。明确实际 NAS GPU smoke 未触发旧碰撞，CPU 回归与 GPU 路径覆盖分开；旧上下文/legacy 敏感度没有写回正式成绩。 |
| 固定索引 | INDEX 有 171 个输入身份，SHA 与正文一致；七项固定 `final_v1` 导出合计 277,892 字节。该字节数指本次检查的固定导出，不是随后 publisher 生成的公开目录或重写存档索引的总大小。 |

## 证据边界与发布衔接

此次通过表示上述报告与限定的保存证据在数值及逻辑上相符，不是再次验证所有原始答案、serving 连续性或根因。旧 GPT/DeepSeek 的细粒度冻结影响与静态敏感度、逐池启动/结束及池 wall、模板作用链等引用，没有在本次重新打开其原运行/配置证据；已有数值与范围声明保持其原证据层级。GPU 释放解释核对到四份 RELEASE，本次没有新增 Slurm 查询或重跑控制操作。

被复核版本仍含“待最终独立复核”状态文字。ROOT 在本记录完成后可将该状态替换为“复核完成”及本记录链接；这是已知的非数值发布状态更新，不构成新实验、重评分或第二轮全审。本记录中的报告 SHA 指该状态更新之前的确切版本。

公开 `RAW_INDEX.json`、`ARCHIVE_INDEX.md` 和 payload 分片随后由 publisher 生成。这里核对的是固定导出及报告引用关系，没有将当前尚未生成的相对发布链接报告为数据丢失，也没有提前宣称公开归档上传或链接验收完成；这些属于随后的发布步骤。

## 实读文件 SHA256

下表除最后一项以外均相对 `/lustrefs/users/chufan.shi/codex_space_tn/eval_diagnostics_20260912/`；最后一项相对 workspace 根目录。SHA 覆盖本次读取的文件，不表示跟随其中所有路径读取了原件。

| 文件 | SHA256 |
| --- | --- |
| `reporting/public_v1/README.zh.md` | `c918bda675b2eed9c83289fe205e898235f3d621bcfe5e4fffeb617381061970` |
| `reporting/public_v1/DETAILS.zh.md` | `0f8a9afe010d57a0a79f0792301450845a824d2c1a8c8f9d2ac37ce917ebe4c5` |
| `reporting/final_v1/comparisons.csv` | `b742e2207f5a5c3bcd642bb3dac3a3b5e25ee4621c220b382cc9f49ee3c1ae6a` |
| `reporting/final_v1/per_pool.csv` | `82d66ddccabeeae8172e1f0e0c55580dcf80708cfa074f7aff680387f077f89d` |
| `reporting/final_v1/per_agent.csv` | `f7ba5737c84c8b401cbdb2b32f4b790df35542a12b9a23485b380999f970da5c` |
| `reporting/final_v1/costs.csv` | `aab3e92203849db027246164659bafdacf0c49c70ae961d99da0013b82503cb6` |
| `reporting/final_v1/physical_attempts.csv` | `7a85738b4feb64ea9ddbaa3bc3cbbbdc1a4f284a45a6e10d75b2a5bdcb6808f7` |
| `reporting/final_v1/INDEX.json` | `d0445e686b9894c821840ffce47568da440c65574ced2d9d5433ebe612244368` |
| `reporting/final_v1/ARCHIVE_INDEX.md` | `9f65c4a4af0ef81a389bce51e14a724078ea9d3d03d7ccb6f2ef9c2a1878013a` |
| `graph_collision_census.json` | `f5d2533ab94021383584a48994daf321cb106bb67d02bf588545375948d2e193` |
| `glm_fidelity_review/README.zh.md` | `15c1e1340fab58f33ff530d8c3d45b6ce8231d40bf491a813ecd0681df31788a` |
| `task_fidelity_review/README.zh.md` | `6bcb13496273558363b0a36712e3b147945e7d44b0aa1dd93056c538ff90fad2` |
| `serving/baseline/RELEASE.zh.md` | `ea93896a121ff233d8706b559bf15b7bdd8d5922dd4293e1612b4dbf5c74b4e9` |
| `serving/multistream-off/RELEASE.zh.md` | `1468a13491021196554508596e9331292a014eb137cd1a417bda1a5ea6eb21be` |
| `serving/glm-baseline/RELEASE.zh.md` | `890a65197c1b21ec761fa3397163015ed75d065b7fcfec9e90c544c745943f2b` |
| `serving/glm-continuation/RELEASE.zh.md` | `732c8615037868cb5d0089c5c96b8f257af2ce73241d07068192150ef6837bea` |
| `publication/five_model_report_20260911/results/five-model-ranking-20260911/main_findings_v2/README.zh.md` | `ab2e5ac779af41d520de888f03bb501d9ce538bbed5ccd3425c4a7fbc98db2c2` |

完成后 STOP_WRITE；没有修改上述报告、导出或旧结果。
