#!/usr/bin/env python3
"""Export a small, explicitly selected smoke cohort; never run models/scorers.

Only the supported frozen smoke-plan/result/API-attempt shapes are accepted.
Output is a NEW directory. Unknown scores/usage remain blank, not zero.
"""
from __future__ import annotations

import argparse
import collections
import csv
import datetime
import hashlib
import json
import math
from pathlib import Path
import statistics


METRICS = {'tuning': ('nas_raw_mi', 'nas_raw_bon'),
           'evidence_audit': ('ea_mi', 'ea_mv', 'la_mi', 'la_mv')}
TOKENS = ('input_tokens', 'output_tokens', 'reasoning_tokens', 'cached_input_tokens')
IDENTITY = ('cohort', 'model', 'scenario', 'item', 'budget', 'strategy', 'N', 'seed', 'job_id',
            'comparison_role', 'comparison_reason')
COMPARISON_ROLES = frozenset(('primary', 'superseded_for_matched'))
UNSTARTED_STATUSES = frozenset(('not_started', 'pending_approval', 'cancelled_before_start',
                                'not_started_infra_budget'))
ATTEMPT_STATES = {
    'success': frozenset(('success', 'delivered')),
    'failure': frozenset(('error', 'failed', 'transport_error', 'http_error',
                          'transport_failure', 'http_failure', 'malformed_response')),
    'pending': frozenset(('started', 'pending', 'in_progress', 'running')),
}


def attempt_state_class(state):
    for category, states in ATTEMPT_STATES.items():
        if isinstance(state, str) and state in states:
            return category
    return 'unknown'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def complete_mean(values):
    return statistics.mean(values) if values and all(finite(x) for x in values) else None


def endpoint_values(result, scenario, n):
    """Arithmetic on SAVED scores only; no answer parsing/evaluator calls."""
    agents = result['agent_results']
    if len(agents) != n:
        raise ValueError('wrong agent count')
    aggregate = result['aggregate']
    if scenario == 'tuning':
        perfs = [a.get('answer_perf') for a in agents]
        full = (result['terminal_status'].get('score_complete') is True and
                all(a.get('answer') is not None and finite(a.get('answer_perf')) for a in agents))
        expected_mi = complete_mean(perfs) if full else None
        expected_bon = max(perfs) if full else None
        for saved, expected in ((aggregate.get('mean_individual_perf'), expected_mi),
                                (aggregate.get('answer_perf'), expected_bon)):
            if (saved is None) != (expected is None) or (saved is not None and
                    not math.isclose(saved, expected, rel_tol=1e-12, abs_tol=1e-12)):
                raise ValueError('saved full NAS aggregate disagrees with agent scores/missingness')
        return {'nas_raw_mi': expected_mi, 'nas_raw_bon': expected_bon}
    if scenario != 'evidence_audit':
        raise ValueError('unsupported scenario')
    values = {}
    for short, name in (('ea', 'evidence_acc'), ('la', 'label_acc')):
        values[short + '_mi'] = complete_mean([(a.get('answer_metrics') or {}).get(name) for a in agents])
        values[short + '_mv'] = (aggregate.get('answer_metrics') or {}).get(name)
    # answer_perf is the Audit label endpoint; never substitute it for EA.
    return values


def usage_fields(usage):
    usage = usage if isinstance(usage, dict) else {}
    prompt = usage.get('prompt_tokens_details') or usage.get('input_tokens_details') or {}
    completion = usage.get('completion_tokens_details') or usage.get('output_tokens_details') or {}
    return {'input_tokens': usage.get('prompt_tokens', usage.get('input_tokens')),
            'output_tokens': usage.get('completion_tokens', usage.get('output_tokens')),
            'reasoning_tokens': usage.get('reasoning_tokens', completion.get('reasoning_tokens')),
            'cached_input_tokens': prompt.get('cached_tokens')}


def cost_row(scope, group_id, attempts, expected=None):
    classes = collections.Counter(attempt_state_class(x.get('state')) for x in attempts)
    unresolved = classes['pending'] + classes['unknown']
    ledger_complete = expected is not None and expected == len(attempts) and not unresolved
    row = {'cost_scope': scope, 'group_id': group_id, 'physical_attempts_recorded': len(attempts),
           'expected_attempts_from_result': expected,
           'attempt_count_matches_result': None if expected is None else len(attempts) == expected,
           'known_failed_attempts': classes['failure'],
           'failed_attempts': classes['failure'] if ledger_complete else None,
           'pending_attempts': classes['pending'], 'unknown_state_attempts': classes['unknown'],
           'all_recorded_attempt_states_terminal': (not unresolved) if attempts or expected == 0 else None,
           'attempt_ledger_complete': bool(ledger_complete),
           'attempt_state_counts': json.dumps(dict(collections.Counter(
               x.get('state') if isinstance(x.get('state'), str) else '<missing_or_nonstring>'
               for x in attempts)), sort_keys=True)}
    for field in (*TOKENS, 'wall_time_seconds'):
        known = [x[field] for x in attempts if finite(x.get(field))]
        row[field + '_known_subtotal'] = sum(known) if known else None
        row[field + '_unknown_attempts'] = len(attempts) - len(known)
        row[field + '_complete_total'] = (sum(known) if ledger_complete and len(known) == len(attempts) else None)
    return row


def comparison_rows(pools):
    groups = collections.defaultdict(dict)
    for row in pools:
        key = tuple(row[k] for k in ('cohort', 'model', 'scenario', 'item', 'budget', 'N', 'seed'))
        if row['strategy'] in groups[key]:
            raise ValueError('duplicate strategy slot; do not silently select one outcome')
        groups[key][row['strategy']] = row
    output, primary_slots = [], set()
    for key, rows in sorted(groups.items()):
        if set(rows) != {'naive', 'cached', 'poolact'}:
            raise ValueError('planned strategy matrix is incomplete')
        if len({r['comparison_signature'] for r in rows.values()}) != 1:
            raise ValueError('strategy source/config/deployment bindings differ')
        roles = {r.get('comparison_role', 'primary') for r in rows.values()}
        if len(roles) != 1 or not roles <= COMPARISON_ROLES:
            raise ValueError('comparison roles differ within a strategy group or are unsupported')
        role = next(iter(roles))
        if role == 'primary':
            if key[1:] in primary_slots:
                raise ValueError('duplicate primary comparison across cohorts; declare superseded group')
            primary_slots.add(key[1:])
        base = dict(zip(('cohort', 'model', 'scenario', 'item', 'budget', 'N', 'seed'), key))
        for metric in METRICS[base['scenario']]:
            row = dict(base, metric=metric, unit='fraction',
                       comparison_role=role,
                       comparison_reasons=json.dumps({s: r.get('comparison_reason') for s, r in rows.items()},
                                                     ensure_ascii=False, sort_keys=True),
                       strategy_statuses=json.dumps({s: r['status'] for s, r in rows.items()}, sort_keys=True))
            row.update({s: r.get(metric) for s, r in rows.items()})
            for target, control in (('cached', 'naive'), ('poolact', 'cached'), ('poolact', 'naive')):
                a, b = row[target], row[control]
                row[target + '_minus_' + control] = a - b if finite(a) and finite(b) else None
            output.append(row)
    return output


class Inputs:
    def __init__(self):
        self.files = {}

    def read(self, path, role, expected=None):
        path = Path(path).resolve()
        raw = path.read_bytes()
        entry = {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw), 'role': role}
        if expected is not None and entry['sha256'] != expected:
            raise ValueError(f'identity mismatch: {path}')
        old = self.files.get(str(path))
        if old and old['sha256'] != entry['sha256']:
            raise ValueError(f'input changed during export: {path}')
        self.files[str(path)] = entry
        return json.loads(raw)


def collect(spec_path):
    inputs = Inputs()
    spec = inputs.read(spec_path, 'explicit_cohort_selection')
    pools, agents, attempts, costs, archives = [], [], [], [], []
    seen_jobs = set()
    for cohort in spec['cohorts']:
        binding_map = inputs.read(cohort['serving_bindings'], 'prospective_same_serving_binding')
        binding = binding_map[cohort['model']]
        inputs.read(binding['deployment_file'], 'bound_deployment_metadata', binding['sha256'])
        selected = []
        for plan_path in cohort['plans']:
            plan = inputs.read(plan_path, 'frozen_smoke_plan')
            if plan['source_tree_sha256'] != spec['expected_source_tree_sha256']:
                raise ValueError('source version differs from explicit cohort')
            for job in plan['jobs']:
                if job['config']['model'] == cohort['model']:
                    selected.append((plan, job))
        if len(selected) != cohort['expected_jobs']:
            raise ValueError('selected job count differs from plan')
        for plan, job in selected:
            if job['id'] in seen_jobs:
                raise ValueError('job selected more than once')
            seen_jobs.add(job['id'])
            config = job['config']
            if len(config['strategies']) != 1 or config['scenario'] not in METRICS:
                raise ValueError('unsupported smoke plan shape')
            strategy = config['strategies'][0]
            root = Path(job['root'])
            result_path = root / 'result' / strategy / 'result.json'
            validation_path = root / 'validation.json'
            row = dict(cohort=cohort['id'], model=config['model'], scenario=config['scenario'],
                       item=config['tuning_task'] if config['scenario'] == 'tuning' else
                            f"{config['cc_split']}:{config['question_index']}",
                       budget=config['cost_regime'], strategy=strategy, N=config['agents'],
                       seed=config['seed'], job_id=job['id'], source_tree_sha256=plan['source_tree_sha256'],
                       result_path=str(result_path), validation_path=str(validation_path), dump_path=job['dump'])
            role = spec.get('comparison_role_by_job', {}).get(job['id'], {})
            row['comparison_role'] = role.get('role', 'primary')
            row['comparison_reason'] = role.get('reason')
            if row['comparison_role'] not in COMPARISON_ROLES:
                raise ValueError('unsupported comparison role')
            if row['comparison_role'] != 'primary' and not row['comparison_reason']:
                raise ValueError('superseded comparison requires a recorded reason')
            comparable = {k: v for k, v in config.items() if k not in ('strategies', 'prompt_cache_key')}
            row['comparison_signature'] = sha(json.dumps(
                [cohort['id'], binding['sha256'], plan['source_tree_sha256'], comparable],
                sort_keys=True, separators=(',', ':')).encode())
            status_selection = spec.get('unstarted_status_by_job', {}).get(job['id'], 'not_started')
            status_selection = {'status': status_selection} if isinstance(status_selection, str) else status_selection
            status = status_selection['status']
            if status not in UNSTARTED_STATUSES:
                raise ValueError('unsupported unstarted status override')
            if status == 'not_started_infra_budget' and not status_selection.get('reason'):
                raise ValueError('infra-budget unstarted status requires a recorded reason')
            row['planned_unstarted_status'] = status
            row['planned_unstarted_reason'] = status_selection.get('reason')
            finished = None
            if (root / 'execution_started.json').exists():
                inputs.read(root / 'execution_started.json', 'execution_start')
                status = 'running_or_interrupted'
            if (root / 'execution_finished.json').exists():
                finished = inputs.read(root / 'execution_finished.json', 'execution_finish')
                status = 'failed' if finished['returncode'] else 'awaiting_validation'
            result = inputs.read(result_path, 'saved_pool_result') if result_path.exists() else None
            validation = inputs.read(validation_path, 'existing_smoke_validation') if validation_path.exists() else None
            inventory = validation.get('inventory', {}) if validation else {}
            if validation:
                if not result or not finished or finished['returncode'] != 0:
                    raise ValueError('validation lacks successful execution/result')
                if validation['job_id'] != job['id'] or validation['result_sha256'] != inputs.files[str(result_path.resolve())]['sha256']:
                    raise ValueError('validation/result binding mismatch')
                if result['config'] != config or result['implementation_sha256']['source_tree'] != plan['source_tree_sha256']:
                    raise ValueError('saved result config/source identity differs')
                check = validation['score_check']
                if check.get('execution_complete') is not True:
                    raise ValueError('existing score check did not validate execution')
                status = 'validated_complete' if check.get('score_complete') else 'validated_score_incomplete'
                row.update(endpoint_values(result, config['scenario'], config['agents']))
            row.update(status=status,
                       execution_complete=bool(validation and validation['score_check'].get('execution_complete')),
                       score_complete=bool(validation and validation['score_check'].get('score_complete')),
                       validation_recomputed_by_exporter=False)
            if result:
                row['missing_answer_members'] = sum(a.get('answer') is None for a in result['agent_results'])
                row['saved_feedback_seconds'] = sum(a['total_overhead'] for a in result['agent_results'])
            pools.append(row)
            result_agents = {a['agent_id']: a for a in result['agent_results']} if result else {}
            for aid in range(config['agents']):
                a = result_agents.get(aid, {})
                ar = {k: row[k] for k in IDENTITY}
                ar.update(agent_id=aid, status=status, answer_is_null=a.get('answer') is None if a else None,
                          score_status=a.get('score_status'), terminal_origin=a.get('terminal_origin'),
                          termination_reason=a.get('termination_reason'), score_check_saved=json.dumps(a.get('score_check')),
                          result_path=str(result_path),
                          agent_result_path=str(result_path.parent / 'agents' / f'agent_{aid}.json'),
                          saved_feedback_seconds=a.get('total_overhead'),
                          agent_wall_seconds=a.get('wall_time_seconds'), evaluations=a.get('evaluations'),
                          http_request_attempts=a.get('http_request_attempts'), api_calls=a.get('api_calls'),
                          answer_source=a.get('answer_source'),
                          protocol_failure_count=len(a['protocol_failures']) if isinstance(a.get('protocol_failures'), list) else None,
                          protocol_failure_reasons=json.dumps(a.get('protocol_failures'), ensure_ascii=False))
                if validation and a:
                    ar['raw_perf'] = a.get('answer_perf')
                    ar['ea'] = (a.get('answer_metrics') or {}).get('evidence_acc')
                    ar['la'] = (a.get('answer_metrics') or {}).get('label_acc')
                agents.append(ar)
            dump_root = Path(job['dump']).resolve()
            if validation:
                dump_paths = [root / name for name in inventory
                              if (root / name).parent.resolve() == dump_root and name.endswith('.json')]
            else:
                # Exact selected invocation only; includes failed and pending attempts.
                dump_paths = list(dump_root.glob('*.json')) if dump_root.exists() else []
            job_attempts = []
            for path in sorted(dump_paths):
                entry = inventory.get(str(path.relative_to(root)))
                dump = inputs.read(path, 'physical_api_attempt', entry['sha256'] if entry else None)
                if dump.get('run_id') != job['id']:
                    raise ValueError('dump belongs to another run')
                usage = (dump.get('response_json') or {}).get('usage')
                record = dict(cost_scope='task_smoke', group_id=job['id'], cohort=cohort['id'],
                              comparison_role=row['comparison_role'],
                              model=cohort['model'], job_id=job['id'], agent_id=(dump.get('context') or {}).get('agent_id'),
                              request_id=dump.get('request_id'), physical_attempt=dump.get('attempt'),
                              state=dump.get('state'), state_class=attempt_state_class(dump.get('state')),
                              wall_time_seconds=dump.get('wall_time_seconds'),
                              source_path=str(path.resolve()), **usage_fields(usage))
                job_attempts.append(record)
            attempts.extend(job_attempts)
            expected = sum(a['http_request_attempts'] for a in result_agents.values()) if result_agents else None
            if validation and (len(job_attempts) != validation['raw_attempt_count'] or len(job_attempts) != expected):
                raise ValueError('validated physical attempt count mismatch')
            job_cost = cost_row('task_smoke', job['id'], job_attempts, expected)
            job_cost.update(cohort=cohort['id'], comparison_role=row['comparison_role'])
            costs.append(job_cost)
            row['physical_attempt_ledger_complete'] = job_cost['attempt_ledger_complete']
            archives.append({'job_id': job['id'], 'status': status, 'root': str(root),
                             'cohort': cohort['id'], 'comparison_role': row['comparison_role'],
                             'comparison_reason': row['comparison_reason'],
                             'planned_unstarted_status': row['planned_unstarted_status'],
                             'planned_unstarted_reason': row['planned_unstarted_reason'],
                             'dump_root': str(dump_root), 'result': str(result_path),
                             'validation': str(validation_path),
                             'inventory_evidence': 'inherited_existing_validation_inventory',
                             'inventory': inventory,
                             'serving_binding': binding,
                             'actual_same_serving_continuity_verified_by_exporter': False})
    for field in ('unstarted_status_by_job', 'comparison_role_by_job'):
        if set(spec.get(field, {})) - seen_jobs:
            raise ValueError(f'{field} contains unselected job IDs')
    comparisons = comparison_rows(pools)
    primary_pools = [row for row in pools if row['comparison_role'] == 'primary']
    replays = []
    replay_groups = set()
    for selection in spec.get('api_replay_summaries', []):
        selection = {'path': selection} if isinstance(selection, str) else selection
        path = selection['path']
        if not Path(path).exists():
            # Missing SUMMARY is not evidence that no request or failure occurred.
            unknown = {'cost_scope': 'api_replay', 'group_id': 'pending:' + str(Path(path).resolve()),
                       'status': 'pending_or_missing_summary', 'physical_attempts_recorded': None,
                       'expected_attempts_from_plan': selection.get('planned_calls'),
                       'failed_attempts': None, 'known_failed_attempts': None,
                       'pending_attempts': None, 'unknown_state_attempts': None,
                       'all_recorded_attempt_states_terminal': None,
                       'attempt_ledger_complete': False, 'attempt_count_matches_result': None}
            for field in (*TOKENS, 'wall_time_seconds'):
                unknown.update({field + '_known_subtotal': None, field + '_unknown_attempts': None,
                                field + '_complete_total': None})
            costs.append(unknown)
            replays.append({'summary_path': str(Path(path).resolve()), 'run_id': None,
                            'status': 'pending_or_missing_summary',
                            'planned_calls': selection.get('planned_calls'), 'records': None,
                            'raw_dump_root': str(Path(path).resolve().parent),
                            'scope': 'no completed summary read; cost/failure counts unknown, not zero'})
            continue
        summary = inputs.read(path, 'separate_api_replay_summary')
        group = summary['run_id']
        if group in replay_groups:
            raise ValueError('duplicate replay run would double-count costs')
        replay_groups.add(group)
        records = []
        for ordinal, record in enumerate(summary['records'], 1):
            records.append(dict(cost_scope='api_replay', group_id=group, cohort=record.get('variant'),
                                model=None, job_id=None, agent_id=None, request_id=record.get('original_request_id'),
                                physical_attempt=record.get('transport_attempt'), state=record.get('state'),
                                state_class=attempt_state_class(record.get('state')),
                                wall_time_seconds=record.get('wall_seconds'), source_path=str(Path(path).resolve()),
                                summary_record_ordinal=ordinal, case_id=record.get('case_id'),
                                duplicate=record.get('duplicate'),
                                **usage_fields((record.get('shape') or {}).get('usage'))))
        if len(records) != summary['completed_attempt_records']:
            raise ValueError('replay summary count mismatch')
        attempts.extend(records)
        replay_cost = cost_row('api_replay', group, records, summary['planned_calls'])
        costs.append(replay_cost)
        replays.append({'summary_path': str(Path(path).resolve()), 'run_id': group,
                        'schema': summary['schema'], 'planned_calls': summary['planned_calls'],
                        'status': ('summary_read_complete' if replay_cost['attempt_ledger_complete'] else
                                   'summary_read_unresolved_states' if len(records) == summary['planned_calls'] else
                                   'summary_read_partial'),
                        'records': len(records), 'raw_dump_root': str(Path(path).resolve().parent),
                        'scope': 'separate API replay, never part of task score comparisons'})
    return pools, agents, comparisons, attempts, costs, {
        'schema': 'bounded-smoke-comparison-index-v1', 'inputs': list(inputs.files.values()),
        'attempt_state_taxonomy': {k: sorted(v) for k, v in ATTEMPT_STATES.items()},
        'expected_pools': sum(c['expected_jobs'] for c in spec['cohorts']),
        'pool_status_counts': dict(collections.Counter(r['status'] for r in pools)),
        'comparison_role_pool_counts': dict(collections.Counter(r['comparison_role'] for r in pools)),
        'primary_expected_pools': len(primary_pools),
        'primary_pool_status_counts': dict(collections.Counter(r['status'] for r in primary_pools)),
        'all_primary_execution_validated': all(r['execution_complete'] for r in primary_pools),
        'all_primary_scores_complete': all(r['score_complete'] for r in primary_pools),
        'all_execution_validated': all(r['execution_complete'] for r in pools),
        'all_scores_complete': all(r['score_complete'] for r in pools),
        'all_physical_attempt_ledgers_complete': all(c['attempt_ledger_complete'] for c in costs),
        'task_archives': archives, 'api_replay_archives': replays,
        'limits': ['Fixed inspected tasks, N2/R1/short horizon; not full matrix or causal proof.',
                   'NAS uses saved raw accuracy MI/BoN; no Gap imputation or scorer calls.',
                   'Audit MI averages saved per-agent EA/LA; MV uses saved aggregate metrics.',
                   'Reasoning is included in output; cached input is included in input. Do not add these subcategories twice.',
                   'Wall sums are request wall sums, not elapsed run/GPU allocation time.',
                   'Unrecorded token fields remain unknown, including failed physical attempts.',
                   'Unknown or pending physical-attempt states make failure totals and complete cost totals unknown. Known failure subtotals remain separate.',
                   'HTTP-delivered model protocol violations remain successful physical attempts; per-agent protocol_failure_reasons is a separate saved diagnostic.',
                   'Primary comparisons never mix cohorts; superseded groups retain original scores, unknowns and all physical-attempt costs.',
                   'Original dumps remain local-only; index creation is not publication clearance.',
                   'Existing validation is inherited, not independent scientific review or proof of serving fidelity.']}


def write_csv(path, rows):
    fields = list(dict.fromkeys(k for row in rows for k in row))
    with path.open('x', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--spec', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path, help='must not already exist')
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError('output already exists; preserve previous exports')
    pools, agents, comparisons, attempts, costs, index = collect(args.spec)
    args.output.mkdir(parents=True, exist_ok=False)
    for name, rows in [('per_pool', pools), ('per_agent', agents), ('comparisons', comparisons),
                       ('physical_attempts', attempts), ('costs', costs)]:
        write_csv(args.output / (name + '.csv'), rows)
    index['exported_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    index['exporter_sha256'] = sha(Path(__file__).read_bytes())
    (args.output / 'INDEX.json').write_text(json.dumps(index, ensure_ascii=False, indent=2) + '\n')
    lines = ['# Smoke 原始 dump 与比较索引', '',
             '固定诊断样本；本导出不运行模型或评分器，不替换旧正式报告。', '',
             f"池状态：`{json.dumps(index['pool_status_counts'], ensure_ascii=False)}`。", '',
             '[逐池](per_pool.csv) · [逐成员](per_agent.csv) · [三策略比较](comparisons.csv) · '
             '[全部物理尝试](physical_attempts.csv) · [成本](costs.csv) · [完整机器索引](INDEX.json)', '',
             '| Job | 比较角色 | 状态 | 原始 dump | 原结果 | 验证 |', '|---|---|---|---|---|---|']
    for entry in index['task_archives']:
        lines.append(f"| {entry['job_id']} | {entry['comparison_role']} | {entry['status']} | [{Path(entry['dump_root']).name}]({entry['dump_root']}) | [result]({entry['result']}) | [validation]({entry['validation']}) |")
    lines += ['', 'API replay 单列，不计入上表任务成绩：', '']
    lines += [f"- [{entry['run_id'] or 'pending summary'}]({entry['summary_path']})；状态：{entry['status']}；原dump目录：{entry['raw_dump_root']}" for entry in index['api_replay_archives']]
    (args.output / 'ARCHIVE_INDEX.md').write_text('\n'.join(lines) + '\n')
    print(json.dumps({'output': str(args.output.resolve()), 'pools': len(pools),
                      'statuses': index['pool_status_counts'], 'physical_attempts': len(attempts)}))


if __name__ == '__main__':
    main()
