"""Offline fixtures for the general first-decision frozen runner probe."""
import unittest
from classify import actual_runner_probe


PAYLOAD = {"tools": [{"type": "function", "function": {"name": "read_note", "parameters": {"type": "object", "properties": {"label": {"type": "string"}}, "required": ["label"]}}}]}
CALL = {"id": "call-1", "type": "function", "function": {"name": "read_note", "arguments": '{"label":"a"}'}}


class ProbeTests(unittest.TestCase):
    def run_probe(self, text, calls, finish):
        return actual_runner_probe(text, calls, {"role": "assistant", "content": text, "reasoning_content": "fixture only", "tool_calls": calls}, finish, PAYLOAD)

    def test_single_tool(self):
        result = self.run_probe("", [CALL], "tool_calls")
        self.assertEqual(result["first_decision_fake_tool_executions"], 1)
        self.assertTrue(result["first_decision_accepted"])

    def test_multiple_tools(self):
        result = self.run_probe("", [CALL, {**CALL, "id": "call-2"}], "tool_calls")
        self.assertEqual(result["first_decision_fake_tool_executions"], 0)
        self.assertEqual(result["paired_tool_protocol_rejections"], 2)
        self.assertFalse(result["first_decision_accepted"])

    def test_reasoning_only_empty_visible(self):
        result = self.run_probe("", [], "stop")
        self.assertEqual(result["user_protocol_rejections"], 1)
        self.assertIn("LLM returned empty response", result["rejection_reason"])
        self.assertFalse(result["first_decision_accepted"])

    def test_natural_final(self):
        result = self.run_probe("Answer: fixture", [], "stop")
        self.assertTrue(result["natural_final_accepted_without_scoring"])
        self.assertFalse(result["stopped_before_forced_final"])

    def test_length_stop(self):
        result = self.run_probe("", [CALL], "length")
        self.assertEqual(result["first_decision_fake_tool_executions"], 0)
        self.assertIn("completion token limit", result["rejection_reason"])


if __name__ == "__main__":
    unittest.main()
