# 原始顺序 v2 首请求 GPU 回放：协议与生成质量独立复核

**同输入真实 GPU 回放已经再次观察到明显乱码，不能宣称 DeepSeek 已修好。**
这同时揭示另一项独立问题：schema 合法的多工具输出仍会被原 runner 拒绝；
native tool 成功也不能证明 reasoning 没有循环退化或乱码。

| 条件 | 完成 | 连贯 | 严重循环退化 | 明显乱码 | 原 runner 接受首决策 | 多工具拒绝 | 空可见回复拒绝 |
|---|---:|---:|---:|---:|---:|---:|---:|
| original-order-v2-c1 | 8 | 8 | 0 | 0 | 5 | 3 | 0 |
| original-order-v2-c4 | 8 | 2 | 4 | 2 | 6 | 1 | 1 |
| 合计 | 16 | 10 | 4 | 2 | 11 | 4 | 1 |

“接受首决策”指实际冻结 native runner 将该决策派发给一个惰性工具 spy，
不是完整任务完成、正确答案或正式得分。c4 的 7 条 native 回复参数均符合 schema，
另 1 条 HTTP 200 / `finish_reason=stop` 仅有 reasoning，既无 content 也无 tool。
后者被 runner 正确拒绝为空回复，不能因 HTTP 200 将其记作协议通过。

## 两条明确乱码证据

- `c4 / audit_bad_first_1 / duplicate 2`：从可读分析进入长期循环，末段变成
  破碎词句、无关词与杂乱标点／数字；最终没有可见答案或工具调用。
  原始响应 SHA256 为
  `6bf1197bfd4344c0389e18198f6e65bdd0c4c47b839ddb25c519da69f0f07b95`。
- `c4 / audit_native_control / duplicate 2`：reasoning 中途明显崩成标点、
  无关 token／字母碎片，之后恢复语法分析并给出 17 个工具调用。
  原始响应 SHA256 为
  `24a2e125b6cbed914de7fd8134dc8141f65fe7b4040283f0664af8cb895037a0`。
  有最终 native tools 不会抵消中间已经发生的乱码，也不会使多调用满足单调用规则。

另有 4 条属于**严重循环退化而非字符乱码**：文字大体合乎语法，却持续无进展地
重解析同一问题或工具例子；其中 Search duplicate 1 最后确实发出一次 search。
这些标签来自逐条完整阅读 reasoning/content，不按长度、是否缺答或最终工具数推断。
本说明不引用长篇 reasoning；逐条简短依据及 SHA 见下方机读文件。

## 输入与实际 runner 验证

16 次新请求的实际 wire bytes 均与各自冻结原请求的保序序列化逐字节一致，
并与 `INPUTS.v2.json`、既有独立 actual-renderer CPU 审计的 wire SHA 一致。
四输入预期 token 数为 1974、2824、1860、730，两条件的 16 个实际 prompt token
计数全部匹配。计数仅是辅助验证；实际 bytes 与 renderer hash 链才是更强的输入身份。
v1 排序序列化样本和 v2 保序样本完全分开，未覆盖任何旧输出。

每条回复先核对 record/raw SHA，再调用冻结 `OpenAICompatibleLLM._decode_response`，
随后进入未修改的原 `run_react_loop`，只运行 1 个 CPU 决策、工具替换为惰性 spy，
在 forced-final 请求前主动停止。多工具批次全部拒绝，不偷偷执行第一个；
reasoning-only 回复保留其真实空可见输出。该复核没有模型调用、网络、真实任务工具、
gold 或评分器访问。通用 probe 的单工具、多工具、空可见输出、自然结束和 length
五个 CPU fixture 均通过；最终分类确定性复算通过。

## 不能从这些样本推出什么

这是 4 条目的性选择的首请求、每条件各重复 2 次，不是总体故障率估计或正式效果实验。
原记录配置下 FlashInfer 的实际采样不由请求 seed 保证逐次相同；c1/c4 未进行随机化、
交错或充分重复。虽然异常出现在本轮 c4，**不能据此确定并发就是根因**，也不能把
v1/v2 的差异归因于 schema 顺序。可以确认的是：相同历史输入在当前 GPU 服务上
仍会产生异常；根因尚需有限、单因素的 runtime 验证。评分、完整任务表现以及修复
带来的性能提升均不由本首轮诊断证明。

模型自己声称输入包含某条批量调用指令，不构成该指令实际存在的证据。

## 查验文件

- [逐响应 CSV](classification.csv)：16 条分类、原始 SHA、wire SHA、工具数、usage、时间。
- [完整分类与 CPU runner 证据](classification.json)：52 个 run 输入文件身份及源代码身份。
- [人工全文阅读标签](MANUAL_READABILITY.json)：明确区分连贯、循环退化和乱码。
- [独立复核脚本](classify.py)；[五项 probe 测试](test_classify.py)。

复算（无 GPU／网络）：

```bash
/lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python -B \
  eval_diagnostics_20260912/v2_contract_review/classify.py --check
```

原始 `original-order-v2-c1`、`original-order-v2-c4` 和全部 v1/历史实验数据保持不变。
