#!/usr/bin/env python3
"""Classify completed original-order v2 first responses offline, no model calls.

Requires both completed eight-attempt summaries and SHA-bound human labels.
Never inspects partially running output directories, never writes old artifacts.
"""
from __future__ import annotations

import argparse
import copy
import csv
import importlib.util
import io
import json
from pathlib import Path
import sys


OUT = Path(__file__).resolve().parent
DIAG = OUT.parent
ROOT = DIAG.parent
V1_REVIEW = DIAG / "v1_contract_review/classify.py"
spec = importlib.util.spec_from_file_location("frozen_v1_contract_probe", V1_REVIEW)
probe_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe_module)
sys.path.insert(0, str(DIAG))
import replay_first_requests_v2 as wire_helper

CONDITIONS = ("original-order-v2-c1", "original-order-v2-c4")


def actual_runner_probe(text, calls, assistant, finish, payload):
    """General first-decision probe, including reasoning-only/empty/final output."""
    executed, followup = [], []
    stopped = False
    result = None

    class ReplayOnly:
        supports_native_tools = True
        count = 0

        def generate(self, messages, *, tools, tool_choice):
            self.count += 1
            if self.count == 1:
                if tool_choice != "auto":
                    raise AssertionError("Expected original native auto decision")
                return probe_module.LLMOutput(text=text, tool_calls=copy.deepcopy(calls),
                                              assistant_message=copy.deepcopy(assistant), finish_reason=finish,
                                              request_attempts=0)
            if self.count != 2 or tool_choice != "none":
                raise AssertionError("Unexpected extra model decision")
            followup.extend(copy.deepcopy(messages))
            raise probe_module.StopBeforeForcedFinal()

    tools = {}
    for definition in payload["tools"]:
        name = definition["function"]["name"]

        def spy(argument, name=name):
            executed.append(name)
            return ("offline contract probe; not task feedback", 0.0)

        spy.__expgym_tool_schema__ = copy.deepcopy(definition["function"])
        tools[name] = spy
    try:
        result = probe_module.run_react_loop(ReplayOnly(), tools, max_steps=1, max_protocol_retries=0,
                                            tool_protocol="native", context="Offline first-decision contract probe")
    except probe_module.StopBeforeForcedFinal:
        stopped = True
    notices = [message for message in followup if message.get("role") in ("user", "tool")
               and isinstance(message.get("content"), str) and message["content"].startswith("Protocol error:")]
    natural_final = result is not None and result.get("answer") is not None
    if not stopped and not natural_final:
        raise AssertionError("Unclassified first-decision terminal")
    return {"first_decision_fake_tool_executions": len(executed),
            "paired_tool_protocol_rejections": sum(message["role"] == "tool" for message in notices),
            "user_protocol_rejections": sum(message["role"] == "user" for message in notices),
            "rejection_reason": notices[0]["content"] if notices else None,
            "stopped_before_forced_final": stopped,
            "natural_final_accepted_without_scoring": natural_final,
            "first_decision_accepted": bool(executed or natural_final)}


def build():
    # Check completion markers before opening any new response/request bodies.
    summaries = {}
    for condition in CONDITIONS:
        path = DIAG / condition / "SUMMARY.json"
        summary = json.loads(path.read_text())
        if summary.get("completed_attempt_records") != 8 or len(summary.get("records", [])) != 8:
            raise ValueError("Condition is not complete: " + condition)
        summaries[condition] = summary
    manual_path = OUT / "MANUAL_READABILITY.json"
    manual = json.loads(manual_path.read_text())
    labels = {(row["condition"], row["case_id"], row["duplicate"]): row for row in manual["rows"]}
    if len(labels) != 16:
        raise ValueError("Need sixteen SHA-bound manual labels")
    manifest, original_payloads, _ = wire_helper.checked_cases(DIAG / "INPUTS.v2.json")
    cases = {row["case_id"]: row for row in manifest["cases"]}
    rows, probes, inputs, conditions = [], [], [], []
    for condition in CONDITIONS:
        summary = summaries[condition]
        inputs.extend(probe_module.identity(DIAG / condition / name) for name in ("SUMMARY.json", "PLAN.json"))
        condition_rows = []
        for summary_record in summary["records"]:
            case_id, duplicate = summary_record["case_id"], summary_record["duplicate"]
            folder = DIAG / condition / (case_id + "--duplicate-" + str(duplicate))
            record_path, response_path, request_path = folder / "record.json", folder / "response.body.bin", folder / "request.json"
            record = json.loads(record_path.read_text())
            if record != summary_record:
                raise ValueError("Summary/record mismatch")
            raw, request_raw = response_path.read_bytes(), request_path.read_bytes()
            if probe_module.sha(raw) != record["response_body_sha256"]:
                raise ValueError("Raw response hash mismatch")
            case = cases[case_id]
            if probe_module.sha(request_raw) != record["request_wire_sha256"] or record["request_wire_sha256"] != case["ordered_wire_sha256"]:
                raise ValueError("Ordered wire hash mismatch")
            if request_raw != wire_helper.wire_body(original_payloads[case_id]):
                raise ValueError("Actual sent bytes differ from frozen original-order body")
            annotation = labels[(condition, case_id, duplicate)]
            if annotation["response_body_sha256"] != probe_module.sha(raw):
                raise ValueError("Human annotation bound to different response")
            if annotation["label"] not in ("coherent", "degenerate_repetition", "obvious_garbled", "uncertain"):
                raise ValueError("Unknown manual label")
            payload = json.loads(request_raw)
            data, text, calls, assistant, finish = probe_module.OpenAICompatibleLLM._decode_response(raw)
            schemas = {tool["function"]["name"]: tool["function"]["parameters"] for tool in payload["tools"]}
            valid = sum(call["function"]["name"] in schemas and probe_module.schema_valid(json.loads(call["function"]["arguments"]), schemas[call["function"]["name"]]) for call in calls)
            probe = actual_runner_probe(text, calls, assistant, finish, payload)
            dispatch_accepted = probe["first_decision_fake_tool_executions"] == 1
            if dispatch_accepted:
                classification = "accept_one_native_tool"
            elif probe["natural_final_accepted_without_scoring"]:
                classification = "accept_natural_final_without_scoring"
            elif len(calls) > 1:
                classification = "reject_multiple_native_tools"
            elif not calls and not text:
                classification = "reject_empty_visible_response"
            else:
                classification = "reject_other_protocol_decision"
            usage = data["usage"]
            row = {"condition": condition, "case_id": case_id, "duplicate": duplicate,
                   "original_request_id": record["original_request_id"], "original_dump_sha256": case["original_sha256"],
                   "request_wire_sha256": record["request_wire_sha256"], "response_body_sha256": probe_module.sha(raw),
                   "response_body_bytes": len(raw), "raw_tool_calls": len(calls), "schema_valid_tool_calls": valid,
                   "client_transport_accepted": True, "runner_first_decision_dispatch_accepted": dispatch_accepted,
                   "runner_first_decision_accepted": probe["first_decision_accepted"],
                   "runner_classification": classification,
                   "schema_only_usable": record["shape"]["protocol_shape_usable"],
                   "manual_readability_label": annotation["label"], "manual_readability_basis": annotation["basis"],
                   "finish_reason": finish, "expected_prompt_tokens": case["expected_prompt_tokens"],
                   "prompt_tokens": usage["prompt_tokens"], "prompt_token_count_matches": usage["prompt_tokens"] == case["expected_prompt_tokens"],
                   "completion_tokens": usage["completion_tokens"], "reasoning_tokens": usage.get("reasoning_tokens"),
                   "total_tokens": usage["total_tokens"], "wall_seconds": record["wall_seconds"]}
            rows.append(row)
            condition_rows.append(row)
            probes.append({"condition": condition, "case_id": case_id, "duplicate": duplicate, **probe})
            inputs.extend(probe_module.identity(path) for path in (record_path, response_path, request_path))
        conditions.append({"condition": condition, "attempts": len(condition_rows),
                           "schema_all_calls_valid_responses": sum(row["raw_tool_calls"] > 0 and row["schema_valid_tool_calls"] == row["raw_tool_calls"] for row in condition_rows),
                           "runner_first_decision_dispatch_accepted": sum(row["runner_first_decision_dispatch_accepted"] for row in condition_rows),
                           "runner_first_decision_accepted": sum(row["runner_first_decision_accepted"] for row in condition_rows),
                           "runner_multicall_rejected": sum(row["runner_classification"] == "reject_multiple_native_tools" for row in condition_rows),
                           "runner_empty_visible_rejected": sum(row["runner_classification"] == "reject_empty_visible_response" for row in condition_rows),
                           "prompt_token_count_matches": sum(row["prompt_token_count_matches"] for row in condition_rows),
                           "manual_label_counts": {label: sum(row["manual_readability_label"] == label for row in condition_rows) for label in ("coherent", "degenerate_repetition", "obvious_garbled", "uncertain")}})
    csvout = io.StringIO(newline="")
    writer = csv.DictWriter(csvout, fieldnames=list(rows[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    result = {"schema": "expgym.offline-v2-contract-review.v1", "conditions": conditions,
              "scope": "Sixteen purpose-selected first requests, two fixed duplicates per case per concurrency; actual original-order wire bodies verified.",
              "no_network_model_real_tools_gold_or_evaluator": True, "fresh_model_calls": 0,
              "method": "Frozen client decoder and unmodified frozen one-step native runner with inert tool spies; stops before forced final. Dispatch acceptance is not task-tool execution or final-task success.",
              "manual_method": manual["method"], "selection_not_performance_corpus": True,
              "causal_limitations": ["A sample without observed obvious garbling does not prove historical garbling is fixed or its cause identified; manual labels are separate from protocol results.", "v1 order-perturbed and v2 outputs are nondeterministic samples, not paired causal evidence for an order or concurrency effect.", "Native schema validity does not imply the runner permits a multiple-tool batch.", "Only the first decision is probed, not the full task trajectory or task correctness."],
              "manifest": probe_module.identity(DIAG / "INPUTS.v2.json"), "manual_labels": probe_module.identity(manual_path),
              "sources": [probe_module.identity(V1_REVIEW), probe_module.identity(Path(__file__)), probe_module.identity(probe_module.REPO / "expgym/react_loop.py"), probe_module.identity(probe_module.REPO / "expgym/llm_clients.py")],
              "inputs": inputs, "rows": rows, "cpu_runner_probes": probes}
    return {"classification.csv": csvout.getvalue(), "classification.json": json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n"}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--build", action="store_true")
    group.add_argument("--check", action="store_true")
    args = parser.parse_args()
    outputs = build()
    for name, text in outputs.items():
        if args.check:
            if (OUT / name).read_bytes() != text.encode("utf-8"):
                raise ValueError("Sidecar identity mismatch: " + name)
        else:
            with (OUT / name).open("x", encoding="utf-8") as handle:
                handle.write(text)
    print("PASS: completed v2 conditions, exact wire/response identities, frozen CPU runner probe, sixteen manual annotations")
