# DeepSeek 首轮编码与采样路径复核

本目录是独立诊断材料，不修改旧 runtime、study、checkpoint 或正式结果。
这项检查不调用模型、不加载权重、不初始化 CUDA；不能视为 GPU 或模型质量验收。

启动环境的独立对照见 [STARTUP_ENV_REVIEW.zh.md](STARTUP_ENV_REVIEW.zh.md)。
后续发现的诊断 schema 排序差异与单调用能力缺口，见独立增补
[SERIALIZATION_AND_SINGLE_CALL.zh.md](SERIALIZATION_AND_SINGLE_CALL.zh.md)，不覆盖首轮检查结果。
可选单调用原型的 parser 边界与 CPU 编码碰撞证明，见
[DSML_PARSER_BOUNDARY_DESIGN.zh.md](DSML_PARSER_BOUNDARY_DESIGN.zh.md)；原型继续 fail-closed。

## 已核实的结论

四条固定原始输入经过冻结 SGLang 实际 `OpenAIServingChat` renderer，与 checkpoint
随附的官方 0731 编码器逐 token 完全一致。历史服务记录与离线重建 token 数分别为
1974、2824、1860、730，逐条相等。最大思考前缀、完整工具定义均保留；四条输入均为
system/user 首轮，没有输入特殊 token；`thinking` 与 `enable_thinking` 均为 true。
机器可读证据见 `RESULT.v1.json`，包含每条输入、渲染文本与 token 序列的 SHA256。

Deep 0.5.17 的 `multinomial_with_seed` 确实仍有 `hash / uint32.max` 的端点写法，
未包含此前 GLM/Kimi 的 midpoint 修复。但四个原始服务均记录了
`sampling_backend=flashinfer`、`enable_deterministic_inference=False`、
`rl_on_policy_target=None`。`SamplingBatchInfo` 因此将有效 sampling seed 设为 None；
实际 top_p=0.95 请求走 FlashInfer joint rejection sampler，不调用该 Murmur/Gumbel 函数。
报告同时保存源码片段、行号、源码完整 hash，以及原始四个 server_args 日志行 hash。

因此不能用请求 seed 2200/2202 的假想 Murmur 端点命中来解释这次乱码。请求带 seed
并不意味着当前运行时执行逐请求确定性采样：FlashInfer 在此读取默认设备 generator。
同输入诊断应比较重复采样的协议/乱码情况，不应要求逐 token 相同；也不能未经单独设计
就开启 deterministic，因为这会改变执行路径，并引入尚未修复的另一缺陷。

## 复现

请从工作区根目录运行；约需数分钟 CPU import，Lustre 冷缓存可能更久。输出必须是本目录
中不存在的新文件，helper 拒绝覆盖已有结果。以下命令仅生成新的 JSON 诊断结果：

```bash
source deepseek_flash_eval_20260911/runtime/runtime-env.sh
CUDA_VISIBLE_DEVICES='' deepseek_flash_eval_20260911/runtime/.venv/bin/python -B \
  eval_diagnostics_20260912/serving_audit/replay_encoder_and_sampler.py \
  --output eval_diagnostics_20260912/serving_audit/RESULT.recheck.json
```

helper 固定核验四输入清单、旧检查器、版本文件、旧新 sampler SHA256；旧检查器继续核验
实际编码器补丁、checkpoint tokenizer/config 和依赖版本。结果不会复制完整任务内容或答案。

## 解释边界

这里排除的是这四条首轮请求的编码错配，以及旧 Gumbel 端点缺陷的实际可达性。
不证明权重张量正确、不证明 GPU 计算或并发执行正确，也不能单凭乱码归因模型能力。
原始生成 token 流未存档；历史 HTTP 响应是 SGLang parser 之后的结果。
待原配置的实际 GPU 重复验证完成后，再判断服务质量及结论适用范围。
