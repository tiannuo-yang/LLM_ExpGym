"""Offline exact-render comparison of original payloads and completed c1 requests.

No model calls, GPU work, rescoring, runtime edits or old-artifact overwrites.
The result records only schema/prompt identity and bounded source evidence.
"""
from __future__ import annotations

import argparse
import copy
import datetime
import hashlib
import json
from pathlib import Path
import runpy


ROOT = Path('/lustrefs/users/chufan.shi/codex_space_tn')
AUDIT = ROOT / 'eval_diagnostics_20260912/serving_audit'
BASE_HELPER = AUDIT / 'replay_encoder_and_sampler.py'
BASE_SHA = '4392dd490a8fb15d509117551e7bb4e10e31c9fa96619f01bad17eea583b3299'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def source_excerpt(inputs, path, first, last):
    raw = inputs.read(path)
    return {'path': str(path), 'sha256': sha(raw), 'first_line': first, 'last_line': last,
            'text': '\n'.join(raw.decode().splitlines()[first - 1:last])}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    output = args.output.absolute()
    require(output.parent.resolve() == AUDIT.resolve() and not output.exists() and not output.is_symlink(),
            'Output must be a new file in serving_audit')
    require(sha(BASE_HELPER.read_bytes()) == BASE_SHA, 'Prior audit helper changed')
    base = runpy.run_path(str(BASE_HELPER))
    old_path = base['REPLAY']
    old_bytes = old_path.read_bytes()
    require(sha(old_bytes) == base['PINS'][old_path], 'Original renderer helper changed')
    namespace = {'__name__': 'frozen_renderer_check', '__file__': str(old_path)}
    exec(compile(old_bytes, str(old_path), 'exec'), namespace)
    inputs = namespace['Inputs']()
    inputs.read(BASE_HELPER, BASE_SHA)
    inputs.read(Path(__file__).resolve())
    inputs.read(old_path, base['PINS'][old_path])
    manifest_path = ROOT / 'eval_diagnostics_20260912/INPUTS.json'
    manifest = inputs.json(manifest_path, base['PINS'][manifest_path])
    renderer = namespace['Renderer'](inputs, str(base['CHECKPOINT']), base['RUNTIME'] / 'versions.json',
                                      base['PINS'][base['RUNTIME'] / 'versions.json'])
    cases = []
    for case in manifest['cases']:
        original = inputs.json(case['original_path'], case['original_sha256'])
        folder = ROOT / 'eval_diagnostics_20260912/baseline-tp8-c1' / (case['case_id'] + '--duplicate-1')
        require((folder / 'record.json').is_file(), 'Only completed response artifacts may be compared')
        wire_payload = inputs.json(folder / 'request.json')
        response = inputs.json(folder / 'response.decoded.json')
        replay_record = copy.deepcopy(original)
        replay_record.update(request_payload=wire_payload, response_json=response,
                             response_raw=inputs.read(folder / 'response.body.bin').decode())
        old_result, new_result = [renderer.replay(item) for item in (original, replay_record)]
        prompts = []
        for payload in (original['request_payload'], wire_payload):
            request = renderer.request_type(**copy.deepcopy(payload))
            tools = [tool.model_dump() for tool in request.tools]
            messages = namespace['reference_messages'](payload, tools)
            prompts.append(renderer.reference['encode_messages'](messages, thinking_mode='thinking', reasoning_effort='max'))
        blocks = []
        for prompt in prompts:
            prefix, rest = prompt.split('### Available Tool Schemas\n\n', 1)
            schema_text, suffix = rest.split('\n\nYou MUST strictly follow the above defined tool name', 1)
            blocks.append((prefix, schema_text, suffix))
        require(original['request_payload'] == wire_payload, 'Request values changed beyond key ordering')
        require(blocks[0][0] == blocks[1][0] and blocks[0][2] == blocks[1][2], 'Non-schema rendered text differs')
        require(json.loads(blocks[0][1]) == json.loads(blocks[1][1]), 'Schema semantics changed')
        require(prompts[0] != prompts[1], 'Expected schema-order rendering difference absent')
        cases.append({
            'case_id': case['case_id'], 'original_path': case['original_path'], 'new_request_path': str(folder / 'request.json'),
            'payload_objects_equal': True, 'all_rendered_text_differences_confined_to_schema_key_order': True,
            'old_render': old_result, 'new_render': new_result,
            'old_schema_sha256': sha(blocks[0][1].encode()), 'new_schema_sha256': sha(blocks[1][1].encode()),
            'schema_byte_length_unchanged': len(blocks[0][1].encode()) == len(blocks[1][1].encode()),
            'original_property_order': list(original['request_payload']['tools'][0]['function']['parameters']['properties']),
            'new_property_order': list(wire_payload['tools'][0]['function']['parameters']['properties']),
            'new_native_call_count': len(response['choices'][0]['message'].get('tool_calls') or []),
            'request_parallel_tool_calls': wire_payload['parallel_tool_calls'],
            'request_tool_choice': wire_payload['tool_choice'],
        })
    site = base['SITE'] / 'sglang/srt'
    frozen = ROOT / 'LLM_ExpGym-deepseek-flash-20260911/expgym'
    publication = ROOT / 'publication/five_model_report_20260911/expgym'
    framework = {}
    for name in ('tool_protocol.py', 'react_loop.py'):
        a, b = inputs.read(frozen / name), inputs.read(publication / name)
        require(a == b, 'Compared frozen and publication framework protocol files differ')
        framework[name] = {'frozen_sha256': sha(a), 'publication_sha256': sha(b), 'equal': True}
    evidence = [source_excerpt(inputs, path, first, last) for path, first, last in (
        (frozen / 'llm_clients.py', 382, 386),
        (frozen / 'tool_protocol.py', 414, 450),
        (frozen / 'react_loop.py', 320, 341),
        (frozen / 'react_loop.py', 367, 375),
        (site / 'entrypoints/openai/serving_chat.py', 1072, 1082),
        (site / 'entrypoints/openai/serving_chat.py', 1239, 1249),
        (site / 'entrypoints/openai/encoding_dsv4.py', 87, 124),
        (site / 'entrypoints/openai/encoding_dsv4.py', 220, 237),
        (site / 'function_call/function_call_parser.py', 247, 264),
        (site / 'function_call/base_format_detector.py', 383, 440),
    )]
    require(not renderer.torch.cuda.is_initialized() and not renderer.network_attempts, 'CPU-only offline check violated')
    result = {
        'schema': 'deepseek_schema_order_and_single_call_audit_v1',
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'status': 'passed_offline_exact_render_comparison_not_generation_validation',
        'cases': cases, 'cuda_initialized': False, 'network_attempts': [],
        'framework_protocol_files_match': framework, 'source_evidence': evidence,
        'interpretation': {
            'c1_is_exact_render_replay_of_formal_inputs': False,
            'c1_request_json_values_equal_original': True,
            'usage_delta_explained_by_schema_key_order': True,
            'upfront_framework_one_call_instruction_already_present': True,
            'rejected_multi_call_feedback_explicitly_states_one_call_and_no_execution': True,
            'schema_valid_multi_call_is_runner_admissible': False,
            'this_explains_all_historical_garbling_or_poolact_effects': False,
        },
        'limitations': ['Only the four completed duplicate-1 c1 artifacts were rendered.',
                        'No model requests or performance rescoring were performed.',
                        'No prompt, runtime, evaluator or running replay was changed.',
                        'The caller must not infer deterministic generation from input identity or request seed.'],
        'inputs': inputs.finish(),
    }
    text = json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n'
    with output.open('x', encoding='utf-8') as handle:
        handle.write(text)
    print(json.dumps({'output': str(output), 'sha256': sha(text.encode()), 'cases': len(cases), 'status': result['status']}))


if __name__ == '__main__':
    main()
