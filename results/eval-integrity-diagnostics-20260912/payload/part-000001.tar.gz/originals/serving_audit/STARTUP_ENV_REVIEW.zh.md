# 旧 launch02 与诊断 baseline 的启动差异

范围：只读核对源码、配置与有界日志片段；目标为 DeepSeek baseline job 1205016。
没有读取完整环境、没有 ptrace/sudo/signal、没有修改正在运行的进程，没有模型调用。
这是加载期间的一次有限配置审查，不是服务已就绪或失败的判定。

## 结论

存在一个此前 delta 清单漏记的启动环境差异：旧 launcher 给子进程显式设置
`OMP_NUM_THREADS=8`、`PYTHONUNBUFFERED=1`，新 launcher 直接继承环境。
但这不构成加载慢的因果证据：相同 runtime 在 CUDA 模型加载前执行
`torch.set_num_threads(1)`；实际 safetensors loader 另有独立的 8-worker 线程池。
本次审查没有取得新远程进程有效 OMP/MKL/OPENBLAS 值，不能把“没有固定”写成确定值。

没有发现 checkpoint loader、mmap、prefetch、dtype、容器或显式异步加载参数变化。
主监控记录的 read_bytes 仍在增长，与“没有任何进展/已经卡死”判断不符；具体 I/O
测量属于主监控记录，本报告不将转述值冒充自己重新测量的结果。

## 有证据的差异与解释边界

| 项目 | 旧 launch02 | 新 baseline | 解释 |
|---|---|---|---|
| OMP/Python buffering | 子进程固定 OMP=8、unbuffered=1 | 不显式固定，继承环境 | 可复现性清单应记录；不能直接解释慢加载 |
| 编译缓存 | DG/TileLang/CUDA 位于 runtime 下共享缓存；Triton/HF modules/TVM 每次分配隔离 | 全部位于新的 `/tmp/expgym_diag_JOB_rankR`，额外隔离 FlashInfer/XDG/HF | 可能增加冷 JIT 初始化；不能据此归因当前 checkpoint 读盘慢 |
| srun 失败传播 | `--kill-on-bad-exit=0` | `--kill-on-bad-exit=1` | 生命周期监督差异，不是 loader 算法差异 |
| 服务初始化随机种子 | launcher 未显式指定 | 同样未显式指定，记录值不同 | 输出复现记录项，不解释存储吞吐 |

源码依据：

- `deepseek_flash_eval_20260911/serving/launch02/serve_slurm.py:218–228,245–250`。
- `deepseek_flash_eval_20260911/runtime/runtime-env-isolated.sh:4–9`。
- `eval_diagnostics_20260912/serving/runtime-env.sh:4–15`。
- `eval_diagnostics_20260912/serving/run-server.py:46,50`；第 46 行的 delta 清单未覆盖 OMP 固定差异。
- `eval_diagnostics_20260912/serving/baseline/serve.sbatch:16–18`。

## 已确认相同

旧 `launch02/plan.json` 的 container_image=null、container_mounts=[]；新 sbatch 也没有
container 参数。两边每节点均为 32 CPUs、8 GPUs、`--cpu-bind=none`。

对照旧 `deepseek_flash_eval_20260911/serving/launch02/replica0-rank0.log:14`
和新 `eval_diagnostics_20260912/serving/baseline/slurm-1205016.log:14`：

- 相同 checkpoint、冻结 runtime、TP8/PP1/EP1。
- `load_format='auto'`，`model_loader_extra_config='{}'`，`dtype='auto'`，`quantization=None`。
- `weight_loader_disable_mmap=False`，`weight_loader_prefetch_checkpoints=False`。
- `weight_loader_prefetch_num_threads=4`，但预取未启用。
- `weight_loader_drop_cache_after_load=False`，`cpu_offload_gb=0`。
- 无新增显式 remote/async checkpoint loader 参数。

实际加载源码位于同一个私有 runtime 的 `sglang/srt/` 下：

- `model_executor/model_runner.py:1015–1017`：CUDA 加载前 `torch.set_num_threads(1)`。
- `model_loader/loader.py:368,633–641`：默认 loader 线程数 8，extra_config={} 不覆盖。
- `model_loader/weight_utils.py:1104–1164`：buffered safetensors iterator，
  `ThreadPoolExecutor(max_workers)`，默认 mmap `safe_open`；最多约 9 个 shard 在途。
  这是独立于 OMP 的线程池，不能从 OMP 环境遗漏推导为单线程读取。

## 审查时源码 SHA256

路径均相对于工作区；runtime 库文件的共同前缀为
`deepseek_flash_eval_20260911/runtime/.venv/lib/python3.12/site-packages/sglang/srt/`。

```text
42632c3d679ed5a2d476215135d6d54ddca800ce27ac1b8e88872f02abb53776  deepseek_flash_eval_20260911/serving/launch02/serve_slurm.py
5b52270bc12986f1ebdeb067598c0844db4fde37df0c44e58031e045d0863edf  deepseek_flash_eval_20260911/runtime/runtime-env-isolated.sh
2e025b956965eb032a1ae43b4d7d2fb17ce13b611c3d5e297998b1f43e7df9a3  eval_diagnostics_20260912/serving/run-server.py
9652e7ab4e4eac31d075af4799aef6dda98b4b7639b81698010d951cdbfc7803  eval_diagnostics_20260912/serving/runtime-env.sh
9e7caccb193810c7989f7f7d3885cb744caad05632c2625b45e77bd5cdc9a9d8  eval_diagnostics_20260912/serving/baseline/serve.sbatch
1366587f70f58f65d16ec02d500e0ebae985891cae87ab911c2d46cc30ae474a  eval_diagnostics_20260912/serving/baseline/run-rank.sh
221032bf7ae57d2ebdb96801150a48d23244840a9b7938dc586e911671c11102  model_executor/model_runner.py
04e8dd279e1ffcc5d9405ccab1deb5ad073cbab81a1a7ad64d8c5ece21871609  model_loader/loader.py
3e34c2449bdbfb6a2db6c1422d0e6d28d45ee4b83b9fa8d019c2e26913530cb4  model_loader/weight_utils.py
```

建议只把已核实的环境差异补入诊断 provenance。当前没有足够证据要求立即重启或更换
loader 参数；是否进行单变量验证由主任务根据实际加载进度和服务就绪情况决定。
