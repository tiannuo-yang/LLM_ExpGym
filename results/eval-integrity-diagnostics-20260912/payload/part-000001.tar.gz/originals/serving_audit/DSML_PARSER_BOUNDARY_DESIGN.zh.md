# DSML parser 边界：可修复部分与无法由 parser 独自消除的歧义

状态：仅 CPU／源码设计复核，不部署；现有 `single_call_adapter` 的 14 项测试
13 pass / 1 fail 与公开入口 fail-closed 保持不动。没有改 frozen runtime、checkpoint、
源仓库或任何正式数据，也没有模型调用。

## 结论

当前失败样例可局部修复，但不能因此把原型升级为“任意合法字符串都保证最多一个调用”。
具体失败是 XML `string="true"` 的参数值包含 invoke 结束／开始标签，**不是仅有 JSON
字符串问题**。参数感知的 scanner 可以正确处理不含自身 parameter 结束符的该样例。

更深一层，官方 XML encoder 原样插入字符串，无转义／长度边界；同一段合法编码文本
可以由不同参数字典产生，甚至可以由一个调用和两个调用产生。没有任何只读文本的
parser 能唯一恢复这两种编码的原始意图。这个问题不能靠更复杂的正则或仅限制外层
grammar 解决；也不能通过删除第二个调用、改变评分或收紧 schema 来掩盖。

## 可复现证据

[DSML_FRAMING.v1.json](DSML_FRAMING.v1.json) 保存两种碰撞的输入、完整合成编码、
源码与 helper SHA256。结果 SHA256：
`6d4ba4767a1c403b0bd26d52b52770fb50f51c18f6815bc66b59a577467f1b3f`。

[prove_dsml_framing.py](prove_dsml_framing.py) 使用原始 checkpoint 编码器的
`encode_arguments_to_dsml` 和实际 `render_message` 执行断言，仅依赖标准库。
第二个证明中，两种输入都使用同一个 `lookup(q: string)` 工具，参数均是合法 JSON；
第一种有一个调用，第二种有两个调用，实际 renderer 输出逐字节相同。它不是通过
schema 不同或者非法 JSON 制造的反例。

```bash
python3 -B eval_diagnostics_20260912/serving_audit/prove_dsml_framing.py \
  --output eval_diagnostics_20260912/serving_audit/DSML_FRAMING.recheck.json
```

输出必须是本目录中不存在的新文件，helper 拒绝覆盖已有证据。
首次 helper 执行发现内部调用列表需转换成 OpenAI 格式，未生成结果文件；按原始
`tool_calls_to_openai_format` 转换后重跑，上述两个断言均通过。未隐藏失败或改动被测源码。

## 精确源码路径

冻结 runtime 前缀：
`deepseek_flash_eval_20260911/runtime/.venv/lib/python3.12/site-packages/sglang/`。

| 路径／行 | 证据 |
| --- | --- |
| `srt/function_call/deepseekv32_detector.py:77–90` | XML parameter regex 与先切 invoke 的 regex 都不理解嵌套值边界 |
| 同文件 `:203–220` | nonstream 先切外层 block，再切 invoke，最后解析参数 |
| 同文件 `:265–303` | streaming 同样先切 invoke，可能过早发布无法撤回的调用名／参数前缀 |
| `srt/function_call/deepseekv4_detector.py:8,60–64` | V4 继承上述实现，只改变 block 标记等属性 |
| `srt/entrypoints/openai/encoding_dsv4.py:167,179–188` | runtime encoder 也把 XML string 值原样放入，和 checkpoint 一致 |

Checkpoint `/lustrefs/users/runner/chufan.shi/tau_vision/ckpts/DeepSeek-V4-Flash-0731/encoding/encoding_dsv4.py`：

- `:161,174,178`：字符串与参数连接不做 XML 标记转义。
- `:53,340–351`：调用模板与换行连接，使一个／两个调用的完整文本碰撞成立。
- `:646–700`：官方 parser 进入参数后先找 parameter 结束符，故能处理当前 fixture 中的
  invoke 字面量；但遇到 parameter 自身结束符时也不能恢复已经丢失的原始边界。

## 最小设计及风险

若单独修复无歧义的 parser 兼容性 bug，可限于同一 detector 的共享 scanner：

1. 明确 outer block、invoke header、XML parameter、direct JSON、调用间隔状态。
   在参数内部忽略 invoke／outer-block 标记；direct JSON 跟踪字符串、反斜杠转义与括号深度。
   不能只替换 invoke regex，因为字符串里的 outer-block 结束标记也会截断。
2. nonstream 与 streaming 使用同一套结构边界，不删除、合并或截取真正的多个调用。
   streaming 只发布确定的前缀；如首版缓冲完整参数再发布，需要明确这是延迟行为变化。
3. 测试覆盖字符串内 invoke／block 标记、直接 JSON 中完整 DSML 片段、转义引号／反斜杠、
   XML 非字符串里的嵌套 JSON、所有字符位置分块、self-closing、零调用、真实多调用／多 block、
   裸 invoke 的现有流式兼容行为、reasoning 边界。保留原始参数字符串空白，不沿用
   `.rstrip(token)` 的字符集合裁剪作为精确截断。

这个有限 scanner 修补不需要新框架，但不足以解除当前通用 adapter 的阻断。
要完整支持任意字符串且保证 grammar/parser 一致，需要明确且可逆的编码约定，并同步
编码历史消息、grammar、nonstream 和 streaming，例如对歧义值使用支持转义的 direct JSON
表示。该方案保留字符串语义，却是协议／表示方式变化，不再是 parser-only 小修；不能在
没有 round-trip 与联合约束测试时悄悄部署，也不应把合法字符串禁掉作为所谓通用修复。

因此，本轮到设计与反证为止，不继续实现更大的 runtime overlay。

## 对当前实验的解释边界

上述都是合成输入的源码可证明问题，不是已确认出现在原始任务中的触发样例。
实际 Audit／NAS 工具通常使用 enum／整数，未必触发该字符串边界；不能据此归因正式运行
中的乱码、PoolAct 反例，也不能把修复本测试当作数值／并发稳定性已验收。
当前 GPU 并发单因素诊断与此相互独立。
