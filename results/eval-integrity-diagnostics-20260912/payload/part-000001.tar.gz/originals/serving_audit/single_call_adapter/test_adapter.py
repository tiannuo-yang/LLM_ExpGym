"""CPU actual-XGrammar tests, plus original source-class parser/reasoner tests.

No server import, socket, subprocess, model-weight loading or GPU operation.
The optional real-tokenizer test opens only tokenizer metadata, local_files_only.
"""
import ast
import copy
import json
import logging
import os
from pathlib import Path
import re
from types import SimpleNamespace
from typing import List, Optional
import unittest
from abc import ABC, abstractmethod
import __future__

import partial_json_parser
from partial_json_parser.core.options import Allow
from pydantic import BaseModel
import torch
import xgrammar as xgr

from adapter import (BOT, EOT, INVOKE, INVOKE_END, UnsupportedParserAlignment,
                     _single_call_tag_candidate as single_call_tag,
                     _install_candidate_on_detector_class_for_tests as install_on_detector_class,
                     _prepare_request_overlay_candidate_for_tests as prepare_candidate,
                     install_on_detector_class as public_install,
                     prepare_request_overlay)

ROOT = Path(__file__).resolve().parents[3]
SITE = ROOT / 'deepseek_flash_eval_20260911/runtime/.venv/lib/python3.12/site-packages'
SG = SITE / 'sglang'
CHECKPOINT = Path('/lustrefs/users/runner/chufan.shi/tau_vision/ckpts/DeepSeek-V4-Flash-0731')
TOOLS = [{'type': 'function', 'function': {
    'name': 'lookup', 'parameters': {'type': 'object', 'properties': {'q': {'type': 'string'}},
                                  'required': ['q'], 'additionalProperties': False}}},
         {'type': 'function', 'function': {'name': 'noop', 'parameters': {
             'type': 'object', 'properties': {}, 'additionalProperties': False}}}]
CAPS = dict(tool_call_parser='deepseekv4', chat_encoding_spec='dsv4',
            reasoning_parser='deepseek-v4', structural_tag_supported=True)


def invoke(name='lookup', body='<｜DSML｜parameter name="q" string="true">Ada</｜DSML｜parameter>\n'):
    return f'<｜DSML｜invoke name="{name}">\n{body}{INVOKE_END}\n'


def block(*items):
    return '\n\n' + BOT + '\n' + ''.join(items) + EOT


def source_definitions(relative, names, namespace):
    """Execute selected original definitions, not copied implementations."""
    path = SG / relative
    tree = ast.parse(path.read_text(), filename=str(path))
    picked = [node for node in tree.body if isinstance(node, (ast.ClassDef, ast.FunctionDef))
              and node.name in names]
    if {node.name for node in picked} != set(names):
        raise AssertionError('Missing frozen source definitions')
    module = ast.Module(body=picked, type_ignores=[])
    exec(compile(module, str(path), 'exec', flags=__future__.annotations.compiler_flag), namespace)


def parser_class():
    ns = dict(json=json, re=re, logging=logging, logger=logging.getLogger('source-parser'),
              ABC=ABC, abstractmethod=abstractmethod, BaseModel=BaseModel, Allow=Allow,
              partial_json_parser=partial_json_parser, JSONDecodeError=json.JSONDecodeError,
              JSONDecoder=json.JSONDecoder, WHITESPACE=json.decoder.WHITESPACE,
              List=List, Optional=Optional)
    source_definitions('srt/function_call/core_types.py', ['ToolCallItem', 'StreamingParseResult'], ns)
    ns['ToolCallItem'].model_rebuild(_types_namespace=ns)
    ns['StreamingParseResult'].model_rebuild(_types_namespace=ns)
    source_definitions('srt/function_call/utils.py', ['_find_common_prefix', '_partial_json_loads'], ns)
    source_definitions('srt/function_call/base_format_detector.py', ['BaseFormatDetector'], ns)
    source_definitions('srt/function_call/deepseekv32_detector.py', ['DeepSeekV32Detector'], ns)
    source_definitions('srt/function_call/deepseekv4_detector.py', ['DeepSeekV4Detector'], ns)
    return ns['DeepSeekV4Detector']


class GrammarTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if os.environ.get('CUDA_VISIBLE_DEVICES') != '':
            raise RuntimeError('Run these tests with CUDA_VISIBLE_DEVICES empty')
        cls.info = xgr.TokenizerInfo([bytes([i]) for i in range(256)] + [b'<STOP>'],
                                    vocab_size=257, stop_token_ids=[256])
        cls.compiler = xgr.GrammarCompiler(cls.info, max_threads=1)
        cls.compiled = cls.compiler.compile_structural_tag(
            single_call_tag(TOOLS, parallel_tool_calls=False))
        cls.parser = parser_class()
        cls.tool_objects = [SimpleNamespace(function=SimpleNamespace(**t['function'])) for t in TOOLS]

    def matcher(self, tag=None):
        return xgr.GrammarMatcher(self.compiled if tag is None else self.compiler.compile_structural_tag(tag))

    def accepts(self, text, tag=None, chunks=None):
        m = self.matcher(tag)
        pieces = chunks if chunks is not None else [text]
        return all(m.accept_string(piece) for piece in pieces) and m.accept_token(256)

    def test_auto_natural_final_and_empty_no_call(self):
        self.assertTrue(self.accepts('Answer: Ada'))
        self.assertTrue(self.accepts(''))

    def test_wrapped_xml_json_and_zeroarg(self):
        for text in (block(invoke()), block(invoke(body='{"q":"Ada"}')),
                     block(invoke('noop', '')), block('<｜DSML｜invoke name="noop"/>\n')):
            with self.subTest(text=text):
                self.assertTrue(self.accepts(text))
                self.assertEqual(len(self.parser().detect_and_parse(text, self.tool_objects).calls), 1)

    def test_multiple_invokes_blocks_and_bare_stream_bypass_rejected(self):
        for text in (block(invoke(), invoke()), block(invoke()) + block(invoke()),
                     invoke() + invoke(), invoke() + block(invoke()), block(invoke()) + invoke()):
            with self.subTest(text=text):
                self.assertFalse(self.accepts(text))

    def test_non_strict_does_not_enforce_parameter_schema(self):
        for body in ('', '{"unknown":3}', '<｜DSML｜parameter name="unknown" string="false">3</｜DSML｜parameter>\n'):
            self.assertTrue(self.accepts(block(invoke(body=body))))
        strict = copy.deepcopy(TOOLS)
        strict[0]['function']['strict'] = True
        tag = single_call_tag(strict, parallel_tool_calls=False)
        self.assertFalse(self.accepts(block(invoke(body='{"unknown":3}')), tag))
        self.assertFalse(self.accepts(block('<｜DSML｜invoke name="lookup"/>\n'), tag))

    def test_required_and_named_retain_semantics(self):
        required = single_call_tag(TOOLS, 'required', parallel_tool_calls=False)
        named = single_call_tag(TOOLS, {'type': 'function', 'function': {'name': 'noop'}},
                                parallel_tool_calls=False)
        for tag in (required, named):
            self.assertFalse(self.accepts('Answer: Ada', tag))
            self.assertTrue(self.accepts(block(invoke('noop', '')), tag))
            self.assertFalse(self.accepts(block(invoke('noop', ''), invoke('noop', '')), tag))
        self.assertFalse(self.accepts(block(invoke()), named))

    def test_scope_and_inputs_are_unchanged(self):
        original = copy.deepcopy(TOOLS)
        for flag in (True, None):
            self.assertIsNone(single_call_tag(TOOLS, parallel_tool_calls=flag))
        self.assertIsNone(single_call_tag([], parallel_tool_calls=False))
        self.assertIsNone(single_call_tag(TOOLS, 'none', parallel_tool_calls=False))
        a = single_call_tag(TOOLS, parallel_tool_calls=False)
        a.format.tags.clear()
        self.assertEqual(len(single_call_tag(TOOLS, parallel_tool_calls=False).format.tags), 1)
        self.assertEqual(TOOLS, original)

    def test_streaming_chunks_and_actual_source_parser(self):
        text = block(invoke())
        for size in (1, 2, 7, 31, len(text)):
            chunks = [text[i:i+size] for i in range(0, len(text), size)]
            self.assertTrue(self.accepts(text, chunks=chunks))
            parser = self.parser()
            ids = set()
            for chunk in chunks:
                for call in parser.parse_streaming_increment(chunk, self.tool_objects).calls:
                    ids.add(call.tool_index)
            self.assertEqual(ids, {0})
        bare = invoke() + invoke()
        self.assertEqual(len(self.parser().detect_and_parse(bare, self.tool_objects).calls), 0)
        emitted = self.parser().parse_streaming_increment(bare, self.tool_objects).calls
        self.assertEqual({call.tool_index for call in emitted}, {0, 1})

    def test_reasoning_prefix_separate_from_suffix(self):
        tag = single_call_tag(TOOLS, parallel_tool_calls=False, thinking_mode=True)
        self.assertTrue(self.accepts('reason about two calls</think>' + block(invoke()), tag))
        self.assertFalse(self.accepts('reason</think>' + block(invoke(), invoke()), tag))
        self.assertFalse(self.accepts('</think>Answer: Ada'))

    def test_request_overlay_only_adds_response_format(self):
        source = {'model': 'unfamiliar-model-id', 'messages': [{'role': 'system', 'content': 'one call'}],
                  'tools': copy.deepcopy(TOOLS), 'tool_choice': 'auto', 'parallel_tool_calls': False,
                  'reasoning_effort': 'max', 'max_tokens': 32768, 'temperature': 1.0}
        original = copy.deepcopy(source)
        with self.assertRaises(UnsupportedParserAlignment):
            prepare_request_overlay(source, **CAPS)
        with self.assertRaises(UnsupportedParserAlignment):
            public_install(object)
        result = prepare_candidate(source, **CAPS)
        self.assertEqual(source, original)
        self.assertEqual({k:v for k,v in result.items() if k != 'response_format'}, source)
        self.assertTrue(self.accepts(block(invoke()), xgr.StructuralTag.model_validate(result['response_format'])))
        result['messages'][0]['content'] = 'changed'
        self.assertEqual(source, original)
        for update in ({'response_format': {'type': 'json_object'}}, {'tool_choice': 'required'},
                       {'tools': [{'type':'function','function':{'name':'noop','strict':True}}]}):
            with self.assertRaises(ValueError):
                prepare_candidate({**source, **update}, **CAPS)
        with self.assertRaises(ValueError):
            prepare_candidate(source, **{**CAPS, 'tool_call_parser': 'other'})
        for update in ({'parallel_tool_calls':True}, {'parallel_tool_calls':None},
                       {'tool_choice':'none'}, {'tools':[]}):
            p = {**source, **update}
            self.assertEqual(prepare_request_overlay(p, **CAPS), p)

    def test_explicit_hook_restores_and_preserves_passthrough(self):
        class SelectedFormat:
            def get_structural_tag_name(self): return 'deepseek_v4'
            def get_auto_tool_call_structural_tag(self, **kwargs): return ('original-auto', kwargs)
            def get_structural_tag(self, **kwargs): return ('original-tag', kwargs)
        original = SelectedFormat.get_auto_tool_call_structural_tag
        restore = install_on_detector_class(SelectedFormat)
        try:
            self.assertIsInstance(SelectedFormat().get_auto_tool_call_structural_tag(
                tools=TOOLS, parallel_tool_calls=False), xgr.StructuralTag)
            self.assertEqual(SelectedFormat().get_auto_tool_call_structural_tag(
                tools=TOOLS, parallel_tool_calls=True)[0], 'original-auto')
            with self.assertRaises(RuntimeError): install_on_detector_class(SelectedFormat)
        finally:
            restore()
        self.assertIs(SelectedFormat.get_auto_tool_call_structural_tag, original)

    def test_cpu_no_cuda_initialization(self):
        self.assertFalse(torch.cuda.is_initialized())

    def test_nested_reserved_markup_parser_cardinality(self):
        nested = INVOKE_END + '\n' + invoke('noop', '')
        text = block(invoke(body='<｜DSML｜parameter name="q" string="true">'
                            + nested + '</｜DSML｜parameter>\n'))
        accepted = self.accepts(text)
        count = len(self.parser().detect_and_parse(text, self.tool_objects).calls)
        self.assertFalse(accepted and count > 1,
                         'UNSAFE: one grammar invoke produced multiple parser calls')


class RealTokenizerTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if os.environ.get('CUDA_VISIBLE_DEVICES') != '':
            raise RuntimeError('Run these tests with CUDA_VISIBLE_DEVICES empty')
        from transformers import AutoTokenizer
        cls.tokenizer = AutoTokenizer.from_pretrained(CHECKPOINT, local_files_only=True,
                                                      trust_remote_code=False)
        info = xgr.TokenizerInfo.from_huggingface(cls.tokenizer)
        cls.compiler = xgr.GrammarCompiler(info, max_threads=1)
        cls.compiled = cls.compiler.compile_structural_tag(single_call_tag(TOOLS, parallel_tool_calls=False))

    def tokens(self, text):
        return self.tokenizer.encode(text, add_special_tokens=False)

    def test_actual_token_ids_and_stop_boundary(self):
        for text in ('Answer: Ada', block(invoke()), block(invoke(body='{"q":"Ada"}')),
                     block('<｜DSML｜invoke name="noop"/>\n')):
            matcher = xgr.GrammarMatcher(self.compiled)
            self.assertTrue(all(matcher.accept_token(t) for t in self.tokens(text)))
            self.assertTrue(matcher.accept_token(self.tokenizer.eos_token_id))
        for text in (block(invoke(), invoke()), block(invoke()) + block(invoke()), invoke() + invoke()):
            matcher = xgr.GrammarMatcher(self.compiled)
            self.assertFalse(all(matcher.accept_token(t) for t in self.tokens(text)))

    def test_original_reasoner_boundary_and_rollback_with_actual_matcher(self):
        ns = {}
        source_definitions('srt/utils/token_sequence_matcher.py', ['TokenSequenceMatcher'], ns)
        source_definitions('srt/constrained/base_grammar_backend.py', ['BaseGrammarObject'], ns)
        source_definitions('srt/constrained/reasoner_grammar_backend.py', ['ReasonerGrammarObject'], ns)
        matcher = xgr.GrammarMatcher(self.compiled)

        class Bridge:
            def __init__(self): self.accepted = []
            def accept_token(self, token):
                if not matcher.accept_token(token): raise ValueError('Token rejected by actual XGrammar')
                self.accepted.append(token)
            def rollback(self, count):
                matcher.rollback(count)
                del self.accepted[-count:]
            def is_terminated(self): return matcher.is_terminated()

        bridge = Bridge()
        end_ids = self.tokens('</think>')
        self.assertEqual(end_ids, [128822])
        wrapper = ns['ReasonerGrammarObject'](bridge, end_ids)
        wrapper.maybe_init_reasoning(True)
        for token in self.tokens('Plan without executing tools.') + end_ids:
            wrapper.accept_token(token)
        self.assertEqual(bridge.accepted, [])
        self.assertTrue(wrapper._is_generation())
        body_ids = self.tokens(block(invoke()))
        for token in body_ids: wrapper.accept_token(token)
        self.assertEqual(bridge.accepted, body_ids)
        wrapper.rollback(len(body_ids) + len(end_ids))
        self.assertEqual(bridge.accepted, [])
        self.assertTrue(wrapper._is_thinking())
        for token in end_ids + self.tokens('Answer: Ada'):
            wrapper.accept_token(token)
        self.assertEqual(bridge.accepted, self.tokens('Answer: Ada'))
        self.assertFalse(torch.cuda.is_initialized())


if __name__ == '__main__':
    unittest.main(verbosity=2)
