# Single-call adapter：CPU 原型，尚不允许部署

状态：**BLOCKED — grammar/parser 边界仍有可复现漏洞**。未编辑冻结
SGLang、未安装 hook、未启动服务、未重启 GPU、未调用模型或实验工具。
公共 `prepare_request_overlay()` 和 `install_on_detector_class()` 已 fail
closed：需要干预时抛出 `UnsupportedParserAlignment`，没有可部署输出。
未验证 candidate factory/hook/overlay 只保留为 `_...candidate...` 私有
测试接口，用于复现失败，不能当作绕过公共保护的部署入口。

## 内容

- `adapter.py`：fresh XGrammar tag factory；首选只新增 `response_format` 的
  request overlay；另保留显式进程内 detector hook。导入无安装行为。
- `test_adapter.py`：真实 XGrammar matcher、实际本地 tokenizer、冻结原类
  parser/reasoner 的 AST 单元测试。并非完整 SGLang HTTP/GPU 集成验证。

应用条件只依赖明确选中的 native parser/encoding/reasoner 能力和
`parallel_tool_calls=False`，不依赖模型名。overlay 目前仅覆盖
`auto` + non-strict，拒绝已有 response_format、strict、required/named
冲突；`parallel=True/None`、no-tools、none 保持原请求不变。**none 未被
本原型修复或硬约束**。默认请求、原历史、参数 strictness、effort、输出
上限、预算、评分和生成出的调用都不会被删除或重写。

## 已验证与阻塞

14 项测试中，13 项通过，1 项失败；详见 `CHECKS.json`。
该完整测试记录绑定加 fail-closed 保护前的源码 SHA；加保护后只检查公共
入口的拒绝/透传，未重复全套 tokenizer/grammar 检查，也不宣称新增通过。

通过的范围包括自然答案/零调用、一个 wrapped XML/direct-JSON 调用、
零参长格式和 self-closing 格式、拒绝两个普通 invoke/两个 block、拒绝
裸 invoke 流式绕过、非 strict 参数不被提升为 strict、required/named
factory 语义、独立请求副本、hook 恢复、真实 tokenizer tokens/stop、
原 ReasonerGrammarObject 的 `</think>` 边界及跨边界 rollback。

**失败用例不能删除或当作通过**：一个 XML string 参数内部包含字面
`</｜DSML｜invoke>` 和新的 `<｜DSML｜invoke ...>` 时，XGrammar 可以将其
视为第一个调用的字符串内容，冻结正则 parser 却将其拆成多个调用。
因此“内外层 stop_after_first=True”仍不足以保证最终 parser 至多输出
一个调用。direct-JSON 中未转义的保留结束标记也需要后续逐字段保真复核。
当前 Audit/NAS 工具往往使用 enum/int 参数，但 non-strict 请求仍允许
模型产生 schema 外参数，不能据此忽略字符串边界反例。改开 strict 会
改变允许的输出空间，不是已验证的仅单调用兼容修复。

本原型还明确收窄为完整 wrapped block；不支持 parser 流式路径接受的
裸 invoke。direct JSON 根部限 object（native arguments 的契约），不
把数组或标量悄悄解析为 `{}`。XML 内部保留标记的安全处理尚未解决。
不能据此声称这是“只有调用数变化、所有原生形式完全等价”的修复。

## 重跑 CPU 检查

从 workspace 根目录，使用冻结解释器；该命令故意保留上述失败回归：

```bash
source deepseek_flash_eval_20260911/runtime/runtime-env.sh
CUDA_VISIBLE_DEVICES='' OMP_NUM_THREADS=1 \
deepseek_flash_eval_20260911/runtime/.venv/bin/python -B \
eval_diagnostics_20260912/serving_audit/single_call_adapter/test_adapter.py
```

测试不读取模型权重，只加载本地 tokenizer metadata。
实际 tokenizer 的 `</think>` ID 为 128822；当 SGLang reasoning parser
负责该边界时，overlay 仅约束后续 suffix，不二次强制思考段。

进程内 hook 只是备选原型：调用者必须将其安装在构造约束的进程内；
没有实现 spawn、Ray、gRPC、Rust 或多 tokenizer worker 的自动传播。
现阶段不得把 hook 或 overlay 投入正式实验，更不能改写旧实验结果。
