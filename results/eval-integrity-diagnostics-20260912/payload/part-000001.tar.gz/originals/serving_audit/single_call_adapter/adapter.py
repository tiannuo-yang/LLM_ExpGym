"""CPU-review prototype: opt-in single-call grammar for a selected DSML adapter.

Importing this module does not install anything or launch a server. Frozen
packages, prompts, histories, generated calls and experimental settings are not
modified. This is NOT deployment clearance; see README.zh.md.
"""
from copy import deepcopy

FORMAT = "deepseek_v4"
BOT = "<｜DSML｜tool_calls>"
EOT = "</｜DSML｜tool_calls>"
INVOKE = "<｜DSML｜invoke"
INVOKE_END = "</｜DSML｜invoke>"


class UnsupportedParserAlignment(ValueError):
    """The candidate grammar does not enforce the frozen parser's cardinality."""


def prepare_request_overlay(payload, *, tool_call_parser, chat_encoding_spec,
                            reasoning_parser, structural_tag_supported=False):
    """Fail closed: no active request overlay has deployment clearance.

    Inapplicable requests remain unmodified copies. A request needing the
    candidate intervention is rejected before constructing a deployable payload.
    """
    result = deepcopy(payload)
    if (result.get("parallel_tool_calls") is False and result.get("tools")
            and result.get("tool_choice", "auto") != "none"):
        raise UnsupportedParserAlignment(
            "Single-call prototype blocked: reserved DSML markup inside arguments "
            "can make the frozen parser return multiple calls; no overlay is deployable")
    return result


def _prepare_request_overlay_candidate_for_tests(payload, *, tool_call_parser, chat_encoding_spec,
                                                reasoning_parser, structural_tag_supported=False):
    """Fresh, opt-in request overlay; never sends requests or changes a runtime.

    This narrow path is for auto/non-strict requests using the reviewed DSV4
    native parser and SGLang reasoner-owned boundary. It refuses collisions with
    caller response formats or existing strict/required tool constraints.
    The untouched original payload remains evidence of the pre-overlay request.
    """
    result = deepcopy(payload)
    if (result.get("parallel_tool_calls") is not False or not result.get("tools")
            or result.get("tool_choice", "auto") == "none"):
        return result
    if not (tool_call_parser == "deepseekv4" and chat_encoding_spec == "dsv4"
            and reasoning_parser == "deepseek-v4" and structural_tag_supported is True):
        raise ValueError("Explicit reviewed DSV4 structural-tag/reasoner capability required")
    if result.get("tool_choice", "auto") != "auto":
        raise ValueError("Request overlay is scoped to auto; required/named need separate integration")
    if any(tool["function"].get("strict") is True for tool in result["tools"]):
        raise ValueError("Request overlay cannot silently replace strict tool constraints")
    if result.get("response_format") is not None:
        raise ValueError("Request already specifies response_format; refusing replacement")
    tag = _single_call_tag_candidate(result["tools"], "auto", parallel_tool_calls=False,
                                     thinking_mode=False)
    result["response_format"] = tag.model_dump(by_alias=True)
    return result


def _plain(value):
    return value.model_dump() if hasattr(value, "model_dump") else deepcopy(value)


def _single_call_tag_candidate(tools, tool_choice="auto", *, parallel_tool_calls=True,
                               thinking_mode=False):
    """Return a fresh tag only for an explicit false, nonempty tool request.

    None means no intervention, not a claim that tools are disallowed. In
    particular tool_choice=none remains owned by the serving implementation.
    Natural-language answers are allowed for auto. Required/named keep their
    original forced-call meaning. Schema strictness is not turned on implicitly.
    Only complete wrapped DSML blocks are accepted; bare invokes outside a block
    are excluded because the streaming parser can otherwise parse them as calls.
    """
    if parallel_tool_calls is not False or not tools or tool_choice == "none":
        return None
    import jsonschema
    from xgrammar import get_model_structural_tag
    from xgrammar.structural_tag import (
        ConstStringFormat, JSONSchemaFormat, OrFormat, SequenceFormat,
        StructuralTag, TagFormat, TagsWithSeparatorFormat, TriggeredTagsFormat,
    )

    definitions = [_plain(tool) for tool in tools]
    choice = _plain(tool_choice)
    # Pydantic's unset strict is None. This adapter must not turn it into schema
    # enforcement merely by asking the native grammar factory for a tag.
    for tool in definitions:
        function = tool["function"]
        if function.get("strict") is not True:
            function["strict"] = False
    original = get_model_structural_tag(
        FORMAT, tools=definitions, tool_choice=choice, reasoning=thinking_mode,
    )
    tag = original.model_copy(deep=True)
    suffix = tag.format
    if thinking_mode:
        if not isinstance(suffix, SequenceFormat) or len(suffix.elements) != 2:
            raise ValueError("Unsupported reasoning structural-tag shape")
        suffix = suffix.elements[-1]

    # Retain the upstream per-tool XML schema, add its direct-JSON equivalent and
    # a self-closing form only when the selected schema accepts an empty object.
    def expand(invoke):
        if not isinstance(invoke, TagFormat) or not isinstance(invoke.content, JSONSchemaFormat):
            raise ValueError("Unsupported native invoke structural-tag shape")
        schema = deepcopy(invoke.content.json_schema)
        if invoke.content.style != "deepseek_xml":
            raise ValueError("Expected DeepSeek XML parameter grammar")
        content = OrFormat(elements=[
            invoke.content.model_copy(deep=True),
            JSONSchemaFormat(json_schema={"type": "object"} if schema is True else schema),
        ])
        expanded = [invoke.model_copy(update={"content": content}, deep=True)]
        if jsonschema.Draft202012Validator(schema).is_valid({}):
            prefix = invoke.begin
            if not isinstance(prefix, str) or not prefix.endswith('\">\n'):
                raise ValueError("Unsupported native invoke prefix")
            expanded.append(TagFormat(
                begin=prefix[:-2] + "/>\n", content=ConstStringFormat(value=""), end="",
            ))
        return expanded

    if isinstance(suffix, TriggeredTagsFormat):
        if suffix.triggers != [BOT] or len(suffix.tags) != 1:
            raise ValueError("Unsupported automatic-tool grammar")
        outer = suffix.tags[0]
        inner = outer.content
        if not isinstance(inner, TagsWithSeparatorFormat):
            raise ValueError("Unsupported native call-list grammar")
        inner.tags = [candidate for item in inner.tags for candidate in expand(item)]
        inner.stop_after_first = True
        suffix.stop_after_first = True
        suffix.excludes = list(dict.fromkeys([*suffix.excludes, INVOKE, INVOKE_END]))
    elif isinstance(suffix, SequenceFormat) and len(suffix.elements) == 3:
        middle = suffix.elements[1]
        if isinstance(middle, TagsWithSeparatorFormat):
            middle.tags = [candidate for item in middle.tags for candidate in expand(item)]
            middle.stop_after_first = True
        elif isinstance(middle, TagFormat):
            suffix.elements[1] = OrFormat(elements=expand(middle))
        else:
            raise ValueError("Unsupported required/named call grammar")
    else:
        raise ValueError("Unsupported DeepSeek V4 grammar; refusing partial patch")
    return StructuralTag.model_validate(tag.model_dump())


def install_on_detector_class(detector_class):
    """Fail closed; the process-local hook also lacks deployment clearance."""
    raise UnsupportedParserAlignment("Single-call prototype blocked; detector hook was not installed")


def _install_candidate_on_detector_class_for_tests(detector_class):
    """Explicit, process-local hook for a caller-selected native-format class.

    The caller must arrange installation in the process that builds constraints;
    this does not propagate to spawn/Ray/gRPC/Rust/multi-tokenizer workers.
    Returns a restoration callback; restoration refuses to overwrite new hooks.
    """
    if detector_class().get_structural_tag_name() != FORMAT:
        raise ValueError("This prototype only supports the selected deepseek_v4 format")
    if "_expgym_single_call_prototype" in detector_class.__dict__:
        raise RuntimeError("Prototype already installed on this detector class")
    old_auto = detector_class.get_auto_tool_call_structural_tag
    old_tag = detector_class.get_structural_tag
    own_auto = detector_class.__dict__.get("get_auto_tool_call_structural_tag")
    own_tag = detector_class.__dict__.get("get_structural_tag")

    def automatic(self, tools=None, thinking_mode=False, parallel_tool_calls=True):
        changed = _single_call_tag_candidate(tools, "auto", parallel_tool_calls=parallel_tool_calls,
                                             thinking_mode=thinking_mode)
        if changed is not None:
            return changed
        return old_auto(self, tools=tools, thinking_mode=thinking_mode,
                        parallel_tool_calls=parallel_tool_calls)

    def explicit(self, tools=None, tool_choice="auto", thinking_mode=False,
                 parallel_tool_calls=True):
        changed = _single_call_tag_candidate(tools, tool_choice, parallel_tool_calls=parallel_tool_calls,
                                             thinking_mode=thinking_mode)
        if changed is not None:
            return changed
        return old_tag(self, tools=tools, tool_choice=tool_choice, thinking_mode=thinking_mode,
                       parallel_tool_calls=parallel_tool_calls)

    detector_class.get_auto_tool_call_structural_tag = automatic
    detector_class.get_structural_tag = explicit
    detector_class._expgym_single_call_prototype = True

    def restore():
        if (detector_class.get_auto_tool_call_structural_tag is not automatic
                or detector_class.get_structural_tag is not explicit):
            raise RuntimeError("Detector changed after installation; refusing overwrite")
        for name, original in (("get_auto_tool_call_structural_tag", own_auto),
                               ("get_structural_tag", own_tag)):
            if original is None:
                delattr(detector_class, name)
            else:
                setattr(detector_class, name, original)
        delattr(detector_class, "_expgym_single_call_prototype")
    return restore
