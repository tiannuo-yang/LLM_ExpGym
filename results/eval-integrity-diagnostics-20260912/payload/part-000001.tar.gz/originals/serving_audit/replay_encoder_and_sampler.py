"""CPU-only, offline check of four frozen first requests and sampler reachability.

Uses the original runtime's pinned actual renderer, not a replacement template.
Never sends model requests, loads tensor weights, initializes CUDA, changes the
runtime, or reads an entire serving log. Output must be a new file in this folder.
"""
from __future__ import annotations

import argparse
import ast
import copy
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import sys


ROOT = Path("/lustrefs/users/chufan.shi/codex_space_tn")
OUT = ROOT / "eval_diagnostics_20260912/serving_audit"
RUNTIME = ROOT / "deepseek_flash_eval_20260911/runtime"
CHECKPOINT = Path("/lustrefs/users/runner/chufan.shi/tau_vision/ckpts/DeepSeek-V4-Flash-0731")
SITE = RUNTIME / ".venv/lib/python3.12/site-packages"
REPLAY = ROOT / "deepseek_flash_eval_20260911/study/replay_native_contract.py"
PINS = {
    REPLAY: "567ffe27bc970a49bc76ad896b9185883bf08c3a97f5bf2af557689d69b36c0a",
    RUNTIME / "versions.json": "806001e105b5f9a7f7e6035e4260401fc02a5a5b8f88549883aa74dbd3aa6472",
    ROOT / "eval_diagnostics_20260912/INPUTS.json": "b686460c88683a146cb0c280d3e654f8e4128e85a171e246953c1b0761b86610",
    SITE / "sglang/srt/layers/sampler.py": "6b727fcde1724924c71c1148d89005500195527e827fe7ec8d51eef43d92a762",
    ROOT / "portable_eval_20260908/serving/runtime_candidates/gumbel_midpoint_v1/.venv/lib/python3.12/site-packages/sglang/srt/layers/sampler.py": "4f8ce718c6bfedb3271900b3066f77ef2ba2d94551ef63bd3dba0f53b1c450e7",
}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def snippet(inputs, relative, first, last):
    path = SITE / relative
    raw = inputs.read(path, PINS.get(path))
    lines = raw.decode().splitlines()
    return {"path": str(path), "source_sha256": digest(raw),
            "first_line": first, "last_line": last,
            "text": "\n".join(lines[first - 1:last])}


def launch_args(rank):
    path = ROOT / f"deepseek_flash_eval_20260911/serving/launch02/replica{rank}-rank0.log"
    # Only inspect a bounded prefix, not token/throughput history.
    with path.open("rb") as handle:
        for lineno in range(1, 101):
            raw = handle.readline(131073)
            require(len(raw) <= 131072, "Unexpected oversized log line")
            if not raw:
                break
            if b"server_args=ServerArgs(" not in raw:
                continue
            line = raw.decode()
            keys = ("sampling_backend", "enable_deterministic_inference", "rl_on_policy_target")
            result = {}
            for key in keys:
                match = re.search(r"\b" + key + r"=([^,]+)", line)
                require(match is not None, f"Missing recorded setting {key}")
                result[key] = ast.literal_eval(match.group(1))
            require(result == {"sampling_backend": "flashinfer", "enable_deterministic_inference": False,
                               "rl_on_policy_target": None}, "Original sampling configuration changed")
            return {"path": str(path), "line": lineno, "line_utf8_sha256": digest(raw),
                    "settings": result, "hash_scope": "exact server_args log line only, not entire log"}
    raise ValueError(f"No original server_args in bounded log prefix: {path}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    target = args.output.absolute()
    require(target.parent.resolve() == OUT.resolve(), "Output must stay in serving_audit")
    require(not target.exists() and not target.is_symlink(), "Refusing to overwrite output")
    require(os.environ.get("CUDA_VISIBLE_DEVICES") == "", "Disable CUDA visibility first")
    require(os.environ.get("HF_HUB_OFFLINE") == "1" and os.environ.get("TRANSFORMERS_OFFLINE") == "1",
            "Source the frozen offline runtime environment first")
    sys.dont_write_bytecode = True
    original = REPLAY.read_bytes()
    require(digest(original) == PINS[REPLAY], "Original renderer helper changed")
    namespace = {"__name__": "frozen_renderer_helper", "__file__": str(REPLAY)}
    exec(compile(original, str(REPLAY), "exec"), namespace)
    inputs = namespace["Inputs"]()
    inputs.read(REPLAY, PINS[REPLAY])
    inputs.read(Path(__file__).resolve())
    for path, expected in PINS.items():
        inputs.read(path, expected)
    manifest = inputs.json(ROOT / "eval_diagnostics_20260912/INPUTS.json")
    require([c["case_id"] for c in manifest["cases"]] == [
        "audit_bad_first_1", "audit_bad_first_2", "audit_native_control", "search_native_control"],
        "Diagnostic input selection changed")
    renderer = namespace["Renderer"](inputs, str(CHECKPOINT), RUNTIME / "versions.json",
                                      PINS[RUNTIME / "versions.json"])
    cases = []
    for case in manifest["cases"]:
        record = inputs.json(case["original_path"], case["original_sha256"])
        replay = renderer.replay(record)
        payload = record["request_payload"]
        request = renderer.request_type(**copy.deepcopy(payload))
        require([m["role"] for m in payload["messages"]] == ["system", "user"], "Not a first request")
        require(payload["temperature"] == 1 and payload["top_p"] == .95 and
                payload["reasoning_effort"] == "max", "Original sampling or effort changed")
        text = [m.get("content", "") for m in payload["messages"]]
        markers = [token for token in renderer.tokenizer.all_special_tokens
                   if any(token in message for message in text)]
        cases.append({"case_id": case["case_id"], "original_path": case["original_path"],
                      "original_sha256": case["original_sha256"], "replay": replay,
                      "raw_message_special_tokens": markers,
                      "validated_thinking": request.chat_template_kwargs,
                      "request_seed": payload.get("seed"), "effective_sampling_seed": None,
                      "temperature": payload["temperature"], "top_p": payload["top_p"],
                      "tool_names": [t["function"]["name"] for t in payload["tools"]]})
    batch_path = SITE / "sglang/srt/sampling/sampling_batch_info.py"
    tree = ast.parse(inputs.read(batch_path))
    function = next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)
                    and n.name == "from_schedule_batch")
    assignment = next(n for n in function.body if isinstance(n, ast.Assign)
                      and any(isinstance(t, ast.Name) and t.id == "sampling_seed" for t in n.targets))
    require(isinstance(assignment.value, ast.IfExp) and
            isinstance(assignment.value.test, ast.Name) and assignment.value.test.id == "enable_deterministic"
            and isinstance(assignment.value.orelse, ast.Constant) and assignment.value.orelse.value is None,
            "Effective-seed conditional changed")
    source_evidence = [
        snippet(inputs, "sglang/srt/sampling/sampling_batch_info.py", 87, 133),
        snippet(inputs, "sglang/srt/layers/sampler.py", 25, 38),
        snippet(inputs, "sglang/srt/layers/sampler.py", 139, 147),
        snippet(inputs, "sglang/srt/layers/sampler.py", 246, 295),
        snippet(inputs, "sglang/srt/layers/sampler.py", 683, 743),
        snippet(inputs, "sglang/srt/entrypoints/openai/protocol.py", 936, 949),
        snippet(inputs, "sglang/srt/entrypoints/openai/protocol.py", 1027, 1033),
        snippet(inputs, "sglang/srt/entrypoints/openai/serving_chat.py", 1218, 1249),
        snippet(inputs, "sglang/srt/arg_groups/overrides.py", 1922, 1942),
        snippet(inputs, "flashinfer/sampling.py", 47, 63),
        snippet(inputs, "flashinfer/sampling.py", 409, 451),
        snippet(inputs, "flashinfer/sampling.py", 1582, 1594),
        snippet(inputs, "flashinfer/sampling.py", 1725, 1739),
    ]
    require(not renderer.torch.cuda.is_initialized() and not renderer.network_attempts,
            "Offline CPU-only constraint failed")
    result = {
        "schema": "deepseek_frozen_encoder_sampler_audit_v1",
        "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "status": "passed_cpu_only_not_model_or_gpu_validation",
        "checkpoint": str(CHECKPOINT), "effort_profile": renderer.profile,
        "tokenizer_class": type(renderer.tokenizer).__name__, "tokenizer_chat_template": renderer.tokenizer.chat_template,
        "cuda_initialized": False, "network_attempts": [], "cases": cases,
        "original_replica_sampling_settings": [launch_args(rank) for rank in range(4)],
        "sampler_findings": {
            "deep_midpoint_patch_present": False,
            "deep_sampler_sha256": PINS[SITE / "sglang/srt/layers/sampler.py"],
            "old_midpoint_sampler_sha256": "4f8ce718c6bfedb3271900b3066f77ef2ba2d94551ef63bd3dba0f53b1c450e7",
            "effective_seed_none_conditional_ast_checked": True,
            "seeded_murmur_gumbel_path_reachable_in_recorded_configuration": False,
            "actual_path": "top_p=.95 -> FlashInfer joint rejection sampling -> default device generator seed/offset",
            "same_request_seed_guarantees_identical_output": False,
            "endpoint_census_performed": False,
            "endpoint_census_not_performed_reason": "Request-seeded Murmur path is not executed in recorded configuration; hypothetical endpoints are not causal evidence.",
        },
        "source_evidence": source_evidence,
        "limitations": [
            "Four fixed first requests, not a corpus-wide replay or an actual new generation.",
            "Exact tokens match the checkpoint's official encoder, not an independently reproduced model implementation.",
            "Recorded server usage verifies token count; old raw pre-parser generated token IDs were not archived.",
            "This does not verify checkpoint tensor contents, GPU numerical correctness, runtime concurrency, or task capability.",
            "Static recorded-configuration reachability excludes this specific Murmur endpoint defect, not all sampling defects.",
            "No original artifacts or runtime files are modified; only this new output file is created.",
        ],
        "inputs": inputs.finish(),
    }
    serialized = json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    with target.open("x", encoding="utf-8") as handle:
        handle.write(serialized)
    print(json.dumps({"output": str(target), "sha256": digest(serialized.encode()),
                      "cases": len(cases), "status": result["status"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
