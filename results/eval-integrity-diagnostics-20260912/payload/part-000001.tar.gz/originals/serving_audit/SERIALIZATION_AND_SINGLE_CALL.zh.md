# Schema 顺序与单调用约束：独立复核及最小修复建议

分类：**Static/fake validation**。本目录只新增诊断证据和复现 helper；没有修改原始
checkpoint、runtime、框架、评分器或正在执行的 GPU 回放。遵循仓库 expgym-runner skill：
按显式协议/能力定位兼容问题，保留全部调用及失败，不因预期性能趋势修改验收标准。

## 一、已证实的两个不同问题

### 诊断 v1 的 JSON 排序改变了实际模型输入

`replay_first_requests.py:37–38,269–278` 将 `canonical(payload)` 用作 wire body，
`sort_keys=True` 会递归重排 schema 字段。原始客户端
`LLM_ExpGym-deepseek-flash-20260911/expgym/llm_clients.py:382–386` 则使用
`json.dumps(payload).encode('utf-8')`，保留字段插入顺序。

冻结 DSV4 encoder 的 `render_tools()` → `to_json()` 同样保留字段顺序，把 schema
写进模型提示词。因此对象相等或 canonical hash 相等不等于 token 输入相同。

| 固定输入 | 原始 prompt tokens | 诊断 v1 tokens | 实际 renderer 与新服务 usage 相等 |
|---|---:|---:|---|
| audit_bad_first_1 | 1974 | 1973 | 是 |
| audit_bad_first_2 | 2824 | 2823 | 是 |
| audit_native_control | 1860 | 1859 | 是 |
| search_native_control | 730 | 730 | 是 |

四条均完成 actual frozen renderer → 官方 checkpoint encoder 的逐 token 对照。
所有渲染文本差异只在 schema 键顺序；schema 前后其余 prompt 文本完全相同。
Search 虽然计数没变，文本和 token 序列 hash 也变了。不是日期、最大思考映射或 parser
改变导致的计数差异。诊断 v1 必须保留为“schema 顺序扰动回放”，不能作为严格同输入的
并发因果对照；观察到较好输出也不能证明并发是旧乱码根因。

机器可读证据：[SCHEMA_ORDER_AND_PARALLEL.v1.json](SCHEMA_ORDER_AND_PARALLEL.v1.json)。
使用新文件名复现，helper 拒绝覆盖已有文件：

```bash
source deepseek_flash_eval_20260911/runtime/runtime-env.sh
CUDA_VISIBLE_DEVICES='' deepseek_flash_eval_20260911/runtime/.venv/bin/python -B \
  eval_diagnostics_20260912/serving_audit/replay_schema_order.py \
  --output eval_diagnostics_20260912/serving_audit/SCHEMA_ORDER_AND_PARALLEL.recheck.json
```

诊断 v2 已另由主任务修订。独立检查实际 v2 `wire_body()` 后，四条 reconstructed wire
SHA 均等于先前独立 renderer 收据里的 `reconstructed_client_request_serialization_sha256`，
且 `one_request()` 将同一份 body 写入 dump 并发往服务。审核时 v2 源码 SHA 为
`6bcd154bc8d8e9e3304986a320e59794785efc2747c42567f9e504d9a726b499`。
这只通过了请求身份检查，不是新生成质量验收。

### 冻结 DSV4 serving 没有落实 parallel_tool_calls=False

服务源码共同根目录：
`deepseek_flash_eval_20260911/runtime/.venv/lib/python3.12/site-packages/sglang/srt/`。

1. `entrypoints/openai/serving_chat.py:1078–1081` 接收并转交 parallel 标志。
2. `function_call/function_call_parser.py:247–264` 在 auto/non-strict 时询问
   `get_auto_tool_call_structural_tag()`；DSV4 没有 override，base 实现返回 None。
3. `entrypoints/openai/serving_chat.py:1243–1249` 调用自定义 DSV4 encoder 时没有传 parallel
   标志。`encoding_dsv4.py:87–112` 无条件示范一个 block 内两个 invoke。
4. `function_call/base_format_detector.py:398–402` 明确说明通用 XGrammar 接口忽略 parallel
   参数，因此**单独启用 strict 也不是保证单调用的修复**。
5. `entrypoints/openai/serving_chat.py:1991–2023` 保留解析出的全部调用，没有单调用检查。

新 v1 回放第一组 Audit bad1 返回 4 calls、Audit control 返回 10 calls；这些请求都显式
parallel=false。能解析出合法 schema 不代表满足 ExpGym 的决策协议。

模型 reasoning 声称的“If you intend … independent calls … same block”并不存在于所查
冻结 runtime 或官方 0731 encoder 原文。不能把模型自身复述当成真实模板指令；实际证据
是无条件双 invoke 示例和没有落实的请求参数。

## 二、框架是否漏了单调用提示或错误反馈？没有

publication 和 frozen Deep 的 `tool_protocol.py`、`react_loop.py` 内容 hash 相同，见 JSON
中的 `framework_protocol_files_match`。

- `expgym/tool_protocol.py:414–420` 的统一 native 协议已经明确要求每轮最多一个函数调用，
  收到真实工具结果后再决定是否继续。
- `expgym/react_loop.py:191–194` 对 native 路径应用该协议。
- `react_loop.py:373–374` 对多调用整批拒绝，原因是只允许一个 native call。
- `react_loop.py:320–339` 为**每一个**被拒调用 ID 返回 tool feedback，明确写出
  `Protocol error: Exactly one native tool call is allowed per decision. No tool was executed.`
- 只进行预先配置、计入正常决策步数的有限协议修复；不是免费 HTTP 重采样。

因此不建议重复添加统一 system 指令。Audit task-owned 示例与实际决策命令混淆是另外一项
可以在任务源码修复的歧义，但不能替代 serving 参数契约，也不能解释所有乱码。

## 三、推荐最小方案与边界

**保留框架现有单调用决策单位、预算和评分语义；可选的新 serving adapter 按显式请求参数
实现，而不是按模型名称猜测。** 不改 frozen runtime，后续实现必须使用独立版本和新结果目录。

| 层级 | 建议 | 可以声称什么 |
|---|---|---|
| ExpGym 统一系统协议 | 不重复添加，保留完整调用、整批拒绝及逐 ID feedback | 已清楚表达并检验单调用要求 |
| DSV4 encoder adapter | 将显式 parallel 标志传入 renderer；false 使用单 invoke 示例及单调用说明，true/默认行为保持原样 | 消除模板冲突，仍然只是 prompt-only |
| 格式结构约束 | auto 允许普通答案或一个完整 native call，限制第二 invoke 和第二 tool_calls block | 通过 matcher/集成/真实 smoke 后才能标 enforced |
| 未安全实现约束 | 在 manifest 标 unsupported/prompt-only，并报告实际多调用率 | 不应声称支持严格单调用 |

提示词改变概率，不是形式约束；仅在 decoder 最后检查数量可以检测违约，但不能让已经
生成的违规多调用变成合规。框架现有整批拒绝是正确的防副作用边界，不是解决服务契约的方式。

### 本地依赖提供的可选结构约束落点（尚未实现）

已安装 XGrammar 的 `builtin_structural_tag.py:1674` 有 DSV4 auto 模板：外层
`TriggeredTagsFormat` 控制 tool_calls block，内层 `TagsWithSeparatorFormat` 控制 invoke。
`structural_tag.py` 中这两类都公开 `stop_after_first`，当前默认 false。
因此存在可测试的协议 adapter 设计：parallel=false 时，对**两层**单独限制；只限制
内层仍可能输出多个 block。auto 的 `at_least_one` 应保持 false，允许不调用工具直接回答。
这不是删除已生成调用，也不是为某个模型特制任意 token 黑名单。

必须保持 reasoning 边界由正确一层负责，不能误限制 chain of thought；不能把 auto 改为
required；不能把 non-strict 参数 schema 偷换成 strict。当前 XGrammar
`_get_function_parameters():385–400` 对 non-strict 工具返回 True，明确保留参数语法约束
而不强制完整 schema，任何 adapter 都应保持该行为。

这些 API 字段只说明存在候选实现接口，本审查**没有构造或验证**新 grammar，不保证与
实际 tokenizer、流式 parser、空参数调用及 reasoning backend 无冲突。如不能通过下述
有限验收，应保留 unsupported/prompt-only，不为得到预期结果强行部署。

审查的 XGrammar 源码 SHA：

```text
8a3be29074f8640718b16557c86222515c4ff9a93f86ac105633e775b0854bff  xgrammar/structural_tag.py
a7263451288a81b7f140354e126175924d3245531b4a462dd4f3f87bed408f14  xgrammar/builtin_structural_tag.py
```

## 四、最小验收建议

1. 序列化：真实 wire 字节、schema 嵌套键顺序、renderer token hash 与记录绑定；相同 token
   数不等于同输入。v1 保留，不改写成 v2。
2. Renderer：parallel=false/true/缺省分支明确；不更改 max effort、sampling、任务文本、历史。
   使用陌生模型 ID 验证行为由选定 adapter/请求字段决定。
3. CPU grammar/matcher：false 下普通答案、一个合法 call 可接受；同 block 两 invoke、
   两个 block 不可接受；true 下保留既有多调用能力；non-strict 参数语义保持不变。
4. Parser/history：非流式及分块 streaming、空参数工具、reasoning 分隔符、stop/length、
   forced final none；不可丢失原始调用、思考、ID、usage。none 禁止新的工具执行但保留历史。
5. 框架回归：整批拒绝、全部调用 ID 配对、零工具执行、明确 feedback、有限 repair 与预算
   一致；不执行第一条、不展开整批、不免费重采样。
6. 经主任务授权后代表性真实多轮 smoke：保留相同四输入/effort/采样及所有失败，报告协议
   合法率和多调用率，不只报告 schema_valid；全部必要实际路径通过后才扩大实验。

已有静态测试入口包括 `test_native_llm_clients.py`、`test_native_react_loop.py`、
`test_native_task_context.py`、`test_model_agnostic_regressions.py`。本次没有运行这些回归，
因为没有改动框架或 serving；执行了独立 CPU renderer 身份比较，不把它包装为模型验收。

上述两个缺口分别影响诊断输入身份和部分 native 协议适配。目前都不足以证明历史 Deep
所有缺答/乱码、PoolAct 负提升均由同一原因造成；旧数据及不利观察继续保留。
