# v1 首请求回放的 runner contract 独立复核

结论：`baseline-tp8-c1` 的 8 个 HTTP 200 回复全部包含 schema 合法工具调用，但只有 **3 / 8** 可以进入原 runner 的工具执行；其余 **5 / 8** 因单轮多调用被明确拒绝。不能把 v1 的 `protocol_shape_usable=true` 解释为 runner 接受。

| 固定案例 | duplicate 1 调用数 / 决策 | duplicate 2 调用数 / 决策 | 人工可读性 |
|---|---|---|---|
| audit_bad_first_1 | 4 / 拒绝 | 8 / 拒绝 | 两次均 coherent |
| audit_bad_first_2 | 1 / 接受 | 4 / 拒绝 | 两次均 coherent |
| audit_native_control | 10 / 拒绝 | 8 / 拒绝 | 两次均 coherent |
| search_native_control | 1 / 接受 | 1 / 接受 | 两次均 coherent |

所有原始调用都通过 frozen client envelope 解码、finish_reason 为 `tool_calls`，各调用参数通过对应请求 schema。原 native runner 对多调用整批拒绝，逐一配对 tool error 消息，**不会只执行第一个**。一个 Audit 回复有非空说明文字和 8 个工具调用；工具调用分支优先，仍被拒绝，而不是当作最终答案。

复核方法：读取原 `response.body.bin`，验证 SHA；调用冻结仓库 `OpenAICompatibleLLM._decode_response`，再将解码结果交给实际 `run_react_loop`，仅运行一个 CPU 决策。工具替换为保留原 schema 的惰性 spy；在 forced-final 请求之前主动停止，没有模型、网络、真实环境工具、评分器或 gold 访问。接受的 3 条各执行 1 次 spy，拒绝的 5 条执行 0 次且分别产生 4、8、4、10、8 条配对拒绝消息。

人工阅读完整 `reasoning_content` 与 `content` 后，8 条均标为 `coherent`：Audit 有连贯的文档—假设分析与反馈计划，虽重复、犹豫且可能有错误；Search 有连贯的关系链拆解与搜索计划。这里不评价答案正确性，也不是自动可读性分数；未保存或引用长篇 reasoning。

部分模型 reasoning 声称指令鼓励批量独立调用，**这不是输入里确有该指令的证据**，本复核不推断其来源。对 template 的任何判断须另外检查实际渲染输入。

该 v1 回放不是历史请求的严格等价重放：helper 对 JSON 递归 `sort_keys=True`，改变 schema 键顺序；此顺序可能进入 DeepSeek 渲染文本。不能据这些首请求声称原正式实验已恢复正常、归因原始乱码，或确认完整多轮任务表现。

原 v1 helper、INPUTS、run 输出、历史 dump 均未改动。新增 sidecar 仅是独立分类，不替换原统计。

产物：

- [classification.csv](classification.csv)：逐条原 dump / v1 回复 SHA、工具数量、runner 接受性、人工标签、finish / usage。
- [classification.json](classification.json)：输入文件 SHA / 大小、源码 SHA 与行号、每条 CPU runner probe 证据。
- [classify.py](classify.py)：CPU 可重复复核；输出投影由 apply_patch 新建。

验证命令：

```bash
/lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python -B eval_diagnostics_20260912/v1_contract_review/classify.py --check
```

这些是 8 个被预选的首请求，不是总体故障率估计，也不是正式效果实验。
