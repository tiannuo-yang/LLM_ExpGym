#!/usr/bin/env python3
"""Offline, read-only classification of eight frozen v1 responses.

Print artifact JSON to stdout; --check compares existing sidecars. No network,
model, evaluator, real tool, gold annotation, or frozen-artifact writes.
"""
from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import io
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
DIAG = OUT.parent
REPO = ROOT / "LLM_ExpGym-deepseek-flash-20260911"
sys.path.insert(0, str(REPO))
from expgym.llm_clients import OpenAICompatibleLLM
from expgym.react_loop import LLMOutput, run_react_loop


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    raw = path.read_bytes()
    return {"path": str(path.relative_to(ROOT)), "bytes": len(raw), "sha256": sha(raw)}


def schema_valid(value, schema):
    kinds = {"object": lambda x: isinstance(x, dict), "array": lambda x: isinstance(x, list),
             "string": lambda x: isinstance(x, str), "integer": lambda x: type(x) is int,
             "number": lambda x: type(x) in (int, float), "boolean": lambda x: type(x) is bool,
             "null": lambda x: x is None}
    if schema.get("type") and not kinds[schema["type"]](value):
        return False
    if "enum" in schema and value not in schema["enum"]:
        return False
    if isinstance(value, dict):
        if not set(schema.get("required", [])).issubset(value):
            return False
        properties = schema.get("properties", {})
        if schema.get("additionalProperties") is False and set(value) - set(properties):
            return False
        if any(not schema_valid(item, properties[key]) for key, item in value.items() if key in properties):
            return False
    if isinstance(value, list) and "items" in schema:
        return all(schema_valid(item, schema["items"]) for item in value)
    return True


class StopBeforeForcedFinal(Exception):
    pass


def actual_runner_probe(data, text, calls, assistant, finish, payload):
    """Replay delivered first decision into the unmodified frozen CPU runner.

    Tools are spies returning inert observations, with original schema metadata.
    Stop before the forced-final request; never fabricate a model final answer.
    """
    executed, followup = [], []

    class ReplayOnly:
        supports_native_tools = True
        count = 0

        def generate(self, messages, *, tools, tool_choice):
            self.count += 1
            if self.count == 1:
                assert tool_choice == "auto"
                return LLMOutput(text=text, tool_calls=copy.deepcopy(calls),
                                 assistant_message=copy.deepcopy(assistant), finish_reason=finish,
                                 request_attempts=0)
            assert self.count == 2 and tool_choice == "none"
            followup.extend(copy.deepcopy(messages))
            raise StopBeforeForcedFinal()

    tools = {}
    for definition in payload["tools"]:
        name = definition["function"]["name"]

        def spy(argument, name=name):
            executed.append(name)
            return ("offline contract probe; not task feedback", 0.0)

        spy.__expgym_tool_schema__ = copy.deepcopy(definition["function"])
        tools[name] = spy
    try:
        run_react_loop(ReplayOnly(), tools, max_steps=1, max_protocol_retries=0,
                       tool_protocol="native", context="Offline first-decision contract probe")
    except StopBeforeForcedFinal:
        pass
    else:
        raise AssertionError("Expected native first decision followed by forced-final boundary")
    notices = [message["content"] for message in followup
               if message.get("role") == "tool" and message.get("content", "").startswith("Protocol error:")]
    return {"first_decision_fake_tool_executions": len(executed),
            "paired_protocol_rejections": len(notices),
            "rejection_reason": notices[0] if notices else None,
            "stopped_before_forced_final": True}


def build():
    manifest = json.loads((DIAG / "INPUTS.json").read_text())
    cases = {case["case_id"]: case for case in manifest["cases"]}
    source_ranges = {"expgym/llm_clients.py": [[410, 452], [516, 571]],
                     "expgym/react_loop.py": [[322, 345], [368, 416]],
                     "expgym/tool_protocol.py": [[412, 420]]}
    sources = []
    for relative, ranges in source_ranges.items():
        item = identity(REPO / relative)
        item["relevant_line_ranges"] = ranges
        sources.append(item)
    inputs, rows, probes = [], [], []
    for record_path in sorted((DIAG / "baseline-tp8-c1").glob("*/record.json")):
        folder = record_path.parent
        record = json.loads(record_path.read_text())
        response_path = folder / "response.body.bin"
        raw = response_path.read_bytes()
        assert record["state"] == "delivered" and record["http_status"] == 200
        assert sha(raw) == record["response_body_sha256"]
        payload = json.loads((folder / "request.json").read_text())
        # request.json is a payload snapshot, not proof of original wire ordering.
        if "request_payload" in payload:
            payload = payload["request_payload"]
        assert payload["tool_choice"] == "auto" and payload["parallel_tool_calls"] is False
        data, text, calls, assistant, finish = OpenAICompatibleLLM._decode_response(raw)
        assert calls and finish == "tool_calls"
        schemas = {t["function"]["name"]: t["function"]["parameters"] for t in payload["tools"]}
        valid = sum(call["function"]["name"] in schemas and
                    schema_valid(json.loads(call["function"]["arguments"]), schemas[call["function"]["name"]])
                    for call in calls)
        assert valid == record["shape"]["valid_tool_calls"] == len(calls)
        probe = actual_runner_probe(data, text, calls, assistant, finish, payload)
        accepted = len(calls) == 1
        assert probe["first_decision_fake_tool_executions"] == int(accepted)
        assert probe["paired_protocol_rejections"] == (0 if accepted else len(calls))
        usage = data["usage"]
        row = {"case_id": record["case_id"], "duplicate": record["duplicate"],
               "original_request_id": record["original_request_id"],
               "original_dump_sha256": cases[record["case_id"]]["original_sha256"],
               "v1_response_body_sha256": sha(raw), "v1_response_body_bytes": len(raw),
               "raw_tool_calls": len(assistant["tool_calls"]), "schema_valid_tool_calls": valid,
               "client_transport_accepted": True, "runner_first_decision_accepted": accepted,
               "runner_classification": "accept_one_native_tool" if accepted else "reject_multiple_native_tools",
               "v1_schema_only_usable": record["shape"]["protocol_shape_usable"],
               "manual_readability_label": "coherent",
               "manual_readability_basis": ("Connected document/hypothesis analysis and explicit feedback plan; repetitive/ambivalent in places, not obvious garbling."
                   if record["case_id"].startswith("audit") else
                   "Connected relationship-chain decomposition leading to relevant first search."),
               "finish_reason": finish, "prompt_tokens": usage["prompt_tokens"],
               "completion_tokens": usage["completion_tokens"], "reasoning_tokens": usage["reasoning_tokens"],
               "total_tokens": usage["total_tokens"], "wall_seconds": record["wall_seconds"]}
        rows.append(row)
        probes.append({"case_id": row["case_id"], "duplicate": row["duplicate"], **probe})
        inputs.extend(identity(path) for path in (record_path, response_path, folder / "request.json"))
    assert len(rows) == 8 and sum(r["runner_first_decision_accepted"] for r in rows) == 3
    csvout = io.StringIO(newline="")
    writer = csv.DictWriter(csvout, fieldnames=list(rows[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    result = {"schema": "expgym.offline-v1-contract-review.v1", "scope": "baseline-tp8-c1, eight frozen delivered first responses only",
              "no_network_model_real_tools_gold_or_evaluator": True, "original_artifacts_unchanged": True,
              "schema_valid_responses": 8, "runner_accepted_first_decisions": 3,
              "runner_rejected_multiple_calls": 5, "fresh_model_calls": 0,
              "method": "Frozen client decoder plus actual frozen one-step native runner using inert tool spies; stop before forced final",
              "manual_readability_method": "Reviewer read full reasoning_content and content privately, then recorded qualitative labels without quoting reasoning. Not an automated readability score or correctness assessment.",
              "model_instruction_claim_not_input_evidence": "Some responses claim that instructions encourage batching independent tools. This is model-generated reasoning, NOT evidence that such text was present in the input or template. No instruction-origin inference is made here.",
              "not_historical_exact_replay": "v1 recursively sort_keys canonicalized request JSON, altering function schema key order visible to DeepSeek rendering; do not attribute original-run differences to serving recovery",
              "sources": sources, "manifest": identity(DIAG / "INPUTS.json"),
              "v1_helper": identity(DIAG / "replay_first_requests.py"), "inputs": inputs,
              "rows": rows, "cpu_runner_probes": probes}
    return {"classification.csv": csvout.getvalue(), "classification.json": json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n"}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    outputs = build()
    if args.check:
        for name, text in outputs.items():
            assert (OUT / name).read_bytes() == text.encode(), name
        print("PASS: eight raw SHA identities; three accepted / five rejected; frozen CPU runner confirmation; deterministic sidecars")
    else:
        print(json.dumps(outputs, ensure_ascii=False))
