"""Read-only source/raw inspection plus toy CPU replay of legacy final selection.

Writes only this diagnostic directory. Does not instantiate a model client,
load benchmark data, run a scoring backend, or change any saved experiment.
"""
import hashlib
import json
from pathlib import Path
import sys


ROOT = Path("/lustrefs/users/chufan.shi/codex_space_tn")
SOURCE = ROOT / "LLM_ExpGym-eval-fixes-20260912"
OUT = ROOT / "eval_diagnostics_20260912/shared_final_audit"
POOL = ROOT / (
    "eval_diagnostics_20260912/graph_smoke/streamoff/cohort_v1/runs/"
    "deepseek-v4-flash-0731-graph-v4-20260912-nas101_a-streamoff-poolact/result/poolact"
)
sys.path.insert(0, str(SOURCE))

from expgym.extras.parallel_cache import _parse_evaluate_config
from expgym.poolact import PoolActCoordinator
from expgym.react_loop import LLMOutput, _extract_answer, run_react_loop
from scripts.run_paper_sweep import _score_result


def canonical(value):
    return json.dumps(json.loads(value), sort_keys=True, separators=(",", ":"))


def pin(path):
    content = path.read_bytes()
    return {"path": str(path), "size_bytes": len(content),
            "sha256": hashlib.sha256(content).hexdigest()}


class FixedReplies:
    def __init__(self, replies):
        self.replies = iter(replies)
        self.inputs = []

    def generate(self, messages):
        self.inputs.append([dict(message) for message in messages])
        return LLMOutput(next(self.replies))


def toy_case(*, policy="legacy", shared_score=0.9, shared_completion=0.0,
             cache_fetch=False, own_evaluation=True, final_x=2):
    coordinator = PoolActCoordinator(2)
    own_key, shared_key = '{"x":1}', '{"x":2}'
    coordinator.graph.record_evaluate_config(
        1, shared_key, '{x:2}', shared_score, 1.0,
        completion_time=shared_completion,
    )
    coordinator.cache.put("evaluate_config", shared_key, (shared_score, 1.0),
                          completion_time=shared_completion)
    online_calls, offline_calls = [], []

    def online_tool(payload):
        online_calls.append(canonical(payload))
        return (0.8 if json.loads(payload)["x"] == 1 else shared_score, 2.0)

    def offline_tool(payload):
        # Explicit toy table: no HPO/NAS evaluator or network is used.
        offline_calls.append(canonical(payload))
        return ({1: 0.8, 2: shared_score, 3: 0.95}[json.loads(payload)["x"]], 2.0)

    runtime = coordinator.bind_tools({"evaluate_config": online_tool}, 0, time_budget=10.0)
    replies = []
    if own_evaluation:
        replies.append("Action: evaluate_config " + own_key)
    if cache_fetch:
        replies.append("Action: evaluate_config " + shared_key)
    requested = json.dumps({"x": final_x}, separators=(",", ":"))
    replies.append("Answer: " + requested)
    llm = FixedReplies(replies)
    result = run_react_loop(
        llm=llm, tools=runtime.tools, context="Tune x.", time_budget=10.0,
        max_steps=4, max_evals=4, tuning_final_policy=policy,
        observation_augmenter=runtime.observation_augmenter,
        agent_clock=runtime.clock, pre_tool_hook=runtime.pre_tool_hook,
        llm_lock=runtime.reasoning_lock,
    )
    before_score = result["answer_perf"]
    check = _score_result(result, {"evaluate_config": offline_tool}, None)
    assert check["ok"] is True
    final_request = "\n".join(message["content"] for message in llm.inputs[-1])
    return {
        "policy": policy, "requested_final": requested,
        "saved_final": result["answer"], "score_before_offline_validation": before_score,
        "saved_score": result["answer_perf"], "answer_source": result["answer_source"],
        "answer_score_source": result["answer_score_source"],
        "peer_observation_in_final_request": ("{{x:2}} -> {:.6f}".format(shared_score) in final_request),
        "online_direct_tool_calls": online_calls, "offline_toy_validation_calls": offline_calls,
        "evaluations": result["evaluations"], "simulated_cost": result["total_overhead"],
        "cache_stats": coordinator.cache.stats(), "score_check": check,
    }


def actual_evidence():
    paths = [POOL / "agents" / "agent_0.json", POOL / "agents" / "agent_1.json", POOL / "result.json"]
    first, second, pool = [json.loads(path.read_text()) for path in paths]
    final_index = max(i for i, message in enumerate(first["messages"])
                      if message.get("role") == "assistant")
    raw_final = _extract_answer(first["messages"][final_index]["content"])
    key = canonical(raw_final)
    own_matches = [record for record in first["eval_records"] if canonical(record[0]) == key]
    shared_matches = [record for record in second["eval_records"] if canonical(record[0]) == key]
    assert raw_final is not None and not own_matches and shared_matches
    _, display, _ = _parse_evaluate_config(raw_final, "0.5")
    final_request_message = first["messages"][final_index - 1]["content"]
    visible_rows = [line for line in final_request_message.splitlines() if display in line]
    assert len(visible_rows) == 1 and "[agents 1]" in visible_rows[0]
    shared_score = shared_matches[-1][2]
    assert "{:.6f}".format(shared_score) in visible_rows[0]
    assert first["answer_source"] == "best_evaluated_fallback"
    assert canonical(first["answer"]) != key
    assert canonical(second["answer"]) == key
    return {
        "input_pins": [pin(path) for path in paths],
        "final_assistant_message_index": final_index,
        "final_request_message_index": final_index - 1,
        "model_requested_configuration": json.loads(raw_final),
        "saved_configuration": json.loads(first["answer"]),
        "request_configuration_sha256": hashlib.sha256(key.encode()).hexdigest(),
        "configuration_displayed_in_final_request": True,
        "displayed_graph_row": visible_rows[0],
        "matching_local_eval_records": len(own_matches),
        "matching_peer_eval_records": len(shared_matches),
        "peer_recorded_performance": shared_score,
        "saved_agent_performance": first["answer_perf"],
        "saved_agent_score_source": first["answer_score_source"],
        "original_agent_score_check": first["score_check"],
        "agent_raw_accuracy_difference": shared_score - first["answer_perf"],
        "recorded_pool_raw_accuracy_mi": sum(agent["answer_perf"] for agent in (first, second)) / 2,
        "shared_selection_raw_accuracy_mi": shared_score,
        "raw_accuracy_mi_difference": (shared_score - first["answer_perf"]) / 2,
        "recorded_pool_aggregate": pool["aggregate"],
        "causal_scope": "One observed terminal selection; no estimate of full-study frequency or effect.",
    }


def main():
    cases = {
        "legacy_direct_shared": toy_case(),
        "legacy_explicit_cache_fetch": toy_case(cache_fetch=True),
        "legacy_direct_shared_no_own_eval": toy_case(own_evaluation=False),
        "submitted_direct_shared": toy_case(policy="submitted"),
        "submitted_unobserved_configuration": toy_case(policy="submitted", final_x=3),
        "legacy_lower_shared": toy_case(shared_score=0.7),
        "legacy_future_shared_hidden": toy_case(shared_completion=5.0),
    }
    assert cases["legacy_direct_shared"]["peer_observation_in_final_request"]
    assert cases["legacy_direct_shared"]["saved_score"] == 0.8
    assert cases["legacy_direct_shared"]["saved_final"] == '{"x":1}'
    assert cases["legacy_explicit_cache_fetch"]["saved_score"] == 0.9
    assert cases["legacy_explicit_cache_fetch"]["simulated_cost"] == 2.0
    assert cases["legacy_explicit_cache_fetch"]["evaluations"] == 2
    assert cases["legacy_direct_shared_no_own_eval"]["saved_score"] == 0.9
    assert cases["legacy_direct_shared_no_own_eval"]["answer_score_source"] == "offline_final_answer"
    assert cases["submitted_direct_shared"]["saved_score"] == 0.9
    assert cases["submitted_unobserved_configuration"]["saved_score"] == 0.95
    assert cases["legacy_lower_shared"]["saved_score"] == 0.8
    assert not cases["legacy_future_shared_hidden"]["peer_observation_in_final_request"]
    report = {
        "scope": "CPU toy control + read-only one real pool; no model/backend calls or rescoring of raw artifacts",
        "source_pins": [pin(SOURCE / path) for path in (
            "expgym/react_loop.py", "expgym/extras/parallel_cache.py", "expgym/poolact.py",
            "scripts/run_poolact.py", "scripts/run_paper_sweep.py", "expgym/trace_v2.py")],
        "script_pin": pin(Path(__file__)), "actual": actual_evidence(), "toy_cases": cases,
        "all_assertions_passed": True,
    }
    target = OUT / "EVIDENCE.json"
    target.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"output": str(target), "sha256": pin(target)["sha256"],
                      "cases": len(cases), "all_assertions_passed": True}))


if __name__ == "__main__":
    main()
