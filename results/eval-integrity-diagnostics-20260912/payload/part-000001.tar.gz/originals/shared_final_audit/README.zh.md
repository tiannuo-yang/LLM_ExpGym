# 共享配置最终选择：legacy 口径诊断

范围：2026-09-12，一个真实 DeepSeek 两成员 NAS PoolAct smoke 的只读证据，
以及七个无模型、无数据集、无真实评分器的 CPU 控制。
执行源码为 `b3382b1c0b89ef1637e232f4b7eef68d55a54f12`；活动源码、runtime、
冻结结果和本轮 smoke 设置均未修改。本文件不提出覆盖已有报告分数。

## 结论与严重程度

这是通用的 **PoolAct 共享观察与 tuning 最终选择集合之间的整合缺口**，
但其触发行为符合明确记录并已有测试的 `legacy` 政策，不能描述为新发生的
数值评分 bug，也不能为消除反例临时切换评分端点。

对“模型是否能够直接采用共享图中的好配置”这一主张，它是值得正视的限制：
模型看到了配置、最终也选择了它，却可能被保存成自己评估过的另一配置。
要在现有 legacy 下保留共享选择，模型还需要对它发出一次 `evaluate_config`
调用，将零成本缓存结果放进**自己的** `eval_records`。这会增加一次工具决策和
evaluation 计数；已触发预算终止的 forced-final 阶段不允许补这次调用。

影响不是一概降低分数：如果模型提交的共享配置更差，legacy 的自身 best fallback
反而可能提高保存分数。现有证据只证明一个真实发生的终局选择差异，**未统计全量
频次，不能推出五模型总体 MI、BoN、排名或策略效应会改变多少**。

## 真实证据：MI 有差异，BoN 不变

原件：

- [agent_0.json](../graph_smoke/streamoff/cohort_v1/runs/deepseek-v4-flash-0731-graph-v4-20260912-nas101_a-streamoff-poolact/result/poolact/agents/agent_0.json)
- [agent_1.json](../graph_smoke/streamoff/cohort_v1/runs/deepseek-v4-flash-0731-graph-v4-20260912-nas101_a-streamoff-poolact/result/poolact/agents/agent_1.json)
- [result.json](../graph_smoke/streamoff/cohort_v1/runs/deepseek-v4-flash-0731-graph-v4-20260912-nas101_a-streamoff-poolact/result/poolact/result.json)

Agent 0 的 message 11（0-based）包含已完成的 agent 1 配置，图中显示
`0.878239 [agents 1]`。Message 12 的最终 `Answer:` 完整 JSON 与该配置精确一致。
它没有出现在 agent 0 自己的 `eval_records` 中；同一配置能在 agent 1 的原始
`eval_records` 中找到，保存的未舍入分数为 `0.8782385190327963`。

| 项目 | 原保存值 | 若保留这次明确共享选择 |
|---|---:|---:|
| Agent 0 原始准确率 | 0.845886747042338 | 0.8782385190327963 |
| 两成员池 MI 原始准确率 | 0.8620626330375671 | 0.8782385190327963 |
| 两成员池 BoN 原始准确率 | 0.8782385190327963 | 0.8782385190327963 |

这一个池的 MI 差为 **0.016175885995229122，即 1.61759 个原始准确率百分点**；
这不是 Gap 点。BoN 已选中 agent 1 的同一配置，故这次不变。
这是固定终局选择的数值对照，不是新政策真实重跑后的实验结果。

`answer_source=answer_score_source=best_evaluated_fallback` 明确记录了覆盖行为。
原 `score_check.ok=true` 也正确：它复算的是**已经被替换的保存配置**，不是
检查保存配置是否仍等于最后模型选择。不能用这次 `score_check` 通过来排除该口径限制。

## 实现路径

1. `expgym/react_loop.py:529–543`：有答案后 `_finalize_answer` 在 tuning
   evaluator 为 null 时仅查自身 `eval_records`；legacy 无匹配则覆盖成自身 best。
2. `scripts/run_poolact.py:533–605`：传入共享 tools/clock/graph/hook，但没有
   共享最终选择查询接口。之后 `_score_result` 验证的是覆盖后的保存答案。
3. `docs/portable-study.md:71–76`、`docs/task-abstention-v5.md:37–39`：明确保留
   非缺答的 legacy 最终选择行为；`submitted` 是另外的端点。
4. `tests/test_native_react_loop.py:130–140`、`tests/test_json_answer_lookup.py`
   已明确覆盖未在自身记录中匹配的配置被 legacy fallback 替换的行为。

## 七个 CPU 控制

玩具配置：自身评估 `x=1` 得 0.8；共享 `x=2` 默认得 0.9；工具成本为 2。
下表不是 NAS/HPO 评分结果，只证明控制流。

| 控制 | 模型最终选择 | 保存配置/分数 | 工具 evaluations / 模拟成本 |
|---|---|---|---|
| legacy，直接选择已见共享配置 | x=2 | x=1 / 0.8 | 1 / 2 |
| legacy，先显式访问零成本 cache | x=2 | x=2 / 0.9 | 2 / 2 |
| legacy，没有自身评估记录 | x=2 | x=2 / 0.9，offline final | 0 / 0 |
| submitted，直接选择已见共享配置 | x=2 | x=2 / 0.9，offline final | 1 / 2 |
| submitted，选择从未观察的配置 | x=3 | x=3 / 0.95，offline final | 1 / 2 |
| legacy，共享配置分数较低（0.7） | x=2 | x=1 / 0.8 | 1 / 2 |
| legacy，共享配置还在未来、不可见 | x=2 | x=1 / 0.8 | 1 / 2 |

七项控制与真实原件的所有断言通过。`submitted` **不只是禁止 fallback**：
loop 保留提交配置，若缺少匹配分数，runner 的 `_legacy_score_result` 会使用
真实任务工具在模型终止后离线计算该配置的分数，包括尚未获得反馈的配置。
此离线分数不回传模型，不增加 simulated feedback cost/evaluations。
它不是查询全局最优，但确实扩大到“提交配置的离线评估”端点；不能把它说成
仅从共享缓存读取已知结果。Legacy 在自身 `eval_records` 为空时也已有离线补分分支。

## 若以后授权：最小 opt-in 设计，而非本轮修改

可另行命名 `shared-visible-legacy-v1`，所有模型和策略固定同一新政策：

1. 先保留当前自身记录精确匹配规则。
2. 无自身匹配时，仅对**产生该最终答案的实际请求中已送达的图快照**进行完整
   canonical 配置精确匹配，使用对应已完成原始工具记录的未舍入分数，保留模型选择。
3. 没有符合条件的共享匹配时继续原 legacy 路径；不自动选择共享最高分、不补空答案。
4. 新的共享查询自身不离线评估未知配置、不增加 tool/evaluation/cost/cache-hit 统计。
   现有无自身评估时的 legacy 离线分支若保留，须继续明确记录，不能混称为纯共享查表。

安全要求：

- 必须在图注入/请求发送时以同一快照捕获可见记录，不可模型返回后查询 live cache：
  其他工具能在 LLM 生成期间完成，事后查询可能加入模型从未看见的结果。
- 只接受完成时间 ≤ 接收 agent 时钟且严格小于反馈预算、且实际展示的记录；
  排除未来、预算边界、pending、被隐藏结果和不同池/任务的缓存。
- 不从图中六位小数反解析正式分数；不把共享记录伪装成自身 `eval_records`。
- 同一配置存在多次反馈时，遵循该实际可见快照的合并规则并绑定对应来源事件，
  不混用 live cache 的最早记录或之后才出现的更优值。
- 新增明确的 score source 与来源 agent/event/完整配置/完成时间/接收请求快照绑定。
  扩展 trace-v2 schema、序列化/恢复 allowlist、PoolAct 跨成员来源验证；现有仅数值
  复算不足以证明共享记录确实已见。
- 回归需要保留 legacy/submitted 原行为，并覆盖未来、预算外、未展示、伪造来源、
  低分共享选择、零分配置及无答案；不能以新结果更符合预期作为通过标准。

本次**没有实现新政策**，继续保留 b338 + legacy 的冻结 smoke。

## 可复现文件

- [reproduce.py](reproduce.py)：只写当前诊断目录的 CPU 控制与实际单池核查。
- [EVIDENCE.json](EVIDENCE.json)：三个原件、六个源码文件和脚本的 SHA/大小；完整
  配置映射、可见图行、原分数与七个控制结果。JSON SHA-256：
  `b6840d7b65c7226b68a552f2567514a47606fe3c77492622904cb092be5aaed3`。

使用原有已安装解释器运行，不重装环境：

```bash
/lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python -B \
  /lustrefs/users/chufan.shi/codex_space_tn/eval_diagnostics_20260912/shared_final_audit/reproduce.py
```

新政策设计另经独立只读 agent 核查实现/验证器边界；这不是重新评分完整历史实验。
