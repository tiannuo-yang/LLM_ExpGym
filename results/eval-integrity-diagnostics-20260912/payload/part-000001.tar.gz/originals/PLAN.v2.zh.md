# 首请求诊断 v2：原始字段顺序，2026-09-12

v1 helper 的排序序列化是本次诊断代码的错误：`sort_keys=True` 改变嵌套工具
schema 字段顺序，从而改变 DeepSeek 实际渲染 prompt。JSON 值等价和 canonical
SHA 相等不代表模型输入相等。已完成 v1 c1 的 8 次调用、成本、原始输出和 helper
全部保留；它们只能作为 **字段顺序被改变的诊断样本**，不得称为历史精确重放。

v2 使用独立 helper `replay_first_requests_v2.py`，出网 body 完全采用冻结客户端
`llm_clients.py:385` 的 `json.dumps(payload).encode("utf-8")`：保留所有层次的
插入顺序，`ensure_ascii=True`、默认 separators，不排序。canonical SHA 只用作
语义身份，另记录真实 wire SHA/bytes。`INPUTS.v2.json` 将 wire SHA 与既有实际
renderer CPU 审计逐条绑定，并保留预期 rendered text/token SHA 和 token 数。
这不是再次运行 GPU renderer，也不是用 token 数代替 prompt hash。

固定仍为同 4 条首请求，每条预先计划重复 2 次；original-order c1 和 c4 各 8 次，
不增加 nonce、不扩展样本、不按结果补抽。参数、思考级别、tools/tool_choice、
messages、seed 和 cache_salt 均保持原样。请求 seed 不保证实际 FlashInfer 采样
确定性，不能把不同输出当成 exact-input replay 失败。

执行前由 root 分别排空并刷新 owned endpoint 的缓存，记录控制证据。v2 helper
本身不改变 GPU 状态，不刷新共享服务。输出必须全新、目录名包含 `v2`，建议：

```bash
/lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python -B \
  /lustrefs/users/chufan.shi/codex_space_tn/eval_diagnostics_20260912/replay_first_requests_v2.py run \
  --endpoint http://azure-uk-hpc-H200-instance-012:33240/v1 \
  --variant original-order-v2-c1 --concurrency 1 \
  --output-dir /lustrefs/users/chufan.shi/codex_space_tn/eval_diagnostics_20260912/original-order-v2-c1

# 在独立 drain/flush 之后：
/lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python -B \
  /lustrefs/users/chufan.shi/codex_space_tn/eval_diagnostics_20260912/replay_first_requests_v2.py run \
  --endpoint http://azure-uk-hpc-H200-instance-012:33240/v1 \
  --variant original-order-v2-c4 --concurrency 4 \
  --output-dir /lustrefs/users/chufan.shi/codex_space_tn/eval_diagnostics_20260912/original-order-v2-c4
```

每次 HTTP body、解码 JSON、usage、finish reason、latency 和失败分类单独存档；
无自动重试、无旧文件覆盖、无评分。schema-valid 多工具调用不等于 runner 可执行：
原 native ReAct 每个 decision 仅允许 1 个工具调用。v2 另存原始工具数及
`native_exactly_one_schema_valid_tool_call`，但仍不将 shape 当作任务质量或可读性分数。

当前工作仅准备与 CPU mocks；模型调用由 root 授权后执行。
