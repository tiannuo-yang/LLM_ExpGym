#!/usr/bin/env bash
set -euo pipefail
umask 077
ulimit -c 0
source /lustrefs/users/chufan.shi/codex_space_tn/eval_diagnostics_20260912/serving/runtime-env.sh
exec /lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python -B \
  /lustrefs/users/chufan.shi/codex_space_tn/eval_diagnostics_20260912/serving/run-server.py
