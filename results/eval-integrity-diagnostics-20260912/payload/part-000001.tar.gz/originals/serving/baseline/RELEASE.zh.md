# 基线主动结束记录

操作者：本线程 ROOT assistant。决策时间：2026-09-12 01:06 UTC。
目标：只结束已拥有的 Slurm job `1205016`，不操作任何其他 job。

全部24个任务请求（v1 c1=8、v2 c1=8、v2 c4=8）已返回；无运行中的实验队列。
`control-after-original-order-v2-c4/CONTROL.json` 保存最后metadata/metrics和成功flush，
flush确认当时服务running/waiting队列已排空；该控制另有一次单token health探测。
全部请求/响应、失败/乱码、usage与人工/runner分类保持原样，没有删除数据。

由ROOT执行 `scancel 1205016`，以释放节点012供已提交的单因素候选job `1205022`。
这不是运行失败后的隐式重试：候选事前计划见 `../multistream-off/PLAN.zh.md`，
仅测试关闭多stream开关；原8条c4结果全部进入对照。实际结束时间与GPU资源成本
以稍后的Slurm accounting为准，不能由本文件推断取消命令已经成功。
