"""One owned diagnostic server; freeze real argv/device evidence before launch."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import time

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'baseline'
job = os.environ['SLURM_JOB_ID']
assert os.environ.get('SLURM_JOB_NUM_NODES') == '1'
argv = [
    '/lustrefs/users/chufan.shi/codex_space_tn/deepseek_flash_eval_20260911/runtime/.venv/bin/sglang',
    'serve', '--model-path', '/lustrefs/users/runner/chufan.shi/tau_vision/ckpts/DeepSeek-V4-Flash-0731',
    '--served-model-name', 'deepseek-v4-flash-0731', '--tp-size', '8', '--pp-size', '1',
    '--ep-size', '1', '--nnodes', '1', '--node-rank', '0',
    '--dist-init-addr', socket.gethostbyname(socket.gethostname()) + ':53240',
    '--context-length', '1048576', '--mem-fraction-static', '0.85',
    '--max-running-requests', '64', '--cuda-graph-max-bs-decode', '64',
    '--enable-metrics', '--host', '0.0.0.0', '--port', '33240',
    '--reasoning-parser', 'deepseek-v4', '--tool-call-parser', 'deepseekv4',
    '--moe-runner-backend', 'marlin', '--attention-backend', 'dsv4',
    '--page-size', '256', '--chunked-prefill-size', '4096', '--dist-timeout', '1800',
]
def write(name, value):
    with (OUT / name).open('x') as f:
        json.dump(value, f, indent=2, sort_keys=True)
        f.write('\n')

devices = subprocess.check_output([
    'nvidia-smi', '--query-gpu=index,uuid,name,memory.total', '--format=csv,noheader'
], text=True).strip().splitlines()
assert len(devices) == 8, len(devices)
version_path = Path('/lustrefs/users/chufan.shi/codex_space_tn/deepseek_flash_eval_20260911/runtime/versions.json')
write('deployment.json', {
    'classification': 'diagnostic_baseline_not_ready', 'job_id': job,
    'node': socket.gethostname(), 'devices': devices, 'argv': argv,
    'endpoints': ['http://' + socket.gethostname() + ':33240/v1'],
    'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'runtime_manifest': str(version_path),
    'runtime_manifest_sha256': hashlib.sha256(version_path.read_bytes()).hexdigest(),
    'code_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'delta_from_formal_single_replica': ['one replica allocation', 'new ports', 'new mutable compiler caches'],
    'public_endpoint': False, 'new_model_requests': 0,
})
started = time.monotonic()
process = subprocess.Popen(argv)
code = process.wait()
write('server_exit.json', {'returncode': code, 'elapsed_seconds': time.monotonic()-started,
                           'job_id': job, 'provider_quiescence_proven': False})
raise SystemExit(code)
