# 单因素 GPU 对照：关闭多 CUDA stream 重叠

前瞻决策：2026-09-12 01:04 UTC，baseline 原顺序 c1/c4 各8请求均结束后。
人工完整阅读已确认 c1 8条连贯；c4 至少2条真正碎词/字符乱码、1条严重循环退化。
这提示并发相关的生成风险，但采样本来非确定性，不能据此直接认定某个 kernel 为根因。

候选只改 `SGLANG_OPT_USE_MULTI_STREAM_OVERLAP=0`。源码依据：DeepSeek V4 初始化
alternate streams，并在 Hopper、bs<=64、CUDA graph capture 路径使用多 stream；
该标志影响初始化/已捕获图，没有受支持的热切换。需要新服务进程。

- 复用 baseline 同节点012、同8 GPU UUID、同runtime/权重、相同有效参数（含端口）。
  唯一额外argv选项是显式固定 baseline 日志已记录的 `--random-seed 482082713`，
  避免新进程自动选另一个seed；这不重放此前的RNG消费顺序，不保证输出确定性。
  baseline 完成且排空后由 ROOT 主动结束1205016；新job绑定该节点，不碰其他job。
- 对齐已观察到的 baseline 环境：OMP_NUM_THREADS/MKL_NUM_THREADS/PYTHONUNBUFFERED
  未设置；TORCH_EXTENSIONS_DIR同样保持未设置。TORCHINDUCTOR_CACHE_DIR 保持原继承的 `/tmp/inductor-chufan.shi-1203165`。
  其他 mutable cache 仍使用新job namespace，不删除或重用旧诊断缓存。显式记录这种
  新进程/编译缓存/时序差异，不把 A/B 解释为逐token确定性的配对试验。
- 服务ready后，先保存metadata/metrics，记录一次health探测与flush；然后仅运行
  冻结 v2 的同4输入×2重复、concurrency4，共8请求。原最大思考/T1/p.95/32768
  和wire/prompt身份不改，无重试、不补抽、不根据分数更换样本。
- 以全部response raw和人工阅读/原runner协议分类比较：乱码、循环退化、单调用、
  多调用拒绝、空答、长度限制分别记录。没有乱码也只能支持该小对照，不证明根因。
- 新allocation时限2小时、8H200。若无法ready或对照仍异常，保留全部成本/失败，
  不自行开始全量矩阵。真实PoolAct及matched策略计划需另绑定实际通过检查的deployment，
  不能沿用baseline绑定并假称它们在新variant执行过。

权重完整性已做过48/48单次hash核验；本对照不重复166GB扫描。
这是原总计划允许的第1个源码依据单因素候选，不是修改评分或模型答案。

## 候选请求预算的前瞻补充（服务仍在预热，尚无候选任务请求）

为检查“只是重启后暂时正常”这一替代解释，预留原总计划第二组的8个候选请求：
若首组具备足以进入真实smoke的输出保真度，且固定六池smoke完成，则在排空/flush后
用同一候选服务再执行一次同4输入×2重复的c4检查，目录
`multistream-off-v2-c4-after-smokes`。这组不是对坏答案补抽；无论结果好坏都保留。
它检验较晚运行状态下的复现，仍不恢复相同RNG消费或证明严格因果。

若首组暴露仍需诊断的生成异常，则不执行上述后段检查；保留这8请求用于原计划允许
的另一个源码支持候选，由ROOT另写具体单因素计划。两条分支互斥，本轮候选直接回放
总上限保持16请求，不因结果不合预期无界追加。任务smoke最多60请求另计，低分/负差
不是选择分支或追加样本的依据。
