#!/usr/bin/env bash
set -euo pipefail
umask 077
ulimit -c 0
source /lustrefs/users/chufan.shi/codex_space_tn/eval_diagnostics_20260912/serving/runtime-env.sh
# Match the observed baseline worker environment; do not introduce OMP fixes.
unset OMP_NUM_THREADS MKL_NUM_THREADS PYTHONUNBUFFERED TORCH_EXTENSIONS_DIR
export TORCHINDUCTOR_CACHE_DIR=/tmp/inductor-chufan.shi-1203165
export SGLANG_OPT_USE_MULTI_STREAM_OVERLAP=0
exec /lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python -B \
  /lustrefs/users/chufan.shi/codex_space_tn/eval_diagnostics_20260912/serving/multistream-off/run-server.py
