"""Fresh, same-hardware server; only declared stream flag differs from baseline."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import time

OUT = Path(__file__).resolve().parent
BASE = OUT.parent / 'baseline/deployment.json'
BASE_SHA = 'a5a357b6fabc5f188986927e00a36762bbbf1db58e9ffc738780c6e458016847'
raw = BASE.read_bytes()
assert hashlib.sha256(raw).hexdigest() == BASE_SHA
baseline = json.loads(raw)
assert os.environ.get('SLURM_JOB_NUM_NODES') == '1'
assert socket.gethostname() == baseline['node']
devices = subprocess.check_output([
    'nvidia-smi', '--query-gpu=index,uuid,name,memory.total', '--format=csv,noheader'
], text=True).strip().splitlines()
assert devices == baseline['devices'], 'Hardware differs from registered same-node baseline'
assert os.environ['SGLANG_OPT_USE_MULTI_STREAM_OVERLAP'] == '0'
assert all(key not in os.environ for key in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'PYTHONUNBUFFERED', 'TORCH_EXTENSIONS_DIR', 'SGLANG_DEFAULT_THINKING', 'PYTHONPATH'))
assert os.environ['TORCHINDUCTOR_CACHE_DIR'] == '/tmp/inductor-chufan.shi-1203165'
manifest = Path(baseline['runtime_manifest'])
assert hashlib.sha256(manifest.read_bytes()).hexdigest() == baseline['runtime_manifest_sha256']
argv = list(baseline['argv'])
seed_matches = re.findall(r'\brandom_seed=(\d+)', (OUT.parent / 'baseline/slurm-1205016.log').read_text())
assert seed_matches == ['482082713'], 'Unexpected baseline effective server seed'
assert '--random-seed' not in argv
argv.extend(['--random-seed', seed_matches[0]])

def write(name, value):
    with (OUT / name).open('x') as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write('\n')

env_keys = (
    'SGLANG_OPT_USE_MULTI_STREAM_OVERLAP', 'SGLANG_DSV4_USE_BF16_KV_QUANT_SOURCE',
    'SGLANG_DSV4_FP4_DEQUANT', 'SGLANG_DSV4_FIX_TP_ATTN_A2A_SCATTER',
    'SGLANG_DSV4_REASONING_EFFORT', 'SGLANG_EXPERIMENTAL_CPP_RADIX_TREE',
    'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'PYTHONUNBUFFERED', 'TORCHINDUCTOR_CACHE_DIR',
    'TORCH_EXTENSIONS_DIR', 'SGLANG_DEFAULT_THINKING', 'PYTHONPATH',
    'HF_HOME', 'XDG_CACHE_HOME', 'TRITON_CACHE_DIR', 'FLASHINFER_WORKSPACE_BASE',
    'TVM_FFI_CACHE_DIR', 'SGLANG_DG_CACHE_DIR', 'TILELANG_CACHE_DIR', 'CUDA_CACHE_PATH',
)
for key in env_keys[:6]:
    if key != 'SGLANG_OPT_USE_MULTI_STREAM_OVERLAP':
        assert key not in os.environ, 'Undeclared runtime candidate environment change: ' + key
write('deployment.json', {
    'classification': 'single_factor_candidate_not_ready', 'job_id': os.environ['SLURM_JOB_ID'],
    'node': socket.gethostname(), 'devices': devices, 'argv': argv,
    'endpoints': baseline['endpoints'], 'baseline_deployment_sha256': BASE_SHA,
    'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'runtime_manifest': str(manifest), 'runtime_manifest_sha256': baseline['runtime_manifest_sha256'],
    'code_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'argv_base_equal_to_baseline': argv[:-2] == baseline['argv'],
    'argv_delta': {'--random-seed': '482082713; explicit preservation of baseline effective value, not identical RNG state'},
    'intended_runtime_delta': {'SGLANG_OPT_USE_MULTI_STREAM_OVERLAP': {'baseline': 'UNSET(default True)', 'candidate': '0'}},
    'allowlisted_environment': {key: os.environ.get(key, 'UNSET') for key in env_keys},
    'other_changes': ['new job/process/startup', 'new job-scoped mutable compiler cache paths; inherited inductor path intentionally unchanged'],
    'public_endpoint': False, 'new_model_requests': 0,
})
started = time.monotonic()
process = subprocess.Popen(argv)
code = process.wait()
write('server_exit.json', {'returncode': code, 'elapsed_seconds': time.monotonic()-started,
                           'job_id': os.environ['SLURM_JOB_ID'], 'provider_quiescence_proven': False})
raise SystemExit(code)
