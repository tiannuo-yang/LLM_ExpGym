#!/usr/bin/env bash
# Identical nonsecret library setup; only the already isolated cache namespace changes.
source /lustrefs/users/chufan.shi/codex_space_tn/portable_eval_20260908/serving/phase_candidates/dual_glm_v1/runtime.sh
GLM_CONTINUE_CACHE_ROOT="/tmp/expgym_glm_continue_${SLURM_JOB_ID:?}_rank${SLURM_PROCID:?}"
export HF_HOME="$GLM_CONTINUE_CACHE_ROOT/hf"
export HF_MODULES_CACHE="$GLM_CONTINUE_CACHE_ROOT/hf/modules"
export XDG_CACHE_HOME="$GLM_CONTINUE_CACHE_ROOT/cache"
export TRITON_CACHE_DIR="$GLM_CONTINUE_CACHE_ROOT/triton"
export FLASHINFER_WORKSPACE_BASE="$GLM_CONTINUE_CACHE_ROOT/flashinfer"
export TVM_FFI_CACHE_DIR="$GLM_CONTINUE_CACHE_ROOT/tvm"
export SGLANG_DG_CACHE_DIR="$GLM_CONTINUE_CACHE_ROOT/deep_gemm"
export DG_JIT_CACHE_DIR="$SGLANG_DG_CACHE_DIR"
export TILELANG_CACHE_DIR="$GLM_CONTINUE_CACHE_ROOT/tilelang"
export TILELANG_TMP_DIR="$GLM_CONTINUE_CACHE_ROOT/tilelang/tmp"
export CUDA_CACHE_PATH="$GLM_CONTINUE_CACHE_ROOT/cuda-driver"
# run-server.py restores the observed allowlisted child environment, including
# the unchanged inherited TORCHINDUCTOR_CACHE_DIR. No model/runtime settings are tuned.
