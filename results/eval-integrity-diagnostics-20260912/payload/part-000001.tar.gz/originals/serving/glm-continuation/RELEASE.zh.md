# GLM continuation：任务完成后的 ROOT 主动收尾

2026-09-12 03:45:37.913753 UTC，最后一池 cached 完成。
同部署 PoolAct/naive/cached 三池均正常退出，共25个任务请求、6/6有效最终答案，
无仍在途的任务请求。执行者停止写入后才进行控制和资源收尾。

03:46:14 UTC 的 `control-final/CONTROL.json` 保存 health、model-info、metrics、
flush_cache 四路200；成功flush证明该次控制操作时服务的running/waiting队列为空。
health可能执行内部单token生成，不计任务调用；不能把这个控制视为零计算。

ROOT 于03:46:31 UTC主动 `scancel 1205034`；不是用户或调度器取消未完成样本。
Slurm父job账：

```text
1205034|CANCELLED by 1071|2026-09-12T01:59:14|2026-09-12T03:46:31|6437|billing=192,cpu=192,gres/gpu=16,mem=3720000M,node=2
```

按父allocation一次计费：6437秒×16GPU/3600=28.608888889 GPU-hours。
不叠加job steps，不将请求wall相加当allocation历时，也不把此数称为纯推理GPU利用率。
Slurm账面End早于后台清理完成；取消后曾短暂处于COMPLETING，不能据账面End
推定所有进程同一时刻退出。保存的rank1退出码为−15，rank0为−9，后者记录
elapsed_seconds=6499.213659909088，说明清理比父job账面时长更长。
两份exit记录的 `provider_quiescence_proven=false` 保持原样；任务排空证据来自
已有全部完成的请求与最终flush，而不是由进程退出码反推。

旧GLM Audit的已完成PoolAct及两个未启动controls继续保留，不同新cohort拼分。
本次cached有一次32k输出长度耗尽，之后在原预算内恢复；原始失败回复和费用保留。
本轮没有因负分补抽、没有新增实验，也未停止其他人的作业。
