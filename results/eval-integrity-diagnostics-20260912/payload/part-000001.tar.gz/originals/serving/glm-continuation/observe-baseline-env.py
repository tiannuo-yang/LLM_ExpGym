"""One read-only, explicitly allowlisted process environment observation."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess

OUT = Path(__file__).resolve().parent
KEYS = (
    'OMP_NUM_THREADS', 'OMP_PROC_BIND', 'OMP_PLACES', 'MKL_NUM_THREADS',
    'OPENBLAS_NUM_THREADS', 'KMP_AFFINITY', 'PYTHONUNBUFFERED', 'PYTHONPATH',
    'PYTHONNOUSERSITE', 'PYTHONDONTWRITEBYTECODE', 'TOKENIZERS_PARALLELISM',
    'HF_HUB_OFFLINE', 'TRANSFORMERS_OFFLINE', 'CUDA_VISIBLE_DEVICES',
    'TORCHINDUCTOR_CACHE_DIR', 'TORCH_EXTENSIONS_DIR',
    'SGLANG_OPT_USE_MULTI_STREAM_OVERLAP', 'SGLANG_EXPERIMENTAL_CPP_RADIX_TREE',
    'SGLANG_DEFAULT_THINKING', 'SGLANG_ENABLE_JIT_DEEPGEMM',
    'SGLANG_DISABLE_FLASHINFER_AUTOTUNE', 'SGLANG_DSV4_USE_BF16_KV_QUANT_SOURCE',
    'SGLANG_DSV4_FP4_DEQUANT', 'SGLANG_DSV4_FIX_TP_ATTN_A2A_SCATTER',
    'SGLANG_DSV4_REASONING_EFFORT', 'HF_HOME', 'HF_MODULES_CACHE',
    'XDG_CACHE_HOME', 'TRITON_CACHE_DIR', 'FLASHINFER_WORKSPACE_BASE',
    'TVM_FFI_CACHE_DIR', 'SGLANG_DG_CACHE_DIR', 'DG_JIT_CACHE_DIR',
    'TILELANG_CACHE_DIR', 'TILELANG_TMP_DIR', 'CUDA_CACHE_PATH',
    'LD_LIBRARY_PATH', 'LIBRARY_PATH', 'PATH',
)
IDENTITY_KEYS = ('SLURM_JOB_ID', 'SLURM_PROCID', 'SLURM_STEP_ID')


def read_allowlist(path, keys):
    allowed = {key.encode('ascii'): key for key in keys}
    values = {key: None for key in keys}
    pending = b''
    with path.open('rb') as stream:
        while chunk := stream.read(4096):
            fields = (pending + chunk).split(b'\0')
            pending = fields.pop()
            for field in fields:
                key, separator, value = field.partition(b'=')
                if separator and key in allowed:
                    values[allowed[key]] = value.decode('utf-8')
        if pending:
            key, separator, value = pending.partition(b'=')
            if separator and key in allowed:
                values[allowed[key]] = value.decode('utf-8')
    return values


def main():
    if os.environ.get('SLURM_JOB_ID') != '1205018':
        raise ValueError('Observation must execute inside owned baseline job 1205018')
    if socket.gethostname().split('.')[0] != 'azure-uk-hpc-H200-instance-256':
        raise ValueError('Observation is restricted to the known baseline head node')
    listing = subprocess.check_output(['ps', '-u', 'chufan.shi', '-o', 'pid=,args='], text=True)
    needle = '/gumbel_midpoint_v1/.venv/bin/sglang serve --model-path /lustrefs/users/runner/chufan.shi/tau_vision/ckpts/GLM-5.3 '
    matches = [int(line.strip().split(None, 1)[0]) for line in listing.splitlines() if needle in line]
    if len(matches) != 1:
        raise ValueError('Expected one exact GLM SGLang server process, found ' + str(len(matches)))
    pid = matches[0]
    proc = Path('/proc') / str(pid)
    values = read_allowlist(proc / 'environ', KEYS + IDENTITY_KEYS)
    if values['SLURM_JOB_ID'] != '1205018' or values['SLURM_PROCID'] != '0':
        raise ValueError('Resolved process is not baseline rank 0')
    command_sha = hashlib.sha256((proc / 'cmdline').read_bytes()).hexdigest()
    result = {
        'schema': 'allowlisted-serving-environment-observation-v1',
        'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'hostname': socket.gethostname(), 'pid': pid, 'cmdline_sha256': command_sha,
        'process_identity': {key: values[key] for key in IDENTITY_KEYS},
        'allowlisted_environment': {key: values[key] for key in KEYS},
        'missing_value': 'null means unset, not empty string',
        'scope': 'One baseline rank-0 process; rank 1 and nonallowlisted variables are not observed',
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    output = OUT / 'baseline-env-observation.json'
    fd = os.open(output, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'w') as stream:
        json.dump(result, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'output': str(output), 'pid': pid, 'observed_keys': len(KEYS),
                      'sha256': hashlib.sha256(output.read_bytes()).hexdigest()}, sort_keys=True))


if __name__ == '__main__':
    main()
