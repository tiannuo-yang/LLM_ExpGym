#!/usr/bin/env bash
set -euo pipefail
umask 077
ulimit -c 0
source /lustrefs/users/chufan.shi/codex_space_tn/eval_diagnostics_20260912/serving/glm-continuation/runtime-env.sh
exec /lustrefs/users/chufan.shi/codex_space_tn/portable_eval_20260908/serving/runtime_candidates/gumbel_midpoint_v1/.venv/bin/python -B \
  /lustrefs/users/chufan.shi/codex_space_tn/eval_diagnostics_20260912/serving/glm-continuation/run-server.py
