# GLM 三项思考设置：只读源码核对

结论：**未发现本次三项设置的明显不兼容或 max 被丢弃。** 当前配置是模板支持的
Max 思考、保留历史 reasoning；没有依据将可读语义重复判为 serving/kernel 损坏。
不改正在执行的 naive/cached，也不据此追加模型调用。

核对对象为 `1205034` 的实际 deployment、同 cohort 的 `pool_plan.json` /
`matched_plan.json`，以及其 frozen GLM runtime 和本地 checkpoint 模板；未读取任何
真实 API dump、未加载 Tokenizer/权重、未请求 HTTP/GPU。这里只验证配置到源码的
作用链，不替代逐请求渲染/输出 fidelity 检查。

| 设置 | 本次声明与实际源码语义 | 作用边界 |
|---|---|---|
| `reasoning_effort=max` | plan 的 top-level 与 `chat_template_kwargs` 都为 max。SGLang 取出模板里的同名值，写入 request，再传给 Jinja。GLM 模板第2–3行输出系统字段 `Reasoning Effort: Max`；low/high 会对应改变该字段，未指定也默认 Max。 | 是模型可见的 effort 指令，不是额外硬性 token 配额；本次总 completion 上限仍是32768。显式 max 与该模板默认档相同，不等于参数失效。 |
| `enable_thinking` | plan **未主动传入**。SGLang 请求归一化根据 top-level max，以 `setdefault` 补 `enable_thinking=true` / `thinking=true`。本地 GLM 模板不读取这个开关，而在 generation prompt 无条件追加 `<think>`；显式 glm45 parser 的默认判断也与开启思考相符。 | 不能把它宣传成此模板可用的独立 on/off 控制；本次没有 false 与模板 always-on 冲突。 |
| `clear_thinking=false` | 模板第4行默认也是 false。第137–146行取得历史 `reasoning_content`（或已有 think 标签），false 时保留各历史 assistant 的 reasoning。若设 true，只清除最后 user 之前的历史 reasoning，当前 user 后工具轮次的 reasoning 仍保留。 | 不清除正文/tool history，也不清除 PoolAct graph 或缓存；可能使历史更长，但本核对不能证明它导致重复。 |

源码位置（均为实际 frozen runtime / checkpoint 的本地文件）：

- [GLM 模板第2行](/lustrefs/users/runner/chufan.shi/tau_vision/ckpts/GLM-5.3/chat_template.jinja:2)、[历史保留条件第143行](/lustrefs/users/runner/chufan.shi/tau_vision/ckpts/GLM-5.3/chat_template.jinja:143)、[生成前缀第253行](/lustrefs/users/runner/chufan.shi/tau_vision/ckpts/GLM-5.3/chat_template.jinja:253)。本次只读模板 SHA256：`3740abcea51c45830cb3ca562084ad5fb2ef53589376f73332e9886f93ade41c`。
- runtime 前缀：`portable_eval_20260908/serving/runtime_candidates/gumbel_midpoint_v1/.venv/lib/python3.12/site-packages/`。
  `sglang/srt/entrypoints/openai/serving_chat.py:723–734,1165–1207` 传递 effort/模板参数；
  `protocol.py:931–944` 补 thinking 开关，`:1005–1007` 将 max_tokens 映射为 max_new_tokens。
- `sglang/srt/parser/template_manager.py:145–183` 使用默认 HF 模板；
  `transformers/tokenization_utils_base.py:1791–1808` 优先读取独立 `chat_template.jinja`。
  启动日志 `slurm-1205034.log:31` 也明确记录使用默认 HuggingFace 模板。
- `serving_chat.py:178,2150–2193` 使用显式部署的 glm45 parser，并在无模板 toggle config
  时回退到 parser 默认；`sglang/srt/parser/reasoning_parser.py:572–607` 定义该默认。
  自动检测日志中的 parser **建议**不替换 deployment 已显式指定的 glm45/glm47。

两个冻结 plan 的 SHA256 分别为
`59810b919f3a7b895c873d20b72e24340c19e625b6d76e32875c8830276106ca` 和
`d0d85a3058bf60b74279249bad81d8c5728a3e4d704cad3dfa4b808213bf46e2`；
三策略的这三项配置及32768 cap一致。此次不做性能归因、不修改设置，核对到此停止。
