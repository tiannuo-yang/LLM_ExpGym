# GLM 同硬件 continuation：仅准备，尚未提交

分类：**Static/fake validation** 的启动准备，服务成功启动后才可能成为
**Real smoke validation**。本目录的文件或 `--plan` 输出都不是 ready 证据。

## 原因与固定边界

ROOT 于 2026-09-12 决定：原 job `1205018` 的两小时时限中，启动约占 59 分钟，
当前 Audit 实际耗时已超过 20 分钟，延长 allocation 被调度器拒绝。
因此先完成并排空旧两份 PoolAct smoke 与 NAS naive/cached controls，再主动结束
旧 job，之后才由 ROOT 申请同节点的四小时 continuation。增加一份 Audit PoolAct
来自基础设施时限和完整同 cohort 比较的需要，不是根据分数补抽。

此次准备不提交、不取消、不发 HTTP、不修改旧 launcher/runtime/checkpoint，
不重新哈希大权重。唯一额外检查是在仍运行的旧 job 内，对已解析的 head server
PID `2205579` 做一次明确 allowlist 的非敏感环境观察，保存于本目录。

调用数边界：

| allocation/cohort | 保留或计划的池 | 模型调用上限 |
|---|---|---:|
| 旧 `1205018` | 原 NAS PoolAct、原 Audit PoolAct、NAS naive、NAS cached | 40 |
| 新 continuation | Audit PoolAct、Audit naive、Audit cached | 30 |
| 合计 | 7 池；原计划为 6 池 | 70 |

旧 Audit PoolAct 仍完整留存并计入资源/诊断记录，但**不混入新 Audit 三策略比较**。
新三池使用同一份冻结任务、源码、生成和评分设置；PoolAct 独立池状态/cache/dump
不共享。source/graph smoke plans 由负责实验的 agent 单独冻结；这个 launcher
不会启动实验或通过分数选择下一步。原始错误、空答案、负效果和所有成本均保留。

## 与 baseline 相同及实际变化

保持一副本、两节点 × 八张 H200、TP16/EP1、同 checkpoint 和 frozen runtime：
`portable_eval_20260908/serving/runtime_candidates/gumbel_midpoint_v1/.venv`。
节点固定为 `azure-uk-hpc-H200-instance-256` / `257`；两 rank 的全部 16 个 GPU
UUID/顺序/型号/显存必须与已有 baseline deployment 完全一致，否则启动失败。

直接从 baseline **实际 rank argv** 复制，仅将 HTTP `33440` 改为 `33460`、
rendezvous `53440` 改为 `53460`。head IP 继续绑定 `10.0.5.4`，变动即拒绝启动。
保留 context 262144、memory fraction .84、max-running 64、CUDA graph batch 64、
glm45/glm47 parser、FlashInfer sampler、native FP8、初始化 seed **4200**。
修改过的原 sampler SHA256 和旧 runtime/setup/metadata 都在启动前再次核对。
本次不修改 sampler，不降低 thinking/output cap/horizon，不改变评分。

显式差异只有新的 job/process、四小时时限、上述两个端口、新输出目录及新的
`/tmp/expgym_glm_continue_JOB_rankR/` 编译/模块缓存根。相同初始化 seed 不意味着
相同 RNG 消费顺序；新进程、冷/热缓存、启动时序及重新调度都可能不同。

环境证据 `baseline-env-observation.json` 在 01:44:00 UTC 观察了 baseline rank 0
的 39 个配置键（null 表示未设置）。launcher 为两个新的子进程显式重放这些值，
仅把旧 `/tmp/expgym_glm_diag_1205018_rank0` 前缀映射成各自新的 job/rank 缓存根。
OMP/MKL、multistream 等保持原未设置状态；不把另一个模型的环境设置带入 GLM。

`TORCHINDUCTOR_CACHE_DIR` 实际继承为 `/tmp/inductor-chufan.shi-1203165`，为保持
baseline 配置不变，本次继续保持该值。它不在 job/rank 隔离根内，因此不能宣称
“全部编译缓存物理隔离”。rank 1 的旧进程环境和 allowlist 以外的变量未单独观察，
不声称全环境逐字相同。观察只写了已明确列出的非敏感键，未保存完整环境或凭据。

## ROOT 的启动与验收

1. 确认旧两 PoolAct 与 NAS controls 完成，停止新 dispatch，保存并检查排空证据；
   仅 ROOT 可以结束确切旧 job `1205018`。不影响任何其他 job。
2. 使用下述只读命令检查冻结输入与计划。准备 agent 未提交本 batch。
3. ROOT 审核后才 `sbatch serve.sbatch`；指定同节点，四小时、exclusive、no-requeue。
   不自动改节点，不自动重提。若节点不可用，等待正常调度，不占用别人的资源。
4. 新 rank deployment 仅表示 launching。ROOT 另查实际 readiness/metadata，
   将新 Audit 三池绑定到真实新 deployment 与新 dump namespace 后再执行。
5. 检验 native 历史/工具路径、graph identity、pending claims=0、原 evaluator 分数、
   每代理完整 raw dump/usage。工程通过与 PoolAct 增益方向分开报告，不以正增益为验收。
6. 最后停止 dispatch、排空并释放新确切 job；保留启动/失败/全部尝试 GPU-hours。

```bash
/lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python -B \
  /lustrefs/users/chufan.shi/codex_space_tn/eval_diagnostics_20260912/serving/glm-continuation/run-server.py --plan
```

本目录的 `deployment.json`、`rank*-deployment.json` 和 exit 文件只在实际启动时
create-only 生成，避免同一路径静默重启。直接 HTTP 无鉴权，仅限可信私网。
一条 srun 持有两 rank；失败清理限定于这个新 step，没有自动模型请求或重跑。

准备期已执行无 GPU 检查：8 个针对 launcher 的测试全部通过；3 个 shell 文件
通过 `bash -n`；实际 `run-server.py --plan` 通过冻结输入检查并正常输出计划，
未创建 deployment。测试覆盖精确两项 argv 差异、UUID 顺序守卫、环境/缓存映射、
不修改调用方环境、输入 hash 拒绝、固定 batch 边界及 plan 无子进程/写入。
这些是启动文件的静态检查，不代表新的 allocation 已提交或真实 serving 已通过。
另一个 agent 已完成独立只读复核并重跑上述 8 项测试，未发现阻止启动的逻辑问题；
明确保留未观察 rank 1 环境、共享 inductor 路径和 RNG 非确定性等边界。
