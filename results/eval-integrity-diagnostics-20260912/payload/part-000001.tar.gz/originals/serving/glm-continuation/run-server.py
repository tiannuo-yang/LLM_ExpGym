"""Frozen GLM continuation launcher; --plan is read-only and never submits/probes."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import time


OUT = Path(__file__).resolve().parent
BASE = OUT.parent / 'glm-baseline'
BASE_JOB = '1205018'
NODES = ['azure-uk-hpc-H200-instance-256', 'azure-uk-hpc-H200-instance-257']
HTTP_PORT = 33460
DIST_PORT = 53460
BASE_PINS = {
    BASE / 'deployment.json': 'd9c13a137a98b3fbef12e24b833369d1a52a24abb5c50dfc0d13a9eb9000ef7a',
    BASE / 'rank0-deployment.json': 'd9c13a137a98b3fbef12e24b833369d1a52a24abb5c50dfc0d13a9eb9000ef7a',
    BASE / 'rank1-deployment.json': '22f5d1fffbb2f28f96faf9c38316dc3a53a168cb75b1034512f17069171c9161',
    OUT / 'baseline-env-observation.json': '13b55ebf4e0935e8b19980744cd503c72b4259be73f89f51bc0a6a833b0f910b',
}
OLD_CACHE = '/tmp/expgym_glm_diag_1205018_rank0'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def baseline():
    for path, expected in BASE_PINS.items():
        if sha(path) != expected:
            raise ValueError('Frozen baseline input changed: ' + str(path))
    ranks = [json.loads((BASE / ('rank' + str(rank) + '-deployment.json')).read_text())
             for rank in (0, 1)]
    for rank, item in enumerate(ranks):
        if item['job_id'] != BASE_JOB or item['rank'] != rank or item['nodes'] != NODES or item['node'] != NODES[rank]:
            raise ValueError('Baseline allocation/rank identity mismatch')
        if len(item['devices']) != 8 or any('NVIDIA H200' not in row for row in item['devices']):
            raise ValueError('Baseline device inventory is not eight H200 per node')
        if item['argv'][item['argv'].index('--random-seed') + 1] != '4200':
            raise ValueError('Baseline effective seed differs from the registered seed')
        if item['argv'][item['argv'].index('--node-rank') + 1] != str(rank):
            raise ValueError('Baseline argv rank mismatch')
    for path, expected in ranks[0]['frozen_input_sha256'].items():
        if sha(Path(path)) != expected:
            raise ValueError('Frozen runtime input changed: ' + path)
    for name, expected in ranks[0]['launcher_source_sha256'].items():
        if sha(BASE / name) != expected:
            raise ValueError('Baseline launcher source changed: ' + name)
    checkpoint = Path(ranks[0]['checkpoint'])
    for name, expected in ranks[0]['checkpoint_metadata_sha256'].items():
        if sha(checkpoint / name) != expected:
            raise ValueError('Checkpoint metadata changed: ' + name)
    if not Path(ranks[0]['argv'][0]).is_file():
        raise ValueError('Frozen SGLang executable is missing')
    observation = json.loads((OUT / 'baseline-env-observation.json').read_text())
    if observation['process_identity']['SLURM_JOB_ID'] != BASE_JOB or observation['process_identity']['SLURM_PROCID'] != '0':
        raise ValueError('Environment observation is not the baseline head process')
    return ranks, observation


def argv_for_rank(rank, ranks):
    if type(rank) is not int or rank not in (0, 1):
        raise ValueError('Exactly two node ranks are supported')
    command = list(ranks[rank]['argv'])
    index = command.index('--dist-init-addr') + 1
    head_ip, old_port = command[index].rsplit(':', 1)
    if old_port != '53440' or command[command.index('--port') + 1] != '33440':
        raise ValueError('Unexpected original diagnostic ports')
    command[index] = head_ip + ':' + str(DIST_PORT)
    command[command.index('--port') + 1] = str(HTTP_PORT)
    return command


def expected_environment(job, rank, observation):
    if not str(job).isdigit() or type(rank) is not int or rank not in (0, 1):
        raise ValueError('Invalid job/rank cache namespace')
    new_root = '/tmp/expgym_glm_continue_' + str(job) + '_rank' + str(rank)
    result = {}
    for key, value in observation['allowlisted_environment'].items():
        if value is not None and (value == OLD_CACHE or value.startswith(OLD_CACHE + '/')):
            value = new_root + value[len(OLD_CACHE):]
        result[key] = value
    return result


def child_environment(job, rank, observation, inherited):
    environment = dict(inherited)
    for key, value in expected_environment(job, rank, observation).items():
        if value is None:
            environment.pop(key, None)
        else:
            environment[key] = value
    return environment


def verify_devices(rank, devices, ranks):
    if devices != ranks[rank]['devices']:
        raise ValueError('Physical GPU UUID/order/name/memory differs from baseline rank ' + str(rank))


def plan():
    ranks, observation = baseline()
    return {
        'classification': 'infrastructure_continuation_plan_not_submitted_not_ready',
        'baseline_job_id': BASE_JOB,
        'slurm': {'account': 'k2p', 'partition': 'higherprio', 'nodes': 2,
                  'nodelist': NODES, 'gpus_per_node': 8, 'cpus_per_task': 32,
                  'time_limit': '04:00:00', 'exclusive': True, 'requeue': False},
        'topology': ranks[0]['topology'], 'model': ranks[0]['model'],
        'checkpoint': ranks[0]['checkpoint'], 'runtime': ranks[0]['runtime'],
        'sampler_modified': ranks[0]['sampler_modified'],
        'checkpoint_metadata_sha256': ranks[0]['checkpoint_metadata_sha256'],
        'model_tensor_payload_hashes_reverified': False,
        'frozen_input_sha256': {str(path): value for path, value in BASE_PINS.items()},
        'original_runtime_input_sha256': ranks[0]['frozen_input_sha256'],
        'rank_argv': [argv_for_rank(rank, ranks) for rank in (0, 1)],
        'expected_devices_per_rank': [item['devices'] for item in ranks],
        'endpoints': ['http://' + NODES[0] + ':' + str(HTTP_PORT) + '/v1'],
        'environment_observation': str(OUT / 'baseline-env-observation.json'),
        'environment_scope': observation['scope'],
        'environment_policy': 'Replay the 39 observed nonsecret configuration keys to both child ranks; transform only the old job/rank cache-root prefix. Other inherited keys are not claimed identical.',
        'inherited_inductor_path_preserved': observation['allowlisted_environment']['TORCHINDUCTOR_CACHE_DIR'],
        'delta_from_baseline': [
            'new allocation/process and wall-time ceiling 02:00:00 -> 04:00:00',
            'same two nodes and all sixteen ordered GPU UUIDs required at launch',
            'HTTP 33440 -> 33460; distributed rendezvous 53440 -> 53460; no other argv change',
            'new serving output and job/rank cache root; inherited inductor path unchanged',
            'same initialization seed 4200 but fresh RNG/cache state and startup timing, not identical RNG consumption',
            'new Audit three-strategy cohort; previous Audit PoolAct retained separately and excluded from the new paired comparison',
        ],
        'bounded_experiment_scope': {
            'old_allocation': 'two original PoolAct pools plus NAS naive/cached controls: four pools, at most 40 model calls',
            'new_allocation': 'Audit PoolAct/naive/cached only: three new pools, at most 30 model calls',
            'combined_max_pools': 7, 'combined_max_model_calls': 70,
            'reason_for_extra_audit_pool': 'allocation wall-time/startup limit, not observed scores',
            'runner_plan_enforcement': 'owned by separately frozen experiment plans; launcher makes no experiment requests',
        },
        'generation_settings': 'Use the separately frozen unchanged Audit runner settings; no reduction of thinking, sampling, output limit or horizon in this launcher',
        'requires_before_submit': 'ROOT must finish/drain old work and stop only owned baseline job 1205018 before submission',
        'network_security': 'no API authentication; trusted private cluster network only',
        'finite_tests_do_not_establish_model_quality_or_desired_score_direction': True,
    }


def write_new(name, value):
    with (OUT / name).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', action='store_true')
    args = parser.parse_args()
    provenance = plan()
    if args.plan:
        print(json.dumps(provenance, indent=2, sort_keys=True))
        return 0
    ranks, observation = baseline()
    job = os.environ['SLURM_JOB_ID']
    if job == BASE_JOB or os.environ.get('SLURM_JOB_NUM_NODES') != '2':
        raise ValueError('A new allocation with exactly two nodes is required')
    rank = int(os.environ['SLURM_PROCID'])
    if rank not in (0, 1):
        raise ValueError('Requires one task on each of two nodes')
    job_info = subprocess.check_output(['scontrol', 'show', 'job', job, '-o'], text=True)
    fields = dict(part.split('=', 1) for part in job_info.split() if '=' in part)
    if fields.get('Account') != 'k2p' or fields.get('Partition') != 'higherprio' or fields.get('NumNodes') != '2' or fields.get('TimeLimit') != '04:00:00':
        raise ValueError('Unexpected Slurm allocation/account/time limit')
    nodes = subprocess.check_output(['scontrol', 'show', 'hostnames', os.environ['SLURM_JOB_NODELIST']], text=True).strip().splitlines()
    host = socket.gethostname().split('.')[0]
    if nodes != NODES or host != NODES[rank]:
        raise ValueError('Continuation must use baseline nodes in the same rank order')
    old_head_ip = ranks[0]['argv'][ranks[0]['argv'].index('--dist-init-addr') + 1].rsplit(':', 1)[0]
    if socket.gethostbyname(NODES[0]) != old_head_ip:
        raise ValueError('Baseline head-node IP changed; needs explicit new identity')
    if (OUT / ('rank' + str(rank) + '-deployment.json')).exists():
        raise FileExistsError('Output already used; no automatic relaunch')
    devices = subprocess.check_output(['nvidia-smi', '--query-gpu=index,uuid,name,memory.total', '--format=csv,noheader'], text=True).strip().splitlines()
    verify_devices(rank, devices, ranks)
    command = argv_for_rank(rank, ranks)
    runtime_environment = child_environment(job, rank, observation, os.environ)
    actual_allowlist = {key: runtime_environment.get(key) for key in observation['allowlisted_environment']}
    if actual_allowlist != expected_environment(job, rank, observation):
        raise ValueError('Prepared child environment differs from the explicit baseline mapping')
    provenance.update({
        'classification': 'infrastructure_continuation_launching_not_ready',
        'job_id': job, 'nodes': nodes, 'rank': rank, 'node': host, 'devices': devices,
        'argv': command, 'allowlisted_child_environment': actual_allowlist,
        'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'launcher_source_sha256': {name: sha(OUT / name) for name in ('run-server.py', 'runtime-env.sh', 'run-rank.sh', 'serve.sbatch')},
        'new_model_requests': 0,
    })
    write_new('rank' + str(rank) + '-deployment.json', provenance)
    if rank == 0:
        write_new('deployment.json', provenance)
    started = time.monotonic()
    process = subprocess.Popen(command, env=runtime_environment)

    def forward(signum, frame):
        if process.poll() is None:
            process.send_signal(signum)

    signal.signal(signal.SIGTERM, forward)
    signal.signal(signal.SIGINT, forward)
    code = process.wait()
    write_new('rank' + str(rank) + '-exit.json', {'returncode': code, 'job_id': job, 'rank': rank,
              'elapsed_seconds': time.monotonic() - started, 'provider_quiescence_proven': False})
    return code if code >= 0 else 128 - code


if __name__ == '__main__':
    raise SystemExit(main())
