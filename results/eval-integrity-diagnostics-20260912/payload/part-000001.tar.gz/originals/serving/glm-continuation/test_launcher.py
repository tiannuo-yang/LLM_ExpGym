"""CPU-only checks; no Slurm, GPU, HTTP, model, or output-file calls."""
import importlib.util
import os
from pathlib import Path
import unittest
from unittest import mock


ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('glm_continuation_launcher', ROOT / 'run-server.py')
launcher = importlib.util.module_from_spec(spec)
spec.loader.exec_module(launcher)


class ContinuationLauncherTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ranks, cls.observation = launcher.baseline()

    def test_plan_never_calls_slurm_gpu_http_or_child(self):
        with mock.patch.object(launcher.subprocess, 'check_output', side_effect=AssertionError('Unexpected subprocess')), \
             mock.patch.object(launcher.subprocess, 'Popen', side_effect=AssertionError('Unexpected child')), \
             mock.patch.object(launcher, 'write_new', side_effect=AssertionError('Unexpected file write')):
            result = launcher.plan()
        self.assertEqual(result['slurm']['nodelist'], launcher.NODES)
        self.assertEqual(result['slurm']['time_limit'], '04:00:00')
        self.assertEqual(result['bounded_experiment_scope']['combined_max_model_calls'], 70)

    def test_argv_changes_exactly_two_port_values(self):
        for rank in (0, 1):
            old = self.ranks[rank]['argv']
            new = launcher.argv_for_rank(rank, self.ranks)
            self.assertEqual(len(old), len(new))
            changes = [index for index, (a, b) in enumerate(zip(old, new)) if a != b]
            self.assertEqual(set(changes), {old.index('--port') + 1, old.index('--dist-init-addr') + 1})
            self.assertEqual(new[new.index('--random-seed') + 1], '4200')
            self.assertEqual(new[new.index('--port') + 1], '33460')
            self.assertEqual(new[new.index('--dist-init-addr') + 1], '10.0.5.4:53460')

    def test_exact_gpu_identity_and_order_required(self):
        for rank in (0, 1):
            launcher.verify_devices(rank, self.ranks[rank]['devices'], self.ranks)
            altered = list(reversed(self.ranks[rank]['devices']))
            with self.assertRaises(ValueError):
                launcher.verify_devices(rank, altered, self.ranks)

    def test_cache_root_changes_but_inherited_inductor_does_not(self):
        expected = launcher.expected_environment('1209999', 1, self.observation)
        self.assertEqual(expected['HF_HOME'], '/tmp/expgym_glm_continue_1209999_rank1/hf')
        self.assertEqual(expected['TRITON_CACHE_DIR'], '/tmp/expgym_glm_continue_1209999_rank1/triton')
        self.assertEqual(expected['TORCHINDUCTOR_CACHE_DIR'], '/tmp/inductor-chufan.shi-1203165')
        self.assertFalse(any(isinstance(value, str) and launcher.OLD_CACHE in value for value in expected.values()))

    def test_environment_restored_without_mutating_caller(self):
        inherited = {'OMP_NUM_THREADS': '99', 'SGLANG_OPT_USE_MULTI_STREAM_OVERLAP': '0',
                     'SLURM_JOB_ID': '1209999', 'OTHER_UNOBSERVED_KEY': 'unchanged'}
        snapshot = dict(inherited)
        result = launcher.child_environment('1209999', 1, self.observation, inherited)
        self.assertEqual(inherited, snapshot)
        self.assertNotIn('OMP_NUM_THREADS', result)
        self.assertNotIn('SGLANG_OPT_USE_MULTI_STREAM_OVERLAP', result)
        self.assertEqual(result['SLURM_JOB_ID'], '1209999')
        self.assertEqual(result['OTHER_UNOBSERVED_KEY'], 'unchanged')
        self.assertEqual(result['CUDA_VISIBLE_DEVICES'], '0,1,2,3,4,5,6,7')

    def test_invalid_rank_and_namespace_rejected(self):
        for rank in (-1, 2, True, '0'):
            with self.assertRaises(ValueError):
                launcher.argv_for_rank(rank, self.ranks)
        for job in ('../old', 'job;echo', '', '12/3'):
            with self.assertRaises(ValueError):
                launcher.expected_environment(job, 0, self.observation)

    def test_frozen_input_mismatch_stops_plan(self):
        with mock.patch.object(launcher, 'sha', return_value='0' * 64):
            with self.assertRaises(ValueError):
                launcher.plan()

    def test_batch_is_fixed_nodes_four_hours_and_no_requeue(self):
        batch = (ROOT / 'serve.sbatch').read_text()
        self.assertIn('#SBATCH --nodelist=azure-uk-hpc-H200-instance-[256-257]', batch)
        self.assertIn('#SBATCH --time=04:00:00', batch)
        self.assertIn('#SBATCH --no-requeue', batch)
        self.assertIn('--kill-on-bad-exit=1', batch)
        self.assertNotIn('scancel', batch)
        self.assertNotIn('curl', batch)


if __name__ == '__main__':
    unittest.main()
