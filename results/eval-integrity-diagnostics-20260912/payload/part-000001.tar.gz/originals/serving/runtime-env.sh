#!/usr/bin/env bash
# Frozen packages; only mutable compilation caches are relocated for diagnosis.
source /lustrefs/users/chufan.shi/codex_space_tn/deepseek_flash_eval_20260911/runtime/runtime-env.sh
DIAG_CACHE_ROOT="/tmp/expgym_diag_${SLURM_JOB_ID:?}_rank${SLURM_PROCID:-0}"
export HF_HOME="$DIAG_CACHE_ROOT/hf"
export HF_MODULES_CACHE="$DIAG_CACHE_ROOT/hf/modules"
export XDG_CACHE_HOME="$DIAG_CACHE_ROOT/cache"
export TRITON_CACHE_DIR="$DIAG_CACHE_ROOT/triton"
export FLASHINFER_WORKSPACE_BASE="$DIAG_CACHE_ROOT/flashinfer"
export TVM_FFI_CACHE_DIR="$DIAG_CACHE_ROOT/tvm"
export SGLANG_DG_CACHE_DIR="$DIAG_CACHE_ROOT/deep_gemm"
export DG_JIT_CACHE_DIR="$SGLANG_DG_CACHE_DIR"
export TILELANG_CACHE_DIR="$DIAG_CACHE_ROOT/tilelang"
export TILELANG_TMP_DIR="$DIAG_CACHE_ROOT/tilelang/tmp"
export CUDA_CACHE_PATH="$DIAG_CACHE_ROOT/cuda-driver"
