"""One frozen GLM TP16 replica; --plan is CPU/read-only, never submits or probes."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import time


OUT = Path(__file__).resolve().parent
WORKSPACE = Path('/lustrefs/users/chufan.shi/codex_space_tn')
ORIGINAL = WORKSPACE / 'portable_eval_20260908/serving/phase_candidates/dual_glm_v1'
ORIGINAL_RUN = ORIGINAL / 'runs/1203652/glm_formal'
RUNTIME = WORKSPACE / 'portable_eval_20260908/serving/runtime_candidates/gumbel_midpoint_v1'
CHECKPOINT = Path('/lustrefs/users/runner/chufan.shi/tau_vision/ckpts/GLM-5.3')
HTTP_PORT = 33440
DIST_PORT = 53440
PINS = {
    ORIGINAL / 'runtime.sh': '96a27aa5ddef554a3e5653968604e2519acec4812e46e25dc6ad5703333def0b',
    ORIGINAL_RUN / 'deployment.json': '2ec929cb976866bc386534d95f2a55cc2ba5c748ddb56d5ad6d77b5c6a08d14b',
    ORIGINAL_RUN / 'replica0-rank0-launch.json': '64a7bacafbadcf49665dc96c72587793ec72649a98c49df2aadedc1ae6cddf89',
    RUNTIME / 'manifests/validation_v6.json': '6ae2baf43591acaad1be8b4f0dfe7fc705996313d1f588ce7cb63990cb892111',
    RUNTIME / '.venv/lib/python3.12/site-packages/sglang/srt/layers/sampler.py':
        '4f8ce718c6bfedb3271900b3066f77ef2ba2d94551ef63bd3dba0f53b1c450e7',
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_pins():
    for path, expected in PINS.items():
        if sha(path) != expected:
            raise ValueError('Frozen input changed: ' + str(path))
    if not (RUNTIME / '.venv/bin/sglang').is_file():
        raise ValueError('Frozen executable is missing')


def argv_for_rank(rank, head_ip):
    if type(rank) is not int or rank not in (0, 1):
        raise ValueError('Exactly two node ranks are supported')
    # Start from the actual old replica-0 command, not a guessed model default.
    command = json.loads((ORIGINAL_RUN / 'replica0-rank0-launch.json').read_text())['command']
    command[0] = str(RUNTIME / '.venv/bin/sglang')
    for flag, value in (
        ('--node-rank', str(rank)),
        ('--dist-init-addr', str(head_ip) + ':' + str(DIST_PORT)),
        ('--port', str(HTTP_PORT)),
    ):
        command[command.index(flag) + 1] = value
    return command


def plan():
    verify_pins()
    old = json.loads((ORIGINAL_RUN / 'deployment.json').read_text())
    return {
        'classification': 'bounded_real_smoke_serving_plan_not_submitted_not_ready',
        'slurm': {'account': 'k2p', 'partition': 'higherprio', 'nodes': 2,
                  'gpus_per_node': 8, 'cpus_per_task': 32, 'time_limit': '02:00:00',
                  'exclusive': True, 'requeue': False},
        'topology': {'replicas': 1, 'tp_size': 16, 'ep_size': 1,
                     'pp_size': 1, 'nodes_per_replica': 2},
        'model': 'glm-5.3', 'checkpoint': str(CHECKPOINT),
        'runtime': str(RUNTIME / '.venv'), 'sampler_modified': True,
        'historical_profile_verbatim': old['profile'],
        'historical_profile_scope': 'contains original four replicas; current topology above is authoritative',
        'frozen_input_sha256': {str(p): digest for p, digest in PINS.items()},
        'rank_argv_templates': [argv_for_rank(rank, 'HEAD_IP') for rank in (0, 1)],
        'delta_from_formal_replica0': [
            'one replica, two nodes total instead of four replicas/eight nodes',
            'same runtime through its direct path instead of the old symlink alias',
            'new allocated nodes, HTTP 33440 and distributed rendezvous 53440',
            'new private output directory and per-job/rank mutable compiler caches',
            'two-hour no-requeue allocation; no router and no automatic model requests',
        ],
        'generation_settings': 'supplied separately by frozen experiment runner; unchanged by this launcher',
        'network_security': 'no API authentication; trusted private cluster network only',
        'finite_tests_do_not_establish_model_quality_or_desired_score_direction': True,
    }


def write_new(name, value):
    with (OUT / name).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', action='store_true')
    args = parser.parse_args()
    provenance = plan()
    if args.plan:
        print(json.dumps(provenance, indent=2, sort_keys=True))
        return 0
    job = os.environ['SLURM_JOB_ID']
    if os.environ.get('SLURM_JOB_NUM_NODES') != '2':
        raise ValueError('Requires exactly two allocated nodes')
    rank = int(os.environ['SLURM_PROCID'])
    if rank not in (0, 1):
        raise ValueError('Requires one task on each of two nodes')
    job_info = subprocess.check_output(['scontrol', 'show', 'job', job, '-o'], text=True)
    fields = dict(part.split('=', 1) for part in job_info.split() if '=' in part)
    if fields.get('Account') != 'k2p' or fields.get('NumNodes') != '2':
        raise ValueError('Unexpected Slurm allocation identity')
    nodes = subprocess.check_output(
        ['scontrol', 'show', 'hostnames', os.environ['SLURM_JOB_NODELIST']], text=True
    ).strip().splitlines()
    host = socket.gethostname().split('.')[0]
    if len(set(nodes)) != 2 or host != nodes[rank].split('.')[0]:
        raise ValueError('Rank/node mapping mismatch')
    if (OUT / ('rank' + str(rank) + '-deployment.json')).exists():
        raise FileExistsError('Output was already used; automatic relaunch is forbidden')
    devices = subprocess.check_output([
        'nvidia-smi', '--query-gpu=index,uuid,name,memory.total', '--format=csv,noheader'
    ], text=True).strip().splitlines()
    if len(devices) != 8 or any('H200' not in row for row in devices):
        raise ValueError('Expected eight H200 devices per node')
    command = argv_for_rank(rank, socket.gethostbyname(nodes[0]))
    provenance.update({
        'classification': 'diagnostic_launching_not_ready', 'job_id': job,
        'nodes': nodes, 'rank': rank, 'node': host, 'devices': devices,
        'argv': command, 'endpoints': ['http://' + nodes[0] + ':' + str(HTTP_PORT) + '/v1'],
        'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'launcher_source_sha256': {name: sha(OUT / name) for name in
                                   ('run-server.py', 'runtime-env.sh', 'run-rank.sh', 'serve.sbatch')},
        'checkpoint_metadata_sha256': {name: sha(CHECKPOINT / name) for name in
                                       ('config.json', 'model.safetensors.index.json', 'tokenizer_config.json')},
        'model_tensor_payload_hashes_reverified': False,
        'new_model_requests': 0,
    })
    write_new('rank' + str(rank) + '-deployment.json', provenance)
    if rank == 0:
        write_new('deployment.json', provenance)
    started = time.monotonic()
    process = subprocess.Popen(command)

    def forward(signum, frame):
        # Only this rank's directly owned process, never a broad pkill/scancel.
        if process.poll() is None:
            process.send_signal(signum)

    signal.signal(signal.SIGTERM, forward)
    signal.signal(signal.SIGINT, forward)
    code = process.wait()
    write_new('rank' + str(rank) + '-exit.json', {
        'returncode': code, 'job_id': job, 'rank': rank,
        'elapsed_seconds': time.monotonic() - started,
        'provider_quiescence_proven': False,
    })
    return code if code >= 0 else 128 - code


if __name__ == '__main__':
    raise SystemExit(main())
