# GLM-5.3 图修复诊断：隔离单副本 TP16

这是供 ROOT review 后提交的启动文件，**尚未提交、不是 ready 证据**。
仅用于已获授权的 bounded real PoolAct smoke；不恢复旧全量实验，不调用付费网关。

原实际执行证据：

- `portable_eval_20260908/serving/phase_candidates/dual_glm_v1/runs/1203652/glm_formal/deployment.json`
- 同目录 `replica0-rank0-launch.json`：实际 rank argv，而非仅计划。
- runtime：`portable_eval_20260908/serving/runtime_candidates/gumbel_midpoint_v1/.venv`。
- 原 sampler 是已记录的修改版，当前 SHA256
  `4f8ce718c6bfedb3271900b3066f77ef2ba2d94551ef63bd3dba0f53b1c450e7`；本次不修改、不切换。

每副本设置保留 TP16 / EP1 / 两节点、context 262144、memory fraction .84、
max-running 64、CUDA graph max batch 64、glm45 reasoning、glm47 tool parser、
FlashInfer sampler、原生 FP8、初始化 seed 4200。每请求 thinking、采样、token cap
由单独冻结的 runner 决定；初始化 seed 不证明跨请求的确定性或独立重复。

本次变化仅为：原四副本缩为单副本（2×8 H200）；新的节点和输出目录；
HTTP 33440 / rendezvous 53440；同 runtime 的直接路径替代旧符号链接别名；
新的 job/rank 编译缓存；两小时时限、禁止自动 requeue。直接 API 无鉴权，仅限
可信集群私网，不复制旧 router 密钥，不修改旧 runtime 或原始结果。

准备时 2026-09-12 00:13:24 UTC，higherprio 中精确 `idle` 状态有 50 个整节点
（400 GPU），包括 228–248 连续区间。`mix/drain` 不计为可用整节点；此快照不是
预约或启动时可用性的保证。batch 不指定旧节点，由 Slurm 重新分配。

ROOT 提交前先执行无 GPU、无请求、无文件写入的检查：

```bash
/lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python -B \
  /lustrefs/users/chufan.shi/codex_space_tn/eval_diagnostics_20260912/serving/glm-baseline/run-server.py --plan
```

实际启动时每 rank 验证 account / 两节点映射 / 八张 H200，核对旧 manifest、
原 argv、runtime setup 和 sampler 指纹，创建独立 rank deployment。一个 srun
拥有两 rank，`--kill-on-bad-exit=1` 限制失败清理在本次 step。没有自动重试、
readiness 探针、模型调用或实验启动。旧 job 1203925 / 1203165 不在本脚本 scope。

部署文件仅证明开始加载；ROOT 需核验 `/health`、实际 server/model metadata，
完成统一 graph smoke 的真实 native-tool、graph ID、pending-claim、独立评分验证。
所有答案（含错误/空答案/负效果）必须保留。功能验收与性能方向分开报告；小型
smoke 不能证明 PoolAct 普遍改进。结束前停止 dispatch 并排空，随后只释放此次
ROOT 提交获得的确切 job ID；完整保存原始 dump / CSV / token usage / GPU-hours。
