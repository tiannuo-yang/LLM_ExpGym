"""Preserve idle GLM control evidence without a health/token-generation request."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import urllib.error
import urllib.request


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=("before-matched", "after-validation"), required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    deployment_bytes = (root / "deployment.json").read_bytes()
    deployment_sha = hashlib.sha256(deployment_bytes).hexdigest()
    assert deployment_sha == "d9c13a137a98b3fbef12e24b833369d1a52a24abb5c50dfc0d13a9eb9000ef7a"
    deployment = json.loads(deployment_bytes)
    assert str(deployment["job_id"]) == "1205018"
    base = deployment["endpoints"][0].removesuffix("/v1")
    assert base == "http://azure-uk-hpc-H200-instance-256:33440"
    output = root / ("control-" + args.phase)
    output.mkdir(mode=0o700, exist_ok=False)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    records = []
    for name, route in (("metrics-before", "/metrics"), ("flush_cache", "/flush_cache"), ("metrics-after", "/metrics")):
        try:
            with opener.open(base + route, timeout=30) as response:
                status, body = response.status, response.read()
        except urllib.error.HTTPError as exc:
            status, body = exc.code, exc.read()
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            status, body = None, type(exc).__name__.encode()
        with (output / (name + ".body")).open("xb") as handle:
            handle.write(body)
        records.append({"route": route, "artifact": name + ".body", "status": status,
                        "at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                        "bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()})
        if status != 200:
            break
    evidence = {"schema": "expgym.glm-idle-control.v1", "deployment_sha256": deployment_sha,
                "job_id": deployment["job_id"], "endpoint": base,
                "phase": args.phase, "task_generation_calls": 0, "health_generation_attempts_maximum": 0,
                "control_requests": records,
                "note": "Only run after all owned task clients finish. A successful SGLang flush confirms running/waiting queues empty at that operation; this is not teardown proof."}
    with (output / "CONTROL.json").open("x") as handle:
        json.dump(evidence, handle, indent=2)
        handle.write("\n")
    print(json.dumps(evidence))
    return 0 if len(records) == 3 and all(row["status"] == 200 for row in records) else 2


if __name__ == "__main__":
    raise SystemExit(main())
