# ROOT 主动收尾与 continuation

2026-09-12 01:57:44 UTC，ROOT 主动 `scancel 1205018`，在全部已派发任务结束之后。
旧作业保存四池：NAS PoolAct、Audit PoolAct、NAS naive、NAS cached，共29次请求，
8/8成员有效计分。NAS三策略MI/BoN均为0.845886747，不声称此处提升。

01:57:17的 `control-after-validation/CONTROL.json` 记录metrics/flush/metrics全200，
无额外health生成；当时队列为空。没有取消正在生成的任务。
旧Audit naive/cached未启动，因为两小时时限中的冷启动约59分钟、Audit约24分钟，
调度器拒绝常规用户延长时限。此续跑决定在原Audit分数产生前作出，不是按结果筛选。

随后ROOT提交job1205034，同节点256/257、同16张H200、4小时时限、同有效运行参数，
端口改为33460/53460，独立输出/cache namespace。新Audit PoolAct/naive/cached三池
形成自己的完整cohort，旧Audit PoolAct仍留存并计入成本，不用作新cohort的对照。

旧allocation实际6136秒×16GPU=27.271111 GPU-hours，按job一次记账，不重复计算step。
本次未停止Deep以外任何无关任务；Deep1205022此前也已由ROOT完整收尾。
