#!/usr/bin/env python3
"""Create-only, bounded, diagnostic PoolAct runs; no model call in plan/validate."""
import argparse
import datetime as dt
import hashlib
import json
import math
import os
from pathlib import Path
import re
import socket
import subprocess
import sys
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parent.parent
REPO = WORKSPACE / "LLM_ExpGym-eval-fixes-20260912"
PYTHON = WORKSPACE / "LLM_ExpGym/.venv/bin/python"
DATA = WORKSPACE / "deepseek_flash_eval_20260911/data"
STRATEGIES = ("poolact",)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_new(path, value):
    with Path(path).open("x", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2, ensure_ascii=False, allow_nan=False)
        handle.write("\n")


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def environment(job=None):
    env = dict(os.environ)
    env.update({"EXPGYM_DATA_ROOT": str(DATA),
                "PHANTOM_WIKI_ROOT": str(DATA / "phantom-wiki"),
                "HPOBENCH_ROOT": str(DATA / "hpo_tuning/HPOBench"),
                "XDG_DATA_HOME": str(DATA / "hpo_tuning/hpobench_data"),
                "PYTHONPATH": str(REPO), "PYTHONNOUSERSITE": "1",
                "PYTHONDONTWRITEBYTECODE": "1", "OMP_NUM_THREADS": "1",
                "MKL_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1",
                "HF_HUB_OFFLINE": "1", "HF_DATASETS_OFFLINE": "1",
                "OPENAI_API_KEY": "EXPGYM_DIAGNOSTIC_PRIVATE_NOAUTH_PLACEHOLDER"})
    if job:
        env.update({"EXPGYM_RUN_ID": job["id"],
                    "EXPGYM_API_DUMP_DIR": job["dump"],
                    "XDG_CACHE_HOME": str(Path(job["root"]) / "runtime/cache"),
                    "XDG_CONFIG_HOME": str(Path(job["root"]) / "runtime/config")})
    return env


def imports():
    os.environ.update(environment())
    os.chdir(REPO)
    sys.path.insert(0, str(REPO))
    from scripts import run_poolact as runner
    return runner


def resolved(runner, argv):
    args = runner.parse_args(argv)
    args = runner._repeat_namespace(args, 0)
    args._evaluation_identity = runner.evaluation_identity(args, REPO)
    budget, _ = runner.resolve_cost_regime(args, runner.resolve_base_cost(args.scenario, args))
    return args, runner._resolved_config(args, budget)


def plan(endpoints, references, output_plan=None):
    # These are intentionally inspected/development tasks, never held-out evidence.
    runner = imports()
    if len(endpoints) != len(references):
        raise ValueError("Each model reference requires its explicitly paired endpoint")
    jobs = []
    profiles = []
    for endpoint, reference in zip(endpoints, references):
        url = urlsplit(endpoint)
        if (url.scheme != "http" or not re.fullmatch(r"azure-uk-hpc-h200-instance-[0-9]+", url.hostname or "")
                or url.path != "/v1" or url.query or url.fragment or url.username or url.password
                or url.port is None or not 1 <= url.port <= 65535):
            raise ValueError("This diagnostic profile is restricted to the private owned cluster endpoint")
        config_ref = json.loads(reference.read_text())["config"]
        model = config_ref["model"]
        stamp = re.sub(r"[^a-zA-Z0-9_-]", "_", model) + "-graph-v4-20260912"
        profiles.append({"model": model, "endpoint": endpoint,
                         "reference_result": str(reference), "reference_sha256": sha(reference)})
        for scenario, label in (("tuning", "nas101_a"), ("evidence_audit", "audit_q0")):
            strategy = "poolact"
            job_id = f"{stamp}-{label}-{strategy}"
            out = ROOT / "runs" / job_id
            argv = ["--backend", "openai", "--model", model,
                    "--base-url", endpoint, "--scenario", scenario,
                    "--tuning-task", "hpobench:nasbench101:A", "--question-index", "0",
                    "--cc-split", "cc-large", "--cost-regime", "cost_tight",
                    "--strategies", strategy, "--agents", "2", "--repeats", "1",
                    "--seed", "2200", "--max-steps", "4", "--max-evals", "3",
                    "--max-context-tokens", str(config_ref["max_context_tokens"]),
                    "--max-tokens", str(config_ref["max_tokens"]),
                    "--temperature", str(config_ref["temperature"]),
                    "--top-p", str(config_ref["top_p"]), "--tool-protocol", "native",
                    "--max-protocol-retries", "1", "--max-retries", "0",
                    "--request-timeout", str(config_ref["request_timeout"]), "--retry-base-seconds", "3",
                    "--retry-max-seconds", "30", "--tuning-final-policy", "legacy",
                    "--missing-final-policy", "task-abstention-v1",
                    "--prompt-cache-key-field", "cache_salt", "--prompt-cache-key", job_id,
                    "--output-dir", str(out / "result")]
            for key, flag in (("reasoning_effort", "--reasoning-effort"), ("top_k", "--top-k")):
                if config_ref.get(key) is not None:
                    argv += [flag, str(config_ref[key])]
            if config_ref.get("chat_template_kwargs") is not None:
                argv += ["--chat-template-kwargs", json.dumps(config_ref["chat_template_kwargs"], separators=(",", ":"))]
            _, config = resolved(runner, argv)
            jobs.append({"id": job_id, "root": str(out), "dump": str(out / "api_dump"),
                         "argv": argv, "config": config, "max_decisions": 10,
                         "max_completion_tokens": 10 * config_ref["max_tokens"]})
    result = {"schema": "expgym.graph-v4-real-smoke.v1", "created_utc": now(),
              "scope": "Real smoke validation; inspected fixed tasks; not formal score replacement",
              "profiles": profiles,
              "repo": str(REPO), "python": str(PYTHON), "helper_sha256": sha(__file__),
              "source_tree_sha256": runner.source_tree_sha256(REPO),
              "git_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip(),
              "jobs": jobs, "max_decisions": sum(j["max_decisions"] for j in jobs),
              "max_completion_tokens": sum(j["max_completion_tokens"] for j in jobs),
              "other_strategies": {"naive": "not_planned_for_smoke", "cached": "not_planned_for_smoke"},
              "acceptance": "Score/integrity, protocol and graph invariants; never improvement direction"}
    target = output_plan or ROOT / "plan.json"
    write_new(target, result)
    print(json.dumps({"plan": str(target), "sha256": sha(target), "jobs": len(jobs)}))


def load_plan(path, digest):
    if sha(path) != digest:
        raise ValueError("Plan hash mismatch")
    value = json.loads(Path(path).read_text())
    if value["helper_sha256"] != sha(__file__):
        raise ValueError("Helper changed since planning")
    return value


def select(value, job_id):
    return next(job for job in value["jobs"] if job["id"] == job_id)


def check_graph_snapshots(keys, snapshots):
    """Check snapshot-local compact aliases against independent complete payload hashes."""
    graph_ids = set()
    for text in snapshots:
        rows = text.split("== Already Explored ==", 1)[-1].split("== Exploration Paths ==", 1)[0]
        aliases = {}
        for line in rows.splitlines():
            found = re.match(r"\s*(E:h:([0-9a-f]{12,64}))\s", line)
            if found:
                alias, suffix = found.groups()
                candidates = [node_id for node_id, value in keys.items()
                              if len(value["canonical"]) > 80 and node_id.removeprefix("E:sha256:").startswith(suffix)
                              and value["display"] in line]
                assert len(candidates) == 1, "Compact alias lacks an exact readable full-payload mapping"
                assert alias not in aliases, "Compact alias reused within snapshot"
                aliases[alias] = candidates[0]
                graph_ids.add(candidates[0])

        def parse_label(line):
            if line.startswith("E:h:"):
                match = re.match(r"E:h:[0-9a-f]{12,64}", line)
                assert match is not None
                alias = match.group()
                assert alias in aliases, "Snapshot edge has no local observation-row mapping"
                return aliases[alias], line[len(alias):]
            assert line.startswith("E:"), "Unexpected non-evaluation path"
            value, end = json.JSONDecoder().raw_decode(line[2:])
            canonical = json.dumps(value, sort_keys=True, separators=(",", ":"))
            assert len(canonical) <= 80 and line[2:2 + end] == canonical, "Truncated or noncanonical short path"
            node_id = "E:sha256:" + hashlib.sha256(canonical.encode()).hexdigest()
            assert node_id in keys, "Graph ID lacks a completed visible tool record"
            assert keys[node_id]["display"] in rows, "Short path has no readable observation row"
            return node_id, line[2 + end:]

        paths = text.split("== Exploration Paths ==", 1)[-1].split("== Coverage Gap ==", 1)[0]
        for line in paths.splitlines():
            if " --> " not in line:
                continue
            left, remainder = parse_label(line.strip())
            assert remainder.startswith(" --> ")
            right, remainder = parse_label(remainder[5:])
            assert remainder.startswith(" ["), "Malformed path suffix"
            graph_ids.update((left, right))
        assert "END:" not in text, "Time-gated graph leaked final-answer node"
        assert "E:sha256:" not in text, "Internal full hash leaked into model-facing graph"
    return graph_ids


def executed_tool_messages(agent):
    messages = []
    for message in agent["messages"]:
        if message["role"] != "tool":
            continue
        if message.get("name") in ("evaluate_config", "human_feedback"):
            messages.append(message)
        else:
            # Native rejected calls are paired with protocol notices, never tool executions.
            content = message.get("content") or ""
            assert content.startswith("Protocol error:") and ". No tool was executed." in content
    return messages


def validate(value, job):
    # Hard no-network guard. Validation must not fall back to runner generation.
    def denied(*args, **kwargs):
        raise RuntimeError("NETWORK_FORBIDDEN_IN_VALIDATION")
    socket.socket.connect = denied
    socket.create_connection = denied
    runner = imports()
    args, config = resolved(runner, job["argv"])
    if config != job["config"] or runner.source_tree_sha256(REPO) != value["source_tree_sha256"]:
        raise ValueError("Frozen config/source/data/dependency identity changed")
    scenario = runner._SCENARIOS[args.scenario]
    tools = runner._resolve_tools(scenario, args)
    evaluator = runner._resolve_answer_evaluator(scenario, args)
    strategy = args.strategies[0]
    output = Path(args.output_dir)
    path = output / strategy / "result.json"
    result = runner._load_resumable_result(path, item_output_dir=output, strategy=strategy,
                    config=config, implementation={"source_tree": value["source_tree_sha256"]},
                    agents=2, answer_evaluator=evaluator, score_tools=tools)
    if result is None:
        raise ValueError("Exact repository result/per-agent/score validator rejected artifacts")
    score = runner.validate_terminal_pool(result, tools, evaluator, scenario=args.scenario, expected_agents=2)
    assert score["execution_complete"], score
    summary = json.loads((output / "summary.json").read_text())
    assert summary["config"] == config
    assert summary["implementation_sha256"] == result["implementation_sha256"]
    assert summary["strategies"] == {strategy: result["aggregate"]}
    from expgym.extras.parallel_cache import _parse_evaluate_config, _parse_human_feedback
    keys, snapshots = {}, []
    agent_rows = []
    for agent in result["agent_results"]:
        assert agent["api_calls"] <= 5
        assert agent["evaluations"] == len(agent["tool_records"]) <= 3
        assert math.isfinite(agent["total_overhead"]) and agent["total_overhead"] >= 0
        assert math.isclose(agent["total_overhead"], agent["eval_time"], abs_tol=1e-8)
        tool_messages = executed_tool_messages(agent)
        assert len(tool_messages) == len(agent["tool_records"]), "Unexpected truncated smoke history"
        for record, message in zip(agent["tool_records"], tool_messages):
            name, payload, feedback = record
            text = message.get("content") or ""
            if "over-budget — result withheld" in text or text.startswith("Observation: Tool error:"):
                continue
            parser = _parse_evaluate_config if name == "evaluate_config" else _parse_human_feedback
            key, display, _ = parser(payload, str(feedback))
            if key:
                node_id = "E:sha256:" + hashlib.sha256(key.encode()).hexdigest()
                assert node_id not in keys or keys[node_id]["canonical"] == key
                keys[node_id] = {"canonical": key, "display": display}
        for message in agent["messages"]:
            text = message.get("content") or ""
            if "[Parallel Exploration —" in text:
                snapshots.append(text.split("[Parallel Exploration —", 1)[1])
        agent_rows.append({"agent_id": agent["agent_id"], "answer_missing": agent["answer"] is None,
                           "answer_perf": agent["answer_perf"], "score_status": agent.get("score_status"),
                           "api_calls": agent["api_calls"], "evaluations": agent["evaluations"],
                           "protocol_failures": agent["protocol_failures"], "termination_reason": agent["termination_reason"]})
    graph_ids = check_graph_snapshots(keys, snapshots)
    graph = (result.get("shared_state") or {}).get("graph")
    if strategy == "poolact":
        assert graph["pending_claims"] == 0
        assert graph["eval_nodes"] == len(keys)
    else:
        assert not snapshots
    dumps = sorted(Path(job["dump"]).glob("*.json"))
    assert len(dumps) == sum(a["http_request_attempts"] for a in result["agent_results"])
    for dump in dumps:
        raw = json.loads(dump.read_text())
        request = raw["request_payload"]
        for key in ("model", "temperature", "top_p", "top_k", "max_tokens", "reasoning_effort", "chat_template_kwargs"):
            assert request.get(key) == config.get(key), (key, dump)
        assert raw["run_id"] == job["id"]
        assert request.get("cache_salt") and "prompt_cache_key" not in request
        assert request.get("tools") and request["tool_choice"] in ("auto", "none")
    receipt = {"schema": "expgym.graph-smoke-validation.v1", "created_utc": now(),
               "job_id": job["id"], "result_sha256": sha(path), "score_check": score,
               "graph_unique_canonical_nodes": len(keys), "graph_ids_observed_in_prompts": len(graph_ids),
               "graph_snapshots": len(snapshots), "graph_path_coverage": "observed" if any(" --> " in x for x in snapshots) else "unobserved",
               "graph_mapping": keys, "agent_rows": agent_rows,
               "raw_attempt_count": len(dumps), "pending_claims": None if graph is None else graph["pending_claims"],
               "scope_limit": "Saved full-node map and visible path-row integrity; synthetic tests cover adversarial timing/cache hits. No performance-sign gate.",
               "inventory": {str(p.relative_to(Path(job["root"]))): {"sha256": sha(p), "bytes": p.stat().st_size}
                             for p in sorted(Path(job["root"]).rglob("*")) if p.is_file()}}
    write_new(Path(job["root"]) / "validation.json", receipt)
    print(json.dumps({"job": job["id"], "execution_complete": True, "score_complete": score["score_complete"],
                      "aggregate": result["aggregate"], "graph_nodes": len(keys), "graph_snapshots": len(snapshots)}))


def run(value, job):
    runner = imports()
    _, config = resolved(runner, job["argv"])
    assert config == job["config"]
    assert runner.source_tree_sha256(REPO) == value["source_tree_sha256"]
    target = Path(job["root"])
    target.mkdir(parents=True, exist_ok=False)
    os.chmod(target, 0o700)
    write_new(target / "execution_started.json", {"started_utc": now(), "job": job,
                                                  "helper_sha256": sha(__file__)})
    with (target / "stdout.log").open("x") as stdout, (target / "stderr.log").open("x") as stderr:
        completed = subprocess.run([str(PYTHON), "scripts/run_poolact.py", *job["argv"]],
                                   cwd=REPO, env=environment(job), stdout=stdout, stderr=stderr)
    write_new(target / "execution_finished.json", {"finished_utc": now(), "returncode": completed.returncode})
    if completed.returncode:
        raise SystemExit(completed.returncode)
    validate(value, job)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("plan")
    p.add_argument("--endpoint", action="append", required=True)
    p.add_argument("--reference-result", action="append", type=Path, required=True,
                   help="Frozen original PoolAct result; pair positional order with --endpoint")
    p.add_argument("--output-plan", type=Path, default=None)
    for command in ("run", "validate"):
        p = sub.add_parser(command)
        p.add_argument("--plan", type=Path, required=True)
        p.add_argument("--sha256", required=True)
        p.add_argument("--job-id", required=True)
        if command == "run":
            p.add_argument("--authorize-real-model", action="store_true", required=True)
    args = parser.parse_args()
    if args.command == "plan":
        return plan(args.endpoint, args.reference_result, args.output_plan)
    value = load_plan(args.plan, args.sha256)
    job = select(value, args.job_id)
    return run(value, job) if args.command == "run" else validate(value, job)


if __name__ == "__main__":
    main()
