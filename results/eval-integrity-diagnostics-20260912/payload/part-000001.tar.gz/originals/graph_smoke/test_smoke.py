import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch

import smoke


class GraphChecks(unittest.TestCase):
    def setUp(self):
        self.canonical = json.dumps({"long": "a" * 100}, separators=(",", ":"))
        digest = hashlib.sha256(self.canonical.encode()).hexdigest()
        self.node = "E:sha256:" + digest
        self.alias = "E:h:" + digest[:12]
        self.keys = {self.node: {"canonical": self.canonical, "display": "a=1"}}

    def snapshot(self, row, path):
        return f"== Already Explored ==\n{row}\n== Exploration Paths ==\n{path}\n== Coverage Gap =="

    def test_mapped_self_loop_is_not_rejected(self):
        text = self.snapshot(f"  {self.alias} a=1 -> 0.5", f"  {self.alias} --> {self.alias} [agents 0]")
        self.assertEqual({self.node}, smoke.check_graph_snapshots(self.keys, [text]))

    def test_unknown_id_rejected(self):
        with self.assertRaisesRegex(AssertionError, "lacks"):
            smoke.check_graph_snapshots({}, [self.snapshot(f"{self.alias} a=1", "")])

    def test_unmapped_edge_rejected(self):
        with self.assertRaises(AssertionError):
            smoke.check_graph_snapshots(self.keys, [self.snapshot("", f"{self.alias} --> {self.alias} [agents 0]")])

    def test_wrong_readable_mapping_rejected(self):
        with self.assertRaisesRegex(AssertionError, "readable"):
            smoke.check_graph_snapshots(self.keys, [self.snapshot(f"{self.alias} a=2", "")])

    def test_mapping_must_be_in_the_same_snapshot(self):
        with self.assertRaisesRegex(AssertionError, "Snapshot"):
            smoke.check_graph_snapshots(self.keys, [self.snapshot(f"{self.alias} a=1", ""), self.snapshot("", f"{self.alias} --> {self.alias} [agents 0]")])

    def test_full_hash_and_end_rejected(self):
        for text in (self.node, "END:anything"):
            with self.subTest(text=text), self.assertRaises(AssertionError):
                smoke.check_graph_snapshots({}, [text])

    def test_short_exact_canonical_json_path_needs_no_added_row_id(self):
        canonical = '{"a":1}'
        node = "E:sha256:" + hashlib.sha256(canonical.encode()).hexdigest()
        text = self.snapshot("  a=1 [agents 0]", f"E:{canonical} --> E:{canonical} [agents 0]")
        self.assertEqual({node}, smoke.check_graph_snapshots({node: {"canonical": canonical, "display": "a=1"}}, [text]))

    def test_truncated_json_path_is_rejected(self):
        with self.assertRaises((AssertionError, json.JSONDecodeError)):
            smoke.check_graph_snapshots(self.keys, [self.snapshot("a=1", 'E:{"a": --> E:{"a": [agents 0]')])

    def test_longer_collision_disambiguated_alias_is_accepted(self):
        alias = self.node.replace("E:sha256:", "E:h:")[:4 + 16]
        text = self.snapshot(f"{alias} a=1", f"{alias} --> {alias} [agents 0]")
        self.assertEqual({self.node}, smoke.check_graph_snapshots(self.keys, [text]))

    def test_empty_coverage_is_allowed_and_not_faked(self):
        self.assertEqual(set(), smoke.check_graph_snapshots({}, []))

    def test_rejected_native_tools_are_not_executed_records(self):
        executed = {"role": "tool", "name": "evaluate_config", "content": "Observation: perf=0"}
        rejected = {"role": "tool", "tool_call_id": "rejected", "content": "Protocol error: Exactly one native tool call is allowed per decision. No tool was executed."}
        self.assertEqual([executed], smoke.executed_tool_messages({"messages": [rejected, executed]}))

    def test_unknown_nameless_tool_message_is_not_silently_dropped(self):
        with self.assertRaises(AssertionError):
            smoke.executed_tool_messages({"messages": [{"role": "tool", "content": "looks plausible"}]})


class PlanningChecks(unittest.TestCase):
    def test_model_parameters_come_from_each_reference_and_caps_are_fixed(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            references = []
            for model, topk, template, cap in (("deep", None, {"thinking": True}, 32768),
                                                ("glm", -1, {"clear_thinking": False}, 16384)):
                ref = root / (model + ".json")
                ref.write_text(json.dumps({"config": {"model": model, "max_context_tokens": 131072,
                                     "max_tokens": cap, "temperature": 1, "top_p": .95,
                                     "request_timeout": 7200,
                                     "top_k": topk, "reasoning_effort": "max",
                                     "chat_template_kwargs": template}}))
                references.append(ref)
            runner = Mock()
            runner.source_tree_sha256.return_value = "source"
            with patch.object(smoke, "ROOT", root), patch.object(smoke, "imports", return_value=runner), \
                 patch.object(smoke, "resolved", side_effect=lambda r, a: (None, {"args": a})), \
                 patch.object(smoke.subprocess, "check_output", return_value="commit\n"):
                smoke.plan(["http://azure-uk-hpc-H200-instance-012:33240/v1",
                            "http://azure-uk-hpc-H200-instance-256:33440/v1"], references)
            plan = json.loads((root / "plan.json").read_text())
            self.assertEqual(4, len(plan["jobs"]))
            self.assertEqual(40, plan["max_decisions"])
            self.assertEqual(20 * (32768 + 16384), plan["max_completion_tokens"])
            self.assertEqual("not_planned_for_smoke", plan["other_strategies"]["cached"])
            for index, job in enumerate(plan["jobs"]):
                args = dict(zip(job["argv"][::2], job["argv"][1::2]))
                self.assertEqual(("poolact", "2", "4", "3"),
                                 tuple(args[x] for x in ("--strategies", "--agents", "--max-steps", "--max-evals")))
                self.assertEqual("0", args["--max-retries"])
                self.assertEqual(index >= 2, "--top-k" in args)

    def test_load_rejects_changed_plan(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "plan.json"
            path.write_text("{}")
            with self.assertRaisesRegex(ValueError, "hash"):
                smoke.load_plan(path, "not-the-hash")


if __name__ == "__main__":
    unittest.main()
