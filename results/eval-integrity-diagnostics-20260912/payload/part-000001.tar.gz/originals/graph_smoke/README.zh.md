# Graph-v4 实际工具链 smoke

分类：**Real smoke validation / 已检查任务上的诊断**，不是正式重跑或性能复现。
只在主 agent 确认 owned 服务 ready 并授权相应调用后执行。脚本不会申请 GPU。

## 固定范围

每模型只跑两池：NASBench101-A、Audit q0；均 `poolact / cost_tight`、N2、seed 2200、
R1、max_steps 4、max_evals 3。每成员最多四次正常决策＋一次 forced final；
每模型最多 20 个模型请求、655360 completion tokens。Naive/Cached 为
`not_planned_for_smoke`，不是正式矩阵缺失。不同模型、任务有独立进程、结果目录、
dump、run ID、服务 prompt-cache namespace。

| 参数 | DeepSeek | GLM |
|---|---|---|
| 原始模型名 | deepseek-v4-flash-0731 | glm-5.3 |
| temperature / top_p / top_k | 1 / 0.95 / 未传 | 1 / 0.95 / 未传 |
| max_tokens / max_context_tokens | 32768 / 131072 | 32768 / 131072 |
| reasoning_effort | max | max |
| chat_template_kwargs | `{"thinking":true}` | `{"clear_thinking":false,"reasoning_effort":"max"}` |
| request_timeout | 7200 秒 | 3600 秒 |

参数读取各模型**真实原 PoolAct result.json 的 config**并绑定文件 SHA，不采用 serving
proposal 中未实际发送的值（例如 GLM proposal 的 top_k=-1）。共用 native tools、
一次正常 step-bounded protocol repair、`legacy` tuning policy、`task-abstention-v1`。
本次显式变更为 N2/4 steps/3 evals、诊断端点/目录、`max_retries=0`；GLM 原无 prompt cache
namespace，本次显式增加隔离的 `cache_salt`。未增加题目、seed 或基于结果重抽。

耗时须按刚测得的请求/输出长度估计。硬 token 上限不是预计用量；若每请求都达
32768 tokens，单模型 PoolAct 串行决策在 50 output tokens/s 下仅输出就约 3.64 小时，
尚未包括 prefill/工具/加载。这个 50 是计算示例，不是测量承诺。主 agent 根据实时
serving 试验及剩余 allocation 时间安排，不以缩短输出或隐藏失败保证完成。

## 验收

1. 原 runner 保存全部两个成员、result/summary、终止证据与原始 HTTP 尝试。
2. 单独禁用网络后，以真实 compact NAS 表 / Audit evaluator 重新核对每个 final 和完整池聚合，
   并核对 source/config/data/dependency identity、独立成员文件、summary。
3. 实际 graph 的完成记录数对应唯一完整 canonical payload；pending=0。
   内部完整 SHA 与模型可见短 alias 分开。可见的每条路径必须在同一个 snapshot 中映射
   到完整可读配置，短 key 的 `E:<完整 JSON>` 不允许截断。cache/cost/time 边界对抗情况
   由定向合成测试补充，不能假称小 smoke 遍历全部并发时序。
4. 保留低分、缺答、多工具拒绝、长度终止及 graph/forced-final/cache-hit 路径未观察到的情况。
   不要求 PoolAct 分数提高，不把该 smoke 替代原正式结果。基础设施正确与模型任务能力
   分开报告；缺少配置的 NAS 完整池仍可以 execution-complete / score-incomplete。

`smoke.py validate` 硬禁止 socket connect，仅使用本地 runner validator；不调用 `main --resume`
而触发补跑。`run` 的目标目录只允许首次新建，失败后不可用同一目录再次发送请求。
native 多工具拒绝产生的 tool-role 协议占位不是真实工具执行，验证器明确区分两者。

## 文件与命令

- `smoke.py`：计划 / 有限实跑 / 禁网络评分与路径复核。
- `test_smoke.py`：计划上限、不同模型参数、短/长 alias、拒绝占位及错误检测的 CPU 单测。
- `plan.json`：fullhash-display 初版计划，**superseded_before_execution**，没有执行；保留审计。
  `plan_compact.json` 也在执行前被新的 Audit native prompt 修复版本替代，两个计划均不覆盖。
- `plan_audit_native_fixed.json`：实际批准 source 下的新 PoolAct-only 计划，commit
  `b3382b1c0b89ef1637e232f4b7eef68d55a54f12`；SHA256
  `0d9392f44ab1d9bb7eeda21c0217920ba16a0a8b124c21e9683b2f337d645af8`。
  是否执行/完成以各 `runs/<job-id>/execution_*.json` 和 validation 原件为准，不能从计划存在推断。
- `matched_strategies/PLAN.zh.md`：同版本、同部署上有限追加 Naive/Cached 的独立方案；
  复用上述已预选 PoolAct 条目，不复制或重跑 PoolAct，不自动提交任何任务。
- `runs/<job-id>/result/{summary.json,poolact/result.json,poolact/agents/agent_*.json}`：实际结果。
- `runs/<job-id>/api_dump/*.json`：原始 request/response/usage 与失败尝试。
- `runs/<job-id>/validation.json`：评分重算、每成员诊断、graph coverage、SHA/size 索引。
- `overhead_complete/{by_pool.csv,summary.json}`：36 NAS + 52 Audit 的初版 fullhash 表示开销。
  初次 `overhead/` 含34个Audit可识别池；之后修正诊断脚本对拒绝占位的处理并完整重算，
  应引用 `overhead_complete/`，不引用前一子集作为完整计数。
- `overhead_compact/{by_pool.csv,summary.json}`：同一88池在最终紧凑表示下的测量；全部
  同 snapshot alias 到完整配置的映射检查通过。相对 v3，NAS 图总 tokens 为
  DeepSeek −5.89%、GPT −6.16%；Audit 52 池逐池 token 数保持不变。

```bash
/lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python -B \
  smoke.py run --plan /absolute/final-plan.json --sha256 RECORDED_SHA256 \
  --job-id EXACT_JOB_ID_FROM_PLAN --authorize-real-model
```

从任意 cwd 调用绝对 helper 路径亦可。主 agent 逐个授权已计划 job 或不同模型各一个并行，
不要在 DeepSeek serving A/B replay 正在执行时混入此 smoke 请求。每次实跑自动跟随本地
独立分数/文件核对，所有工作目录都在该诊断根下，原正式数据与 checkpoint/runtime 不改。

## 表示开销的含义

`measure_graph_overhead.py` 只读原始完整池，在相同已完成记录集上重绘 old/new 终态图，
保留每个 agent 自己的路径顺序，不重建跨 agent 实时交错、pending 或原每次请求历史。
使用本地 DeepSeek tokenizer 对独立 graph 文本精确分词、不含 chat-template specials；
GPT 行也是同一个 tokenizer 的**表示尺寸**测量，不是 GPT billed tokens。
全部88池的数据路径与 SHA 在 CSV；该测量不调用模型、评分器或 GPU。

初版 fullhash 显示使 NAS 图 token 总量增加 DeepSeek 22.9%、GPT 29.9%，Audit 分别约
2.086× 和 2.197×；因此主 agent 在实跑前要求紧凑显示修订。这不是分数筛选：首次方案
没有任何实际模型调用，内部完整身份修复、计分与原数据均保持。修订后的紧凑表示见
`overhead_compact/`。NAS 并非每池都变短：DeepSeek 最大单池 +243 tokens、GPT +44；
一部分边此前被错误合并，修复后恢复正确路径本来就需要表示更多信息。
