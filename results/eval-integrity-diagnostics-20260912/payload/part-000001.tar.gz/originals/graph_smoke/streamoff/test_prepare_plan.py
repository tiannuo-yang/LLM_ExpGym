import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "matched_strategies"))
from test_derive_plan import fixture, resolver_for
import prepare_plan as planner


class CandidatePlanTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.base = fixture()
        self.model = "unfamiliar-model-a"
        self.base["profiles"] = [{"model": model, "endpoint": "http://azure-uk-hpc-H200-instance-012:33240/v1"}
                                 for model in ("unfamiliar-model-a", "unfamiliar-model-b")]
        for job in self.base["jobs"]:
            job["config"]["base_url"] = "http://azure-uk-hpc-H200-instance-012:33240/v1"
        self.runtime = self.root / "runtime.json"
        self.runtime.write_text("{}")
        self.deployment = {"allowlisted_environment": {"SGLANG_OPT_USE_MULTI_STREAM_OVERLAP": "0"},
                           "argv_base_equal_to_baseline": True,
                           "argv": ["sglang", "serve", "--served-model-name", self.model,
                                    "--random-seed", "482082713"],
                           "endpoints": ["http://azure-uk-hpc-H200-instance-012.core42.ai:33240/v1"],
                           "job_id": "new-owned-job", "runtime_manifest": str(self.runtime),
                           "runtime_manifest_sha256": planner.digest(self.runtime)}
        self.deployment_path = self.root / "deployment.json"
        self.deployment_path.write_text(json.dumps(self.deployment))

    def prepare(self, resolver=None):
        return planner.prepare_pool(self.base, Path("/frozen/settings.json"), "bound-sha", self.model,
                                    self.deployment_path, self.deployment, self.root / "candidate",
                                    resolver_for(self.base) if resolver is None else resolver)

    def test_deep_only_new_ids_and_no_baseline_result_reuse(self):
        pool, bindings = self.prepare()
        self.assertEqual(2, len(pool["jobs"]))
        self.assertEqual(20, pool["max_decisions"])
        self.assertEqual(20 * 32768, pool["max_completion_tokens"])
        self.assertEqual({self.model}, set(bindings))
        for job in pool["jobs"]:
            self.assertTrue(job["id"].endswith("-streamoff-poolact"))
            self.assertFalse(job["baseline_result_reused"])
            parent = next(p for p in self.base["jobs"] if p["id"] == job["settings_parent_id"])
            self.assertNotEqual(parent["root"], job["root"])
            self.assertNotEqual(parent["dump"], job["dump"])
            changed = {k for k in parent["config"] if parent["config"][k] != job["config"][k]}
            self.assertEqual({"prompt_cache_key"}, changed)
        self.assertEqual(1, len(pool["profiles"]))
        self.assertIn("HOLD", pool["execution_gate"])

    def test_matched_reuses_only_candidate_pool_and_caps_total60(self):
        pool, bindings = self.prepare()
        matched = planner.derive_plan.derive(pool, self.root / "pool.json", "candidate-pool-hash",
                    self.root / "matched", bindings, resolver_for(pool))
        self.assertEqual(40, matched["max_decisions"])
        self.assertEqual(60, matched["max_decisions"] + pool["max_decisions"])
        self.assertEqual(2, len(matched["reused_poolact"]))
        self.assertTrue(all("-streamoff-" in r["job"]["id"] for r in matched["reused_poolact"]))
        self.assertTrue(all("-streamoff-matched-" in j["id"] for j in matched["jobs"]))

    def test_wrong_multistream_flag_rejected(self):
        self.deployment["allowlisted_environment"]["SGLANG_OPT_USE_MULTI_STREAM_OVERLAP"] = "UNSET"
        with self.assertRaisesRegex(ValueError, "multistream"):
            self.prepare()

    def test_wrong_model_rejected(self):
        self.deployment["argv"][3] = "unfamiliar-model-b"
        with self.assertRaisesRegex(ValueError, "different model"):
            self.prepare()

    def test_unknown_other_argv_delta_rejected(self):
        self.deployment["argv_base_equal_to_baseline"] = False
        with self.assertRaisesRegex(ValueError, "unreviewed"):
            self.prepare()

    def test_changed_initialization_seed_rejected(self):
        self.deployment["argv"][-1] = "1"
        with self.assertRaisesRegex(ValueError, "seed"):
            self.prepare()

    def test_changed_endpoint_node_or_port_rejected(self):
        for endpoint in ("http://azure-uk-hpc-H200-instance-013:33240/v1",
                         "http://azure-uk-hpc-H200-instance-012:33241/v1"):
            with self.subTest(endpoint=endpoint):
                self.deployment["endpoints"] = [endpoint]
                with self.assertRaisesRegex(ValueError, "same-node"):
                    self.prepare()

    def test_generation_change_rejected(self):
        original = resolver_for(self.base)
        def changed(argv):
            value = original(argv)
            value["temperature"] = .7
            return value
        with self.assertRaisesRegex(ValueError, "config changed"):
            self.prepare(changed)

    def test_changed_runtime_manifest_rejected(self):
        self.runtime.write_text('{"version":"changed"}')
        with self.assertRaisesRegex(ValueError, "runtime manifest"):
            self.prepare()

    def test_existing_output_rejected(self):
        parent = next(j for j in self.base["jobs"] if j["config"]["model"] == self.model)
        target = self.root / "candidate/runs" / (parent["id"][:-len("-poolact")] + "-streamoff-poolact")
        target.mkdir(parents=True)
        with self.assertRaises(FileExistsError):
            self.prepare()


if __name__ == "__main__":
    unittest.main()
