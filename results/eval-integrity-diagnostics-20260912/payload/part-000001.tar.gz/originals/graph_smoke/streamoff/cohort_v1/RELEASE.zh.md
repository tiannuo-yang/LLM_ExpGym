# ROOT 实跑放行

2026-09-12 01:37:47 UTC：候选1205022同原输入c4首组8条全部完成，wire/token身份均匹配。
独立全文分类为8连贯、0严重循环、0明显乱码；原runner接受6条，拒绝2条多调用。
这足以进入有限任务smoke，不是根因或总体性能已经证明。

`serving/multistream-off/control-before-task-smokes` 的metadata/metrics/flush成功；
health另计最多1 token探测，不混入8个任务请求。ROOT已完成排空操作。

放行冻结六池：NAS PoolAct → Audit PoolAct → NAS naive → NAS cached → Audit naive → Audit cached。
source/helper/两个plan/deployment保持原绑定，六池最多60请求，不改变长度、评分、预算，
不因正常协议拒绝、低分或负差停止/补抽。框架记录、评分校验错误或明显乱码需立即报root。
全部输出独立保存；allocation截止03:07:06 UTC，根据真实时长留排空空间。
六池结束后交root执行预留后段8请求检查，代理不得混发诊断或取消服务。
