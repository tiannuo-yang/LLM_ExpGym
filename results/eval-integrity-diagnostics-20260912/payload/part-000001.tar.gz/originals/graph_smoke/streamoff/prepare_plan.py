#!/usr/bin/env python3
"""Create new-cohort PoolAct + matched plans from settings only; never executes them."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import re
import sys
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent
SMOKE_ROOT = ROOT.parent
sys.path.insert(0, str(SMOKE_ROOT))
sys.path.insert(0, str(SMOKE_ROOT / "matched_strategies"))
import smoke
import derive_plan


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def normalize_endpoint(value):
    url = urlsplit(value)
    host = (url.hostname or "").removesuffix(".core42.ai")
    if (url.scheme != "http" or not re.fullmatch(r"azure-uk-hpc-h200-instance-[0-9]+", host)
            or url.port is None or url.path != "/v1" or url.query or url.fragment or url.username or url.password):
        raise ValueError("Unexpected private cluster endpoint")
    return host, url.port


def prepare_pool(base, base_path, base_sha, model, deployment_path, deployment,
                 cohort_root, resolver):
    selected = [job for job in base["jobs"] if job["config"]["model"] == model]
    if len(selected) != 2 or {job["config"]["scenario"] for job in selected} != {"tuning", "evidence_audit"}:
        raise ValueError("Exactly the preselected NAS/Audit pair is required")
    profiles = [copy.deepcopy(p) for p in base["profiles"] if p["model"] == model]
    if len(profiles) != 1:
        raise ValueError("One explicit original generation profile is required")
    if deployment.get("allowlisted_environment", {}).get("SGLANG_OPT_USE_MULTI_STREAM_OVERLAP") != "0":
        raise ValueError("Deployment is not the explicit multistream-off candidate")
    if deployment.get("argv_base_equal_to_baseline") is not True:
        raise ValueError("Candidate has an unreviewed serving argv delta")
    argv = deployment["argv"]
    if argv[argv.index("--served-model-name") + 1] != model:
        raise ValueError("Candidate serves a different model")
    if argv[argv.index("--random-seed") + 1] != "482082713":
        raise ValueError("Candidate must explicitly preserve the recorded baseline effective initialization seed")
    endpoints = deployment["endpoints"]
    if len(endpoints) != 1:
        raise ValueError("The diagnostic candidate has exactly one TP8 endpoint")
    jobs = []
    for parent in selected:
        if normalize_endpoint(parent["config"]["base_url"]) != normalize_endpoint(endpoints[0]):
            raise ValueError("Only the same-node/same-port serving-cohort replacement is registered")
        if not parent["id"].endswith("-poolact"):
            raise ValueError("Expected an explicit PoolAct-only parent job ID")
        new_id = parent["id"][:-len("-poolact")] + "-streamoff-poolact"
        output = cohort_root / "runs" / new_id
        if output.exists():
            raise FileExistsError("Candidate output already exists; never reuse or overwrite it")
        new_argv = list(parent["argv"])
        for flag, value in (("--output-dir", output / "result"), ("--prompt-cache-key", new_id)):
            new_argv = derive_plan.replace_option(new_argv, flag, value)
        actual = resolver(new_argv)
        expected = copy.deepcopy(parent["config"])
        expected["prompt_cache_key"] = new_id
        if actual != expected:
            raise ValueError("Model/task/budget/source-dependent config changed outside cohort namespaces")
        jobs.append({"id": new_id, "root": str(output), "dump": str(output / "api_dump"),
                     "argv": new_argv, "config": actual, "max_decisions": 10,
                     "max_completion_tokens": 10 * actual["max_tokens"],
                     "settings_parent_id": parent["id"], "baseline_result_reused": False})
    binding = {"deployment_file": str(deployment_path), "sha256": digest(deployment_path),
               "job_id": deployment["job_id"], "cohort": "deepseek-multistream-off-20260912",
               "pool_same_deployment_bound": True,
               "binding_scope": "Prospective same-candidate binding; real requests require ROOT release after c4 diagnostic. No baseline PoolAct result reuse.",
               "runtime_manifest": deployment["runtime_manifest"],
               "runtime_manifest_sha256": deployment["runtime_manifest_sha256"]}
    if digest(binding["runtime_manifest"]) != binding["runtime_manifest_sha256"]:
        raise ValueError("Frozen serving runtime manifest changed")
    plan = {"schema": "expgym.graph-v4-candidate-smoke.v1", "created_utc": smoke.now(),
            "scope": "New DeepSeek serving candidate custom smoke; no baseline PoolAct artifact reuse",
            "profiles": profiles, "repo": base["repo"], "python": base["python"],
            "helper_sha256": base["helper_sha256"], "source_tree_sha256": base["source_tree_sha256"],
            "git_commit": base["git_commit"], "planner_sha256": digest(__file__),
            "settings_parent_plan": str(base_path), "settings_parent_plan_sha256": base_sha,
            "settings_parent_scope": "Settings only. Baseline DeepSeek PoolAct executions=0 as reported by ROOT; no scores or dumps copied.",
            "serving_bindings": {model: binding}, "jobs": jobs,
            "max_decisions": sum(job["max_decisions"] for job in jobs),
            "max_completion_tokens": sum(job["max_completion_tokens"] for job in jobs),
            "execution_gate": "HOLD until ROOT releases after fixed v2 c4 ≤8-request serving diagnostic. Deployment-file existence is not readiness or validation.",
            "acceptance": "Real task/native/graph/scoring integrity, not positive score or PoolAct improvement",
            "later_matched_scope": "Same new-cohort PoolAct2 + Naive/Cached4 only; all ≤60 requests. Never cross-cohort contrasts."}
    return plan, {model: binding}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--settings-plan", type=Path, required=True)
    parser.add_argument("--settings-plan-sha256", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--deployment", type=Path, required=True)
    parser.add_argument("--cohort-root", type=Path, required=True)
    args = parser.parse_args()
    base = derive_plan.load_pool_plan(args.settings_plan, args.settings_plan_sha256)
    runner = smoke.imports()
    if runner.source_tree_sha256(smoke.REPO) != base["source_tree_sha256"]:
        raise ValueError("Evaluation source differs from the frozen settings parent")
    deployment = json.loads(args.deployment.read_text())
    cohort_root = args.cohort_root.resolve()
    if cohort_root.exists():
        raise FileExistsError("Cohort artifact root must be fresh")
    resolver = lambda argv: smoke.resolved(runner, argv)[1]
    pool, bindings = prepare_pool(base, args.settings_plan.resolve(), args.settings_plan_sha256,
                                  args.model, args.deployment.resolve(), deployment, cohort_root, resolver)
    # Freeze both manifests before any real call. No run command exists in this planner.
    cohort_root.mkdir(parents=True, exist_ok=False)
    pool_path = cohort_root / "pool_plan.json"
    smoke.write_new(pool_path, pool)
    smoke.write_new(cohort_root / "same_serving_bindings.json", bindings)
    matched = derive_plan.derive(pool, pool_path, digest(pool_path), cohort_root / "matched_runs", bindings, resolver)
    matched["serving_candidate"] = "multistream-off"
    matched["execution_gate"] = pool["execution_gate"]
    matched["all_six_pool_request_cap"] = 60
    matched["baseline_pool_reuse"] = False
    matched_path = cohort_root / "matched_plan.json"
    smoke.write_new(matched_path, matched)
    assert pool["max_decisions"] == 20 and matched["max_decisions"] == 40
    print(json.dumps({"pool_plan": str(pool_path), "pool_sha256": digest(pool_path),
                      "matched_plan": str(matched_path), "matched_sha256": digest(matched_path),
                      "serving_job_id": deployment["job_id"], "max_model_requests": 60,
                      "execution_gate": "ROOT release still required"}))


if __name__ == "__main__":
    main()
