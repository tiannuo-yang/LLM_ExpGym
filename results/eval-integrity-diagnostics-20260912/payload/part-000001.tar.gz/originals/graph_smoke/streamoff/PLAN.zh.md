# DeepSeek multistream-off 新 cohort：有限 PoolAct 与 matched smoke

**状态：只准备计划；不得执行，直到 ROOT 完成固定 v2/c4 最多8请求诊断并 release。**
部署文件写出不代表服务 ready、输出正常或问题已修复；也不能按任务分数决定是否补抽。

ROOT 已确认 baseline 作业1205016的24个 serving 诊断请求结束、排空并主动停止，
其中并发4的原输入复现仍有乱码/循环退化。旧 b338 计划中的 **DeepSeek PoolAct池执行数为0**；
旧计划/原诊断证据均保持，不把终止的 baseline 计划标成完成。GLM继续其原 b338 cohort，
不修改它的运行、目录或计划。

## 唯一新 serving cohort

候选作业1205022在同节点012、同8块H200、同checkpoint及冻结runtime启动。
模型多stream开关明确设为 `SGLANG_OPT_USE_MULTI_STREAM_OVERLAP=0`；
`--random-seed 482082713` 是显式保留 baseline 记录的有效初始化seed，不代表相同RNG状态。
实际 argv/env、runtime SHA、GPU UUID 与其他新进程/cache差异已记录在
`serving/multistream-off/deployment.json`。计划绑定其实际文件 SHA，且同端口33240，
不因 URL 字符串未变就把两套 server 当同 cohort。

## 固定新执行范围

原 evaluation source仍为 `b3382b1c0b89ef1637e232f4b7eef68d55a54f12`，runtime source SHA
`e96575475b66e9e25b59115301dee10d04850a1f14f9d6b4d499f0651da47a78`；原 frozen
`smoke.py` 和 `matched_strategies/derive_plan.py` 不改。新 planner只读取旧计划的设置，
不读取原答案/gold选择题目，不复用 baseline PoolAct 结果。

每个策略固定 NASBench101-A 与 Audit q0，cost_tight、N2、R1、seed2200、steps4/evals3；
Deep原 T1/top_p.95/top_k未传、effort=max、thinking=true、32768 max_tokens、131072本地
context cap、native tool/policy/评分/时间预算原样。只修改新 cohort 的 ID、cache namespace
和输出位置；所有 PoolAct job ID 明确以 `-streamoff-poolact` 结尾。

先执行两个新PoolAct池，最多20请求；然后同一候选cohort的Naive/Cached各两个池，
最多40额外请求；六池总计 **≤60模型请求、1966080 completion tokens上限**。
调用上限不等于预计时长，不能为了赶 allocation 时限私自缩短思考/输出或重试坏答。
附加比较只复用这两个新candidate PoolAct池，不引用baseline输出。六池全保留正/负/零/缺答；
NAS缺配置仍保持完整MI/BoN unknown，Audit缺答走原空预测评分。

规划目录 `streamoff/cohort_v1/` 下：

- `pool_plan.json`：仅两个新PoolAct job。
- `matched_plan.json`：仅四个新Naive/Cached job；`reused_poolact` 只引用上述candidate两池。
- `same_serving_bindings.json`：同candidate部署的前瞻约束，不是实跑完成断言。
- `runs/<...-streamoff-poolact>/` 与 `matched_runs/<...-streamoff-matched-strategy>/`：
  各自独立原dump、日志、终止证据与独立评分验证文件。所有baseline和GLM文件保持原位。

报告使用候选cohort自身三策略绝对值、PoolAct−Naive/Cached；分别记录serving异常、
native协议完整性、graph路径、missing与任务分数，不以得分为bug修复验收。
没有随机化策略次序，seed标签不保证独立/可重复；两任务、小horizon的custom smoke不替代
论文完整矩阵，也不证明所有模型均改善。不得跨baseline/candidate拼接策略比较。

## 生成与执行分离

`prepare_plan.py` 只有计划生成功能，没有模型/Slurm/HTTP调用路径；要求实际deployment文件
已存在，检查env开关、模型、显式初始化seed、同端点、原runtime清单SHA及source/config身份。
根目录必须新建，不覆盖历史输出。CPU测试使用合成配置，包含陌生模型名、ID/目录隔离、
不当参数变化拒绝以及60请求边界。

执行使用不变的 `smoke.py run --plan ... --sha256 ... --job-id ... --authorize-real-model`，
但只在 ROOT 明确 release 后发起。ROOT会在阶段切换前排空并记录cache处理，不在执行中
混入诊断请求或清理缓存。事后需用实际运行记录核对所有六池确实来自同candidate部署。
