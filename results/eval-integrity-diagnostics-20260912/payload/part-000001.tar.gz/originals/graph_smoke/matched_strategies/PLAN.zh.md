# 有限 matched-strategy 追加方案（已绑定 / 未执行）

类别：**固定、已检查任务上的 custom smoke**。不是论文重跑，不承诺正向效果。
Audit task-owned prompt 修复已由主 agent 冻结为
`b3382b1c0b89ef1637e232f4b7eef68d55a54f12`，runtime source SHA
`e96575475b66e9e25b59115301dee10d04850a1f14f9d6b4d499f0651da47a78`。
本目录 `plan_audit_native_fixed.json` 引用上一级同名 PoolAct-only plan 并派生补充 jobs；
生成计划未发送任何模型请求。上一级 `plan.json`、`plan_compact.json` 均未执行并被替代，
不继承为已完成证据。

## 固定比较与调用预算

每模型固定 NASBench101-A 与 Audit q0，`cost_tight / N2 / R1 / seed2200`，
max_steps4、max_evals3。对每个任务预先保留三策略 `naive/cached/poolact`。
复用最终 source 下即将执行、预先选定的 PoolAct 两池，只追加 Naive/Cached 四池。
每成员最多四次普通决定＋一次 forced final，`max_retries=0`；**每模型最多40额外请求、
1310720额外 completion tokens**（两模型现均 max_tokens32768）。这是最坏上限，不是预计用量。

各模型原 temperature/top_p/top_k、thinking、reasoning_effort、max_tokens、
context cap、missing/tuning policy、数据/评分器/预算严格继承最终 PoolAct plan。
Naive/Cached只改变算法策略与隔离目录/cache命名，不改模型参数或任务提示。
请求 seed 2200/2201 不证明生成可重复或相互独立；池内两个成员不是两个 outer repeats。

## 复用 PoolAct 的硬条件

必须逐任务核对最终源代码与协议、数据/依赖、实际 generation 参数、预算，以及
checkpoint、runtime、serving flags、deployment 完全相同。不能把 serving A/B 候选的
PoolAct 和不同 baseline 下的 Naive/Cached 配在一起。用部署文件的 SHA 及实际运行记录
确认同一 serving cohort；端点字符串相同本身不证明模型/runtime未更换。

只按已冻结的两任务/两模型清单复用，所有负分、缺答、格式失败及执行失败都保留。
如果既定 PoolAct 缺配置，则 NAS全池比较为 unknown；不得换成功seed补位或改成已有成员均值。
如果条件不满足，应明确该 matched 对照尚不能成立，另报新计划；不得偷偷重跑 PoolAct
使本次40额外请求上限变成60。

## 实现与隔离

已审计 frozen `smoke.py`：只有 planner 写死 PoolAct；`run()` / `validate()` 本身支持
单策略 Naive/Cached。后两者核对无 graph injection、正常 shared-state 和原 repository
final/aggregate evaluator。因此保留 frozen helper 和旧计划不改，新 `derive_plan.py`
只派生补充计划，**脚本没有 model/run 调用路径**。可执行计划仍绑定原 helper SHA。

目录建议 `matched_strategies/runs/<model-task-matched-strategy>/`；每池独立进程、
coordinator/cache、run ID、raw dump 与服务 cache_salt。PoolAct原文件只引用，不复制/重写。
每任务顺序固定 naive 后 cached；可以只在不同模型间并行。补充phase开始前由主 agent
排空 owned 服务并记录 cache flush，绝不对正在执行的请求清缓存。顺序、server随机性
与调度仍是限制，不能声称随机化因果估计。

## 数值交付

每池所有成员都由真实 compact NAS/Audit evaluator 完成保存与独立重新评分；使用
frozen helper 的禁网络 `validate()` 核对文件和分数。报告按模型×任务给全部三策略绝对值：

- NAS：raw accuracy MI、BoN（两者皆需完整N2配置；不偷偷零填充）。
- Audit：evidence accuracy MI/MV 为主，label accuracy MI/MV为辅；不把`answer_perf`的
  label accuracy误叫evidence accuracy。缺答保留原null，使用原空预测评分，而非统一常数。
- 对各指标导出 PoolAct−Naive、PoolAct−Cached，任何负值/零/unknown均保留。
- 同时输出 execution_complete/score_complete、成员缺答数、评估次数、模型请求/usage、
  模拟反馈成本与实测wall time。缺失usage不是0，模拟成本不是GPU墙钟时间。

主表不用具体 question ID 展开；详细CSV保留pool/job/source/raw路径和精确数据身份。
交付一张三策略绝对值与差值表、详细 per-pool/per-agent CSV、原dump/validation索引。
这些数值只能描述两个固定任务、N2、小horizon上的策略行为，不能替代完整矩阵或证明
“所有模型 PoolAct 稳定提升”。即便吻合总体结论，仍执行一次独立数值/逻辑复核。

## 冻结命令（source release 后）

```bash
/lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python -B derive_plan.py \
  --pool-plan /absolute/final-pool-plan.json --pool-plan-sha256 FINAL_POOL_PLAN_SHA \
  --serving-bindings /absolute/same-serving-bindings.json \
  --output /absolute/matched-strategy-plan.json \
  --output-root /absolute/matched_strategies/runs
```

`same-serving-bindings.json` 明确按模型给 `deployment_file`、`sha256`、
`pool_same_deployment_bound:true`；这是前瞻性的同部署约束，不是假称已经观察到执行。
实跑后仍需日志证明各策略确实来自该部署；脚本不会用端点相同替代实际身份核对。
计划生成只读 source/config/deployment 身份，不发送网络/模型请求。
每个新job授权执行时可直接调用原 frozen `smoke.py run --plan ... --sha256 ... --job-id ...`
并显式加 `--authorize-real-model`。不要批量重新执行 `reused_poolact` 条目。
