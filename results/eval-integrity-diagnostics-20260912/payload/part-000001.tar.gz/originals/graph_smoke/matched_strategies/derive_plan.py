#!/usr/bin/env python3
"""Derive a create-only bounded Naive/Cached supplement; NEVER invokes a model."""
import argparse
import copy
import datetime as dt
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
SMOKE_ROOT = ROOT.parent
sys.path.insert(0, str(SMOKE_ROOT))
import smoke


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def replace_option(argv, flag, value):
    if argv.count(flag) != 1:
        raise ValueError(f"Expected exactly one {flag}")
    output = list(argv)
    index = output.index(flag)
    output[index + 1] = str(value)
    return output


def load_pool_plan(path, expected):
    if digest(path) != expected:
        raise ValueError("PoolAct plan SHA256 mismatch")
    plan = json.loads(path.read_text())
    if plan["helper_sha256"] != digest(smoke.__file__):
        raise ValueError("Frozen smoke helper differs from the PoolAct plan")
    if not plan.get("jobs"):
        raise ValueError("PoolAct plan is empty")
    return plan


def derive(pool_plan, pool_plan_path, pool_plan_sha256, output_root, serving_bindings, resolver):
    """Pure plan transformation; resolver is the existing no-model config resolver."""
    jobs, reused, matches = [], [], []
    models = {job["config"]["model"] for job in pool_plan["jobs"]}
    if set(serving_bindings) != models:
        raise ValueError("Exactly one explicit same-deployment binding per model is required")
    identities = set()
    per_model_scenarios = {model: set() for model in models}
    for pool in pool_plan["jobs"]:
        config = pool["config"]
        if (config["strategies"] != ["poolact"] or config["agents"] != 2
                or config["repeats"] != 1 or config["seed"] != 2200
                or config["max_steps"] != 4 or config["max_evals"] != 3
                or config["cost_regime"] != "cost_tight" or config["max_retries"] != 0):
            raise ValueError("Parent plan does not match the fixed N2/R1/4-step/3-eval smoke")
        scenario = config["scenario"]
        if scenario == "tuning":
            if config["tuning_task"] != "hpobench:nasbench101:A":
                raise ValueError("Only the already selected NASBench101-A task is in scope")
        elif scenario != "evidence_audit" or config["question_index"] != 0:
            raise ValueError("Only the already selected Audit q0 is in scope")
        pair = (config["model"], scenario)
        if pair in identities:
            raise ValueError("Duplicate parent model/scenario pool")
        identities.add(pair)
        per_model_scenarios[config["model"]].add(scenario)
        reused.append({"job": copy.deepcopy(pool), "mode": "reuse_preselected_pool_plan_entry",
                       "include_outcomes": "all; negative/missing/failure stays in planned accounting",
                       "pool_parent_plan_sha256": pool_plan_sha256})
        group = {"model": config["model"], "scenario": scenario,
                 "poolact": pool["id"], "naive": None, "cached": None}
        for strategy in ("naive", "cached"):
            new_id = pool["id"].removesuffix("-poolact") + "-matched-" + strategy
            target = output_root / new_id
            if target.exists():
                raise FileExistsError(f"New independent strategy output already exists: {target}")
            argv = pool["argv"]
            for flag, value in (("--strategies", strategy), ("--output-dir", target / "result"),
                                ("--prompt-cache-key", new_id)):
                argv = replace_option(argv, flag, value)
            actual = resolver(argv)
            expected = copy.deepcopy(config)
            expected.update(strategies=[strategy], prompt_cache_key=new_id)
            if actual != expected:
                changed = sorted(key for key in set(actual) | set(expected) if actual.get(key) != expected.get(key))
                raise ValueError(f"Derived config changed outside registered strategy/namespace delta: {changed}")
            jobs.append({"id": new_id, "root": str(target), "dump": str(target / "api_dump"),
                         "argv": argv, "config": actual, "max_decisions": 10,
                         "max_completion_tokens": 10 * config["max_tokens"],
                         "paired_pool_job_id": pool["id"]})
            group[strategy] = new_id
        matches.append(group)
    if any(scenarios != {"tuning", "evidence_audit"} for scenarios in per_model_scenarios.values()):
        raise ValueError("Each model requires exactly the two preselected scenarios")
    budgets = {model: {"extra_pools": sum(j["config"]["model"] == model for j in jobs),
                       "max_extra_requests": sum(j["max_decisions"] for j in jobs if j["config"]["model"] == model),
                       "max_extra_completion_tokens": sum(j["max_completion_tokens"] for j in jobs if j["config"]["model"] == model)}
               for model in sorted(models)}
    assert all(value["extra_pools"] == 4 and value["max_extra_requests"] == 40 for value in budgets.values())
    return {"schema": "expgym.matched-strategy-smoke.v1", "created_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
            "scope": "Fixed inspected task custom smoke; no paper-exact claim or universal improvement gate",
            "helper_sha256": pool_plan["helper_sha256"], "planner_sha256": digest(__file__),
            "source_tree_sha256": pool_plan["source_tree_sha256"], "git_commit": pool_plan["git_commit"],
            "repo": pool_plan["repo"], "python": pool_plan["python"], "profiles": pool_plan["profiles"],
            "pool_parent_plan": str(pool_plan_path), "pool_parent_plan_sha256": pool_plan_sha256,
            "serving_bindings": serving_bindings, "reused_poolact": reused, "jobs": jobs,
            "matches": matches, "budgets": budgets,
            "max_decisions": sum(j["max_decisions"] for j in jobs),
            "max_completion_tokens": sum(j["max_completion_tokens"] for j in jobs),
            "execution_order": "Within each preselected parent task, naive then cached; root may interleave different models only. No strategy-order randomization claim.",
            "cache_policy": "Fresh per-pool run/output/cache_salt. Root drains and records owned-server flush before the supplemental phase; never flush in-flight requests.",
            "reuse_requirements": ["same source/protocol/data/evaluator/budget/sampling and frozen helper",
                                   "same checkpoint/runtime/serving flags/deployment as the already selected PoolAct run",
                                   "all preselected PoolAct outcomes retained; no score/valid-answer-based selection",
                                   "if serving or source changed, do not reuse across revisions or silently rerun PoolAct"],
            "report_metrics": {"tuning": ["raw_accuracy_mi", "raw_accuracy_best_of_n"],
                               "evidence_audit": ["evidence_accuracy_mi", "evidence_accuracy_mv", "label_accuracy_mi", "label_accuracy_mv"]},
            "comparison_orientation": "poolact-minus-naive and poolact-minus-cached; retain negative, positive and unknown",
            "missing_policy": "Original task-abstention-v1; missing NAS configuration keeps full MI/BoN unknown, no zero or available-member substitution. Audit raw null stays null and original empty-prediction score remains data.",
            "seed_scope": "Seeds2200/2201 label member requests only; no verified independent or repeatable sampling. N2 agents are not two independent outer repeats.",
            "causal_scope": "Serving nondeterminism, strategy order and small N remain; not randomized causal superiority evidence."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pool-plan", type=Path, required=True)
    parser.add_argument("--pool-plan-sha256", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--serving-bindings", type=Path, required=True,
                        help="Explicit JSON model→{deployment_file,sha256,pool_same_deployment_bound}; prospective binding, not proof of execution")
    args = parser.parse_args()
    pool = load_pool_plan(args.pool_plan, args.pool_plan_sha256)
    runner = smoke.imports()
    if runner.source_tree_sha256(smoke.REPO) != pool["source_tree_sha256"]:
        raise ValueError("Current source does not match the final PoolAct parent plan")
    bindings = json.loads(args.serving_bindings.read_text())
    for model, binding in bindings.items():
        if (binding.get("pool_same_deployment_bound") is not True
                or digest(binding["deployment_file"]) != binding["sha256"]):
            raise ValueError(f"Missing/changed explicit same-serving identity for {model}")
    result = derive(pool, args.pool_plan.resolve(), args.pool_plan_sha256,
                    args.output_root.resolve(), bindings,
                    lambda argv: smoke.resolved(runner, argv)[1])
    result["serving_bindings_file"] = str(args.serving_bindings.resolve())
    result["serving_bindings_sha256"] = digest(args.serving_bindings)
    smoke.write_new(args.output, result)
    print(json.dumps({"plan": str(args.output), "sha256": digest(args.output), "budgets": result["budgets"]}))


if __name__ == "__main__":
    main()
