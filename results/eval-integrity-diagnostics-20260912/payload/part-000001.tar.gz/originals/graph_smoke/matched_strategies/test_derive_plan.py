import copy
from pathlib import Path
import tempfile
import unittest

import derive_plan as planner


def fixture():
    jobs = []
    for model in ("unfamiliar-model-a", "unfamiliar-model-b"):
        for scenario in ("tuning", "evidence_audit"):
            job_id = f"{model}-{scenario}-poolact"
            config = {"model": model, "scenario": scenario, "strategies": ["poolact"],
                      "agents": 2, "repeats": 1, "seed": 2200, "max_steps": 4,
                      "max_evals": 3, "max_retries": 0, "cost_regime": "cost_tight",
                      "tuning_task": "hpobench:nasbench101:A", "question_index": 0,
                      "prompt_cache_key": job_id, "max_tokens": 32768,
                      "temperature": 1, "reasoning_effort": "max", "top_p": .95,
                      "evaluation_identity": {"sha256": "selected-data"}}
            argv = ["--model", model, "--scenario", scenario, "--strategies", "poolact",
                    "--output-dir", f"/frozen/original/{job_id}/result", "--prompt-cache-key", job_id]
            jobs.append({"id": job_id, "config": config, "argv": argv,
                         "root": f"/frozen/original/{job_id}", "dump": f"/frozen/original/{job_id}/api_dump"})
    return {"jobs": jobs, "helper_sha256": "frozen-helper", "source_tree_sha256": "source",
            "git_commit": "commit", "repo": "/source/repo", "python": "/verified/python", "profiles": []}


def resolver_for(pool):
    configs = {(j["config"]["model"], j["config"]["scenario"]): j["config"] for j in pool["jobs"]}
    def resolve(argv):
        args = dict(zip(argv[::2], argv[1::2]))
        config = copy.deepcopy(configs[(args["--model"], args["--scenario"])])
        config.update(strategies=[args["--strategies"]], prompt_cache_key=args["--prompt-cache-key"])
        return config
    return resolve


class DerivePlanTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.pool = fixture()
        self.bindings = {model: {"same_deployment": "explicit-fixture"}
                         for model in ("unfamiliar-model-a", "unfamiliar-model-b")}

    def derive(self, pool=None, resolver=None, bindings=None):
        pool = self.pool if pool is None else pool
        return planner.derive(pool, Path("/frozen/pool-plan.json"), "bound-plan-sha", self.root,
                              self.bindings if bindings is None else bindings,
                              resolver_for(pool) if resolver is None else resolver)

    def test_only_naive_cached_are_new_and_poolact_all_reused_without_outcome_reads(self):
        result = self.derive()
        self.assertEqual(8, len(result["jobs"]))
        self.assertEqual(4, len(result["reused_poolact"]))
        self.assertEqual(80, result["max_decisions"])
        self.assertEqual(80 * 32768, result["max_completion_tokens"])
        self.assertEqual({"naive", "cached"}, {job["config"]["strategies"][0] for job in result["jobs"]})
        for budget in result["budgets"].values():
            self.assertEqual(40, budget["max_extra_requests"])
            self.assertEqual(4, budget["extra_pools"])
        self.assertEqual(8, len({j["root"] for j in result["jobs"]}))
        self.assertEqual(8, len({j["dump"] for j in result["jobs"]}))
        self.assertEqual(8, len({j["config"]["prompt_cache_key"] for j in result["jobs"]}))
        self.assertEqual(self.pool["jobs"], [entry["job"] for entry in result["reused_poolact"]])
        self.assertEqual("frozen-helper", result["helper_sha256"])

    def test_only_strategy_and_prompt_namespace_change_in_config(self):
        result = self.derive()
        parents = {j["id"]: j for j in self.pool["jobs"]}
        for job in result["jobs"]:
            parent = parents[job["paired_pool_job_id"]]
            keys = {key for key in parent["config"] if parent["config"][key] != job["config"][key]}
            self.assertEqual({"strategies", "prompt_cache_key"}, keys)

    def test_changed_horizon_rejected(self):
        self.pool["jobs"][0]["config"]["max_steps"] = 30
        with self.assertRaisesRegex(ValueError, "fixed"):
            self.derive()

    def test_changed_task_rejected(self):
        self.pool["jobs"][0]["config"]["tuning_task"] = "hpobench:nasbench101:B"
        with self.assertRaisesRegex(ValueError, "NASBench101-A"):
            self.derive()

    def test_changed_audit_question_rejected(self):
        self.pool["jobs"][1]["config"]["question_index"] = 1
        with self.assertRaisesRegex(ValueError, "Audit q0"):
            self.derive()

    def test_generation_delta_rejected(self):
        original = resolver_for(self.pool)
        def changed(argv):
            value = original(argv)
            value["temperature"] = 0
            return value
        with self.assertRaisesRegex(ValueError, "temperature"):
            self.derive(resolver=changed)

    def test_missing_or_extra_serving_model_binding_rejected(self):
        with self.assertRaisesRegex(ValueError, "per model"):
            self.derive(bindings={})

    def test_missing_scenario_rejected(self):
        self.pool["jobs"].pop()
        with self.assertRaisesRegex(ValueError, "exactly the two"):
            self.derive()

    def test_duplicate_parent_rejected(self):
        self.pool["jobs"].append(copy.deepcopy(self.pool["jobs"][0]))
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            self.derive()

    def test_existing_supplement_output_rejected(self):
        target = self.root / (self.pool["jobs"][0]["id"].removesuffix("-poolact") + "-matched-naive")
        target.mkdir()
        with self.assertRaises(FileExistsError):
            self.derive()

    def test_option_replacement_rejects_ambiguous_cli(self):
        with self.assertRaises(ValueError):
            planner.replace_option(["--strategies", "poolact", "--strategies", "naive"], "--strategies", "cached")


if __name__ == "__main__":
    unittest.main()
