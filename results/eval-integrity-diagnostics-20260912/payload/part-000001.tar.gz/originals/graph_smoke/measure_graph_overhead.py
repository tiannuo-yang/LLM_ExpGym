#!/usr/bin/env python3
"""Offline final completed-graph rendering comparison; no original prompt rewrite."""
import argparse
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parent.parent
NEW = WORKSPACE / "LLM_ExpGym-eval-fixes-20260912"
OLD = WORKSPACE / "LLM_ExpGym-deepseek-flash-20260911"
sys.path.insert(0, str(NEW))
from smoke import check_graph_snapshots, executed_tool_messages


def load_graph_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def events(result):
    """Per-agent action order is preserved; cross-agent wall order is not reconstructed."""
    for agent in result["agent_results"]:
        if result["config"]["scenario"] == "tuning":
            for payload, canonical, perf, cost in agent["eval_records"]:
                yield agent["agent_id"], "evaluate_config", payload, (perf, cost)
        else:
            messages = executed_tool_messages(agent)
            assert len(messages) == len(agent["tool_records"])
            for (name, payload, feedback), message in zip(agent["tool_records"], messages):
                text = message.get("content") or ""
                if "over-budget — result withheld" in text or text.startswith("Observation: Tool error:"):
                    continue
                yield agent["agent_id"], name, payload, (feedback, 0.0)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--validate-new-graph", action="store_true")
    args = parser.parse_args()
    old_path = OLD / "expgym/extras/parallel_cache.py"
    new_path = NEW / "expgym/extras/parallel_cache.py"
    old, new = load_graph_module("graph_v3_measure", old_path), load_graph_module("graph_v4_measure", new_path)
    from tokenizers import Tokenizer
    tokenizer_path = Path("/lustrefs/users/runner/chufan.shi/tau_vision/ckpts/DeepSeek-V4-Flash-0731/tokenizer.json")
    tokenizer = Tokenizer.from_file(str(tokenizer_path))
    inputs = [("deepseek", WORKSPACE / "deepseek_flash_eval_20260911/formal/invocations"),
              ("gpt", WORKSPACE / "LLM_ExpGym_api_studies_20260910/studies/gpt56sol_medium_refmatrix_20260910_v1/invocations")]
    rows, not_measured = [], []
    for model, root in inputs:
        for path in sorted(root.glob("*/result/poolact/result.json")):
            result = json.loads(path.read_text())
            scenario = result["config"]["scenario"]
            if scenario not in ("tuning", "evidence_audit"):
                continue
            graphs = [m.SharedExplorationGraph(n_agents=result["agents"], diversity_mode=True) for m in (old, new)]
            if scenario == "evidence_audit" and any(
                    len(executed_tool_messages(a)) != len(a["tool_records"])
                    for a in result["agent_results"]):
                not_measured.append({"source_result": str(path), "model": model, "scenario": scenario,
                                     "reason": "saved message history no longer contains every tool turn; not reconstructable without complete API history"})
                continue
            replay = list(events(result))
            for module, graph in zip((old, new), graphs):
                for agent, name, payload, feedback in replay:
                    module._record_in_graph(graph, agent, name, payload, feedback, completion_time=0.0)
                assert graph.stats()["eval_nodes"] == result["shared_state"]["graph"]["eval_nodes"], str(path)
            texts = [g.format_for_injection(visible_before=1.0, agent_id=0) for g in graphs]
            if args.validate_new_graph:
                mapping = {"E:sha256:" + hashlib.sha256(key.encode()).hexdigest():
                           {"canonical": key, "display": node.config_display}
                           for key, node in graphs[1]._eval_nodes.items()}
                check_graph_snapshots(mapping, [texts[1]])
            tokens = [len(tokenizer.encode(text, add_special_tokens=False).ids) for text in texts]
            row = {"model": model, "scenario": scenario, "regime": result["config"]["cost_regime"],
                   "source_result": str(path), "source_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                   "eval_nodes": graphs[0].stats()["eval_nodes"], "old_edges": graphs[0].stats()["edges"],
                   "new_edges": graphs[1].stats()["edges"], "old_chars": len(texts[0]), "new_chars": len(texts[1]),
                   "old_tokens": tokens[0], "new_tokens": tokens[1], "delta_tokens": tokens[1] - tokens[0],
                   "delta_chars": len(texts[1]) - len(texts[0]),
                   "token_ratio": tokens[1] / tokens[0] if tokens[0] else None}
            rows.append(row)
    args.output_dir.mkdir(parents=True, exist_ok=False)
    with (args.output_dir / "by_pool.csv").open("x") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    groups = []
    for model in ("deepseek", "gpt"):
        for scenario in ("tuning", "evidence_audit"):
            selected = [row for row in rows if row["model"] == model and row["scenario"] == scenario]
            old_tokens = sum(row["old_tokens"] for row in selected)
            new_tokens = sum(row["new_tokens"] for row in selected)
            groups.append({"model": model, "scenario": scenario, "pools": len(selected),
                           "nonempty_graphs": sum(row["old_tokens"] > 0 for row in selected),
                           "total_old_tokens": old_tokens, "total_new_tokens": new_tokens,
                           "total_token_ratio": new_tokens / old_tokens if old_tokens else None,
                           "median_delta_tokens": statistics.median(row["delta_tokens"] for row in selected),
                           "max_delta_tokens": max(row["delta_tokens"] for row in selected)})
    summary = {"schema": "expgym.graph-render-overhead.v1", "groups": groups, "not_measured": not_measured,
               "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               "compact_display_validation": "passed_all_rendered_pools" if args.validate_new_graph else "not_requested",
               "old_source_sha256": hashlib.sha256(old_path.read_bytes()).hexdigest(),
               "new_source_sha256": hashlib.sha256(new_path.read_bytes()).hexdigest(),
               "tokenizer_file": str(tokenizer_path), "tokenizer_sha256": hashlib.sha256(tokenizer_path.read_bytes()).hexdigest(),
               "tokenizer_scope": "Exact standalone graph text tokenization with DeepSeek tokenizer, no chat-template specials; GPT graphs use the same tokenizer as a representation measurement, not GPT billed tokens.",
               "scope": "All frozen DeepSeek/GPT NAS pools; Audit pools with full saved tool-message histories, all exclusions listed. Re-render final completed visible observation set, replay per-agent order, no END/pending. Not historical per-call context replay or generated output; inter-agent wall timing is not reconstructed.",
               "limitations": "Only graph representation overhead; appended-history accumulation is unchanged. Nonempty final-graph totals do not estimate actual whole-run API token change."}
    with (args.output_dir / "summary.json").open("x") as handle:
        json.dump(summary, handle, indent=2, ensure_ascii=False, allow_nan=False)
        handle.write("\n")
    print(json.dumps(groups, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
