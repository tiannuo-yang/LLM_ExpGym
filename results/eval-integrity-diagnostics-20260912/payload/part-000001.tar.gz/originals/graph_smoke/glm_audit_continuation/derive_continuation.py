#!/usr/bin/env python3
"""Create-only, offline GLM Audit continuation plans; no model or Slurm path."""
import argparse
import copy
import hashlib
import ipaddress
import json
from pathlib import Path
import re
import socket
import subprocess
import sys
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent
SMOKE_ROOT = ROOT.parent
sys.path.insert(0, str(SMOKE_ROOT))
import smoke
sys.path.insert(0, str(SMOKE_ROOT / "matched_strategies"))
from derive_plan import load_pool_plan, replace_option

MODEL = "glm-5.3"
PREFIX = "glm-5_3-graph-v4-audit-cont-20260912-audit_q0"
OLD_PREFIX = "glm-5_3-graph-v4-20260912-audit_q0"
POOL_INPUT = SMOKE_ROOT / "plan_audit_native_fixed.json"
MATCHED_INPUT = SMOKE_ROOT / "matched_strategies/plan_audit_native_fixed.json"
POOL_SHA = "0d9392f44ab1d9bb7eeda21c0217920ba16a0a8b124c21e9683b2f337d645af8"
MATCHED_SHA = "177da78885d2651e84e56242253d612db69e15842e0475ef7466c85e8c04603a"
HELPER_SHA = "12593d4e6ef29d98efaed11a8de83c011007fcd7cc0ad146162ed32dee317b8b"
SOURCE_SHA = "e96575475b66e9e25b59115301dee10d04850a1f14f9d6b4d499f0651da47a78"
COMMIT = "b3382b1c0b89ef1637e232f4b7eef68d55a54f12"
OLD_DEPLOYMENT_SHA = "d9c13a137a98b3fbef12e24b833369d1a52a24abb5c50dfc0d13a9eb9000ef7a"
SERVING_ROOT = SMOKE_ROOT.parent / "serving"
BASE_PINS = {
    str(SERVING_ROOT / "glm-baseline/deployment.json"): OLD_DEPLOYMENT_SHA,
    str(SERVING_ROOT / "glm-baseline/rank0-deployment.json"): OLD_DEPLOYMENT_SHA,
    str(SERVING_ROOT / "glm-baseline/rank1-deployment.json"): "22f5d1fffbb2f28f96faf9c38316dc3a53a168cb75b1034512f17069171c9161",
    str(SERVING_ROOT / "glm-continuation/baseline-env-observation.json"): "13b55ebf4e0935e8b19980744cd503c72b4259be73f89f51bc0a6a833b0f910b",
}
OUTPUT_NAMES = ("pool_plan.json", "matched_plan.json", "same_serving_bindings.json",
                "derivation_manifest.json", "inventory.json")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_bound(path, expected):
    raw = Path(path).read_bytes()
    require(hashlib.sha256(raw).hexdigest() == expected, f"SHA256 mismatch: {path}")
    return json.loads(raw)


def option(argv, flag):
    require(argv.count(flag) == 1, f"Expected exactly one {flag}")
    index = argv.index(flag)
    require(index + 1 < len(argv) and not argv[index + 1].startswith("--"), f"Missing {flag} value")
    return argv[index + 1]


def normalize_serving_argv(argv):
    output = list(argv)
    for flag in ("--dist-init-addr", "--port"):
        option(output, flag)
        output = replace_option(output, flag, "<owned-address>")
    return output


def validate_deployment(old, new):
    """Metadata identity only; does not contact the endpoint or assert readiness."""
    require(str(old["job_id"]) == "1205018", "Unexpected old allocation")
    job_id = str(new["job_id"])
    require(re.fullmatch(r"[1-9][0-9]*", job_id) is not None and job_id != "1205018",
            "Continuation requires a distinct owned job ID")
    for key in ("model", "checkpoint", "checkpoint_metadata_sha256", "runtime", "topology",
                "sampler_modified", "network_security"):
        require(new.get(key) == old[key], f"Serving invariant changed: {key}")
    require(new["baseline_job_id"] == "1205018" and new["frozen_input_sha256"] == BASE_PINS,
            "Continuation must bind the exact original deployment/ranks/environment")
    require(new["original_runtime_input_sha256"] == old["frozen_input_sha256"],
            "Original runtime input hashes changed")
    require(new["model"] == MODEL, "Wrong served model")
    expected_slurm = copy.deepcopy(old["slurm"])
    expected_slurm["time_limit"] = "04:00:00"
    expected_slurm["nodelist"] = old["nodes"]
    require(new["slurm"] == expected_slurm, "Only Slurm walltime may change to four hours")
    nodes = new["nodes"]
    require(nodes == old["nodes"], "Registered continuation requires the original two nodes and rank order")
    require(isinstance(nodes, list) and len(nodes) == len(set(nodes)) == 2,
            "Expected exactly two distinct owned nodes")
    require(all(re.fullmatch(r"azure-uk-hpc-H200-instance-[0-9]+", node) for node in nodes),
            "Only private H200 cluster nodes are allowed")
    require(new["rank"] == 0 and new["node"] == nodes[0], "Deployment must describe owned rank zero")
    require(len(new["devices"]) == 8 and all(
        re.fullmatch(rf"{index}, GPU-[0-9a-f-]+, NVIDIA H200, 143771 MiB", device)
        for index, device in enumerate(new["devices"])), "Expected eight recorded H200 devices on rank zero")
    require(new["devices"] == old["devices"] == new["expected_devices_per_rank"][0],
            "Registered continuation must preserve rank-zero GPU UUID/order")
    require(len(new["endpoints"]) == 1, "Continuation requires one TP16 replica endpoint")
    endpoint = new["endpoints"][0]
    url = urlsplit(endpoint)
    require(url.scheme == "http" and url.hostname == nodes[0].lower() and url.path == "/v1"
            and not url.query and not url.fragment and url.username is None and url.password is None
            and url.port is not None and 1 <= url.port <= 65535,
            "Endpoint must be the credential-free private owned head node")
    require(int(option(new["argv"], "--port")) == url.port, "Endpoint/argv port mismatch")
    host, port = option(new["argv"], "--dist-init-addr").rsplit(":", 1)
    require(host == option(old["argv"], "--dist-init-addr").rsplit(":", 1)[0]
            and int(port) == 53460 and url.port == 33460, "Registered continuation ports/IP changed")
    require(ipaddress.ip_address(host).is_private and 1 <= int(port) <= 65535
            and int(port) != url.port, "Rendezvous must use a distinct private address/port")
    require(normalize_serving_argv(new["argv"]) == normalize_serving_argv(old["argv"]),
            "Effective serving argv changed outside endpoint/rendezvous")
    require(len(new["rank_argv"]) == len(old["rank_argv_templates"]) == 2,
            "Expected both TP16 rank templates")
    for rank, (before, after) in enumerate(zip(old["rank_argv_templates"], new["rank_argv"])):
        require(normalize_serving_argv(before) == normalize_serving_argv(after),
                f"Rank {rank} serving flags changed")
        require(option(after, "--node-rank") == str(rank)
                and int(option(after, "--port")) == url.port
                and option(after, "--dist-init-addr") == f"{host}:{port}",
                f"Rank {rank} template address/topology mismatch")
    require(new["argv"] == new["rank_argv"][0], "Actual head argv differs from its frozen rank command")
    return endpoint


def validate_environment(new, observation):
    require(observation["process_identity"]["SLURM_JOB_ID"] == "1205018"
            and observation["process_identity"]["SLURM_PROCID"] == "0", "Wrong baseline environment observation")
    expected = {}
    old_root = "/tmp/expgym_glm_diag_1205018_rank0"
    new_root = f"/tmp/expgym_glm_continue_{new['job_id']}_rank0"
    for key, value in observation["allowlisted_environment"].items():
        if value is not None and (value == old_root or value.startswith(old_root + "/")):
            value = new_root + value[len(old_root):]
        expected[key] = value
    require(new["allowlisted_child_environment"] == expected,
            "Observed numeric/unset environment changed beyond registered job/rank cache roots")
    require(new["inherited_inductor_path_preserved"] == observation["allowlisted_environment"]["TORCHINDUCTOR_CACHE_DIR"],
            "Inherited inductor path differs from the registered launcher policy")


def select_inputs(pool_plan, matched_plan):
    for value in (pool_plan, matched_plan):
        require(value["helper_sha256"] == HELPER_SHA and value["source_tree_sha256"] == SOURCE_SHA
                and value["git_commit"] == COMMIT and value["repo"] == str(smoke.REPO)
                and value["python"] == str(smoke.PYTHON), "Frozen source/helper/interpreter identity changed")
    selected = []
    for strategy, plan in (("poolact", pool_plan), ("naive", matched_plan), ("cached", matched_plan)):
        suffix = "poolact" if strategy == "poolact" else f"matched-{strategy}"
        expected_id = f"{OLD_PREFIX}-{suffix}"
        candidates = [job for job in plan["jobs"] if job["id"] == expected_id]
        require(len(candidates) == 1, f"Exactly one frozen {strategy} Audit input required")
        job = candidates[0]
        config = job["config"]
        fixed = {"model": MODEL, "scenario": "evidence_audit", "question_index": 0,
                 "strategies": [strategy], "agents": 2, "repeats": 1, "seed": 2200,
                 "agent_seeds": [2200, 2201], "max_steps": 4, "max_evals": 3,
                 "cost_regime": "cost_tight", "time_budget": 900, "max_tokens": 32768,
                 "max_context_tokens": 131072, "temperature": 1, "top_p": .95,
                 "top_k": None, "reasoning_effort": "max", "tool_protocol": "native",
                 "chat_template_kwargs": {"clear_thinking": False, "reasoning_effort": "max"},
                 "max_protocol_retries": 1, "max_retries": 0, "tuning_final_policy": "legacy",
                 "missing_final_policy": "task-abstention-v1", "prompt_cache_key_field": "cache_salt"}
        require(all(config.get(k) == v for k, v in fixed.items()), "Fixed Audit task/generation setting changed")
        require(job["max_decisions"] == 10 and job["max_completion_tokens"] == 327680,
                "Per-pool budget changed")
        if strategy != "poolact":
            require(job["paired_pool_job_id"] == f"{OLD_PREFIX}-poolact", "Wrong original matched PoolAct")
            expected = copy.deepcopy(selected[0]["config"])
            expected.update(strategies=[strategy], prompt_cache_key=job["id"])
            require(config == expected, "Original strategies differ beyond strategy/cache namespace")
        selected.append(job)
    return selected


def derive_jobs(pool_plan, matched_plan, endpoint, output_root, resolver):
    parents = select_inputs(pool_plan, matched_plan)
    require(not output_root.exists() and not output_root.is_symlink(), "Continuation run root must be fresh")
    jobs = []
    for parent, strategy in zip(parents, ("poolact", "naive", "cached")):
        suffix = "poolact" if strategy == "poolact" else f"matched-{strategy}"
        new_id = f"{PREFIX}-{suffix}"
        target = output_root / new_id
        argv = parent["argv"]
        for flag, value in (("--base-url", endpoint), ("--prompt-cache-key", new_id),
                            ("--output-dir", target / "result")):
            argv = replace_option(argv, flag, value)
        actual = resolver(argv)
        expected = copy.deepcopy(parent["config"])
        expected.update(base_url=endpoint, prompt_cache_key=new_id)
        changed = sorted(k for k in set(actual) | set(expected) if actual.get(k) != expected.get(k))
        require(actual == expected, f"Config changed outside endpoint/cache namespace: {changed}")
        job = {"id": new_id, "root": str(target), "dump": str(target / "api_dump"),
               "argv": argv, "config": actual, "max_decisions": 10, "max_completion_tokens": 327680,
               "derived_from_job_id": parent["id"]}
        if strategy != "poolact":
            job["paired_pool_job_id"] = f"{PREFIX}-poolact"
        jobs.append(job)
    require(len({j["root"] for j in jobs}) == len({j["dump"] for j in jobs}) == 3,
            "Output/dump namespaces overlap")
    return jobs


def build_documents(pool_input, matched_input, jobs, binding, created, planner_sha):
    bindings = {MODEL: binding}
    profile = [copy.deepcopy(p) for p in pool_input["profiles"] if p["model"] == MODEL]
    require(len(profile) == 1, "Exactly one historical GLM configuration profile required")
    profile[0]["endpoint"] = jobs[0]["config"]["base_url"]
    common = {key: pool_input[key] for key in ("helper_sha256", "source_tree_sha256", "git_commit", "repo", "python")}
    common.update(created_utc=created, profiles=profile, planner_sha256=planner_sha,
                  scope="Fixed previously inspected Audit q0 custom smoke; no full-matrix or universal improvement claim",
                  serving_bindings=bindings, execution_order=[j["id"] for j in jobs],
                  acceptance="Integrity/native-output fidelity only; all valid negative/missing outcomes retained",
                  max_cohort_requests=30, max_cohort_completion_tokens=983040,
                  serving_bindings_file=str(ROOT / "same_serving_bindings.json"))
    pool = copy.deepcopy(common)
    pool.update(schema="expgym.graph-v4-real-smoke.v1", jobs=[jobs[0]],
                max_decisions=10, max_completion_tokens=327680)
    matched = copy.deepcopy(common)
    matched.update(schema="expgym.matched-strategy-smoke.v1", jobs=jobs[1:],
                   max_decisions=20, max_completion_tokens=655360,
                   budgets={MODEL: {"extra_pools": 2, "max_extra_requests": 20,
                                    "max_extra_completion_tokens": 655360}},
                   pool_parent_plan=str(ROOT / "pool_plan.json"),
                   reused_poolact=[{"job": jobs[0], "mode": "new_same_deployment_preselected_pool",
                                    "include_outcomes": "all; never outcome-selected"}],
                   matches=[{"model": MODEL, "scenario": "evidence_audit",
                             "poolact": jobs[0]["id"], "naive": jobs[1]["id"], "cached": jobs[2]["id"]}],
                   report_metrics=matched_input["report_metrics"],
                   comparison_orientation=matched_input["comparison_orientation"],
                   missing_policy=matched_input["missing_policy"], seed_scope=matched_input["seed_scope"],
                   causal_scope=matched_input["causal_scope"])
    return pool, matched, bindings


def ensure_create_only():
    for name in OUTPUT_NAMES:
        path = ROOT / name
        require(not path.exists() and not path.is_symlink(), f"Output already exists: {path}")
    require(not (ROOT / "runs").exists() and not (ROOT / "runs").is_symlink(), "Run root already exists")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--deployment", type=Path, required=True)
    parser.add_argument("--deployment-sha256", required=True)
    args = parser.parse_args()
    ensure_create_only()
    expected_deployment = SMOKE_ROOT.parent / "serving/glm-continuation/deployment.json"
    require(args.deployment.is_absolute() and args.deployment == expected_deployment,
            "Deployment must be the explicit root-owned continuation file")
    require(not args.deployment.is_symlink(), "Deployment file must not alias the old allocation")
    # Even an accidental future code path cannot make model/network calls here.
    def denied(*unused_args, **unused_kwargs):
        raise RuntimeError("NETWORK_FORBIDDEN_IN_CONTINUATION_PLANNING")
    socket.socket.connect = denied
    socket.socket.connect_ex = denied
    socket.create_connection = denied
    require(smoke.sha(smoke.__file__) == HELPER_SHA, "Frozen helper changed")
    pool_input = load_pool_plan(POOL_INPUT, POOL_SHA)
    matched_input = read_bound(MATCHED_INPUT, MATCHED_SHA)
    old_binding = matched_input["serving_bindings"][MODEL]
    require(old_binding["sha256"] == OLD_DEPLOYMENT_SHA and old_binding["job_id"] == "1205018",
            "Old deployment binding changed")
    old = read_bound(old_binding["deployment_file"], OLD_DEPLOYMENT_SHA)
    new = read_bound(args.deployment, args.deployment_sha256)
    endpoint = validate_deployment(old, new)
    baseline_records = {path: read_bound(path, digest) for path, digest in BASE_PINS.items()}
    rank_one = baseline_records[str(SERVING_ROOT / "glm-baseline/rank1-deployment.json")]
    require(new["expected_devices_per_rank"] == [old["devices"], rank_one["devices"]],
            "Registered sixteen-GPU inventory changed")
    observation_path = str(SERVING_ROOT / "glm-continuation/baseline-env-observation.json")
    require(new["environment_observation"] == observation_path, "Unexpected environment observation source")
    validate_environment(new, baseline_records[observation_path])
    runner = smoke.imports()
    require(runner.source_tree_sha256(smoke.REPO) == SOURCE_SHA, "Current runtime source changed")
    require(subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=smoke.REPO, text=True).strip() == COMMIT,
            "Current source commit changed")
    jobs = derive_jobs(pool_input, matched_input, endpoint, ROOT / "runs",
                       lambda argv: smoke.resolved(runner, argv)[1])
    binding = {"deployment_file": str(args.deployment), "sha256": args.deployment_sha256,
               "job_id": str(new["job_id"]), "pool_same_deployment_bound": True,
               "binding_scope": "Prospective binding of all three new jobs; execution/readiness requires separate evidence",
               "old_poolact_reused": False, "endpoint": endpoint}
    created = smoke.now()
    planner_sha = smoke.sha(__file__)
    pool, matched, bindings = build_documents(pool_input, matched_input, jobs, binding, created, planner_sha)
    # Recheck immutable inputs before the first write. Partial failures are preserved, never overwritten.
    for path, digest in ((POOL_INPUT, POOL_SHA), (MATCHED_INPUT, MATCHED_SHA),
                         (Path(old_binding["deployment_file"]), OLD_DEPLOYMENT_SHA),
                         (args.deployment, args.deployment_sha256), (Path(smoke.__file__), HELPER_SHA)):
        require(smoke.sha(path) == digest, f"Input changed during planning: {path}")
    ensure_create_only()
    smoke.write_new(ROOT / "same_serving_bindings.json", bindings)
    binding_sha = smoke.sha(ROOT / "same_serving_bindings.json")
    pool["serving_bindings_sha256"] = matched["serving_bindings_sha256"] = binding_sha
    smoke.write_new(ROOT / "pool_plan.json", pool)
    matched["pool_parent_plan_sha256"] = smoke.sha(ROOT / "pool_plan.json")
    matched["reused_poolact"][0]["pool_parent_plan_sha256"] = matched["pool_parent_plan_sha256"]
    smoke.write_new(ROOT / "matched_plan.json", matched)
    inventory = lambda names: {name: {"sha256": smoke.sha(ROOT / name), "bytes": (ROOT / name).stat().st_size}
                               for name in names}
    manifest = {"schema": "expgym.glm-audit-continuation-derivation.v1", "created_utc": created,
                "planner_sha256": planner_sha, "expected_jobs": 3, "execution_order": [j["id"] for j in jobs],
                "inputs": {str(POOL_INPUT): POOL_SHA, str(MATCHED_INPUT): MATCHED_SHA,
                           old_binding["deployment_file"]: OLD_DEPLOYMENT_SHA,
                           str(args.deployment): args.deployment_sha256, str(smoke.__file__): HELPER_SHA},
                "source_tree_sha256": SOURCE_SHA, "git_commit": COMMIT,
                "reason": "Authorized infrastructure-budget continuation: observed approximately 59-minute cold startup and 23-minute Audit elapsed time within the old two-hour allocation; decision recorded before completion/scoring of the old Audit Pool, with NAS scores already known, not selected by Audit outcomes",
                "old_poolact": {"job_id": f"{OLD_PREFIX}-poolact", "retained": True,
                                "scope": "correctness_only_separate_deployment", "reused_in_new_matched": False},
                "old_audit_controls": [{"job_id": f"{OLD_PREFIX}-matched-{strategy}",
                                        "status": "not_started_infra_budget"} for strategy in ("naive", "cached")],
                "request_budget": {"new_cohort": 30, "new_cohort_completion_tokens": 983040,
                                   "extra_repeated_poolact": 10, "extra_repeated_poolact_completion_tokens": 327680,
                                   "all_old_and_new_glm_maximum": 70,
                                   "old_allowed_scope_maximum": 40, "health_controls_excluded_and_separately_recorded": True},
                "execution_policy": "Sequential PoolAct then Naive then Cached; no score/answer-sign stop gate, no failed-run retry, fresh per-pool process/output/dump/cache_salt; drain and record idle flush before supplemental phase, never in-flight",
                "readiness": "Prospective plan may be frozen while loading; model dispatch requires later independent readiness evidence and root release. No probe performed by this planner.",
                "output_inventory": inventory(OUTPUT_NAMES[:3]), "new_model_calls": 0, "slurm_calls": 0}
    smoke.write_new(ROOT / "derivation_manifest.json", manifest)
    smoke.write_new(ROOT / "inventory.json", {"schema": "expgym.continuation-plan-inventory.v1",
                    "files": inventory(OUTPUT_NAMES[:4]), "self_hash": "Record SHA256 externally; no recursive self-hash"})
    print(json.dumps({"plans": inventory(OUTPUT_NAMES), "expected_jobs": 3,
                      "new_model_calls": 0, "max_requests": 30, "max_completion_tokens": 983040}))


if __name__ == "__main__":
    main()
