"""Small offline fixtures; no model, Slurm, deployment or final-plan writes."""
import copy
import functools
import importlib.util
import json
import os
from pathlib import Path
import socket
import tempfile
import unittest
from unittest import mock

import derive_continuation as planner


@functools.lru_cache(maxsize=1)
def base_fixture():
    pool = planner.read_bound(planner.POOL_INPUT, planner.POOL_SHA)
    matched = planner.read_bound(planner.MATCHED_INPUT, planner.MATCHED_SHA)
    binding = matched["serving_bindings"][planner.MODEL]
    old = planner.read_bound(binding["deployment_file"], planner.OLD_DEPLOYMENT_SHA)
    launcher_path = planner.SERVING_ROOT / "glm-continuation/run-server.py"
    spec = importlib.util.spec_from_file_location("continuation_launcher_fixture", launcher_path)
    launcher = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(launcher)
    # Use the real launcher's metadata-only plan shape, not a copy of old schema.
    with mock.patch.object(socket.socket, "connect", side_effect=AssertionError("NO_NETWORK")), \
            mock.patch.object(launcher.subprocess, "check_output", side_effect=AssertionError("NO_SLURM")), \
            mock.patch.object(launcher.subprocess, "Popen", side_effect=AssertionError("NO_MODEL_PROCESS")):
        new = launcher.plan()
    observation_path = planner.SERVING_ROOT / "glm-continuation/baseline-env-observation.json"
    observation = planner.read_bound(observation_path, planner.BASE_PINS[str(observation_path)])
    new.update(job_id="9999999", nodes=old["nodes"], node=old["node"], rank=0,
               devices=old["devices"], argv=new["rank_argv"][0],
               allowlisted_child_environment=launcher.expected_environment("9999999", 0, observation))
    return pool, matched, old, new


def fixtures():
    return copy.deepcopy(base_fixture())


def fixture_resolver(pool, matched):
    parents = planner.select_inputs(pool, matched)
    def resolve(argv):
        strategy = planner.option(argv, "--strategies")
        config = copy.deepcopy(next(j for j in parents if j["config"]["strategies"] == [strategy])["config"])
        config.update(base_url=planner.option(argv, "--base-url"),
                      prompt_cache_key=planner.option(argv, "--prompt-cache-key"))
        return config
    return resolve


class ContinuationTests(unittest.TestCase):
    def setUp(self):
        self.pool, self.matched, self.old, self.new = fixtures()
        self.temp = tempfile.TemporaryDirectory(prefix=".test-cont-", dir=planner.ROOT)
        self.addCleanup(self.temp.cleanup)
        self.output = Path(self.temp.name) / "fresh-runs"

    def derive(self, resolver=None):
        return planner.derive_jobs(self.pool, self.matched, self.new["endpoints"][0], self.output,
                                   resolver or fixture_resolver(self.pool, self.matched))

    def test_three_fresh_audit_jobs_preserve_all_config_except_endpoint_and_cache(self):
        before = copy.deepcopy((self.pool, self.matched))
        jobs = self.derive()
        self.assertEqual(["poolact", "naive", "cached"], [j["config"]["strategies"][0] for j in jobs])
        self.assertEqual(30, sum(j["max_decisions"] for j in jobs))
        self.assertEqual(983040, sum(j["max_completion_tokens"] for j in jobs))
        self.assertEqual(3, len({j["config"]["prompt_cache_key"] for j in jobs}))
        for old, new in zip(planner.select_inputs(self.pool, self.matched), jobs):
            changed = {key for key in old["config"] if old["config"][key] != new["config"][key]}
            self.assertEqual({"base_url", "prompt_cache_key"}, changed)
            self.assertNotEqual(old["root"], new["root"])
            self.assertEqual(str(Path(new["root"]) / "api_dump"), new["dump"])
            self.assertEqual(str(Path(new["root"]) / "result"), planner.option(new["argv"], "--output-dir"))
        self.assertEqual(before, (self.pool, self.matched))
        self.assertFalse(self.output.exists())

    def test_new_controls_pair_only_to_new_pool(self):
        jobs = self.derive()
        self.assertEqual([jobs[0]["id"]] * 2, [j["paired_pool_job_id"] for j in jobs[1:]])
        docs = planner.build_documents(self.pool, self.matched, jobs, {"job_id": "9999999"}, "fixed-time", "planner-sha")
        self.assertEqual([jobs[0]], docs[0]["jobs"])
        self.assertEqual(jobs[1:], docs[1]["jobs"])
        self.assertEqual(jobs[0], docs[1]["reused_poolact"][0]["job"])
        self.assertNotIn(planner.OLD_PREFIX + "-poolact", json.dumps(docs[1]["matches"]))

    def test_valid_four_hour_same_runtime_deployment(self):
        self.assertEqual(self.new["endpoints"][0], planner.validate_deployment(self.old, self.new))
        observation_path = planner.SERVING_ROOT / "glm-continuation/baseline-env-observation.json"
        observation = planner.read_bound(observation_path, planner.BASE_PINS[str(observation_path)])
        planner.validate_environment(self.new, observation)
        self.assertNotIn("historical_profile_verbatim", self.new)
        self.assertNotIn("rank_argv_templates", self.new)

    def test_wrong_model_runtime_sampling_or_topology_rejected(self):
        for key, value in (("model", "other-model"), ("runtime", "/other-runtime"),
                           ("sampler_modified", False), ("topology", {"tp_size": 8})):
            with self.subTest(key=key):
                broken = copy.deepcopy(self.new)
                broken[key] = value
                with self.assertRaisesRegex(ValueError, "Serving invariant"):
                    planner.validate_deployment(self.old, broken)
        broken = copy.deepcopy(self.new)
        broken["argv"] = planner.replace_option(broken["argv"], "--random-seed", 4201)
        with self.assertRaisesRegex(ValueError, "argv changed"):
            planner.validate_deployment(self.old, broken)

    def test_old_job_wrong_walltime_or_wrong_node_count_rejected(self):
        for mutate in (lambda d: d.update(job_id="1205018"),
                       lambda d: d["slurm"].update(time_limit="08:00:00"),
                       lambda d: d.update(nodes=[d["node"]])):
            broken = copy.deepcopy(self.new)
            mutate(broken)
            with self.assertRaises(ValueError):
                planner.validate_deployment(self.old, broken)

    def test_credentials_external_endpoint_query_and_ownership_mismatch_rejected(self):
        for endpoint in ("http://secret@azure-uk-hpc-H200-instance-256:33460/v1",
                         "https://azure-uk-hpc-H200-instance-256:33460/v1",
                         "http://public.example:33460/v1",
                         "http://azure-uk-hpc-H200-instance-256:33460/v1?key=x",
                         "http://azure-uk-hpc-H200-instance-257:33460/v1",
                         "http://azure-uk-hpc-H200-instance-256:33461/v1"):
            with self.subTest(endpoint=endpoint):
                broken = copy.deepcopy(self.new)
                broken["endpoints"] = [endpoint]
                with self.assertRaises(ValueError):
                    planner.validate_deployment(self.old, broken)

    def test_rendezvous_or_rank_template_delta_rejected(self):
        broken = copy.deepcopy(self.new)
        broken["argv"] = planner.replace_option(broken["argv"], "--dist-init-addr", "8.8.8.8:53460")
        with self.assertRaisesRegex(ValueError, "ports/IP"):
            planner.validate_deployment(self.old, broken)
        broken = copy.deepcopy(self.new)
        broken["rank_argv"][1] = planner.replace_option(broken["rank_argv"][1], "--node-rank", 0)
        with self.assertRaisesRegex(ValueError, "Rank 1"):
            planner.validate_deployment(self.old, broken)

    def test_runtime_pin_or_environment_delta_rejected(self):
        broken = copy.deepcopy(self.new)
        broken["original_runtime_input_sha256"] = {}
        with self.assertRaisesRegex(ValueError, "runtime input"):
            planner.validate_deployment(self.old, broken)
        observation_path = planner.SERVING_ROOT / "glm-continuation/baseline-env-observation.json"
        observation = planner.read_bound(observation_path, planner.BASE_PINS[str(observation_path)])
        self.new["allowlisted_child_environment"]["UNREGISTERED_KNOB"] = "1"
        with self.assertRaisesRegex(ValueError, "environment"):
            planner.validate_environment(self.new, observation)

    def test_config_resolver_sampling_data_or_policy_delta_rejected(self):
        original = fixture_resolver(self.pool, self.matched)
        for key, value in (("temperature", 0), ("max_tokens", 4096), ("top_k", -1),
                           ("evaluation_identity", {}), ("missing_final_policy", "error")):
            with self.subTest(key=key):
                def changed(argv):
                    config = original(argv)
                    config[key] = value
                    return config
                with self.assertRaisesRegex(ValueError, key):
                    self.derive(changed)

    def test_parent_source_and_duplicate_selected_job_rejected(self):
        self.pool["source_tree_sha256"] = "unpublished-source"
        with self.assertRaisesRegex(ValueError, "identity"):
            self.derive()
        self.pool, self.matched, _, _ = fixtures()
        original = planner.select_inputs(self.pool, self.matched)[0]
        self.pool["jobs"].append(copy.deepcopy(original))
        with self.assertRaisesRegex(ValueError, "Exactly one"):
            self.derive()

    def test_existing_roots_and_output_files_are_not_overwritten(self):
        self.output.mkdir()
        with self.assertRaisesRegex(ValueError, "fresh"):
            self.derive()
        temporary_root = Path(self.temp.name)
        planner.smoke.write_new(temporary_root / "pool_plan.json", {"sentinel": True})
        with mock.patch.object(planner, "ROOT", temporary_root):
            with self.assertRaisesRegex(ValueError, "already exists"):
                planner.ensure_create_only()
        self.assertEqual({"sentinel": True}, json.loads((temporary_root / "pool_plan.json").read_text()))

    def test_ambiguous_cli_rejected(self):
        with self.assertRaises(ValueError):
            planner.option(["--port", "1", "--port", "2"], "--port")
        with self.assertRaises(ValueError):
            planner.option(["--port"], "--port")

    def test_actual_no_network_resolver_matches_frozen_audit_identity(self):
        previous_cwd = Path.cwd()
        def denied(*args, **kwargs):
            raise AssertionError("NO_NETWORK_IN_CPU_TEST")
        try:
            with mock.patch.object(socket.socket, "connect", denied), mock.patch.object(socket, "create_connection", denied):
                runner = planner.smoke.imports()
                jobs = self.derive(lambda argv: planner.smoke.resolved(runner, argv)[1])
                self.assertEqual(3, len(jobs))
                self.assertEqual(planner.SOURCE_SHA, runner.source_tree_sha256(planner.smoke.REPO))
        finally:
            os.chdir(previous_cwd)


if __name__ == "__main__":
    unittest.main()
