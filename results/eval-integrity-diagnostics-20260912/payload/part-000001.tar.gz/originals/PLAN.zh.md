# 2026-09-12：评估缺陷影响与 DeepSeek 定向 GPU 诊断

类型：Static/fake validation + 经用户授权的 Real smoke validation / Custom diagnostic study。
不是正式全量重跑，不修改或替换历史分数；已看过的失败输入用于诊断，不能当新 held-out 性能样本。

## 范围和验收

1. 影响评估：量化 graph identity 碰撞、GPT context-stop 频率和单格分数敏感性；区分 ExpGym 单体趋势/家族排名与 PoolAct 策略效果。
2. 修复已确认的图路径身份碰撞，保留缓存、评分、预算、时间可见性与独立 pool 状态；回归旧实现失败、新实现通过。升级实际协调协议版本。
3. GPT 图历史/上下文策略本轮暂不改；保留原 missing 和 Gap0。
4. DeepSeek 复用冻结 0731 checkpoint 和 SGLang 0.5.17 + 原 encoder backport，先启动一个 TP8 / 8 H200 副本，保持原单副本配置。诊断运行不调用 GPT API。
5. 第一阶段使用 4 个明确来源的首次请求（2 个已知异常、2 个正常对照），每个请求重复 2 次，串行 concurrency=1 和并发 concurrency=4 各 8 请求。复用原 messages/tools/生成参数（max effort、thinking、原 temperature/top_p、32768 上限）。新增传输/缓存命名空间必须记录，不把 seed 当确定性承诺。工具输出控制单独保留。
6. 根据第一阶段证据，至多另选 2 个具有源码依据的单因素配置对照；每个对照最多 8 个同集请求。先写明因果假设和配置差值，再运行。不是不断尝试直到分数变好。
7. 图修复的实际 GPU smoke：固定小规模 NAS pool，验证路径 ID 唯一、映射可追溯、pending=0 和保存评分一致；性能仅描述，不以提升为通过条件。若 serving 尚不可信，明确区分图行为覆盖与生成质量。
8. 完成一次独立代码/诊断结论复核。留下输入身份、全部请求/原始响应、CSV、版本、Slurm/GPU 耗时和结论。结束已拥有的服务 allocation；不碰其他任务。

用户追加验收：DeepSeek 之外也做实际模型 PoolAct 链路验证；优先复用可安全使用的已有本地服务，否则另开隔离、有限时的最小兼容副本。正常工具/图/计分是工程验收，策略提升需独立实测，不能以得到正差值作为停止或选样规则。
串行和并发条件分别开始前，先排空当前 owned server 并记录 `/health`、`/get_model_info`、`/metrics` 和 `/flush_cache` 状态/响应，避免前一阶段热缓存混杂。保留原请求 cache_salt。

## 资源和停止条件

首个 allocation：k2p / higherprio，1 node × 8 GPU，4 小时时限；先启动原配置基线。
加载耗时参考历史同 TP8 约 14 分钟，并非保证。若出现加载/运行错误先保留诊断，不自动重提相同失败任务。
HTTP 成功但乱码、空答、length 均留存，不免费重试；基础设施失败不记作模型零分。
若有限对照仍未定位根因，报告未决原因与已排除假设，不宣称已完全解决、不发起全量重跑。

源码新工作树：`../LLM_ExpGym-eval-fixes-20260912`，基线 `5aabf7f6b568a1281fb677a94c19cfb2e8ce98b8`。
旧运行、旧 runtime、旧报告保持不变；新编译缓存及 dump 全部使用诊断命名空间。

## 00:50 UTC：发现新缺陷后的前瞻修订

- v1 串行回放已完成 8/8；全部原始请求、响应、成本保留。诊断 helper 在 HTTP body
  使用了递归排序 JSON，改变了模型可见的工具 schema 顺序。离线实际 renderer 精确
  证实四个提示词均变化，三个 Audit 请求分别少一个 token；因此该组仅作为
  `reordered-schema diagnostic`，不是原提示词的精确回放。原结果不得覆盖。
- 不再执行尚未开始的 v1 排序 schema 并发组：它不能回答原定的历史输入问题。
  新独立 v2 helper 使用旧客户端的 `json.dumps(payload).encode('utf-8')` 保序 wire
  序列化；冻结测试和源身份之后执行原定 c1/c4 各 8 请求。语义 JSON hash、wire hash
  和 rendered prompt identity 分开记录。这个修订因 helper 缺陷发生，不因分数筛选。
- 新回放还暴露两项不同问题：Audit native 的任务说明把固定 `nda-11 / [3,7]`
  写成命令；DeepSeek serving 没有对 `parallel_tool_calls=false` 实施单调用约束。
  Schema 合法的 4/10 调用不等于 runner 协议合法，不能记为功能通过。
- 授权仅修复 task-owned Audit native 说明：依据当前文档/假设选择调用，用真实 schema
  描述参数，明确每轮至多一次并等待结果；legacy text、文档内容、答案和评分不变。
  系统级 native 指令原本已经要求至多一次，不重复堆叠该指令，也不丢弃多余调用。
- `graph_smoke/plan_compact.json` 尚未执行；先 HOLD 两模型的 runner smoke，待上述
  源修复与回归验证完成后另存 source-bound 计划，保留旧计划为
  `superseded_before_execution`。直接 first-request 回放不读取变动中的框架源码。
- `/health` 在这些 SGLang 版本可能触发一次单 token 探测；它不属于 task request，
  但不是零生成。进度检查用日志/metadata/metrics，比较前记录探测并随后 flush。
  实际启动有少量环境差异（含继承的 node-local TORCHINDUCTOR_CACHE_DIR），见 CHECKS；
  不能把新旧 deployment 称为完全相同或把新 coherent 输出当作根因已修复。
