"""CPU-only mocked HTTP tests. No sockets, model, GPU, or real credentials."""
import copy
import http.client
import io
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock
import urllib.error

import replay_first_requests as h


PAYLOAD = {"model": "unfamiliar-model", "messages": [{"role": "system", "content": "a"}, {"role": "user", "content": "b"}],
           "seed": 2202, "max_tokens": 32768, "temperature": 1.0, "top_p": .95,
           "reasoning_effort": "max", "chat_template_kwargs": {"thinking": True}, "cache_salt": "original",
           "tool_choice": "auto", "parallel_tool_calls": False,
           "tools": [{"type": "function", "function": {"name": "read_note", "parameters": {"type": "object", "properties": {"label": {"type": "string", "enum": ["a"]}}, "required": ["label"], "additionalProperties": False}}}]}


def response(content="", calls=None, finish="stop"):
    return {"choices": [{"message": {"role": "assistant", "content": content, "reasoning_content": "reason", "tool_calls": calls}, "finish_reason": finish}], "usage": {"prompt_tokens": 17, "completion_tokens": 9}}


CALL = {"id": "call-1", "type": "function", "function": {"name": "read_note", "arguments": '{"label":"a"}'}}


class FakeStream(io.BytesIO):
    status = 200


class Opener:
    def __init__(self, body=None, error=None):
        self.body, self.error, self.requests = body, error, []

    def open(self, request, timeout):
        self.requests.append((request, timeout))
        if self.error:
            raise self.error
        return FakeStream(self.body)


class HarnessTests(unittest.TestCase):
    def test_tool_only_native_accepted(self):
        shape = h.response_shape(response(calls=[CALL], finish="tool_calls"), PAYLOAD, "evidence_audit")
        self.assertTrue(shape["protocol_shape_usable"])
        self.assertEqual(shape["valid_tool_calls"], 1)
        self.assertFalse(shape["has_nonempty_content"])

    def test_reasoning_only_not_final(self):
        shape = h.response_shape(response(), PAYLOAD, "evidence_audit")
        self.assertFalse(shape["protocol_shape_usable"])
        self.assertEqual(shape["reasoning_characters"], 6)

    def test_garbled_text_not_invented_as_json(self):
        shape = h.response_shape(response("unfinished [ gibberish"), PAYLOAD, "evidence_audit")
        self.assertTrue(shape["has_nonempty_content"])
        self.assertFalse(shape["protocol_shape_usable"])
        self.assertEqual(shape["content_json_status"], "not_json")

    def test_audit_schema_is_not_gold_score(self):
        text = '{"nda-1":{"label":"Entailment","evidence_ids":[1]}}'
        shape = h.response_shape(response(text), PAYLOAD, "evidence_audit")
        self.assertTrue(shape["audit_entry_shape_valid"])
        self.assertTrue(shape["shape_is_not_task_score_or_readability"])
        self.assertNotIn("score", shape)

    def test_fenced_json_cleanup_matches_evaluator(self):
        value, status = h.content_object('```json\n{"a":1}\n```;')
        self.assertEqual(value, {"a": 1})
        self.assertEqual(status, "audit_cleanup_json")

    def test_wrong_tool_arguments_and_forced_final(self):
        call = copy.deepcopy(CALL)
        call["function"]["arguments"] = '{"label":42}'
        self.assertEqual(h.response_shape(response(calls=[call]), PAYLOAD, "evidence_audit")["invalid_tool_calls"], 1)
        forced = {**PAYLOAD, "tool_choice": "none"}
        self.assertEqual(h.response_shape(response(calls=[CALL]), forced, "evidence_audit")["invalid_tool_calls"], 1)

    def test_nonstring_tool_name_does_not_abort_record(self):
        call = copy.deepcopy(CALL)
        call["function"]["name"] = []
        raw = json.dumps(response(calls=[call])).encode()
        with tempfile.TemporaryDirectory() as temp:
            target = Path(temp)/"one"
            record, _ = h.one_request(PAYLOAD, "evidence_audit", "http://localhost", target, {}, 1, opener=Opener(raw))
            self.assertTrue((target/"record.json").exists())
        self.assertEqual(record["state"], "delivered")
        self.assertEqual(record["shape"]["invalid_tool_calls"], 1)

    def test_malformed_envelope_retained(self):
        self.assertFalse(h.response_shape({"choices": []}, PAYLOAD, "evidence_audit")["envelope_valid"])
        self.assertFalse(h.response_shape(None, PAYLOAD, "evidence_audit")["envelope_valid"])

    def test_exact_payload_and_raw_bytes(self):
        original = copy.deepcopy(PAYLOAD)
        raw = json.dumps(response(calls=[CALL]), ensure_ascii=False).encode()
        opener = Opener(raw)
        with tempfile.TemporaryDirectory() as temp:
            target = Path(temp) / "attempt"
            record, decoded = h.one_request(PAYLOAD, "evidence_audit", "http://localhost/v1/chat/completions", target, {"case_id": "test"}, 3, api_key="FAKE_TEST_ONLY", opener=opener)
            self.assertEqual(opener.requests[0][0].data, h.canonical(PAYLOAD))
            self.assertEqual((target / "response.body.bin").read_bytes(), raw)
            self.assertEqual(PAYLOAD, original)
            self.assertEqual(record["shape"]["usage"]["completion_tokens"], 9)
            self.assertEqual(record["state"], "delivered")
            self.assertEqual(decoded, json.loads(raw))
            self.assertNotIn("FAKE_TEST_ONLY", (target / "record.json").read_text())
            self.assertNotIn("Authorization", (target / "record.json").read_text())
            with self.assertRaises(FileExistsError):
                h.one_request(PAYLOAD, "evidence_audit", "http://localhost", target, {}, 3, opener=opener)
            self.assertEqual(len(opener.requests), 1)

    def test_delivered_bad_no_retry(self):
        opener = Opener(b'{"choices": []}')
        with tempfile.TemporaryDirectory() as temp:
            record, _ = h.one_request(PAYLOAD, "evidence_audit", "http://localhost", Path(temp)/"one", {}, 1, opener=opener)
        self.assertEqual(len(opener.requests), 1)
        self.assertEqual(record["state"], "delivered")
        self.assertFalse(record["will_retry"])

    def test_http_failure_not_zero_score(self):
        error = urllib.error.HTTPError("http://localhost", 503, "failure", {}, io.BytesIO(b"not ready"))
        opener = Opener(error=error)
        with tempfile.TemporaryDirectory() as temp:
            record, _ = h.one_request(PAYLOAD, "evidence_audit", "http://localhost", Path(temp)/"one", {}, 1, opener=opener)
        self.assertEqual(record["state"], "http_failure")
        self.assertEqual(record["http_status"], 503)
        self.assertEqual(len(opener.requests), 1)
        self.assertNotIn("score", record)

    def test_transport_error_redacts_exception_text(self):
        opener = Opener(error=urllib.error.URLError("FAKE_SECRET_EXCEPTION"))
        with tempfile.TemporaryDirectory() as temp:
            target = Path(temp)/"one"
            record, _ = h.one_request(PAYLOAD, "evidence_audit", "http://localhost", target, {}, 1, opener=opener)
            self.assertNotIn("FAKE_SECRET_EXCEPTION", (target/"record.json").read_text())
            self.assertFalse((target/"response.body.bin").exists())
        self.assertEqual(record["state"], "transport_failure")
        self.assertEqual(len(opener.requests), 1)

    def test_invalid_utf8_raw_preserved(self):
        opener = Opener(b"\xff\xfe")
        with tempfile.TemporaryDirectory() as temp:
            target = Path(temp)/"one"
            record, _ = h.one_request(PAYLOAD, "evidence_audit", "http://localhost", target, {}, 1, opener=opener)
            self.assertEqual((target/"response.body.bin").read_bytes(), b"\xff\xfe")
        self.assertEqual(record["response_json_error"], "UnicodeDecodeError")

    def test_endpoint_cannot_embed_credential(self):
        for bad in ("http://secret@example.org/v1", "http://example.org/v1?key=secret", "file:///etc/passwd"):
            with self.assertRaises(ValueError):
                h.endpoint_url(bad)
        self.assertEqual(h.endpoint_url("http://localhost:30000/v1"), "http://localhost:30000/v1/chat/completions")

    def test_redirect_rejected_and_not_delivered(self):
        request = h.urllib.request.Request("http://localhost", data=b"{}")
        self.assertIsNone(h.NoRedirect().redirect_request(request, None, 302, "redirect", {}, "http://other-host"))
        error = urllib.error.HTTPError("http://localhost", 302, "redirect", {}, io.BytesIO(b"redirect body"))
        opener = Opener(error=error)
        with tempfile.TemporaryDirectory() as temp:
            record, _ = h.one_request(PAYLOAD, "evidence_audit", "http://localhost", Path(temp)/"one", {}, 1, opener=opener)
        self.assertEqual(record["state"], "http_failure")
        self.assertEqual(record["http_status"], 302)
        self.assertEqual(len(opener.requests), 1)

    def test_incomplete_http_body_preserves_partial_and_record(self):
        class IncompleteStream(FakeStream):
            def read(self):
                raise http.client.IncompleteRead(b"partial body", 100)
        class IncompleteOpener:
            def open(self, request, timeout):
                return IncompleteStream()
        with tempfile.TemporaryDirectory() as temp:
            target = Path(temp)/"one"
            record, _ = h.one_request(PAYLOAD, "evidence_audit", "http://localhost", target, {}, 1, opener=IncompleteOpener())
            self.assertEqual((target/"response.body.bin").read_bytes(), b"partial body")
            self.assertTrue((target/"record.json").exists())
        self.assertEqual(record["state"], "transport_failure")
        self.assertTrue(record["response_body_incomplete"])
        self.assertEqual(record["transport_error_class"], "IncompleteRead")

    def test_http_error_body_read_failure_still_records(self):
        class BrokenStream(io.BytesIO):
            def read(self, *args, **kwargs):
                raise TimeoutError("FAKE_SECRET_ERROR_BODY")
        error = urllib.error.HTTPError("http://localhost", 503, "failure", {}, BrokenStream())
        with tempfile.TemporaryDirectory() as temp:
            target = Path(temp)/"one"
            record, _ = h.one_request(PAYLOAD, "evidence_audit", "http://localhost", target, {}, 1, opener=Opener(error=error))
            self.assertTrue((target/"record.json").exists())
            self.assertNotIn("FAKE_SECRET_ERROR_BODY", (target/"record.json").read_text())
        self.assertEqual(record["state"], "transport_failure")
        self.assertEqual(record["http_status"], 503)

    def test_run_exactly_two_duplicates_each_concurrency_condition(self):
        for concurrency in (1, 4):
            with self.subTest(concurrency=concurrency), tempfile.TemporaryDirectory() as temp:
                cases = [{"case_id": "case-" + str(i), "scenario": "evidence_audit", "original_request_id": str(i)} for i in range(4)]
                manifest = {"cases": cases}
                payloads = {case["case_id"]: copy.deepcopy(PAYLOAD) for case in cases}
                plan = {"run_id": "fixed-test", "endpoint": "http://unused"}
                sent = []
                def fake_one(payload, scenario, endpoint, output, metadata, timeout, key):
                    sent.append((copy.deepcopy(payload), metadata.copy()))
                    # Intentionally unusable delivery: it is not resampled.
                    return {"state": "delivered", "shape": {"protocol_shape_usable": False}}, None
                prepared = (Path(temp), manifest, payloads, None, plan)
                args = SimpleNamespace(variant="mock", concurrency=concurrency, timeout=1)
                with mock.patch.object(h, "prepare_run", return_value=prepared), mock.patch.object(h, "one_request", side_effect=fake_one):
                    self.assertEqual(h.run_replays(args), 0)
                self.assertEqual(len(sent), 8)
                self.assertTrue(all(payload == PAYLOAD for payload, _ in sent))
                observed = sorted((meta["case_id"], meta["duplicate"]) for _, meta in sent)
                self.assertEqual(observed, sorted((case["case_id"], duplicate) for case in cases for duplicate in (1, 2)))

    def test_nonce_complete_native_history_and_no_tools_final(self):
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp)
            prepared = (output, {}, {"audit_bad_first_1": copy.deepcopy(PAYLOAD)}, None, {"run_id": "test-native", "endpoint": "http://unused"})
            args = SimpleNamespace(variant="mock", timeout=1)
            sent = []
            def fake_one(payload, scenario, endpoint, target, metadata, timeout, key):
                sent.append(copy.deepcopy(payload))
                if metadata["decision"] == 1:
                    call = copy.deepcopy(CALL)
                    label = metadata["case_id"].split("nonce-", 1)[1]
                    call["function"]["arguments"] = json.dumps({"label": label})
                    reply = response(calls=[call], finish="tool_calls")
                    reply["choices"][0]["message"]["provider_opaque"] = {"keep": "exact"}
                    return {"state": "delivered", "shape": h.response_shape(reply, payload, scenario)}, reply
                note = payload["messages"][-1]["content"]
                reply = response(note)
                return {"state": "delivered", "shape": h.response_shape(reply, payload, scenario)}, reply
            with mock.patch.object(h, "prepare_run", return_value=prepared), mock.patch.object(h, "one_request", side_effect=fake_one):
                self.assertEqual(h.run_nonce(args), 0)
            self.assertEqual(len(sent), 4)
            for first, second in ((sent[0], sent[1]), (sent[2], sent[3])):
                self.assertEqual(second["tools"], first["tools"])
                self.assertEqual(second["messages"][:2], first["messages"])
                self.assertEqual(second["tool_choice"], "none")
                self.assertEqual(second["messages"][-2]["provider_opaque"], {"keep": "exact"})
                self.assertEqual(second["messages"][-1]["tool_call_id"], "call-1")
                for key in ("seed", "max_tokens", "temperature", "top_p", "reasoning_effort", "chat_template_kwargs"):
                    self.assertEqual(second[key], PAYLOAD[key])
            summary = json.loads((output/"SUMMARY.json").read_text())
            self.assertTrue(all(case["nonce_match_descriptive_only"] for case in summary["controls"]))

    def test_nonce_early_final_not_resampled(self):
        with tempfile.TemporaryDirectory() as temp:
            prepared = (Path(temp), {}, {"audit_bad_first_1": copy.deepcopy(PAYLOAD)}, None, {"run_id": "test-native", "endpoint": "http://unused"})
            reply = response("An early answer")
            fake = ({"state": "delivered", "shape": h.response_shape(reply, PAYLOAD, "synthetic_nonce")}, reply)
            args = SimpleNamespace(variant="mock", timeout=1)
            with mock.patch.object(h, "prepare_run", return_value=prepared), mock.patch.object(h, "one_request", return_value=fake) as sender:
                self.assertEqual(h.run_nonce(args), 0)
            self.assertEqual(sender.call_count, 2)


if __name__ == "__main__":
    unittest.main()
