#!/usr/bin/env python3
"""Bounded, read-only census of frozen PoolAct graph-key collisions.

Reads only explicitly indexed PoolAct-strategy NAS and Audit results: 44 pools
per model, 220 total. Does not recurse into raw, call a model/evaluator, or alter
historical scores. Its only write is the named diagnostic JSON beside this file.
"""
from __future__ import annotations

import argparse
import collections
import csv
import datetime
import hashlib
import io
import json
from pathlib import Path


ROOT = Path('/lustrefs/users/chufan.shi/codex_space_tn')
SOURCE_COMMIT = {
    'Kimi': '6119f9d136c9ed1f06a7bedd7371be0deb9b5d59',
    'GLM': '6119f9d136c9ed1f06a7bedd7371be0deb9b5d59',
    'Qwen': 'ff8c572b6a00c33964a00a8fb991fd79dcf900e4',
    'DeepSeek': '8c79111de3398d12fb36ba349d8f4266f2330200',
    'GPT': None,
}


def fingerprint(path: Path, raw: bytes) -> dict:
    return {'path': str(path.resolve()), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def canonical(payload: str) -> str | None:
    try:
        value = json.loads(payload)
    except (ValueError, TypeError, RecursionError, OverflowError):
        return None
    if not isinstance(value, (dict, list)):
        return None
    return json.dumps(value, sort_keys=isinstance(value, dict),
                      separators=(',', ':'))


def dict_parse(text: object, *, cleanup: bool) -> bool:
    if not isinstance(text, str):
        return isinstance(text, dict)
    try:
        value = json.loads(text)
    except (ValueError, RecursionError, OverflowError):
        if not cleanup:
            return False
        cleaned = text.strip().rstrip(';').strip()
        if cleaned.startswith('```'):
            cleaned = cleaned.split('\n', 1)[-1].rsplit('```', 1)[0].strip()
        try:
            value = json.loads(cleaned)
        except (ValueError, RecursionError, OverflowError):
            return False
    return isinstance(value, dict)


def run() -> dict:
    inputs, targets = [], []

    def read(path: Path, role: str) -> bytes:
        raw = path.read_bytes()
        inputs.append(dict(fingerprint(path, raw), role=role))
        return raw

    def csv_read(path: Path, role: str) -> list[dict]:
        return list(csv.DictReader(io.StringIO(read(path, role).decode())))

    for model, directory in (
        ('Kimi', 'publication/k3_composite_public_analysis_replay_v1'),
        ('GLM', 'publication/glm_public_analysis_replay_v1'),
    ):
        directory = ROOT / directory
        spec = json.loads(read(directory / 'ROOT_RELOCATION_SPEC.json',
                               'original_analysis_identity_and_restore_mapping'))
        index = json.loads(read(directory / 'relocated/source_index.relocated.json',
                                'explicit_original_artifact_to_restored_file_map'))
        # This is the completed original/composite selection, not a directory scan.
        for logical, physical in index.items():
            if not logical.endswith('/poolact/poolact/result.json'):
                continue
            scenario = ('tuning' if '/poolact/tuning/' in logical else
                        'evidence_audit' if '/poolact/evidence_audit/' in logical
                        else None)
            if scenario is None:
                continue
            budget = ('cost_moderate' if '/cost_moderate/' in logical else
                      'cost_tight' if '/cost_tight/' in logical else None)
            assert budget is not None
            targets.append({'model': model, 'scenario': scenario,
                            'budget': budget, 'logical_id': logical,
                            'path': Path(physical),
                            'original_analysis_source_index_sha256':
                                spec['original_inputs']['source_index']['sha256'],
                            'original_analysis_manifest_sha256':
                                spec['original_inputs']['manifest']['sha256']})

    for model, directory, version in (
        ('Qwen', 'qwen38_eval_20260910', 'full_v1'),
        ('DeepSeek', 'deepseek_flash_eval_20260911', 'full_v2'),
    ):
        directory = ROOT / directory
        read(directory / 'analysis' / version / 'INPUTS.json',
             'original_frozen_analysis_input_identity')
        rows = csv_read(directory / 'analysis' / version / 'normalized.csv',
                        'explicit_execution_to_artifact_root_map')
        for row in rows:
            if (row['system'] != 'poolact' or row['strategy'] != 'poolact'
                    or row['scenario'] not in ('tuning', 'evidence_audit')):
                continue
            targets.append({'model': model, 'scenario': row['scenario'],
                            'budget': row['regime'],
                            'logical_id': row['execution_id'],
                            'path': Path(row['artifact_root']) /
                                    'result/poolact/result.json'})

    gpt = ROOT / 'LLM_ExpGym_api_studies_20260910/studies/gpt56sol_medium_refmatrix_20260910_v1'
    read(gpt / 'analysis_v1/INPUTS.json', 'original_frozen_analysis_input_identity')
    rows = csv_read(gpt / 'analysis_v1/raw_terminals.csv',
                    'explicit_terminal_to_original_result_map')
    for row in rows:
        if (row['system'] != 'poolact' or row['strategy'] != 'poolact'
                or row['scenario'] not in ('tuning', 'evidence_audit')
                or row['agent_id'] != '0'):
            continue
        targets.append({'model': 'GPT', 'scenario': row['scenario'],
                        'budget': row['budget'], 'logical_id': row['job_id'],
                        'path': gpt / row['artifact']})

    matrix = collections.Counter((t['model'], t['scenario'], t['budget'])
                                 for t in targets)
    expected = {(model, scenario, budget): n
                for model in SOURCE_COMMIT
                for scenario, n in (('tuning', 9), ('evidence_audit', 13))
                for budget in ('cost_moderate', 'cost_tight')}
    assert dict(matrix) == expected, matrix
    assert len({t['path'].resolve() for t in targets}) == 220

    output = []
    for target in sorted(targets, key=lambda t: (t['model'], t['logical_id'])):
        raw = target['path'].read_bytes()
        result = json.loads(raw)
        assert result['strategy'] == 'poolact' and result['agents'] == 4
        assert len(result['agent_results']) == 4
        graph = result['shared_state']['graph']
        keys, terminal_rows = set(), []
        is_nas = target['scenario'] == 'tuning'
        for agent in result['agent_results']:
            records = (agent['eval_records'] if is_nas else
                       [record[1:] for record in agent['tool_records']
                        if record[0] == 'human_feedback'])
            for record in records:
                key = canonical(record[0])
                if key is not None:
                    keys.add(key)
            terminal = {'agent_id': agent['agent_id'],
                        'score_status': agent['score_status'],
                        'answer_is_null': agent['answer'] is None,
                        'terminal_origin': agent.get('terminal_origin'),
                        'termination_reason': agent.get('termination_reason')}
            if not is_nas:
                answer = agent['answer']
                direct = dict_parse(answer, cleanup=False)
                cleaned = dict_parse(answer, cleanup=True)
                terminal.update({
                    'strict_json_dict': direct,
                    'individual_evaluator_cleanup_json_dict': cleaned,
                    'cleanup_only_dict': cleaned and not direct,
                    'leading_fence': isinstance(answer, str) and
                                     answer.strip().startswith('```'),
                    'trailing_semicolon': isinstance(answer, str) and
                                          answer.strip().endswith(';'),
                })
            terminal_rows.append(terminal)
        short = collections.defaultdict(set)
        for key in keys:
            short[key[:80]].add(key)
        collision_groups = [group for group in short.values() if len(group) > 1]
        if is_nas:
            assert len(keys) == graph['eval_nodes'], (
                target['model'], target['logical_id'], len(keys), graph)
        out = {k: v for k, v in target.items() if k != 'path'}
        out.update({
            'source_commit': SOURCE_COMMIT[target['model']],
            'original_result': fingerprint(target['path'], raw),
            'candidate_key_scope': ('saved_visible_eval_records' if is_nas else
                                   'all_attempted_human_feedback_tool_records'),
            'distinct_full_keys': len(keys), 'distinct_prefix80_ids': len(short),
            'collision_groups': len(collision_groups),
            'keys_in_collision_groups': sum(map(len, collision_groups)),
            'keys_longer_than_80': sum(len(key) > 80 for key in keys),
            'max_key_length': max(map(len, keys), default=0),
            'saved_graph_stats': graph,
            'nas_reconstructed_count_matches_graph':
                len(keys) == graph['eval_nodes'] if is_nas else None,
            'saved_pool_terminal_status': result['terminal_status'],
            'terminal_members': terminal_rows,
        })
        output.append(out)

    summaries = []
    for model in SOURCE_COMMIT:
        for scenario in ('tuning', 'evidence_audit'):
            selected = [p for p in output if p['model'] == model and
                        p['scenario'] == scenario]
            members = [a for p in selected for a in p['terminal_members']]
            summary = {
                'model': model, 'scenario': scenario, 'pools': len(selected),
                'collision_pools': sum(p['collision_groups'] > 0 for p in selected),
                'collision_pools_by_budget': {
                    b: sum(p['collision_groups'] > 0 for p in selected if p['budget'] == b)
                    for b in ('cost_moderate', 'cost_tight')},
                'distinct_full_keys_sum_over_pools': sum(p['distinct_full_keys'] for p in selected),
                'distinct_prefix80_ids_sum_over_pools': sum(p['distinct_prefix80_ids'] for p in selected),
                'keys_in_collision_groups_sum_over_pools': sum(p['keys_in_collision_groups'] for p in selected),
                'keys_longer_than_80_sum_over_pools': sum(p['keys_longer_than_80'] for p in selected),
                'max_key_length': max(p['max_key_length'] for p in selected),
                'nonzero_pending_claim_pools': sum(p['saved_graph_stats']['pending_claims'] != 0 for p in selected),
                'member_score_status_counts': dict(collections.Counter(a['score_status'] for a in members)),
            }
            if scenario == 'evidence_audit':
                summary['syntax_only_counts'] = {
                    name: sum(a[name] for a in members) for name in (
                        'strict_json_dict', 'individual_evaluator_cleanup_json_dict',
                        'cleanup_only_dict', 'answer_is_null')}
            summaries.append(summary)
    assert all(p['saved_graph_stats']['pending_claims'] == 0 for p in output)
    return {
        'schema': 'bounded-five-model-graph-collision-census-v1',
        'audited_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scope': {'nas_pools': 90, 'audit_pools': 130, 'result_files_read': len(output),
                  'result_bytes_read': sum(p['original_result']['bytes'] for p in output),
                  'model_calls': 0, 'scorer_calls': 0, 'raw_directory_recursion': False},
        'method': [
            'Use explicit original/composite source maps; only PoolAct strategy, Moderate/Tight, NAS/Audit.',
            'NAS keys use saved visible eval_records first payload; canonical dict JSON sorts keys and uses compact separators, lists preserve order.',
            'Each NAS reconstructed distinct-key count must match original saved graph.eval_nodes.',
            'Collision means two different full canonical keys within one pool share their first 80 characters. Counts are summed within pools, not globally deduplicated.',
            'Audit uses all attempted human_feedback payloads as an upper bound on graph keys. If every key is <=80 chars there is no truncation collision even before excluding withheld attempts.',
            'Audit syntax comparison reproduces only strict JSON-dict acceptance vs the historical individual evaluator fence/semicolon cleanup; it does not compute or change a score.',
        ],
        'limits': [
            'Graph prefix collisions concern graph IDs/paths, not full-key cache or score records; prevalence does not identify effect size or direction.',
            'Pending-claim and terminal flags are checked saved evidence, not fresh runtime validation.',
            'No answer bodies or HTTP payloads are emitted. A terminal is located by its original_result path and agent_id in agent_results.',
            'Kimi uses the existing fixed8 composite relocation map; original failed attempts are not substituted for selected outcomes.',
            'GPT source is frozen local API study data, not a claim that original raw has been published.',
        ],
        'analysis_inputs': inputs,
        'summary': summaries,
        'pools': output,
        'script': fingerprint(Path(__file__), Path(__file__).read_bytes()),
    }


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path,
                        default=Path(__file__).with_suffix('.json'))
    args = parser.parse_args()
    report = run()
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'output': str(args.output.resolve()), 'scope': report['scope'],
                      'summary': report['summary']}, ensure_ascii=False, indent=2))
