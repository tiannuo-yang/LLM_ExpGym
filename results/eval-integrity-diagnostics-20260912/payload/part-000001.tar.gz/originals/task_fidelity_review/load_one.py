#!/usr/bin/env python3
"""Read one completed new smoke API dump once; print metadata/current reply only.

Reviewer should keep this returned JSON in session memory and page `review`
there, never reopen the original for metadata or additional text chunks.
No original request/history, headers, gold or key files are emitted.
"""
import argparse
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
COHORT = ROOT / "eval_diagnostics_20260912/graph_smoke/streamoff/cohort_v1"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    args = parser.parse_args()
    path = args.source.resolve()
    if path.suffix != ".json" or path.parent.name != "api_dump" or not any(path.is_relative_to(COHORT / branch) for branch in ("runs", "matched_runs")):
        raise ValueError("Outside the six-pool task-fidelity scope")
    pool = path.parent.parent
    if not (pool / "execution_finished.json").is_file():
        raise ValueError("No executor process-finished marker; refuse reading active dump")
    raw = path.read_bytes()  # The single source read.
    data = json.loads(raw)
    if data.get("state") == "in_progress":
        raise ValueError("A process-finished pool has an in_progress dump; report coverage gap, do not retry silently")
    response = data.get("response_json")
    choices = response.get("choices") if isinstance(response, dict) else None
    message = choices[0].get("message") if isinstance(choices, list) and choices and isinstance(choices[0], dict) else None
    message = message if isinstance(message, dict) else {}
    content = message.get("content")
    reasoning = message.get("reasoning_content")
    calls = message.get("tool_calls")
    context = data.get("context") or {}
    payload = data.get("request_payload") or {}
    text_content = content if isinstance(content, str) else json.dumps(content, ensure_ascii=False) if content is not None else ""
    text_reasoning = reasoning if isinstance(reasoning, str) else json.dumps(reasoning, ensure_ascii=False) if reasoning is not None else ""
    reply = {"reasoning_content": text_reasoning, "content": text_content, "tool_calls": calls,
             "other_current_message_fields": {key: value for key, value in message.items() if key not in ("role", "reasoning_content", "content", "tool_calls")}}
    meta = {"source_path": str(path), "source_bytes": len(raw), "source_sha256": hashlib.sha256(raw).hexdigest(),
            "pool_id": pool.name, "request_id": data.get("request_id"), "generation_id": data.get("generation_id"),
            "run_id": data.get("run_id"), "agent_id": context.get("agent_id"), "scenario": context.get("scenario"),
            "strategy": context.get("strategy"), "request_tool_choice": payload.get("tool_choice"),
            "state": data.get("state"), "http_status": data.get("http_status"),
            "error_type": data.get("error", {}).get("type") if isinstance(data.get("error"), dict) else None,
            "finish_reason": choices[0].get("finish_reason") if isinstance(choices, list) and choices and isinstance(choices[0], dict) else None,
            "usage": response.get("usage") if isinstance(response, dict) else None,
            "wall_seconds": data.get("wall_time_seconds"),
            "native_tool_call_count": len(calls) if isinstance(calls, list) else 0 if calls is None else None,
            "reasoning_characters": len(text_reasoning), "content_characters": len(text_content),
            "empty_visible_and_no_native_call": not text_content.strip() and not calls,
            "response_message_present": bool(message), "review_response_only_not_repeated_request_history": True}
    print(json.dumps({"metadata": meta, "review": reply}, ensure_ascii=False))


if __name__ == "__main__":
    main()
