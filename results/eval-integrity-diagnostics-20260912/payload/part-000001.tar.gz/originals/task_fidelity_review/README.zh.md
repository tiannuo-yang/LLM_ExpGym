# Deep 六池新任务输出：完整增量保真复核

六池全部 **47 个新完成 API 回复**均纳入并完整阅读，没有按得分、协议是否合法或
是否给出最终答案筛选。结果为 **46 连贯、1 语义循环退化、0 明显碎词／字符乱码**。
循环标签原样保留；有可读最终答案不意味着 reasoning 没有退化。

| 场景／策略 | 回复数／全文覆盖 | 连贯 | 循环退化 | 明显乱码 | 多工具回复 | 空可见且无工具 | length |
|---|---:|---:|---:|---:|---:|---:|---:|
| NAS PoolAct | 7/7 | 7 | 0 | 0 | 1 | 0 | 0 |
| Audit PoolAct | 8/8 | 8 | 0 | 0 | 0 | 0 | 0 |
| NAS naive | 8/8 | 8 | 0 | 0 | 2 | 0 | 0 |
| NAS cached | 8/8 | 8 | 0 | 0 | 2 | 0 | 0 |
| Audit naive | 8/8 | 8 | 0 | 0 | 0 | 0 | 0 |
| Audit cached | 8/8 | 7 | 1 | 0 | 0 | 0 | 0 |

完整覆盖当前回复 reasoning **209,335 字符**及 content **9,094 字符**；没有把
多轮请求中重复携带的旧历史再次人读。5 个多工具回复单独记形态，不因参数合法或
最终任务有分数而忽略。协议处理、graph 与评分验证由原执行者负责，此处未重跑
decoder、runner probe、评分器或模型。

## 唯一循环标签与定位

文件：
`graph_smoke/streamoff/cohort_v1/matched_runs/deepseek-v4-flash-0731-graph-v4-20260912-audit_q0-streamoff-matched-cached/api_dump/5b441bdc2c9443c19b0e8a14a467da92.json`

完整源文件 SHA256：
`58e1d00b65e41d4baab65fe3d737935909502bce9e5a4a410496acbfd745ca83`

这是 forced-final 回复，reasoning 长 15,938 字符，最后有可读答案、`finish_reason=stop`。
原 reader 从保留的 RAM 文本定位：以下为 reasoning 的 **0-based、end-exclusive**
字符区间，不是 dump 文件字节偏移。

- 约 `[3461,13462)` 持续讨论同一假设；前段含必要候选比较。
- `[7956,13462)` 约 5,506 字符集中反复决定、推翻并重启同一比较；约
  7956／8504／10320／11578／12900／12967／13349／13407 处再次作决定。
- 这段重复回到同样的代理访问、第三方禁止、强制披露例外和候选证据集合，
  未解决已有矛盾或形成稳定筛选规则；13462 后才转向其余假设收尾。

因此保留人工“持续语义循环／效率退化”标签，而不把它误称为随机字符乱码、
无限循环或未交付答案。该语义判断不构成 runtime 根因证明，最终复核可据原文查验，
不能按分数或合法最终格式覆盖这个标签。

## 一次读取与证据边界

执行者确认每池进程退出、文件终结后，reviewer 才读固定的完整 dump 清单。
每个源文件只由指定 reviewer 读取一次，同时计算 SHA、取得 metadata 和完整当前
回复；较长文字从 RAM 分段阅读，不重开原文件。每池独立 sidecar 保留其覆盖范围。
汇总只读取这些 sidecar、检查原文件名及大小，不再次读取原始正文或重算原 SHA。
所有 47 条均 full_read，无 unknown／not_fully_reviewed 隐藏缺口。

这是所选 NAS/Audit 的小规模工程 smoke，不是总体故障率、完整矩阵性能或策略
普遍改善的证明。没有明显字符乱码不等于全部生成问题已消失。先前首请求回放和
其后 late-state 八条均不在这个六池统计中。

## 查验入口

- [统一 CSV](fidelity.csv)：47 条 source SHA／metadata／人工标签及依据。
- [完整证据 JSON](fidelity.json)：六池全量文件名覆盖、read-once inventories、字符数。
- [逐池原始复核 sidecars](reviews/)：审阅分工及完整源身份。
- [增量方案](PLAN.zh.md)、[单次读取 helper](load_one.py)、[纯 metadata 汇总器](aggregate.py)。

```bash
/lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python -B \
  eval_diagnostics_20260912/task_fidelity_review/aggregate.py --check
```

最后一条循环定位说明补齐时，仅刷新了受影响的派生 CSV/JSON；未重读任何原 dump，
未改变标签、分数、模型输出或执行结果。
