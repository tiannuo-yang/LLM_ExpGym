# Deep 六池新任务输出：一次增量保真复核

范围仅限 `graph_smoke/streamoff/cohort_v1/runs` 和 `matched_runs` 的这次六池
新完成 API dump；不重新阅读旧首请求回放，不读取 gold，不执行请求、原 runner
probe 或评分。原 runner 协议、graph 与保存评分验证由 graph_gpu_smoke 负责。

每池收到执行者的结束确认后，固定该池全部 `api_dump/*.json` 文件清单；失败及
缺答不排除。每个原文件只由一名指定 reviewer 读取一次，读取时同时取得完整文件
SHA、bytes、状态、响应 shape／usage／finish 及当前回复的完整 reasoning/content。
多轮请求里复制的历史不重复人读。若文件仍为 in_progress，不将其当作完成输出阅读，
记录覆盖缺口并向执行者确认，不静默忽略。

人工标签沿用连贯／严重循环退化／明显乱码／不确定；没有足够全文阅读覆盖时记
`not_fully_reviewed`，不得以短输出、合法 JSON/schema、非空或得分代替人工判断。
当前回复是否多工具、空可见输出、length 停止分别计数，不混同生成可读性。
发现明确乱码立即通知 ROOT 和 graph_gpu_smoke，但本复核无自行停止 GPU 权限。

只写本目录的新逐池 review 记录、统一 CSV/JSON 和最终简短总结，记录实际覆盖的
文件、响应数和字符数。汇总使用 reviewer 已留存的 metadata／标签，不重读原 dump。
所有异常保留；六池结束后一次收尾。later-state 八请求不属于当前范围，需 ROOT
另行通知。
