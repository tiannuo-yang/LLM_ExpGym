#!/usr/bin/env python3
"""Aggregate read-once reviewer inventories; never opens original API dumps."""
import argparse
import csv
import hashlib
import io
import json
from pathlib import Path


OUT = Path(__file__).resolve().parent
DIAG = OUT.parent
COHORT = DIAG / "graph_smoke/streamoff/cohort_v1"
LABELS = ("coherent", "degenerate_repetition", "obvious_garbled", "uncertain", "not_fully_reviewed")


def identity(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def build():
    jobs, sources = [], [identity(Path(__file__)), identity(OUT / "load_one.py")]
    for name in ("pool_plan.json", "matched_plan.json"):
        path = COHORT / name
        jobs.extend(json.loads(path.read_text())["jobs"])
        sources.append(identity(path))
    if len(jobs) != 6 or len({job["id"] for job in jobs}) != 6:
        raise ValueError("Expected the fixed six-pool scope")
    expected = {}
    for job in jobs:
        pool = Path(job["root"])
        if not (pool / "execution_finished.json").is_file():
            raise ValueError("Pool process has not finished: " + job["id"])
        # Names and sizes only: no API file is opened by this aggregator.
        for path in sorted((pool / "api_dump").glob("*.json")):
            expected[str(path)] = {"pool_id": job["id"], "current_bytes": path.stat().st_size}
        sources.append(identity(pool / "execution_finished.json"))
    rows, reviewers, seen = [], [], set()
    for path in sorted((OUT / "reviews").glob("*.json")):
        review = json.loads(path.read_text())
        if review.get("schema") != "expgym.task-output-manual-review.v1" or review.get("source_files_read_once") is not True:
            raise ValueError("Unsupported reviewer inventory")
        reviewers.append(identity(path))
        for row in review["rows"]:
            source = row["source_path"]
            if source in seen or source not in expected:
                raise ValueError("Duplicate or out-of-scope raw inventory row")
            if row["source_bytes"] != expected[source]["current_bytes"] or row["pool_id"] != expected[source]["pool_id"]:
                raise ValueError("Source metadata changed or pool identity mismatch")
            if row["manual_label"] not in LABELS:
                raise ValueError("Unknown manual taxonomy")
            if row["full_read"] and (row["reviewed_reasoning_characters"] != row["reasoning_characters"] or row["reviewed_content_characters"] != row["content_characters"]):
                raise ValueError("Full-read coverage inconsistent")
            if not row["full_read"] and row["manual_label"] != "not_fully_reviewed":
                raise ValueError("Incomplete reading must not masquerade as a quality label")
            seen.add(source)
            rows.append({**row, "reviewer": review["reviewer"]})
    if seen != set(expected):
        raise ValueError("Missing raw-file coverage: " + str(len(set(expected) - seen)))
    rows.sort(key=lambda row: (row["pool_id"], row["request_id"] or ""))
    pools = []
    for job in jobs:
        selected = [row for row in rows if row["pool_id"] == job["id"]]
        pools.append({"pool_id": job["id"], "raw_attempts": len(selected),
                      "fully_read": sum(row["full_read"] for row in selected),
                      "manual_labels": {label: sum(row["manual_label"] == label for row in selected) for label in LABELS},
                      "multiple_native_call_responses": sum(isinstance(row["native_tool_call_count"], int) and row["native_tool_call_count"] > 1 for row in selected),
                      "empty_visible_and_no_native": sum(row["empty_visible_and_no_native_call"] for row in selected),
                      "length_stops": sum(row["finish_reason"] == "length" for row in selected),
                      "non_success_states": sum(row["state"] != "success" for row in selected),
                      "reasoning_characters": sum(row["reasoning_characters"] for row in selected),
                      "content_characters": sum(row["content_characters"] for row in selected),
                      "reviewed_reasoning_characters": sum(row["reviewed_reasoning_characters"] for row in selected),
                      "reviewed_content_characters": sum(row["reviewed_content_characters"] for row in selected)})
    csvrows = [{**row, "usage": json.dumps(row["usage"], ensure_ascii=False, sort_keys=True)} for row in rows]
    csvout = io.StringIO(newline="")
    writer = csv.DictWriter(csvout, fieldnames=list(dict.fromkeys(key for row in csvrows for key in row)), lineterminator="\n")
    writer.writeheader()
    writer.writerows(csvrows)
    result = {"schema": "expgym.six-pool-task-output-fidelity.v1", "scope": "Only the six newly completed streamoff cohort_v1 runs/matched_runs pools",
              "expected_pools": 6, "observed_pools": len(pools), "expected_raw_attempts": len(expected), "review_rows": len(rows),
              "fully_read_responses": sum(row["full_read"] for row in rows), "coverage_complete": all(row["full_read"] for row in rows),
              "manual_taxonomy": list(LABELS), "all_completed_dumps_included_without_score_filtering": True,
              "raw_read_policy": "Every raw source file was read once by its assigned reviewer; SHA and full response inspection were captured together. Aggregation only stats original filenames/sizes and reads reviewer sidecars, not original raw bytes again.",
              "hash_evidence_scope": "Raw SHA captures identity at completed-file inspection time; no second raw-content rehash performed during aggregation.",
              "quality_scope": "Current response reasoning/content inspected, not duplicated request-history text; manual readability is not a task score or causal proof.",
              "no_new_model_network_runner_or_score_calls": True,
              "protocol_scope": "Multi-call, empty-visible and length are observed shape flags only; automated protocol and score validation belongs to graph_gpu_smoke.",
              "fresh_raw_model_requests": 0, "old_replay_inputs_read": 0,
              "sources": sources, "review_inventories": reviewers, "pools": pools, "rows": rows}
    return {"fidelity.csv": csvout.getvalue(), "fidelity.json": json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n"}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--build", action="store_true")
    group.add_argument("--check", action="store_true")
    args = parser.parse_args()
    for name, text in build().items():
        if args.check:
            if (OUT / name).read_bytes() != text.encode("utf-8"):
                raise ValueError("Fidelity aggregation mismatch: " + name)
        else:
            with (OUT / name).open("x", encoding="utf-8") as handle:
                handle.write(text)
    print("PASS: six-pool raw filename/size coverage and read-once reviewer aggregation; no raw API bodies reread")
