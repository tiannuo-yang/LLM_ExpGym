#!/usr/bin/env python3
"""Private, bounded serving diagnostics; never an evaluation or retry runner.

`freeze` is local read-only inspection plus a new manifest. `run` makes exactly
the registered requests once per planned duplicate; it never retries a delivery.
No credentials are accepted from historical dumps or persisted from headers.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import copy
import datetime as dt
import hashlib
import http.client
import json
import os
from pathlib import Path
import re
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid


ROOT = Path(__file__).resolve().parent
ORIGINAL_ROOT = ROOT.parent / "deepseek_flash_eval_20260911"
CASES = (
    ("audit_bad_first_1", "job_5b175a687a752c5e3b18166c618d8568bb33c3f32284a918f700652a91b1d597", "a0e99c9991444c26b2e6ea92823e4c8b", "evidence_audit", "Previously audited first-turn garbling, before any tool or shared-graph history."),
    ("audit_bad_first_2", "job_118400b4d46b8ef19c3efbd25dd4d7782c3272b7bdd78ec97457ff5ba5b7140d", "96325f454ed74cfdad1c1e3001830fbb", "evidence_audit", "Second previously audited first-turn garbling case, before any tool or shared-graph history."),
    ("audit_native_control", "job_fa711c130ec49096564fdf6981208670baa684d2009618f38e17336d773cebd1", "5dbfaea2412845918331889d5f9e5f5f", "evidence_audit", "Same Audit document as first bad case; first native tool call was valid and frozen final EA was positive. Prompt 6155 vs 6619 characters. Selected without reading gold annotations."),
    ("search_native_control", "job_37a6e5271e730a9129a5307d4ae48aac23020b0d4b6e1799d2cc66615c20e121", "d66fef4269d64a37b7db34b91ae05766", "restricted_search", "First positive scored Search row in frozen terminal export; valid native first tool call. Selected without reading gold answers."),
)


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def write_json(path, value):
    # Every runtime artifact is new. Refuse overwrite, even after partial failure.
    with Path(path).open("x", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        handle.write("\n")


def checked_payload(case):
    path = Path(case["original_path"])
    data = path.read_bytes()
    if sha(data) != case["original_sha256"] or len(data) != case["original_bytes"]:
        raise ValueError("Frozen original identity changed: " + case["case_id"])
    original = json.loads(data)
    body = original["request_payload"]
    if sha(canonical(body)) != case["payload_canonical_sha256"]:
        raise ValueError("Frozen payload identity changed: " + case["case_id"])
    return body


def freeze(output):
    import csv

    index_path = ORIGINAL_ROOT / "analysis/full_v2/SOURCE_INDEX.json"
    index_bytes = index_path.read_bytes()
    index = {row["path"]: row for row in json.loads(index_bytes)["files"]}
    terminals_path = ORIGINAL_ROOT / "analysis/full_v2/raw_terminals.csv"
    terminals_bytes = terminals_path.read_bytes()
    terminal_rows = list(csv.DictReader(terminals_bytes.decode().splitlines()))
    manifest = {
        "schema": "expgym.private-serving-diagnostic-inputs.v1",
        "scope": "Purpose-selected serving diagnostic, NOT a performance corpus, study rerun, or representative error-rate estimate.",
        "originals_unchanged": True,
        "payload_projection": "request_payload only; exclude original endpoint, headers, API keys, trace outputs and gold annotations",
        "body_identity": "SHA256 of canonical UTF-8 JSON, sort_keys=True, ensure_ascii=False, compact separators; original wire serialization was not separately preserved",
        "source_index": {"path": str(index_path), "bytes": len(index_bytes), "sha256": sha(index_bytes)},
        "terminal_export": {"path": str(terminals_path), "bytes": len(terminals_bytes), "sha256": sha(terminals_bytes)},
        "planned_duplicates_per_case": 2,
        "duplicate_policy": "Two preplanned duplicate requests per case, original seed unchanged. Labels do not establish reproducibility or independent sampling; no result-dependent retry.",
        "concurrency_conditions": [1, 4],
        "per_condition_requests": 8,
        "preserved_fields": "Every original payload field, including messages, tools, tool_choice, parallel_tool_calls, model, max_tokens, temperature, top_p, seed, reasoning_effort, chat_template_kwargs, cache_salt",
        "new_identity_scope": "New local diagnostic run ID / output directory only; payload cache_salt is deliberately preserved for exact-body replay. This is serving-cache reuse, not shared mutable evaluation state.",
        "classification_limit": "Shape flags are protocol/schema diagnostics, not a readability score and not task correctness; no model/scorer/gold used to classify results.",
        "cases": [],
    }
    for case_id, job, request, scenario, reason in CASES:
        path = ORIGINAL_ROOT / "formal/invocations" / job / "api_dump" / (request + ".json")
        raw = path.read_bytes()
        item = index[str(path)]
        if sha(raw) != item["sha256"] or len(raw) != item["bytes"]:
            raise ValueError("SOURCE_INDEX mismatch: " + case_id)
        original = json.loads(raw)
        payload = original["request_payload"]
        if [message["role"] for message in payload["messages"]] != ["system", "user"]:
            raise ValueError("Not an untouched first request: " + case_id)
        # Explicit deny-list on metadata, never inspect values of credential keys.
        if any(key.lower() in {"authorization", "api_key", "headers", "access_token"} for key in payload):
            raise ValueError("Unexpected credential-bearing payload field")
        agent = original["context"].get("agent_id", 0)
        row = next(row for row in terminal_rows if row["execution_id"] == job and row["agent_id"] == str(agent))
        if "control" in case_id and not (row["score_status"] == "scored_final_answer" and float(row["raw_answer_perf"]) > 0):
            raise ValueError("Control must be a frozen positive final score")
        case = {
            "case_id": case_id, "scenario": scenario, "reason": reason,
            "original_path": str(path), "original_bytes": len(raw), "original_sha256": sha(raw),
            "source_index_sha256": item["sha256"], "original_run_id": original["run_id"],
            "original_request_id": original["request_id"], "original_agent_id": agent,
            "payload_canonical_sha256": sha(canonical(payload)), "payload_canonical_bytes": len(canonical(payload)),
            "message_characters": sum(len(message.get("content") or "") for message in payload["messages"]),
            "payload_settings": {key: value for key, value in payload.items() if key not in {"messages", "tools", "cache_salt"}},
            "original_response_shape": response_shape(original.get("response_json"), payload, scenario),
            "frozen_final_score": row["raw_answer_perf"],
            "frozen_final_score_status": row["score_status"],
        }
        if "control" in case_id and case["original_response_shape"]["valid_tool_calls"] < 1:
            raise ValueError("Control must have a schema-valid native first tool call")
        manifest["cases"].append(case)
    write_json(output, manifest)
    return manifest


def schema_errors(value, schema, where="$"):
    """The finite JSON-Schema subset present in these frozen tool schemas."""
    errors = []
    kinds = {
        "object": lambda x: isinstance(x, dict), "array": lambda x: isinstance(x, list),
        "string": lambda x: isinstance(x, str), "integer": lambda x: type(x) is int,
        "number": lambda x: type(x) in (int, float), "boolean": lambda x: type(x) is bool,
        "null": lambda x: x is None,
    }
    kind = schema.get("type")
    if kind and (kind not in kinds or not kinds[kind](value)):
        return [where + ": wrong type"]
    if "enum" in schema and value not in schema["enum"]:
        errors.append(where + ": outside enum")
    if isinstance(value, dict):
        for key in schema.get("required", []):
            if key not in value:
                errors.append(where + ": missing " + key)
        props = schema.get("properties", {})
        for key, child in value.items():
            if key in props:
                errors.extend(schema_errors(child, props[key], where + "." + key))
            elif schema.get("additionalProperties") is False:
                errors.append(where + ": unexpected property")
    if isinstance(value, list) and "items" in schema:
        for index, child in enumerate(value):
            errors.extend(schema_errors(child, schema["items"], where + "[" + str(index) + "]"))
    return errors


def content_object(content):
    if not isinstance(content, str) or not content.strip():
        return None, "empty"
    try:
        value = json.loads(content)
        return value, "strict_json"
    except (ValueError, RecursionError, OverflowError):
        # Same bounded fence/semicolon cleanup as current Audit evaluator.
        cleaned = content.strip().rstrip(";").strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.split("\n", 1)[-1].rsplit("```", 1)[0].strip()
        try:
            return json.loads(cleaned), "audit_cleanup_json"
        except (ValueError, RecursionError, OverflowError):
            return None, "not_json"


def response_shape(response, payload, scenario):
    result = {"envelope_valid": False, "valid_tool_calls": 0, "invalid_tool_calls": 0,
              "has_nonempty_content": False, "content_characters": 0,
              "reasoning_characters": 0, "finish_reason": None, "usage": None,
              "tool_schema_errors": [], "content_json_status": "not_checked",
              "content_json_object": False, "audit_entry_shape_valid": False,
              "protocol_shape_usable": False}
    if not isinstance(response, dict):
        return result
    result["usage"] = response.get("usage")
    choices = response.get("choices")
    if not isinstance(choices, list) or len(choices) != 1 or not isinstance(choices[0], dict):
        return result
    result["finish_reason"] = choices[0].get("finish_reason")
    message = choices[0].get("message")
    if not isinstance(message, dict) or message.get("role") != "assistant":
        return result
    result["envelope_valid"] = True
    result["assistant_message_keys"] = sorted(message)
    content = message.get("content")
    result["has_nonempty_content"] = isinstance(content, str) and bool(content.strip())
    result["content_characters"] = len(content) if isinstance(content, str) else 0
    reasoning = message.get("reasoning_content")
    result["reasoning_characters"] = len(reasoning) if isinstance(reasoning, str) else 0
    tool_schemas = {tool["function"]["name"]: tool["function"].get("parameters", {}) for tool in payload.get("tools", []) if tool.get("type") == "function"}
    calls = message.get("tool_calls")
    if calls is not None and not isinstance(calls, list):
        result["invalid_tool_calls"] = 1
        result["tool_schema_errors"].append(["tool_calls is not a list"])
    for call in calls if isinstance(calls, list) else []:
        errors = []
        function = call.get("function") if isinstance(call, dict) else None
        if not isinstance(call, dict) or call.get("type") != "function" or not isinstance(call.get("id"), str) or not call.get("id"):
            errors.append("invalid native tool-call envelope")
        if not isinstance(function, dict) or not isinstance(function.get("name"), str) or function["name"] not in tool_schemas:
            errors.append("unknown function")
        else:
            try:
                args = json.loads(function["arguments"])
                errors.extend(schema_errors(args, tool_schemas[function["name"]]))
            except (ValueError, TypeError, KeyError, RecursionError, OverflowError):
                errors.append("invalid JSON arguments")
        if payload.get("tool_choice") == "none":
            errors.append("tool call under forced-final none")
        if errors:
            result["invalid_tool_calls"] += 1
            result["tool_schema_errors"].append(errors)
        else:
            result["valid_tool_calls"] += 1
    value, status = content_object(content)
    result["content_json_status"] = status
    result["content_json_object"] = isinstance(value, dict)
    if isinstance(value, dict) and value:
        result["audit_entry_shape_valid"] = all(
            isinstance(entry, dict) and isinstance(entry.get("label"), str)
            and isinstance(entry.get("evidence_ids"), list)
            and all(type(item) is int for item in entry["evidence_ids"])
            for entry in value.values()
        )
    has_tools = result["valid_tool_calls"] > 0 and result["invalid_tool_calls"] == 0
    has_final = result["audit_entry_shape_valid"] if scenario == "evidence_audit" else result["has_nonempty_content"]
    result["protocol_shape_usable"] = bool(has_tools or (not calls and has_final))
    result["length_stop"] = result["finish_reason"] == "length"
    result["shape_is_not_task_score_or_readability"] = True
    return result


def endpoint_url(value):
    parsed = urllib.parse.urlsplit(value)
    if parsed.scheme not in ("http", "https") or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError("Endpoint must be credential-free http(s) base URL or completions URL")
    path = parsed.path.rstrip("/")
    if not path.endswith("/chat/completions"):
        path += "/chat/completions" if path.endswith("/v1") else "/v1/chat/completions"
    return urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, path, "", ""))


class NoRedirect(urllib.request.HTTPRedirectHandler):
    """A redirected POST is another network request, forbidden in this harness."""
    def redirect_request(self, request, stream, code, message, headers, new_url):
        return None


def read_body(stream):
    try:
        return stream.read(), None, False
    except http.client.IncompleteRead as exc:
        return exc.partial, type(exc).__name__, True
    except (http.client.HTTPException, urllib.error.URLError, TimeoutError, OSError) as exc:
        return None, type(exc).__name__, True


def one_request(payload, scenario, endpoint, output, metadata, timeout, api_key=None, opener=None):
    output = Path(output)
    output.mkdir(parents=False, exist_ok=False)
    body = canonical(payload)
    with (output / "request.json").open("xb") as handle:
        handle.write(body)
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = "Bearer " + api_key
    request = urllib.request.Request(endpoint, data=body, headers=headers, method="POST")
    record = {"schema": "expgym.private-serving-diagnostic-attempt.v1", **metadata,
              "started_at_utc": utc(), "request_body_sha256": sha(body),
              "request_body_bytes": len(body), "transport_attempt": 1, "will_retry": False,
              "request_headers_persisted": False, "response_headers_persisted": False}
    write_json(output / "started.json", record)
    started = time.monotonic()
    response = None
    raw = None
    http_status = None
    transport_error = None
    body_incomplete = False
    if opener is None:
        # Internal endpoint calls must not inherit ambient forwarding proxies.
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
    try:
        with opener.open(request, timeout=timeout) as stream:
            http_status = stream.status
            raw, transport_error, body_incomplete = read_body(stream)
    except urllib.error.HTTPError as exc:
        http_status = exc.code
        raw, transport_error, body_incomplete = read_body(exc)
    except (http.client.HTTPException, urllib.error.URLError, TimeoutError, OSError) as exc:
        # Class only: exception text can echo credential-bearing request details.
        transport_error = type(exc).__name__
    record["wall_seconds"] = time.monotonic() - started
    record["finished_at_utc"] = utc()
    record["http_status"] = http_status
    record["transport_error_class"] = transport_error
    record["response_body_incomplete"] = body_incomplete
    record["response_json_error"] = None
    if raw is not None:
        with (output / "response.body.bin").open("xb") as handle:
            handle.write(raw)
        record["response_body_sha256"] = sha(raw)
        record["response_body_bytes"] = len(raw)
        try:
            response = json.loads(raw.decode("utf-8"))
            write_json(output / "response.decoded.json", response)
        except (ValueError, UnicodeDecodeError, RecursionError, OverflowError) as exc:
            record["response_json_error"] = type(exc).__name__
    record["state"] = "transport_failure" if transport_error else "http_failure" if not http_status or http_status >= 300 else "delivered"
    record["shape"] = response_shape(response, payload, scenario)
    write_json(output / "record.json", record)
    return record, response


def read_manifest(path):
    raw = Path(path).read_bytes()
    manifest = json.loads(raw)
    if manifest.get("schema") != "expgym.private-serving-diagnostic-inputs.v1" or len(manifest["cases"]) != 4 or manifest["planned_duplicates_per_case"] != 2:
        raise ValueError("Unsupported diagnostic manifest")
    return manifest, sha(raw)


def prepare_run(args, mode):
    endpoint = endpoint_url(args.endpoint)
    if not re.fullmatch(r"[A-Za-z0-9_.-]+", args.variant):
        raise ValueError("Use a simple secret-free variant label")
    output = Path(args.output_dir).resolve()
    if not output.is_relative_to(ROOT) or output == ROOT:
        raise ValueError("New diagnostic outputs must stay below private diagnostic directory")
    output.mkdir(parents=True, exist_ok=False)
    manifest, identity = read_manifest(args.inputs)
    # Fail before making any calls if any original has changed.
    payloads = {case["case_id"]: checked_payload(case) for case in manifest["cases"]}
    api_key = os.environ.get(args.api_key_env) if args.api_key_env else None
    if args.api_key_env and not api_key:
        raise ValueError("Requested credential environment variable is unset")
    plan = {"schema": "expgym.private-serving-diagnostic-run.v1", "mode": mode,
            "run_id": "diag-" + uuid.uuid4().hex, "created_at_utc": utc(),
            "variant": args.variant, "endpoint": endpoint, "inputs_sha256": identity,
            "inputs_path": str(Path(args.inputs).resolve()), "harness_sha256": sha(Path(__file__).read_bytes()),
            "output_dir": str(output), "credentials_persisted": False,
            "http_timeout_seconds": args.timeout, "automatic_retries": 0,
            "concurrency": getattr(args, "concurrency", 1), "not_a_performance_corpus": True}
    return output, manifest, payloads, api_key, plan


def run_replays(args):
    output, manifest, payloads, api_key, plan = prepare_run(args, "frozen-first-request-replays")
    plan["planned_calls"] = 8
    plan["duplicates_per_case"] = 2
    plan["payload_changes"] = []
    write_json(output / "PLAN.json", plan)
    work = [(case, duplicate) for duplicate in (1, 2) for case in manifest["cases"]]
    def execute(work_item):
        case, duplicate = work_item
        identity = {"run_id": plan["run_id"], "variant": args.variant, "case_id": case["case_id"],
                    "duplicate": duplicate, "original_seed_preserved": True,
                    "original_request_id": case["original_request_id"], "not_a_retry": True}
        record, _ = one_request(payloads[case["case_id"]], case["scenario"], plan["endpoint"],
                                output / (case["case_id"] + "--duplicate-" + str(duplicate)),
                                identity, args.timeout, api_key)
        return record
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.concurrency) as pool:
        records = list(pool.map(execute, work))
    summary = {"schema": "expgym.private-serving-diagnostic-summary.v1", "run_id": plan["run_id"],
               "planned_calls": 8, "completed_attempt_records": len(records),
               "delivered": sum(record["state"] == "delivered" for record in records),
               "transport_or_http_failures": sum(record["state"] != "delivered" for record in records),
               "records": records, "not_a_performance_estimate": True}
    write_json(output / "SUMMARY.json", summary)
    return 0 if summary["transport_or_http_failures"] == 0 else 2


def run_nonce(args):
    output, manifest, payloads, api_key, plan = prepare_run(args, "separate-native-two-turn-control")
    plan["planned_calls_maximum"] = 4
    plan["cases"] = ["auto", "named-tool"]
    plan["description"] = "Two independent synthetic native tool/final controls. Not a task or a replay; no gold. Second turn occurs only after a valid native tool call; no resampling for coverage."
    plan["base_settings_case"] = "audit_bad_first_1"
    write_json(output / "PLAN.json", plan)
    summaries = []
    for label in plan["cases"]:
        case_dir = output / label
        case_dir.mkdir()
        nonce = "DIAG_NOTE_" + uuid.uuid4().hex[:12]
        tool = {"type": "function", "function": {"name": "read_note", "description": "Return the exact stored note for the requested label.", "parameters": {"type": "object", "properties": {"label": {"type": "string", "enum": [label]}}, "required": ["label"], "additionalProperties": False}}}
        payload = copy.deepcopy(payloads["audit_bad_first_1"])
        payload.update({"messages": [{"role": "system", "content": "Use the read_note tool to retrieve the requested note, then answer only with the exact note text. Do not invent the note."}, {"role": "user", "content": "Read the note labeled " + label + " and return its exact text."}], "tools": [tool], "parallel_tool_calls": False,
                        "tool_choice": "auto" if label == "auto" else {"type": "function", "function": {"name": "read_note"}},
                        "cache_salt": plan["run_id"] + "-" + label})
        write_json(case_dir / "CASE.json", {"label": label, "note": nonce, "synthetic_not_task": True})
        meta = {"run_id": plan["run_id"], "variant": args.variant, "case_id": "nonce-" + label, "decision": 1}
        first, response = one_request(payload, "synthetic_nonce", plan["endpoint"], case_dir / "decision-1", meta, args.timeout, api_key)
        summary = {"case_id": label, "first": first, "second_executed": False, "native_history_preserved": None,
                   "nonce_match_descriptive_only": None, "not_task_performance": True}
        if first["state"] == "delivered" and first["shape"]["valid_tool_calls"] == 1 and first["shape"]["invalid_tool_calls"] == 0:
            assistant = copy.deepcopy(response["choices"][0]["message"])
            call = assistant["tool_calls"][0]
            follow = copy.deepcopy(payload)
            follow["messages"] += [assistant, {"role": "tool", "tool_call_id": call["id"], "content": nonce}]
            follow["tool_choice"] = "none"
            second, final = one_request(follow, "synthetic_nonce", plan["endpoint"], case_dir / "decision-2", {**meta, "decision": 2}, args.timeout, api_key)
            summary.update({"second_executed": True, "native_history_preserved": follow["messages"][-2] == assistant,
                            "second": second, "nonce_match_descriptive_only": bool(second["shape"]["envelope_valid"] and isinstance(final["choices"][0]["message"].get("content"), str) and final["choices"][0]["message"]["content"].strip() == nonce)})
        summaries.append(summary)
    write_json(output / "SUMMARY.json", {"run_id": plan["run_id"], "controls": summaries, "no_result_dependent_retries": True})
    return 0 if all(item["first"]["state"] == "delivered" and (not item["second_executed"] or item["second"]["state"] == "delivered") for item in summaries) else 2


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    frozen = commands.add_parser("freeze", help="Local-only: freeze the four exact original request identities")
    frozen.add_argument("--output", type=Path, default=ROOT / "INPUTS.json")
    for command in ("run", "nonce"):
        sub = commands.add_parser(command, help="AUTHORIZED REAL CALLS: " + command)
        sub.add_argument("--inputs", type=Path, default=ROOT / "INPUTS.json")
        sub.add_argument("--endpoint", required=True)
        sub.add_argument("--variant", required=True)
        sub.add_argument("--output-dir", required=True)
        sub.add_argument("--timeout", type=float, default=1800)
        sub.add_argument("--api-key-env", help="Optional environment variable name only; never persisted")
        if command == "run":
            sub.add_argument("--concurrency", type=int, choices=(1, 4), required=True)
    args = parser.parse_args()
    if args.command == "freeze":
        freeze(args.output)
        print("Frozen four diagnostic inputs; no network calls.")
        return 0
    return run_replays(args) if args.command == "run" else run_nonce(args)


if __name__ == "__main__":
    raise SystemExit(main())
