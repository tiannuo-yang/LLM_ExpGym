# Private bounded serving diagnostic — 2026-09-12

This directory is not a formal rerun, a new performance corpus, or a publication
bundle. Historical results and dumps are read-only. Four purpose-selected frozen
first requests isolate serving behavior before tool execution or shared-graph
history: two previously observed garbled Audit replies, one successful native
Audit control on the same document, and one successful native Search control.
Selection reads frozen score/status and transport artifacts, never gold answers.

## Identity and scope

`INPUTS.json` binds source index and terminal export SHA256 identities plus each
original dump and canonical request-body identity. Replay sends every original
payload field unchanged, including model, reasoning effort, thinking flag,
temperature, top_p, seed, max_tokens, tools, tool_choice, native messages, and
cache_salt. Only destination endpoint and local diagnostic run/output identities
are new. Exact payload means JSON-value equivalence and identical canonical bytes
for new sends; original wire whitespace was not separately recorded.

There are exactly two preplanned duplicate sends per case, with original seed
unchanged. One condition has concurrency 1; the other has concurrency 4. Labels
do not prove deterministic or independent sampling. No bad, empty, malformed,
length-stopped, HTTP-failed, or transport-failed attempt is automatically retried.
Requests are not reordered based on outcomes. Failures remain failure records,
never task scores or zeros.

Before comparing concurrency conditions, the parent operator must drain the
owned endpoint and explicitly flush its serving cache before **each** condition,
recording the readiness/drain evidence and flush HTTP status/body separately.
The harness deliberately does not flush a potentially shared server or mutate
cache_salt itself. Without those controls, concurrency 1 then 4 is confounded by
prefix-cache warming and order. Even with cache flush, this tiny fixed-order
diagnostic does not establish independent samples or formal performance effects.

## Commands

Use the existing verified Python environment. `freeze` and tests are CPU-only.
`run` and `nonce` make real HTTP/model calls and require parent authorization.

```bash
/lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python -B replay_first_requests.py freeze
/lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python -B -m unittest -v test_replay_first_requests

# Parent substitutes the authorized internal serving endpoint and variant label.
/lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python -B replay_first_requests.py run \
  --endpoint http://NODE:PORT/v1 --variant baseline-tp8-c1 --concurrency 1 \
  --output-dir /lustrefs/users/chufan.shi/codex_space_tn/eval_diagnostics_20260912/baseline-tp8-c1

/lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python -B replay_first_requests.py run \
  --endpoint http://NODE:PORT/v1 --variant baseline-tp8-c4 --concurrency 4 \
  --output-dir /lustrefs/users/chufan.shi/codex_space_tn/eval_diagnostics_20260912/baseline-tp8-c4

/lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python -B replay_first_requests.py nonce \
  --endpoint http://NODE:PORT/v1 --variant baseline-tp8-native \
  --output-dir /lustrefs/users/chufan.shi/codex_space_tn/eval_diagnostics_20260912/baseline-tp8-native
```

If required, pass `--api-key-env NAME` after securely setting the named variable.
The harness never reads old keys or stores request/response headers. Ambient HTTP
proxies are disabled. The endpoint cannot contain embedded credentials or query
parameters. HTTP redirects are refused without following them. Interrupted body
reads retain available partial bytes and an explicit transport-failure record.
Each output directory and artifact is exclusively created; partial
outputs are retained, not overwritten or resumed. Script/manifest/source hashes
and endpoint/variant/concurrency/timeout are bound in each new plan.

## Artifacts and interpretation

Each run has `PLAN.json`, one directory per attempted case/duplicate, and
`SUMMARY.json`. Each attempt preserves:

- `request.json`: exact new canonical wire body, all native fields retained;
- `started.json`: pre-send metadata, with no headers or credentials;
- `response.body.bin`: exact received HTTP entity-body bytes, when delivered;
- `response.decoded.json`: parsed response, when JSON decoding succeeds;
- `record.json`: SHA/byte identities, timestamps, latency, HTTP status, usage,
  finish reason, envelope/JSON/tool-schema flags and failure classification.

The stored raw body is the HTTP **entity body**, not a packet capture or
upstream tokenizer trace. Tool argument validation uses the finite schema subset
in these four requests. Audit JSON cleanup matches the evaluator's bounded
fence/semicolon cleanup, but `audit_entry_shape_valid` checks shape only; no
labels/evidence are compared with gold. Search nonempty text is only a visible
content flag: it is **not** proof of readability or correctness. No hand-tuned
regex "garbling score" is used. Manual inspection must cite the actual bodies.

The separate `nonce` control follows the earlier native smoke design: `auto` and
named-tool cases, each at most two calls. It preserves the complete new assistant
message and tool-call ID into a forced-final `tool_choice=none` continuation with
the tool schema retained. It does not use task documents. A second request is
made only after a valid native tool call; early answers remain unresampled. The
nonce match is descriptive native-plumbing evidence, not a performance gate.
