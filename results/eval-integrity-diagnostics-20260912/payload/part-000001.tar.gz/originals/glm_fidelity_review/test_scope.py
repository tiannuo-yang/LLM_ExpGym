"""Four scope/fixture checks; no real GLM or Deep dump is opened."""
import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

import load_one


class ScopeTests(unittest.TestCase):
    def test_exact_pool_allowed(self):
        source = load_one.POOL / "api_dump/fixture.json"
        self.assertEqual(load_one.assert_scope(source), source.resolve())

    def test_siblings_deep_nested_and_nonjson_rejected(self):
        invalid = [
            load_one.POOL.parent / "glm-5_3-graph-v4-audit-cont-20260912-audit_q0-naive/api_dump/fixture.json",
            load_one.POOL.parent / "glm-5_3-graph-v4-audit-cont-20260912-audit_q0-cached/api_dump/fixture.json",
            load_one.DIAG / "graph_smoke/streamoff/cohort_v1/runs/any/api_dump/fixture.json",
            load_one.POOL / "api_dump/nested/fixture.json",
            load_one.POOL / "api_dump/fixture.json.tmp",
        ]
        for source in invalid:
            with self.subTest(source=str(source)), self.assertRaises(ValueError):
                load_one.assert_scope(source)

    def test_missing_marker_prevents_reader_loading(self):
        with mock.patch.object(load_one.Path, "is_file", return_value=False), \
             mock.patch.object(load_one, "load_shared", side_effect=AssertionError("must not load")), \
             mock.patch.object(load_one.sys, "argv", ["load_one.py", str(load_one.POOL / "api_dump/fixture.json")]):
            with self.assertRaisesRegex(ValueError, "not process-finished"):
                load_one.main()

    def test_synthetic_current_reply_only_and_one_source_read(self):
        with tempfile.TemporaryDirectory() as temp:
            cohort = Path(temp) / "cohort"
            pool = cohort / "runs/exact-pool"
            dump = pool / "api_dump/fixture.json"
            dump.parent.mkdir(parents=True)
            (pool / "execution_finished.json").write_text("{}")
            fixture = {"state": "success", "request_id": "fixture", "request_payload": {
                "messages": [{"role": "user", "content": "HISTORY_MUST_NOT_BE_EMITTED"}], "tool_choice": "none"},
                "response_json": {"choices": [{"finish_reason": "stop", "message": {
                    "role": "assistant", "reasoning_content": "fixture reasoning", "content": "fixture final", "tool_calls": None}}]}}
            dump.write_text(json.dumps(fixture))
            original_read = Path.read_bytes
            counts = {str(dump): 0}
            def counted_read(path):
                if str(path) in counts:
                    counts[str(path)] += 1
                return original_read(path)
            stdout = io.StringIO()
            with mock.patch.object(load_one, "COHORT", cohort), mock.patch.object(load_one, "POOL", pool), \
                 mock.patch.object(Path, "read_bytes", counted_read), \
                 mock.patch.object(load_one.sys, "argv", ["load_one.py", str(dump)]), contextlib.redirect_stdout(stdout):
                load_one.main()
            result = json.loads(stdout.getvalue())
            self.assertEqual(counts[str(dump)], 1)
            self.assertEqual(result["review"]["reasoning_content"], "fixture reasoning")
            self.assertEqual(result["review"]["content"], "fixture final")
            self.assertNotIn("HISTORY_MUST_NOT_BE_EMITTED", stdout.getvalue())


if __name__ == "__main__":
    unittest.main()
