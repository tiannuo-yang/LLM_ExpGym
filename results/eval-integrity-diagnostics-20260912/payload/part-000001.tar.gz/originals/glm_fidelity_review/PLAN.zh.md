# 新 GLM Audit PoolAct：有界全文保真复核准备

仅检查以下**一个预先选定的新池**，不因成绩改变选择：

`graph_smoke/glm_audit_continuation/runs/glm-5_3-graph-v4-audit-cont-20260912-audit_q0-poolact`

预计实际任务请求上限 10。所有完成 API dump 均进入固定 inventory，包括失败、
缺答、length、多调用；若文件数意外超出计划，不截断或隐藏，而应报告偏差。
该范围不包含新 naive/cached 池、旧 GLM 29 条、任何 Deep 数据或 controls；
未经全文阅读的旧记录不能补称为已通过全文质量检查。

## 启动闸门与一次读取

当前仅准备入口及 4 项纯 CPU scope／合成 fixture 测试，**不读取真实 GLM dump**。
必须同时等 ROOT 明确给出池完成通知，并存在 `execution_finished.json`，才开始。
入口先限制精确 pool/api_dump 路径（拒绝其他策略、Deep、嵌套路径和非 JSON），
然后按 SHA pin 导入既有 Deep-era loader 源码，仅在内存设置新 COHORT。
共享源码和 Deep 结果均不修改；复用源码不等于重新阅读 Deep 数据。

完成后固定全部实际文件清单，由两名已有 reviewer 按互斥文件各半负责。
每个原文件只读一次，同时生成 SHA／bytes／metadata 并把完整当前回复留在 RAM；
较长 reasoning/content 只从 RAM 分段人读，不重开原件。重复携带的请求历史、
headers、credentials 不输出。若已结束池仍遗留 in_progress dump 或无法读取的文件，
必须在 inventory 中保留缺口并报 ROOT，不能静默忽略或重试后装作完整覆盖。

人工标签为 coherent／degenerate_repetition／obvious_garbled／uncertain；
未完整阅读则明确记 not_fully_reviewed。可读性与多调用、空可见回复、length 等
形态分开；合法 schema、非空答案、短回复或正确得分不能代替全文判断。
不访问 gold，不执行 scorer、runner probe、HTTP 或任何模型／GPU 操作。
发现明确乱码立即告 ROOT，但无自行停止或追加实验权限。

只在本目录新增逐文件 metadata／标签和覆盖说明；所有结论只针对这一个新池，
不能外推为 GLM 全模型、旧 29 条、其他策略或控制样本的普遍质量证明。

准备验证：

```bash
/lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python -B \
  -m unittest -v test_scope
```

运行目录为本 `glm_fidelity_review`。真实读取命令须等 ROOT 释放后再使用：

```bash
/lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python -B \
  eval_diagnostics_20260912/glm_fidelity_review/load_one.py EXACT_COMPLETED_DUMP_PATH
```
