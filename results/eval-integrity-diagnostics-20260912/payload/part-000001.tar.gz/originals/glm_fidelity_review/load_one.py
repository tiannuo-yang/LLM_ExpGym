#!/usr/bin/env python3
"""Pinned current-reply reader for exactly one completed new GLM Audit pool."""
import argparse
import hashlib
from pathlib import Path
import sys


DIAG = Path(__file__).resolve().parent.parent
SHARED = DIAG / "task_fidelity_review/load_one.py"
SHARED_SHA256 = "b24ce6e46f9186c00d056b9c9c0640bb46f3c19f949ec62a050750dd883217ff"
COHORT = DIAG / "graph_smoke/glm_audit_continuation"
POOL = COHORT / "runs/glm-5_3-graph-v4-audit-cont-20260912-audit_q0-poolact"


def assert_scope(source):
    source = Path(source).resolve()
    if source.suffix != ".json" or source.parent != POOL.resolve() / "api_dump":
        raise ValueError("Only the exact new GLM Audit PoolAct api_dump directory is authorized")
    return source


def load_shared():
    raw = SHARED.read_bytes()  # Pinned helper source, never a Deep data file.
    if hashlib.sha256(raw).hexdigest() != SHARED_SHA256:
        raise ValueError("Shared read-once helper identity changed")
    namespace = {"__name__": "pinned_current_reply_loader", "__file__": str(SHARED)}
    exec(compile(raw, str(SHARED), "exec"), namespace)
    namespace["COHORT"] = COHORT
    return namespace["main"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    args = parser.parse_args()
    source = assert_scope(args.source)
    if not (POOL / "execution_finished.json").is_file():
        raise ValueError("Pool is not process-finished; no GLM dump may be read yet")
    reader = load_shared()
    original_argv = sys.argv
    try:
        sys.argv = [str(SHARED), str(source)]
        reader()  # Exact existing single read; only current reply + metadata.
    finally:
        sys.argv = original_argv


if __name__ == "__main__":
    main()
