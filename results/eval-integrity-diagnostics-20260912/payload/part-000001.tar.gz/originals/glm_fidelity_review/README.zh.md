# 新 GLM Audit PoolAct：全文输出保真复核

预先限定的单池 **8/8 请求全部全文读完**：**1 条 coherent、7 条持续语义重复、0 条明显乱码**。全文覆盖 438,696 个 reasoning 字符与 4,911 个 content 字符；两名 reviewer 按固定文件名顺序互斥各读 4 条，原文件各读一次。这里的字符指 Unicode codepoint。

## 需要区分的三个层面

- **传递与输出形态**：6 条单原生工具调用、2 条有可见 final；0 多调用、0 空答、0 length。执行者另行报告 2/2 最终答案有效、协议错误 0；本次不重复 decoder、runner 或 scorer。
- **文本可读性**：未发现字符乱码或明显 token 崩坏。没有把长回复或合法 schema 自动记为正常；所有当前 reasoning/content 均从 RAM 完整分页检查。
- **推理进展效率**：7 条可读文本存在长时间重复同一候选、预算/反馈解释、优先级及“已最终决定后再重开”的循环。最终能提交工具/答案不能覆盖这些标签；短暂必要候选比较不算循环。

这些是一个预定诊断池的观察，**不是 GLM 总体异常率，不证明 serving 故障，也不单独证明框架/计分 bug**。本复核没有读取 gold、旧 GLM 29、任何 Deep 数据或其他 GLM 策略；没有发模型请求。模型在自身文本里猜测数据来源/评分规则，不等同于已核实的输入事实。

## 全部请求

| 请求 ID 前缀 | Agent | Reasoning 字符 | Content 字符 | 输出形态 | 全文标签 |
|---|---:|---:|---:|---|---|
| 1facf321… | 1 | 1,403 | 234 | 单工具 | coherent |
| 52eebc8f… | 0 | 52,200 | 210 | 单工具 | degenerate_repetition |
| 55f415c9… | 0 | 53,470 | 1,236 | 单工具 | degenerate_repetition |
| 5ae11872… | 1 | 81,230 | 1,001 | 可见 final | degenerate_repetition |
| 757352ec… | 0 | 96,807 | 1,021 | 可见 final | degenerate_repetition |
| 8dc76556… | 0 | 41,491 | 534 | 单工具 | degenerate_repetition |
| a7cd8a7f… | 1 | 76,977 | 259 | 单工具 | degenerate_repetition |
| f927315c… | 1 | 35,118 | 416 | 单工具 | degenerate_repetition |

标签依据和代表性 **RAM 中当前 reasoning 的 0-based、末端不包含字符区间**保存在两份 review 中；这些区间是便于定位的人工近似段落边界，不代表只有该段被阅读。表格只显示 ID 前缀，完整路径与源 SHA 均见索引/CSV。

## 完整索引

- [INVENTORY.json](INVENTORY.json)：固定 8 文件清单、绝对原 dump 路径、读取当次 source SHA/字节数、互斥 reviewer 分配、loader pin。此文件在复核结束后记录预先分配的同一清单，不是事后择优抽样。
- [review_a.json](review_a.json)、[review_b.json](review_b.json)：逐条全文人工标签、依据、覆盖字符与循环定位。
- [fidelity.json](fidelity.json)：一次汇总、计数、完整逐条 metadata 与来源关系。
- [fidelity.csv](fidelity.csv)：全部 8 条的扁平可查验索引；原 source SHA 在首次唯一读取时计算，未二次重读原件做 hash。
- [PLAN.zh.md](PLAN.zh.md)、[load_one.py](load_one.py)：既定范围与精确单池、完成 marker、共享 reader SHA guard；没有更改旧 Deep reader/结果。

原始池：`/lustrefs/users/chufan.shi/codex_space_tn/eval_diagnostics_20260912/graph_smoke/glm_audit_continuation/runs/glm-5_3-graph-v4-audit-cont-20260912-audit_q0-poolact`。

所有当前回复在首次加载后均验证 stdout 是完整 JSON，提取文本的 Unicode 字符数等于 metadata，再从 RAM 分页。原始文件、最终答案与失败记录均未重写；本池实际 8 条全部保留，无失败漏选。归档后 STOP_WRITE。
