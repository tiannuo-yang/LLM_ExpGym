# 三项问题对当前结论的影响

仅分析冻结结果的影响范围；不改变原端点、原分数或原样本。

| 问题 | 发生范围（本次实读） | 对结论的严重性 | 决策 |
| --- | --- | --- | --- |
| 80 字符图路径 ID 碰撞 | 五模型 NAS PoolAct 80/90 池，见下表 | 中高：协调输入错误，广泛影响 NAS 轨迹；不是分数直接算错。无法从旧输出计算无偏的修后收益。 | 修复完整身份，并做回归和实际 smoke |
| GPT 图历史累计触发本地上下文限制 | 1881 个成员仅 1 次；受影响 NAS/Moderate/PoolAct 为 1/36 成员 | 全局低、该单格中等：能决定一个小差值的正负，不影响 ExpGym 单体 Free/Tight 与单体家族排名。 | 本轮暂不修改上下文策略，明确解释该格 |
| DeepSeek 非空乱码/破损结构/工具标记 | Tight Audit 每策略空答均 22/52，但 naive/cached/poolact 可解析 dict 15/11/2 | 高：对 DeepSeek 部署结果与算法归因有实质影响，不能仅用空答解释；尚未证明 serving 或模型的底层原因。 | 最高优先级定向 GPU A/B，保留负结果 |

## 图身份碰撞的数量

统计全部 36 个 GPT/DeepSeek NAS PoolAct 原结果，已保存 eval_records 重建配置数逐池匹配 graph.eval_nodes；不纳入超预算未共享结果。

- GPT：Moderate 9/9、Tight 9/9 有碰撞；各池 distinct 配置合计 423，仅 158 个前缀 ID；318 个配置落入碰撞组。
- DeepSeek：Moderate 3/9、Tight 7/9 有碰撞；78 个配置仅 43 个前缀 ID；49 个配置落入碰撞组。
- 两模型全部 52 个 Audit PoolAct 池的 canonical feedback key 最长 57/54 字符，小于 80：Audit 无此碰撞。
- 单体 ExpGym 不使用该共享图，因此其预算退化与单体 ranking reshuffle 不直接受此缺陷影响。不能由此推断其他协议/部署影响为零。

后续扩展核查覆盖全部五模型：明确读取 90 个 NAS + 130 个 Audit PoolAct 结果；90 个 NAS 的完整配置重建数全部匹配保存的 graph.eval_nodes，220 个池的 pending_claims 全部为 0。

| 模型 | NAS 碰撞池 | Moderate / Tight | 完整配置数 → 前缀 ID 数（逐池求和） |
| --- | --- | --- | --- |
| Kimi | 17/18 | 9/9，8/9 | 356 → 172 |
| GLM | 18/18 | 9/9，9/9 | 490 → 265 |
| Qwen | 17/18 | 9/9，8/9 | 440 → 236 |
| DeepSeek | 10/18 | 3/9，7/9 | 78 → 43 |
| GPT | 18/18 | 9/9，9/9 | 423 → 158 |

全部 130 个 Audit 池无此碰撞。逐原件路径/大小/SHA、算法及计数见 `graph_collision_census.json`；可复现脚本为 `graph_collision_census.py`。这是保存结果的路径身份审计，不是修复后的模型运行或效果量。

## GPT 唯一上下文终止的敏感度

原 Moderate NAS Gap0-MI：PoolAct 95.579679，naive 98.211271，差值 −2.631592。
该设置 9 个池、每池 4 人；若缺失者交付 Gap=G，设置均值增加 G/36。

| 假设交付原 trace 已见配置 | Gap | 均值增加 | 假设 PoolAct MI | 假设相对 naive |
| --- | --- | --- | --- | --- |
| 最后一次可见配置 | 99.184812 | 2.755134 | 98.334813 | +0.123542 |
| 最佳可见配置 | 99.669198 | 2.768589 | 98.348268 | +0.136997 |

这只是敏感度，不是实际修复结果，不证明模型一定会交付该配置，不能用来替换原 missing/Gap0。
Gap 没有 100 的硬上限，因此上述不是数学最大影响界限。

## 对三个主问题的边界

1. **反馈预算退化**：图碰撞不直接影响 ExpGym 单体；原数值仍可复算。DeepSeek 只能解释为冻结 serving stack 的实测输出，不扩张成纯模型能力。
2. **PoolAct 提升**：NAS 协调图有已确认缺陷；GPT Moderate NAS 的负值受单次 context stop 影响；DeepSeek Audit 另有广泛生成异常。不能把三个问题互相替代解释，也不能保证修复后所有差值为正。
3. **家族与预算的最优模型换位**：当前排名取 ExpGym 单体，不直接使用 PoolAct 图；数值排序没算错，但模型部署差异及 DeepSeek 异常限制纯能力/算法因果解释。

旧分数、失败、未知项与全部 raw 保留。定向诊断不添加到原正式样本中。

## GPU 诊断中新发现的独立协议问题

Audit native 任务提示词把固定 `nda-11 / [3,7]` 写成没有示例标签的调用命令。
这与 PoolAct 的“该调用正在进行，请选择其他动作”可能冲突；原系统指令和真实
tool schema 虽然正确，也不能消除任务文本中的矛盾。源修复已删除固定可执行参数，
改为依据当前文档选择验证项。legacy text、数据、schema、答案与评分均未修改；
这是所有 native 模型共享的 task-prompt 修复，不是 DeepSeek 专属补丁。

另一个问题位于冻结 DeepSeek serving 路径：`parallel_tool_calls=false` 没有得到
单调用约束实现。v1 排序 schema 诊断的 6 个 Audit 响应中有 5 个含多个 native 调用，
会被 runner 按原规则拒绝；不能将各调用的 schema 合法记为整轮协议合法。
该组输入有诊断 helper 的字段顺序错误，不是原始提示词精确回放，也不是总体发生率。
修复任务指令并不等于修复 serving 约束；后者仍待独立验证。

这些新证据不证明历史乱码的根因，更不能从有限诊断推算正式 PoolAct 效果。
修复源码为 `b3382b1`；722 项测试、5 skip、假模型四条 runner 路径通过。
实际 GPU 验证及 matched-strategy 数值对照仍待完成，旧正式分数不改。

保序 v2 首请求回放已全部结束，16条真实wire与独立renderer预期身份/计数一致：

| 条件 | 请求 | 完整输出连贯 | 严重循环退化 | 明显碎词/字符乱码 | 原runner可执行 |
| --- | --- | --- | --- | --- | --- |
| concurrency1 | 8 | 8 | 0 | 0 | 5 |
| concurrency4 | 8 | 2 | 4 | 2 | 6 |

人工标签来自完整阅读，不是按输出长短判断；runner列由冻结原decoder和实际单步
runner的CPU inert-tool回放核对，既不是任务得分也不是GPU成功率。并发组两条乱码中，
一条是reasoning-only空答，另一条最后仍输出17个工具调用：只数空答会漏掉真实退化。
串行组3条多调用、并发组1条多调用和1条空答均按原协议保留拒绝。
这证实当前GPU部署路径能复现生成异常，但非确定采样、请求顺序和初始化状态
尚不允许把变化唯一归因为并发或某个kernel。见 `v2_contract_review/`。

ROOT已在24个baseline任务请求完成/flush后主动结束job1205016；保留8.34 allocated
GPU-hours成本。候选job1205022在同节点同8GPU上启动，仅关闭多stream重叠并显式
保持baseline有效server seed。候选首组8请求已完成：8连贯、0循环退化、0明显乱码；
6条原runner接受、2条多调用整批拒绝。wire/token身份8/8匹配。见 `candidate_contract_review/`。
该结果支持继续验证，而不是根因证明。候选实际六池PoolAct/naive/cached已于01:37 UTC放行，
结束后还将执行预留的后段8请求检查。GLM NAS PoolAct已完成并复核，Audit仍在运行；
目前不宣称完整任务稳定或策略性能提升已经验证。通用源码/skill已推送修复分支b3382b1，
旧正式数据和已有结果分支未改；见 `SOURCE_PUBLICATION.json`。

## 缺陷来源：原仓库与本次移植的责任分开

读取 Git 历史可明确区分，不能把所有问题笼统归给上游：

- 图身份截断 `return "E:{}".format(config_key[:80])` 已存在于初始公开版本
  `aa135b17e625e7091bf6294c47859b8ffec10e02`（2026-05-05，
  `expgym/extras/parallel_cache.py` 的 `_eval_key`）。它不是本轮模型适配中新加的。
- 无示例标签的 native Audit 命令由我们的 portable-v3 适配提交
  `18fa994a3e34c6c051411b22bdcc4efcda4d3f6b`（2026-09-08）引入：
  原 `Action: human_feedback ...` 文本模板被改写为命令式 `Call ...`。
  这是此次移植引入的通用提示兼容性缺陷，不应推责给原论文实现或 DeepSeek。
- 诊断 v1 排序 JSON schema 的错误由本次诊断 helper 引入，已公开标注且保留8次成本；
  v2 保序回放纠正该错误，不能用 v1 作为原请求的精确重放证据。

以上来源只解释相应实现缺陷，不构成旧表现下降或候选生成改善的单一因果证明。

## 修后 DeepSeek 固定六池：已完成但并非所有差值为正

同一候选服务的 NAS/Audit × naive/cached/PoolAct 六池全部完成，47次请求、12/12完整评分。
NAS raw accuracy MI：naive=cached 0.845886747，PoolAct 0.862062633；BoN 分别0.845886747、0.878238519。
Audit EA-MI：naive=cached 0.382352941，PoolAct 0.323529412；EA-MV：naive 0.352941176、
cached 0.411764706、PoolAct 0.352941176。负值保留，两固定任务/N2/R1不能替代正式矩阵。

全文复核47条：46连贯、1语义重复思考、0明显碎词乱码，见`task_fidelity_review/`。
重复出现在cached最终回答，仍形成合法有效答案；不能由此推断其他任务总体故障率为零。
NAS保留两次既有legacy fallback；共享配置终局选择的限制符合该政策而非意外scalar错误，
具体例子/CPU控制见`shared_final_audit/`，本轮不切换评分端点或覆盖原分数。

预留后段8请求也已完成，分类另行保留；ROOT于01:53:17排空后主动释放1205022，
候选共63任务请求、6.1578 allocated GPU-hours。GLM同配置matched对照尚在进行。
