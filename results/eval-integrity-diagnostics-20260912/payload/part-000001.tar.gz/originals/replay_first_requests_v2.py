#!/usr/bin/env python3
"""Bounded original-order DeepSeek replay v2; preserves all v1 artifacts.

Wire bytes use exactly the frozen llm_clients.py expression:
    json.dumps(payload).encode("utf-8")
Sorted canonical JSON is only semantic identity, NEVER the outgoing body.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import http.client
import json
import os
from pathlib import Path
import re
import time
import urllib.error
import urllib.request
import uuid

import replay_first_requests as shared


ROOT = Path(__file__).resolve().parent
V1_HELPER_SHA = "0d602b58a5f675ddd8a115379e22301eb57499293b066b08684dc66c7e5a17ed"
V1_INPUTS_SHA = "b686460c88683a146cb0c280d3e654f8e4128e85a171e246953c1b0761b86610"
AUDIT_SHA = "f19b3c525770b993846fb5e39ae4f08fb43ed60a879a1877a3f7f04057a6bb7c"
CLIENT_SOURCE = ROOT.parent / "LLM_ExpGym-deepseek-flash-20260911/expgym/llm_clients.py"
CLIENT_SHA = "59f1e78f518fb7e0e85fda51cc163b2e54c533de68f5d94607f3ac1e05dcd2c5"


def wire_body(payload):
    # Do not add sort_keys, custom separators or ensure_ascii=False here.
    return json.dumps(payload).encode("utf-8")


def identify(path, expected=None):
    path = Path(path)
    raw = path.read_bytes()
    actual = shared.sha(raw)
    if expected is not None and actual != expected:
        raise ValueError("Pinned source changed: " + str(path))
    return {"path": str(path.resolve()), "bytes": len(raw), "sha256": actual}


def freeze(output):
    sources = {
        "v1_helper": identify(ROOT / "replay_first_requests.py", V1_HELPER_SHA),
        "original_input_manifest": identify(ROOT / "INPUTS.json", V1_INPUTS_SHA),
        "frozen_client_source": identify(CLIENT_SOURCE, CLIENT_SHA),
        "original_prompt_cpu_audit": identify(ROOT / "serving_audit/RESULT.v1.json", AUDIT_SHA),
    }
    original = json.loads((ROOT / "INPUTS.json").read_bytes())
    audit = json.loads((ROOT / "serving_audit/RESULT.v1.json").read_bytes())
    audited = {case["case_id"]: case for case in audit["cases"]}
    cases = []
    for source in original["cases"]:
        payload = shared.checked_payload(source)
        wire = wire_body(payload)
        proof = audited[source["case_id"]]
        replay = proof["replay"]
        if proof["original_sha256"] != source["original_sha256"] or shared.sha(wire) != replay["reconstructed_client_request_serialization_sha256"]:
            raise ValueError("Ordered wire bytes differ from independent frozen renderer audit")
        case = {**source,
                "ordered_wire_sha256": shared.sha(wire), "ordered_wire_bytes": len(wire),
                "expected_rendered_prompt_utf8_sha256": replay["rendered_prompt_utf8_sha256"],
                "expected_rendered_token_ids_json_sha256": replay["rendered_token_ids_json_sha256"],
                "expected_prompt_tokens": replay["replayed_prompt_tokens"],
                "tool_property_order": [[*tool["function"].get("parameters", {}).get("properties", {})] for tool in payload.get("tools", [])]}
        cases.append(case)
    result = {
        "schema": "expgym.private-serving-diagnostic-inputs.v2",
        "sources": sources, "cases": cases,
        "planned_duplicates_per_case": 2, "allowed_concurrencies": [1, 4],
        "planned_calls_per_condition": 8,
        "wire_serialization": {"expression": "json.dumps(payload).encode('utf-8')", "source_line": 385, "sort_keys": False, "ensure_ascii": True, "separators": [", ", ": "]},
        "semantic_hash_is_not_wire_or_rendered_identity": True,
        "v1_status": "Preserved order-perturbed diagnostic; not historical exact replay. v1 sorted nested JSON keys before sending.",
        "prompt_identity_scope": "Expected hashes inherited from independent actual-renderer CPU audit of these exact ordered wire bodies; no new renderer/model run by this helper.",
        "sampling_scope": "Original request seeds retained; recorded FlashInfer nondeterministic sampler ignores per-request seed, so token-equal output is not expected.",
        "selection_scope": "The same four fixed diagnostic cases; not a performance corpus or new independent samples.",
    }
    shared.write_json(output, result)
    return result


def checked_cases(path):
    raw = Path(path).read_bytes()
    manifest = json.loads(raw)
    if manifest.get("schema") != "expgym.private-serving-diagnostic-inputs.v2" or len(manifest["cases"]) != 4 or manifest["planned_duplicates_per_case"] != 2:
        raise ValueError("Unsupported v2 manifest")
    identify(ROOT / "replay_first_requests.py", V1_HELPER_SHA)
    for source in manifest["sources"].values():
        identify(source["path"], source["sha256"])
    payloads = {}
    for case in manifest["cases"]:
        payload = shared.checked_payload(case)
        wire = wire_body(payload)
        if shared.sha(wire) != case["ordered_wire_sha256"] or len(wire) != case["ordered_wire_bytes"]:
            raise ValueError("Ordered wire identity changed: " + case["case_id"])
        payloads[case["case_id"]] = payload
    return manifest, payloads, shared.sha(raw)


def one_request(payload, scenario, endpoint, output, metadata, timeout, api_key=None, opener=None):
    output = Path(output)
    output.mkdir(parents=False, exist_ok=False)
    body = wire_body(payload)
    with (output / "request.json").open("xb") as handle:
        handle.write(body)
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = "Bearer " + api_key
    request = urllib.request.Request(endpoint, data=body, headers=headers, method="POST")
    record = {"schema": "expgym.private-serving-diagnostic-attempt.v2", **metadata,
              "started_at_utc": shared.utc(), "request_wire_sha256": shared.sha(body), "request_wire_bytes": len(body),
              "request_semantic_canonical_sha256": shared.sha(shared.canonical(payload)),
              "transport_attempt": 1, "will_retry": False, "request_headers_persisted": False, "response_headers_persisted": False}
    shared.write_json(output / "started.json", record)
    raw = response = http_status = transport_error = None
    body_incomplete = False
    if opener is None:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), shared.NoRedirect())
    started = time.monotonic()
    try:
        with opener.open(request, timeout=timeout) as stream:
            http_status = stream.status
            raw, transport_error, body_incomplete = shared.read_body(stream)
    except urllib.error.HTTPError as exc:
        http_status = exc.code
        raw, transport_error, body_incomplete = shared.read_body(exc)
    except (http.client.HTTPException, urllib.error.URLError, TimeoutError, OSError) as exc:
        transport_error = type(exc).__name__
    record.update({"wall_seconds": time.monotonic() - started, "finished_at_utc": shared.utc(),
                   "http_status": http_status, "transport_error_class": transport_error,
                   "response_body_incomplete": body_incomplete, "response_json_error": None})
    if raw is not None:
        with (output / "response.body.bin").open("xb") as handle:
            handle.write(raw)
        record.update({"response_body_sha256": shared.sha(raw), "response_body_bytes": len(raw)})
        try:
            response = json.loads(raw.decode("utf-8"))
            shared.write_json(output / "response.decoded.json", response)
        except (ValueError, UnicodeDecodeError, RecursionError, OverflowError) as exc:
            record["response_json_error"] = type(exc).__name__
    record["state"] = "transport_failure" if transport_error else "http_failure" if not http_status or http_status >= 300 else "delivered"
    record["shape"] = shared.response_shape(response, payload, scenario)
    # The v1 schema flag is deliberately retained but explicitly not upgraded to
    # native ReAct acceptance: that runner permits exactly one native call.
    calls = None
    if record["shape"]["envelope_valid"]:
        calls = response["choices"][0]["message"].get("tool_calls")
    record["native_raw_tool_call_count"] = len(calls) if isinstance(calls, list) else 0 if calls is None else None
    record["native_exactly_one_schema_valid_tool_call"] = bool(
        isinstance(calls, list) and len(calls) == 1 and record["shape"]["valid_tool_calls"] == 1 and record["shape"]["invalid_tool_calls"] == 0)
    record["schema_shape_flag_is_not_runner_acceptance"] = True
    shared.write_json(output / "record.json", record)
    return record, response


def run(args):
    manifest, payloads, manifest_sha = checked_cases(args.inputs)
    endpoint = shared.endpoint_url(args.endpoint)
    if not re.fullmatch(r"[A-Za-z0-9_.-]+", args.variant):
        raise ValueError("Variant must be a simple secret-free label")
    output = Path(args.output_dir).resolve()
    if output == ROOT or not output.is_relative_to(ROOT) or "v2" not in output.name:
        raise ValueError("New v2 output directory must be inside diagnostic root and contain v2 in its name")
    output.mkdir(parents=True, exist_ok=False)
    api_key = os.environ.get(args.api_key_env) if args.api_key_env else None
    if args.api_key_env and not api_key:
        raise ValueError("Credential environment variable is unset")
    plan = {"schema": "expgym.private-serving-diagnostic-run.v2", "run_id": "diag-v2-" + uuid.uuid4().hex,
            "variant": args.variant, "endpoint": endpoint, "created_at_utc": shared.utc(),
            "helper": identify(__file__), "shared_helper": identify(ROOT / "replay_first_requests.py", V1_HELPER_SHA),
            "inputs_sha256": manifest_sha, "inputs_path": str(Path(args.inputs).resolve()),
            "concurrency": args.concurrency, "planned_calls": 8, "duplicates_per_case": 2,
            "http_timeout_seconds": args.timeout, "automatic_retries": 0,
            "wire_serialization": manifest["wire_serialization"], "payload_changes": [],
            "original_key_order_preserved": True, "not_a_performance_corpus": True,
            "cache_flush_owner": "Root operator drains and flushes owned serving endpoint before each condition; records control evidence separately.",
            "sampling_note": manifest["sampling_scope"]}
    shared.write_json(output / "PLAN.json", plan)
    work = [(case, duplicate) for duplicate in (1, 2) for case in manifest["cases"]]
    def execute(item):
        case, duplicate = item
        metadata = {"run_id": plan["run_id"], "variant": args.variant, "case_id": case["case_id"], "duplicate": duplicate,
                    "original_request_id": case["original_request_id"], "original_seed_preserved": True, "not_a_retry": True,
                    "expected_rendered_prompt_utf8_sha256": case["expected_rendered_prompt_utf8_sha256"],
                    "expected_prompt_tokens": case["expected_prompt_tokens"], "rendered_identity_source": manifest["sources"]["original_prompt_cpu_audit"]}
        record, _ = one_request(payloads[case["case_id"]], case["scenario"], endpoint,
                                output / (case["case_id"] + "--duplicate-" + str(duplicate)), metadata, args.timeout, api_key)
        return record
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.concurrency) as pool:
        records = list(pool.map(execute, work))
    summary = {"schema": "expgym.private-serving-diagnostic-summary.v2", "run_id": plan["run_id"],
               "planned_calls": 8, "completed_attempt_records": len(records),
               "delivered": sum(row["state"] == "delivered" for row in records),
               "transport_or_http_failures": sum(row["state"] != "delivered" for row in records), "records": records,
               "not_a_performance_estimate": True, "v1_runs_remain_separate": True}
    shared.write_json(output / "SUMMARY.json", summary)
    return 0 if summary["transport_or_http_failures"] == 0 else 2


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    frozen = sub.add_parser("freeze", help="CPU only: bind ordered wire identity to existing frozen actual-renderer audit")
    frozen.add_argument("--output", type=Path, default=ROOT / "INPUTS.v2.json")
    command = sub.add_parser("run", help="AUTHORIZED REAL CALLS: exactly 4 original-order cases x 2 fixed duplicates")
    command.add_argument("--inputs", type=Path, default=ROOT / "INPUTS.v2.json")
    command.add_argument("--endpoint", required=True)
    command.add_argument("--variant", required=True)
    command.add_argument("--concurrency", type=int, choices=(1, 4), required=True)
    command.add_argument("--output-dir", required=True)
    command.add_argument("--timeout", type=float, default=1800)
    command.add_argument("--api-key-env")
    args = parser.parse_args()
    if args.command == "freeze":
        freeze(args.output)
        print("Frozen v2 ordered-wire identities; no network or model calls.")
        return 0
    return run(args)


if __name__ == "__main__":
    raise SystemExit(main())
