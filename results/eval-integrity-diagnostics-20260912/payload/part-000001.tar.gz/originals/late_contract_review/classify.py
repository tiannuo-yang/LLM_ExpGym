#!/usr/bin/env python3
"""Classify only the eight completed late-state responses using existing probes.

No new model/network calls, fixtures, old-response review or scorer execution.
The imported implementation is reused in memory; its frozen source is unchanged.
"""
import argparse
import importlib.util
import json
from pathlib import Path


OUT = Path(__file__).resolve().parent
DIAG = OUT.parent
HELPER = DIAG / "candidate_contract_review/classify.py"
CONDITION = "multistream-off-v2-c4-after-smokes"
spec = importlib.util.spec_from_file_location("existing_candidate_contract", HELPER)
candidate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(candidate)


def build():
    # Redirect only this module instance's input/output namespace, not files or
    # the frozen serializer. The same existing proof/contract paths are reused.
    candidate.OUT = OUT
    candidate.CONDITION = CONDITION
    outputs = candidate.build()
    result = json.loads(outputs["classification.json"])
    earlier_path = DIAG / "candidate_contract_review/classification.json"
    earlier = json.loads(earlier_path.read_text())
    late_condition = result["conditions"][-1]
    result["schema"] = "expgym.offline-late-state-contract-review.v1"
    result["conditions"] = earlier["conditions"] + [late_condition]
    result.pop("candidate_scope", None)
    result["scope"] = "Only eight predetermined same-input late-state c4 responses after all six smoke pools, on the same multistream-off deployment. Previous result tables are inherited metadata; old raw replies are not reread."
    result["previous_candidate_classification"] = candidate.prior.probe_module.identity(earlier_path)
    result["candidate_pre_run_control"] = candidate.prior.probe_module.identity(DIAG / "serving/multistream-off/control-before-late-v2-c4/CONTROL.json")
    result["sources"].append(candidate.prior.probe_module.identity(Path(__file__)))
    result["no_fixtures_or_extra_review_ladder_added"] = True
    result["scope_does_not_include_six_pool_quality_scores"] = True
    outputs["classification.json"] = json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    return outputs


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--build", action="store_true")
    group.add_argument("--check", action="store_true")
    args = parser.parse_args()
    for name, text in build().items():
        if args.check:
            if (OUT / name).read_bytes() != text.encode("utf-8"):
                raise ValueError("Late-state sidecar mismatch: " + name)
        else:
            with (OUT / name).open("x", encoding="utf-8") as handle:
                handle.write(text)
    print("PASS: eight new late-state replies, ordered wire/response identity, existing inert one-step runner contract")
