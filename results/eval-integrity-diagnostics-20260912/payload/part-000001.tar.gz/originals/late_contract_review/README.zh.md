# 六池之后的 late-state 八请求复核

六池共 47 个任务请求结束后，在同一 multistream-off 服务上按前瞻计划完成最后
8 个原始顺序首请求。**8 条全文均连贯，未观察到明显乱码或严重循环退化**；
其中 7 条通过原 runner 的单工具派发规则，1 条含 10 个工具调用而被整批拒绝。
这说明本组较晚运行状态没有复现原配置 c4 的字符／碎词崩坏，但仍不证明根因已解决。

| 条件 | 条数 | 连贯 | 循环退化 | 明显乱码 | 原 runner 接受 | 多调用拒绝 | 空回复拒绝 |
|---|---:|---:|---:|---:|---:|---:|---:|
| 原配置 v2 c1 | 8 | 8 | 0 | 0 | 5 | 3 | 0 |
| 原配置 v2 c4 | 8 | 2 | 4 | 2 | 6 | 1 | 1 |
| multistream-off 初始 c4 | 8 | 8 | 0 | 0 | 6 | 2 | 0 |
| multistream-off 六池之后 c4 | 8 | 8 | 0 | 0 | 7 | 1 | 0 |

前三组仅继承已经完成的分类 metadata；没有重新阅读其旧响应。六池中的那条
Audit cached 语义循环反例仍保留在 [六池复核](../task_fidelity_review/README.zh.md)，
不因最后 8 条连贯而删除，也不把不同阶段混成独立总体故障率。

## 最后八条全部结果

| 固定输入 | 重复 | 人工全文标签 | Native 数 | 原 runner | 输出 token |
|---|---:|---|---:|---|---:|
| audit_bad_first_1 | 1 | 连贯 | 1 | 接受一次派发 | 2,284 |
| audit_bad_first_1 | 2 | 连贯 | 10 | 多调用整批拒绝 | 9,095 |
| audit_bad_first_2 | 1 | 连贯 | 1 | 接受一次派发 | 7,291 |
| audit_bad_first_2 | 2 | 连贯 | 1 | 接受一次派发 | 4,401 |
| audit_native_control | 1 | 连贯 | 1 | 接受一次派发 | 2,227 |
| audit_native_control | 2 | 连贯 | 1 | 接受一次派发 | 3,147 |
| search_native_control | 1 | 连贯 | 1 | 接受一次派发 | 88 |
| search_native_control | 2 | 连贯 | 1 | 接受一次派发 | 106 |

两名已有 reviewer 分工完整阅读当前 reasoning **124,808 字符**、content **160 字符**。
较长回复包含冗余及反复法律语义比较，但仍围绕实质区别推进并形成具体决策；
没有仅凭长度、非空或合法 schema 判断连贯。连贯不代表答案正确或模型自述可靠。

8 条实际保序 wire bytes／SHA 均与冻结原输入及既有 actual-renderer 身份链一致；
8 条 prompt token 均匹配各案例预期 1974／2824／1860／730。使用已有冻结 decoder
及原单步 native runner／惰性 spy 复核，停止于 forced-final 前；不执行真实任务工具
或评分器。未加模型请求、测试 fixture 或新的审阅层；最终 `--check` 通过。

运行前排空与 flush 见
[late control](../serving/multistream-off/control-before-late-v2-c4/CONTROL.json)，
任务请求全部结束后的资源释放见 [RELEASE.zh.md](../serving/multistream-off/RELEASE.zh.md)。
本复核不操作 GPU，不将 root 正常收尾取消 allocation 解释成中途取消模型输出。

## 解释与存档

这是固定 4 输入×2 次的有界、预先保留检查，不是对坏样本重新抽取。它补充了
初始候选检查，但未随机化、未恢复相同 RNG 消费序列，也不建立总体稳定性或严格
因果。多工具兼容性问题仍存在，六池另有 1 个人工语义循环标签；都应进入最终结论。

- [逐条 CSV](classification.csv)
- [wire／raw 身份与原 runner 证据](classification.json)
- [完整人工阅读标签及覆盖](MANUAL_READABILITY.json)
- [复用既有检查路径的 helper](classify.py)

```bash
/lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python -B \
  eval_diagnostics_20260912/late_contract_review/classify.py --check
```
