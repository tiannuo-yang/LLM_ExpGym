"""Record control-plane evidence for this diagnostic's owned server only."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import urllib.error
import urllib.request

parser = argparse.ArgumentParser()
parser.add_argument('--deployment', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--flush', action='store_true')
args = parser.parse_args()
root = Path(__file__).resolve().parent
deployment_bytes = args.deployment.read_bytes()
deployment = json.loads(deployment_bytes)
assert args.deployment.resolve().is_relative_to(root / 'serving')
assert args.output.resolve().is_relative_to(root)
base = deployment['endpoints'][0].removesuffix('/v1')
args.output.mkdir(parents=True, exist_ok=False)
opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
records = []
for route in (['/health', '/get_model_info', '/metrics', '/flush_cache'] if args.flush
              else ['/health', '/get_model_info', '/metrics']):
    try:
        with opener.open(base + route, timeout=30) as stream:
            status, body = stream.status, stream.read()
    except urllib.error.HTTPError as exc:
        status, body = exc.code, exc.read()
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        status, body = None, type(exc).__name__.encode()
    path = args.output / (route.strip('/') + '.body')
    with path.open('xb') as handle:
        handle.write(body)
    records.append({'route': route, 'status': status,
                    'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                    'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()})
    if status != 200:
        break
with (args.output / 'CONTROL.json').open('x') as handle:
    json.dump({'deployment_sha256': hashlib.sha256(deployment_bytes).hexdigest(),
               'job_id': deployment['job_id'], 'endpoint': base,
               'task_generation_calls': 0,
               'health_generation_attempts_maximum': 1,
               'health_generation_note': 'SGLang /health may generate one token when idle; this is not a zero-compute probe. Startup warmup is separate. Raw internal tokens are not returned by this route.',
               'flush_requested': args.flush,
               'control_requests': records,
               'note': 'A successful SGLang flush confirms its running and waiting queues were empty at the control operation; not a general teardown proof.'}, handle, indent=2)
    handle.write('\n')
print(json.dumps(records))
raise SystemExit(0 if all(row['status'] == 200 for row in records) else 2)
