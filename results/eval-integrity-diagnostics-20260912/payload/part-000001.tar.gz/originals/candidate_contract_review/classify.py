#!/usr/bin/env python3
"""Offline classification of the completed multistream-off candidate only.

Reuses the already-tested frozen-decoder/inert-runner probe. Does not run models,
rescore tasks, rerun old audits, or inspect partial candidate responses.
"""
from __future__ import annotations

import argparse
import csv
import importlib.util
import io
import json
from pathlib import Path


OUT = Path(__file__).resolve().parent
DIAG = OUT.parent
CONDITION = "multistream-off-v2-c4"
PRIOR_HELPER = DIAG / "v2_contract_review/classify.py"
spec = importlib.util.spec_from_file_location("frozen_v2_contract_probe", PRIOR_HELPER)
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)


def build():
    summary_path = DIAG / CONDITION / "SUMMARY.json"
    summary = json.loads(summary_path.read_text())
    if summary.get("completed_attempt_records") != 8 or len(summary.get("records", [])) != 8:
        raise ValueError("Candidate must finish all eight attempts before inspection")
    manual_path = OUT / "MANUAL_READABILITY.json"
    manual = json.loads(manual_path.read_text())
    labels = {(row["case_id"], row["duplicate"]): row for row in manual["rows"]}
    if len(labels) != 8:
        raise ValueError("Need eight SHA-bound full-read annotations")
    manifest, payloads, _ = prior.wire_helper.checked_cases(DIAG / "INPUTS.v2.json")
    cases = {case["case_id"]: case for case in manifest["cases"]}
    rows, inputs, probes = [], [], []
    for item in summary["records"]:
        case_id, duplicate = item["case_id"], item["duplicate"]
        folder = DIAG / CONDITION / (case_id + "--duplicate-" + str(duplicate))
        record_path, response_path, request_path = folder / "record.json", folder / "response.body.bin", folder / "request.json"
        record = json.loads(record_path.read_text())
        if record != item:
            raise ValueError("Summary/record mismatch")
        raw, wire = response_path.read_bytes(), request_path.read_bytes()
        if prior.probe_module.sha(raw) != record["response_body_sha256"]:
            raise ValueError("Response hash mismatch")
        case = cases[case_id]
        if wire != prior.wire_helper.wire_body(payloads[case_id]) or prior.probe_module.sha(wire) != record["request_wire_sha256"] or record["request_wire_sha256"] != case["ordered_wire_sha256"]:
            raise ValueError("Original ordered wire fidelity mismatch")
        annotation = labels[(case_id, duplicate)]
        if annotation["response_body_sha256"] != prior.probe_module.sha(raw) or annotation["label"] not in ("coherent", "degenerate_repetition", "obvious_garbled", "uncertain"):
            raise ValueError("Manual annotation identity/taxonomy mismatch")
        payload = json.loads(wire)
        client_error = None
        try:
            data, text, calls, assistant, finish = prior.probe_module.OpenAICompatibleLLM._decode_response(raw)
            if record["state"] != "delivered" or record["http_status"] != 200:
                client_error = "non_successful_http_delivery"
        except (ValueError, TypeError, RecursionError) as exc:
            client_error = type(exc).__name__
            data, text, calls, assistant, finish = {}, "", [], {}, None
        schemas = {tool["function"]["name"]: tool["function"]["parameters"] for tool in payload["tools"]}
        valid = 0
        for call in calls:
            try:
                function = call["function"]
                valid += bool(function["name"] in schemas and prior.probe_module.schema_valid(json.loads(function["arguments"]), schemas[function["name"]]))
            except (ValueError, TypeError, KeyError, RecursionError):
                pass
        probe = (prior.actual_runner_probe(text, calls, assistant, finish, payload) if client_error is None else
                 {"first_decision_fake_tool_executions": 0, "natural_final_accepted_without_scoring": False,
                  "first_decision_accepted": False, "not_probed_reason": "Client/HTTP delivery failure; not converted into a model zero or successful abstention"})
        dispatch = probe["first_decision_fake_tool_executions"] == 1
        if client_error is not None:
            classification = "client_or_http_failure_not_scored"
        elif dispatch:
            classification = "accept_one_native_tool"
        elif probe["natural_final_accepted_without_scoring"]:
            classification = "accept_natural_final_without_scoring"
        elif len(calls) > 1:
            classification = "reject_multiple_native_tools"
        elif not calls and not text:
            classification = "reject_empty_visible_response"
        else:
            classification = "reject_other_protocol_decision"
        usage = data.get("usage") or {}
        rows.append({"condition": CONDITION, "case_id": case_id, "duplicate": duplicate,
                     "original_request_id": record["original_request_id"], "original_dump_sha256": case["original_sha256"],
                     "request_wire_sha256": record["request_wire_sha256"], "response_body_sha256": prior.probe_module.sha(raw),
                     "response_body_bytes": len(raw), "raw_tool_calls": len(calls), "schema_valid_tool_calls": valid,
                     "client_transport_accepted": client_error is None, "client_error_class": client_error,
                     "runner_first_decision_dispatch_accepted": dispatch,
                     "runner_first_decision_accepted": probe["first_decision_accepted"], "runner_classification": classification,
                     "manual_readability_label": annotation["label"], "manual_readability_basis": annotation["basis"],
                     "finish_reason": finish, "expected_prompt_tokens": case["expected_prompt_tokens"],
                     "prompt_tokens": usage.get("prompt_tokens"), "prompt_token_count_matches": usage.get("prompt_tokens") == case["expected_prompt_tokens"],
                     "completion_tokens": usage.get("completion_tokens"), "reasoning_tokens": usage.get("reasoning_tokens"),
                     "total_tokens": usage.get("total_tokens"), "wall_seconds": record["wall_seconds"]})
        probes.append({"case_id": case_id, "duplicate": duplicate, **probe})
        inputs.extend(prior.probe_module.identity(path) for path in (record_path, response_path, request_path))
    current = {"condition": CONDITION, "attempts": 8,
               "client_or_http_failures": sum(not row["client_transport_accepted"] for row in rows),
               "schema_all_calls_valid_responses": sum(row["raw_tool_calls"] > 0 and row["schema_valid_tool_calls"] == row["raw_tool_calls"] for row in rows),
               "runner_first_decision_dispatch_accepted": sum(row["runner_first_decision_dispatch_accepted"] for row in rows),
               "runner_first_decision_accepted": sum(row["runner_first_decision_accepted"] for row in rows),
               "runner_multicall_rejected": sum(row["runner_classification"] == "reject_multiple_native_tools" for row in rows),
               "runner_empty_visible_rejected": sum(row["runner_classification"] == "reject_empty_visible_response" for row in rows),
               "prompt_token_count_matches": sum(row["prompt_token_count_matches"] for row in rows),
               "manual_label_counts": {label: sum(row["manual_readability_label"] == label for row in rows) for label in ("coherent", "degenerate_repetition", "obvious_garbled", "uncertain")}}
    previous_path = DIAG / "v2_contract_review/classification.json"
    previous = json.loads(previous_path.read_text())
    csvout = io.StringIO(newline="")
    writer = csv.DictWriter(csvout, fieldnames=list(rows[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    result = {"schema": "expgym.offline-candidate-contract-review.v1", "conditions": previous["conditions"] + [current],
              "comparison_scope": "Descriptive same-selected-input comparison only. Conditions are not randomized or token-deterministic; no population effect estimate or proof that a runtime defect is solved.",
              "candidate_scope": "One completed eight-request c4 candidate with multistream disabled; no task scores or full trajectories.",
              "fresh_model_calls": 0, "no_network_real_tools_gold_or_evaluator": True,
              "method": "Reuse already-tested frozen client decoder and actual one-step native runner with inert tool spies; stops before forced final.",
              "manual_method": manual["method"],
              "sources": [prior.probe_module.identity(Path(__file__)), prior.probe_module.identity(PRIOR_HELPER), prior.probe_module.identity(prior.probe_module.REPO / "expgym/react_loop.py"), prior.probe_module.identity(prior.probe_module.REPO / "expgym/llm_clients.py")],
              "manifest": prior.probe_module.identity(DIAG / "INPUTS.v2.json"), "manual_labels": prior.probe_module.identity(manual_path),
              "previous_classification": prior.probe_module.identity(previous_path),
              "run_plan": prior.probe_module.identity(DIAG / CONDITION / "PLAN.json"), "run_summary": prior.probe_module.identity(summary_path),
              "candidate_deployment": prior.probe_module.identity(DIAG / "serving/multistream-off/deployment.json"),
              "candidate_pre_run_control": prior.probe_module.identity(DIAG / "serving/multistream-off/control-before-v2-c4/CONTROL.json"),
              "inputs": inputs, "rows": rows, "cpu_runner_probes": probes}
    return {"classification.csv": csvout.getvalue(), "classification.json": json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n"}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--build", action="store_true")
    group.add_argument("--check", action="store_true")
    args = parser.parse_args()
    for name, text in build().items():
        if args.check:
            if (OUT / name).read_bytes() != text.encode("utf-8"):
                raise ValueError("Candidate sidecar mismatch: " + name)
        else:
            with (OUT / name).open("x", encoding="utf-8") as handle:
                handle.write(text)
    print("PASS: eight candidate raw/wire identities, frozen one-step runner probe, full-read manual labels")
