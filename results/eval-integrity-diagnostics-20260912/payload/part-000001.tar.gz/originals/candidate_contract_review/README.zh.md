# 关闭 multistream 候选：八条首请求独立复核

本次候选的 8 条完整 reasoning/content 均连贯，**未观察到 baseline c4 中的
明显乱码或严重循环退化**。但仍有 2 条 schema 合法的多工具输出被原 runner
整批拒绝，因此只能说生成质量在这个固定小样本上改善，不能说所有兼容性问题已解决。

| 条件 | 条数 | 连贯 | 循环退化 | 明显乱码 | 原 runner 接受首决策 | 多工具拒绝 | 空回复拒绝 |
|---|---:|---:|---:|---:|---:|---:|---:|
| 原配置 v2 c1 | 8 | 8 | 0 | 0 | 5 | 3 | 0 |
| 原配置 v2 c4 | 8 | 2 | 4 | 2 | 6 | 1 | 1 |
| multistream-off v2 c4 | 8 | 8 | 0 | 0 | 6 | 2 | 0 |

本表读取已冻结的前两组独立复核结果，不重新读取或重跑旧模型实验。

## 本次全部八条

| 固定输入 | 重复 | 人工全文标签 | Native 调用数 | 原 runner | 输出 token |
|---|---:|---|---:|---|---:|
| audit_bad_first_1 | 1 | 连贯 | 10 | 多调用整批拒绝 | 6,637 |
| audit_bad_first_1 | 2 | 连贯 | 1 | 接受一次工具派发 | 2,999 |
| audit_bad_first_2 | 1 | 连贯 | 1 | 接受一次工具派发 | 3,433 |
| audit_bad_first_2 | 2 | 连贯 | 8 | 多调用整批拒绝 | 2,917 |
| audit_native_control | 1 | 连贯 | 1 | 接受一次工具派发 | 3,636 |
| audit_native_control | 2 | 连贯 | 1 | 接受一次工具派发 | 2,522 |
| search_native_control | 1 | 连贯 | 1 | 接受一次工具派发 | 86 |
| search_native_control | 2 | 连贯 | 1 | 接受一次工具派发 | 103 |

输出 token 包含 reasoning。标签来自完整阅读，而不是根据长度、缺答或工具数猜测。
例如第一条虽 reasoning 较长，仍在逐项推进假设评估，并非 baseline 的持续无进展循环。
所有 8 条 HTTP 200、finish reason 为 `tool_calls`、参数符合原 schema；工具派发
是否通过与内容是否连贯分开记录。这里没有执行真实任务工具或计算任务分数。

## 保真与复核范围

- 同样 4 个历史首请求，每个固定重复 2 次，并发 4；未按结果补抽或排除任何输出。
- 8 条实际请求 wire bytes 与冻结保序原请求逐字节一致，wire SHA 也匹配既有独立
  actual-renderer 审计链；prompt token 数均匹配 1974／2824／1860／730。
- 每条原始响应先核对 SHA，再通过冻结 client decoder；使用未修改的原单步 native
  runner 和惰性工具 spy 验证，6 条各执行一次 spy，2 条多调用批次均执行零次并配对拒绝。
- 复用已验证的 probe，不增加重复测试阶梯。最终 sidecar 确定性 `--check` 通过。
- 本复核未新增模型、网络、GPU、真实工具或评分器调用，未修改任何原始输出。

候选配置及重启差异见 [单因素候选计划](../serving/multistream-off/PLAN.zh.md)，
运行前排空／flush 证据见 [CONTROL.json](../serving/multistream-off/control-before-v2-c4/CONTROL.json)。
候选 deployment 和 control 身份同时绑定在本分类 JSON 中。

## 解释边界

结果支持把 multistream-off 作为值得继续验证的服务候选，但不是根因已经得到
严格证明：只有 8 个目的性选择的首请求，未盲化或随机化；新进程、缓存、时序和
实际采样状态存在差异，请求 seed 不使这些输出构成逐 token 确定性的配对试验。
不能据此估计总体故障率、认定正式旧分数已被纠正，或保证完整 PoolAct 多轮轨迹稳定。
多调用拒绝这一独立协议问题在本组中仍然存在。

## 查验入口

- [逐条 CSV](classification.csv)：8 条原始／wire SHA、工具数、usage、时长、人工依据。
- [完整证据 JSON](classification.json)：24 个候选输入文件身份、实际 CPU runner probe、
  原配置对照结果身份、deployment/control 身份。
- [完整人工阅读标签](MANUAL_READABILITY.json)；[复核脚本](classify.py)。

```bash
/lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python -B \
  eval_diagnostics_20260912/candidate_contract_review/classify.py --check
```
