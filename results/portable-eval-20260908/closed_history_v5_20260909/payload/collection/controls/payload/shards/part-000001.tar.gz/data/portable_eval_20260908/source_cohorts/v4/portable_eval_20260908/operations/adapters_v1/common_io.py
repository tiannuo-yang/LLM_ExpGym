"""Small, explicit-reference I/O; no discovery, authority or model calls."""
import hashlib
import json
import math
import os
from pathlib import Path
import re
import stat

MAX_BYTES = 128 * 1024 * 1024


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def parse_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("duplicate_json_key")
            result[key] = value
        return result
    def bad_number(value):
        raise ValueError("nonfinite_json_number")
    def finite_float(value):
        result = float(value)
        if not math.isfinite(result):
            raise ValueError("nonfinite_json_number")
        return result
    return json.loads(raw.decode("utf-8"), object_pairs_hook=pairs,
                      parse_constant=bad_number, parse_float=finite_float)


def lexical(path):
    if not isinstance(path, (str, Path)):
        raise ValueError("absolute_lexical_path_required")
    text = str(path)
    value = Path(text)
    if (not value.is_absolute() or value.anchor != "/" or "\x00" in text
            or str(value) != text or ".." in value.parts
            or len(value.parts) < 3):
        raise ValueError("absolute_lexical_narrow_path_required")
    return value


def _directory(path):
    value = lexical(path)
    fd = os.open(value.anchor, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for part in value.parts[1:]:
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW,
                            dir_fd=fd)
            os.close(fd)
            fd = child
        return fd
    except BaseException:
        os.close(fd)
        raise


def _stamp(value):
    return (value.st_dev, value.st_ino, value.st_mode, value.st_nlink,
            value.st_size, value.st_mtime_ns, value.st_ctime_ns)


def check_secret_metadata(path):
    """Check a declared credential path without opening/reading/hashing it.

    Only path metadata is inspected; no stat values are returned or logged.
    The file contents remain solely the explicit authorized run's concern.
    """
    value = lexical(path)
    parent = _directory(value.parent)
    try:
        info = os.stat(value.name, dir_fd=parent, follow_symlinks=False)
        if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1
                or info.st_size > 2050):
            raise ValueError("unaliased_single_link_bounded_secret_file_required")
    finally:
        os.close(parent)


def read_regular(path, *, max_bytes=MAX_BYTES):
    """Internal primitive; public evidence callers must use read_ref.

    Only the explicit run entry uses this without a hash, after authorization,
    for the separately designated secret file. Secret bytes are never hashed.
    """
    value = lexical(path)
    if type(max_bytes) is not int or not 0 < max_bytes <= MAX_BYTES:
        raise ValueError("bounded_read_required")
    parent = _directory(value.parent)
    try:
        fd = os.open(value.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK,
                     dir_fd=parent)
        try:
            before = os.fstat(fd)
            if (not stat.S_ISREG(before.st_mode) or before.st_nlink != 1
                    or before.st_size > max_bytes):
                raise ValueError("bounded_single_link_regular_file_required")
            chunks, count = [], 0
            while True:
                part = os.read(fd, min(1024 * 1024, max_bytes + 1 - count))
                if not part:
                    break
                count += len(part)
                if count > max_bytes:
                    raise ValueError("file_exceeds_read_bound")
                chunks.append(part)
            after = os.fstat(fd)
            entry = os.stat(value.name, dir_fd=parent, follow_symlinks=False)
            if _stamp(before) != _stamp(after) or _stamp(after) != _stamp(entry):
                raise ValueError("file_changed_during_read")
            return b"".join(chunks)
        finally:
            os.close(fd)
    finally:
        os.close(parent)


def read_ref(ref, *, max_bytes=MAX_BYTES):
    if (type(ref) is not dict or set(ref) != {"path", "sha256"}
            or not isinstance(ref["sha256"], str)
            or re.fullmatch(r"[0-9a-f]{64}", ref["sha256"]) is None):
        raise ValueError("exact_external_path_sha256_ref_required")
    raw = read_regular(ref["path"], max_bytes=max_bytes)
    if hashlib.sha256(raw).hexdigest() != ref["sha256"]:
        raise ValueError("external_file_sha256_mismatch")
    return raw


def read_json_ref(ref):
    return parse_json(read_ref(ref))


def read_blob_refs(refs):
    if type(refs) is not list:
        raise ValueError("explicit_reference_list_required")
    result = {}
    for ref in refs:
        if type(ref) is not dict or not isinstance(ref.get("path"), str):
            raise ValueError("explicit_reference_required")
        if ref["path"] in result:
            raise ValueError("duplicate_reference_path")
        result[ref["path"]] = read_ref(ref)
    return result


def new_directory(path):
    value = lexical(path)
    parent = _directory(value.parent)
    try:
        os.mkdir(value.name, 0o700, dir_fd=parent)
        os.fsync(parent)
    finally:
        os.close(parent)
    return value


def file_ref_from_bytes(path, raw):
    if type(raw) is not bytes:
        raise ValueError("original_bytes_required")
    return {"path": str(lexical(path)), "sha256": hashlib.sha256(raw).hexdigest()}


def write_new(output_dir, basename, raw):
    if (not isinstance(basename, str) or basename in {"", ".", ".."}
            or Path(basename).name != basename or "/" in basename
            or type(raw) is not bytes):
        raise ValueError("single_basename_and_original_bytes_required")
    directory = lexical(output_dir)
    parent = _directory(directory)
    try:
        fd = os.open(basename, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                     0o600, dir_fd=parent)
        try:
            pending = memoryview(raw)
            while pending:
                written = os.write(fd, pending)
                if written <= 0:
                    raise OSError("short_output_write")
                pending = pending[written:]
            os.fsync(fd)
        finally:
            os.close(fd)
        os.fsync(parent)
    finally:
        os.close(parent)
    return file_ref_from_bytes(directory / basename, raw)
