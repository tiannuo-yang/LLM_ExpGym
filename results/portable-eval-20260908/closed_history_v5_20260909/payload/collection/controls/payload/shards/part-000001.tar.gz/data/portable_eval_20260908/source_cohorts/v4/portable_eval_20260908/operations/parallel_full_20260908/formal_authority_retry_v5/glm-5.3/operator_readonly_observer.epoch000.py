from pathlib import Path
import json,datetime,collections,time,os
N=Path('/lustrefs/users/chufan.shi/codex_space_tn/portable_eval_20260908/source_cohorts/v4/portable_eval_20260908')
R=N/'formal_runs/parallel_full_20260908_glm_r3_retry_v5'
A=N/'operations/parallel_full_20260908/formal_authority_retry_v5/glm-5.3'
D=json.loads((A/'compile_define_v1/define.json').read_bytes())
inv={i['invocation_id']:i for i in D['validated_plan_view']['candidate']['invocations']}
closed={}
cache={}
PARENT=13573
PSTART=2033307968
def parent_alive():
    try:
        s=(Path('/proc')/str(PARENT)/'stat').read_text()
        t=s[s.rfind(')')+2:].split()
        return int(t[19])==PSTART and t[0]!='Z'
    except OSError:return False
def rawmeta(p):
    x=json.loads(p.read_bytes())
    state=x.get('state','missing_state')
    resp=x.get('response_json') or {}
    choice=(resp.get('choices') or [{}])[0]
    usage=resp.get('usage')
    counts={k:usage.get(k) for k in ('prompt_tokens','completion_tokens','total_tokens')} if isinstance(usage,dict) else {}
    return {'state':state,'finish':choice.get('finish_reason') if state=='success' else None,
            'attempt':x.get('attempt'),'client_id':x.get('client_id'),'request_id':x.get('request_id'),
            'error_type':(x.get('error') or {}).get('type') if isinstance(x.get('error'),dict) else None,
            'http_status':x.get('http_status'),'will_retry':x.get('will_retry'),'usage':counts}
def snapshot():
    started={p.name[:-11] for p in (R/'journal').glob('*.start.json')}
    finished={p.name[:-12] for p in (R/'journal').glob('*.finish.json')}
    aggregate=collections.Counter()
    finish=collections.Counter()
    attempts=collections.Counter()
    passes=collections.Counter()
    known=collections.Counter()
    unknown=collections.Counter()
    errors=[]
    def add_summary(summary):
        aggregate.update(summary['raw_states']);finish.update(summary['finish_reasons']);attempts.update(summary['attempt_counts'])
        known.update(summary['known_usage_sum']);unknown.update(summary['unknown_usage_responses'])
        errors.extend(summary['errors'])
        if summary['passed'] is not None:passes[str(summary['passed'])]+=1
    parsed=0
    for iid in started:
        if iid in closed:
            add_summary(closed[iid]);continue
        entries=cache.setdefault(iid,{})
        dump=R/inv[iid]['dump_relative_dir']
        if dump.exists():
            for p in dump.iterdir():
                if p.suffix!='.json' or not p.is_file():continue
                s=p.stat();sig=(s.st_size,s.st_mtime_ns)
                prior=entries.get(p.name)
                if prior is not None and prior[0]==sig:continue
                try:
                    entries[p.name]=(sig,rawmeta(p));parsed+=1
                except (OSError,json.JSONDecodeError):
                    continue
        rc=collections.Counter();fc=collections.Counter();ac=collections.Counter();kc=collections.Counter();uc=collections.Counter();er=[]
        for name,(_,m) in entries.items():
            rc[m['state']]+=1;ac[str(m['attempt'])]+=1
            if m['finish'] is not None:fc[str(m['finish'])]+=1
            if m['state']=='error':er.append({'invocation_id':iid,'raw_path':str(dump/name),'request_id':m['request_id'],'error_type':m['error_type'],'http_status':m['http_status'],'attempt':m['attempt'],'will_retry':m['will_retry']})
            if m['state']!='in_progress':
                for k in ('prompt_tokens','completion_tokens','total_tokens'):
                    v=m['usage'].get(k)
                    if type(v) is int and v>=0:kc[k]+=v
                    else:uc[k]+=1
        passed=None
        if iid in finished:
            rp=R/'logs'/iid/'invocation_receipt.json'
            if rp.exists():passed=json.loads(rp.read_bytes()).get('passed')
        summary={'raw_states':dict(rc),'finish_reasons':dict(fc),'attempt_counts':dict(ac),'known_usage_sum':dict(kc),'unknown_usage_responses':dict(uc),'errors':er,'passed':passed}
        if iid in finished and rc.get('in_progress',0)==0 and passed is not None:
            closed[iid]=summary
            cache.pop(iid,None)
        add_summary(summary)
    active=started-finished
    alive=parent_alive()
    return {'schema_version':'formal-readonly-progress-observation-v1','observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'observer_pid':os.getpid(),'controller_pid':PARENT,'controller_alive':alive,
            'started':len(started),'finished':len(finished),'active':len(active),'not_started':1845-len(started),
            'active_by_system':dict(collections.Counter(inv[i]['system'] for i in active)),
            'finished_pass_counts':dict(passes),'raw_states':dict(aggregate),'finish_reasons':dict(finish),'attempt_counts':dict(attempts),
            'known_usage_sum':dict(known),'unknown_usage_responses':dict(unknown),'errors':errors,
            'incremental_json_reads':parsed,'cached_finished_invocations':len(closed),
            'cache_is_progress_only_not_final_integrity_audit':True,'no_model_api_get_or_write':True}
print(json.dumps({'schema_version':'formal-readonly-observer-start-v1','pid':os.getpid(),'ppid':os.getppid(),'controller_pid':PARENT,'interval_seconds':45,'root':str(R),'read_only':True}),flush=True)
while True:
    begin=time.monotonic()
    try:
        row=snapshot();row['scan_seconds']=time.monotonic()-begin
        print(json.dumps(row,sort_keys=True),flush=True)
        if not row['controller_alive']:break
    except Exception as exc:
        print(json.dumps({'observer_error_type':type(exc).__name__,'observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'controller_alive':parent_alive()}),flush=True)
        if not parent_alive():break
    time.sleep(max(1,45-(time.monotonic()-begin)))

