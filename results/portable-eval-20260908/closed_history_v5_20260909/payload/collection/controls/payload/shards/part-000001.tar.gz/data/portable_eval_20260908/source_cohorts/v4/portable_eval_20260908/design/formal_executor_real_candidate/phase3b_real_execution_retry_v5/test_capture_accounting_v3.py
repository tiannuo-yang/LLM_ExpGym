"""R4 regression: actual source N4, inert bytes, synthetic key, no network.

Capture errors are injected in the production parent after or during stdout
capture. Original client dumps and owner/scorer semantics remain unchanged.
"""
import os
from contextlib import ExitStack
from pathlib import Path
import sys
import unittest
from unittest import mock

import real_common as common
import real_authority as auth
import real_invocation as invocation
import secret_fd
from test_real_execution import FixtureBase, KEY
import test_source_integration as source_fixture


class CaptureLifecycleTests(FixtureBase):
    def test_prelaunch_failure_has_no_drain_or_zero_cost_claim(self):
        with mock.patch.object(secret_fd.subprocess, "Popen", side_effect=OSError("CPU prelaunch")):
            with self.assertRaises(secret_fd.ChildCaptureError) as raised:
                secret_fd.run_child([sys.executable, "-B", "-c", "pass"], str(self.folder), {},
                    self.folder / "prelaunch.log", secret=KEY)
        receipt = raised.exception.process_receipt
        self.assertFalse(receipt["child_started"])
        self.assertFalse(receipt["drain_proven"])
        self.assertIsNone(receipt["exit_code"])
        self.assertEqual(receipt["error_type"], "OSError")
        self.assertNotIn(KEY, str(receipt))

    def test_production_log_write_failure_still_naturally_drains(self):
        target = self.folder / "write_error.log"
        original_write = os.write

        def fail_log(fd, data):
            if os.readlink("/proc/self/fd/%d" % fd) == str(target):
                raise OSError("CPU log-write fault")
            return original_write(fd, data)

        # More than a pipe buffer proves cleanup consumes stdout before wait.
        code = "import sys; sys.stdout.write('CPU-only-' * 20000); sys.stdout.flush()"
        with mock.patch.object(secret_fd.os, "write", fail_log):
            with self.assertRaises(secret_fd.ChildCaptureError) as raised:
                secret_fd.run_child([sys.executable, "-B", "-c", code], str(self.folder), {}, target, secret=KEY)
        receipt = raised.exception.process_receipt
        self.assertTrue(receipt["child_started"])
        self.assertTrue(receipt["stdout_eof_observed"])
        self.assertTrue(receipt["wait_returned"])
        self.assertTrue(receipt["drain_proven"])
        self.assertFalse(receipt["capture_complete"])
        self.assertEqual(receipt["exit_code"], 0)
        self.assertEqual(receipt["error_type"], "OSError")

    def test_stdout_read_failure_wait_alone_is_not_drain_proof(self):
        stream = mock.Mock(closed=False)
        stream.read.side_effect = OSError("CPU unreadable pipe")
        process = mock.Mock(stdout=stream, returncode=0)
        with mock.patch.object(secret_fd.subprocess, "Popen", return_value=process):
            with self.assertRaises(secret_fd.ChildCaptureError) as raised:
                secret_fd.run_child([sys.executable, "-B", "-c", "pass"], str(self.folder), {},
                    self.folder / "pipe_error.log", secret=KEY)
        receipt = raised.exception.process_receipt
        self.assertTrue(receipt["wait_returned"])
        self.assertFalse(receipt["stdout_eof_observed"])
        self.assertFalse(receipt["drain_proven"])

    def test_keyboard_interrupt_capture_failure_drains_and_preserves_type(self):
        target = self.folder / "interrupted.log"
        original_write = os.write

        def interrupt_log(fd, data):
            if os.readlink("/proc/self/fd/%d" % fd) == str(target):
                raise KeyboardInterrupt()
            return original_write(fd, data)

        code = "import sys; sys.stdout.write('CPU-only-' * 20000); sys.stdout.flush()"
        with mock.patch.object(secret_fd.os, "write", interrupt_log):
            with self.assertRaises(secret_fd.ChildCaptureError) as raised:
                secret_fd.run_child([sys.executable, "-B", "-c", code], str(self.folder), {}, target, secret=KEY)
        receipt = raised.exception.process_receipt
        self.assertEqual(receipt["error_type"], "KeyboardInterrupt")
        self.assertTrue(receipt["child_started"])
        self.assertTrue(receipt["stdout_eof_observed"])
        self.assertTrue(receipt["wait_returned"])
        self.assertTrue(receipt["drain_proven"])
        self.assertEqual(receipt["exit_code"], 0)
        self.assertFalse(receipt["capture_complete"])
        self.assertNotIn(KEY, str(receipt))

    def test_sensitive_output_receipt_redacted_and_drained(self):
        code = "import os,sys; print(os.read(int(sys.argv[-1]),2048).decode('ascii'))"
        target = self.folder / "sensitive.log"
        with self.assertRaises(secret_fd.ChildCaptureError) as raised:
            secret_fd.run_child([sys.executable, "-B", "-c", code], str(self.folder), {}, target, secret=KEY)
        receipt = raised.exception.process_receipt
        self.assertTrue(receipt["drain_proven"])
        self.assertEqual(receipt["error_type"], "RuntimeError")
        self.assertNotIn(KEY, str(receipt))
        self.assertNotIn(KEY.encode(), common.read_bytes(target))
        self.assertIn(b"[REDACTED]", common.read_bytes(target))


class SourceCaptureAccountingTests(FixtureBase):
    make_case = source_fixture.SourceIntegration.make_case

    def run_n4(self, fault=None):
        study, epoch, anchors, chosen, instance, grant = self.make_case("poolact", "restricted_search")
        original, calls, captured = secret_fd.run_child, [], []

        def inert_child(command, cwd, env, log, *, secret):
            calls.append(list(command))
            argv = list(command)
            index = argv.index("--spec") + 1
            spec = common.read(argv[index])
            spec["cpu_fixture_boundary"] = True
            fixture_spec = Path(argv[index]).with_name("cpu_capture_child_spec.json")
            common.write(fixture_spec, spec)
            argv[index], argv[2] = str(fixture_spec), str(common.HERE / "cpu_child_fixture.py")
            if fault == "prelaunch":
                with mock.patch.object(secret_fd.subprocess, "Popen", side_effect=OSError("CPU launch failure")):
                    return original(argv, cwd, env, log, secret=secret)
            if fault in ("fsync", "fsync_unreadable"):
                original_sync = os.fsync

                def fail_run_log(fd):
                    if os.readlink("/proc/self/fd/%d" % fd) == str(log):
                        raise OSError("CPU post-drain fsync failure")
                    return original_sync(fd)

                try:
                    with mock.patch.object(secret_fd.os, "fsync", fail_run_log):
                        return original(argv, cwd, env, log, secret=secret)
                except secret_fd.ChildCaptureError as exc:
                    captured.append(exc.process_receipt)
                    if fault == "fsync_unreadable":
                        # Add only a new bad fixture object; all four original
                        # source dump and canonical bytes remain retained.
                        dump = self.root / chosen["dump_relative_dir"]
                        (dump / ("f" * 32 + ".json")).symlink_to(dump / "CPU_missing_raw")
                    raise
            result = original(argv, cwd, env, log, secret=secret)
            captured.append(result[0])
            if fault == "unknown_after_drain":
                # Parent sees no typed lifecycle proof; cannot infer drain even
                # though this independent test observer saw a normal return.
                raise RuntimeError("CPU generic capture error")
            return result

        with ExitStack() as faults, mock.patch.object(auth, "validate_real_authority", return_value=grant), \
             mock.patch.object(auth, "verify_epoch"), \
             mock.patch.object(secret_fd, "run_child", inert_child):
            if fault == "inventory":
                faults.enter_context(mock.patch.object(invocation.attempt_gate, "inventory", side_effect=OSError("CPU inventory failure")))
            if fault == "raw_checker":
                faults.enter_context(mock.patch.object(invocation.raw_scope, "audit_partial", side_effect=ValueError("CPU raw checker failure")))
            report = invocation.execute_real_invocation(study, epoch, anchors, chosen["invocation_id"], instance, secret=KEY)
        common.write(self.folder / "CPU_ONLY_capture_accounting_v3.json", {
            "classification": "Static/fake validation; actual source N4, synthetic wire, not real ROOT GO or model performance",
            "fault": fault, "child_call_count": len(calls), "observed_child_receipts": captured,
            "actual_model_calls": 0, "parent_network_calls": self.network_calls, "synthetic_key_only": True,
            "all_child_network_blocked": True, "result": report})
        self.assertEqual(len(calls), 1)
        self.assertEqual(len(report["owners"]), 4)
        self.assertIn("raw", report)
        self.assertIn("attempt_operations", report)
        self.assertNotIn(KEY, common.encoded(report).decode())
        if fault is not None:
            self.assertFalse(report["passed"])
            self.assertFalse(report["resume"]["executed"])
            self.assertTrue(all(x["state"] == "infrastructure_failed" for x in report["logical_results"].values()))
            self.assertTrue(all("aggregate" not in x for x in report["logical_results"].values()))
        return report

    def check_known_four(self, report):
        self.assertEqual(report["attempt_operations"]["raw_attempts"], 4)
        self.assertEqual(report["attempt_operations"]["http_response_bytes_returned"], 4)
        usage = report["accounting"]["totals_all_attempts"]["provider_usage"]
        self.assertEqual(usage["input_tokens"]["known_sum"], 40)
        self.assertEqual(usage["output_tokens"]["known_sum"], 20)
        self.assertTrue(all(x["artifact"] is not None for x in report["owners"]))

    def test_original_n4_positive_keeps_full_resume(self):
        report = self.run_n4()
        self.check_known_four(report)
        self.assertTrue(report["passed"])
        self.assertTrue(report["resume"]["executed"])
        self.assertTrue(report["accounting"]["namespace_accounting_complete"])
        self.assertTrue(all(x["owner_evidence_qualified"] for x in report["owners"]))

    def test_production_fsync_failure_keeps_four_owners_and_known_usage(self):
        report = self.run_n4("fsync")
        self.check_known_four(report)
        self.assertEqual(report["error_type"], "OSError")
        self.assertEqual(report["capture_error_type"], "ChildCaptureError")
        self.assertTrue(report["run"]["drain_proven"])
        self.assertEqual(report["run"]["exit_code"], 0)
        self.assertTrue(report["raw"]["passed"])
        self.assertTrue(report["accounting"]["namespace_accounting_complete"])
        self.assertTrue(all(x["score_recomputed"] and x["owner_evidence_qualified"] for x in report["owners"]))

    def test_unknown_capture_error_keeps_known_sum_but_not_finality(self):
        report = self.run_n4("unknown_after_drain")
        self.check_known_four(report)
        self.assertFalse(report["run"]["drain_proven"])
        self.assertIsNone(report["run"]["child_started"])
        self.assertFalse(report["accounting"]["namespace_accounting_complete"])
        self.assertIsNone(report["accounting"]["totals_all_attempts"]["complete_http_attempts"])
        self.assertIsNone(report["accounting"]["totals_all_attempts"]["provider_usage"]["input_tokens"]["complete_total"])
        self.assertTrue(all(not x["owner_evidence_qualified"] for x in report["owners"]))

    def test_unreadable_extra_raw_preserves_four_known_without_complete_total(self):
        report = self.run_n4("fsync_unreadable")
        self.check_known_four(report)
        self.assertTrue(report["raw"]["raw_coverage"]["unreadable_paths"])
        self.assertFalse(report["raw"]["passed"])
        self.assertTrue(report["attempt_operations"]["issues"])
        self.assertFalse(report["accounting"]["namespace_accounting_complete"])
        self.assertIsNone(report["accounting"]["totals_all_attempts"]["provider_usage"]["input_tokens"]["complete_total"])

    def test_prelaunch_failure_still_audits_missing_namespace_as_unknown(self):
        report = self.run_n4("prelaunch")
        self.assertFalse(report["run"]["child_started"])
        self.assertFalse(report["run"]["drain_proven"])
        self.assertFalse(report["accounting"]["namespace_accounting_complete"])
        self.assertIsNone(report["accounting"]["totals_all_attempts"]["complete_http_attempts"])
        self.assertTrue(report["owner_load_errors"])

    def test_inventory_exception_does_not_skip_strict_raw_or_owner_loading(self):
        report = self.run_n4("inventory")
        self.assertIsNone(report["attempt_operations"]["raw_attempts"])
        self.assertTrue(report["attempt_operations"]["issues"])
        self.assertTrue(report["raw"]["passed"])
        self.assertFalse(report["accounting"]["namespace_accounting_complete"])
        self.assertEqual(report["accounting"]["totals_all_attempts"]["provider_usage"]["input_tokens"]["known_sum"], 40)
        self.assertTrue(all(x["artifact"] is not None for x in report["owners"]))

    def test_strict_raw_exception_retains_frozen_catalog_known_usage_only(self):
        report = self.run_n4("raw_checker")
        self.check_known_four(report)
        self.assertFalse(report["raw"]["passed"])
        self.assertFalse(report["accounting"]["namespace_accounting_complete"])
        self.assertIsNone(report["accounting"]["totals_all_attempts"]["provider_usage"]["input_tokens"]["complete_total"])
        self.assertTrue(all(not x["owner_evidence_qualified"] for x in report["owners"]))


if __name__ == "__main__":
    unittest.main(verbosity=2)
