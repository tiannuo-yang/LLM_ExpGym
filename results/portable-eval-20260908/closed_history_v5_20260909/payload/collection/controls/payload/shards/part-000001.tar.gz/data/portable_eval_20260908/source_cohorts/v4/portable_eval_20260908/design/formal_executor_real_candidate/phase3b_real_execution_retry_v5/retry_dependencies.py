"""Pinned read-only raw dependencies, without the real execution import chain.

The already accepted raw scope owns its existing Phase2/base source verification.
Its historical transitive modules define CPU helpers but no execution is invoked
here. In particular this module never imports real_common or real authority.
"""
import hashlib
import importlib
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
A3 = HERE.parent / "phase3_dispatch_candidate"
RAW_SCOPE_SHA256 = "9f02510ffa6c2a2dabb73a3e2284fc2a08099428ee6e9d450baa7607fbb5edce"


def frozen_scope():
    path = A3 / "raw_scope.py"
    if path != path.resolve() or hashlib.sha256(path.read_bytes()).hexdigest() != RAW_SCOPE_SHA256:
        raise ValueError("frozen_raw_scope_source_changed")
    if str(A3) not in sys.path:
        sys.path.insert(0, str(A3))
    loaded = importlib.import_module("raw_scope")
    if (Path(loaded.__file__).resolve() != path
            or hashlib.sha256(path.read_bytes()).hexdigest() != RAW_SCOPE_SHA256):
        raise ValueError("wrong_frozen_raw_scope_module")
    loaded.verify_dependencies()
    return loaded
