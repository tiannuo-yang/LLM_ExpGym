"""Retry-v5 scope: unchanged audit_partial body, pinned accepted helpers.

Only the local raw audit retry predicate differs; no old module is mutated.
All namespace, owner, history, usage and qualification rules remain unchanged.
"""
from collections import Counter, defaultdict
import json
from pathlib import Path

import retry_dependencies as dependencies
if Path(dependencies.__file__).resolve() != Path(__file__).resolve().parent / "retry_dependencies.py":
    raise ValueError("wrong_local_retry_dependencies_module")

_frozen = dependencies.frozen_scope()
import raw_audit_retry as raw
if Path(raw.__file__).resolve() != Path(__file__).resolve().parent / "raw_audit_retry.py":
    raise ValueError("wrong_retry_auditor_module")
bridge = _frozen.bridge
strict_native_history = _frozen.strict_native_history
full_catalog = _frozen.full_catalog
safe_usage_totals = _frozen.safe_usage_totals
safe_same = _frozen.safe_same
verify_dependencies = _frozen.verify_dependencies


def audit_partial(owners, dump_dir, *, planned_owners, profile, policy, endpoint, run_id, secret=None):
    verify_dependencies()
    planned = {row["owner_id"]: row for row in planned_owners}
    if not planned or len(planned) != len(planned_owners):
        raise ValueError("complete_unique_planned_owners_required")
    owner_map = {row["owner_id"]: row for row in owners}
    if len(owner_map) != len(owners) or set(owner_map) - set(planned):
        raise ValueError("duplicate_or_unplanned_completed_owner")
    catalog = full_catalog(dump_dir)
    records = catalog.get("unique_records", [])
    by_request = {record["request_id"]: record for record in records}
    routes, generations, client_routes = {}, defaultdict(set), defaultdict(set)
    reasons = {key: [] for key in owner_map}
    errors = [{"rule": rule} for rule in catalog["issues"]]
    unsafe = bool(catalog["issues"])
    clients = bridge.module("expgym.llm_clients")
    redact = lambda value: bridge.core().helper("a21").redact_wire(value, secret, clients.OpenAICompatibleLLM._is_secret_field)
    contexts = {key: json.dumps(redact(row["context"]), sort_keys=True, allow_nan=False) for key, row in planned.items()}
    if len(set(contexts.values())) != len(contexts):
        raise ValueError("planned_contexts_must_identify_one_owner_each")
    unassigned, in_progress = [], []
    for record in records:
        key = record["request_id"]
        try:
            context = json.dumps(record.get("context"), sort_keys=True, allow_nan=False)
            route = next((owner for owner, expected in contexts.items() if expected == context), None)
        except (ValueError, TypeError):
            route = None
        routes[key] = route
        generation = record.get("generation_id")
        if isinstance(generation, str):
            generations[generation].add(route)
        client = record.get("client_id")
        if isinstance(client, str):
            client_routes[client].add(route)
        if route is None:
            unassigned.append(key)
            unsafe = True
        if record.get("state") == "in_progress":
            in_progress.append(key)
        payload = record.get("request_payload") or {}
        strict_errors = strict_native_history(payload.get("messages")) if isinstance(payload, dict) else ["invalid_raw_payload"]
        if route is not None:
            expected = raw.generation_payload(profile, policy, planned[route]["seed"])
            expected.update(tools=redact(planned[route]["schemas"]), parallel_tool_calls=False)
            if (record.get("run_id") != run_id or record.get("endpoint") != clients._normalize_chat_completions_url(endpoint)
                    or not isinstance(payload, dict) or payload.get("tool_choice") not in ("auto", "none")
                    or any(not safe_same(payload.get(name), value) for name, value in expected.items())):
                strict_errors.append("planned_owner_raw_profile_or_namespace_mismatch")
        for rule in strict_errors:
            errors.append({"rule": rule, "request_id": key, "owner_id": route})
            if route in reasons:
                reasons[route].append(rule)
            elif route is None:
                unsafe = True
    if unassigned:
        errors.append({"rule": "unassigned_raw_requests", "request_ids": unassigned})
    if any(len(values) != 1 or None in values for values in client_routes.values()):
        unsafe = True
        errors.append({"rule": "client_spans_unknown_or_multiple_planned_owners"})
    try:
        global_raw = raw.audit_owners(owners, dump_dir, expected_owner_ids=list(planned),
            profile=profile, policy=policy, endpoint=endpoint, run_id=run_id, secret=secret)
    except Exception as exc:
        global_raw = {"passed": False, "errors": [{"rule": "global_raw_audit_exception", "error_type": type(exc).__name__}], "owners": []}
        unsafe = True
    aggregate_rules = {"planned_owner_set_mismatch", "raw_ledger_request_bijection_failed", "raw_ledger_generation_bijection_failed"}
    for error in global_raw.get("errors", []):
        errors.append(dict(error, layer="frozen_full_namespace_audit"))
        targets = set()
        if error.get("owner_id") in planned:
            targets.add(error["owner_id"])
        if error.get("request_id") in routes:
            targets.add(routes[error["request_id"]])
        if error.get("generation_id") in generations:
            targets.update(generations[error["generation_id"]])
        if targets and None not in targets:
            for owner in targets:
                if owner in reasons:
                    reasons[owner].append(error["rule"])
        elif error.get("rule") not in aggregate_rules:
            unsafe = True
    expected_requests = []
    for key, owner in owner_map.items():
        if any(not safe_same(owner.get(field), planned[key].get(field)) for field in ("logical_id", "context", "seed", "schemas")):
            reasons[key].append("completed_owner_not_equal_to_planned_identity")
        reasons[key].extend(strict_native_history(owner["history"]))
        listed = []
        for call in owner["calls"]:
            reasons[key].extend(strict_native_history(call["messages"]))
            listed.extend(entry["request_id"] for entry in call["attempts"])
        expected_requests.extend(listed)
        assigned = [request for request, route in routes.items() if route == key]
        if Counter(assigned) != Counter(listed):
            reasons[key].append("owner_attempt_set_not_exact")
        if any(by_request[request].get("client_id") != owner["client_id"] for request in assigned):
            reasons[key].append("owner_client_id_not_exact")
    if any(count != 1 for count in Counter(expected_requests).values()):
        unsafe = True
        errors.append({"rule": "logical_ledger_request_claim_not_unique"})
    missing = sorted(set(expected_requests) - set(by_request))
    incomplete = sorted(set(planned) - set(owner_map))
    local_reports = {row["owner_id"]: row for row in global_raw.get("owners", [])}
    qualified = []
    for key in owner_map:
        if unsafe:
            reasons[key].append("unscoped_global_raw_integrity_failure")
        if local_reports.get(key, {}).get("passed") is not True:
            reasons[key].append("frozen_owner_audit_not_passed")
        qualified.append({"owner_id": key, "eligible": not reasons[key], "reasons": sorted(set(reasons[key]))})
    # Re-read the complete namespace without normalizing or moving any files.
    final_catalog = full_catalog(dump_dir)
    signature = lambda value: {key: value.get(key) for key in ("files", "issues", "unreadable_paths", "nested_paths", "duplicate_request_ids", "conflicting_request_ids")}
    if signature(catalog) != signature(final_catalog):
        errors.append({"rule": "full_namespace_changed_during_partial_audit"})
        for row in qualified:
            row["eligible"] = False
            row["reasons"].append("full_namespace_changed_during_partial_audit")
    complete = bool(global_raw.get("passed")) and not errors and not incomplete and not missing and not in_progress
    totals = safe_usage_totals(records, complete)
    totals["enumerated_unique_http_attempts"] = len({item["record"]["request_id"] for item in catalog["records"]})
    totals["scope"] = "All safely parsed unambiguous unique raw request IDs, independent of owner qualification; conflicting copies excluded from unique known cost and separately indexed; complete_total null when namespace coverage is unproven"
    physical = safe_usage_totals([item["record"] for item in catalog["records"]], False)
    physical.pop("enumerated_unique_http_attempts")
    physical.pop("unambiguous_unique_http_attempts")
    physical["parsed_physical_files"] = len(catalog["records"])
    physical["scope"] = "Physical parseable file copies only, NOT unique requests or complete project cost; duplicates may repeat usage"
    # Preserve the frozen checker verdict/diagnostics, but explicitly withdraw
    # its flat-directory cost completeness claim. Phase2 totals above supersede it.
    global_raw["totals_authoritative"] = False
    global_raw["totals_notice"] = "Use phase2 totals_all_attempts: frozen totals do not establish full namespace coverage"
    if not complete:
        for value in global_raw.get("totals_all_attempts", {}).get("provider_usage", {}).values():
            value["complete_total"] = None
    verify_dependencies()
    return {"passed": complete and all(row["eligible"] for row in qualified), "errors": errors,
        "global_raw_audit": global_raw, "owner_qualification": qualified,
        "expected_incomplete_owners": incomplete, "unassigned_request_ids": sorted(unassigned),
        "raw_coverage": {"complete": complete, "missing_request_ids": missing, "in_progress_request_ids": sorted(in_progress),
            "unreadable_paths": catalog["unreadable_paths"], "nested_paths": catalog["nested_paths"],
            "duplicate_request_ids": catalog.get("duplicate_request_ids", []), "conflicting_request_ids": catalog.get("conflicting_request_ids", [])},
        "totals_all_attempts": totals, "files": catalog["files"],
        "physical_file_reported_usage": physical,
        "warning": "Qualified partial owners never override failed global raw or invocation status"}
