# 用户授权的新研究重跑入口（候选，尚无实际执行授权）

旧研究、旧 GO、raw、失败和成本全部保留。此新目录不是旧 authority 的续接：用户要求完整重跑，旧 invocation ID 即使相同也不用于跳过。跨研究身份是 `(run_id, invocation_id)`。

## 固定矩阵与终态

每模型单独 plan/run/ROOT GO，可并行各用原 64 GPU。显式 `repeat_policy` 为两 system 各 `restricted_search:1, evidence_audit:1, tuning:3`。Exp Audit 在每次 invocation 内仍是 3 orders；Pool Audit 为原 default。每模型 705 invocation / 783 logical outcome / 1881 agent trace / 2613 result JSON。outer blocks 615→45→45 有固定 barrier。Search 标记 mixed_or_unknown；旧结果已被查看，不声称盲预注册。

原 source 自己评分、保存 traces/raw、实施任务策略。新增 `--missing-final-policy task-abstention-v1`：Search/Audit 缺答用原评分器空预测独立核分；tuning 缺答为 unknown，不合成分数。`terminal_status` 必须为 `expgym.execution-terminal.v1`，含 execution_complete、score_complete、terminal_classification、model_no_answer_count、expected_model_terminals、reported_model_terminals。只有原 --resume 禁 LLM 重验通过、原 artifact 和 raw 完整后，typed model_no_answer 才继续。infra、abort、格式/身份/证据缺失停新派并自然 join；不重抽。

## 编译输入

`launcher.py compile --spec /ABS/ROOT_INPUT.json --spec-sha256 SHA --output-dir /ABS/FRESH_PLAN_DIR`

输入 schema_version=`restart-compile-input-v1`，mode=`formal_mixed` 或 `selected_smoke`，config 必填：

- run_id、supersedes（旧 study IDs，至少一项）、model={label,model_id}、repo_root、output_root（尚不存在，parent 已由操作者创建）。
- source_acceptance_ref、profile_ref、deployment_ref、runtime_validation_ref，均仅 `{path,sha256}`。source receipt 必须含完整 files 相对路径→SHA 和 source_tree_sha256；runtime 原件 passed=true；profile 是原 schema1 完整单模型 request profile；deployment 为真实 serving 原件，包含 router_url/router_api_key_file/model/runtime_receipt/runtime_receipt_sha256。
- runtimes={native:runtime, paramnet_legacy:runtime}。每 runtime 精确 `{executable, resolved_executable_ref, prefix, pyvenv_config_ref}`；executable 是实际 venv Python 路径，可为 venv 正常解释器链接，实际目标必须匹配安全 regular binary ref；prefix 与 pyvenv.cfg parent 匹配。外部 ROOT 对真实 runtime 的接受仍不可由此哈希检查替代。
- environment：显式数据/runtime 环境字符串字典，不含 credentials、proxy、PYTHONPATH 或 PYTHONHOME。继承的 provider/EXPGYM credential/config 环境被清除后，再加这里的非秘密数据环境。服务 key 仅以 deployment 声明路径记录；compile 只 lstat 全路径，不读、不 hash 内容。
- policy：精确 workers、max_steps、max_evals、max_tokens、max_context_tokens、max_protocol_retries、max_retries、request_timeout、retry_base_seconds、retry_max_seconds、tuning_final_policy、missing_final_policy、stop_new_before_deadline_seconds、max_wall_seconds。正式候选 32/30/30/32768/131072/1/2/3600/3/30/legacy/task-abstention-v1/21600/259200。smoke 可使用 ROOT 明确给定小 steps/evals/workers，不改 profile/输出预算。max_context_tokens 仅 Pool CLI 显式传入；Exp 不伪造不存在的该选项。
- formal_mixed 另需 repeat_policy、schedule_seed、base_seed、legacy_runtime_root。全部 705 command 从 matrix 构造；不接受子集。
- selected_smoke 另在输入顶层给 jobs 与 selected_input_refs。每 job 精确提供 invocation_id/model_id/system/scenario/runtime_profile_required、command、sampling_seed_labels、expected_model_terminals、endpoint、output_dir、dump_dir、log_dir、terminal_evidence_dir、expected_files、terminal_artifacts；outerrep 可统一 0。command 必须完整 `[实际Python,-u,-B,实际repo/scripts/run_paper_sweep.py或run_poolact.py,...]`，backend=openai，显式 missing policy 与 terminal-evidence-dir；不含任何 api-key/api-key-file/resume/dry-run。endpoint 是完整 chat/completions URL；只有 task auto/none，不允许新工具强制策略。

compile 读取声明 refs、source 全 files、选定 inputs、解释器/venv 与自身/接受 helper 闭包，产 plan.json + compile_receipt.json。plan 的文件 SHA 与 canonical SHA 不混用。无模型、无 source/scorer 执行、无 GO 签发。selected_smoke 是独立用途，不计入正式矩阵。

## ROOT 单次启动原件

ROOT 外部创建 schema_version=`restart-root-launch-go-v1`：action=`execute_once`，plan_ref（原文件 SHA）、run_id、model_id、mode、output_root、invocation_ids（完整精确顺序）、deployment_ref、policy_sha256（canonical policy SHA）；not_before_unix、latest_start_unix（仅整个入口首次启动期限）、deadline_unix、allocation_start_unix、allocation_deadline_unix、gpu_seconds_cap、gpu_count=64、allocation_id。

所有时间有限且有序；deadline 不越实际 allocation 结束。GPU cap 从该 allocation 真实开始算，包含加载，并非仅模型 decode。旧 allocation 成本另外保留，不捏造为零。本入口不自动续 allocation、不自动签新 GO。每次 HTTP 都要求 now+timeout<deadline；新 invocation 还受 stop-new margin；whole dispatcher 受 max_wall_seconds。max_retries=2 即最多 3 次原客户端尝试；超时/重试并不扩大 deadline。W32 是 childslots，不保证持续 128 HTTP 或已测满容量。

`launcher.py launch --plan /ABS/plan.json --plan-sha256 FILE_SHA --go /ABS/ROOT_GO.json --go-sha256 EXTERNAL_ROOT_SHA --execute-real`

仅完成所有 refs/runtime/profile/GO/unused-root 检查后，才读取 deployment 的声明 key 文件到内存并校验。无效 key 不创建实验目录。接受的 anonymous-FD helper 启动每个 child，key 不进 argv/env/log/hash；stdout/stderr 合并安全捕获。`child` 是此入口内部使用，不能替代 ROOT GO。每 job 保存 reserved/source-start PID/原 source log/raw/wire events/终态旁证/verified-resume log/原件清单/terminal。单父 SIGINT handler 仅设置 stop-new，join 已启动 children；不 signal 子进程或服务。

## 验证和边界

原 source 输出 terminal evidence 在 `run/evidence/iid`，与 result 预期清单分离；验证旁证另在 `verification_evidence/iid`。原 --resume 禁止 LLM 构造及 generate，评分仍由 source 完成。Pool summary 可以按原行为重写：比较原 path 集合和 bytes，不宣称 mtime 不变；原 raw 与原 terminal evidence 必须 bytes 不变。raw 审计独立比对原 request/default JSON bytes 与 wire SHA、原 response bytes/parsed JSON、有限 retry、client/seed/数量及历史有序保留；合法 trim 可丢旧 group，不宣称重建所有任务提示词。

final execution 区分 execution_complete 与 score_complete；unknown tuning 可以前者 true、后者 false。所有未派 invocation 列出；本地子进程排空不等于 provider 全部队列空。后续 ROOT provider 观察及独立全评分/raw/报告审计仍必需。当前 CPU 与 synthetic 结果不是真实 GO、真实模型兼容性或正式性能结论。
