"""Synthetic constructors/openers only: no actual source, model, scorer or GET."""
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest import mock
import urllib.error
import urllib.request
import uuid

import wire


SECRET = "synthetic-memory-only-test-credential"
ENDPOINT = "http://wire-test.invalid/v1/chat/completions"
REPO = "/synthetic/restart-wire-repo"


def fixtures(owners=1, steps=1, retries=1, top_k=None):
    profile = {"temperature": 1.0, "top_p": 0.95, "reasoning_effort": "max",
               "chat_template_kwargs": {"thinking": True}}
    if top_k is not None:
        profile["top_k"] = top_k
    plan = {"config": {"repo_root": REPO, "run_id": "restart-study:synthetic",
        "profiles": {"model-any": profile},
        "policy": {"max_tokens": 4096, "max_steps": steps, "max_retries": retries,
                   "request_timeout": 3600, "retry_base_seconds": 3, "retry_max_seconds": 30}}}
    job = {"invocation_id": "synthetic-invocation", "model_id": "model-any", "system": "expgym",
        "command": ["/synthetic/python", "-u", "-B", REPO + "/scripts/run_paper_sweep.py", "--backend", "openai"],
        "sampling_seed_labels": list(range(4100, 4100 + owners)), "expected_model_terminals": owners,
        "endpoint": ENDPOINT, "dump_dir": REPO + "/dumps/job", "log_dir": REPO + "/logs/job"}
    return plan, job


class Authority:
    def __init__(self):
        self.checks, self.events = [], []
        self.failure = None
    def check(self, invocation_id):
        self.checks.append(invocation_id)
        if self.failure is not None:
            raise self.failure
    def record_wire(self, event):
        self.events.append(copy.deepcopy(event))


class Response:
    def __init__(self, body=b"opaque response bytes", read_error=None, close_error=None):
        self.body, self.read_error, self.close_error = body, read_error, close_error
        self.closed = False
    def read(self):
        if self.read_error is not None:
            raise self.read_error
        return self.body
    def close(self):
        self.closed = True
        if self.close_error is not None:
            raise self.close_error


class Opener:
    def __init__(self, response=None, error=None):
        self.response, self.error = response or Response(), error
        self.calls = []
    def open(self, request, timeout):
        self.calls.append((request.full_url, timeout))
        if self.error is not None:
            raise self.error
        return self.response


def original_client(seed, run_id):
    identifier = uuid.uuid4().hex
    return SimpleNamespace(_dump_client_id=identifier, config=SimpleNamespace(seed=seed),
                           dump_metadata={"client_id": identifier, "run_id": run_id})


def payload(plan, seed=4100, choice="auto"):
    profile = plan["config"]["profiles"]["model-any"]
    value = dict(profile, model="model-any", max_tokens=plan["config"]["policy"]["max_tokens"],
                 seed=seed, parallel_tool_calls=False, messages=[{"role": "user", "content": "synthetic task input"}],
                 tools=[{"type": "function", "function": {"name": "synthetic_tool", "parameters": {"type": "object"}}}],
                 tool_choice=choice)
    if value.get("reasoning_effort") is None:
        value.pop("reasoning_effort", None)
    if not value.get("chat_template_kwargs"):
        value.pop("chat_template_kwargs", None)
    if value.get("top_k") is None:
        value.pop("top_k", None)
    return value


def request(value, endpoint=ENDPOINT, secret=SECRET):
    return urllib.request.Request(endpoint, data=json.dumps(value).encode("utf-8"),
        headers={"Content-Type": "application/json", "Authorization": "Bearer " + secret}, method="POST")


def bound_context(owners=1, steps=1, retries=1, opener=None, top_k=None):
    plan, job = fixtures(owners, steps, retries, top_k)
    authority = Authority()
    opener = opener or Opener()
    context = wire.InvocationWire(plan, job, authority, SECRET, lambda: opener)
    guard = context.client(4100)
    guard.bind_source(original_client(4100, plan["config"]["run_id"]))
    return plan, job, authority, opener, context, guard


class WireTests(unittest.TestCase):
    def test_source_pinned_primitive_only(self):
        self.assertEqual(hashlib.sha256(wire.PRIMITIVE_PATH.read_bytes()).hexdigest(), wire.PRIMITIVE_SHA256)
        self.assertEqual(Path(wire._primitive().__file__).resolve(), wire.PRIMITIVE_PATH.resolve())
        with mock.patch.object(wire, "PRIMITIVE_SHA256", "0" * 64):
            with self.assertRaisesRegex(wire.WireContractError, "source_changed"):
                wire._primitive()

    def test_success_hashes_only_and_exact_identity(self):
        plan, job, authority, opener, context, guard = bound_context()
        value = payload(plan)
        req = request(value)
        body = guard(req, 3600)
        self.assertEqual(body, b"opaque response bytes")
        self.assertTrue(opener.response.closed)
        self.assertEqual(authority.checks, [job["invocation_id"]])
        self.assertEqual([e["kind"] for e in authority.events], ["client_identity", "attempt_start", "attempt_terminal"])
        terminal = authority.events[-1]
        self.assertEqual(terminal["request_body_sha256"], hashlib.sha256(req.data).hexdigest())
        self.assertEqual(terminal["response_bytes_sha256"], hashlib.sha256(body).hexdigest())
        self.assertEqual(terminal["state"], "bytes_returned")
        self.assertIsNone(terminal["http_status"])
        self.assertIsNone(terminal["provider_usage_or_cost"])
        serialized = json.dumps(authority.events)
        for excluded in (SECRET, "synthetic task input", "opaque response bytes", "Authorization"):
            self.assertNotIn(excluded, serialized)
        self.assertEqual(context.summary()["attempt_terminals_recorded"], 1)
        self.assertFalse(context.summary()["provider_quiescence_proven"])

    def test_none_choice_and_empty_length_unknown_bytes_are_not_semantic_errors(self):
        for body in (b"", b'{"finish_reason":"length"}', b'{"answer":null}', b"not even parsed here"):
            with self.subTest(body=body):
                opener = Opener(Response(body))
                plan, _, authority, _, _, guard = bound_context(opener=opener)
                self.assertEqual(guard(request(payload(plan, choice="none")), 3600), body)
                self.assertEqual(authority.events[-1]["state"], "bytes_returned")

    def test_payload_mismatches_never_enter_opener(self):
        changes = [{"tool_choice": "required"}, {"tool_choice": {"type": "function", "function": {"name": "x"}}},
                   {"seed": 4101}, {"seed": True}, {"temperature": 0.2}, {"top_p": 1.0},
                   {"max_tokens": 100}, {"parallel_tool_calls": True}, {"reasoning_effort": "none"},
                   {"chat_template_kwargs": {"thinking": False}}, {"chat_template_kwargs": {"thinking": 1}},
                   {"stream": True}, {"tools": []}]
        for change in changes:
            with self.subTest(change=change):
                plan, _, authority, opener, _, guard = bound_context()
                value = payload(plan); value.update(change)
                with self.assertRaises(wire.WireContractError):
                    guard(request(value), 3600)
                self.assertEqual(opener.calls, [])
                self.assertEqual(authority.checks, [])

    def test_optional_top_k_is_exact(self):
        plan, _, _, _, _, guard = bound_context(top_k=40)
        self.assertEqual(guard(request(payload(plan)), 3600), b"opaque response bytes")
        value = payload(plan); value["top_k"] = 20
        with self.assertRaises(wire.WireContractError):
            guard(request(value), 3600)

    def test_scope_blocks_timeout_endpoint_auth_extra_header_and_proxy(self):
        for kind in ("timeout", "endpoint", "auth", "header", "proxy"):
            with self.subTest(kind=kind):
                plan, _, _, opener, _, guard = bound_context()
                req = request(payload(plan), endpoint=ENDPOINT + "x" if kind == "endpoint" else ENDPOINT,
                              secret="wrong" if kind == "auth" else SECRET)
                if kind == "header": req.add_header("X-Extra", "forbidden")
                if kind == "proxy": req.set_proxy("proxy.invalid", "http")
                with self.assertRaises(Exception):
                    guard(req, 1800 if kind == "timeout" else 3600)
                self.assertEqual(opener.calls, [])

    def test_authority_is_rechecked_before_each_attempt(self):
        plan, _, authority, opener, context, guard = bound_context()
        guard(request(payload(plan)), 3600)
        authority.failure = RuntimeError("revoked-synthetic")
        with self.assertRaises(RuntimeError):
            guard(request(payload(plan)), 3600)
        self.assertEqual(len(opener.calls), 1)
        self.assertEqual(context.used, 1)
        self.assertEqual(len(authority.checks), 2)

    def test_attempt_ceiling_is_shared_across_owners(self):
        plan, _, _, opener, context, first = bound_context(owners=2, steps=0, retries=0)
        second = context.client(4101)
        second.bind_source(original_client(4101, plan["config"]["run_id"]))
        first(request(payload(plan)), 3600)
        second(request(payload(plan, seed=4101)), 3600)
        with self.assertRaisesRegex(wire.WireContractError, "ceiling"):
            first(request(payload(plan)), 3600)
        self.assertEqual(context.limit, 2)
        self.assertEqual(len(opener.calls), 2)

    def test_unique_owner_seed_and_client_ceiling(self):
        _, _, _, _, context, _ = bound_context()
        for seed in (4100, 4101, True):
            with self.assertRaises(wire.WireContractError):
                context.client(seed)

    def test_http_error_unchanged_and_body_not_consumed(self):
        fp = io.BytesIO(b"provider-error-body-owned-by-original-client")
        error = urllib.error.HTTPError(ENDPOINT, 503, "synthetic error", {}, fp)
        plan, _, authority, opener, _, guard = bound_context(opener=Opener(error=error))
        with self.assertRaises(urllib.error.HTTPError) as raised:
            guard(request(payload(plan)), 3600)
        self.assertIs(raised.exception, error)
        self.assertEqual(fp.tell(), 0)
        terminal = authority.events[-1]
        self.assertEqual(terminal["http_status"], 503)
        self.assertIsNone(terminal["response_bytes_sha256"])
        self.assertTrue(terminal["response_body_owned_by_source_client"])
        self.assertEqual(error.read(), b"provider-error-body-owned-by-original-client")
        self.assertEqual(len(opener.calls), 1)

    def test_transport_and_read_errors_preserve_types_and_terminal_metadata(self):
        for error in (TimeoutError("synthetic"), ConnectionResetError("synthetic")):
            plan, _, authority, _, _, guard = bound_context(opener=Opener(error=error))
            with self.assertRaises(type(error)) as raised:
                guard(request(payload(plan)), 3600)
            self.assertIs(raised.exception, error)
            self.assertEqual(authority.events[-1]["error_type"], type(error).__name__)
        response = Response(read_error=OSError("read-synthetic"))
        plan, _, authority, _, _, guard = bound_context(opener=Opener(response))
        with self.assertRaises(OSError):
            guard(request(payload(plan)), 3600)
        self.assertTrue(response.closed)
        self.assertEqual(authority.events[-1]["state"], "error")

    def test_nonbytes_and_close_error_are_not_successes(self):
        for response, error_type in ((Response("not bytes"), TypeError), (Response(close_error=OSError("close")), OSError)):
            plan, _, authority, _, _, guard = bound_context(opener=Opener(response))
            with self.assertRaises(error_type):
                guard(request(payload(plan)), 3600)
            self.assertEqual(authority.events[-1]["state"], "error")

    def test_metadata_failure_is_nonretryable_and_prevents_send(self):
        plan, _, authority, opener, _, guard = bound_context()
        authority.record_wire = lambda event: (_ for _ in ()).throw(ConnectionError("synthetic metadata sink"))
        guard.context.callback = authority.record_wire
        with self.assertRaises(wire.MetadataWriteError):
            guard(request(payload(plan)), 3600)
        self.assertEqual(opener.calls, [])

    def test_default_opener_has_no_proxy_discovery_or_redirect_following(self):
        primitive = wire._primitive()
        with mock.patch.object(urllib.request, "getproxies", side_effect=AssertionError("proxy discovery")):
            opener = primitive._build_real_opener()
        self.assertEqual(opener.addheaders, [])
        self.assertTrue(any(isinstance(handler, primitive.NoRedirectHandler) for handler in opener.handlers))
        with self.assertRaises(urllib.error.HTTPError):
            primitive.NoRedirectHandler().redirect_request(request(payload(fixtures()[0])), io.BytesIO(b""), 302, "redirect", {}, "http://other.invalid/")


class SourceHookTests(unittest.TestCase):
    def setUp(self):
        self.plan, self.job = fixtures()
        self.authority, self.opener = Authority(), Opener()
        class Client:
            def __init__(self, **kwargs):
                self.config = SimpleNamespace(**kwargs)
                self._dump_client_id = uuid.uuid4().hex
                self._transport = kwargs.get("transport")
            @property
            def dump_metadata(self):
                return {"client_id": self._dump_client_id, "run_id": os.environ["EXPGYM_RUN_ID"]}
            def generate(self, *args, **kwargs):
                raise AssertionError("fixture never invokes model generation")
        self.Client = Client
        self.module = SimpleNamespace(__file__=REPO + "/expgym/llm_clients.py", OpenAICompatibleLLM=Client)
        self.original_init, self.original_generate = Client.__init__, Client.generate
        self.loader = lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError("disk key loader called"))

    def kwargs(self):
        profile = self.plan["config"]["profiles"]["model-any"]
        p = self.plan["config"]["policy"]
        return dict(profile, model="model-any", api_key=SECRET, seed=4100, base_url=ENDPOINT,
                    max_tokens=p["max_tokens"], timeout=p["request_timeout"], max_retries=p["max_retries"],
                    retry_base_seconds=p["retry_base_seconds"], retry_max_seconds=p["retry_max_seconds"])

    def source_main(self, action):
        namespace = {"_load_api_key": self.loader, "action": action}
        exec("def main():\n    return action(_load_api_key())\n", namespace)
        return namespace["main"]

    def invoke(self, main, verify=False):
        with mock.patch.object(wire.importlib, "import_module", return_value=self.module), \
             mock.patch.object(wire.runpy, "run_path", return_value={"main": main}):
            if verify:
                return wire.verify_source(self.plan, self.job)
            return wire.run_source(self.plan, self.job, self.authority, SECRET, lambda: self.opener)

    def test_original_main_loader_constructor_and_hooks_restored(self):
        argv, path = sys.argv, list(sys.path)
        prior = {k: os.environ.get(k) for k in ("EXPGYM_API_DUMP_DIR", "EXPGYM_RUN_ID")}
        def action(key):
            self.assertEqual(key, SECRET)
            self.assertEqual(sys.argv, self.job["command"][3:])
            client = self.Client(**self.kwargs())
            self.assertEqual(client._transport(request(payload(self.plan)), 3600), b"opaque response bytes")
            return None
        main = self.source_main(action)
        result = self.invoke(main)
        self.assertEqual(result["source_exit_code"], 0)
        self.assertEqual(result["clients_created"], 1)
        self.assertIs(self.Client.__init__, self.original_init)
        self.assertIs(main.__globals__["_load_api_key"], self.loader)
        self.assertIs(sys.argv, argv)
        self.assertEqual(sys.path, path)
        self.assertEqual({k: os.environ.get(k) for k in prior}, prior)

    def test_nonzero_main_and_exception_preserve_hooks(self):
        result = self.invoke(self.source_main(lambda key: 1))
        self.assertEqual(result["source_exit_code"], 1)
        main = self.source_main(lambda key: (_ for _ in ()).throw(RuntimeError("synthetic source")))
        with self.assertRaises(RuntimeError):
            self.invoke(main)
        self.assertIs(self.Client.__init__, self.original_init)
        self.assertIs(main.__globals__["_load_api_key"], self.loader)

    def test_constructor_mismatch_is_blocked(self):
        def action(key):
            kwargs = self.kwargs(); kwargs["max_tokens"] = 99
            self.Client(**kwargs)
        with self.assertRaises(wire.WireContractError):
            self.invoke(self.source_main(action))
        self.assertEqual(self.opener.calls, [])

    def test_wrong_module_origin_or_source_command_blocked(self):
        self.module.__file__ = "/different/expgym/llm_clients.py"
        with self.assertRaises(wire.WireContractError):
            self.invoke(self.source_main(lambda key: 0))
        self.module.__file__ = REPO + "/expgym/llm_clients.py"
        self.job["command"][3] = REPO + "/scripts/not_registered.py"
        with self.assertRaises(wire.WireContractError):
            self.invoke(self.source_main(lambda key: 0))

    def test_verify_source_resume_without_credential_or_transport(self):
        def action(key):
            self.assertEqual(key, "RESTART_VERIFIED_RESUME_PUBLIC_PLACEHOLDER")
            self.assertEqual(sys.argv, self.job["command"][3:] + ["--resume"])
            self.assertEqual(os.environ["EXPGYM_API_DUMP_DIR"], "")
            return 0
        with mock.patch.object(wire, "InvocationWire", side_effect=AssertionError("verify created wire")):
            result = self.invoke(self.source_main(action), verify=True)
        self.assertTrue(result["passed"])
        self.assertEqual(result["forbidden_model_attempts"], {"construction": 0, "generation": 0})
        self.assertFalse(result["artifact_bytes_verified_by_this_helper"])
        self.assertEqual(self.opener.calls, [])
        self.assertIs(self.Client.__init__, self.original_init)
        self.assertIs(self.Client.generate, self.original_generate)

    def test_verify_source_constructor_or_existing_generate_forbidden(self):
        for existing in (False, True):
            with self.subTest(existing=existing):
                def action(key):
                    if existing:
                        object.__new__(self.Client).generate()
                    else:
                        self.Client(**self.kwargs())
                with self.assertRaises(wire.WireContractError):
                    self.invoke(self.source_main(action), verify=True)
                self.assertIs(self.Client.__init__, self.original_init)
                self.assertIs(self.Client.generate, self.original_generate)
        self.assertEqual(self.opener.calls, [])


if __name__ == "__main__":
    unittest.main()
