"""Bounded original-runner integration, fake bytes and synthetic FD key only."""
import copy
import os
from pathlib import Path
import sys
import tempfile
import time
import unittest
from unittest import mock

import real_common as common
import real_authority as auth
import real_dispatch as dispatch
import real_invocation as invocation
import real_journal as journal
import real_runner_child
import secret_fd
from test_real_execution import FixtureBase, KEY, URL


class SourceIntegration(FixtureBase):
    def make_case(self, system, scenario, task=None):
        old = common.read(common.HERE.parent.parent / "formal_executor_candidate/validation/cpu_acceptance_v4_v3/plan.json")
        policy = dict(old["policy"], max_steps=1, max_evals=1, max_retries=1, retry_base_seconds=0.001, retry_max_seconds=0.001)
        plan = common.core().prepare_plan(old["candidate_path"], old["candidate_sha256"],
            {k: v["path"] for k, v in old["profiles"].items()}, policy, common.main_source(),
            common.frozen.STUDY / "validation/static_acceptance_v4.json")
        now = time.time()
        study = {"kind": "CPU_REAL_PATH_FIXTURE_NOT_AUTHORITY", "run_id": "CPU-real-source:" + self.folder.name,
            "output_root": str(self.root), "validated_plan_view": plan,
            "operations": {"workers": 1, "max_http_attempts": 100000, "max_wall_seconds": 3600, "stop_new_before_deadline_seconds": 1},
            "whole_study": {"not_before": now - 100, "absolute_deadline": now + 3600, "max_allocation_gpu_seconds": 1}}
        chosen = next(x for x in plan["candidate"]["invocations"] if x["model"] == "m0" and x["system"] == system
            and x["scenario"] == scenario and (task is None or common.core().logical_rows(plan, x)[0]["selector"].get("tuning_task") == task))
        native = Path(os.environ["FORMAL_CPU_NATIVE_PYTHON"]).expanduser().absolute()
        legacy = Path(os.environ["FORMAL_CPU_LEGACY_RUNTIME"]).expanduser().absolute() / ".venv-hpo/bin/python"
        command = common.core().fake_command(plan, chosen, self.root, str(native), str(legacy))
        command[command.index("--backend") + 1] = "openai"
        command[command.index("--tool-protocol") + 1] = "native"
        command += ["--base-url", URL.rsplit("/chat/completions", 1)[0]]
        epoch = {"kind": "CPU_REAL_PATH_FIXTURE_NOT_AUTHORITY", "identity": {"endpoint": URL.rsplit("/chat/completions", 1)[0],
            "native_python": str(native), "legacy_python": str(legacy),
            "valid_until": now + 3600, "credential": {"mode": "bearer_anonymous_fd"}}, "model": "m0", "epoch_id": 0,
            "commands": [{"invocation_id": chosen["invocation_id"], "command": command, "sha256": common.digest(command)}],
            "evidence": {"ready": {"sha256": "b" * 64}}}
        anchors = {"definition": self.ref("definition", study), "epoch": self.ref("epoch", epoch)}
        go = {"output_root": str(self.root), "invocation_ids": [chosen["invocation_id"]], "not_before": now - 100, "valid_until": now + 3600}
        grant = auth.RealGrant(auth._TOKEN, study=study, epoch=epoch, anchors={}, go=go)
        instance = journal.Journal(self.root, common.digest(study), plan["candidate"]["invocations"], plan["candidate"]["logical_rows"],
            create=True, capability=journal.real_root_capability(grant))
        self.addCleanup(instance.close)
        return study, epoch, anchors, chosen, instance, grant

    def execute_case(self, system, scenario, task=None):
        study, epoch, anchors, chosen, instance, grant = self.make_case(system, scenario, task)
        original = secret_fd.run_child
        def inert_child(command, cwd, env, log, *, secret):
            # Only this test substitutes a separate explicitly CPU driver. Real
            # invocation.py's fixed driver remains unchanged on disk.
            argv = list(command)
            spec_index = argv.index("--spec") + 1
            spec = common.read(argv[spec_index])
            spec["cpu_fixture_boundary"] = True
            fixture_spec = Path(argv[spec_index]).with_name("cpu_fixture_child_spec.json")
            common.write(fixture_spec, spec)
            argv[spec_index] = str(fixture_spec)
            argv[2] = str(common.HERE / "cpu_child_fixture.py")
            return original(argv, cwd, env, log, secret=secret)
        with mock.patch.object(auth, "validate_real_authority", return_value=grant), \
             mock.patch.object(auth, "verify_epoch"), \
             mock.patch.object(secret_fd, "run_child", inert_child):
            report = invocation.execute_real_invocation(study, epoch, anchors, chosen["invocation_id"], instance, secret=KEY)
        common.write(self.folder / "CPU_ONLY_source_adapter_report.json", {"classification": "CPU fake bytes; not ROOT authority or model performance",
            "external_authority_validation_mocked": True, "all_child_network_blocked": True, "synthetic_key_only": True,
            "outer_test_interpreter": sys.executable,
            "source_child_interpreter": epoch["commands"][0]["command"][0], "result": report})
        self.assertTrue(report["passed"], {k: v for k, v in report.items() if k not in ("preflight", "raw", "after_runner", "score")})
        self.assertEqual(report["schema_version"], auth.PRODUCER_SCHEMA)
        self.assertFalse(report["attempt_operations"]["issues"])
        self.assertTrue(all(x["owner_evidence_qualified"] for x in report["owners"]))
        self.assertTrue(report["resume"]["executed"])
        spec = common.read(self.root / "logs" / chosen["invocation_id"] / "child_spec.json")
        with self.assertRaises((FileExistsError, real_runner_child.GateError)):
            real_runner_child.claim_child(spec, study, epoch, grant)
        changed = dict(spec, dump_dir=str(self.root / "raw/another_invocation"))
        with self.assertRaises(real_runner_child.GateError):
            real_runner_child.claim_child(changed, study, epoch, grant)
        with mock.patch.object(auth, "validate_real_authority", return_value=grant), mock.patch.object(auth, "ensure_epoch_record"), \
             mock.patch.object(secret_fd, "run_child", side_effect=AssertionError("must not repeat begun")):
            with self.assertRaises((auth.AuthorityError, journal.JournalError, FileExistsError)):
                invocation.execute_real_invocation(study, epoch, anchors, chosen["invocation_id"], instance, secret=KEY)
        return report

    def test_audit_three_original_orders_native_runtime(self):
        self.assertEqual(len(self.execute_case("expgym", "evidence_audit")["owners"]), 3)

    def test_pool_n4_original_runner_raw_scorer_and_resume(self):
        self.assertEqual(len(self.execute_case("poolact", "restricted_search")["owners"]), 4)

    def test_legacy_paramnet_original_runner_and_interpreter(self):
        self.assertEqual(len(self.execute_case("expgym", "tuning", "hpobench:paramnet:adult:steps")["owners"]), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
