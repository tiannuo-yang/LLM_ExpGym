"""One-use, read-only source inventory for the user-retired K3 epoch.

Writes generated reports only beside this script, never under either source root.
No network, subprocess execution, credential reads, scoring, or model calls.
"""
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import time

HERE = Path(__file__).resolve().parent
N = HERE.parents[2]
AUTH = N / "operations/parallel_full_20260908/formal_authority_retry_v5/kimi-k3"
ROOTS = {
    "formal": N / "formal_runs/parallel_full_20260908_k3_r3_retry_v5",
    "operator": AUTH / "dispatch_epoch_000_v1",
}
PARENT_PID = 4009384


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def stable_tuple(s):
    return (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns, s.st_mode)


def stat_fields(s):
    return dict(device=s.st_dev, inode=s.st_ino, bytes=s.st_size,
                mtime_ns=s.st_mtime_ns, ctime_ns=s.st_ctime_ns, mode=s.st_mode)


def regular_ref(p):
    if p.resolve(strict=True) != p:
        raise RuntimeError("symlink in file path: " + str(p))
    before = p.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise RuntimeError("not a regular file: " + str(p))
    if any(x in p.name.lower() for x in ("secret", "api_key", "credential", "password")):
        raise RuntimeError("refusing credential-like filename: " + str(p))
    digest = hashlib.sha256()
    with p.open("rb") as f:
        if stable_tuple(os.fstat(f.fileno())) != stable_tuple(before):
            raise RuntimeError("file changed before open: " + str(p))
        for block in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(block)
        if stable_tuple(os.fstat(f.fileno())) != stable_tuple(before):
            raise RuntimeError("file changed during read: " + str(p))
    if stable_tuple(p.lstat()) != stable_tuple(before):
        raise RuntimeError("file changed after read: " + str(p))
    return dict(path=str(p), sha256=digest.hexdigest(), **stat_fields(before))


def write_new(name, value):
    p = HERE / name
    with p.open("x", encoding="utf-8") as f:
        json.dump(value, f, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False)
        f.write("\n")
    return regular_ref(p)


def read_json(p):
    if p.resolve(strict=True) != p:
        raise RuntimeError("symlink in metadata path: " + str(p))
    before = p.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise RuntimeError("metadata is not a regular file: " + str(p))
    fd = os.open(p, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, "rb") as f:
        if stable_tuple(os.fstat(f.fileno())) != stable_tuple(before):
            raise RuntimeError("metadata changed before read: " + str(p))
        data = f.read()
        if stable_tuple(os.fstat(f.fileno())) != stable_tuple(before):
            raise RuntimeError("metadata changed during read: " + str(p))
    if stable_tuple(p.lstat()) != stable_tuple(before):
        raise RuntimeError("metadata changed after read: " + str(p))
    return json.loads(data)


def inventory():
    files, dirs = [], []
    def walk_error(error):
        raise error
    for label, root in ROOTS.items():
        if root.resolve() != root or not root.is_dir():
            raise RuntimeError("invalid explicit source root: " + str(root))
        for directory, subdirs, names in os.walk(root, followlinks=False, onerror=walk_error):
            dp = Path(directory)
            ds = dp.lstat()
            if not stat.S_ISDIR(ds.st_mode):
                raise RuntimeError("non-directory: " + str(dp))
            dirs.append(dict(root=label, path=str(dp), relative_path=str(dp.relative_to(root)), **stat_fields(ds)))
            subdirs.sort()
            for name in subdirs:
                if not stat.S_ISDIR((dp / name).lstat().st_mode):
                    raise RuntimeError("symlink/special directory: " + str(dp / name))
            for name in sorted(names):
                p = dp / name
                files.append(dict(root=label, relative_path=str(p.relative_to(root)), **regular_ref(p)))
            if len(files) and len(files) % 2000 < len(names):
                print(json.dumps({"utc": utc(), "inventory_files_so_far": len(files)}), flush=True)
    return sorted(files, key=lambda x: x["path"]), sorted(dirs, key=lambda x: x["path"])


def closure_metadata():
    root = ROOTS["formal"]
    starts = {p.name[:-11]: p for p in (root / "journal").glob("*.start.json")}
    finishes = {p.name[:-12]: p for p in (root / "journal").glob("*.finish.json")}
    failed = []
    for iid, p in finishes.items():
        d = read_json(p)
        if d.get("passed") is not True:
            failed.append(dict(invocation_id=iid, path=str(p), passed=d.get("passed"), error_type=d.get("error_type")))
    epoch_path = AUTH / "compile_epoch_000_v1/epoch.json"
    epoch_ref = regular_ref(epoch_path)
    epoch = read_json(epoch_path)
    ordered = [c["invocation_id"] for c in epoch["commands"]]
    if len(ordered) != 1845 or len(set(ordered)) != len(ordered):
        raise RuntimeError("unexpected original epoch scope")
    if len(starts) != 295 or set(starts) != set(finishes) or not set(starts).issubset(ordered):
        raise RuntimeError("journal is not locally terminal or not in original scope")
    processes = []
    for iid in sorted(starts):
        p = root / "logs" / iid / "invocation_receipt.json"
        d = read_json(p)
        run = d.get("run", {})
        if run.get("child_started") is not True or any(run.get(k) is not True for k in
                ("drain_proven", "stdout_eof_observed", "wait_returned")):
            raise RuntimeError("runner child closure is not established: " + str(p))
        processes.append(dict(invocation_id=iid, path=str(p), run={k: run.get(k) for k in
                         ("exit_code", "child_started", "drain_proven", "stdout_eof_observed", "wait_returned")},
                         other_process_exit_codes={k: d.get(k, {}).get("exit_code") for k in
                         ("identity_process", "score_process", "resume")}))
    raw, states, pids, errors = [], collections.Counter(), set(), []
    for p in sorted((root / "dumps").rglob("*.json")):
        d = read_json(p)
        state = d.get("state")
        states[str(state)] += 1
        pid = d.get("pid")
        if type(pid) is int and pid > 0:
            pids.add(pid)
        else:
            raise RuntimeError("raw PID metadata missing: " + str(p))
        raw.append(dict(path=str(p), state=state, pid=pid,
                        started_at_utc=d.get("started_at_utc"), finished_at_utc=d.get("finished_at_utc")))
        if d.get("error") is not None:
            errors.append(dict(path=str(p), state=state, error_type=type(d["error"]).__name__))
        if state == "in_progress" or d.get("finished_at_utc") is None:
            raise RuntimeError("nonterminal raw: " + str(p))
    present = sorted(pid for pid in pids | {PARENT_PID} if Path("/proc", str(pid)).exists())
    if present:
        raise RuntimeError("known caller PID still present: " + str(present))
    terminal = ROOTS["operator"] / "run.json"
    if not terminal.is_file():
        raise RuntimeError("operator terminal receipt missing")
    return dict(observed_utc=utc(), parent_pid=PARENT_PID, known_raw_pids=sorted(pids),
                present_known_pids=present, original_scope_count=len(ordered), epoch_ref=epoch_ref,
                started_ids=sorted(starts), finished_ids=sorted(finishes),
                never_started_ids=[iid for iid in ordered if iid not in starts],
                failed_finishes=failed, raw_states=dict(states), raw_attempts=raw,
                raw_error_metadata=errors, invocation_processes=processes, terminal_ref=regular_ref(terminal),
                closure="bounded_local_caller_closure", private_provider_queue_proven_empty=False)


def main():
    began = utc()
    if (HERE / "inventory.json").exists():
        raise RuntimeError("one-use inventory already exists")
    closure = closure_metadata()
    files, dirs = inventory()
    part_refs = []
    for offset in range(0, len(files), 2000):
        group = files[offset:offset + 2000]
        ref = write_new("inventory.part%03d.json" % (offset // 2000), group)
        part_refs.append(dict(file_count=len(group), total_bytes=sum(x["bytes"] for x in group), **ref))
    dir_ref = write_new("inventory.directories.json", dirs)
    raw_ref = write_new("terminal_raw_metadata.json", closure["raw_attempts"])
    closure_ref = write_new("local_closure.json", {k: v for k, v in closure.items() if k != "raw_attempts"})
    files2, dirs2 = inventory()
    if files != files2 or dirs != dirs2:
        raise RuntimeError("source tree changed between complete inventories")
    final_closure = closure_metadata()
    if ({k: v for k, v in closure.items() if k != "observed_utc"} !=
            {k: v for k, v in final_closure.items() if k != "observed_utc"}):
        raise RuntimeError("closure metadata changed during sealing")
    manifest = dict(schema_version="retired-k3-epoch000-source-inventory-v1",
                    started_utc=began, finished_utc=utc(), roots={k: str(v) for k, v in ROOTS.items()},
                    file_count=len(files), directory_count=len(dirs), total_bytes=sum(x["bytes"] for x in files),
                    file_parts=part_refs, directories_ref=dir_ref, local_closure_ref=closure_ref,
                    terminal_raw_metadata_ref=raw_ref, complete_second_read_sha_bytes_stat_and_set_equal=True,
                    source_script_ref=regular_ref(Path(__file__).resolve()),
                    retirement_reason="user_requested_new_design_and_complete_restart",
                    excluded_from_new_study_results=True, no_network_or_model_calls=True,
                    limitations=["No claim about private provider scheduler queues.",
                                 "Raw success is transport completion, not model decision correctness.",
                                 "Interrupted old scope is incomplete and is not the restarted study."])
    ref = write_new("inventory.json", manifest)
    print(json.dumps({"inventory_ref": ref, "files": len(files), "directories": len(dirs),
                      "total_bytes": manifest["total_bytes"], "started": len(closure["started_ids"]),
                      "finished": len(closure["finished_ids"]), "never_started": len(closure["never_started_ids"]),
                      "raw_states": closure["raw_states"], "complete_second_read_equal": True}), flush=True)


if __name__ == "__main__":
    main()
