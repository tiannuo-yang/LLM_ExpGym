"""Explicit frozen-source CPU E2E; never a provider or formal-run acceptance.

Run only with --run-frozen-cpu and a fresh --output-root. Every source case is a
separate native-runtime child with socket/process creation blocked before source
import. The original source client, task data, evaluator and resume are real;
only HTTP response delivery and the authority object are synthetic.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
from contextlib import redirect_stderr, redirect_stdout
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import threading
import time
import traceback

import evidence
import launcher
import planner
import support as s
import wire

HERE = Path(__file__).absolute().parent
STUDY = s.STUDY
ACCEPTANCE = HERE.parent / "source_acceptance_v5_final.json"
ACCEPTANCE_SHA = "0b1166cb5549ceb606bd98086809548cb0d83c3e94070e3570cc4783e1b1a744"
PROFILE = STUDY / "profiles/development_declared_v1/glm-5.3.json"
PROFILE_SHA = "1e090971c89964b658cf12abc987e25e10bb52bd7dc9efdc1e8c126ac1a7583c"
CPU_ENDPOINT = "http://cpu-source-e2e.invalid/v1/chat/completions"
PUBLIC_MARKER = "CPU_PUBLIC_NOT_SECRET"
CASES = (
    ("exp_search_normal", "expgym", "restricted_search", "single", False),
    ("exp_search_missing", "expgym", "restricted_search", "single", True),
    ("pool_search_naive_missing", "poolact", "restricted_search", "naive", True),
    ("pool_search_cached_missing", "poolact", "restricted_search", "cached", True),
    ("pool_search_poolact_missing", "poolact", "restricted_search", "poolact", True),
    ("exp_audit_missing", "expgym", "evidence_audit", "single", True),
    ("exp_nas_missing", "expgym", "tuning", "single", True),
    ("exp_audit_normal", "expgym", "evidence_audit", "single", False),
)


def file_sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def frozen_inputs():
    if file_sha(ACCEPTANCE) != ACCEPTANCE_SHA or file_sha(PROFILE) != PROFILE_SHA:
        raise ValueError("cpu_source_or_profile_receipt_changed")
    receipt = s.parse_json(s.io.read_regular(ACCEPTANCE))
    repo = Path(receipt["repo_root"])
    if len(receipt["files"]) != 86:
        raise ValueError("cpu_source_file_count_changed")
    for relative, expected in receipt["files"].items():
        if file_sha(repo / relative) != expected:
            raise ValueError("cpu_frozen_source_changed")
    native = receipt["runtime_interpreters"]["native"]
    if file_sha(native["path"]) != native["sha256"]:
        raise ValueError("cpu_native_runtime_changed")
    full = s.parse_json(s.io.read_regular(PROFILE))
    return receipt, launcher.normalized_profile(full)


def selected_data(repo):
    base = repo / "data/phantom-wiki/datasets--kilian-group--phantom-wiki-v1/snapshots" / planner.SNAPSHOT
    filename = "depth_20_size_5000_seed_2-00000-of-00001.parquet"
    paths = [(base / "question-answer" / filename, planner.SEARCH[2][2]),
        (base / "text-corpus" / filename, planner.SEARCH[2][3]),
        (repo / "data/contract-nli/test_segments.json", "a81e3ecfc1d423f11289a1711ccd4d5cf3167f4d75576f5180bcc0b4c928fd23"),
        (repo / "data/contract-nli/test_nda_span_dims.json", "25e9a4092a2688dcb1e933161056b4a6362e1b3941610fd0b5aa205745c96c59"),
        (repo / "data/hpo_tuning/hpobench_data/nasbench_101_compact.pkl", "09271ca32f545aac7718be80a0109f79c6244e7853d2f8989aed3b614c590178"),
        (repo / "data/hpo_tuning/hpobench_data/nasbench_101_compact.manifest.json", None),
        (repo / "data/hpo_tuning/oracle3.json", None)]
    result = []
    for path, expected in paths:
        resolved = path.resolve(strict=True)
        value = {"source_path": str(path), "path": str(resolved), "sha256": file_sha(resolved), "bytes": resolved.stat().st_size}
        if expected is not None and value["sha256"] != expected:
            raise ValueError("cpu_selected_data_changed")
        result.append(value)
    return result


def make_plan(root, receipt, profile):
    repo = Path(receipt["repo_root"])
    config = {"run_id": root.name, "output_root": str(root), "repo_root": str(repo),
        "model": {"label": "cpu_glm_full_profile", "model_id": "glm-5.3"},
        "endpoint": CPU_ENDPOINT, "profiles": {"glm-5.3": profile}, "environment": {},
        "runtimes": {"native": {"executable": receipt["runtime_interpreters"]["native"]["path"]}},
        "policy": {"workers": 4, "max_steps": 1, "max_evals": 1, "max_tokens": 32768,
            "max_context_tokens": 131072, "max_protocol_retries": 1, "max_retries": 2,
            "request_timeout": 3600, "retry_base_seconds": 3, "retry_max_seconds": 30,
            "tuning_final_policy": "legacy", "missing_final_policy": "task-abstention-v1",
            "stop_new_before_deadline_seconds": 21600, "max_wall_seconds": 300}}
    invocations, rows = [], []
    for index, (name, system, scenario, strategy, missing) in enumerate(CASES):
        seed = 19000 + 10 * index
        output = "results/" + name
        params = ["--scenarios" if system == "expgym" else "--scenario", scenario,
            "--cost-regimes" if system == "expgym" else "--cost-regime", "cost_tight", "--seed", str(seed)]
        if system == "expgym":
            params += ["--models", config["model"]["label"], "--model-alias", config["model"]["label"] + "=glm-5.3",
                "--tuning-reps", "1", "--search-reps", "1", "--audit-reps", "3" if scenario == "evidence_audit" else "1",
                "--trace-format", "v2"]
        else:
            params += ["--model", "glm-5.3", "--agents", "2", "--repeats", "1", "--strategies", strategy]
        if scenario == "restricted_search":
            params += ["--search-data-source" if system == "expgym" else "--data-source", "phantom_seed2",
                "--search-indices" if system == "expgym" else "--question-index", "0"]
        elif scenario == "evidence_audit":
            params += ["--audit-indices", "0", "--cc-split", "cc-large", "--audit-orders", str(repo / "configs/audit_hypothesis_orders.json")]
        else:
            params += ["--tuning-tasks", "hpobench:nasbench101:A"]
        invocation = {"invocation_id": name, "system": system, "scenario": scenario, "outerrep": 0,
            "runtime_profile_required": "native", "runner": "scripts/run_paper_sweep.py" if system == "expgym" else "scripts/run_poolact.py",
            "selection_argv": params, "output_relative_dir": output, "dump_relative_dir": "dumps/" + name,
            "summary_artifact": output + "/summary.json" if system == "poolact" else None,
            "cpu_missing_fixture": missing}
        invocations.append(invocation)
        orders = range(3) if scenario == "evidence_audit" else [0]
        for order in orders:
            if system == "poolact":
                artifact = output + "/" + strategy + "/result.json"
                agents = [output + "/" + strategy + "/agents/agent_%d.json" % agent for agent in range(2)]
            else:
                if scenario == "restricted_search":
                    filename = "restricted_search_phantom_seed2_0_r0_s%d.json" % seed
                elif scenario == "evidence_audit":
                    filename = "evidence_audit_cc-large_0_r%d_s%d.json" % (order, seed + order)
                else:
                    filename = "tuning_hpobench_nasbench101_A_r0_s%d.json" % seed
                artifact = output + "/" + config["model"]["label"] + "_cost_tight/traces-v2/" + filename
                agents = [artifact]
            rows.append({"invocation_id": name, "system": system, "result_artifact": artifact, "agent_artifacts": agents,
                "sampling_seed_labels": [seed, seed + 1] if system == "poolact" else [seed + order]})
    matrix = {"invocations": invocations, "logical_rows": rows}
    matrix["expected_files"] = planner.expected_files(matrix)
    jobs = launcher.formal_jobs(config, matrix)
    launcher.policy_check(config["policy"])
    launcher.validate_jobs(config, jobs)
    return {"schema_version": "cpu-frozen-source-e2e-plan-v1", "classification": "Static/fake validation",
        "config": config, "jobs": jobs, "source_acceptance_ref": s.ref(ACCEPTANCE), "profile_ref": s.ref(PROFILE),
        "source_tree_sha256": receipt["source_tree_sha256"], "selected_data": selected_data(repo),
        "real_model_calls_authorized": False, "formal_launch_authorized": False}


class CPUAuthority:
    """No ROOT grant or secret capability: only this synthetic invocation."""
    def __init__(self, job):
        self.job, self.checks = job, 0
        self.lock = threading.Lock()
    def check(self, invocation_id):
        if invocation_id != self.job["invocation_id"] or self.job["endpoint"] != CPU_ENDPOINT:
            raise ValueError("cpu_authority_scope_differs")
        with self.lock:
            self.checks += 1
    def record_wire(self, event):
        token = event.get("attempt_sequence", event["wire_client_id"])
        s.put(Path(self.job["log_dir"]) / "wire", event["kind"] + "_" + str(token) + ".json", event)


class SyntheticOpener:
    def __init__(self, job):
        self.job = job
    def open(self, request, timeout):
        if request.full_url != CPU_ENDPOINT or request.get_method() != "POST" or timeout != 3600:
            raise ValueError("cpu_opener_scope_differs")
        missing = self.job["cpu_missing_fixture"]
        content = "" if missing else ("{}" if self.job["scenario"] == "evidence_audit" else "CPU synthetic prediction")
        response = {"id": "cpu-synthetic-delivery", "object": "chat.completion", "model": "glm-5.3",
            "choices": [{"index": 0, "message": {"role": "assistant", "content": content,
                "reasoning_content": "CPU synthetic reasoning retained"}, "finish_reason": "length" if missing else "stop"}],
            "usage": {"prompt_tokens": 10, "completion_tokens": 2, "total_tokens": 12}}
        return io.BytesIO(json.dumps(response).encode("utf-8"))


def install_network_guard():
    counts = {"socket_attempts": 0, "unexpected_subprocess_attempts": 0, "blocked_local_git_metadata_attempts": 0,
              "blocked_platform_uname_metadata_attempts": 0}
    source_root = STUDY.parents[2] / "source_cohorts/v5/LLM_ExpGym"
    permitted_absence = (("git", "rev-parse", "HEAD"), ("git", "status", "--porcelain=v1"), ("git", "diff", "--binary", "HEAD"))
    def guard(event, args):
        if event == "subprocess.Popen" and tuple(args[1]) == ("uname", "-p") and args[2] is None:
            counts["blocked_platform_uname_metadata_attempts"] += 1
            raise FileNotFoundError("CPU_PLATFORM_PROCESSOR_METADATA_UNAVAILABLE")
        if event == "subprocess.Popen" and tuple(args[1]) in permitted_absence and Path(args[2]) == source_root:
            # The unmodified source explicitly tolerates missing git. Preserve
            # exact source-tree SHA provenance, without executing a child that
            # would not inherit Python's socket guard. Never fabricate git data.
            counts["blocked_local_git_metadata_attempts"] += 1
            raise FileNotFoundError("CPU_LOCAL_GIT_METADATA_UNAVAILABLE")
        if event.startswith("socket."):
            counts["socket_attempts"] += 1
            raise RuntimeError("CPU_E2E_NETWORK_AND_SUBPROCESS_FORBIDDEN")
        if event in ("subprocess.Popen", "os.system", "os.posix_spawn", "os.posix_spawnp"):
            counts["unexpected_subprocess_attempts"] += 1
            raise RuntimeError("CPU_E2E_NETWORK_AND_SUBPROCESS_FORBIDDEN")
    sys.addaudithook(guard)
    return counts


def mtimes(root):
    return {row["path"]: Path(row["path"]).stat().st_mtime_ns for row in launcher.safe_tree(root)}


def worker(plan_path, invocation_id):
    guard = install_network_guard()
    plan = s.parse_json(s.io.read_regular(plan_path))
    receipt, unused = frozen_inputs()
    if str(Path(sys.executable).resolve()) != str(Path(receipt["runtime_interpreters"]["native"]["path"]).resolve()):
        raise ValueError("cpu_actual_interpreter_differs")
    job = next(value for value in plan["jobs"] if value["invocation_id"] == invocation_id)
    root = Path(plan["config"]["output_root"])
    for key in ("dump_dir", "log_dir"):
        Path(job[key]).mkdir(parents=True, exist_ok=False)
    (Path(job["log_dir"]) / "wire").mkdir()
    authority = CPUAuthority(job)
    report = {"invocation_id": invocation_id, "passed": False, "classification": "Static/fake validation",
        "original_source_scorer_used": True, "provider_calls": 0, "original_score_values_omitted": True,
        "network_guard": guard, "synthetic_secret_marker": PUBLIC_MARKER}
    began = time.monotonic()
    try:
        with (Path(job["log_dir"]) / "original_source.log").open("x", encoding="utf-8") as log, redirect_stdout(log), redirect_stderr(log):
            run = wire.run_source(plan, job, authority, PUBLIC_MARKER, opener_factory=lambda: SyntheticOpener(job))
            if run["source_exit_code"] != 0:
                raise ValueError("cpu_original_source_exit_nonzero")
            before = {key: launcher.safe_tree(job[key]) for key in ("output_dir", "dump_dir", "terminal_evidence_dir")}
            if {r["path"] for r in before["output_dir"]} != set(job["expected_files"]):
                raise ValueError("cpu_original_result_file_set_differs")
            if not before["terminal_evidence_dir"]:
                raise ValueError("cpu_original_terminal_evidence_missing")
            before_mtime = {key: mtimes(job[key]) for key in before}
            status = launcher.terminal_status(job)
            expect_score = job["scenario"] != "tuning" or not job["cpu_missing_fixture"]
            if (status["execution_complete"] is not True or status["score_complete"] is not expect_score
                    or status["model_no_answer_count"] != (job["expected_model_terminals"] if job["cpu_missing_fixture"] else 0)
                    or status["reported_model_terminals"] != job["expected_model_terminals"]):
                raise ValueError("cpu_typed_source_terminal_differs")
            verify_job = copy.deepcopy(job)
            index = verify_job["command"].index("--terminal-evidence-dir")
            verify_job["command"][index + 1] = str(root / "verification_evidence" / invocation_id)
            verified = wire.verify_source(plan, verify_job)
            after = {key: launcher.safe_tree(job[key]) for key in before}
            changed_mtime = {key: [path for path, prior in before_mtime[key].items() if Path(path).stat().st_mtime_ns != prior] for key in before}
            if not verified["passed"] or before != after or any(verified["forbidden_model_attempts"].values()):
                raise ValueError("cpu_original_verified_resume_failed_or_changed_bytes")
            audit = evidence.audit_raw(plan, job, [r["path"] for r in before["dump_dir"]],
                [r["path"] for r in launcher.safe_tree(Path(job["log_dir"]) / "wire")])
            s.put(job["log_dir"], "raw_audit.json", audit)
            if not audit["verified"]:
                raise ValueError("cpu_original_raw_wire_audit_failed")
            frozen_inputs()
            if guard["socket_attempts"] or guard["unexpected_subprocess_attempts"]:
                raise ValueError("cpu_network_guard_was_exercised")
            report.update(passed=True, source_run=run, terminal_status=status, verified_resume=verified,
                original_artifact_inventories=before, original_bytes_unchanged=True, changed_mtime_paths=changed_mtime,
                raw_audit_ref=s.ref(Path(job["log_dir"]) / "raw_audit.json"),
                source_hashes_unchanged=True, authority_checks=authority.checks,
                verification_evidence=launcher.safe_tree(root / "verification_evidence" / invocation_id))
    except BaseException as exc:
        with (Path(job["log_dir"]) / "failure_traceback.log").open("x", encoding="utf-8") as trace:
            traceback.print_exc(file=trace)
        report.update(error_type=type(exc).__name__, error_message_omitted=True,
            failure_code=str(exc) if isinstance(exc, ValueError) and str(exc).startswith("cpu_") else "see_retained_source_log")
    report["elapsed_seconds"] = time.monotonic() - began
    report["local_artifacts"] = {key: launcher.safe_tree(job[key]) for key in ("output_dir", "dump_dir", "terminal_evidence_dir")}
    s.put(job["log_dir"], "cpu_result.json", report)
    return 0 if report["passed"] else 2


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-frozen-cpu", action="store_true")
    parser.add_argument("--output-root", type=Path)
    parser.add_argument("--worker-plan", type=Path)
    parser.add_argument("--invocation-id")
    args = parser.parse_args()
    if args.worker_plan:
        return worker(args.worker_plan, args.invocation_id)
    if not args.run_frozen_cpu or args.output_root is None:
        parser.error("explicit --run-frozen-cpu and fresh --output-root required")
    root = args.output_root.absolute()
    if root.parent != HERE / "validation_source_e2e" or root.exists():
        raise ValueError("cpu_fresh_dedicated_validation_child_required")
    receipt, profile = frozen_inputs()
    root.parent.mkdir(exist_ok=True)
    root.mkdir()
    plan = make_plan(root, receipt, profile)
    s.put(root, "plan.json", plan)
    env = launcher.clean_environment(plan["config"])
    env.update(CUDA_VISIBLE_DEVICES="", HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", HF_DATASETS_OFFLINE="1")
    def launch(job):
        with (root / (job["invocation_id"] + ".capture.log")).open("xb") as log:
            command = [receipt["runtime_interpreters"]["native"]["path"], "-u", "-B", str(Path(__file__).absolute()),
                "--worker-plan", str(root / "plan.json"), "--invocation-id", job["invocation_id"]]
            result = subprocess.run(command, cwd=receipt["repo_root"], env=env, stdout=log, stderr=subprocess.STDOUT, timeout=300)
        path = Path(job["log_dir"]) / "cpu_result.json"
        report = s.parse_json(s.io.read_regular(path)) if path.exists() else {"passed": False, "failure_code": "cpu_child_no_report"}
        return {"invocation_id": job["invocation_id"], "exit_code": result.returncode, "passed": report["passed"],
            "failure_code": report.get("failure_code"), "terminal_status": report.get("terminal_status"),
            "report_ref": s.ref(path) if path.exists() else None}
    with ThreadPoolExecutor(max_workers=4) as executor:
        results = list(executor.map(launch, plan["jobs"]))
    frozen_inputs()
    unchanged_data = selected_data(Path(receipt["repo_root"])) == plan["selected_data"]
    summary = {"schema_version": "cpu-original-source-e2e-v1", "classification": "Static/fake validation",
        "passed": all(r["passed"] and r["exit_code"] == 0 for r in results) and unchanged_data,
        "cases": results, "cases_planned": len(CASES), "provider_calls": 0,
        "source_acceptance_ref": s.ref(ACCEPTANCE), "profile_ref": s.ref(PROFILE), "plan_ref": s.ref(root / "plan.json"),
        "test_source_ref": s.ref(__file__), "selected_data_unchanged": unchanged_data,
        "limitations": ["Synthetic stop/length deliveries, not actual GLM or provider acceptance.",
            "Eight selected CPU cases, one step/evaluation and two-agent pools; not the formal matrix.",
            "NAS missing configuration remains unscorable; no NAS performance is invented.",
            "No ParamNet legacy-runtime or native tool-call roundtrip is covered by these fixtures.",
            "Local git and platform uname metadata subprocesses are blocked via their original missing-executable fallbacks; exact frozen source-file hashes remain verified."]}
    s.put(root, "summary.json", summary)
    print(json.dumps({"passed": summary["passed"], "cases": results, "summary": str(root / "summary.json")}, sort_keys=True))
    return 0 if summary["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
