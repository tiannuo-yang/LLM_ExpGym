"""Fixed real model/outer dispatch; external admission, stop-new, natural drain."""
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
import time

import real_authority as authority
import real_common as common
from real_journal import eligible_inventory
from real_invocation import execute_real_invocation
from secret_fd import validate_secret


def dispatch_real(study, journal, bindings, *, secrets, prefix, initial_started=None):
    """Bindings map label to (epoch, external anchors, previous), or None.
    The real worker is fixed in accepted source, not caller-supplied executable.
    Secrets are caller memory keyed by model, never included in a receipt.
    """
    if not isinstance(prefix, str) or not prefix or len(prefix) > 64 or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-" for c in prefix):
        raise authority.AuthorityError("safe_unique_dispatch_prefix_required")
    def worker(invocation, epoch, anchors, previous):
        return execute_real_invocation(study, epoch, anchors, invocation["invocation_id"], journal,
            secret=secrets[epoch["model"]], previous_epoch=previous)
    authority.verify_study(study)
    if journal.plan_sha256 != common.digest(study):
        raise authority.AuthorityError("controller_journal_definition_mismatch")
    before = journal.reconcile()
    if not before["valid"]:
        raise authority.AuthorityError("invalid_prior_journal")
    started = {x["invocation_id"] for x in before["invocations"] if x["started"]}
    if initial_started is not None and set(initial_started) != started:
        raise authority.AuthorityError("prior_started_scope_changed")
    eligible = eligible_inventory(journal)
    reserved_without_start = eligible["reserved_without_start"]
    blocked = set(reserved_without_start)
    policy = study["operations"]
    plan = study["validated_plan_view"]
    by_id = {x["invocation_id"]: x for x in plan["candidate"]["invocations"]}
    def reservation(iid):
        rows = common.core().logical_rows(plan, by_id[iid])
        owners = len(rows) if by_id[iid]["system"] == "expgym" else 4
        return owners * (plan["policy"]["max_steps"] + 1) * (plan["policy"]["max_retries"] + 1)
    # Previously begun calls with uncertain delivery retain a worst-case
    # reservation; absence of a completed receipt is never treated as zero.
    reserved_attempts = sum(reservation(iid) for iid in started | blocked)
    active, reports, stops = {}, [], []
    began = time.monotonic()
    max_active = 0
    for stage in plan["stages"]:
        stage_ids = [iid for iid in stage["invocation_ids"] if iid not in started and iid not in blocked]
        if not stage_ids:
            continue  # Completed stages do not require an expired earlier GO.
        selected = bindings.get(stage["model"])
        if selected is None:
            stops.append({"reason": "model_epoch_unbound", "model": stage["model"]})
            break
        epoch, anchors, previous = selected
        grant = authority.validate_real_authority(study, epoch, anchors, previous)
        validate_secret(secrets.get(epoch["model"]))
        authority.ensure_epoch_record(study, epoch, anchors, journal)
        journal.activate_grant(grant)
        if any(iid not in grant.scope for iid in stage_ids):
            raise authority.AuthorityError("GO_must_bind_complete_pending_stage_scope")
        key = prefix + "." + stage["stage_id"]
        journal.write_operation(key + ".begin", {"kind": "stage_begin", "stage_id": stage["stage_id"],
            "epoch_sha256": grant.epoch_sha256, "exact_never_begun_ids": stage_ids, "active_children": 0})
        pending, stop = iter(stage_ids), False
        with ThreadPoolExecutor(max_workers=policy["workers"]) as executor:
            exhausted = False
            while active or not exhausted and not stop:
                while not stop and not exhausted and len(active) < policy["workers"]:
                    try:
                        iid = next(pending)
                    except StopIteration:
                        exhausted = True
                        break
                    try:
                        grant.check(iid)
                        if reserved_attempts + reservation(iid) > policy["max_http_attempts"]:
                            raise authority.AuthorityError("registered_attempt_reservation_limit")
                        if (time.monotonic() - began >= policy["max_wall_seconds"]
                                or time.time() + policy["stop_new_before_deadline_seconds"] >= grant.deadline):
                            raise authority.AuthorityError("registered_wall_or_drain_margin_reached")
                    except Exception as exc:
                        stop = True
                        stops.append({"reason": type(exc).__name__, "invocation_id": iid})
                        break
                    future = executor.submit(worker, by_id[iid], epoch, anchors, previous)
                    reserved_attempts += reservation(iid)
                    active[future] = iid
                    started.add(iid)
                    max_active = max(max_active, len(active))
                if not active:
                    break
                completed, _ = wait(active, return_when=FIRST_COMPLETED)
                # Inspect the entire completed batch before starting another;
                # no low/negative score predicate appears here.
                for future in completed:
                    iid = active.pop(future)
                    try:
                        report = future.result()
                    except BaseException as exc:
                        report = {"invocation_id": iid, "passed": False, "error_type": type(exc).__name__}
                    reports.append(report)
                    if report.get("passed") is not True:
                        stop = True
                        stops.append({"reason": "infrastructure_or_integrity_failed", "invocation_id": iid})
                if stop:
                    exhausted = True
        # Executor context waits naturally; it never cancels/kills healthy work.
        journal.write_operation(key + ".drain", {"kind": "drain", "stage_id": stage["stage_id"],
            "epoch_sha256": grant.epoch_sha256, "local_workers": 0, "joined_child_http_calls": 0,
            "provider_quiescence_proven": False, "kind_of_proof": "joined_local_children_only_not_server_drain"})
        journal.write_operation(key + ".finish", {"kind": "stage_finish", "stage_id": stage["stage_id"],
            "stop_new": stop, "active_children": 0})
        if stop:
            break
    final = journal.reconcile()
    return {"schema_version": "phase3b-real-dispatch-receipt-v1", "classification": "real_dispatch_observation",
        "model_generation_count": None, "reserved_without_start": reserved_without_start,
        "whole_study_bounds": study["whole_study"], "dispatch_wall_bound_is_local": True, "reports": reports, "stop_reasons": stops,
        "max_active_workers": max_active, "elapsed_seconds": time.monotonic() - began,
        "http_attempt_upper_bound_reserved": reserved_attempts,
        "reservation_is_not_reported_usage_or_confirmed_sent": True,
        "journal": final, "passed": final["passed"] and not stops}
