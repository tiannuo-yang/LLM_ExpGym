#!/usr/bin/env python3
"""Reviewed execution only: exact committed source + unchanged scanner; no publish."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import stat
import subprocess
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).absolute().parent
W = HERE.parent.parent
REPO = W / 'publication/source_release_candidate_v5/repo'
HEAD = '9976ce741fab675435d6588ee1e70e29b14fcaea'
TREE = 'bcd15aa5d06f698db237f24a59c8bb6648dc5f93'
SCANNER = W / 'publication/validate_bundle_v2.py'
SCANNER_SHA = 'aea61a9309cb6069240b90e0ca706403b0f21b3e7f77a2f88d462e6ba8734116'
FILEMAP = W / 'publication/source_release_candidate_v5/LOCAL_CANDIDATE_RECEIPT.json'
FILEMAP_SHA = '38db187986d8329897ff55f1d0e1a3f18ab482774f01a3fdc9017a3b748e8d4e'
ACCEPTANCE = W / 'portable_eval_20260908/source_cohorts/v4/portable_eval_20260908/operations/restart_user_20260909/source_acceptance_v5_final.json'
ACCEPTANCE_SHA = '0b1166cb5549ceb606bd98086809548cb0d83c3e94070e3570cc4783e1b1a744'
TEMPLATE_SHA = '478eb129ff87ed3d422383a6e7bbbc511a1c191139bcba6939b475e124ebb44a'


class Refusal(Exception):
    pass


def need(condition, rule):
    if not condition:
        raise Refusal(rule)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def lexical(path):
    if isinstance(path, str):
        need(str(Path(path)) == path and '\\' not in path and
             all(ord(ch) >= 32 for ch in path), 'canonical_path_required')
    path = Path(path)
    need(path.is_absolute() and '..' not in path.parts, 'absolute_unambiguous_path_required')
    need(all(not p.is_symlink() for p in [path, *path.parents]), 'symlink_path')
    return path


def git(*args):
    # Read-only commands; no optional index locks, hooks, remote or fsmonitor.
    p = subprocess.run(['git', '--no-optional-locks', '-c', 'core.fsmonitor=false',
                        '-c', 'core.hooksPath=/dev/null', '-C', str(REPO), *args],
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    need(p.returncode == 0 and not p.stderr and len(p.stdout) <= 8 * 1024**2, 'local_git_read_failed')
    return p.stdout


def write_new(directory, name, value):
    raw = (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()
    need(len(raw) <= 8 * 1024**2, 'report_size_limit')
    fd = os.open(directory / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as f:
        f.write(raw)
        f.flush()
        os.fsync(f.fileno())
    return {'path': name, 'bytes': len(raw), 'sha256': sha(raw)}


def snapshot(scanner, expected, source86):
    need(git('rev-parse', 'HEAD', 'HEAD^{tree}').decode().splitlines() == [HEAD, TREE], 'exact_head_tree_required')
    need(not git('status', '--porcelain=v1', '--untracked-files=all', '--ignored=matching'), 'source_tree_not_clean')
    entries = {}
    for record in git('ls-tree', '-rz', '--full-tree', 'HEAD').split(b'\0'):
        if record:
            info, name = record.split(b'\t', 1)
            mode, kind, oid = info.decode().split()
            name = name.decode('utf-8')
            need(kind == 'blob' and mode in ('100644', '100755') and name not in entries, 'git_tree_entry_type')
            entries[name] = (mode, oid)
    need(set(entries) == set(expected) and len(entries) == 101, 'exact_101_file_set')
    allowed_dirs = {'.'} | {p.as_posix() for n in entries for p in Path(n).parents}
    found = set()
    for root, dirs, files in os.walk(REPO, followlinks=False):
        if Path(root) == REPO:
            dirs[:] = [d for d in dirs if d != '.git']
            files = [f for f in files if f != '.git']
        for name in dirs:
            p = Path(root) / name
            need(not p.is_symlink() and p.relative_to(REPO).as_posix() in allowed_dirs, 'unexpected_source_directory')
        for name in files:
            found.add((Path(root) / name).relative_to(REPO).as_posix())
    need(found == set(entries), 'source_filesystem_set')
    rows = []
    for name in sorted(entries):
        need(scanner.relative(name).as_posix() == name, 'source_relative_path')
        path = lexical(REPO / name)
        raw = scanner.stable_read(path)
        info = path.stat()
        mode, oid = entries[name]
        expected_row = expected[name]
        need(sha(raw) == expected_row['sha256'] and len(raw) == expected_row['bytes'] and
             mode == expected_row['git_mode'] and stat.S_IMODE(info.st_mode) == int(mode[-3:], 8), 'source_pin_or_mode_changed')
        need(hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == oid, 'worktree_not_exact_git_blob')
        rows.append({'path': name, 'sha256': sha(raw), 'bytes': len(raw), 'git_mode': mode,
                     'blob_oid': oid, 'mtime_ns': info.st_mtime_ns, 'device': info.st_dev, 'inode': info.st_ino})
    need(len(source86) == 86 and all(n in expected and expected[n]['sha256'] == h for n, h in source86.items()), 'source86_pin_set')
    need(not any(n.startswith(('runs/', 'budget_sweep_results/')) for n in entries), 'generated_sidecar')
    need([n for n in sorted(entries) if scanner.denied(n)] == ['.env.example'], 'only_exact_template_path_exception')
    need(expected['.env.example'] == {'path': '.env.example', 'bytes': 1936, 'git_mode': '100644', 'sha256': TEMPLATE_SHA}, 'template_not_exact_carried_file')
    return {'head': HEAD, 'tree': TREE, 'files': rows}


def scan_spec(rows):
    return {'approved': True, 'scope': 'Explicit reviewed source scan only; no publication authority.',
            'require_secret_sources': True, 'required_stages': ['root_source_publication_acceptance_pending'],
            'artifacts': [{'id': 'file_%03d' % i, 'kind': 'sealed_file', 'sealed': True,
                           'source': str((REPO / r['path']).relative_to(W)), 'target': r['path'],
                           'anchor': {'path': Path(r['path']).name, 'sha256': r['sha256']},
                           'files': [{'path': Path(r['path']).name, 'bytes': r['bytes'], 'sha256': r['sha256']}]}
                          for i, r in enumerate(rows)]}


def run(args):
    need(args.execute_reviewed_scan, 'explicit_reviewed_execution_required')
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    need(sha(lexical(SCANNER).read_bytes()) == SCANNER_SHA, 'frozen_scanner_pin')
    spec = importlib.util.spec_from_file_location('unchanged_publication_scanner', SCANNER)
    scanner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(scanner)
    def pinned_json(path, pin):
        raw = scanner.stable_read(lexical(path))
        need(sha(raw) == pin, 'source_authority_pin')
        return json.loads(raw)
    filemap = pinned_json(FILEMAP, FILEMAP_SHA)['files']
    expected = {r['path']: r for r in filemap}
    need(len(expected) == len(filemap) == 101, 'filemap_count')
    source86 = pinned_json(ACCEPTANCE, ACCEPTANCE_SHA)['files']
    before = snapshot(scanner, expected, source86)
    output = lexical(args.output_dir)
    need(output.parent == HERE and not output.exists(), 'fresh_direct_child_output_required')
    need(1 <= len(args.secret_file) <= 16, 'explicit_secret_source_count')
    paths = [lexical(p) for p in args.secret_file]
    need(len(set(paths)) == len(paths), 'duplicate_secret_source_path')
    for p in paths:
        need(REPO not in p.parents and HERE not in p.parents, 'secret_source_outside_source_and_output')
        info = p.lstat()
        need(stat.S_ISREG(info.st_mode) and stat.S_IMODE(info.st_mode) == 0o600
             and info.st_uid == os.geteuid() == 1071 and 8 <= info.st_size <= 16384,
             'secret_source_type_owner_mode_size')
    output.mkdir(mode=0o700)
    secrets = []
    try:
        secrets = scanner.load_secrets(paths)  # Exact ROOT-supplied paths only; no discovery/hash/log/copy.
        try:
            scanner.validate(scan_spec(before['files']), W, secrets)
        except scanner.CheckError as exc:
            need(str(exc) == 'forbidden_target_path', 'unexpected_full_strict_refusal')
        else:
            raise Refusal('full_strict_path_rejection_missing')
        strict, _ = scanner.validate(scan_spec([r for r in before['files'] if r['path'] != '.env.example']), W, secrets)
        need(strict['safe_to_stage'] and len(strict['files']) == 100 and not strict['findings'], 'strict100_findings')
        content = []
        for row in before['files']:
            raw = scanner.stable_read(lexical(REPO / row['path']))
            need(sha(raw) == row['sha256'] and len(raw) == row['bytes'], 'content_input_changed')
            findings, notes = scanner.scan_bytes(raw, row['path'], secrets)
            content.append({'path': row['path'], 'findings': dict(findings), 'advisories': dict(notes)})
        need(not any(r['findings'] for r in content), 'full101_content_findings')
    finally:
        secrets.clear()  # Drop references; not a claim of physical memory zeroization.
        after = snapshot(scanner, expected, source86)
        need(before == after, 'source_tree_changed_during_scan')
        pinned_json(FILEMAP, FILEMAP_SHA)
        pinned_json(ACCEPTANCE, ACCEPTANCE_SHA)
        need(sha(SCANNER.read_bytes()) == SCANNER_SHA, 'scanner_changed_during_scan')
    refs = [write_new(output, 'strict_full101_expected_rejection.json',
                     {'strict_path_policy_pass': False, 'rule': 'forbidden_target_path',
                      'sole_path': '.env.example', 'sha256': TEMPLATE_SHA, 'bytes': 1936, 'git_mode': '100644'}),
            write_new(output, 'strict_remaining100.json', strict),
            write_new(output, 'full101_content_scan.json',
                      {'content_only': True, 'not_full_strict_pass': True, 'files_checked': 101,
                       'known_secret_sources_checked': len(paths), 'records': content})]
    receipt = {'schema_version': 'v5-exact-source-scan-receipt-v1', 'publication_authorized': False,
               'publication_performed': False, 'strict_full101_pass': False, 'strict100_pass': True,
               'full101_content_findings': 0, 'template_exception_requires_root_carry_forward_review': True,
               'known_secret_sources_checked': len(paths), 'secret_values_paths_or_hashes_emitted': False,
               'before_after_source_equal': True, 'source_snapshot': after, 'reports': refs,
               'scanner_sha256': SCANNER_SHA, 'wrapper_sha256': sha(Path(__file__).read_bytes()),
               'source86_acceptance_sha256': ACCEPTANCE_SHA, 'full101_filemap_sha256': FILEMAP_SHA,
               'scope_limit': 'Known-value/pattern checks only; manual privacy/license review remains.'}
    ref = write_new(output, 'SCAN_RECEIPT.json', receipt)  # Completion receipt last.
    fd = os.open(output, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
    print(json.dumps({'scan_complete': True, 'receipt_sha256': ref['sha256'],
                      'known_secret_sources_checked': len(paths), 'publication_performed': False}))


def main():
    class Parser(argparse.ArgumentParser):
        def error(self, message):
            raise Refusal('invalid_arguments')
    try:
        parser = Parser(description=__doc__)
        parser.add_argument('--execute-reviewed-scan', action='store_true')
        parser.add_argument('--output-dir', required=True, type=Path)
        parser.add_argument('--secret-file', required=True, action='append')
        run(parser.parse_args())
        return 0
    except (Exception, KeyboardInterrupt) as exc:
        print(json.dumps({'scan_complete': False, 'publication_performed': False,
                          'rule': str(exc) if isinstance(exc, Refusal) else 'source_scan_failed'}))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
