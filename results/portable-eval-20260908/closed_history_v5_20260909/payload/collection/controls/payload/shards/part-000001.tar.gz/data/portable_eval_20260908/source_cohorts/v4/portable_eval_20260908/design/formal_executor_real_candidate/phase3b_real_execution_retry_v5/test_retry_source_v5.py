"""N4 real source/FD/gate post-child accounting with inert retry byte transport."""
from pathlib import Path
import sys
from unittest import mock

import real_common as common
import real_authority as auth
import real_invocation as invocation
import real_journal as journal
import secret_fd
from test_real_execution import FixtureBase, KEY
import test_source_integration as source_fixture


class RetrySourceTests(FixtureBase):
    def test_pool_n4_recovered_disconnects_post_child_accounting_no_redraw(self):
        original_prepare = common.core().prepare_plan
        def prepare(candidate, digest, profiles, policy, *args, **kwargs):
            return original_prepare(candidate, digest, profiles, dict(policy, max_retries=2), *args, **kwargs)
        with mock.patch.object(common.core(), "prepare_plan", side_effect=prepare):
            study, epoch, anchors, chosen, instance, grant = source_fixture.SourceIntegration.make_case(self, "poolact", "restricted_search")
        original, launched = secret_fd.run_child, []
        def retry_child(command, cwd, env, log, *, secret):
            launched.append(list(command))
            argv = list(command)
            index = argv.index("--spec") + 1
            spec = common.read(argv[index])
            spec.update(cpu_fixture_boundary=True, cpu_fixture_retry_class="RemoteDisconnected")
            path = Path(argv[index]).with_name("cpu_retry_child_spec.json")
            common.write(path, spec)
            argv[index], argv[2] = str(path), str(common.HERE / "cpu_child_fixture.py")
            return original(argv, cwd, env, log, secret=secret)
        with mock.patch.object(auth, "validate_real_authority", return_value=grant), \
             mock.patch.object(auth, "verify_epoch"), mock.patch.object(secret_fd, "run_child", retry_child):
            report = invocation.execute_real_invocation(study, epoch, anchors, chosen["invocation_id"], instance, secret=KEY)
        common.write(self.folder / "CPU_ONLY_retry_source_v5.json", {
            "classification": "CPU synthetic byte transport / private mock grant; not real model or GO",
            "source_child_interpreter": epoch["commands"][0]["command"][0], "outer_test_interpreter": sys.executable,
            "model_calls": 0, "real_secrets_read": 0, "external_network_calls": 0,
            "child_launches": len(launched), "result": report})
        self.assertTrue(report["passed"], {k: v for k, v in report.items() if k in ("error_type", "raw", "owner_load_errors")})
        self.assertEqual(len(launched), 1)
        self.assertEqual(len(report["owners"]), 4)
        self.assertTrue(all(x["owner_evidence_qualified"] for x in report["owners"]))
        self.assertTrue(report["raw"]["raw_coverage"]["complete"])
        self.assertEqual(report["attempt_operations"]["issues"], [])
        self.assertEqual(report["attempt_operations"]["raw_attempts"], 12)
        self.assertEqual(report["attempt_operations"]["send_unknown"], 8)
        self.assertEqual(report["attempt_operations"]["http_response_bytes_returned"], 4)
        usage = report["accounting"]["totals_all_attempts"]["provider_usage"]
        for field, total in (("input_tokens", 40), ("output_tokens", 20)):
            self.assertEqual(usage[field]["known_sum"], total)
            self.assertEqual(usage[field]["unknown_attempts"], 8)
            self.assertIsNone(usage[field]["complete_total"])
        self.assertTrue(report["resume"]["executed"])
        self.assertEqual(report["resume"]["verified_skips"], 1)
        before = common.a3_module("support").safe_snapshot(self.root / chosen["dump_relative_dir"])
        with mock.patch.object(auth, "validate_real_authority", return_value=grant), \
             mock.patch.object(auth, "ensure_epoch_record"), \
             mock.patch.object(secret_fd, "run_child", side_effect=AssertionError("never regenerate begun invocation")):
            with self.assertRaises((auth.AuthorityError, journal.JournalError, FileExistsError)):
                invocation.execute_real_invocation(study, epoch, anchors, chosen["invocation_id"], instance, secret=KEY)
        self.assertEqual(before, common.a3_module("support").safe_snapshot(self.root / chosen["dump_relative_dir"]))
