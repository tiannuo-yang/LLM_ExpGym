import copy
from collections import Counter
import unittest
import planner as p


def data():
    labels = {k for system in ("expgym", "poolact") for item in p.items(system) for k in item["inputs"]}
    order = sorted(p.AUDIT_HYPOTHESES)
    return {"files": {k: {"path": "/synthetic/" + k, "sha256": "a"*64, "bytes": 1} for k in labels},
        "source_tree_sha256": "b"*64, "audit_orders": [order, list(reversed(order)), order[1:]+order[:1]]}


def matrix(models=1):
    return p.build_manifest("new-restart-synthetic", [{"label": "m%d" % i, "model_id": "model%d" % i} for i in range(models)],
        p.DEFAULT_REPEAT_POLICY, 20260908, 2200, data(), supersedes=["old-invalidated-study"])


class MatrixTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.m = matrix()

    def test_counts(self):
        self.assertEqual([self.m["counts"][k] for k in ("invocations", "logical_outcomes", "agent_traces")], [705,783,1881])
        self.assertEqual(self.m["expected_result_file_count"], 2613)

    def test_stages(self):
        self.assertEqual(Counter(j["outerrep"] for j in self.m["invocations"]), {0:615,1:45,2:45})
        self.assertTrue(all(j["scenario"] == "tuning" for j in self.m["invocations"] if j["outerrep"]))

    def test_two_models(self):
        m = matrix(2)
        self.assertEqual(m["counts"]["invocations"], 1410)
        self.assertEqual(m["counts"]["logical_outcomes"], 1566)
        self.assertEqual(m["counts"]["agent_traces"], 3762)

    def test_audit_nested_orders(self):
        exp = [j for j in self.m["invocations"] if j["system"] == "expgym" and j["scenario"] == "evidence_audit"]
        self.assertEqual(len(exp),39)
        self.assertTrue(all(len(j["logical_ids"]) == 3 for j in exp))
        self.assertTrue(all(j["selection_argv"][j["selection_argv"].index("--audit-reps")+1] == "3" for j in exp))

    def test_seed_outer_and_owners(self):
        for row in self.m["logical_rows"]:
            wanted = 2200+4*row["outerrep"]
            if row["system"] == "poolact":
                self.assertEqual(row["sampling_seed_labels"],list(range(wanted,wanted+4)))
            else:
                self.assertEqual(row["sampling_seed_labels"],[wanted+(row["order"] if type(row["order"]) is int else 0)])

    def test_no_old_completion_reuse(self):
        self.assertTrue(self.m["restart_from_scratch"])
        self.assertFalse(self.m["reuse_old_completion"])
        self.assertEqual(self.m["supersedes"],["old-invalidated-study"])

    def test_mixed_search_provenance(self):
        self.assertEqual({r["item_status"] for r in self.m["logical_rows"] if r["scenario"] == "restricted_search"},{"mixed_or_unknown"})

    def test_tamper_repeat_rejected(self):
        m=copy.deepcopy(self.m);m["repeat_policy"]["expgym"]["restricted_search"]=3
        with self.assertRaises(ValueError):p.validate(m)

    def test_tamper_argv_rejected(self):
        m=copy.deepcopy(self.m);m["invocations"][0]["selection_argv"] += ["--limit","1"]
        with self.assertRaises(ValueError):p.validate(m)

    def test_tamper_expected_rejected(self):
        m=copy.deepcopy(self.m);m["expected_files"].pop(next(iter(m["expected_files"])))
        with self.assertRaises(ValueError):p.validate(m)

    def test_bool_repeat_rejected(self):
        r=copy.deepcopy(p.DEFAULT_REPEAT_POLICY);r["expgym"]["tuning"]=True
        with self.assertRaises(ValueError):p.checked_repeats(r)

    def test_old_identity_not_restart(self):
        with self.assertRaises(ValueError):
            p.build_manifest("same",[{"label":"m","model_id":"m"}],p.DEFAULT_REPEAT_POLICY,1,1,data(),supersedes=["same"])


if __name__ == "__main__":unittest.main()
