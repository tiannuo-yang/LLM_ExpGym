"""Small real-path I/O adapter; frozen 3B/3A code is imported, never patched."""
import hashlib
import importlib
import json
import os
from pathlib import Path
import stat
import sys

HERE = Path(__file__).resolve().parent
CPU = HERE.parent / "phase3_dispatch_candidate/phase3b_cpu"
DELEGATE = HERE.parent / "phase3b_real_delegate_retry_v5"
CPU_RECEIPT = CPU / "validation/cpu_acceptance_v4_v1/receipt.json"
CPU_RECEIPT_SHA = "baada148f0261320b82364aea47a48f9dd9abf9c8c87704326ddbeb1a06a20c5"
DELEGATE_RECEIPT = DELEGATE / "validation/acceptance_retry_v5/receipt.json"
DELEGATE_RECEIPT_SHA = "c0e2507724755325950f3ea03a28262423b0780a1e27dd846c748cbbabbcd31a"
sys.path.insert(0, str(CPU))
frozen = importlib.import_module("common")
if Path(frozen.__file__).resolve() != CPU / "common.py":
    raise RuntimeError("wrong_frozen_common")
encoded, digest, a3_module = frozen.encoded, frozen.digest, frozen.a3_module
core, main_source, blocked, no_network = frozen.core, frozen.main_source, frozen.blocked, frozen.no_network


def cpu_module(name):
    value = importlib.import_module(name)
    if Path(value.__file__).resolve() != CPU / (name + ".py"):
        raise RuntimeError("wrong_frozen_module")
    return value


def scoped(path):
    path = Path(path)
    if not path.is_absolute() or ".." in path.parts or path != path.resolve() or len(path.parts) < 3:
        raise ValueError("absolute_nonalias_narrow_path_required")
    return path


def directory(path, create=False):
    path = scoped(path)
    fd = os.open(path.anchor, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for part in path.parts[1:]:
            if create:
                try:
                    os.mkdir(part, mode=0o700, dir_fd=fd)
                except FileExistsError:
                    pass
                else:
                    os.fsync(fd)
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = child
        return fd
    except BaseException:
        os.close(fd)
        raise


def read_bytes(path):
    path = scoped(path)
    parent = directory(path.parent)
    try:
        fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
        try:
            before = os.fstat(fd)
            if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
                raise ValueError("single_link_regular_evidence_required")
            chunks = []
            while True:
                chunk = os.read(fd, 1024 * 1024)
                if not chunk:
                    break
                chunks.append(chunk)
            after = os.fstat(fd)
            if (before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (after.st_size, after.st_mtime_ns, after.st_ctime_ns):
                raise ValueError("evidence_changed_during_read")
            return b"".join(chunks)
        finally:
            os.close(fd)
    finally:
        os.close(parent)


def sha(path):
    return hashlib.sha256(read_bytes(path)).hexdigest()


def read(path):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("duplicate_json_key")
            result[key] = value
        return result
    return json.loads(read_bytes(path).decode("utf-8"), object_pairs_hook=pairs,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError("nonfinite_json")))


def write(path, value):
    path = scoped(path)
    parent = directory(path.parent, create=True)
    try:
        fd = os.open(path.name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=parent)
        try:
            view = memoryview(encoded(value) + b"\n")
            while view:
                count = os.write(fd, view)
                if count <= 0:
                    raise OSError("short_evidence_write")
                view = view[count:]
            os.fsync(fd)
        finally:
            os.close(fd)
        os.fsync(parent)
    finally:
        os.close(parent)


def identity():
    return {label: {p.name: sha(p) for p in sorted(root.iterdir())
        if p.is_file() and p.suffix in (".py", ".md", ".json")}
        for label, root in (("real_execution", HERE), ("frozen_3b", CPU), ("delegate", DELEGATE))}


def verify():
    result = frozen.verify()
    if sha(CPU_RECEIPT) != CPU_RECEIPT_SHA or sha(DELEGATE_RECEIPT) != DELEGATE_RECEIPT_SHA:
        raise ValueError("frozen_3B_or_delegate_CPU_acceptance_changed")
    cpu, delegate = read(CPU_RECEIPT), read(DELEGATE_RECEIPT)
    actual = identity()
    if cpu.get("passed") is not True or cpu.get("code_identity") != actual["frozen_3b"] or delegate.get("passed") is not True:
        raise ValueError("frozen_dependency_CPU_acceptance_or_source_changed")
    if {name: value["sha256"] for name, value in delegate["top_level_identity"].items()} != actual["delegate"]:
        raise ValueError("frozen_v2_delegate_source_changed")
    return dict(result, cpu_3b_receipt_sha256=CPU_RECEIPT_SHA, delegate_v2_receipt_sha256=DELEGATE_RECEIPT_SHA)


def import_delegate():
    sys.path.insert(0, str(DELEGATE))
    module = importlib.import_module("urllib_delegate")
    if Path(module.__file__).resolve() != DELEGATE / "urllib_delegate.py":
        raise RuntimeError("wrong_delegate_module")
    return module
