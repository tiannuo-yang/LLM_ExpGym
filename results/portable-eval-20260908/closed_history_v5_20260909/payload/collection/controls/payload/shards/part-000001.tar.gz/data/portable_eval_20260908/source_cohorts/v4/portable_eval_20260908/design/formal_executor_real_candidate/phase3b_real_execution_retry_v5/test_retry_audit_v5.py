"""True frozen-client byte fixtures; never a real HTTP/model call."""
import ast
import copy
import hashlib
import http.client
from io import BytesIO
import json
import os
from pathlib import Path
import ssl
from unittest import mock
import urllib.error

import real_common as common
import raw_audit_retry as raw
import raw_scope_retry as scope
import retry_policy
from test_real_execution import FixtureBase, KEY

PROFILE = {"model": "fixture/retry-audit", "temperature": 1.0, "top_p": 1.0,
           "top_k": -1, "reasoning_effort": "max", "chat_template_kwargs": {"thinking": True}}
POLICY = {"max_tokens": 32768, "max_retries": 2}
URL = "http://127.0.0.1:1/v1"
TOOLS = [{"type": "function", "function": {"name": "lookup", "parameters": {"type": "object"}}}]


class RetryAuditTests(FixtureBase):
    def fixture(self, kind="RemoteDisconnected", code=None):
        clients = common.a3_module("support").bridge.module("expgym.llm_clients")
        self.dumps = self.folder / "dumps"
        count = [0]
        response = {"choices": [{"message": {"role": "assistant", "content": "Answer: CPU",
                     "reasoning_content": "synthetic reasoning"}, "finish_reason": "stop"}],
                    "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15}}
        def transport(request, timeout):
            count[0] += 1
            if count[0] < 3:
                if kind == "HTTPError":
                    raise urllib.error.HTTPError(request.full_url, code, "CPU", {}, BytesIO(b'{}'))
                if kind == "ContentTooShortError":
                    raise urllib.error.ContentTooShortError("CPU", b"")
                cls = {"RemoteDisconnected": http.client.RemoteDisconnected,
                       "URLError": urllib.error.URLError}[kind]
                raise cls("CPU retry fixture")
            return json.dumps(response).encode()
        context = {"runner": "expgym", "logical_id": "cpu-owner"}
        messages = [{"role": "user", "content": "synthetic request"}]
        with mock.patch.dict(os.environ, {"EXPGYM_API_DUMP_DIR": str(self.dumps), "EXPGYM_RUN_ID": "CPU-retry-v5"}):
            client = clients.OpenAICompatibleLLM(api_key=KEY, base_url=URL, transport=transport,
                seed=31, max_tokens=32768, max_retries=2, retry_base_seconds=0, retry_max_seconds=0,
                dump_context=context, **PROFILE)
            output = client.generate(messages, tools=TOOLS, tool_choice="auto")
        self.assertEqual(count[0], 3)
        self.owner = {"owner_id": "cpu-owner", "logical_id": "cpu-owner", "client_id": client.dump_metadata["client_id"],
            "run_id": "CPU-retry-v5", "seed": 31, "schemas": TOOLS, "context": context,
            "calls": [{"call_index": 1, "attempts": output.attempt_usage, "messages": messages,
                "output_message": output.assistant_message, "finish_reason": output.finish_reason,
                "forced": False, "request_attempts": output.request_attempts}],
            "history": messages + [output.assistant_message], "api_calls": 1, "http_request_attempts": 3,
            "delivered_counters": {"input_tokens": 10, "output_tokens": 5, "cache_read_tokens": 0}}
        return output

    def audit(self, module=raw):
        return module.audit_owners([self.owner], self.dumps, expected_owner_ids=["cpu-owner"],
            profile=PROFILE, policy=POLICY, endpoint=URL, run_id="CPU-retry-v5", secret=KEY)

    def change_first(self, **changes):
        entry = self.owner["calls"][0]["attempts"][0]
        path = self.dumps / (entry["request_id"] + ".json")
        value = json.loads(path.read_text())
        value.update(changes)
        for name in ("http_status", "state"):
            if name in changes:
                entry[name] = changes[name]
        path.write_text(json.dumps(value))

    def rejected(self):
        result = self.audit()
        self.assertFalse(result["passed"])
        self.assertIn("nontransport_failure_retried", [item["rule"] for item in result["errors"]])

    def test_original_remote_chain_red_new_green_unknown_cost_not_zero(self):
        self.fixture()
        old = common.a3_module("support").raw
        self.assertFalse(self.audit(old)["passed"])
        report = self.audit()
        self.assertTrue(report["passed"], report["errors"])
        self.assertEqual(report["totals_all_attempts"]["http_attempts"], 3)
        for key, expected in (("input_tokens", 10), ("output_tokens", 5)):
            usage = report["totals_all_attempts"]["provider_usage"][key]
            self.assertEqual(usage["known_sum"], expected)
            self.assertEqual(usage["unknown_attempts"], 2)
            self.assertIsNone(usage["complete_total"])
        report = scope.audit_partial([self.owner], self.dumps, planned_owners=[self.owner],
            profile=PROFILE, policy=POLICY, endpoint=URL, run_id="CPU-retry-v5", secret=KEY)
        self.assertTrue(report["passed"], report["errors"])
        self.assertTrue(report["owner_qualification"][0]["eligible"])
        self.assertIsNone(report["totals_all_attempts"]["provider_usage"]["input_tokens"]["complete_total"])

    def test_content_too_short_original_client_chain(self):
        self.fixture("ContentTooShortError")
        self.assertFalse(self.audit(common.a3_module("support").raw)["passed"])
        self.assertTrue(self.audit()["passed"])

    def test_original_503_retry_unchanged(self):
        self.fixture("HTTPError", 503)
        self.assertTrue(self.audit(common.a3_module("support").raw)["passed"])
        self.assertTrue(self.audit()["passed"])

    def test_urlerror_impossible_http_status_old_false_positive_closed(self):
        self.fixture("URLError")
        self.change_first(http_status=503)
        self.assertTrue(self.audit(common.a3_module("support").raw)["passed"])
        self.rejected()

    def test_http400_cannot_be_reclassified_as_connection_retry(self):
        self.fixture("HTTPError", 503)
        self.change_first(http_status=400)
        self.rejected()

    def test_unknown_ssl_not_accepted_from_declared_mro(self):
        self.fixture()
        self.change_first(error={"type": "SSLError", "mro": ["ConnectionError"]})
        self.rejected()

    def test_unknown_custom_subclass_name_not_inferred(self):
        self.fixture()
        self.change_first(error={"type": "CustomURLError", "mro": ["URLError"]})
        self.rejected()

    def test_delay_domain_does_not_relax_original_state_chain(self):
        self.fixture()
        for delay in (True, -1, 31, float("inf")):
            self.change_first(retry_delay_seconds=delay)
            self.rejected()

    def test_success_never_becomes_transport_retry(self):
        self.fixture()
        self.change_first(state="success")
        report = self.audit()
        self.assertFalse(report["passed"])
        self.assertIn("invalid_retry_state_chain", [item["rule"] for item in report["errors"]])

    def test_terminal_abort_stays_failed_and_cost_retained(self):
        self.fixture()
        entry = self.owner["calls"][0]["attempts"][-1]
        path = self.dumps / (entry["request_id"] + ".json")
        value = json.loads(path.read_text())
        value["response_json"]["choices"][0]["finish_reason"] = "abort"
        value.update(state="error", error={"type": "APICompletionAbortedError"},
                     response_raw=json.dumps(value["response_json"]))
        entry["state"] = "error"
        path.write_text(json.dumps(value))
        report = self.audit()
        self.assertFalse(report["passed"])
        self.assertEqual(report["totals_all_attempts"]["provider_usage"]["output_tokens"]["known_sum"], 5)

    def test_policy_exact_byte_copy_and_only_scope_function_body_unchanged(self):
        self.assertEqual(common.sha(common.HERE / "retry_policy.py"),
            "f8556e75d9a625f877f3f44611c0c7ac0d043c9cae6e53bfd3d655553cf7ad78")
        old = Path(scope._frozen.__file__).read_text().split("\ndef audit_partial", 1)[1]
        new = Path(scope.__file__).read_text().split("\ndef audit_partial", 1)[1]
        self.assertEqual(old, new)
        self.assertIs(scope.full_catalog, scope._frozen.full_catalog)
        self.assertIs(scope.safe_usage_totals, scope._frozen.safe_usage_totals)
        self.assertIsNot(scope.raw, scope._frozen.raw)
        self.assertEqual(Path(scope._frozen.raw.__file__), common.HERE.parent / "raw_audit.py")

    def test_pinned_actual_client_catch_order_and_stdlib_mro(self):
        source = common.main_source() / "expgym/llm_clients.py"
        self.assertEqual(common.sha(source), "5823e7bc9be71af40f47c307e079f820bbe4d808dc03e66deeea416677500ebb")
        self.assertTrue(issubclass(http.client.RemoteDisconnected, ConnectionError))
        self.assertTrue(issubclass(urllib.error.ContentTooShortError, urllib.error.URLError))
        self.assertTrue(issubclass(urllib.error.HTTPError, urllib.error.URLError))
        self.assertFalse(issubclass(ssl.SSLError, (urllib.error.URLError, TimeoutError, ConnectionError)))
        handlers = []
        def name(node):
            if isinstance(node, ast.Name): return node.id
            if isinstance(node, ast.Attribute): return name(node.value) + "." + node.attr
            if isinstance(node, ast.Tuple): return tuple(name(x) for x in node.elts)
        for node in ast.walk(ast.parse(source.read_text())):
            if isinstance(node, ast.Try):
                names = [name(h.type) for h in node.handlers]
                if names[:1] == ["urllib.error.HTTPError"]:
                    handlers.append(names[:3])
        self.assertEqual(handlers, [["urllib.error.HTTPError", ("urllib.error.URLError", "TimeoutError", "ConnectionError"), "Exception"]])
