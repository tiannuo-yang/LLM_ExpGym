"""Record a ROOT-selected, single launch; never launch or renew an allocation."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "planner_candidate_v1"))
import launcher
import support as s


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--plan", required=True)
    p.add_argument("--plan-sha256", required=True)
    p.add_argument("--smoke-acceptance")
    p.add_argument("--smoke-acceptance-sha256")
    args = p.parse_args()
    owner_ref = {"path": str(HERE / "planner_candidate_v1/owner_cpu_freeze_v1/receipt.json"),
                 "sha256": "fe5c76b162ce5089049b2bb3c40bba5d2d98a7b42b4577808d36471d665010aa"}
    owner = s.io.read_json_ref(owner_ref)
    assert owner["passed"] is True
    for item in list(owner["source_files"].values()) + owner["helper_closure"]:
        s.io.read_ref({k: item[k] for k in ("path", "sha256")})
    plan_ref = {"path": args.plan, "sha256": args.plan_sha256}
    plan = s.io.read_json_ref(plan_ref)
    launcher.verify_plan(plan)
    config = plan["config"]
    assert config["source_acceptance_ref"]["sha256"] == "0b1166cb5549ceb606bd98086809548cb0d83c3e94070e3570cc4783e1b1a744"
    assert not Path(config["output_root"]).exists()
    acceptance = None
    if plan["mode"] == "formal_mixed":
        assert args.smoke_acceptance and args.smoke_acceptance_sha256
        acceptance = {"path": args.smoke_acceptance, "sha256": args.smoke_acceptance_sha256}
        smoke = s.io.read_json_ref(acceptance)
        assert smoke["passed"] is True and smoke["model_id"] == config["model"]["model_id"]
        assert smoke["source_acceptance_ref"] == config["source_acceptance_ref"]
    else:
        assert plan["mode"] == "selected_smoke"
    job_id = {"glm-5.3": "1203652", "kimi-k3": "1203653"}[config["model"]["model_id"]]
    cmd = ["squeue", "-h", "-j", job_id, "-o", "%i|%T|%S|%e|%D|%b"]
    observed = subprocess.check_output(cmd, text=True).strip()
    parts = observed.split("|")
    assert len(parts) == 6 and parts[:2] == [job_id, "RUNNING"]
    assert parts[4:] == ["8", "gres/gpu:8"]
    def epoch(value):
        return datetime.datetime.fromisoformat(value).replace(tzinfo=datetime.timezone.utc).timestamp()
    allocation_start, allocation_end = epoch(parts[2]), epoch(parts[3])
    now = time.time()
    deadline = min(now + (10800 if plan["mode"] == "selected_smoke" else 93600), allocation_end)
    go = dict(schema_version="restart-root-launch-go-v1", action="execute_once", plan_ref=plan_ref,
        run_id=config["run_id"], model_id=config["model"]["model_id"], mode=plan["mode"],
        output_root=config["output_root"], invocation_ids=[j["invocation_id"] for j in plan["jobs"]],
        deployment_ref=config["deployment_ref"], policy_sha256=s.digest(config["policy"]),
        not_before_unix=now, latest_start_unix=now+600, deadline_unix=deadline,
        allocation_start_unix=allocation_start, allocation_deadline_unix=allocation_end,
        gpu_seconds_cap=(deadline-allocation_start)*64, gpu_count=64, allocation_id=job_id,
        root_basis="User requested both models completely rerun with the changed repetition and terminal policy; no new allocation or expanded model scope.",
        owner_cpu_acceptance_ref=owner_ref, source_acceptance_ref=config["source_acceptance_ref"],
        smoke_acceptance_ref=acceptance, allocation_observation=dict(argv=cmd, stdout=observed, utc=launcher.utc()),
        acceptance_scope="Execution authorization only; no performance claim and no permission to resample model terminal outcomes.")
    launcher.Authority(plan, plan_ref, go).check(plan["jobs"][0]["invocation_id"], starting=True)
    print(json.dumps(s.put(Path(args.plan).parent, "ROOT_GO.json", go), sort_keys=True))


if __name__ == "__main__":
    main()
