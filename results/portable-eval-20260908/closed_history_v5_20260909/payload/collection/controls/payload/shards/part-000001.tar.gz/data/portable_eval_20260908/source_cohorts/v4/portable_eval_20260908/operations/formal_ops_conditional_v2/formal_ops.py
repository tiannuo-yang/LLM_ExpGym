"""Thin pinned I/O for frozen formal compilers, journal and dispatcher."""
import argparse
import hashlib
import importlib
import os
from pathlib import Path
import sys
import time

import common_io as io
import conditional_preflight as conditional

HERE = Path(__file__).absolute().parent
STUDY = HERE.parent.parent
REAL = STUDY / "design/formal_executor_real_candidate/phase3b_real_execution_retry_v5"
ROOT_ACCEPTANCE = {"path": str(STUDY / "validation/real_execution_root_acceptance_retry_v5.json"),
    "sha256": "51e778b3a4f78e2e721a23a7a2f6634553ceb655a5826ecc46e06d777cd11e5d"}
SOURCE_IDENTITY = "93ca632ec6ab819fe88645d9de263b810e8d7ef8affe5d712f1d1f894e4493b2"
PROXY_KEYS = ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "http_proxy", "https_proxy", "all_proxy")


def exact(value, keys, rule):
    if type(value) is not dict or set(value) != set(keys):
        raise ValueError(rule)
    return value


def frozen_modules():
    """Read accepted explicit code map before importing executable bytes.

    This engineering receipt is NOT the separate definition-bound acceptance,
    registration or GO; validate_real_authority still requires all six anchors.
    """
    accepted = io.read_json_ref(ROOT_ACCEPTANCE)
    identities = accepted["code_identity"]
    if hashlib.sha256(io.canonical(identities)).hexdigest() != SOURCE_IDENTITY:
        raise ValueError("accepted_source_identity_mismatch")
    roots = {"real_execution": REAL, "frozen_3b": REAL.parent / "phase3_dispatch_candidate/phase3b_cpu",
             "delegate": REAL.parent / "phase3b_real_delegate_retry_v5"}
    exact(identities, roots, "complete_three_scope_implementation_required")
    for group, files in identities.items():
        for name, expected in files.items():
            if Path(name).name != name:
                raise ValueError("code_basename_required")
            io.read_ref({"path": str(roots[group] / name), "sha256": expected})
    sys.path.insert(0, str(REAL))
    modules = {}
    for name in ("real_common", "real_authority", "real_journal", "real_dispatch", "secret_fd"):
        module = importlib.import_module(name)
        if Path(module.__file__).absolute() != REAL / (name + ".py"):
            raise ValueError("wrong_frozen_import_scope")
        modules[name] = module
    if modules["real_common"].identity() != identities:
        raise ValueError("complete_frozen_file_set_changed")
    return modules


def check_order(candidate, order):
    if (type(order) is not list or not order or len(order) != len(set(order))
            or [row["model_id"] for row in candidate["models"]] != order):
        raise ValueError("explicit_candidate_model_input_order_mismatch")


def define(inputs, modules):
    exact(inputs, ("candidate", "profiles", "policy", "targets", "operations", "study_id",
                   "output_root", "whole_study", "model_order"), "exact_definition_inputs_required")
    candidate = io.read_json_ref(inputs["candidate"])
    check_order(candidate, inputs["model_order"])
    profiles = {}
    for model, ref in inputs["profiles"].items():
        io.read_ref(ref)
        profiles[model] = ref["path"]
    io.lexical(inputs["output_root"])
    authority = modules["real_authority"]
    draft = authority.frozen.prepare_study(inputs["candidate"]["path"], inputs["candidate"]["sha256"],
        profiles, inputs["policy"], inputs["targets"], inputs["operations"],
        study_id=inputs["study_id"], output_root=inputs["output_root"], kind="formal_draft")
    return authority.define_real(draft, inputs["whole_study"])


def epoch(inputs, modules):
    exact(inputs, ("definition", "model", "epoch_id", "previous", "identity", "evidence",
                   "prior_inventory_sha256", "protocol_admission"), "exact_epoch_inputs_required")
    conditional.check(inputs, mode="epoch", io=io)
    study = io.read_json_ref(inputs["definition"])
    previous = io.read_json_ref(inputs["previous"]) if inputs["previous"] is not None else None
    for ref in inputs["evidence"].values():
        io.read_ref(ref)
    return modules["real_authority"].compile_epoch(study, model=inputs["model"], epoch_id=inputs["epoch_id"],
        previous=previous, identity=inputs["identity"], evidence=inputs["evidence"],
        prior_inventory_sha256=inputs["prior_inventory_sha256"])


def journal_for(study, modules, *, create=False, capability=None):
    candidate = study["validated_plan_view"]["candidate"]
    return modules["real_journal"].Journal(study["output_root"], modules["real_common"].digest(study),
        candidate["invocations"], candidate["logical_rows"], create=create, capability=capability)


def next_stage(study, started, blocked, current_model):
    for stage in study["validated_plan_view"]["stages"]:
        pending = [iid for iid in stage["invocation_ids"] if iid not in started and iid not in blocked]
        if pending:
            if stage["model"] != current_model:
                raise ValueError("current_model_is_not_next_never_started_stage")
            return pending
    raise ValueError("no_eligible_never_started_stage")


def read_run_secret(path, secret_module):
    """Run-only, after authority/scope admission; no hash or serialization."""
    secret = io.read_regular(path, max_bytes=2050).decode("ascii").strip()
    return secret_module.validate_secret(secret)


def reject_secret_refs(value, key_path):
    if isinstance(value, dict):
        if value.get("path") == key_path:
            raise ValueError("secret_cannot_be_an_evidence_reference")
        for child in value.values():
            reject_secret_refs(child, key_path)
    elif isinstance(value, list):
        for child in value:
            reject_secret_refs(child, key_path)


def run(inputs, modules, output, *, execute_real):
    if execute_real is not True:
        raise ValueError("explicit_execute_real_required")
    exact(inputs, ("definition", "model_order", "current_model", "epoch", "previous", "anchors",
                   "prefix", "journal_mode", "initial_started", "quiescence", "key_file", "protocol_admission"),
          "exact_single_live_model_run_inputs_required")
    conditional.check(inputs, mode="run", io=io)
    if inputs["journal_mode"] not in ("create", "continue"):
        raise ValueError("explicit_create_or_continuation_required")
    if type(inputs["initial_started"]) is not list or len(set(inputs["initial_started"])) != len(inputs["initial_started"]):
        raise ValueError("explicit_unique_prior_started_scope_required")
    io.check_secret_metadata(inputs["key_file"])
    reject_secret_refs(inputs, inputs["key_file"])
    study = io.read_json_ref(inputs["definition"])
    reject_secret_refs(study, inputs["key_file"])
    check_order(study["validated_plan_view"]["candidate"], inputs["model_order"])
    current = io.read_json_ref(inputs["epoch"])
    reject_secret_refs(current, inputs["key_file"])
    previous = io.read_json_ref(inputs["previous"]) if inputs["previous"] is not None else None
    if (inputs["anchors"].get("definition") != inputs["definition"]
            or inputs["anchors"].get("epoch") != inputs["epoch"]
            or current["model"] != inputs["current_model"]):
        raise ValueError("exact_current_definition_epoch_and_model_binding_required")
    for ref in inputs["anchors"].values():
        reject_secret_refs(io.read_json_ref(ref), inputs["key_file"])
    authority, jmodule = modules["real_authority"], modules["real_journal"]
    grant = authority.validate_real_authority(study, current, inputs["anchors"], previous)
    # No key read, journal write or model call precedes this exact scope check.
    create = inputs["journal_mode"] == "create"
    journal = None
    if create:
        if inputs["initial_started"] or inputs["quiescence"] is not None:
            raise ValueError("initial_run_has_no_prior_or_quiescence")
        pending = next_stage(study, set(), set(), current["model"])
    else:
        journal = journal_for(study, modules)
        try:
            before = journal.reconcile()
            if not before["valid"]:
                raise ValueError("invalid_prior_journal")
            started = {row["invocation_id"] for row in before["invocations"] if row["started"]}
            if started != set(inputs["initial_started"]):
                raise ValueError("externally_bound_prior_started_scope_changed")
            blocked = set(jmodule.eligible_inventory(journal)["reserved_without_start"])
            pending = next_stage(study, started, blocked, current["model"])
        except BaseException:
            journal.close()
            raise
    secret = None
    try:
        if any(iid not in grant.scope for iid in pending):
            raise ValueError("GO_must_bind_complete_pending_stage_scope")
        if create:
            if Path(study["output_root"]).exists():
                raise ValueError("create_requires_nonexistent_formal_namespace")
        else:
            quiescence = io.read_json_ref(inputs["quiescence"])
            permit = jmodule.real_continuation_permit(grant, journal, quiescence)
        # Invalid credential contents must not strand a fresh namespace without
        # an epoch. All grant/scope/readonly-continuation checks precede this.
        secret = read_run_secret(inputs["key_file"], modules["secret_fd"])
        if create:
            journal = journal_for(study, modules, create=True, capability=jmodule.real_root_capability(grant))
        else:
            journal.authorize_never_started(permit, quiescence, grant.go["invocation_ids"])
        # Proxy state is intentionally cleared only inside this explicit mode.
        for key in PROXY_KEYS:
            os.environ.pop(key, None)
        os.environ["NO_PROXY"] = os.environ["no_proxy"] = "*"
        io.write_new(output, "operator_start.json", io.canonical({"schema_version": "formal-ops-start-v1",
            "pid": os.getpid(), "started_unix": time.time(), "current_model": current["model"],
            "definition": inputs["definition"], "epoch": inputs["epoch"], "anchors": inputs["anchors"],
            "prefix": inputs["prefix"], "journal_mode": inputs["journal_mode"], "key_file": inputs["key_file"]}))
        try:
            # One live epoch only. Unbound later model remains pending by design.
            return modules["real_dispatch"].dispatch_real(study, journal,
                {current["model"]: (current, inputs["anchors"], previous)},
                secrets={current["model"]: secret}, prefix=inputs["prefix"],
                initial_started=inputs["initial_started"])
        finally:
            secret = None
    except KeyboardInterrupt:
        # Frozen executor's context has already joined submitted workers. This
        # is not proof of provider drain and not a normal dispatch receipt.
        return {"schema_version": "formal-ops-interrupted-v1", "passed": False,
                "operator_interrupted": True, "provider_quiescence_proven": False,
                "journal": journal.reconcile() if journal is not None else None}
    finally:
        secret = None
        if journal is not None:
            journal.close()


def reconcile(inputs, modules):
    exact(inputs, ("definition",), "exact_reconcile_definition_ref_required")
    study = io.read_json_ref(inputs["definition"])
    modules["real_authority"].verify_study(study)
    journal = journal_for(study, modules)
    try:
        return {"schema_version": "formal-ops-readonly-inventory-v1", "real_authorized": False,
                "reconciliation": journal.reconcile(), "inventory": journal.snapshot_inventory(),
                "eligibility": modules["real_journal"].eligible_inventory(journal)}
    finally:
        journal.close()


def execute(mode, spec_ref, output_dir, *, execute_real=False):
    if mode not in ("define", "epoch", "run", "reconcile"):
        raise ValueError("unknown_explicit_mode")
    if (mode == "run") != bool(execute_real):
        raise ValueError("execute_real_is_required_only_for_run")
    spec = io.read_json_ref(spec_ref)
    exact(spec, ("schema_version", "mode", "inputs"), "exact_formal_ops_spec_required")
    if spec["schema_version"] != "formal-ops-conditional-input-v1" or spec["mode"] != mode:
        raise ValueError("formal_ops_spec_mode_mismatch")
    if mode in ("epoch", "run"):
        conditional.check(spec["inputs"], mode=mode, io=io)
    if mode == "run":
        io.check_secret_metadata(spec["inputs"]["key_file"])
        reject_secret_refs(spec, spec["inputs"]["key_file"])
    registered_root = (spec["inputs"]["output_root"] if mode == "define" else
                       io.read_json_ref(spec["inputs"]["definition"])["output_root"])
    output_path, run_path = io.lexical(output_dir), io.lexical(registered_root)
    if output_path == run_path or output_path in run_path.parents or run_path in output_path.parents:
        raise ValueError("adapter_output_must_be_separate_from_registered_run")
    modules = frozen_modules()
    # Adapter artifacts are outside the registered run root and never overwrite.
    output = io.new_directory(output_dir)
    io.write_new(output, "input_binding.json", io.canonical({"spec": spec_ref, "mode": mode,
        "source_acceptance": ROOT_ACCEPTANCE, "source_identity": SOURCE_IDENTITY,
        "adapter_issued_authority": False}))
    try:
        if mode == "run":
            result = run(spec["inputs"], modules, output, execute_real=execute_real)
        else:
            result = {"define": define, "epoch": epoch, "reconcile": reconcile}[mode](spec["inputs"], modules)
    except BaseException as exc:
        io.write_new(output, "operator_failure.json", io.canonical({"schema_version": "formal-ops-failure-v1",
            "mode": mode, "error_type": type(exc).__name__, "normal_dispatch_receipt": False,
            "automatic_retry": False}))
        raise
    ref = io.write_new(output, mode + ".json", io.canonical(result))
    return {"output": ref, "mode": mode, "passed": result.get("passed"), "adapter_issued_authority": False}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("define", "epoch", "run", "reconcile"))
    parser.add_argument("--spec", required=True)
    parser.add_argument("--spec-sha256", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--execute-real", action="store_true")
    args = parser.parse_args(argv)
    try:
        result = execute(args.mode, {"path": args.spec, "sha256": args.spec_sha256},
                         args.output_dir, execute_real=args.execute_real)
    except BaseException as exc:
        # Never print exception messages, request bodies, credentials or reprs.
        print(io.canonical({"passed": False, "error_type": type(exc).__name__}).decode())
        return 130 if isinstance(exc, KeyboardInterrupt) else 2
    print(io.canonical(result).decode())
    return 2 if result["passed"] is False else 0


if __name__ == "__main__":
    raise SystemExit(main())
