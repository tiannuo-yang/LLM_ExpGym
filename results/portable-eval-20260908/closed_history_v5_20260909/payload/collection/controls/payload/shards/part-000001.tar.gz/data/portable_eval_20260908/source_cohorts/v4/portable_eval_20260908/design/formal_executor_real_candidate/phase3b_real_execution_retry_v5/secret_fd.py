"""Short in-memory bearer secret over an inherited anonymous pipe, never a file."""
import os
import stat
import subprocess
import time
from pathlib import Path

import real_common as common


class ChildCaptureError(RuntimeError):
    """Sanitized process facts, never exception text, stdout, or credentials."""
    def __init__(self, process_receipt):
        self.process_receipt = dict(process_receipt)
        super().__init__("child_capture_failed_" + process_receipt["error_type"])


def validate_secret(secret):
    if (not isinstance(secret, str) or not secret or len(secret.encode("utf-8")) > 2048
            or not secret.isascii() or any(ord(c) < 33 or ord(c) > 126 for c in secret)):
        raise ValueError("nonempty_bounded_ASCII_bearer_secret_required")
    return secret


def read_secret_fd(fd):
    if type(fd) is not int or fd < 3:
        raise ValueError("anonymous_inherited_fd_required")
    try:
        if not stat.S_ISFIFO(os.fstat(fd).st_mode):
            raise ValueError("secret_must_arrive_via_anonymous_pipe")
        # Named FIFOs are not accepted even if they have identical mode bits.
        if not os.readlink("/proc/self/fd/%d" % fd).startswith("pipe:["):
            raise ValueError("named_secret_FIFO_not_allowed")
        value = os.read(fd, 2049)
        if os.read(fd, 1) or len(value) > 2048:
            raise ValueError("oversized_secret")
        return validate_secret(value.decode("ascii"))
    finally:
        os.close(fd)


def run_child(command, cwd, env, log, *, secret):
    validate_secret(secret)
    # Neither the real key nor any substring-derived/hash identifier is recorded.
    if any(secret in str(x) for x in list(command) + list(env.keys()) + list(env.values())):
        raise ValueError("secret_in_argv_or_environment_forbidden")
    read_fd = write_fd = fd = None
    process, target = None, None
    started = time.monotonic()
    stdout_eof, waited = False, False
    error = None
    try:
        read_fd, write_fd = os.pipe()
        data = secret.encode("ascii")
        if os.write(write_fd, data) != len(data):
            raise OSError("short_secret_pipe_write")
        os.close(write_fd)
        write_fd = None
        target = common.scoped(log)
        parent = common.directory(target.parent, create=True)
        try:
            fd = os.open(target.name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=parent)
        finally:
            os.close(parent)
        try:
            process = subprocess.Popen(list(command) + ["--secret-fd", str(read_fd)], cwd=cwd, env=env,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, pass_fds=(read_fd,))
            # Redact before log persistence, retaining a boundary suffix so a
            # secret split across stdout chunks cannot leak. No secret digest.
            pending = b""
            sensitive_output = False
            while True:
                chunk = process.stdout.read(65536)
                pending += chunk
                if data in pending:
                    sensitive_output = True
                    pending = pending.replace(data, b"[REDACTED]")
                length = len(pending) if not chunk else max(0, len(pending) - len(data) + 1)
                view = memoryview(pending[:length])
                while view:
                    count = os.write(fd, view)
                    if count <= 0:
                        raise OSError("short_child_log_write")
                    view = view[count:]
                pending = pending[length:]
                if not chunk:
                    stdout_eof = True
                    break
            process.stdout.close()
            process.wait()
            waited = True
            os.fsync(fd)
        except BaseException:
            # A parent log failure must not return a supposedly drained worker
            # while leaving its original bounded child running in background.
            if process is not None:
                try:
                    if not process.stdout.closed:
                        while process.stdout.read(65536):
                            pass
                        stdout_eof = True
                except BaseException:
                    pass
                finally:
                    try:
                        process.stdout.close()
                    finally:
                        process.wait()
                        waited = True
            raise
        finally:
            os.close(fd)
            fd = None
        body = common.read_bytes(target)
        if sensitive_output or data in body:
            raise RuntimeError("sensitive_child_output_redacted_stop_new")
        receipt = {"exit_code": process.returncode, "elapsed_seconds": time.monotonic() - started,
            "log": str(target), "sha256": common.sha(target), "capture_complete": True,
            "child_started": True, "stdout_eof_observed": stdout_eof, "wait_returned": waited,
            "drain_proven": stdout_eof and waited,
            "drain_scope": "Direct child exit and stdout EOF only; not service or provider inflight"}
        return receipt, body.decode(errors="replace")
    except BaseException as exc:
        error = {"exit_code": process.returncode if process is not None and waited else None,
            "elapsed_seconds": time.monotonic() - started, "log": str(target) if target is not None else None,
            "capture_complete": False, "error_type": type(exc).__name__,
            "child_started": process is not None, "stdout_eof_observed": stdout_eof,
            "wait_returned": waited, "drain_proven": stdout_eof and waited,
            "drain_scope": "Direct child exit and stdout EOF only; not service or provider inflight"}
        # A partial/redacted log can be retained even if fsync or final read
        # failed. The hash is observational, not proof of durable capture.
        if target is not None:
            try:
                error["sha256"] = common.sha(target)
            except Exception as log_error:
                error["log_identity_error_type"] = type(log_error).__name__
        raise ChildCaptureError(error) from None
    finally:
        for remaining in (fd, read_fd, write_fd):
            if remaining is not None:
                try:
                    os.close(remaining)
                except OSError:
                    # An already recorded capture failure is never replaced by
                    # a cleanup exception that discards its drain evidence.
                    if error is None:
                        raise
