"""Blocked-network CPU tests. Synthetic private grants NEVER represent ROOT GO."""
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import pickle
import socket
import sys
import tempfile
import threading
import time
import types
import unittest
from unittest import mock
import urllib.error
import urllib.request

import real_common as common
import real_authority as auth
import real_journal as journal
import real_attempt_gate as gate
import secret_fd

OUT = common.HERE / "validation"
KEY = "synthetic-CPU-value-never-a-real-key"
URL = "http://127.0.0.1:1/v1/chat/completions"  # owned inert opener only
TOOLS = [{"type": "function", "function": {"name": "lookup", "description": "CPU",
    "parameters": {"type": "object", "properties": {}, "additionalProperties": False}}}]
MESSAGES = [{"role": "system", "content": "Use native tools."}, {"role": "user", "content": "CPU task"}]


def synthetic_grant(root, ids=("audit", "pool"), *, anchors=None):
    # Test seam only: bypasses external validation deliberately, while sockets
    # are patched closed. Production has no CPU-to-RealGrant factory.
    now = time.time()
    study = {"operations": {"max_http_attempts": 100},
        "whole_study": {"not_before": now - 100, "absolute_deadline": now + 3600}}
    epoch = {"identity": {"endpoint": URL.rsplit("/chat/completions", 1)[0], "valid_until": now + 3600,
        "credential": {"mode": "bearer_anonymous_fd"}}, "model": "m0", "epoch_id": 0}
    go = {"output_root": str(root), "invocation_ids": list(ids), "not_before": now - 100, "valid_until": now + 3600}
    return auth.RealGrant(auth._TOKEN, study=study, epoch=epoch, anchors=anchors or {}, go=go)


class FixtureBase(unittest.TestCase):
    def setUp(self):
        OUT.mkdir(exist_ok=True)
        self.folder = Path(tempfile.mkdtemp(prefix="cpu_real_", dir=str(OUT)))
        self.temp = types.SimpleNamespace(name=str(self.folder))
        self.root = self.folder / "run"
        self.network_calls = 0
        def blocked(*args, **kwargs):
            self.network_calls += 1
            raise AssertionError("CPU_REGRESSION_NETWORK_BLOCKED")
        for obj, name in ((socket.socket, "connect"), (socket, "create_connection"), (urllib.request, "urlopen")):
            patch = mock.patch.object(obj, name, side_effect=blocked)
            patch.start()
            self.addCleanup(patch.stop)
        self.addCleanup(lambda: self.assertEqual(self.network_calls, 0))

    def ref(self, name, value):
        path = self.folder / (name + ".json")
        common.write(path, value)
        return {"path": str(path), "sha256": common.sha(path)}


class AuthorityTests(FixtureBase):
    def test_missing_root_pins_precedes_any_helper(self):
        with mock.patch.object(common, "verify", side_effect=AssertionError("must not reach helper")):
            for anchors in (None, {}, {"go": {"passed": True}}):
                with self.assertRaises(auth.AuthorityError):
                    auth.validate_real_authority({}, {}, anchors)

    def test_cpu_receipts_and_draft_flags_cannot_upgrade(self):
        for kind in ("cpu_mock", "DRAFT", "cpu_fixture"):
            refs = {name: self.ref(kind + name, {"kind": kind, "passed": True})
                for name in ("definition", "registration", "acceptance", "epoch", "go", "allocation")}
            with self.assertRaises(auth.AuthorityError):
                auth.validate_real_authority(common.read(refs["definition"]["path"]), common.read(refs["epoch"]["path"]), refs)

    def test_external_wrong_bytes_rejected(self):
        ref = self.ref("pinned", {"authorize": True})
        with self.assertRaises(auth.AuthorityError):
            auth.pinned(dict(ref, sha256="0" * 64))
        with self.assertRaises(auth.AuthorityError):
            auth.pinned({"path": ref["path"], "self_sha256": ref["sha256"]})

    def test_cpu_definition_and_old_phase1_producer_rejected(self):
        for value in ({"schema_version": "phase3b-study-definition-v1", "kind": "cpu_fixture"},
                      {"schema_version": "phase3b-real-study-definition-v1", "kind": "formal_real_definition", "producer_schema": "phase1"}):
            with self.assertRaises(auth.AuthorityError):
                auth.verify_study(value)

    def test_expiry_scope_process_and_serialization(self):
        grant = synthetic_grant(self.root)
        with self.assertRaises(auth.AuthorityError): grant.check("another")
        with self.assertRaises(auth.AuthorityError): grant.check("audit", now=grant.deadline)
        with self.assertRaises(auth.AuthorityError): pickle.dumps(grant)
        grant.pid -= 1
        with self.assertRaises(auth.AuthorityError): grant.check("audit")
        with self.assertRaises(auth.AuthorityError): auth.RealGrant(None, study={}, epoch={}, anchors={}, go={})

    def test_grant_anchor_tamper_revokes_before_wire(self):
        ref = self.ref("anchor", {"unit": 1})
        grant = synthetic_grant(self.root, anchors={"go": ref})
        grant.check("audit")
        Path(ref["path"]).write_text('{"unit":2}')
        with self.assertRaises(auth.AuthorityError): grant.check("audit")
        self.assertTrue(grant.revoked)

    def test_real_endpoint_cannot_use_cpu_reserved_or_credentials(self):
        for url in ("https://fixture.invalid/v1", "http://u:p@example.com/v1", "http://example.com/v1?key=x"):
            with self.assertRaises(auth.AuthorityError): auth.endpoint(url)

    def test_no_marker_can_arm_delegate(self):
        delegate = common.import_delegate()
        for value in (None, {"real": True}, types.SimpleNamespace(cpu_bytes_only=False)):
            with self.assertRaises(delegate.ScopeViolation):
                delegate.authorized_delegate(delegate.RequestScope(URL, 3, "bearer", KEY), value)


class ClientGateTests(FixtureBase):
    def client(self, responses):
        module = common.a3_module("support").bridge.module("expgym.llm_clients")
        delegate = common.import_delegate()
        dump = self.root / "raw/audit"
        env = mock.patch.dict(os.environ, {"EXPGYM_API_DUMP_DIR": str(dump), "EXPGYM_RUN_ID": "CPU-real-path-unit"})
        env.start()
        self.addCleanup(env.stop)
        client = module.OpenAICompatibleLLM(api_key=KEY, model="fixture/unit", base_url=URL, temperature=0.7,
            top_p=0.9, seed=9, max_tokens=32, timeout=3, max_retries=1, retry_base_seconds=0,
            retry_max_seconds=0, dump_context={"runner": "expgym", "unit": "CPU-only"})
        grant = synthetic_grant(self.root)
        opener = delegate.FixtureOpener(responses)
        transport = delegate.authorized_delegate(delegate.RequestScope(URL, 3, "bearer", KEY), grant, opener=opener)
        common.write(self.root / "journal/audit.start.json", {"unit": "CPU begin"})
        common.write(self.root / "logs/audit/identity.json", {"unit": "CPU identity"})
        wrapped = gate.AttemptGate(grant=grant, invocation_id="audit", client=client,
            planned={"owner_id": "order0", "context": {"runner": "expgym", "unit": "CPU-only"}, "seed": 9, "schemas": TOOLS},
            profile={"model": "fixture/unit", "temperature": 0.7, "top_p": 0.9},
            policy={"max_retries": 1, "request_timeout": 3, "max_tokens": 32}, dump_dir=dump,
            evidence_dir=self.root / "logs/audit/attempts", begin_path=self.root / "journal/audit.start.json",
            identity_path=self.root / "logs/audit/identity.json", initial_messages=MESSAGES, delegate=transport)
        client._transport = wrapped
        return client, wrapped, opener, dump

    @staticmethod
    def response(message=None):
        return common.import_delegate().FixtureResponse(common.encoded({"choices": [{"message": message or {"role": "assistant", "content": "done"},
            "finish_reason": "stop"}], "usage": {"prompt_tokens": 5, "completion_tokens": 3}}), url=URL)

    def test_actual_native_client_byte_gate_return_and_no_secret_in_artifacts(self):
        client, wrapped, opener, dump = self.client([self.response()])
        self.assertEqual(client.generate(MESSAGES, tools=TOOLS, tool_choice="auto").text, "done")
        self.assertEqual(opener.call_count, 1)
        result = gate.inventory(wrapped.evidence_dir, dump)
        self.assertEqual(result["issues"], [])
        self.assertEqual(result["http_response_bytes_returned"], 1)
        for path in self.root.rglob("*.json"):
            self.assertNotIn(KEY.encode(), common.read_bytes(path))

    def test_original_http503_retry_two_attempts_unknown_first_cost(self):
        error = urllib.error.HTTPError(URL, 503, "CPU only", {}, io.BytesIO(b"{}"))
        client, wrapped, opener, dump = self.client([error, self.response()])
        value = client.generate(MESSAGES, tools=TOOLS, tool_choice="auto")
        self.assertEqual(opener.call_count, 2)
        self.assertEqual(len(value.attempt_usage), 2)
        result = gate.inventory(wrapped.evidence_dir, dump)
        self.assertEqual(result["issues"], [])
        self.assertEqual(result["send_unknown"], 1)
        self.assertEqual(result["raw_attempts"], 2)
        error.close()

    def abort_response(self, usage):
        response = {"choices": [{"message": {"role": "assistant", "content": "Partial is not a usable answer",
            "reasoning_content": "Retain aborted reasoning"}, "finish_reason": "abort"}], "usage": usage}
        return common.import_delegate().FixtureResponse(common.encoded(response), url=URL), response

    def assert_abort(self, responses, choice, expected_calls, usage):
        client, wrapped, opener, dump = self.client(responses)
        clients = common.a3_module("support").bridge.module("expgym.llm_clients")
        with self.assertRaises(clients.APICompletionAbortedError):
            client.generate(MESSAGES, tools=TOOLS, tool_choice=choice)
        self.assertEqual(opener.call_count, expected_calls)
        value = gate.inventory(wrapped.evidence_dir, dump)
        self.assertEqual(value["issues"], [])
        self.assertEqual(value["raw_attempts"], expected_calls)
        self.assertEqual(value["http_response_bytes_returned"], 1)
        self.assertEqual(value["send_unknown"], expected_calls - 1)
        rows = [common.read(path) for path in dump.glob("*.json")]
        aborted = [row for row in rows if row.get("error", {}).get("type") == "APICompletionAbortedError"]
        self.assertEqual(len(aborted), 1)
        raw = aborted[0]
        self.assertEqual(raw["state"], "error")
        self.assertIs(raw["will_retry"], False)
        self.assertIsNone(raw["retry_delay_seconds"])
        self.assertIsNone(raw["http_status"])
        self.assertEqual(json.loads(raw["response_raw"]), raw["response_json"])
        self.assertEqual(raw["response_json"]["usage"], usage)
        self.assertEqual(raw["response_json"]["choices"][0]["finish_reason"], "abort")
        self.assertTrue(all(row["raw_state"] == "error" for row in value["attempts"]))

    def test_exact_abort_auto_known_usage_is_terminal_not_completion(self):
        usage = {"prompt_tokens": 5, "completion_tokens": 3}
        aborted, _ = self.abort_response(usage)
        self.assert_abort([aborted, self.response()], "auto", 1, usage)

    def test_exact_abort_none_unknown_usage_is_not_zero(self):
        aborted, _ = self.abort_response(None)
        self.assert_abort([aborted, self.response()], "none", 1, None)

    def test_http503_then_abort_never_consumes_success_backup(self):
        error = urllib.error.HTTPError(URL, 503, "CPU only", {}, io.BytesIO(b"{}"))
        usage = {"prompt_tokens": 5, "completion_tokens": 3}
        aborted, _ = self.abort_response(usage)
        try:
            self.assert_abort([error, aborted, self.response()], "auto", 2, usage)
        finally:
            error.close()

    def test_abort_returned_predicate_rejects_near_misses(self):
        _, response = self.abort_response({"prompt_tokens": 5, "completion_tokens": 3})
        body = common.encoded(response).decode("utf-8")
        raw = {"state": "error", "error": {"type": "APICompletionAbortedError"},
            "will_retry": False, "retry_delay_seconds": None,
            "response_json": response, "response_raw": body}
        event = {"response_bytes": len(body.encode("utf-8"))}
        self.assertTrue(gate._terminal_abort_with_returned_bytes(raw, event))
        mutations = [lambda r, e: r.update(state="success"),
            lambda r, e: r.update(error={"type": "APIClientError"}),
            lambda r, e: r.update(will_retry=True),
            lambda r, e: r.update(retry_delay_seconds=0),
            lambda r, e: r.pop("retry_delay_seconds"),
            lambda r, e: r["response_json"]["choices"][0].update(finish_reason="stop"),
            lambda r, e: r.update(response_raw="[]"),
            lambda r, e: r.update(response_raw='{"choices":[],"choices":[]}'),
            lambda r, e: e.update(response_bytes=True),
            lambda r, e: e.update(response_bytes=e["response_bytes"] + 1)]
        for index, mutate in enumerate(mutations):
            with self.subTest(mutation=index):
                changed, changed_event = copy.deepcopy(raw), dict(event)
                mutate(changed, changed_event)
                self.assertFalse(gate._terminal_abort_with_returned_bytes(changed, changed_event))

    def test_malformed_delivered_bytes_not_retried(self):
        client, wrapped, opener, dump = self.client([common.import_delegate().FixtureResponse(b"not json", url=URL), self.response()])
        with self.assertRaises(Exception): client.generate(MESSAGES, tools=TOOLS, tool_choice="auto")
        self.assertEqual(opener.call_count, 1)
        self.assertEqual(gate.inventory(wrapped.evidence_dir, dump)["raw_attempts"], 1)

    def test_request_seed_or_template_mismatch_rejected_before_opener(self):
        client, wrapped, opener, dump = self.client([self.response()])
        client.config.seed = 17
        with self.assertRaises(gate.GateError): client.generate(MESSAGES, tools=TOOLS, tool_choice="auto")
        self.assertEqual(opener.call_count, 0)
        self.assertEqual(gate.inventory(wrapped.evidence_dir, dump)["not_sent"], 1)

    def test_forced_none_preserves_full_reasoning_tool_history(self):
        message = {"role": "assistant", "content": None, "reasoning_content": "CPU opaque history", "tool_calls": [
            {"id": "opaque:with:colon", "type": "function", "function": {"name": "lookup", "arguments": "{}"}}]}
        client, wrapped, opener, dump = self.client([self.response(message), self.response()])
        first = client.generate(MESSAGES, tools=TOOLS, tool_choice="auto")
        history = MESSAGES + [first.assistant_message, {"role": "tool", "tool_call_id": "opaque:with:colon", "name": "lookup", "content": "CPU nonce"}]
        client.generate(history, tools=TOOLS, tool_choice="none")
        payload = json.loads(opener.last_request.data)
        self.assertEqual(payload["messages"], history)
        self.assertEqual(payload["tools"], TOOLS)
        self.assertEqual(gate.inventory(wrapped.evidence_dir, dump)["issues"], [])

    def test_foreign_unreadable_dump_is_not_scanned_before_own_wire(self):
        client, wrapped, opener, dump = self.client([self.response()])
        dump.mkdir(parents=True, exist_ok=True)
        foreign = dump / ("f" * 32 + ".json")
        foreign.symlink_to(dump / "absent-other-client")
        client.generate(MESSAGES, tools=TOOLS, tool_choice="auto")
        self.assertEqual(opener.call_count, 1)
        self.assertTrue(gate.inventory(wrapped.evidence_dir, dump)["issues"])

    def test_no_gate_no_wire_and_consumed_request_not_replayed(self):
        client, wrapped, opener, dump = self.client([self.response(), self.response()])
        request = urllib.request.Request(URL, data=b"{}", headers={"Content-Type": "application/json", "Authorization": "Bearer " + KEY})
        with self.assertRaises(common.import_delegate().ScopeViolation): wrapped.delegate(request, 3)
        self.assertEqual(opener.call_count, 0)
        client.generate(MESSAGES, tools=TOOLS, tool_choice="auto")
        with self.assertRaises(common.import_delegate().ScopeViolation): wrapped.delegate(opener.last_request, 3)
        self.assertEqual(opener.call_count, 1)

    def test_reflected_synthetic_key_never_reaches_raw_or_canonical_return(self):
        client, wrapped, opener, dump = self.client([self.response({"role": "assistant", "content": KEY})])
        with self.assertRaises(gate.GateError): client.generate(MESSAGES, tools=TOOLS, tool_choice="auto")
        self.assertEqual(opener.call_count, 1)
        self.assertEqual(gate.inventory(wrapped.evidence_dir, dump)["send_unknown"], 1)
        for path in self.root.rglob("*.json"):
            self.assertNotIn(KEY.encode(), common.read_bytes(path))

    def test_unknown_or_wrong_terminal_dump_is_rejected_before_write(self):
        client, wrapped, opener, dump = self.client([self.response()])
        for state in ("wrong_state", "success", "error", "malformed_response"):
            with self.assertRaises(gate.GateError):
                client._dump_attempt({"request_id": "a" * 32}, {}, time.monotonic(), state=state)
        self.assertFalse(dump.exists())
        self.assertEqual(opener.call_count, 0)


class SecretTests(FixtureBase):
    def test_anonymous_pipe_only_and_no_serialized_secret(self):
        read_fd, write_fd = os.pipe()
        os.write(write_fd, KEY.encode())
        os.close(write_fd)
        self.assertEqual(secret_fd.read_secret_fd(read_fd), KEY)
        with self.assertRaises(OSError): os.fstat(read_fd)
        path = self.folder / "not-a-key.json"
        common.write(path, {"synthetic": True})
        fd = os.open(str(path), os.O_RDONLY)
        with self.assertRaises(ValueError): secret_fd.read_secret_fd(fd)
        with self.assertRaises(ValueError): secret_fd.validate_secret("bad\nvalue")
        with self.assertRaises(ValueError): secret_fd.validate_secret("")

    def test_secret_argv_env_rejected_before_subprocess(self):
        with mock.patch.object(secret_fd.subprocess, "run", side_effect=AssertionError("must not spawn")):
            for argv, env in ((["python", KEY], {}), (["python"], {"SECRET": KEY})):
                with self.assertRaises(ValueError):
                    secret_fd.run_child(argv, str(self.folder), env, self.folder / "forbidden.log", secret=KEY)

    def test_anonymous_fd_subprocess_roundtrip_and_prewrite_log_redaction(self):
        code = "import os,sys,socket; socket.socket.connect=lambda *a: (_ for _ in ()).throw(RuntimeError('CPU_BLOCKED')); print(os.read(int(sys.argv[-1]),2048).decode('ascii'))"
        target = self.folder / "redacted.log"
        with self.assertRaises(RuntimeError):
            secret_fd.run_child([sys.executable, "-B", "-c", code], str(self.folder), {}, target, secret=KEY)
        data = common.read_bytes(target)
        self.assertNotIn(KEY.encode(), data)
        self.assertIn(b"[REDACTED]", data)


# SHA-pinned original logical journal tests, with only a local module binding
# and new setup/factory. No frozen test or journal globals are changed.
_path = common.HERE.parent / "test_journal.py"
_body = common.read_bytes(_path)
if hashlib.sha256(_body).hexdigest() != "6cfc6473981b68a0f5883175540239009ec6bfa507cafb2c145543feabd23fc2":
    raise ValueError("frozen_logical_journal_suite_changed")
_suite = types.ModuleType("real_path_inherited_logical_tests")
_suite.__dict__["_JOURNAL"] = journal
exec(compile(_body.decode().replace("import journal\n", "journal = _JOURNAL\n"), str(_path), "exec"), _suite.__dict__)


class JournalTests(FixtureBase, _suite.JournalTests):
    def setUp(self):
        FixtureBase.setUp(self)
        self.invocations = [
            {"invocation_id": "audit", "logical_ids": ["order0", "order1", "order2"], "output_relative_dir": "results/audit", "dump_relative_dir": "raw/audit"},
            {"invocation_id": "pool", "logical_ids": ["pool0"], "output_relative_dir": "results/pool", "dump_relative_dir": "raw/pool"}]
        self.rows = [{"invocation_id": inv["invocation_id"], "logical_id": lid, "result_artifact": inv["output_relative_dir"] + "/" + lid + ".json",
            "agent_artifacts": [], "model": "cpu-fixture", "outerrep": 0} for inv in self.invocations for lid in inv["logical_ids"]]
        self.plan_sha = "a" * 64

    def make(self, create=True, **changes):
        values = dict(root=self.root, plan_sha256=self.plan_sha, invocations=self.invocations, logical_rows=self.rows, create=create)
        values.update(changes)
        if values["create"]:
            # CPU fixture scope stays in this task's new directory, even though
            # production accepts any exact externally registered narrow root.
            try:
                Path(values["root"]).relative_to(self.folder)
            except ValueError:
                raise journal.JournalError("CPU fixture cannot grant outside its owned temporary root")
            values["capability"] = journal.real_root_capability(synthetic_grant(values["root"]))
        result = journal.Journal(**values)
        self.addCleanup(result.close)
        return result

    def test_reserved_without_start_is_not_eligible_and_not_freed(self):
        instance = self.make()
        instance.write_operation("budget.audit", {"kind": "identity", "purpose": "request_attempt_reservation", "invocation_id": "audit", "upper_bound": 12})
        value = journal.eligible_inventory(instance)
        self.assertEqual(value["reserved_without_start"], ["audit"])
        self.assertEqual(value["eligible_never_begun_ids"], ["pool"])
        self.assertIn("audit", instance.snapshot_inventory()["never_begun_ids"])

    def test_real_ops_are_distinct_and_readonly_reopen(self):
        instance = self.make()
        record = instance.write_operation("stage0", {"kind": "stage_begin"})
        self.assertEqual(record["schema_version"], "phase3b-real-operation-v1")
        self.assertEqual(record["classification"], "real_observation")
        instance.close()
        reopened = self.make(create=False)
        with self.assertRaises(journal.JournalError): reopened.write_operation("stage1", {"kind": "stage_begin"})
        self.assertTrue(reopened.reconcile()["valid"])

    def test_full_manifest_bytes_same_size_tamper_rejected(self):
        instance = self.make()
        path = self.root / "journal/manifest.json"
        before = path.stat()
        path.write_bytes(path.read_bytes().replace(b'"kind":"manifest"', b'"kind":"MANIFEST"'))
        os.utime(str(path), ns=(before.st_atime_ns, before.st_mtime_ns))
        with self.assertRaises(journal.JournalError): instance.begin("audit", {})


if __name__ == "__main__":
    unittest.main(verbosity=2)
