"""Synthetic closed namespaces only: no real model, scorer, key or run reads."""
import copy
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import evidence


def fake_decode(body):
    data = json.loads(body.decode("utf-8"))
    assistant = copy.deepcopy(data["choices"][0]["message"])
    assistant.setdefault("role", "assistant")
    return data, assistant.get("content"), assistant.get("tool_calls", []), assistant, data["choices"][0].get("finish_reason")


class EvidenceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="restart-evidence-cpu-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.dump = self.root / "dump"
        self.logs = self.root / "logs"
        self.wire = self.logs / "wire"
        self.dump.mkdir()
        self.wire.mkdir(parents=True)
        self.plan = {"config": {"repo_root": str(self.root / "unused-source"), "run_id": "cpu-test",
            "policy": {"max_tokens": 100, "max_steps": 5, "max_retries": 1,
                       "request_timeout": 3600, "retry_base_seconds": 1, "retry_max_seconds": 10},
            "profiles": {"fixture-model": {"temperature": 0.3, "top_p": 0.9,
                "reasoning_effort": "high", "top_k": 40, "chat_template_kwargs": {"enable_thinking": True}}}}}
        self.job = {"invocation_id": "fixture-invocation", "model_id": "fixture-model",
            "sampling_seed_labels": [9001], "expected_model_terminals": 1,
            "endpoint": "http://fixture.invalid/v1/chat/completions", "dump_dir": str(self.dump), "log_dir": str(self.logs)}
        self.payload = {"model": "fixture-model", "messages": [{"role": "system", "content": "synthetic"},
            {"role": "user", "content": "question"}], "temperature": 0.3, "top_p": 0.9,
            "max_tokens": 100, "seed": 9001, "reasoning_effort": "high", "top_k": 40,
            "chat_template_kwargs": {"enable_thinking": True}, "tools": [{"type": "function", "function": {
                "name": "observe", "parameters": {"type": "object", "properties": {}}}}],
            "tool_choice": "auto", "parallel_tool_calls": False}
        self.common = {"schema_version": "restart-source-wire-metadata-v1", "invocation_id": self.job["invocation_id"],
            "model_id": self.job["model_id"], "run_id": "cpu-test", "primitive_sha256": evidence.PRIMITIVE_SHA256,
            "wire_client_id": "c" * 32, "source_client_id": "d" * 32, "seed": 9001}
        self.events = [dict(self.common, kind="client_identity", observed_at_utc=self.ts(0))]
        self.raws = []
        self.addCleanup(patch.stopall)
        patch.object(evidence, "_decoder", return_value=fake_decode).start()

    @staticmethod
    def ts(seconds):
        return (datetime(2026, 9, 9, tzinfo=timezone.utc) + timedelta(seconds=seconds)).isoformat()

    def add_attempt(self, *, generation=1, attempt=1, payload=None, state="success", retry=False,
                    status=None, error_type=None, finish="stop", assistant=None, usage=True, wire_error=False):
        seq = len(self.raws) + 1
        request = copy.deepcopy(self.payload if payload is None else payload)
        response = {"choices": [{"message": assistant if assistant is not None else {"role": "assistant", "content": "answer"},
                                  "finish_reason": finish}]}
        if usage:
            response["usage"] = {"prompt_tokens": 5, "completion_tokens": 3, "total_tokens": 8}
        if state == "error" and status is not None:
            response = {"error": {"message": "synthetic unavailable"}}
        body = json.dumps(response, ensure_ascii=False).encode("utf-8")
        request_body = json.dumps(request).encode("utf-8")
        common = dict(self.common, attempt_sequence=seq, request_body_sha256=hashlib.sha256(request_body).hexdigest(),
                      request_bytes=len(request_body), provider_usage_or_cost=None)
        self.events += [dict(common, kind="attempt_start", started_at_utc=self.ts(seq * 10 + 1), timeout_seconds=3600),
            dict(common, kind="attempt_terminal", finished_at_utc=self.ts(seq * 10 + 2), wall_time_seconds=1,
                state="error" if wire_error or status is not None else "bytes_returned",
                response_bytes_sha256=None if wire_error or status is not None else hashlib.sha256(body).hexdigest(),
                response_bytes=None if wire_error or status is not None else len(body), http_status=status,
                error_type=error_type if wire_error or status is not None else None, close_error_type=None,
                response_body_owned_by_source_client=status is not None)]
        raw = {"schema_version": "expgym.api_attempt.v1", "generation_id": "%032x" % generation,
            "request_id": "%032x" % (1000 + seq), "attempt": attempt, "max_attempts": 2,
            "started_at_utc": self.ts(seq * 10), "finished_at_utc": self.ts(seq * 10 + 3),
            "run_id": "cpu-test", "client_id": self.common["source_client_id"], "context": {}, "pid": 1,
            "thread_id": 1, "thread_name": "synthetic", "state": state, "wall_time_seconds": 3,
            "endpoint": self.job["endpoint"], "request_payload": request,
            "response_raw": body.decode("utf-8"), "response_json": response, "http_status": status,
            "error": {"type": error_type, "message": "private synthetic error text"} if error_type else None,
            "will_retry": retry, "retry_delay_seconds": 1 if retry else None}
        if wire_error:
            raw["response_raw"] = raw["response_json"] = None
        self.raws.append(raw)
        return raw

    def audit(self, raw_filter=None, event_filter=None):
        paths, events = [], []
        for raw in self.raws:
            path = self.dump / (raw["request_id"] + ".json")
            path.write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")
            paths.append(path)
        for index, event in enumerate(self.events):
            path = self.wire / ("%04d.json" % index)
            path.write_text(json.dumps(event), encoding="utf-8")
            events.append(path)
        return evidence.audit_raw(self.plan, self.job, raw_filter(paths) if raw_filter else paths,
                                  event_filter(events) if event_filter else events)

    def assert_bad(self, result, code=None):
        self.assertFalse(result["verified"], result)
        if code:
            self.assertIn(code, [item["code"] for item in result["errors"]], result)

    def test_success_exact_wire_join_usage_and_safe_summary(self):
        self.add_attempt()
        result = self.audit()
        self.assertTrue(result["verified"], result)
        self.assertEqual(result["counts"]["joined_attempts"], 1)
        self.assertEqual(result["known_usage_sum"]["total_tokens"], 8)
        self.assertEqual(result["unknown_usage_counts"]["total_tokens"], 0)
        self.assertIsNone(result["provider_cost_total"])
        self.assertNotIn('"answer"', json.dumps(result))
        self.assertEqual(len(result["inventory"]), 4)

    def test_empty_length_is_delivered_not_semantic_retry(self):
        self.add_attempt(finish="length", assistant={"role": "assistant", "content": ""})
        self.assertTrue(self.audit()["verified"])

    def test_missing_usage_is_unknown_not_zero_cost(self):
        self.add_attempt(usage=False)
        result = self.audit()
        self.assertTrue(result["verified"])
        self.assertEqual(result["unknown_usage_counts"], dict.fromkeys(evidence.USAGE_FIELDS, 1))
        self.assertIsNone(result["provider_cost_total"])

    def test_optional_profile_fields_absent_are_valid(self):
        profile = self.plan["config"]["profiles"]["fixture-model"]
        profile.update(reasoning_effort=None, top_k=None, chat_template_kwargs={})
        for field in ("reasoning_effort", "top_k", "chat_template_kwargs"):
            self.payload.pop(field)
        self.payload["tool_choice"] = "none"
        self.add_attempt()
        self.assertTrue(self.audit()["verified"])

    def test_default_serialization_is_not_canonical_hash(self):
        self.payload["messages"][1]["content"] = "非 ASCII"
        raw = self.add_attempt()
        canonical_hash = hashlib.sha256(evidence.support.canonical(raw["request_payload"])).hexdigest()
        self.assertNotEqual(canonical_hash, self.events[1]["request_body_sha256"])
        self.assertTrue(self.audit()["verified"])
        self.events[1]["request_body_sha256"] = self.events[2]["request_body_sha256"] = canonical_hash
        self.assert_bad(self.audit(), "request_bytes_not_reconstructible_or_wire_hash_differs")

    def test_redacted_request_cannot_be_silently_reconstructed(self):
        raw = self.add_attempt()
        raw["request_payload"]["messages"][1]["content"] = "[REDACTED]"
        self.assert_bad(self.audit(), "request_bytes_not_reconstructible_or_wire_hash_differs")

    def test_profile_mutations_all_rejected(self):
        for key, value in (("model", "other"), ("seed", 9002), ("max_tokens", 101), ("temperature", 0.5),
                           ("top_p", 0.1), ("top_k", 41), ("reasoning_effort", "low"),
                           ("parallel_tool_calls", True), ("tool_choice", "required")):
            with self.subTest(key=key):
                payload = copy.deepcopy(self.payload)
                payload[key] = value
                self.assertTrue(evidence._profile_errors(payload, self.plan, self.job))

    def test_extra_payload_fields_rejected(self):
        raw = self.add_attempt()
        raw["request_payload"]["stream"] = False
        self.assert_bad(self.audit(), "raw_request_profile_or_native_shape_differs")

    def test_missing_wire_terminal_is_not_closed(self):
        self.add_attempt()
        self.events.pop()
        self.assert_bad(self.audit(), "wire_attempt_start_terminal_bijection_differs")

    def test_unlisted_raw_file_is_coverage_failure(self):
        self.add_attempt()
        result = self.audit(raw_filter=lambda paths: [])
        self.assert_bad(result, "physical_namespace_coverage_differs")
        self.assertEqual(result["unknown_usage_counts"]["total_tokens"], 1)

    def test_unlisted_event_file_is_coverage_failure(self):
        self.add_attempt()
        self.assert_bad(self.audit(event_filter=lambda paths: paths[:-1]), "physical_namespace_coverage_differs")

    def test_duplicate_supplied_path_rejected(self):
        self.add_attempt()
        self.assert_bad(self.audit(raw_filter=lambda paths: paths + paths), "duplicate_supplied_path")

    def test_missing_supplied_file_is_read_failure(self):
        self.add_attempt()
        self.assert_bad(self.audit(raw_filter=lambda paths: paths + [self.dump / ("f" * 32 + ".json")]),
                        "unreadable_or_invalid_evidence")

    def test_duplicate_wire_terminal_rejected(self):
        self.add_attempt()
        self.events.append(copy.deepcopy(self.events[-1]))
        self.assert_bad(self.audit(), "invalid_wire_event")

    def test_primitive_and_seed_identity_mismatch_rejected(self):
        self.add_attempt()
        self.events[-1]["primitive_sha256"] = "0" * 64
        self.assert_bad(self.audit(), "invalid_wire_event")

    def test_timeout_and_timestamp_mismatch_rejected(self):
        self.add_attempt()
        self.events[1]["timeout_seconds"] = 30
        self.events[2]["finished_at_utc"] = self.ts(99)
        result = self.audit()
        self.assert_bad(result, "wire_start_terminal_identity_differs")
        self.assert_bad(result, "raw_wire_attempt_time_order_differs")

    def test_response_hash_mismatch_rejected(self):
        self.add_attempt()
        self.events[-1]["response_bytes_sha256"] = "0" * 64
        self.assert_bad(self.audit(), "response_bytes_not_reconstructible_or_wire_hash_differs")

    def test_response_raw_and_json_disagreement_rejected(self):
        raw = self.add_attempt()
        raw["response_json"]["choices"][0]["message"]["content"] = "different"
        self.assert_bad(self.audit(), "response_raw_json_disagrees")

    def test_http_retry_then_success_bounded_and_cost_unknown(self):
        self.add_attempt(state="error", retry=True, status=503, error_type="HTTPError")
        self.add_attempt(attempt=2)
        result = self.audit()
        self.assertTrue(result["verified"], result)
        self.assertEqual(result["counts"]["logical_generations"], 1)
        self.assertEqual(result["unknown_usage_counts"]["total_tokens"], 1)
        self.assertEqual(result["known_usage_sum"]["total_tokens"], 8)

    def test_transport_retry_then_success(self):
        self.add_attempt(state="error", retry=True, error_type="TimeoutError", wire_error=True)
        self.add_attempt(attempt=2)
        self.assertTrue(self.audit()["verified"])

    def test_nonretryable_http_retry_rejected(self):
        self.add_attempt(state="error", retry=True, status=400, error_type="HTTPError")
        self.add_attempt(attempt=2)
        self.assert_bad(self.audit(), "unregistered_semantic_or_unbounded_retry")

    def test_semantic_resampling_rejected(self):
        self.add_attempt(retry=True, finish="length")
        self.add_attempt(attempt=2)
        self.assert_bad(self.audit(), "unregistered_semantic_or_unbounded_retry")

    def test_retry_changed_payload_and_skipped_attempt_rejected(self):
        self.add_attempt(state="error", retry=True, status=503, error_type="HTTPError")
        payload = copy.deepcopy(self.payload)
        payload["messages"][-1]["content"] = "changed"
        self.add_attempt(attempt=3, payload=payload)
        result = self.audit()
        self.assert_bad(result, "retry_changed_request_payload")
        self.assert_bad(result, "retry_attempt_sequence_not_contiguous")

    def test_abort_continuation_rejected_even_with_response_bytes(self):
        self.add_attempt(state="error", finish="abort", error_type="APICompletionAbortedError")
        self.add_attempt(generation=2)
        result = self.audit()
        self.assert_bad(result, "provider_abort_not_publishable_or_retryable")
        self.assert_bad(result, "continued_after_terminal_error_or_abort")

    def test_exhausted_transport_failure_not_verified(self):
        self.add_attempt(state="error", error_type="TimeoutError", wire_error=True)
        self.assert_bad(self.audit(), "terminal_generation_not_delivered")

    def test_http_error_wire_hash_must_not_claim_body_ownership(self):
        self.add_attempt(state="error", retry=True, status=503, error_type="HTTPError")
        self.events[-1]["response_bytes_sha256"] = "0" * 64
        self.add_attempt(attempt=2)
        self.assert_bad(self.audit(), "http_error_wire_source_contract_differs")

    def test_exact_assistant_history_and_native_pairing(self):
        assistant = {"role": "assistant", "content": None, "reasoning_content": "preserve me",
            "tool_calls": [{"id": "call1", "type": "function", "function": {"name": "observe", "arguments": "{}"}}]}
        self.add_attempt(assistant=assistant, finish="tool_calls")
        payload = copy.deepcopy(self.payload)
        payload["messages"] += [assistant, {"role": "tool", "tool_call_id": "call1", "content": "synthetic result"}]
        self.add_attempt(generation=2, payload=payload)
        self.assertTrue(self.audit()["verified"])

    def test_history_order_mutation_latest_and_orphans_rejected(self):
        a = {"role": "assistant", "content": "a"}
        b = {"role": "assistant", "content": "b"}
        for history, prior in (([b, a], [a, b]), ([a], [a, b]),
                               ([dict(a, reasoning_content="new")], [a]),
                               ([{"role": "tool", "tool_call_id": "orphan", "content": "x"}], [])):
            with self.subTest(history=history):
                self.assertTrue(evidence._history(history, prior))

    def test_bounded_history_allows_trim_but_not_missing_tool_result(self):
        a = {"role": "assistant", "content": "a"}
        b = {"role": "assistant", "content": "b"}
        c = {"role": "assistant", "content": None, "tool_calls": [{"id": "x", "type": "function",
            "function": {"name": "observe", "arguments": "{}"}}]}
        self.assertEqual(evidence._history([b], [a, b]), [])
        self.assertEqual(evidence._history([c, {"role": "tool", "tool_call_id": "x", "content": "trimmed"}], [a, c]), [])
        self.assertTrue(evidence._history([c], [c]))

    def test_invalid_state_never_crashes_report(self):
        raw = self.add_attempt()
        raw["state"] = {"unexpected": "object"}
        self.assert_bad(self.audit(), "invalid_raw_record")

    def test_symlink_extra_temp_and_corrupt_json_are_fail_closed(self):
        self.add_attempt()
        extra = self.dump / ".api-attempt-incomplete.tmp"
        extra.write_text("incomplete", encoding="utf-8")
        result = self.audit()
        self.assert_bad(result, "physical_namespace_coverage_differs")
        target = self.root / "outside.json"
        target.write_text("{}", encoding="utf-8")
        link = self.dump / ("e" * 32 + ".json")
        link.symlink_to(target)
        result = self.audit(raw_filter=lambda paths: paths + [link])
        self.assert_bad(result, "unreadable_or_invalid_evidence")
        def corrupt(paths):
            paths[0].write_text('{"invalid"', encoding="utf-8")
            return paths
        self.assert_bad(self.audit(raw_filter=corrupt), "unreadable_or_invalid_evidence")


if __name__ == "__main__":
    unittest.main()
