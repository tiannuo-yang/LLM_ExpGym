"""Post-drain read-only smoke closure; reuses existing checks, grants no authority."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import sys

HERE = Path(__file__).absolute().parent
sys.path.insert(0, str(HERE.parent / "planner_candidate_v1"))
import launcher as l
import evidence


def read(path):
    return l.s.parse_json(l.s.io.read_regular(path))


def snapshot(root):
    result = l.safe_tree(root)
    return [dict(row, bytes=Path(row["path"]).stat().st_size,
                 mtime_ns=Path(row["path"]).stat().st_mtime_ns) for row in result]


def process_fact(start_path):
    value = read(start_path)
    pid = value["pid"]
    if type(pid) is not int or pid < 2:
        raise ValueError("invalid_original_caller_pid")
    proc = Path("/proc") / str(pid)
    return {"pid": pid, "pid_absent": not proc.exists(), "start_ref": l.s.ref(start_path)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", required=True)
    parser.add_argument("--plan-sha256", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    plan_ref = {"path": args.plan, "sha256": args.plan_sha256}
    plan = l.s.io.read_json_ref(plan_ref)
    if plan["schema_version"] != l.SCHEMA or plan["mode"] != "selected_smoke":
        raise ValueError("only_bound_selected_smoke_closure")
    root = Path(plan["config"]["output_root"])
    execution_ref = l.s.ref(root / "execution.json")
    execution = read(root / "execution.json")
    facts = [process_fact(root / "execution_started.json")]
    for job in plan["jobs"]:
        for name in ("source_started.json", "verify_started.json"):
            path = Path(job["log_dir"]) / name
            if path.exists():
                facts.append(process_fact(path))
    if any(not fact["pid_absent"] for fact in facts):
        raise ValueError("caller_pid_still_present_do_not_seal")
    before = snapshot(root)
    errors, jobs, checks = [], [], []
    def error(code, iid=None):
        errors.append({"code": code, "invocation_id": iid})
    if execution.get("plan_ref") != plan_ref:
        error("execution_plan_ref_differs")
    if execution.get("execution_complete") is not True:
        error("execution_not_marked_complete")
    planned = [job["invocation_id"] for job in plan["jobs"]]
    finished = [entry["invocation_id"] for entry in execution["reports"]]
    execution_by_id = {entry["invocation_id"]: entry for entry in execution["reports"]}
    if len(planned) != 28 or len(set(planned)) != 28 or set(planned) != set(finished) or len(finished) != 28:
        error("full_28_invocations_not_closed")
    if execution.get("unstarted_invocation_ids") or execution.get("local_workers") != 0:
        error("incomplete_dispatch_or_local_workers")
    key_path = l.s.io.lexical(plan["config"]["credential_path"])
    for path, checksum in plan["file_bindings"].items():
        if l.s.io.lexical(path) == key_path:
            raise ValueError("credential_must_not_be_hashed")
        l.s.io.read_ref({"path": path, "sha256": checksum})
    source = l.s.io.read_json_ref(plan["config"]["source_acceptance_ref"])
    source_checked = []
    for relative, checksum in source["files"].items():
        reference = {"path": str(Path(plan["config"]["repo_root"]) / relative), "sha256": checksum}
        l.s.io.read_ref(reference)
        source_checked.append(reference)
    classes, statuses, usage, unknown, coverage = Counter(), Counter(), Counter(), Counter(), Counter()
    raw_count = raw_events = delivered = lengths = forced_none = raw_errors = 0
    reasoning_known = reasoning_unknown = 0
    latencies = []
    all_expected = []
    physical = l.safe_tree(root / "results")
    for job in plan["jobs"]:
        iid, logdir = job["invocation_id"], Path(job["log_dir"])
        all_expected.extend(job["expected_files"])
        path = logdir / "terminal.json"
        if not path.exists():
            error("terminal_record_missing", iid)
            continue
        terminal = read(path)
        report = terminal["report"]
        compared = {key: terminal[key] for key in ("invocation_id", "report", "decision")}
        if l.s.canonical(compared) != l.s.canonical(execution_by_id.get(iid)):
            error("execution_entry_does_not_match_physical_terminal", iid)
        if report.get("invocation_id") != iid or terminal["decision"] != l.dispatch.terminal_decision(job, report):
            error("terminal_decision_recompute_differs", iid)
        if not terminal["decision"]["continue"]:
            error("source_or_integrity_failed", iid)
        artifact_refs = l.safe_tree(job["output_dir"])
        if {row["path"] for row in artifact_refs} != set(job["expected_files"]):
            error("result_file_set_differs", iid)
        if report.get("artifacts") != artifact_refs:
            error("reported_artifact_bytes_differ", iid)
        for key in ("original_terminal_evidence", "verification_terminal_evidence"):
            for reference in report.get(key, []):
                l.s.io.read_ref(reference)
        resume = read(logdir / "verified_resume.json") if (logdir / "verified_resume.json").exists() else {}
        if (resume.get("passed") is not True or resume.get("source_exit_code") != 0
                or resume.get("model_calls_forbidden") is not True
                or resume.get("forbidden_model_attempts") != {"construction": 0, "generation": 0}):
            error("verified_resume_contract_failed", iid)
        capture = read(logdir / "source_capture.json") if (logdir / "source_capture.json").exists() else {}
        if capture.get("exit_code") != 0 or capture.get("drain_proven") is not True:
            error("source_child_capture_not_successfully_drained", iid)
        raw_paths = [row["path"] for row in l.safe_tree(job["dump_dir"])]
        event_paths = [row["path"] for row in l.safe_tree(logdir / "wire")]
        repeated = evidence.audit_raw(plan, job, raw_paths, event_paths)
        recorded = read(logdir / "raw_audit.json") if (logdir / "raw_audit.json").exists() else {}
        if recorded and report.get("raw_audit_ref") != l.s.ref(logdir / "raw_audit.json"):
            error("report_raw_audit_ref_differs_from_original_bytes", iid)
        if resume and report.get("verified_resume_ref") != l.s.ref(logdir / "verified_resume.json"):
            error("report_verified_resume_ref_differs_from_original_bytes", iid)
        if repeated != recorded or repeated.get("verified") is not True:
            error("raw_wire_recompute_did_not_match_successful_original", iid)
        raw_count += len(raw_paths)
        raw_events += len(event_paths)
        usage.update(repeated["known_usage_sum"])
        unknown.update(repeated["unknown_usage_counts"])
        job_lengths = job_none = 0
        for path in raw_paths:
            raw = read(path)
            if type(raw.get("wall_time_seconds")) in (int, float) and raw.get("finished_at_utc"):
                latencies.append(raw["wall_time_seconds"])
            raw_usage = (raw.get("response_json") or {}).get("usage") or {}
            reasoning = raw_usage.get("reasoning_tokens", (raw_usage.get("completion_tokens_details") or {}).get("reasoning_tokens"))
            if type(reasoning) is int and reasoning >= 0:
                reasoning_known += reasoning
            else:
                reasoning_unknown += 1
            statuses[raw["state"]] += 1
            raw_errors += raw["state"] != "success"
            if raw["state"] == "success":
                delivered += 1
                choice = raw["response_json"]["choices"][0]
                job_lengths += choice["finish_reason"] == "length"
                job_none += raw["request_payload"]["tool_choice"] == "none"
        lengths += job_lengths
        forced_none += job_none
        status = report.get("terminal_status", {})
        classes[status.get("terminal_classification", "missing")] += 1
        cell = [job["system"], job["scenario"], job["runtime_profile_required"]]
        for flag in ("--cost-regimes", "--cost-regime", "--strategies"):
            if flag in job["command"]:
                cell.append(job["command"][job["command"].index(flag)+1])
        coverage["|".join(cell)] += 1
        jobs.append({"invocation_id": iid, "terminal_status": status, "terminal_ref": l.s.ref(logdir / "terminal.json"),
            "raw_audit_ref": l.s.ref(logdir / "raw_audit.json") if recorded else None,
            "verified_resume_ref": l.s.ref(logdir / "verified_resume.json") if resume else None,
            "raw_files": len(raw_paths), "length_deliveries": job_lengths, "forced_none_deliveries": job_none,
            "early_answer_or_no_forced_branch_does_not_trigger_resampling": True})
    if len(all_expected) != 82 or set(all_expected) != {row["path"] for row in physical}:
        error("full_82_result_JSON_set_differs")
    model_terminals = sum(job["terminal_status"].get("reported_model_terminals", 0) for job in jobs)
    if model_terminals != 46:
        error("full_46_model_terminals_not_reported")
    after = snapshot(root)
    if before != after:
        error("original_run_namespace_changed_during_closure")
    ordered_latency = sorted(latencies)
    def quantile(p):
        return ordered_latency[max(0, math.ceil(len(ordered_latency)*p)-1)] if ordered_latency else None
    result = {"schema_version": "restart-actual-smoke-owner-closure-v1", "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "model_id": plan["config"]["model"]["model_id"], "scope_complete": not errors,
        "root_acceptance": False, "formal_launch_authorized": False, "plan_ref": plan_ref, "execution_ref": execution_ref,
        "source_acceptance_ref": plan["config"]["source_acceptance_ref"], "source_tree_sha256": source["source_tree_sha256"],
        "source_files_rehashed": len(source_checked), "plan_bindings_rehashed": len(plan["file_bindings"]),
        "profile_ref": plan["config"]["profile_ref"], "request_profile": plan["config"]["profiles"], "policy": plan["config"]["policy"],
        "planned_invocations": len(planned), "closed_invocations": len(finished), "model_terminals": model_terminals,
        "result_JSON_files": len(physical), "terminal_classes": dict(classes),
        "model_no_answer_count": sum(job["terminal_status"].get("model_no_answer_count", 0) for job in jobs),
        "unscored_invocations": sum(job["terminal_status"].get("score_complete") is False for job in jobs),
        "raw_files": raw_count, "raw_states": dict(statuses), "wire_events": raw_events, "delivered_attempts": delivered,
        "non_success_attempts": raw_errors, "length_deliveries": lengths, "forced_none_deliveries": forced_none,
        "provider_reported_known_usage": dict(usage), "unknown_usage_counts": dict(unknown), "complete_provider_cost": None,
        "provider_reported_reasoning_tokens": reasoning_known, "reasoning_unknown_attempts": reasoning_unknown,
        "reasoning_is_subset_not_added_to_completion": True,
        "parent_elapsed_seconds_including_verification": execution.get("elapsed_seconds"),
        "physical_attempt_latency_seconds": {"count": len(latencies), "method": "empirical nearest rank",
            "p50": quantile(.5), "p90": quantile(.9), "p95": quantile(.95), "max": quantile(1)},
        "path_coverage": dict(coverage), "caller_pid_facts": facts, "local_caller_drain": True,
        "provider_queue_quiescence_proven": False, "new_model_calls": 0, "new_scorer_calls": 0,
        "namespace_unchanged": before == after, "original_inventory": before, "jobs": jobs, "errors": errors,
        "collector_ref": l.s.ref(__file__),
        "limitations": ["Reuses frozen owner raw/wire checks; not independent ROOT acceptance or performance analysis.",
            "Source scoring is the already-run model-forbidden resume; no repeated scorer execution in this collector.",
            "Missing forced branch or early answer is observed coverage, not smoke failure and never causes resampling.",
            "Full prompt identity review and provider-side observation are separate ROOT-owned checks."]}
    directory = l.s.io.new_directory(args.output_dir)
    reference = l.s.put(directory, "receipt.json", result)
    print(json.dumps(dict(reference, scope_complete=not errors, errors=len(errors)), sort_keys=True))
    return 0 if not errors else 2


if __name__ == "__main__":
    sys.exit(main())
