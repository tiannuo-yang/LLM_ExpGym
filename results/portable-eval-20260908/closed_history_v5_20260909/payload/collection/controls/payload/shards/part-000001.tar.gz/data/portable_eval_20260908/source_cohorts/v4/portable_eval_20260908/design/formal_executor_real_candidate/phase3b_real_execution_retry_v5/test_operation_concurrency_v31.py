"""Actual local Lustre processes vs original operation publication, CPU only.

Mechanically reuses the sealed peer's full-plan/grant/start fixture construction.
Only low-level write pauses and flock observations are injected; no journal,
parser, claim, authority-validator, source runner, model or secret FD is mocked
into success. Private grants are explicit CPU seams, never external ROOT GO.
"""
import copy
import fcntl
import json
import os
from pathlib import Path
import select
import signal
import threading
import time
import unittest
from unittest import mock

import real_common as c
import real_authority as auth
import real_journal as j
import real_runner_child as child
from test_real_execution import FixtureBase

PEER = Path("/lustrefs/users/chufan.shi/codex_space_tn/portable_eval_20260908/design/phase3b_real_execution_review_client_v3/child_concurrency")
PEER_PINS = {"probe.py": "5ff36640967d18f1dda916a2ae347a0cdafaaca71573274f020cd37b01b69594",
             "receipt.json": "d1807c50efdcecab7a2650c08e51c90ed948c4ba1f720089eae22ba440b7c0d3"}


def send(fd, value):
    body = c.encoded(value) + b"\n"
    if os.write(fd, body) != len(body):
        raise RuntimeError("short_CPU_control_message")


def receive(actor, timeout=30):
    deadline = time.monotonic() + timeout
    while b"\n" not in actor["buffer"]:
        remaining = deadline - time.monotonic()
        if remaining <= 0 or not select.select([actor["read_fd"]], [], [], remaining)[0]:
            raise AssertionError("bounded_CPU_child_handshake_timeout")
        chunk = os.read(actor["read_fd"], 65536)
        if not chunk:
            raise AssertionError("CPU_child_closed_without_terminal_observation")
        actor["buffer"] += chunk
    line, actor["buffer"] = actor["buffer"].split(b"\n", 1)
    value = json.loads(line.decode())
    actor["events"].append(value)
    return value


class OperationConcurrency(FixtureBase):
    @classmethod
    def setUpClass(cls):
        for name, checksum in PEER_PINS.items():
            if c.sha(PEER / name) != checksum:
                raise AssertionError("sealed_peer_concurrency_evidence_changed")
        c.verify()
        old = c.read(c.HERE.parents[1] / "formal_executor_candidate/validation/cpu_acceptance_v4_v3/plan.json")
        cls.plan = c.core().prepare_plan(old["candidate_path"], old["candidate_sha256"],
            {key: value["path"] for key, value in old["profiles"].items()}, old["policy"],
            c.main_source(), c.frozen.STUDY / "validation/static_acceptance_v4.json")
        if (len(cls.plan["candidate"]["invocations"]), len(cls.plan["candidate"]["logical_rows"])) != (2460, 2772):
            raise AssertionError("full_original_scientific_plan_required")

    def fixture(self, own_count=1, missing=False):
        self.actors = []
        self.identity = c.identity()
        selected = [x for x in self.plan["candidate"]["invocations"] if x["model"] == "m0" and x["system"] == "expgym"][:own_count + 1]
        self.selected, self.foreign = selected[:-1], selected[-1]
        now = time.time()
        self.study = {"kind": "CPU_CONCURRENCY_FIXTURE_NOT_AUTHORITY", "run_id": self.folder.name,
            "output_root": str(self.root), "validated_plan_view": self.plan,
            "operations": {"workers": 4, "max_http_attempts": 100000000, "max_wall_seconds": 3600,
                "stop_new_before_deadline_seconds": 1},
            "whole_study": {"not_before": now-60, "absolute_deadline": now+3600}}
        native = Path(os.environ["FORMAL_CPU_NATIVE_PYTHON"]).expanduser().absolute()
        legacy = Path(os.environ["FORMAL_CPU_LEGACY_RUNTIME"]).expanduser().absolute() / ".venv-hpo/bin/python"
        commands = []
        for inv in selected:
            command = c.core().fake_command(self.plan, inv, self.root, str(native), str(legacy))
            command[command.index("--backend")+1] = "openai"
            command[command.index("--tool-protocol")+1] = "native"
            command += ["--base-url", "https://concurrency-fixture.invalid/v1"]
            commands.append({"invocation_id": inv["invocation_id"], "command": command, "sha256": c.digest(command)})
        self.epoch = {"kind": "CPU_CONCURRENCY_FIXTURE_NOT_AUTHORITY", "identity": {
            "native_python": str(native), "legacy_python": str(legacy),
            "endpoint": "https://concurrency-fixture.invalid/v1", "valid_until": now+3600},
            "model": "m0", "epoch_id": 0, "previous_epoch_sha256": None, "commands": commands,
            "evidence": {"ready": {"sha256": "b"*64}}}
        self.go = {"output_root": str(self.root), "invocation_ids": [x["invocation_id"] for x in selected],
            "not_before": now-60, "valid_until": now+3600}
        grant = auth.RealGrant(auth._TOKEN, study=self.study, epoch=self.epoch, anchors={}, go=self.go)
        self.live = j.Journal(self.root, c.digest(self.study), self.plan["candidate"]["invocations"],
            self.plan["candidate"]["logical_rows"], create=True, capability=j.real_root_capability(grant))
        self.addCleanup(self.live.close)
        self.addCleanup(self.cleanup_children)
        auth.ensure_epoch_record(self.study, self.epoch, {}, self.live)
        specs, pinned = [], [self.root / "operations/epoch.m0.000000.json"]
        for inv in self.selected:
            iid = inv["invocation_id"]
            static = c.a3_module("owners").static_owners(c.core().logical_rows(self.plan, inv))
            record = next(x for x in commands if x["invocation_id"] == iid)
            if not missing:
                auth.reserve_invocation_attempts(self.study, self.live, iid)
                pinned.append(self.root / "operations" / ("budget."+iid+".json"))
            self.live.begin(iid, {"design_sha256": c.digest(self.study), "binding_sha256": c.digest(self.epoch),
                "phase3_implementation": self.identity, "command_sha256": record["sha256"], "static_owners": static,
                "execution_kind": "phase3b_real_gated_original_source", "producer_schema": auth.PRODUCER_SCHEMA})
            begin = self.root / "journal" / (iid+".start.json")
            identity = self.root / "logs" / iid / "actual_owner_identity.json"
            c.write(identity, {"static_owners_sha256": c.digest(static), "command_sha256": record["sha256"],
                "planned_owners": [{"owner_id": x["owner_id"]} for x in static]})
            specs.append({"invocation_id": iid, "command": record["command"], "logs": str(identity.parent),
                "dump_dir": str(self.root/inv["dump_relative_dir"]), "begin_path": str(begin), "begin_sha256": c.sha(begin),
                "identity_path": str(identity), "identity_sha256": c.sha(identity)})
            pinned.extend([begin, identity])
        self.own_pins = {str(path): c.sha(path) for path in pinned}
        self.assert_parent_lease_held()
        return specs

    def assert_parent_lease_held(self):
        self.assertIsNotNone(self.live._lease_fd)
        target = os.readlink("/proc/self/fd/%d" % self.live._lease_fd)
        fd = os.open(target, os.O_RDONLY | os.O_NOFOLLOW)
        try:
            self.assertEqual(os.fstat(fd).st_ino, os.fstat(self.live._lease_fd).st_ino)
            self.assertNotEqual(os.fstat(fd).st_ino, (self.root/"operations").stat().st_ino)
            with self.assertRaises(BlockingIOError):
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        finally:
            os.close(fd)

    def spawn_claim(self, spec):
        event_read, event_write = os.pipe()
        go_read, go_write = os.pipe()
        # Fork before any writer thread starts. No operations lock FD exists;
        # close the inherited manifest lease FD WITHOUT flock(LOCK_UN), which
        # would unlock the parent's shared open-file description as well.
        inherited = [fd for actor in self.actors for fd in (actor["read_fd"], actor["go_fd"])]
        pid = os.fork()
        if pid == 0:
            os.close(event_read); os.close(go_write)
            for fd in inherited:
                os.close(fd)
            inherited_lease = self.live._lease_fd
            if inherited_lease is not None:
                os.close(inherited_lease)
                self.live._lease_fd = None
            original_flock = fcntl.flock
            observed = [False]
            def observe_flock(fd, operation):
                target = os.readlink("/proc/self/fd/%d" % fd)
                first = not observed[0] and operation == fcntl.LOCK_SH and target == str(self.root/"operations")
                if first:
                    observed[0] = True
                    send(event_write, {"event": "operations_shared_wait", "pid": os.getpid(), "inode": os.fstat(fd).st_ino})
                result = original_flock(fd, operation)
                if first:
                    send(event_write, {"event": "operations_shared_acquired", "pid": os.getpid()})
                return result
            try:
                send(event_write, {"event": "ready", "pid": os.getpid(), "inherited_lease_closed_without_unlock": True})
                if not select.select([go_read], [], [], 30)[0] or os.read(go_read, 1) != b"G":
                    raise RuntimeError("CPU_claim_start_timeout")
                # Exact private grant is newly constructed in this child PID.
                grant = auth.RealGrant(auth._TOKEN, study=self.study, epoch=self.epoch, anchors={}, go=self.go)
                with mock.patch.object(fcntl, "flock", observe_flock):
                    claimed = child.claim_child(spec, self.study, self.epoch, grant)
                send(event_write, {"event": "terminal", "passed": True, "pid": os.getpid(),
                    "entry": {"path": str(claimed), "sha256": c.sha(claimed)}, "source_runner_processes": 0,
                    "model_calls": 0, "real_credentials_read": 0})
            except BaseException as exc:
                send(event_write, {"event": "terminal", "passed": False, "pid": os.getpid(),
                    "error_type": type(exc).__name__, "error": str(exc),
                    "cause_type": type(exc.__cause__).__name__ if exc.__cause__ else None})
            finally:
                os.close(go_read); os.close(event_write)
            os._exit(0)
        os.close(event_write); os.close(go_read)
        actor = {"pid": pid, "read_fd": event_read, "go_fd": go_write, "buffer": b"", "events": [], "reaped": False}
        self.actors.append(actor)
        self.assertEqual(receive(actor)["event"], "ready")
        return actor

    def until(self, actor, event):
        while True:
            value = receive(actor)
            if value["event"] == event:
                return value
            self.assertNotEqual(value["event"], "terminal", value)

    def finish_actor(self, actor):
        result = self.until(actor, "terminal")
        pid, status = os.waitpid(actor["pid"], 0)
        actor["reaped"] = True
        self.assertEqual((pid, status), (actor["pid"], 0))
        return result

    def cleanup_children(self):
        for actor in self.actors:
            if not actor["reaped"]:
                pid, _ = os.waitpid(actor["pid"], os.WNOHANG)
                if not pid:
                    os.kill(actor["pid"], signal.SIGKILL)
                    os.waitpid(actor["pid"], 0)
            os.close(actor["read_fd"]); os.close(actor["go_fd"])

    def seal(self, case, observations):
        self.assert_parent_lease_held()
        self.assertEqual(self.identity, c.identity())
        self.assertEqual(self.own_pins, {path: c.sha(path) for path in self.own_pins})
        for name, checksum in PEER_PINS.items():
            self.assertEqual(c.sha(PEER/name), checksum)
        c.write(self.folder / "CPU_ONLY_operation_concurrency_v31.json", {
            "classification": "Static/fake validation; local Lustre processes, not multi-host locking or ROOT GO",
            "case": case, "full_actual_plan": {"invocations": 2460, "logical_rows": 2772},
            "parent_pid": os.getpid(), "children": [{"pid": a["pid"], "events": a["events"]} for a in self.actors],
            "own_pins_unchanged": self.own_pins, "code_identity": self.identity, "sealed_peer": PEER_PINS,
            "observations": observations, "model_calls": 0, "source_runner_processes": 0,
            "actual_network_calls": self.network_calls, "real_credentials_read": 0,
            "synthetic_private_grants": True, "actual_external_GO_validated": False})

    def contention(self, corrupt=False):
        specs = self.fixture(own_count=1 if corrupt else 4)
        actors = [self.spawn_claim(spec) for spec in specs]
        partial, release = threading.Event(), threading.Event()
        path = self.root / "operations" / ("budget."+self.foreign["invocation_id"]+".json")
        original_write = os.write
        writer_errors = []
        def pause(fd, data):
            if threading.current_thread().name == "CPU-real-operation-writer" and os.readlink("/proc/self/fd/%d" % fd) == str(path):
                if not partial.is_set():
                    written = original_write(fd, data[:16])
                    partial.set()
                    if not release.wait(30):
                        raise OSError("bounded_CPU_write_pause_timeout")
                    if corrupt:
                        raise OSError("CPU_permanent_half_write")
                    return written
            return original_write(fd, data)
        def writer():
            try:
                auth.reserve_invocation_attempts(self.study, self.live, self.foreign["invocation_id"])
            except BaseException as exc:
                writer_errors.append(type(exc).__name__)
        with mock.patch.object(os, "write", pause):
            thread = threading.Thread(target=writer, name="CPU-real-operation-writer", daemon=True)
            thread.start()
            try:
                self.assertTrue(partial.wait(10), "Original writer never reached real 16-byte boundary")
                self.assertEqual(path.stat().st_size, 16)
                partial_sha = c.sha(path)
                for actor in actors:
                    os.write(actor["go_fd"], b"G")
                inode = (self.root/"operations").stat().st_ino
                for actor in actors:
                    self.assertEqual(self.until(actor, "operations_shared_wait")["inode"], inode)
                for actor, spec in zip(actors, specs):
                    self.assertFalse(actor["buffer"], actor["events"])
                    self.assertFalse(select.select([actor["read_fd"]], [], [], 0.2)[0], "Reader passed EX-protected partial bytes")
                    self.assertFalse((Path(spec["logs"])/"real_child_entry.json").exists())
            finally:
                release.set()
                thread.join(30)
        self.assertFalse(thread.is_alive(), "Writer did not release bounded operations lock")
        results = [self.finish_actor(actor) for actor in actors]
        # Children must finish while the parent's separate manifest lease is
        # still held. Closing the parent Journal must not be needed for reads.
        self.assert_parent_lease_held()
        if corrupt:
            self.assertEqual(writer_errors, ["OSError"])
            self.assertEqual(path.stat().st_size, 16)
            self.assertFalse(results[0]["passed"])
            self.assertEqual(results[0]["error_type"], "GateError")
            self.assertEqual(results[0]["error"], "child_journal_operations_not_valid")
            self.assertFalse((Path(specs[0]["logs"])/"real_child_entry.json").exists())
        else:
            self.assertEqual(writer_errors, [])
            self.assertTrue(all(value["passed"] for value in results), results)
            self.assertEqual(len({value["pid"] for value in results}), 4)
            self.assertGreater(path.stat().st_size, 16)
            self.assertEqual(c.read(path)["payload"]["invocation_id"], self.foreign["invocation_id"])
            self.assertIn(path.name, self.live._read_operations())
        self.seal("permanent_half_write" if corrupt else "four_children_foreign_publication", {
            "foreign_operation": str(path), "partial_bytes": 16, "partial_sha256": partial_sha,
            "final_sha256": c.sha(path), "writer_errors": writer_errors, "results": results,
            "parent_manifest_lease_held_through_child_completion": True,
            "children_observed_at_real_operations_SH_attempt_before_release": True})

    def test_four_actual_children_wait_for_foreign_16byte_publication_then_claim(self):
        self.contention()

    def test_permanent_half_write_releases_lock_but_strictly_rejects_claim(self):
        self.contention(corrupt=True)

    def test_wrong_own_sha_rejected_before_operations_wait_or_entry(self):
        spec = self.fixture()[0]
        actor = self.spawn_claim(dict(spec, begin_sha256="0"*64))
        os.write(actor["go_fd"], b"G")
        result = self.finish_actor(actor)
        self.assertFalse(result["passed"])
        self.assertEqual(result["error"], "child_begin_identity_changed")
        self.assertFalse(any(x["event"] == "operations_shared_wait" for x in actor["events"]))
        self.assertFalse((Path(spec["logs"])/"real_child_entry.json").exists())
        self.seal("wrong_own_sha", result)

    def test_missing_own_reservation_rejected_after_shared_read(self):
        spec = self.fixture(missing=True)[0]
        actor = self.spawn_claim(spec)
        os.write(actor["go_fd"], b"G")
        result = self.finish_actor(actor)
        self.assertFalse(result["passed"])
        self.assertEqual(result["error"], "child_exact_durable_attempt_reservation_required")
        self.assertTrue(any(x["event"] == "operations_shared_acquired" for x in actor["events"]))
        self.assertFalse((Path(spec["logs"])/"real_child_entry.json").exists())
        self.seal("missing_own_reservation", result)

    def test_duplicate_child_entry_remains_o_excl_rejected(self):
        spec = self.fixture()[0]
        first = self.spawn_claim(spec)
        os.write(first["go_fd"], b"G")
        accepted = self.finish_actor(first)
        self.assertTrue(accepted["passed"], accepted)
        entry = Path(spec["logs"])/"real_child_entry.json"
        before = c.sha(entry)
        second = self.spawn_claim(spec)
        os.write(second["go_fd"], b"G")
        rejected = self.finish_actor(second)
        self.assertFalse(rejected["passed"])
        self.assertEqual(rejected["error_type"], "FileExistsError")
        self.assertEqual(c.sha(entry), before)
        self.seal("duplicate_entry", {"first": accepted, "second": rejected, "entry_unchanged": True})


if __name__ == "__main__":
    unittest.main(verbosity=2)
