"""Read-only live-smoke terminal-input snapshots; never inspect answer quality."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import stat

HERE = Path(__file__).resolve().parent
STUDY = HERE.parents[2]
MARKERS = re.compile(r'hpobench|nasbench(?:[-_ ]?(?:101|201))?|paramnet|phantom[_ -]?wiki|contractnli|oracle|reference[_ -]?performance', re.I)
COUNT_HINT = re.compile(r'there may be 1 to \d+ correct answers', re.I)


def read(path):
    path = Path(path)
    if not path.is_absolute() or '..' in path.parts:
        raise ValueError('nonabsolute evidence path')
    for ancestor in [path] + list(path.parents):
        if ancestor.is_symlink():
            raise ValueError('symlink evidence path')
    fd = os.open(str(path), os.O_RDONLY | os.O_NOFOLLOW)
    try:
        first = os.fstat(fd)
        if not stat.S_ISREG(first.st_mode) or first.st_size > 128 * 1024 * 1024:
            raise ValueError('not bounded regular input')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read(128 * 1024 * 1024 + 1)
        last = os.fstat(fd)
    finally:
        os.close(fd)
    now = path.stat()
    stamp = lambda v: (v.st_dev, v.st_ino, v.st_size, v.st_mtime_ns, v.st_ctime_ns)
    if stamp(first) != stamp(last) or stamp(last) != stamp(now) or len(raw) != first.st_size:
        raise ValueError('changed during snapshot read')
    return raw, {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw), 'mtime_ns': now.st_mtime_ns}


def scan_strings(value, pointer):
    if isinstance(value, str):
        return [{'pointer': pointer, 'marker': match.group().lower()} for match in MARKERS.finditer(value)]
    result = []
    if isinstance(value, dict):
        for key, child in value.items():
            result += scan_strings(child, pointer + '/' + str(key).replace('~', '~0').replace('/', '~1'))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            result += scan_strings(child, pointer + '/' + str(index))
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', choices=['glm-5.3', 'kimi-k3'], required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists() or args.output.parent != HERE:
        raise ValueError('fresh direct peer output directory required')
    plan_path = HERE.parent / ('compiled_restart-20260909-v5-' + args.model + '-smoke/plan.json')
    plan_bytes, plan_ref = read(plan_path)
    plan = json.loads(plan_bytes)
    config = plan['config']
    assert config['model']['label'] == args.model
    source_bytes, source_ref = read(Path(config['source_acceptance_ref']['path']))
    assert source_ref['sha256'] == config['source_acceptance_ref']['sha256']
    profile_bytes, profile_ref = read(Path(config['profile_ref']['path']))
    assert profile_ref['sha256'] == config['profile_ref']['sha256']
    profile = config['profiles'][args.model]
    rows, skipped, issues, marker_hits = [], [], [], []
    coverage, covered_jobs = Counter(), set()
    for job in plan['jobs']:
        dump = Path(job['dump_dir'])
        if not dump.exists():
            continue
        for path in sorted(dump.glob('*.json')):
            try:
                raw_bytes, ref = read(path)
                raw = json.loads(raw_bytes)
            except (ValueError, OSError) as exc:
                skipped.append({'path': str(path), 'reason': type(exc).__name__})
                continue
            if raw.get('state') != 'success' or not raw.get('finished_at_utc'):
                skipped.append({'path': str(path), 'reason': 'not_completed_success', 'state': raw.get('state')})
                continue
            payload = raw['request_payload']
            context = raw['context']
            owner_context = context.get('job') if context.get('runner') == 'expgym' else context
            if not isinstance(owner_context, dict):
                raise ValueError('Malformed original owner context')
            entry_issues = []
            checks = {'model': config['model']['model_id'], 'max_tokens': config['policy']['max_tokens'],
                      'reasoning_effort': profile['reasoning_effort'], 'chat_template_kwargs': profile['chat_template_kwargs'],
                      'parallel_tool_calls': False}
            for key, expected in checks.items():
                if payload.get(key) != expected:
                    entry_issues.append({'field': key, 'reason': 'plan_request_mismatch'})
            for key in ('temperature', 'top_p'):
                value, expected = payload.get(key), profile[key]
                if type(value) not in (int, float) or not math.isfinite(value) or value != expected:
                    entry_issues.append({'field': key, 'reason': 'plan_numeric_mismatch'})
            if payload.get('top_k') != profile.get('top_k'):
                entry_issues.append({'field': 'top_k', 'reason': 'plan_request_mismatch'})
            if payload.get('seed') not in job['sampling_seed_labels'] or type(payload.get('seed')) is not int:
                entry_issues.append({'field': 'seed', 'reason': 'not_declared_owner_seed'})
            choice = payload.get('tool_choice')
            if choice not in ('auto', 'none'):
                entry_issues.append({'field': 'tool_choice', 'reason': 'unexpected_task_choice'})
            if owner_context.get('scenario') != job['scenario'] or raw.get('request_id') != path.stem:
                entry_issues.append({'field': 'identity', 'reason': 'context_or_request_mismatch'})
            messages = payload['messages']
            first_user = next((i for i, m in enumerate(messages) if m.get('role') == 'user'), None)
            local_hits = []
            for hit in scan_strings(payload.get('tools'), '/tools'):
                local_hits.append(dict(hit, origin='source_tool_schema'))
            graph_count = 0
            excluded_assistant_messages = 0
            for index, message in enumerate(messages):
                role = message.get('role')
                if role == 'assistant':
                    excluded_assistant_messages += 1
                    continue
                text = message.get('content')
                if not isinstance(text, str):
                    continue
                graph_count += text.count('[Parallel Exploration')
                origin = 'source_system' if role == 'system' else 'environment_or_model_derived_history'
                if index == first_user:
                    origin = 'source_task_template'
                    if job['scenario'] == 'restricted_search':
                        text = text.split('\nQuestion: ', 1)[0]
                        if COUNT_HINT.search(text):
                            entry_issues.append({'field': '/messages/' + str(index), 'reason': 'source_gold_count_hint_present'})
                    elif job['scenario'] == 'evidence_audit':
                        text = text.split('\nDocument segments:', 1)[0]
                for hit in scan_strings(text, '/messages/' + str(index) + '/content'):
                    local_hits.append(dict(hit, origin=origin))
            for hit in local_hits:
                if hit['origin'] in ('source_tool_schema', 'source_system', 'source_task_template'):
                    entry_issues.append({'field': hit['pointer'], 'reason': 'explicit_identity_or_reference_marker', 'marker': hit['marker']})
            strategy = context.get('strategy', 'single')
            group = (job['scenario'], job['runtime_profile_required'], job['system'], strategy, choice)
            coverage[group] += 1
            covered_jobs.add(job['invocation_id'])
            row = {'raw_ref': ref, 'invocation_id': job['invocation_id'], 'client_id': raw['client_id'],
                   'generation_id': raw['generation_id'], 'attempt': raw['attempt'], 'scenario': job['scenario'],
                   'runtime': job['runtime_profile_required'], 'system': job['system'], 'strategy': strategy,
                   'tool_choice': choice, 'parameter_checks_ok': not entry_issues,
                   'task_selector': owner_context.get('tuning_task') if job['scenario'] == 'tuning' else owner_context.get('question_index'),
                   'pool_graph_message_occurrences': graph_count, 'assistant_history_messages_excluded': excluded_assistant_messages,
                   'markers': local_hits, 'issues': entry_issues}
            rows.append(row)
            marker_hits += [{'raw_ref': ref, **v} for v in local_hits]
            issues += [{'raw_ref': ref, **v} for v in entry_issues]
    changed = []
    for row in rows:
        _, current = read(Path(row['raw_ref']['path']))
        if current != row['raw_ref']:
            changed.append(row['raw_ref']['path'])
    report = {'schema_version': 'actual-smoke-wire-prompt-snapshot-v1', 'model': args.model,
              'snapshot_at_utc': datetime.now(timezone.utc).isoformat(), 'plan_ref': plan_ref,
              'inspector_ref': read(Path(__file__).absolute())[1], 'inspector_revision': 'v2-expgym-nested-owner-context',
              'source_acceptance_ref': source_ref, 'profile_ref': profile_ref,
              'completed_success_requests_checked': len(rows), 'rows': rows, 'skipped': skipped,
              'coverage': [{'scenario': k[0], 'runtime': k[1], 'system': k[2], 'strategy': k[3], 'tool_choice': k[4], 'requests': v} for k,v in sorted(coverage.items())],
              'planned_invocations': len(plan['jobs']), 'covered_invocations': len(covered_jobs),
              'uncovered_invocation_ids': [j['invocation_id'] for j in plan['jobs'] if j['invocation_id'] not in covered_jobs],
              'issues': issues, 'marker_hits': marker_hits, 'checked_terminal_inputs_unchanged': not changed,
              'changed_after_read': changed, 'no_source_marker_or_request_mismatch_in_checked_scope': not issues and not changed,
              'complete_run_or_all_attempt_audit': False, 'model_calls': 0, 'scorer_calls': 0,
              'limits': ['Live namespace snapshot, not final completeness or source/authority admission.',
                         'Only completed success input payloads are assessed. Pending/error entries are listed, not given a prompt PASS.',
                         'All response bodies and assistant history text are excluded from inspection; source questions/documents are not globally sanitized.',
                         'Later tool/user history markers require provenance review; graph text may include model-derived claims.',
                         'Preserved legal parameter schemas, budgets, task structure and feedback may identify a benchmark; training contamination is not disproven.']}
    args.output.mkdir(exist_ok=False)
    output = args.output/'report.json'
    output.write_text(json.dumps(report, ensure_ascii=False, sort_keys=True, allow_nan=False)+'\n')
    _, output_ref = read(output)
    print(json.dumps({'report': output_ref, 'completed_success_requests_checked': len(rows), 'covered_invocations': len(covered_jobs), 'issues': issues, 'skipped': len(skipped)}))


if __name__ == '__main__':
    main()

