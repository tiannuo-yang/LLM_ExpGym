"""Real pre-wire adapter of frozen 3B's per-attempt payload/history gate.
No added retries; returned HTTP bytes do not prove a model generated them.
"""
import copy
import json
import os
import re
from pathlib import Path
import threading
import time

import real_common as common
from real_authority import AuthorityError, RealGrant, endpoint


class GateError(RuntimeError):
    pass


class AttemptGate:
    def __init__(self, *, grant, invocation_id, client, planned, profile, policy,
                 dump_dir, evidence_dir, begin_path, identity_path, initial_messages, delegate):
        if type(grant) is not RealGrant or getattr(delegate, "real_grant", None) is not grant:
            raise GateError("exact_real_grant_and_bound_authorized_delegate_required")
        for path in (dump_dir, evidence_dir, begin_path, identity_path):
            common.scoped(path).relative_to(common.scoped(grant.go["output_root"]))
        self.grant, self.invocation_id, self.client = grant, invocation_id, client
        self.planned, self.profile, self.policy = copy.deepcopy(planned), copy.deepcopy(profile), copy.deepcopy(policy)
        self.dump_dir, self.evidence_dir = common.scoped(dump_dir), common.scoped(evidence_dir)
        self.begin_path, self.identity_path = Path(begin_path), Path(identity_path)
        self.binding = {"begin_sha256": common.sha(begin_path), "identity_sha256": common.sha(identity_path)}
        self.initial_messages = copy.deepcopy(initial_messages)
        self.delegate, self._lock = delegate, threading.Lock()
        self._seen, self._generation_attempts, self._generation_payloads = set(), {}, {}
        self._first, self._count = True, 0
        if not client.dump_metadata or client.dump_metadata["run_id"] is None:
            raise GateError("raw_dump_required_before_transport")
        self._pending_id = None
        self._pending_metadata = None
        self._pending_lock = threading.RLock()
        original_dump = client._dump_attempt
        if getattr(client, "_phase3b_real_dump_observer", False):
            raise GateError("one_dump_observer_per_client_required")

        def observed_dump(metadata, payload, started, **kwargs):
            rid, state = metadata.get("request_id"), kwargs.get("state")
            with self._pending_lock:
                if not isinstance(rid, str) or re.fullmatch(r"[0-9a-f]{32}", rid) is None:
                    raise GateError("exact_source_request_id_required")
                if state not in ("in_progress", "error", "success", "malformed_response"):
                    raise GateError("unregistered_source_dump_state")
                if state == "in_progress" and self._pending_id is not None:
                    raise GateError("same_client_overlapping_attempt_forbidden")
                if state != "in_progress" and rid != self._pending_id:
                    raise GateError("terminal_attempt_must_match_pending_source_identity")
                if state != "in_progress" and common.encoded(metadata) != common.encoded(self._pending_metadata):
                    raise GateError("terminal_metadata_must_match_pending_source_identity")
                # Capture only after the unchanged writer's atomic write succeeds.
                try:
                    result = original_dump(metadata, payload, started, **kwargs)
                except BaseException:
                    self.grant.revoked = True
                    raise
                if state == "in_progress":
                    self._pending_id = rid
                    self._pending_metadata = copy.deepcopy(metadata)
                elif rid == self._pending_id:
                    self._pending_id = None
                    self._pending_metadata = None
                return result
        client._dump_attempt = observed_dump
        client._phase3b_real_dump_observer = True

    def _write(self, request_id, event, fields):
        value = dict(
            schema_version="phase3b-real-attempt-operation-v1", kind=event,
            invocation_id=self.invocation_id, owner_id=self.planned["owner_id"],
            request_id=request_id, client_id=self.client.dump_metadata["client_id"],
            epoch_sha256=self.grant.epoch_sha256, begin_path=str(self.begin_path), identity_path=str(self.identity_path),
            **self.binding, **self._current_identity)
        value.update(fields)
        common.write(self.evidence_dir / (request_id + "." + event + ".json"), value)

    def _pending(self):
        if self.dump_dir.is_symlink():
            raise GateError("unsafe_dump_root")
        with self._pending_lock:
            if self._pending_id is None:
                raise GateError("source_writer_did_not_confirm_pending_attempt")
            path = self.dump_dir / (self._pending_id + ".json")
            value = common.read(path)
            if any(common.encoded(value.get(key)) != common.encoded(expected) for key, expected in self._pending_metadata.items()):
                raise GateError("exact_captured_source_metadata_required")
        if value.get("client_id") != self.client.dump_metadata["client_id"] or value.get("state") != "in_progress":
            raise GateError("exact_own_pending_attempt_required")
        return path, value

    def _validate(self, request, timeout, path, raw):
        self.grant.check(self.invocation_id)
        if common.sha(self.begin_path) != self.binding["begin_sha256"] or common.sha(self.identity_path) != self.binding["identity_sha256"]:
            raise GateError("begin_or_actual_identity_changed")
        if (raw.get("schema_version") != "expgym.api_attempt.v1" or raw.get("context") != self.planned["context"]
                or raw.get("run_id") != self.client.dump_metadata["run_id"] or raw.get("pid") != os.getpid()
                or raw.get("thread_id") != threading.get_ident() or path.stem != raw.get("request_id")):
            raise GateError("pending_attempt_owner_identity_mismatch")
        rid, generation, attempt = raw["request_id"], raw.get("generation_id"), raw.get("attempt")
        if not isinstance(generation, str) or not generation or type(attempt) is not int or attempt < 1:
            raise GateError("invalid_generation_attempt_identity")
        if (rid in self._seen or attempt != self._generation_attempts.get(generation, 0) + 1
                or raw.get("max_attempts") != self.policy["max_retries"] + 1 or attempt > raw["max_attempts"]):
            raise GateError("duplicate_or_nonsequential_attempt")
        if self._count >= self.grant.max_attempts:
            raise GateError("registered_attempt_limit_reached")
        wanted_url = endpoint(self.grant.epoch["identity"]["endpoint"], cpu=False) + "/chat/completions"
        if request.full_url != wanted_url or raw.get("endpoint") != wanted_url or timeout != self.policy["request_timeout"]:
            raise GateError("request_endpoint_or_timeout_changed")
        if (request.get_method() != "POST" or set(k.lower() for k in request.headers) != {"authorization", "content-type"}
                or request.unredirected_hdrs or request.get_header("Content-type") != "application/json"):
            raise GateError("unregistered_method_or_header")
        # Credentials only compared in memory, never recorded or separately hashed.
        if request.get_header("Authorization") != "Bearer " + self.client.config.api_key:
            raise GateError("credential_changed")
        try:
            payload = json.loads(request.data.decode("utf-8"), parse_constant=lambda value: (_ for _ in ()).throw(ValueError("nonfinite")))
        except Exception as exc:
            raise GateError("invalid_request_json") from exc
        safe_payload = self.client._redact_dump_value(payload)
        if safe_payload != raw.get("request_payload"):
            raise GateError("pending_and_transport_payload_differ")
        fields = {"model": self.profile["model"], "temperature": self.profile["temperature"], "top_p": self.profile["top_p"],
            "seed": self.planned["seed"], "max_tokens": self.policy["max_tokens"], "tools": self.planned["schemas"], "parallel_tool_calls": False}
        for name in ("top_k", "reasoning_effort", "chat_template_kwargs"):
            if self.profile.get(name) is not None and (name != "chat_template_kwargs" or self.profile[name]):
                fields[name] = self.profile[name]
        if set(payload) != set(fields) | {"messages", "tool_choice"}:
            raise GateError("unregistered_payload_fields")
        if any(common.encoded(payload.get(k)) != common.encoded(v) for k, v in fields.items()) or payload["tool_choice"] not in ("auto", "none"):
            raise GateError("request_profile_seed_schema_or_tool_choice_changed")
        messages = payload["messages"]
        history_errors = common.a3_module("raw_scope").strict_native_history(messages)
        if history_errors:
            raise GateError("native_history_not_well_formed")
        if generation in self._generation_payloads and self._generation_payloads[generation] != common.digest(safe_payload):
            raise GateError("retry_payload_changed")
        if self._first:
            if len(messages) < len(self.initial_messages):
                raise GateError("missing_actual_task_context")
            for expected, actual in zip(self.initial_messages, messages):
                if expected["role"] != actual.get("role"):
                    raise GateError("rendered_initial_role_changed")
                # Shared graph additions are dynamic source-owned suffixes, not
                # invented static preflight state. Full prefix is audited later.
                if expected["role"] == "user" and self.planned["context"]["runner"] == "poolact":
                    if not isinstance(actual.get("content"), str) or not actual["content"].startswith(expected["content"]):
                        raise GateError("rendered_initial_task_changed")
                elif actual.get("content") != expected["content"]:
                    raise GateError("rendered_initial_message_changed")
        return rid, generation, attempt, safe_payload

    def __call__(self, request, timeout):
        if not self._lock.acquire(blocking=False):
            raise GateError("same_client_concurrent_generate_forbidden")
        rid, delegate_error = None, None
        try:
            path, raw = self._pending()
            rid = raw.get("request_id")
            self._current_identity = {name: raw.get(name) for name in ("generation_id", "attempt", "run_id")}
            try:
                rid, generation, attempt, payload = self._validate(request, timeout, path, raw)
            except Exception as exc:
                self.grant.revoked = True
                if isinstance(rid, str) and rid == path.stem:
                    self._write(rid, "attempt_rejected", {"delegate_entered": False, "send_status": "not_sent",
                        "error_type": type(exc).__name__, "pending_raw_sha256": common.sha(path)})
                raise
            fields = {"generation_id": generation, "attempt": attempt, "run_id": raw["run_id"],
                "pending_raw_sha256": common.sha(path), "redacted_payload_sha256": common.digest(payload),
                "send_status": "send_unknown", "first_client_attempt": self._first,
                "initial_stable_context_verified": self._first, "dynamic_history_semantics": "post_run_source_reconstruction"}
            self.grant.consume_attempt(self.invocation_id)
            self._write(rid, "attempt_gate", fields)
            self._seen.add(rid)
            self._generation_attempts[generation] = attempt
            self._generation_payloads[generation] = common.digest(payload)
            self._count += 1
            self._first = False
            # A successfully written marker records intent to enter, not receipt
            # by a provider. Crashes anywhere after gate remain unknown.
            self._write(rid, "transport_enter", {"send_status": "send_unknown", "delegate_kind": "authorized_real_bytes"})
            self.grant.arm_transport(self.invocation_id, request, timeout,
                self.evidence_dir / (rid + ".attempt_gate.json"), self.evidence_dir / (rid + ".transport_enter.json"))
            started = time.monotonic()
            try:
                response = self.delegate(request, timeout)
            except Exception as exc:
                self._write(rid, "transport_error", {"send_status": "send_unknown", "error_type": type(exc).__name__,
                    "wall_seconds": time.monotonic() - started})
                delegate_error = exc
                raise
            if not isinstance(response, bytes):
                raise GateError("byte_delegate_contract_broken")
            unsafe = self.client.config.api_key.encode("utf-8") in response
            try:
                parsed_response = json.loads(response.decode("utf-8"))
            except (ValueError, UnicodeError):
                parsed_response = None
            if parsed_response is not None and self.client._redact_dump_value(parsed_response) != parsed_response:
                unsafe = True
            if unsafe:
                # The frozen client redacts raw dumps, but an echoed credential
                # must not reach canonical assistant traces or source logs at all.
                self._write(rid, "transport_error", {"send_status": "send_unknown", "error_type": "ReflectedCredentialRejected",
                    "wall_seconds": time.monotonic() - started, "response_received_but_not_persisted": True})
                raise GateError("provider_reflected_credential_stop_new")
            self._write(rid, "transport_return", {"response_bytes": len(response), "send_status": "http_response_bytes_returned",
                "wall_seconds": time.monotonic() - started, "provider_received_proven": False})
            return response
        except Exception as exc:
            # Filesystem failure must not fall through as a transient retry.
            # HTTP/transport delegate exceptions retain the source retry policy.
            if exc is delegate_error:
                raise
            self.grant.revoked = True
            if isinstance(exc, (GateError, AuthorityError)):
                raise
            raise GateError("gate_failure_" + type(exc).__name__) from exc
        finally:
            self._lock.release()


def _terminal_abort_with_returned_bytes(raw, returned_event):
    """Transport returned bytes; the provider abort is never a usable completion."""
    error = raw.get("error")
    body = raw.get("response_raw")
    if (raw.get("state") != "error" or not isinstance(error, dict)
            or error.get("type") != "APICompletionAbortedError"
            or raw.get("will_retry") is not False
            or "retry_delay_seconds" not in raw or raw["retry_delay_seconds"] is not None
            or not isinstance(body, str)):
        return False
    try:
        response = common.a3_module("support").raw.strict_record(body)
        if not isinstance(response, dict):
            return False
        choices = response.get("choices")
        count = returned_event.get("response_bytes")
        return (common.encoded(response) == common.encoded(raw.get("response_json"))
                and isinstance(choices, list) and bool(choices)
                and isinstance(choices[0], dict) and choices[0].get("finish_reason") == "abort"
                and type(count) is int and count == len(body.encode("utf-8")))
    except (ValueError, TypeError, KeyError, UnicodeError, RecursionError):
        return False


def inventory(evidence_dir, dump_dir):
    """Strict operational linkage; unknown/bad events never establish not_sent."""
    groups, issues = {}, []
    allowed = {"attempt_gate", "attempt_rejected", "transport_enter", "transport_return", "transport_error"}
    required = {"schema_version", "kind", "invocation_id", "owner_id", "request_id", "client_id", "epoch_sha256",
        "begin_path", "identity_path", "begin_sha256", "identity_sha256", "generation_id", "attempt", "run_id"}
    identity_keys = required - {"schema_version", "kind"}
    invalid_ids = set()
    for p in sorted(Path(evidence_dir).glob("*.json")):
        rid = p.name.split(".")[0]
        try:
            v = common.read(p)
            key, event = v["request_id"], v["kind"]
            if (not required.issubset(v) or v["schema_version"] != "phase3b-real-attempt-operation-v1" or event not in allowed
                    or key + "." + event + ".json" != p.name or event in groups.setdefault(key, {})):
                raise ValueError("invalid_event_schema_or_filename")
            if type(v["attempt"]) is not int or v["attempt"] < 1:
                raise ValueError("invalid_attempt")
            for field in ("epoch_sha256", "begin_sha256", "identity_sha256"):
                if not isinstance(v[field], str) or re.fullmatch(r"[0-9a-f]{64}", v[field]) is None:
                    raise ValueError("invalid_event_sha")
            for field in ("begin", "identity"):
                path = common.scoped(v[field + "_path"])
                if common.sha(path) != v[field + "_sha256"]:
                    raise ValueError("event_binding_artifact_changed")
            groups[key][event] = {"sha256": common.sha(p), "value": v}
        except Exception as exc:
            invalid_ids.add(rid)
            issues.append({"path": str(p), "error_type": type(exc).__name__})
    attempts = []
    for p in sorted(Path(dump_dir).glob("*.json")):
        try:
            raw = common.read(p)
            rid = raw["request_id"]
            events = groups.pop(rid, {})
            valid = bool(events) and rid not in invalid_ids
            values = [x["value"] for x in events.values()]
            if values:
                first = values[0]
                for value in values:
                    if any(common.encoded(value[k]) != common.encoded(first[k]) for k in identity_keys):
                        valid = False
                    if any(value[k] != raw.get(k) for k in ("request_id", "client_id", "generation_id", "attempt", "run_id")):
                        valid = False
            kinds = set(events)
            rejected = kinds == {"attempt_rejected"}
            complete = kinds in ({"attempt_gate", "transport_enter", "transport_return"},
                                 {"attempt_gate", "transport_enter", "transport_error"})
            partial = kinds in ({"attempt_gate"}, {"attempt_gate", "transport_enter"})
            if not (rejected or complete or partial):
                valid = False
            if rejected:
                value = events["attempt_rejected"]["value"]
                valid = valid and value.get("delegate_entered") is False and value.get("send_status") == "not_sent" and raw.get("state") == "error"
            if "attempt_gate" in events:
                value = events["attempt_gate"]["value"]
                valid = valid and value.get("redacted_payload_sha256") == common.digest(raw.get("request_payload")) and value.get("send_status") == "send_unknown"
            if "transport_enter" in events:
                valid = valid and events["transport_enter"]["value"].get("delegate_kind") == "authorized_real_bytes"
            abort_returned = ("transport_return" in events and
                              _terminal_abort_with_returned_bytes(raw, events["transport_return"]["value"]))
            returned = ("transport_return" in events and
                        ((raw.get("state") in ("success", "malformed_response")
                          and raw.get("response_raw") is not None) or abort_returned))
            if "transport_return" in events:
                valid = valid and events["transport_return"]["value"].get("provider_received_proven") is False
                if raw.get("state") == "error":
                    valid = valid and abort_returned
            if not valid:
                issues.append({"request_id": rid, "code": "missing_invalid_or_conflicting_attempt_chain"})
            status = "not_sent" if valid and rejected else "http_response_bytes_returned" if valid and complete and returned else "send_unknown"
            attempts.append({"request_id": rid, "raw_state": raw.get("state"), "raw_sha256": common.sha(p),
                "send_status": status, "operation_chain_valid": valid, "events": {k: v["sha256"] for k, v in events.items()}})
        except Exception as exc:
            issues.append({"path": str(p), "error_type": type(exc).__name__})
    if groups:
        issues.append({"code": "orphan_attempt_events", "request_ids": sorted(groups)})
    return {"schema_version": "phase3b-real-send-inventory-v1", "attempts": attempts, "issues": issues,
        "raw_attempts": len(attempts), "not_sent": sum(x["send_status"] == "not_sent" for x in attempts),
        "send_unknown": sum(x["send_status"] == "send_unknown" for x in attempts),
        "http_response_bytes_returned": sum(x["send_status"] == "http_response_bytes_returned" for x in attempts),
        "provider_received_proven": False, "model_generation_count": None}
