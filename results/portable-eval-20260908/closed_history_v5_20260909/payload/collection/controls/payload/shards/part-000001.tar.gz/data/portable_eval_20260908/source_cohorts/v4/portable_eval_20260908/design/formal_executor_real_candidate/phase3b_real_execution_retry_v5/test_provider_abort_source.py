"""New-cohort original-runner abort: no answer, no redraw, all raw cost retained."""
from pathlib import Path
import sys
from unittest import mock

import real_common as common
import real_authority as auth
import real_invocation as invocation
import real_journal as journal
import secret_fd
from test_real_execution import FixtureBase, KEY
import test_source_integration as source_fixture


class ProviderAbortSourceTests(FixtureBase):
    make_case = source_fixture.SourceIntegration.make_case

    def test_abort_first_audit_owner_stops_invocation_and_blocks_regeneration(self):
        study, epoch, anchors, chosen, instance, grant = self.make_case("expgym", "evidence_audit")
        original, child_calls = secret_fd.run_child, []

        def abort_child(command, cwd, env, log, *, secret):
            child_calls.append(list(command))
            argv = list(command)
            index = argv.index("--spec") + 1
            spec = common.read(argv[index])
            spec.update(cpu_fixture_boundary=True, cpu_fixture_provider_abort=True)
            fixture_spec = Path(argv[index]).with_name("cpu_abort_child_spec.json")
            common.write(fixture_spec, spec)
            argv[index], argv[2] = str(fixture_spec), str(common.HERE / "cpu_child_fixture.py")
            return original(argv, cwd, env, log, secret=secret)

        with mock.patch.object(auth, "validate_real_authority", return_value=grant), \
             mock.patch.object(auth, "verify_epoch"), \
             mock.patch.object(secret_fd, "run_child", abort_child):
            report = invocation.execute_real_invocation(study, epoch, anchors, chosen["invocation_id"], instance, secret=KEY)
        self.assertEqual(len(child_calls), 1)
        self.assertFalse(report["passed"])
        self.assertFalse(report["resume"]["executed"])
        self.assertEqual(len(report["owners"]), 3)
        self.assertEqual(set(report["logical_results"]), set(chosen["logical_ids"]))
        self.assertEqual(len(report["logical_results"]), 3)
        self.assertTrue(all(not owner["owner_evidence_qualified"] for owner in report["owners"]))
        self.assertTrue(all(row["state"] == "infrastructure_failed" for row in report["logical_results"].values()))
        attempts = report["attempt_operations"]
        self.assertEqual(attempts["issues"], [])
        self.assertEqual(attempts["raw_attempts"], 1)
        self.assertEqual(attempts["http_response_bytes_returned"], 1)
        self.assertEqual(attempts["send_unknown"], 0)
        self.assertEqual(attempts["attempts"][0]["raw_state"], "error")
        usage = report["accounting"]["totals_all_attempts"]["provider_usage"]
        for name, expected in (("input_tokens", 2901), ("output_tokens", 908), ("reasoning_tokens", 754)):
            self.assertEqual(usage[name]["known_sum"], expected)
            self.assertIsNone(usage[name]["complete_total"])
        dump = self.root / chosen["dump_relative_dir"]
        raw = common.read(next(dump.glob("*.json")))
        self.assertEqual(raw["error"]["type"], "APICompletionAbortedError")
        self.assertIs(raw["will_retry"], False)
        self.assertEqual(raw["response_json"]["choices"][0]["finish_reason"], "abort")
        selected = self.root / chosen["output_relative_dir"]
        snapshot = common.a3_module("support").safe_snapshot
        before = {"results": snapshot(selected), "dumps": snapshot(dump)}
        command = epoch["commands"][0]["command"]
        env = common.core().environment(common.main_source(), dump, study["run_id"],
            Path(epoch["identity"]["legacy_python"]).parents[2])
        env["OPENAI_API_KEY"] = auth.NOAUTH
        # The original runner's missing-result resume must hit the no-generation
        # guard, never be falsely accepted as a verified skip.
        process, text = common.core().run_child(invocation.guard_command(command, "resume"),
            common.main_source(), env, self.folder / "failed_resume_guard.log")
        self.assertNotEqual(process["exit_code"], 0)
        self.assertIn("FORMAL_MODEL_CONSTRUCTION_AND_CALL_FORBIDDEN", text)
        self.assertNotIn("skip verified", text)
        self.assertEqual(before, {"results": snapshot(selected), "dumps": snapshot(dump)})
        with mock.patch.object(auth, "validate_real_authority", return_value=grant), \
             mock.patch.object(auth, "ensure_epoch_record"), \
             mock.patch.object(secret_fd, "run_child", side_effect=AssertionError("failed begun invocation must not repeat")):
            with self.assertRaises((auth.AuthorityError, journal.JournalError, FileExistsError)):
                invocation.execute_real_invocation(study, epoch, anchors, chosen["invocation_id"], instance, secret=KEY)
        common.write(self.folder / "CPU_ONLY_provider_abort_source.json", {
            "classification": "CPU fake wire and synthetic private grant; not a real model response or ROOT authority",
            "fault": "provider_abort", "result": report, "child_call_count": len(child_calls),
            "source_child_interpreter": epoch["commands"][0]["command"][0],
            "outer_test_interpreter": sys.executable,
            "source_child_runtime_notice": "Audit source child uses the explicitly bound native interpreter even when the outer test runs in legacy Python",
            "all_child_network_blocked": True, "synthetic_key_only": True, "actual_model_calls": 0,
            "failed_resume_guard": process, "failed_resume_was_verified_skip": False,
            "result_and_dump_bytes_unchanged": True, "begun_failed_invocation_regeneration_blocked": True})
