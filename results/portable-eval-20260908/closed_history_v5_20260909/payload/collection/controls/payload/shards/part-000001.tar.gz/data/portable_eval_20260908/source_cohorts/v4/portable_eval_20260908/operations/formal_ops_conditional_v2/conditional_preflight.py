"""Pure read-only qualification gate at the specified ROOT operations entry."""
from pathlib import Path

SCHEMA = "formal-protocol-conditional-admission-v1"
AUDIT_SCHEMA = "development-v6-conditional-independent-audit-v1"
QUALIFICATION = "conditional_native_path_coverage"
STUDY = Path(__file__).absolute().parents[2]
PRODUCER_REF = {"path": str(STUDY / "design/fresh_live_evidence_v4_candidate_v8/producer.py"),
                "sha256": "824c54caa6259d5ed73b3fdf8e8da3c0e08b093bb1a5f7ccd1acf5a55a39d14b"}
SOURCE = "b280a0f640ffab8aa90bc74df4c9ecf3189b375cdd674094a005b3569bb4b608"


def require(ok, rule):
    if not ok:
        raise ValueError(rule)


def same(left, right, io, rule):
    require(io.canonical(left) == io.canonical(right), rule)


def pair(ref):
    require(type(ref) is dict and set(ref) == {"path", "sha256"}, "conditional_exact_ref_required")
    return ref


def check(inputs, *, mode, io):
    """No key path inspection, writes, imports, authority minting or scoring."""
    require(mode in ("epoch", "run"), "conditional_preflight_mode_required")
    key_path = inputs.get("key_file") if mode == "run" else None
    def guard(value):
        if type(value) is dict:
            if key_path is not None and value.get("path") == key_path:
                raise ValueError("conditional_secret_cannot_be_evidence")
            for child in value.values():
                guard(child)
        elif type(value) is list:
            for child in value:
                guard(child)
    def read(ref):
        guard(ref)
        value = io.read_json_ref(pair(ref))
        guard(value)
        return value
    guard(inputs)
    admission_ref = pair(inputs["protocol_admission"])
    admission = read(admission_ref)
    require(type(admission) is dict and set(admission) == {
        "schema_version", "issuer", "accepted", "evidence_kind", "qualification",
        "audit_ref", "conditional_decision_ref", "model_id", "deployment_id", "deployment",
        "profile", "profile_sha256", "source_tree_sha256", "selected_job_ids", "expected_agent_traces",
        "original_auto_passed", "strict_named_gate_passed", "original_audit_overall_qualified",
        "scope", "formal_result_reuse"}, "conditional_ROOT_admission_fields_required")
    require(admission["schema_version"] == SCHEMA and admission["issuer"] == "ROOT"
            and admission["accepted"] is True and admission["evidence_kind"] == "real_observation"
            and admission["qualification"] == QUALIFICATION
            and admission["scope"] == "development_engineering_only"
            and admission["formal_result_reuse"] is False, "conditional_ROOT_admission_required")
    study = read(inputs["definition"])
    if mode == "epoch":
        model, identity = inputs["model"], inputs["identity"]
        role_ref = pair(inputs["evidence"]["protocol"])
    else:
        current = read(inputs["epoch"])
        model, identity = current["model"], current["identity"]
        require(model == inputs["current_model"], "conditional_current_model_mismatch")
        embedded = current["evidence"]["protocol"]
        role_ref = pair({key: embedded[key] for key in ("path", "sha256")})
        for key in ("acceptance", "registration"):
            anchor = read(inputs["anchors"][key])
            same(anchor["protocol_admission"], admission_ref, io, "conditional_anchor_admission_mismatch")
        # Existing authority validates the GO's complete six-anchor hash links.
    role = read(role_ref)
    if mode == "run":
        same(role, embedded["contents"], io, "conditional_embedded_role_changed")
    audit = read(admission["audit_ref"])
    decision = read(admission["conditional_decision_ref"])
    require(role["schema_version"] == "phase3b-real-evidence-v1" and role["evidence_kind"] == "real_observation"
            and role["role"] == "protocol" and role["passed"] is True
            and role["qualification"] == QUALIFICATION
            and role["protocol_admission_schema"] == AUDIT_SCHEMA
            and role["passed_scope"] == "conditional_development_engineering_acceptance"
            and role["strict_eight_slot_success_claimed"] is False
            and type(role["new_synthetic_calls"]) is int and role["new_synthetic_calls"] == 0,
            "conditional_explicit_role_required")
    same(role["producer"], {"schema": "independent-real-evidence-normalizer-v1", "source": PRODUCER_REF},
         io, "conditional_accepted_producer_required")
    guard(PRODUCER_REF)
    io.read_ref(PRODUCER_REF)
    same(role["independent_audit"], admission["audit_ref"], io, "conditional_full_audit_pin_mismatch")
    same(role["conditional_decision_ref"], admission["conditional_decision_ref"], io, "conditional_decision_pin_mismatch")
    require(audit["schema_version"] == AUDIT_SCHEMA and audit["evidence_kind"] == "real_observation"
            and audit["qualification"] == QUALIFICATION
            and all(audit[key] is True for key in ("passed", "tasks_passed", "score_checks_complete")),
            "conditional_complete_independent_audit_required")
    require(decision["schema_version"] == "development-tasks-continuation-v6-decision-v1"
            and decision["issuer"] == "ROOT" and decision["qualification"] == QUALIFICATION
            and decision["unresolved_engineering_issues"] == [], "conditional_original_decision_required")
    plan = study["validated_plan_view"]
    selected_models = [row for row in plan["candidate"]["models"] if row["label"] == model]
    require(len(selected_models) == 1 and identity["model_id"] == selected_models[0]["model_id"],
            "conditional_formal_label_identity_mismatch")
    model_id = selected_models[0]["model_id"]
    profile_view = plan["profiles"][model]
    for value in (role, audit, admission):
        require(value["model_id"] == model_id and value["deployment_id"] == identity["deployment_id"]
                and value["source_tree_sha256"] == SOURCE
                and value["profile_sha256"] == profile_view["sha256"], "conditional_scope_identity_mismatch")
        require(all(value[key] is False for key in ("original_auto_passed", "strict_named_gate_passed",
                                                   "original_audit_overall_qualified")),
                "conditional_original_false_disclosure_required")
    same(audit["deployment"], admission["deployment"], io, "conditional_ROOT_deployment_pin_mismatch")
    same(audit["profile"], admission["profile"], io, "conditional_ROOT_profile_pin_mismatch")
    read(admission["deployment"])
    read(admission["profile"])
    same(audit["conditional_decision_ref"], admission["conditional_decision_ref"], io, "conditional_audit_decision_mismatch")
    for key in ("native_tools", "rendered_task_context", "assistant_tool_history"):
        require(role[key] is True and audit["checks"][key] is True, "conditional_engineering_capability_required")
    require(audit["checks"]["full_attempt_coverage"] is True, "conditional_all_attempt_coverage_required")
    same(role["audit_checks"], audit["checks"], io, "conditional_role_checks_mismatch")
    same(role["scope_details"], audit["scope_details"], io, "conditional_role_scope_mismatch")
    selected = admission["selected_job_ids"]
    require(type(selected) is list and len(selected) == 15 and all(type(x) is str and x for x in selected)
            and len(set(selected)) == 15 and type(admission["expected_agent_traces"]) is int
            and admission["expected_agent_traces"] == 51, "conditional_exact_development_scope_required")
    same(selected, audit["scope_details"]["selected_job_ids"], io, "conditional_ROOT_selected_mismatch")
    same(selected, decision["selected_job_ids"], io, "conditional_decision_selected_mismatch")
    require(type(audit["scope_details"]["expected_agent_traces"]) is int
            and audit["scope_details"]["expected_agent_traces"] == 51, "conditional_audit_owners_mismatch")
    same(audit["scope_details"]["historical_replica_coverage"], [0, 1, 2, 3], io,
         "conditional_four_replica_existence_required")
    # The accepted producer already bound each original and all raw/trace bytes.
    # ROOT independently accepted the full audit; this gate does not re-score.
    return {"protocol_admission": admission_ref, "protocol_role": role_ref,
            "qualification": QUALIFICATION, "executor_scope_awareness_claimed": False}
