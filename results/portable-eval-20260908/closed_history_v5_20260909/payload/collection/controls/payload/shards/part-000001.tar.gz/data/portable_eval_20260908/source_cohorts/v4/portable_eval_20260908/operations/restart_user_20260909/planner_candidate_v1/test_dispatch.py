import copy
import threading
import unittest
import dispatch as d


def job(i=0,scenario="restricted_search",n=1):
    return {"invocation_id":str(i),"scenario":scenario,"expected_model_terminals":n}


def report(j,missing=0,scored=True):
    return dict({k:True for k in d.EVIDENCE_FIELDS},invocation_id=j["invocation_id"],terminal_status={
        "schema_version":"expgym.execution-terminal.v1","policy_version":"task-abstention-v1",
        "execution_complete":True,"score_complete":scored,"terminal_classification":"model_no_answer" if missing else "completed_scored",
        "model_no_answer_count":missing,"expected_model_terminals":j["expected_model_terminals"],"reported_model_terminals":j["expected_model_terminals"]})


class DispatcherTests(unittest.TestCase):
    def test_all_normal(self):
        result=d.run_bounded([job(i) for i in range(6)],report,workers=2,before_start=lambda j:None,record=lambda k,v:None)
        self.assertTrue(result["execution_complete"])
        self.assertEqual(len(result["reports"]),6)

    def test_missing_search_continue(self):
        self.assertTrue(d.terminal_decision(job(),report(job(),1))["continue"])

    def test_missing_tuning_unknown_continue(self):
        j=job(scenario="tuning",n=4)
        r=d.terminal_decision(j,report(j,1,False))
        self.assertTrue(r["continue"]);self.assertFalse(r["score_complete"])

    def test_unknown_not_performance_complete(self):
        js=[job(i,"tuning") for i in range(3)]
        r=d.run_bounded(js,lambda j:report(j,1,False),workers=2,before_start=lambda j:None,record=lambda k,v:None)
        self.assertTrue(r["execution_complete"]);self.assertFalse(r["score_complete"])

    def test_no_raw_evidence_no_continue(self):
        r=report(job());r["raw_integrity_complete"]=False
        self.assertFalse(d.terminal_decision(job(),r)["continue"])

    def test_unscored_search_rejected(self):
        self.assertFalse(d.terminal_decision(job(),report(job(),1,False))["continue"])

    def test_wrong_owners_rejected(self):
        r=report(job());r["terminal_status"]["reported_model_terminals"]=0
        self.assertFalse(d.terminal_decision(job(),r)["continue"])

    def test_infra_stops_new_and_joins(self):
        began=[];closed=[];gate=threading.Event()
        def worker(j):
            began.append(j["invocation_id"])
            if j["invocation_id"]=="0":
                gate.wait(2);return {"invocation_id":"0"}
            gate.set();closed.append(j["invocation_id"]);return report(j)
        r=d.run_bounded([job(i) for i in range(8)],worker,workers=2,before_start=lambda j:None,record=lambda k,v:None)
        self.assertFalse(r["execution_complete"])
        self.assertEqual(r["local_workers"],0)
        self.assertEqual(set(r["started_invocation_ids"]),set(began))
        self.assertTrue(r["unstarted_invocation_ids"])

    def test_operator_stop_no_start(self):
        event=threading.Event();event.set()
        r=d.run_bounded([job()],report,workers=1,before_start=lambda j:None,record=lambda k,v:None,stop_event=event)
        self.assertEqual(r["started_invocation_ids"],[])

    def test_before_start_failure_not_reserved(self):
        records=[]
        def fail(j):raise ValueError("expired")
        r=d.run_bounded([job()],report,workers=1,before_start=fail,record=lambda k,v:records.append(k))
        self.assertEqual(records,["drain"]);self.assertFalse(r["execution_complete"])

    def test_bool_workers_rejected(self):
        with self.assertRaises(ValueError):d.run_bounded([job()],report,workers=True,before_start=lambda j:None,record=lambda k,v:None)

    def test_duplicate_job_rejected(self):
        with self.assertRaises(ValueError):d.run_bounded([job(),job()],report,workers=1,before_start=lambda j:None,record=lambda k,v:None)


if __name__=="__main__":unittest.main()
