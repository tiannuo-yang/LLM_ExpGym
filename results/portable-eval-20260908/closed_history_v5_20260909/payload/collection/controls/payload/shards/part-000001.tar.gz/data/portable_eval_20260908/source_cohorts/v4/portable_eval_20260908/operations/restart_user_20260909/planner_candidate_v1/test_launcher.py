import copy
import inspect
from pathlib import Path
import tempfile
import unittest
from unittest import mock
import launcher as l
import test_planner as p


def config():
    return {"run_id":"cpu-restart", "supersedes":["old"],"model":{"label":"m0","model_id":"model0"},
        "repo_root":"/synthetic/repo","output_root":"/synthetic/output",
        "endpoint":"http://example.invalid/v1/chat/completions", "credential_path":"/synthetic/declared/credential",
        "environment":{},"runtimes":{r:{"executable":"/synthetic/"+r+"/python"} for r in ("native","paramnet_legacy")},
        "profiles":{"model0":{"temperature":1.0,"top_p":1.0,"top_k":None,"reasoning_effort":"max","chat_template_kwargs":{}}},
        "deployment_ref":{"path":"/synthetic/deployment.json","sha256":"d"*64},
        "policy":{"workers":32,"max_steps":30,"max_evals":30,"max_tokens":32768,"max_context_tokens":131072,
            "max_protocol_retries":1,"max_retries":2,"request_timeout":3600,"retry_base_seconds":3,
            "retry_max_seconds":30,"tuning_final_policy":"legacy","missing_final_policy":"task-abstention-v1",
            "stop_new_before_deadline_seconds":21600,"max_wall_seconds":259200}}


def plan():
    c=config();m=p.matrix()
    return {"schema_version":l.SCHEMA,"mode":"formal_mixed","config":c,"jobs":l.formal_jobs(c,m),"matrix":m}


def grant(value):
    c=value["config"]
    return {"schema_version":"restart-root-launch-go-v1","action":"execute_once","plan_ref":{"path":"/synthetic/plan.json","sha256":"a"*64},
        "run_id":c["run_id"],"model_id":c["model"]["model_id"],"output_root":c["output_root"],"mode":value["mode"],
        "invocation_ids":[j["invocation_id"] for j in value["jobs"]],"deployment_ref":c["deployment_ref"],
        "policy_sha256":l.s.digest(c["policy"]),"not_before_unix":1000,"latest_start_unix":2000,
        "deadline_unix":100000,"allocation_start_unix":100,"allocation_deadline_unix":200000,
        "gpu_seconds_cap":6400000,"gpu_count":64,"allocation_id":"synthetic-never-real"}


class LauncherTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.plan=plan()

    def test_all_705_commands_count_identity(self):
        value=copy.deepcopy(self.plan);l.validate_jobs(value["config"],value["jobs"])
        self.assertEqual(len(value["jobs"]),705)
        self.assertEqual(sum(j["expected_model_terminals"] for j in value["jobs"]),1881)
        self.assertEqual(sum(len(j["expected_files"]) for j in value["jobs"]),2613)

    def test_actual_cli_spellings(self):
        for j in self.plan["jobs"]:
            cmd=j["command"]
            self.assertIn("--output-dir",cmd);self.assertIn("--tool-protocol",cmd)
            self.assertNotIn("--out-dir",cmd);self.assertNotIn("--tool-call-mode",cmd)
            if j["system"]=="expgym":
                self.assertIn("--temperature-eval",cmd);self.assertIn("--temperature-tuning",cmd)
                self.assertIn("disabled",cmd)

    def test_separate_evidence_path(self):
        for j in self.plan["jobs"]:
            self.assertNotIn(Path(j["output_dir"]),Path(j["terminal_evidence_dir"]).parents)
            self.assertEqual(j["command"][j["command"].index("--terminal-evidence-dir")+1],j["terminal_evidence_dir"])

    def test_single_model_only(self):
        jobs=copy.deepcopy(self.plan["jobs"][:1]);jobs[0]["model_id"]="other"
        with self.assertRaises(ValueError):l.validate_jobs(self.plan["config"],jobs)

    def test_output_escape(self):
        jobs=copy.deepcopy(self.plan["jobs"][:1]);jobs[0]["expected_files"][0]="/elsewhere/result.json"
        with self.assertRaises(ValueError):l.validate_jobs(self.plan["config"],jobs)

    def test_credential_argv_rejected(self):
        jobs=copy.deepcopy(self.plan["jobs"][:1]);jobs[0]["command"] += ["--api-key-file","/secret/path"]
        with self.assertRaises(ValueError):l.validate_jobs(self.plan["config"],jobs)

    def test_authority_explicit_and_scope(self):
        g=grant(self.plan);a=l.Authority(self.plan,g["plan_ref"],g,now=lambda:1500)
        a.check(self.plan["jobs"][0]["invocation_id"],starting=True)
        with self.assertRaises(ValueError):a.check("other")

    def test_authority_reordered_jobs_rejected(self):
        g=grant(self.plan);g["invocation_ids"].reverse()
        with self.assertRaises(ValueError):l.Authority(self.plan,g["plan_ref"],g)

    def test_authority_policy_tamper_rejected(self):
        g=grant(self.plan);g["policy_sha256"]="f"*64
        with self.assertRaises(ValueError):l.Authority(self.plan,g["plan_ref"],g)

    def test_authority_timeout_and_stopmargin(self):
        g=grant(self.plan);iid=self.plan["jobs"][0]["invocation_id"]
        a=l.Authority(self.plan,g["plan_ref"],g,now=lambda:90000)
        a.check(iid)
        with self.assertRaises(ValueError):a.check(iid,starting=True)
        a=l.Authority(self.plan,g["plan_ref"],g,now=lambda:97000)
        with self.assertRaises(ValueError):a.check(iid)

    def test_allocation_loading_counts_against_cap(self):
        g=grant(self.plan);g["gpu_seconds_cap"]=(g["deadline_unix"]-g["not_before_unix"])*64
        with self.assertRaises(ValueError):l.Authority(self.plan,g["plan_ref"],g)

    def test_environment_no_proxy_credentials(self):
        with mock.patch.dict(l.os.environ,{"HTTPS_PROXY":"x","http_proxy":"x","OPENAI_API_KEY":"synthetic-marker"}):
            env=l.clean_environment(config())
        self.assertNotIn("OPENAI_API_KEY",env);self.assertNotIn("HTTPS_PROXY",env)
        self.assertEqual(env["NO_PROXY"],"*")

    def test_environment_override_rejected(self):
        c=config();c["environment"]={"PYTHONPATH":"/other"}
        with self.assertRaises(ValueError):l.clean_environment(c)

    def test_no_authority_no_key_or_namespace(self):
        g=grant(self.plan);g["action"]="not-a-grant"
        with mock.patch.object(l,"verify_plan"),mock.patch.object(l.s.io,"read_regular") as read,mock.patch.object(l.s.io,"new_directory") as create:
            with self.assertRaises(ValueError):l.launch(self.plan,g["plan_ref"],g,{"path":"/synthetic/go","sha256":"g"*64})
            read.assert_not_called();create.assert_not_called()

    def test_invalid_key_no_namespace(self):
        g=grant(self.plan)
        with mock.patch.object(l,"verify_plan"),mock.patch.object(l.time,"time",return_value=1500),\
             mock.patch.object(Path,"exists",return_value=False),mock.patch.object(l.s.io,"read_regular",return_value=b"bad key"),\
             mock.patch.object(l.s.io,"new_directory") as create:
            with self.assertRaises(ValueError):l.launch(self.plan,g["plan_ref"],g,{"path":"/synthetic/go","sha256":"a"*64})
            create.assert_not_called()

    def test_existing_root_no_key(self):
        g=grant(self.plan)
        with mock.patch.object(l,"verify_plan"),mock.patch.object(l.time,"time",return_value=1500),\
             mock.patch.object(Path,"exists",return_value=True),mock.patch.object(l.s.io,"read_regular") as read:
            with self.assertRaises(ValueError):l.launch(self.plan,g["plan_ref"],g,{"path":"/synthetic/go","sha256":"a"*64})
            read.assert_not_called()

    def test_safe_tree_rejects_symlink(self):
        with tempfile.TemporaryDirectory(prefix="restart-cpu-") as name:
            root=Path(name);(root/"link").symlink_to("/nonexistent")
            with self.assertRaises(OSError):l.safe_tree(root)

    def test_safe_tree_byte_not_mtime_identity(self):
        with tempfile.TemporaryDirectory(prefix="restart-cpu-") as name:
            l.s.put(name,"fixture.json",{"synthetic":True})
            first=l.safe_tree(name);l.os.utime(str(Path(name)/"fixture.json"),None)
            self.assertEqual(first,l.safe_tree(name))

    def test_fd_helper_real_signatures(self):
        helper=l.s.secret_helpers()
        inspect.signature(helper.run_child).bind([],"/cwd",{},"/log",secret="public-fixture")
        inspect.signature(helper.read_secret_fd).bind(4)
        inspect.signature(l.wire.run_source).bind({}, {}, object(), "public-fixture")


if __name__=="__main__":unittest.main()
