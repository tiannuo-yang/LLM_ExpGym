"""Real invocation adapter. Frozen original owner/raw/score/resume logic retained.
No begun invocation is regenerated; N4 pools are never synthesized from N3.
"""
from pathlib import Path
import copy
import json

import real_common as common
import real_authority as authority
import real_attempt_gate as attempt_gate
import secret_fd

_a3 = common.a3_module("routes")
owners = common.a3_module("owners")
import raw_scope_retry as raw_scope
bridge = common.a3_module("support").bridge
HERE, verify, scoped = common.HERE, common.verify, common.scoped
code_identity, read_json, write_evidence = common.identity, common.a3_module("support").read_json, common.write
safe_snapshot, retained = common.a3_module("support").safe_snapshot, common.a3_module("support").retained
guard_command, pool_prerequisites, pool_structural_prerequisites = _a3.guard_command, _a3.pool_prerequisites, _a3.pool_structural_prerequisites


def _post_child_accounting(report, *, rows, preflight, output, selected, dumps, logs, study, invocation, epoch, planned, secret):
    """Independent best-effort observations; no source execution or repairs.

    Each collector is isolated so a failed attempt inventory, snapshot, owner
    loader, or strict raw checker cannot erase the other available evidence.
    Frozen raw totals describe the observed namespace. Only the separate
    accounting projection can claim finality after a proven direct-child drain.
    """
    plan = study["validated_plan_view"]
    errors, before = [], {}
    for label, path in (("results", selected), ("dumps", dumps)):
        try:
            before[label] = safe_snapshot(path)
        except Exception as exc:
            before[label] = {"__snapshot_error__": {"unreadable_type": type(exc).__name__}}
            errors.append({"collector": label + "_snapshot", "error_type": type(exc).__name__})
    report["after_runner"] = before
    try:
        report["attempt_operations"] = attempt_gate.inventory(logs / "attempts", dumps)
    except Exception as exc:
        errors.append({"collector": "attempt_operations", "error_type": type(exc).__name__})
        report["attempt_operations"] = {"schema_version": "phase3b-real-send-inventory-v1", "attempts": [],
            "issues": [{"code": "attempt_inventory_failed", "error_type": type(exc).__name__}],
            "raw_attempts": None, "not_sent": None, "send_unknown": None,
            "http_response_bytes_returned": None, "provider_received_proven": False, "model_generation_count": None}
    try:
        loaded, report["owner_load_errors"] = owners.load_available(rows, preflight, output, study["run_id"], plan["policy"]["max_context_tokens"])
    except Exception as exc:
        loaded = []
        report["owner_load_errors"] = [{"error_type": type(exc).__name__, "scope": "all owner loading failed"}]
        errors.append({"collector": "owners", "error_type": type(exc).__name__})
    try:
        report["raw"] = raw_scope.audit_partial(loaded, dumps, planned_owners=planned,
            profile=plan["profiles"][invocation["model"]]["profile"], policy=plan["policy"],
            endpoint=epoch["identity"]["endpoint"], run_id=study["run_id"], secret=secret)
    except Exception as exc:
        errors.append({"collector": "strict_raw_audit", "error_type": type(exc).__name__})
        report["raw"] = {"passed": False, "errors": [{"rule": "strict_raw_audit_failed", "error_type": type(exc).__name__}],
            "owner_qualification": [], "raw_coverage": {"complete": False}, "totals_all_attempts": None}
        # Reuse only the frozen full-namespace catalog and usage accumulator.
        # This preserves parseable known usage without inventing qualification.
        try:
            catalog = raw_scope.full_catalog(dumps)
            report["raw"]["files"] = catalog["files"]
            report["raw"]["raw_coverage"].update({key: catalog.get(key, []) for key in
                ("unreadable_paths", "nested_paths", "duplicate_request_ids", "conflicting_request_ids")})
            report["raw"]["totals_all_attempts"] = raw_scope.safe_usage_totals(catalog.get("unique_records", []), False)
            report["raw"]["fallback_catalog_issues"] = catalog["issues"]
        except Exception as catalog_error:
            errors.append({"collector": "fallback_raw_catalog", "error_type": type(catalog_error).__name__})
    loaded_map = {item["owner_id"]: item for item in loaded}
    report["owners"] = [{"owner_id": item["owner_id"], "logical_id": item["logical_id"],
        "artifact": loaded_map.get(item["owner_id"], {}).get("artifact"), "raw_eligible": False,
        "score_recomputed": False, "owner_evidence_qualified": False,
        "prerequisite_errors": ["post_run_score_and_finality_not_yet_verified"]} for item in planned]
    try:
        write_evidence(logs / "raw_audit.json", report["raw"])
    except Exception as exc:
        errors.append({"collector": "raw_audit_persistence", "error_type": type(exc).__name__})
    drained = report["run"].get("drain_proven") is True
    complete = drained and report["raw"]["raw_coverage"]["complete"] is True and not report["attempt_operations"]["issues"] and not errors
    totals = copy.deepcopy(report["raw"]["totals_all_attempts"])
    if totals is not None and not complete:
        totals["complete_http_attempts"], totals["partial_known_sum_only"] = None, True
        for usage in totals["provider_usage"].values():
            usage["complete_total"] = None
    report["accounting"] = {"schema_version": "phase3b-real-post-child-accounting-v1",
        "scope": "Observed raw namespace and original owner artifacts; never inferred model generations or provider receipt",
        "drain_proven": drained, "namespace_finality": "drained_direct_child_snapshot" if drained else "unknown",
        "namespace_accounting_complete": complete, "totals_all_attempts": totals, "collector_errors": errors,
        "totals_notice": "Use this projection for finality; frozen raw totals alone are a namespace snapshot. Unreported provider fields remain unknown.",
        "unknown_reasons": ([] if drained else ["direct_child_drain_not_proven"])
            + ([] if report["raw"]["raw_coverage"]["complete"] else ["strict_raw_coverage_incomplete"])
            + ([] if not report["attempt_operations"]["issues"] else ["attempt_inventory_incomplete"])
            + ([] if not errors else ["accounting_collector_failed"])}
    return before, loaded


def execute_real_invocation(study, epoch, anchors, invocation_id, journal, *, secret, previous_epoch=None):
    verify()
    grant = authority.validate_real_authority(study, epoch, anchors, previous_epoch)
    grant.check(invocation_id)
    secret_fd.validate_secret(secret)
    c, plan = common.core(), study["validated_plan_view"]
    invocation = next(row for row in plan["candidate"]["invocations"] if row["invocation_id"] == invocation_id)
    command_record = next(row for row in epoch["commands"] if row["invocation_id"] == invocation_id)
    command = command_record["command"]
    output = scoped(study["output_root"])
    if journal.root != output or journal.plan_sha256 != c.digest(study):
        raise ValueError("journal_requires_complete_design_and_exact_root")
    rows, system = c.logical_rows(plan, invocation), invocation["system"]
    static = owners.static_owners(rows)
    identity = code_identity()
    logs = output / "logs" / invocation_id
    selected, dumps = output / invocation["output_relative_dir"], output / invocation["dump_relative_dir"]
    authority.ensure_epoch_record(study, epoch, anchors, journal)
    authority.reserve_invocation_attempts(study, journal, invocation_id)
    journal.begin(invocation_id, {"design_sha256": c.digest(study), "binding_sha256": c.digest(epoch),
        "phase3_implementation": identity, "command_sha256": command_record["sha256"],
        "static_owners": static, "execution_kind": "phase3b_real_gated_original_source", "producer_schema": authority.PRODUCER_SCHEMA})
    env = c.environment(plan["repo_root"], dumps, study["run_id"], Path(epoch["identity"]["legacy_python"]).absolute().parents[2],
        invocation["runtime_profile_required"] == "paramnet_legacy")
    for name in list(env):
        if any(tag in name.upper() for tag in ("API_KEY", "ACCESS_TOKEN", "AUTH_TOKEN", "SECRET")):
            env.pop(name, None)
    env["OPENAI_API_KEY"] = authority.NOAUTH
    report = {"schema_version": authority.PRODUCER_SCHEMA, "kind": "real_invocation_observation",
        "runtime_kind": "real_3b_source_child", "classification": "real_source_execution_observation", "invocation_id": invocation_id,
        "model_generation_count": None, "passed": False, "code_identity": identity, "code_sha256": c.digest(identity),
        "resume": {"executed": False, "verified_skips": 0, "reason": "Not independently qualified; never regenerate begun invocation"},
        "logical_results": {row["logical_id"]: {"state": "infrastructure_failed", "reason": "No complete independently qualified logical result"} for row in rows}}
    try:
        process, text = c.run_child(guard_command(command, "identity"), plan["repo_root"], env, logs / "identity.log")
        report["identity_process"] = process
        if process["exit_code"]:
            raise RuntimeError("identity_probe_failed_before_real_wire")
        preflight = c.parse_guard(text, system)
        report["preflight"] = preflight
        actual_planned = owners.planned(rows, preflight, output)
        report["runtime"] = c.checked_runtime(command, preflight, invocation["runtime_profile_required"] == "paramnet_legacy")
        write_evidence(logs / "actual_owner_identity.json", {"static_owners_sha256": c.digest(static), "planned_owners": actual_planned,
            "preflight_sha256": c.digest(preflight), "command_sha256": command_record["sha256"], "generation_allowed": False})
        identity_path = logs / "actual_owner_identity.json"
        begin_path = output / "journal" / (invocation_id + ".start.json")
        spec_path = logs / "child_spec.json"
        write_evidence(spec_path, {"kind": "phase3b_real_source", "implementation": identity,
            "anchors": anchors, "previous_epoch": previous_epoch, "invocation_id": invocation_id,
            "command": command, "identity_path": str(identity_path), "identity_sha256": common.sha(identity_path),
            "begin_path": str(begin_path), "begin_sha256": common.sha(begin_path),
            "logs": str(logs), "dump_dir": str(dumps)})
        driver = command[:2] + [str(HERE / "real_runner_child.py"), "--spec", str(spec_path)]
        capture_error = None
        try:
            process, _ = secret_fd.run_child(driver, plan["repo_root"], env, logs / "run.log", secret=secret)
        except Exception as exc:
            capture_error = exc
            if type(exc) is secret_fd.ChildCaptureError:
                process = dict(exc.process_receipt)
            else:
                # A caller-side or prelaunch exception carries no process proof.
                # In particular, existing raw files cannot imply inflight=0.
                process = {"exit_code": None, "capture_complete": False, "error_type": type(exc).__name__,
                    "child_started": None, "stdout_eof_observed": False, "wait_returned": False,
                    "drain_proven": False, "drain_scope": "Unknown: no child lifecycle receipt available"}
            report["error_type"] = process["error_type"]
            report["capture_error_type"] = type(exc).__name__
        report["run"] = process
        before, loaded = _post_child_accounting(report, rows=rows, preflight=preflight, output=output,
            selected=selected, dumps=dumps, logs=logs, study=study, invocation=invocation,
            epoch=epoch, planned=actual_planned, secret=secret)
        score_by_owner = {}
        try:
            if any("unreadable_type" in item for item in before["results"].values()):
                raise ValueError("unsafe_selected_object_blocks_frozen_score_reader")
            score_process, text = c.run_child(guard_command(command, "score"), plan["repo_root"], env, logs / "score.log")
            report["score_process"] = score_process
            scoring = c.parse_guard(text, system)
        except Exception as exc:
            score_process = {"exit_code": 2}
            scoring = {"passed": False, "reason": "Whole frozen score guard failed; raw accounting remains independent", "error_type": type(exc).__name__}
        report["score"] = scoring
        if system == "expgym":
            try:
                c.check_exp_probe(rows, scoring, output)
                score_by_owner = {row["logical_id"]: next(item for item in scoring["rows"] if item["path"] == str(output / row["result_artifact"])) for row in rows}
            except Exception as exc:
                report["owner_score_error_type"] = type(exc).__name__
            prerequisites = {row["logical_id"]: [] for row in rows}
            expected_files = {str(Path(row["result_artifact"]).relative_to(invocation["output_relative_dir"])) for row in rows}
        else:
            try:
                owner_score_process, text = c.run_child(guard_command(command, "pool-owners"), plan["repo_root"], env, logs / "owner_scores.log")
                report["owner_score_process"] = owner_score_process
                lines = [line.split("=", 1)[1] for line in text.splitlines() if line.startswith("PHASE3_OWNER_SCORE=")]
                if len(lines) != 1:
                    raise ValueError("missing_complete_independent_owner_score_receipt")
                individual = json.loads(lines[0])
                if (not raw_scope.safe_same(preflight, individual["preflight"]) or len(individual["owners"]) != 4
                        or any(type(item.get("agent_id")) is not int for item in individual["owners"])
                        or {item["agent_id"] for item in individual["owners"]} != set(range(4))):
                    raise ValueError("owner_score_preflight_or_count_mismatch")
                score_by_owner = {rows[0]["logical_id"] + ":agent%d" % item["agent_id"]: item for item in individual["owners"]}
            except Exception as exc:
                report["owner_score_error_type"] = type(exc).__name__
            per_agent, report["pool_prerequisites"] = pool_prerequisites(rows[0], preflight, output)
            report["pool_structural"] = pool_structural_prerequisites(rows[0], invocation, preflight, output, per_agent)
            prerequisites = {rows[0]["logical_id"] + ":agent%d" % index: errors for index, errors in per_agent.items()}
            expected_files = {str(Path(path).relative_to(invocation["output_relative_dir"])) for path in
                [rows[0]["result_artifact"], invocation["summary_artifact"]] + rows[0]["agent_artifacts"]}
        actual_files = set(before["results"])
        report["extra_results"] = sorted(actual_files - expected_files)
        report["missing_results"] = sorted(expected_files - actual_files)
        raw_qualification = {item["owner_id"]: item for item in report["raw"]["owner_qualification"]}
        loaded_map = {item["owner_id"]: item for item in loaded}
        candidates = []
        for planned in actual_planned:
            key, score = planned["owner_id"], score_by_owner.get(planned["owner_id"], {})
            prereq = list(prerequisites.get(key, ["owner_score_prerequisites_missing"]))
            if not report["accounting"]["drain_proven"]:
                prereq.append("direct_child_drain_not_proven")
            raw_ok = raw_qualification.get(key, {}).get("eligible") is True
            score_ok = score.get("passed") is True and score.get("score_check", {}).get("ok") is True
            item = {"owner_id": key, "logical_id": planned["logical_id"], "raw_eligible": raw_ok,
                "score_recomputed": score_ok, "score_prerequisites_verified": not prereq and not report["extra_results"],
                "prerequisite_errors": prereq, "owner_evidence_qualified": raw_ok and score_ok and not prereq and not report["extra_results"],
                "artifact": loaded_map.get(key, {}).get("artifact"), "score_check": score.get("score_check"),
                "protocol_failure_count": score.get("outcome", {}).get("protocol_failure_count", score.get("protocol_failure_count")),
                "score": score.get("outcome", {}).get("score") if system == "expgym" else {"answer_perf": score.get("answer_perf")}}
            candidates.append(item)
        all_qualified = all(item["owner_evidence_qualified"] for item in candidates)
        report["owners"] = candidates
        full = (capture_error is None and process["exit_code"] == 0 and score_process["exit_code"] == 0
            and report["accounting"]["namespace_accounting_complete"] and report["raw"]["passed"] and not report["attempt_operations"]["issues"] and all_qualified
            and not report["extra_results"] and not report["missing_results"] and (system == "expgym" or report["pool_structural"]["passed"]))
        if full:
            resumed, text = c.run_child(guard_command(command, "resume"), plan["repo_root"], env, logs / "resume.log")
            skips = text.count("skip verified") if system == "expgym" else text.count("[resume]")
            report["resume"] = dict(resumed, executed=True, verified_skips=skips, expected_skips=len(rows))
            full = resumed["exit_code"] == 0 and skips == len(rows)
        else:
            report["resume"] = {"executed": False, "verified_skips": 0, "reason": "Partial or failed invocation is never regenerated"}
        after_process, text = c.run_child(guard_command(command, "identity"), plan["repo_root"], env, logs / "identity_after.log")
        if after_process["exit_code"] or not raw_scope.safe_same(preflight, c.parse_guard(text, system)):
            raise ValueError("post_run_identity_changed")
        if before != {"results": safe_snapshot(selected), "dumps": safe_snapshot(dumps)}:
            raise ValueError("raw_or_result_bytes_changed_during_audit")
        authority.verify_epoch(study, epoch, previous_epoch)
        verify()
        if identity != code_identity():
            raise ValueError("phase3_code_changed_during_invocation")
        report["owners"], report["passed"] = candidates, full
        for item in candidates:
            write_evidence(logs / "owner_evidence" / (c.digest(item["owner_id"]) + ".json"), item)
            if system == "expgym" and item["owner_evidence_qualified"]:
                report["logical_results"][item["logical_id"]] = {"state": "model_failure_scored" if item["protocol_failure_count"] else "scored",
                    "score": item["score"], "score_check": item["score_check"], "trace_sha256": item["artifact"]["sha256"]}
        if system == "poolact" and full:
            report["logical_results"][rows[0]["logical_id"]] = {"state": "model_failure_scored" if any(item["protocol_failure_count"] for item in candidates) else "scored",
                "aggregate": scoring["aggregate_recomputed_metrics"], "score_checks": scoring["score_checks"],
                "reason": "Frozen original full N4 aggregate verified; ledger retains numeric fields only, canonical answers remain in original artifacts"}
        for key, value in report["logical_results"].items():
            if value["state"] in {"scored", "model_failure_scored"}:
                journal.record_partial(invocation_id, {key: value}, retained(invocation, output))
    except Exception as exc:
        report["passed"] = False
        if "error_type" in report:
            report["post_run_error_type"] = type(exc).__name__
        else:
            report["error_type"] = type(exc).__name__
    report["phase3b_authority"] = {"epoch_sha256": common.digest(epoch), "anchors": anchors, "grant_kind": "externally_registered_real"}
    write_evidence(logs / "invocation_receipt.json", report)
    journal.finish(invocation_id, report["logical_results"], report["passed"], retained(invocation, output), error_type=report.get("error_type"))
    return report
