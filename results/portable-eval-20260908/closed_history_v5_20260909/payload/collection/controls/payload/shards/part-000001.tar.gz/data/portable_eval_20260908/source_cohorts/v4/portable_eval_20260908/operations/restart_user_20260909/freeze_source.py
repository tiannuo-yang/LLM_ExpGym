"""Bind the explicitly validated v5 source; never launches models or changes code."""
import hashlib
import json
import os
from pathlib import Path
import sys
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
REPO = Path('/lustrefs/users/chufan.shi/codex_space_tn/portable_eval_20260908/source_cohorts/v5/LLM_ExpGym')
sys.path.insert(0, str(REPO))
from expgym.trace_v2 import source_tree_sha256


def ref(path):
    path = Path(path)
    before = path.stat()
    raw = path.read_bytes()
    after = path.stat()
    assert (before.st_size, before.st_mtime_ns, before.st_ino) == (after.st_size, after.st_mtime_ns, after.st_ino)
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


logs = HERE / 'prompt_validation_v1'
full = (logs / 'INTEGRATED_FULL_CHECK_02.log').read_text()
legacy = (logs / 'INTEGRATED_LEGACY_HPO_CHECK.log').read_text()
data = (logs / 'DATA_CHECK.log').read_text()
assert 'Ran 608 tests' in full and 'OK (skipped=5)' in full and '[check] OK' in full
assert 'Ran 72 tests' in legacy and '\nOK\n' in legacy and 'FAILED' not in legacy
assert 'Result: all datasets ready.' in data
files = {}
for directory, directories, filenames in os.walk(str(REPO), followlinks=False):
    directories[:] = sorted(d for d in directories if d != '__pycache__' and not (Path(directory) / d).is_symlink())
    if Path(directory) == REPO:
        directories[:] = [d for d in directories if d in {'expgym', 'scripts', 'schemas', 'tests', 'configs'}]
    for name in sorted(filenames):
        path = Path(directory) / name
        if path.suffix in ('.pyc', '.pyo'):
            continue
        assert path.is_file() and not path.is_symlink(), str(path)
        files[str(path.relative_to(REPO))] = ref(path)['sha256']
files = dict(sorted(files.items()))
assert len(files) == 86, len(files)
runtimes = {
    'native': ref('/lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python'),
    'legacy': ref('/lustrefs/users/chufan.shi/codex_space_tn/kimi_k3_eval/data_runtime/.venv-hpo/bin/python'),
}
assert runtimes['native']['sha256'] == '9e7f0dd93c77a32d07aa66631b48116101db6266701b292ebdc56a30d6cc7924'
assert runtimes['legacy']['sha256'] == '8bc988df7ea93a3154c1b0f6795f5c5a21b596458ea766e9aa24e2fdddf3de07'
receipt = {
    'schema_version': 1, 'classification': 'Static/fake validation',
    'created_utc': datetime.now(timezone.utc).isoformat(), 'repo_root': str(REPO),
    'source_cohort': 'v5_benchmark_blind_task_abstention_mixed_repeats',
    'supersedes_preliminary_inventory': ref(HERE / 'source_acceptance_v5.json'),
    'source_tree_sha256': source_tree_sha256(REPO), 'files': files,
    'runtime_interpreters': runtimes,
    'validation': {'full_tests_run': 608, 'full_passed': 603, 'full_skipped': 5,
                   'legacy_targeted_tests_run': 72, 'legacy_passed': 72, 'legacy_skipped': 0,
                   'full_fake_entrypoints_passed': True, 'data_check_passed': True},
    'evidence': [ref(logs / name) for name in ('INTEGRATED_FULL_CHECK.log', 'INTEGRATED_FULL_CHECK_02.log',
                'INTEGRATED_LEGACY_HPO_CHECK.log', 'DATA_CHECK.log', 'ACTUAL_HPO_DEFAULTS.log',
                'ACTUAL_NAS101_VALID_LOOKUP.log', 'TARGETED_TESTS.log')],
    'real_model_smoke_completed': False, 'formal_generation_completed': False,
    'limits': ['608-test first integration exposed batch-default compatibility; failed log retained, fixed and rerun.',
               'Legacy targeted suite is not the whole repository on Python 3.7.',
               'Legacy environment emitted existing NumPy ABI/deprecation warnings; actual fixed evaluator calls passed.',
               'Explicit benchmark text and gold-cardinality hint removed; structure/training contamination not ruled out.',
               'Default normal scoring preserved; malformed historical resume identity acceptance is stricter.',
               'Imported policy test differs from delta owner by one trailing blank line; test bodies unchanged.',
               'Source scope excludes locally generated synthetic evidence under runs/ and budget_sweep_results/. Those remain retained, not formal model output.',
               'Data link remains shared; selected data hashes must also be frozen by launch matrix.',
               'This receipt is not actual model, statistical or final post-analysis acceptance.'],
}
for name, checksum in files.items():
    assert ref(REPO / name)['sha256'] == checksum
out = HERE / 'source_acceptance_v5_final.json'
raw = (json.dumps(receipt, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()
with out.open('xb') as stream:
    stream.write(raw)
    stream.flush()
    os.fsync(stream.fileno())
print(json.dumps(ref(out), sort_keys=True))
print(json.dumps({'source_tree_sha256': receipt['source_tree_sha256'], 'source_files': len(files)}, sort_keys=True))
