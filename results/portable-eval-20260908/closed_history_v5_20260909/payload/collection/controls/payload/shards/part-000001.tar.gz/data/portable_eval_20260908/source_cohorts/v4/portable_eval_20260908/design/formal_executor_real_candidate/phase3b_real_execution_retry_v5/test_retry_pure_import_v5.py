"""Clean-process pure import boundary; no source runner, transport or key."""
import json
from pathlib import Path
import subprocess
import sys
import unittest

HERE = Path(__file__).resolve().parent
PRELUDE = r'''
import json, socket, subprocess, sys, types, urllib.request
from pathlib import Path
sys.dont_write_bytecode = True
calls = []
def deny(*args, **kwargs):
    calls.append("network_or_subprocess")
    raise AssertionError("PURE_RAW_IMPORT_NETWORK_AND_PROCESS_FORBIDDEN")
socket.socket.connect = socket.socket.connect_ex = socket.create_connection = deny
urllib.request.urlopen = subprocess.Popen = deny
sys.path.insert(0, sys.argv[1])
'''


class PureImportTests(unittest.TestCase):
    def probe(self, code):
        process = subprocess.run([sys.executable, "-B", "-c", PRELUDE + code, str(HERE)],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False, universal_newlines=True)
        self.assertEqual(process.returncode, 0, process.stderr)
        result = json.loads(process.stdout)
        self.assertEqual(result["forbidden_calls"], [])
        return result

    def test_actual_pure_scope_ignores_independent_auditor_common_name(self):
        result = self.probe(r'''
existing = types.ModuleType("common")
existing.__file__ = "/synthetic-independent-auditor/common.py"
sys.modules["common"] = existing
import raw_scope_retry as scope
scope.verify_dependencies()
forbidden = {"real_common", "real_authority", "real_dispatch", "real_runner_child", "real_attempt_gate", "real_journal", "urllib_delegate"}
assert not (forbidden & set(sys.modules))
assert sys.modules["common"] is existing
assert scope.full_catalog is scope._frozen.full_catalog
assert scope.safe_usage_totals is scope._frozen.safe_usage_totals
print(json.dumps({"forbidden_calls": calls, "pure_import": True, "common_preserved": True}))
''')
        self.assertTrue(result["pure_import"] and result["common_preserved"])

    def test_wrong_existing_raw_scope_origin_rejected(self):
        result = self.probe(r'''
existing = types.ModuleType("raw_scope")
existing.__file__ = "/synthetic-wrong/raw_scope.py"
existing.verify_dependencies = deny
sys.modules["raw_scope"] = existing
import retry_dependencies as deps
try:
    deps.frozen_scope()
except ValueError as exc:
    assert str(exc) == "wrong_frozen_raw_scope_module"
else:
    raise AssertionError("wrong scope accepted")
assert sys.modules["raw_scope"] is existing
print(json.dumps({"forbidden_calls": calls, "rejected": True}))
''')
        self.assertTrue(result["rejected"])

    def test_wrong_raw_scope_pin_rejected_before_frozen_import(self):
        result = self.probe(r'''
import retry_dependencies as deps
deps.RAW_SCOPE_SHA256 = "0" * 64
try:
    deps.frozen_scope()
except ValueError as exc:
    assert str(exc) == "frozen_raw_scope_source_changed"
else:
    raise AssertionError("wrong pin accepted")
assert "raw_scope" not in sys.modules
print(json.dumps({"forbidden_calls": calls, "rejected": True}))
''')
        self.assertTrue(result["rejected"])

    def test_wrong_existing_local_policy_origin_rejected(self):
        result = self.probe(r'''
existing = types.ModuleType("retry_policy")
existing.__file__ = "/synthetic-wrong/retry_policy.py"
existing.retry_is_transient = deny
sys.modules["retry_policy"] = existing
try:
    import raw_audit_retry
except ValueError as exc:
    assert str(exc) == "wrong_local_retry_policy_module"
else:
    raise AssertionError("wrong policy accepted")
assert sys.modules["retry_policy"] is existing
print(json.dumps({"forbidden_calls": calls, "rejected": True}))
''')
        self.assertTrue(result["rejected"])
