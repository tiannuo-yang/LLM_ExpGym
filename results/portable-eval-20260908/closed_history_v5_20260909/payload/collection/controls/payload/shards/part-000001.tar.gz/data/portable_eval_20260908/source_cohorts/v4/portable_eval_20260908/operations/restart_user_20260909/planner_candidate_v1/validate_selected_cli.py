"""No-network actual CLI dry and source path reconstruction for ROOT smoke spec."""
import argparse
import contextlib
import io
import json
from pathlib import Path
import runpy
import socket
import sys
from unittest import mock
import launcher as l


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--spec",required=True);parser.add_argument("--spec-sha256",required=True)
    parser.add_argument("--output-dir",required=True)
    args=parser.parse_args()
    spec_ref={"path":args.spec,"sha256":args.spec_sha256}
    spec=l.s.io.read_json_ref(spec_ref)
    if spec["mode"]!="selected_smoke":raise ValueError("explicit_selected_smoke_only")
    plan=l.compile_plan(spec)
    directory=l.s.io.new_directory(args.output_dir)
    repo=Path(plan["config"]["repo_root"]);sys.path.insert(0,str(repo))
    from expgym.llm_clients import OpenAICompatibleLLM
    modules={system:runpy.run_path(str(repo/"scripts"/name),run_name="restart_selected_dry_"+system)
        for system,name in (("expgym","run_paper_sweep.py"),("poolact","run_poolact.py"))}
    results=[]
    def forbidden(*args,**kwargs):raise AssertionError("CPU_DRY_FORBIDS_NETWORK_MODEL_KEY")
    with mock.patch.object(OpenAICompatibleLLM,"__init__",side_effect=forbidden),mock.patch.object(socket,"socket",side_effect=forbidden),mock.patch.object(socket,"create_connection",side_effect=forbidden):
        for job in plan["jobs"]:
            module=modules[job["system"]];main=module["main"]
            main.__globals__["_load_api_key"]=lambda *a,**k:None
            stdout=io.StringIO();stderr=io.StringIO();error=None;code=None;expected=None
            command=job["command"][3:]+["--dry-run"]
            with mock.patch.object(sys,"argv",command),contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
                try:
                    code=main();ns=module["parse_args"]()
                    if job["system"]=="expgym":
                        expected=[str(module["_trace_path"](ns.output_dir,j,ns.trace_format)) for j in module["_build_jobs"](ns)]
                    else:
                        # Same original parsed N/strategies/root; tested actual
                        # source E2E separately verifies these emitted names.
                        expected=[str(ns.output_dir/"summary.json")]
                        for strategy in ns.strategies:
                            expected += [str(ns.output_dir/strategy/"result.json")]
                            expected += [str(ns.output_dir/strategy/"agents"/("agent_%d.json" % i)) for i in range(ns.agents)]
                except BaseException as exc:error=type(exc).__name__
            record={"invocation_id":job["invocation_id"],"resolved_argv":command,"exit_code":code,"error_type":error,
                "expected_paths_match":set(expected or [])==set(job["expected_files"]),
                "stdout_ref":l.s.io.write_new(directory,job["invocation_id"]+".stdout",stdout.getvalue().encode()),
                "stderr_ref":l.s.io.write_new(directory,job["invocation_id"]+".stderr",stderr.getvalue().encode())}
            results.append(record)
            if code!=0 or error or not record["expected_paths_match"]:break
    l.verify_plan(plan)
    passed=len(results)==len(plan["jobs"]) and all(r["exit_code"]==0 and r["error_type"] is None and r["expected_paths_match"] for r in results)
    if Path(plan["config"]["output_root"]).exists():raise AssertionError("dry_created_real_root")
    receipt={"schema_version":"restart-selected-source-cli-dry-v1","spec_ref":spec_ref,"passed":passed,"results":results,
        "actual_dry_calls":len(results),"plan":plan,"plan_is_intermediate_CPU_only":True,"network_calls":0,"key_content_read":False,
        "expected_path_scope":"Exp original _trace_path/_build_jobs; Pool original parsed N/strategies and source E2E emitted-name contract",
        "source_code_ref":l.s.ref(__file__)}
    ref=l.s.put(directory,"receipt.json",receipt);print(json.dumps(dict(ref,passed=passed,actual_dry_calls=len(results)),sort_keys=True))
    return 0 if passed else 2


if __name__=="__main__":sys.exit(main())
