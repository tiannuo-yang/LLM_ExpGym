"""Test-only subprocess seam; unconditional socket block and inert byte opener.

This deliberately bypasses real external authority using a private synthetic
grant so the unchanged real child/FD/source paths can be tested. It is NEVER a
real entrypoint or accepted producer and cannot reach a network endpoint.
"""
import argparse
import http.client
import os
from unittest import mock

import real_common as common
import real_authority as authority
import real_runner_child


def main():
    common.no_network()
    parser = argparse.ArgumentParser()
    parser.add_argument("--spec", required=True)
    parser.add_argument("--secret-fd", required=True, type=int)
    args = parser.parse_args()
    spec = common.read(args.spec)
    if not spec.get("cpu_fixture_boundary"):
        raise ValueError("explicit_CPU_fixture_spec_required")
    common.scoped(spec["logs"]).relative_to(common.HERE / "validation")
    transport = common.import_delegate()
    original = transport.authorized_delegate
    def synthetic(study, epoch, anchors, previous=None):
        go = {"output_root": study["output_root"], "invocation_ids": [spec["invocation_id"]],
            "not_before": study["whole_study"]["not_before"], "valid_until": study["whole_study"]["absolute_deadline"]}
        return authority.RealGrant(authority._TOKEN, study=study, epoch=epoch, anchors={}, go=go)
    def inert(scope, grant, **unused):
        body = common.encoded({"choices": [{"message": {"role": "assistant", "content": "Answer: {}", "reasoning_content": "CPU fixture only"},
            "finish_reason": "stop"}], "usage": {"prompt_tokens": 10, "completion_tokens": 5}})
        if spec.get("cpu_fixture_provider_abort") is True:
            # A newly generated CPU response, not an old model raw record.
            # Non-empty partial text must never become an owner answer.
            body = common.encoded({"choices": [{"message": {"role": "assistant", "content": "Partial CPU text, not a usable answer",
                "reasoning_content": "Aborted CPU reasoning retained"}, "finish_reason": "abort"}],
                "usage": {"prompt_tokens": 2901, "completion_tokens": 908, "reasoning_tokens": 754}})
        responses = [transport.FixtureResponse(body, url=scope.endpoint_url) for _ in range(8)]
        if spec.get("cpu_fixture_retry_class") == "RemoteDisconnected":
            responses = [http.client.RemoteDisconnected("CPU fixture disconnect"),
                         http.client.RemoteDisconnected("CPU fixture disconnect")] + responses
        opener = transport.FixtureOpener(responses)
        return original(scope, grant, opener=opener)
    with mock.patch.object(authority, "validate_real_authority", synthetic), mock.patch.object(transport, "authorized_delegate", inert):
        return real_runner_child.run(args.spec, args.secret_fd)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print("CPU_REAL_CHILD_ERROR_TYPE=" + type(exc).__name__)
        raise SystemExit(2)
