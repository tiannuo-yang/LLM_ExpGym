"""Frozen source runner with externally authorized byte transport and FD-only secret."""
import argparse
import copy
from dataclasses import asdict
from io import BytesIO
import json
from pathlib import Path
import runpy
import sys
import threading
import urllib.error

import real_authority as authority
from real_attempt_gate import AttemptGate, GateError
import real_common as common
from secret_fd import read_secret_fd


def _registered_start(spec, study, epoch, invocation, static, record):
    """Read-only independent journal admission before secret FD or source entry."""
    import real_journal
    plan = study["validated_plan_view"]
    iid = invocation["invocation_id"]
    journal = real_journal.Journal(study["output_root"], common.digest(study),
        plan["candidate"]["invocations"], plan["candidate"]["logical_rows"], create=False)
    try:
        if journal._stop_new:
            raise GateError("child_journal_operations_not_valid")
        names = journal._names()
        if iid + ".finish.json" in names or any(name.startswith(iid + ".partial.") for name in names):
            raise GateError("child_already_terminal_or_partial")
        start, start_sha = journal._read(iid + ".start.json")
        journal._validate_record(start, invocation, "start")
        expected = {"design_sha256": common.digest(study), "binding_sha256": common.digest(epoch),
            "phase3_implementation": common.identity(), "command_sha256": record["sha256"], "static_owners": static,
            "execution_kind": "phase3b_real_gated_original_source", "producer_schema": authority.PRODUCER_SCHEMA}
        if start_sha != spec["begin_sha256"] or common.encoded(start["bindings"]) != common.encoded(expected):
            raise GateError("child_start_science_epoch_command_owners_not_registered")
        operations = journal._read_operations()
        reservation = operations.get("budget." + iid + ".json")
        policy = plan["policy"]
        owner_count = len(invocation["logical_ids"]) if invocation["system"] == "expgym" else 4
        upper = owner_count * (policy["max_steps"] + 1) * (policy["max_retries"] + 1)
        payload = reservation["payload"] if reservation else {}
        expected_fields = {"kind", "purpose", "invocation_id", "upper_bound", "prior_reserved_upper_bound", "policy_max_http_attempts", "meaning"}
        if (set(payload) != expected_fields or payload.get("kind") != "identity"
                or payload.get("purpose") != "request_attempt_reservation" or payload.get("invocation_id") != iid
                or payload.get("upper_bound") != upper or payload.get("policy_max_http_attempts") != study["operations"]["max_http_attempts"]
                or type(payload.get("prior_reserved_upper_bound")) is not int or payload["prior_reserved_upper_bound"] < 0
                or payload["prior_reserved_upper_bound"] + upper > study["operations"]["max_http_attempts"]
                or payload.get("meaning") != "worst-case request bound; not known sent, usage or charge"):
            raise GateError("child_exact_durable_attempt_reservation_required")
        if journal.deployment_transition(epoch, operations)["mode"] != "same_epoch":
            raise GateError("child_epoch_not_current_recorded_deployment")
        epoch_event = next(v for v in operations.values() if v["payload"].get("kind") == "epoch"
            and v["payload"]["epoch_binding_sha256"] == common.digest(epoch))
        if epoch_event["payload"]["scientific_sha256"] != common.digest(study):
            raise GateError("child_operational_epoch_science_mismatch")
        journal._verify_manifest()
        return {"manifest_sha256": journal.manifest_sha256, "start_event_sha256": start["event_sha256"],
            "reservation": {"path": str(journal.root / "operations" / (reservation["name"] + ".json")),
                "sha256": common.sha(journal.root / "operations" / (reservation["name"] + ".json"))},
            "operational_epoch_event_sha256": epoch_event["event_sha256"]}
    except (real_journal.JournalError, OSError, ValueError, TypeError, KeyError, StopIteration) as exc:
        raise GateError("child_independent_journal_admission_failed") from exc
    finally:
        journal.close()


def claim_child(spec, study, epoch, grant):
    """One immutable entry for the registered invocation, including direct CLI."""
    iid = spec["invocation_id"]
    if type(grant) is not authority.RealGrant:
        raise GateError("exact_local_real_grant_required")
    grant.check(iid)
    if grant.study_sha256 != common.digest(study) or grant.epoch_sha256 != common.digest(epoch):
        raise GateError("child_study_epoch_grant_mismatch")
    root = common.scoped(study["output_root"])
    if grant.go["output_root"] != str(root):
        raise GateError("child_root_not_registered")
    invocation = next(x for x in study["validated_plan_view"]["candidate"]["invocations"] if x["invocation_id"] == iid)
    if invocation["model"] != epoch["model"]:
        raise GateError("child_invocation_model_mismatch")
    expected = {"logs": root / "logs" / iid, "dump_dir": root / invocation["dump_relative_dir"],
        "begin_path": root / "journal" / (iid + ".start.json"),
        "identity_path": root / "logs" / iid / "actual_owner_identity.json"}
    if any(common.scoped(spec[key]) != path for key, path in expected.items()):
        raise GateError("child_paths_not_exact_registered_invocation")
    record = next(x for x in epoch["commands"] if x["invocation_id"] == iid)
    if record["command"] != spec["command"] or common.digest(record["command"]) != record["sha256"]:
        raise GateError("child_argv_binding_changed")
    for name in ("begin", "identity"):
        if common.sha(expected[name + "_path"]) != spec[name + "_sha256"]:
            raise GateError("child_begin_identity_changed")
    owner_identity = common.read(expected["identity_path"])
    rows = common.core().logical_rows(study["validated_plan_view"], invocation)
    static = common.a3_module("owners").static_owners(rows)
    if (owner_identity.get("static_owners_sha256") != common.digest(static)
            or owner_identity.get("command_sha256") != record["sha256"]
            or [x["owner_id"] for x in owner_identity["planned_owners"]] != [x["owner_id"] for x in static]):
        raise GateError("child_owner_identity_not_registered_scope")
    journal_admission = _registered_start(spec, study, epoch, invocation, static, record)
    path = expected["logs"] / "real_child_entry.json"
    common.write(path, {"schema_version": "phase3b-real-child-entry-v1", "invocation_id": iid,
        "study_sha256": grant.study_sha256, "epoch_sha256": grant.epoch_sha256,
        "begin_sha256": spec["begin_sha256"], "identity_sha256": spec["identity_sha256"],
        "command_sha256": record["sha256"], "journal_admission": journal_admission,
        "generation_allowed_before_entry": False})
    return path


def run(spec_path, secret_fd):
    common.verify()
    spec = common.read(spec_path)
    if spec.get("kind") != "phase3b_real_source" or spec.get("implementation") != common.identity():
        raise GateError("real_child_requires_exact_complete_implementation")
    study, epoch = authority.pinned(spec["anchors"]["definition"]), authority.pinned(spec["anchors"]["epoch"])
    grant = authority.validate_real_authority(study, epoch, spec["anchors"], spec.get("previous_epoch"))
    iid = spec["invocation_id"]
    grant.check(iid)
    claim_child(spec, study, epoch, grant)
    secret = read_secret_fd(secret_fd)
    record = next(r for r in epoch["commands"] if r["invocation_id"] == iid)
    if record["command"] != spec["command"] or common.digest(record["command"]) != record["sha256"]:
        raise GateError("child_argv_binding_changed")
    identity = common.read(spec["identity_path"])
    if common.sha(spec["identity_path"]) != spec["identity_sha256"] or common.sha(spec["begin_path"]) != spec["begin_sha256"]:
        raise GateError("child_begin_identity_changed")
    planned = identity["planned_owners"]
    command = spec["command"][2:]
    path = Path(command[0])
    if path not in (common.main_source() / "scripts/run_paper_sweep.py", common.main_source() / "scripts/run_poolact.py"):
        raise GateError("frozen_actual_runner_required")
    sys.argv = command
    scope = runpy.run_path(str(path), run_name="phase3b_actual_real_runner")
    args = scope["parse_args"]()
    if args.backend != "openai" or args.resume or args.dry_run or getattr(args, "api_key", None) or str(args.api_key_file) != "/dev/null":
        raise GateError("only_fresh_real_source_execution")
    system = "poolact" if path.name == "run_poolact.py" else "expgym"
    plan = study["validated_plan_view"]
    policy, profile = plan["policy"], plan["profiles"][epoch["model"]]["profile"]
    selected, logs = common.scoped(args.output_dir), common.scoped(spec["logs"])
    if selected.exists():
        raise GateError("fresh_selected_root_required")
    jobs = scope["_build_jobs"](args) if system == "expgym" else []
    clients = common.a3_module("support").bridge.module("expgym.llm_clients")
    loop = common.a3_module("support").bridge.module("expgym.react_loop")
    protocol = common.a3_module("support").bridge.module("expgym.tool_protocol")
    original_init, original_loop = clients.OpenAICompatibleLLM.__init__, scope["run_react_loop"]
    registry, registry_lock = {}, threading.Lock()
    receipt = {"kind": "phase3b_real_source", "producer_schema": authority.PRODUCER_SCHEMA,
        "model_generation_count": None, "clients": [], "rendered_contexts": []}

    def namespace(context):
        if system == "expgym":
            job = next(j for j in jobs if asdict(j) == context["job"])
            return scope["_namespace_for_job"](args, job, None)
        repeat = scope["_repeat_namespace"](args, 0)
        repeat.question_index = args.question_index
        return scope["_agent_namespace"](repeat, args.strategies[0], context["agent_id"], None)

    def construct(self, *positional, **kwargs):
        grant.check(iid)
        candidates = [p for p in planned if p["context"] == kwargs.get("dump_context")]
        if len(candidates) != 1:
            raise GateError("client_must_match_one_preflight_owner")
        p = candidates[0]
        with registry_lock:
            if p["owner_id"] in registry:
                raise GateError("duplicate_client_for_owner")
            registry[p["owner_id"]] = self
        if kwargs.get("api_key") != authority.NOAUTH:
            raise GateError("real_client_requires_inert_constructor_placeholder")
        kwargs["api_key"] = secret
        kwargs["transport"] = common.blocked
        original_init(self, *positional, **kwargs)
        self._phase3b_planned = copy.deepcopy(p)
        self._phase3b_namespace = namespace(p["context"])
        receipt["clients"].append(self.dump_metadata)

    def run_loop(*positional, **kwargs):
        if positional:
            raise GateError("actual_runner_keyword_contract_required")
        llm = kwargs["llm"]
        p, ns = llm._phase3b_planned, llm._phase3b_namespace
        scenario = scope["_SCENARIOS"][ns.scenario]
        include_overhead = kwargs["include_overhead_in_observation"]
        expected_context = scope["_resolve_context"](scenario, include_overhead, ns, llm)
        expected_system = scope["_resolve_system_prompt"](scenario, include_overhead, ns) or loop.build_system_prompt()
        if (kwargs.get("context") != expected_context or kwargs.get("system_prompt") != expected_system
                or protocol.native_tool_schemas(kwargs["tools"]) != p["schemas"] or kwargs.get("tool_protocol") != "native"):
            raise GateError("actual_rendered_task_system_schema_not_preflight_compatible")
        initial = [{"role": "system", "content": protocol.native_system_prompt(expected_system)}]
        if expected_context:
            initial.append({"role": "user", "content": expected_context.strip()})
        render_path = logs / "rendered" / (common.digest(p["owner_id"]) + ".json")
        common.write(render_path, {"kind": "actual_rendered_context_before_wire", "owner_id": p["owner_id"],
            "client_id": llm.dump_metadata["client_id"], "actual_owner_identity_sha256": spec["identity_sha256"],
            "stable_initial_messages_sha256": common.digest(llm._redact_dump_value(initial)),
            "native_tools_sha256": common.digest(p["schemas"]), "dynamic_graph": "runtime suffix; independently reconstructed post-run",
            "generation_allowed_before_this_receipt": False})
        receipt["rendered_contexts"].append({"path": str(render_path), "sha256": common.sha(render_path)})
        transport = common.import_delegate()
        delegate = transport.authorized_delegate(transport.RequestScope(
            endpoint_url=authority.endpoint(grant.epoch["identity"]["endpoint"]) + "/chat/completions",
            timeout=policy["request_timeout"], auth_mode="bearer", api_key=secret), grant)
        llm._transport = AttemptGate(grant=grant, invocation_id=iid, client=llm, planned=p, profile=profile, policy=policy,
            dump_dir=spec["dump_dir"], evidence_dir=logs / "attempts", begin_path=spec["begin_path"],
            identity_path=render_path, initial_messages=initial, delegate=delegate)
        return original_loop(**kwargs)

    clients.OpenAICompatibleLLM.__init__ = construct
    scope["main"].__globals__["run_react_loop"] = run_loop
    code = 1
    try:
        code = scope["main"]() or 0
        return code
    except BaseException as exc:
        receipt["error_type"] = type(exc).__name__
        raise
    finally:
        clients.OpenAICompatibleLLM.__init__ = original_init
        scope["main"].__globals__["run_react_loop"] = original_loop
        receipt["runner_exit_code"] = code
        common.write(logs / "real_child_receipt.json", receipt)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--spec", required=True)
    parser.add_argument("--secret-fd", type=int, required=True)
    value = parser.parse_args()
    try:
        raise SystemExit(run(value.spec, value.secret_fd))
    except Exception as exc:
        print("REAL_CHILD_ERROR_TYPE=" + type(exc).__name__, file=sys.stderr)
        raise SystemExit(2)
