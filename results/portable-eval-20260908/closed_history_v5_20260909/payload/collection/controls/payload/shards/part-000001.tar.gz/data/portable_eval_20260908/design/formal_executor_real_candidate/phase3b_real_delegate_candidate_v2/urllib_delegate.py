"""Minimal urllib bytes delegate; real calls require an external live RealGrant.

Contract: delegate(urllib.request.Request, timeout) -> bytes. The surrounding
frozen client owns parsing, retries, raw dumps, and scoring; the outer attempt
gate owns authorization and durable send accounting. This module does neither.

The default constructor is unarmed. authorized_delegate requires the sibling
real_authority module's exact process-local RealGrant, which consumes a durable
per-request gate before the standard-library opener is constructed or entered.
The separate offline factory accepts only inert fixtures on .invalid endpoints.
Credentials are constructor-supplied memory values, never read from files/env,
printed, hashed, serialized, or placed in module-generated exception messages.
"""
import ipaddress
import math
from pathlib import Path
import re
import sys
import threading
import urllib.error
import urllib.parse
import urllib.request


class ScopeViolation(RuntimeError):
    """Non-retryable request/configuration mismatch; messages contain codes only."""


class DelegateProtocolError(RuntimeError):
    """Non-retryable violation of the opener/bytes contract."""


class RealDispatchUnavailable(RuntimeError):
    """This particular delegate/opener has no accepted real connection grant."""


class _MemoryOnly:
    __slots__ = ()

    def __reduce_ex__(self, protocol):
        raise TypeError("memory_only_object_cannot_be_serialized")


def _url(value):
    if (not isinstance(value, str) or not value or
            any(ord(char) < 33 or ord(char) > 126 for char in value) or "\\" in value):
        raise ScopeViolation("invalid_endpoint_url")
    try:
        parsed = urllib.parse.urlsplit(value)
        host, port = parsed.hostname, parsed.port
        if (parsed.scheme not in ("http", "https") or not host or parsed.username is not None
                or parsed.password is not None or parsed.query or parsed.fragment
                or "?" in value or "#" in value or "%" in parsed.netloc or "%" in parsed.path
                or (port is not None and not 1 <= port <= 65535)
                or not parsed.path.endswith("/chat/completions")
                or not parsed.path.startswith("/") or "//" in parsed.path
                or any(part in (".", "..") for part in parsed.path.split("/"))
                or urllib.parse.urlunsplit(parsed) != value):
            raise ValueError("invalid")
        if ":" in host:
            ipaddress.IPv6Address(host)
        elif re.fullmatch(r"[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?", host) is None:
            raise ValueError("invalid")
    except (ValueError, TypeError):
        raise ScopeViolation("invalid_endpoint_url") from None
    return parsed


def _timeout(value):
    if type(value) not in (int, float) or not math.isfinite(value) or value <= 0:
        raise ScopeViolation("invalid_request_timeout")
    return value


class RequestScope(_MemoryOnly):
    __slots__ = ("endpoint_url", "timeout", "auth_mode", "_authorization", "_parsed")

    def __init__(self, endpoint_url, timeout, auth_mode, api_key=None):
        parsed = _url(endpoint_url)
        checked_timeout = _timeout(timeout)
        if auth_mode not in ("bearer", "none"):
            raise ScopeViolation("explicit_auth_mode_required")
        if auth_mode == "bearer":
            if (not isinstance(api_key, str) or not api_key
                    or any(ord(char) < 33 or ord(char) > 126 for char in api_key)):
                raise ScopeViolation("invalid_memory_bearer_credential")
            authorization = "Bearer " + api_key
        else:
            if api_key is not None:
                raise ScopeViolation("no_auth_must_not_have_credential")
            authorization = None
        for name, value in (("endpoint_url", endpoint_url), ("timeout", checked_timeout),
                ("auth_mode", auth_mode), ("_authorization", authorization), ("_parsed", parsed)):
            object.__setattr__(self, name, value)

    def __setattr__(self, name, value):
        raise TypeError("request_scope_is_immutable")

    def __repr__(self):
        return "RequestScope(auth_mode=%r, credential=<memory-only>)" % self.auth_mode

    def validate(self, request, timeout):
        if type(request) is not urllib.request.Request:
            raise ScopeViolation("exact_urllib_request_required")
        if _timeout(timeout) != self.timeout:
            raise ScopeViolation("request_timeout_changed")
        if (request.full_url != self.endpoint_url or request.type != self._parsed.scheme
                or request.host != self._parsed.netloc or request.selector != self._parsed.path
                or request.has_proxy() or getattr(request, "_tunnel_host", None) is not None):
            raise ScopeViolation("request_endpoint_or_proxy_changed")
        if request.get_method() != "POST" or type(request.data) is not bytes:
            raise ScopeViolation("post_bytes_body_required")
        if type(request.headers) is not dict or type(request.unredirected_hdrs) is not dict or request.unredirected_hdrs:
            raise ScopeViolation("unregistered_header_container_or_override")
        headers = {}
        for key, value in request.headers.items():
            if not isinstance(key, str) or not isinstance(value, str) or key.lower() in headers:
                raise ScopeViolation("invalid_or_duplicate_header")
            headers[key.lower()] = value
        expected = {"content-type"}
        if self.auth_mode == "bearer":
            expected.add("authorization")
        if set(headers) != expected or headers.get("content-type") != "application/json":
            raise ScopeViolation("unregistered_header_or_content_type")
        if self.auth_mode == "bearer" and headers["authorization"] != self._authorization:
            raise ScopeViolation("authorization_header_mismatch")


class NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def http_error_302(self, req, fp, code, msg, headers):
        # Own the actual stdlib entry: inherited handlers parse Location before
        # redirect_request, losing original URL/status/body on malformed input.
        # Never inspect Location or follow; preserve caller-owned evidence.
        raise urllib.error.HTTPError(req.full_url, code, msg, headers, fp)

    http_error_301 = http_error_303 = http_error_307 = http_error_308 = http_error_302

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # Preserve redirect response/body ownership as HTTPError, with no retry,
        # no follow-up request, and no credential forwarding to the new target.
        raise urllib.error.HTTPError(req.full_url, code, msg, headers, fp)


class _UnarmedProtocolHandler(urllib.request.BaseHandler):
    handler_order = 100

    def http_open(self, request):
        raise RealDispatchUnavailable("real_transport_not_authorized")

    https_open = http_open


def build_unarmed_opener():
    """Standard-library handler chain with NO connect-capable protocol handler.

    Empty ProxyHandler avoids environment proxy discovery. No default FTP/file
    handlers are installed. This constructor always remains blocked; the real
    factory uses a separate handler chain after its per-request grant check.
    """
    opener = urllib.request.OpenerDirector()
    for handler in (urllib.request.ProxyHandler({}), _UnarmedProtocolHandler(),
            NoRedirectHandler(), urllib.request.HTTPDefaultErrorHandler(),
            urllib.request.HTTPErrorProcessor(), urllib.request.UnknownHandler()):
        opener.add_handler(handler)
    opener.addheaders = []
    return opener


def _build_real_opener():
    """Only called after external RealGrant consumes this request's wire permit.

    No environment proxies, redirect following, cookies, auth retries, FTP,
    local-file or data handlers. HTTPS uses urllib's standard verified TLS.
    """
    opener = urllib.request.OpenerDirector()
    for handler in (urllib.request.ProxyHandler({}), NoRedirectHandler(),
            urllib.request.HTTPHandler(), urllib.request.HTTPSHandler(),
            urllib.request.HTTPDefaultErrorHandler(), urllib.request.HTTPErrorProcessor(),
            urllib.request.UnknownHandler()):
        opener.add_handler(handler)
    opener.addheaders = []
    return opener


def _real_grant_class():
    # The caller loads its validated authority first. Never search sys.path or
    # accept a same-name module from another checkout, and never duck-type GO.
    expected = Path(__file__).resolve().parent.parent / "phase3b_real_execution_candidate/real_authority.py"
    module = sys.modules.get("real_authority")
    if module is None or Path(getattr(module, "__file__", "")).resolve() != expected:
        raise ScopeViolation("validated_real_authority_module_required")
    candidate = getattr(module, "RealGrant", None)
    if not isinstance(candidate, type):
        raise ScopeViolation("validated_real_grant_type_required")
    return candidate


class FixtureResponse(_MemoryOnly):
    """Module-owned inert response: bytes/errors only, no callbacks or I/O."""
    __slots__ = ("body", "url", "read_error", "close_error", "read_count", "close_count")

    def __init__(self, body, url=None, read_error=None, close_error=None):
        for error in (read_error, close_error):
            if error is not None and not isinstance(error, BaseException):
                raise ScopeViolation("fixture_error_must_be_exception")
        self.body, self.url = body, url
        self.read_error, self.close_error = read_error, close_error
        self.read_count = self.close_count = 0

    def geturl(self):
        return self.url

    def read(self):
        self.read_count += 1
        if self.read_error is not None:
            raise self.read_error
        return self.body

    def close(self):
        self.close_count += 1
        if self.close_error is not None:
            raise self.close_error


class FixtureOpener(_MemoryOnly):
    """Inert opener script. The Request (including headers) stays only in memory."""
    __slots__ = ("_steps", "_lock", "call_count", "last_request", "last_timeout")

    def __init__(self, steps):
        if not isinstance(steps, (list, tuple)) or any(
                type(step) is not FixtureResponse and not isinstance(step, BaseException) for step in steps):
            raise ScopeViolation("only_inert_fixture_responses_or_exceptions")
        self._steps, self._lock = list(steps), threading.Lock()
        self.call_count = 0
        self.last_request = self.last_timeout = None

    def open(self, request, timeout):
        with self._lock:
            self.call_count += 1
            self.last_request, self.last_timeout = request, timeout
            if not self._steps:
                raise DelegateProtocolError("fixture_script_exhausted")
            step = self._steps.pop(0)
            if type(step) is FixtureResponse and step.url is None:
                step.url = request.full_url
        if isinstance(step, BaseException):
            raise step
        return step

    def __repr__(self):
        return "FixtureOpener(cpu_only=True)"


_CPU_TOKEN = object()


class UrllibDelegate(_MemoryOnly):
    __slots__ = ("_scope", "_opener", "_token", "_grant")

    def __init__(self, scope):
        if type(scope) is not RequestScope:
            raise ScopeViolation("explicit_request_scope_required")
        object.__setattr__(self, "_scope", scope)
        object.__setattr__(self, "_opener", None)
        object.__setattr__(self, "_token", None)
        object.__setattr__(self, "_grant", None)

    def __setattr__(self, name, value):
        raise TypeError("delegate_is_immutable")

    @property
    def cpu_bytes_only(self):
        return self._token is _CPU_TOKEN and type(self._opener) is FixtureOpener

    @property
    def real_grant(self):
        """Exact process-local identity for the outer RealAttemptGate binding."""
        return self._grant

    def __repr__(self):
        mode = "offline_fixture" if self.cpu_bytes_only else "external_grant" if self._grant is not None else "unarmed"
        return "UrllibDelegate(mode=%s)" % mode

    def __call__(self, request, timeout):
        if not self.cpu_bytes_only and self._grant is None:
            raise RealDispatchUnavailable("real_transport_not_authorized")
        self._scope.validate(request, timeout)
        if self._grant is not None:
            try:
                if type(self._grant) is not _real_grant_class():
                    raise ScopeViolation("wrong_process_local_real_grant")
                # RealAttemptGate already associated this exact Request with
                # fsynced raw/gate identity. Consume once; no extra wire header.
                self._grant.check_transport(request, timeout, scope_endpoint=self._scope.endpoint_url)
            except Exception:
                # Permission/filesystem errors are not transport retries. Do not
                # expose exception text, which may contain private inputs.
                raise ScopeViolation("transport_authorization_denied") from None
            if self._opener is None:
                try:
                    opener = _build_real_opener()
                except Exception:
                    raise DelegateProtocolError("opener_initialization_failed") from None
                object.__setattr__(self, "_opener", opener)
        # An opening HTTPError is not consumed or closed here: the frozen client
        # must read its original body/status/headers and decide bounded retry.
        response = self._opener.open(request, timeout=timeout)
        try:
            if response.geturl() != self._scope.endpoint_url:
                raise ScopeViolation("opener_changed_response_endpoint")
            body = response.read()
            if type(body) is not bytes:
                raise DelegateProtocolError("response_body_must_be_bytes")
        except BaseException as primary:
            try:
                response.close()
            except BaseException as cleanup:
                # Preserve the primary type/object and retain secondary cleanup
                # evidence in memory without formatting either exception.
                primary.__dict__["delegate_close_error"] = cleanup
            raise
        else:
            # On successful read, close failure remains the original exception.
            response.close()
            return body


def cpu_fixture_delegate(scope, injected_opener):
    if type(scope) is not RequestScope or type(injected_opener) is not FixtureOpener:
        raise ScopeViolation("owned_cpu_fixture_opener_required")
    if not scope._parsed.hostname.endswith(".invalid"):
        raise ScopeViolation("cpu_fixture_requires_reserved_invalid_endpoint")
    result = UrllibDelegate(scope)
    object.__setattr__(result, "_opener", injected_opener)
    object.__setattr__(result, "_token", _CPU_TOKEN)
    return result


def authorized_delegate(scope, grant, *, opener=None):
    """Real opener path, armed only by externally validated per-request grants.

    opener=None selects the standard-library implementation lazily after a
    successful request-gate consumption. Offline tests may inject only the
    owned inert FixtureOpener, never an arbitrary callable/opener or CPU flag.
    The sibling authority owns GO/source/runtime checks and secret-FD loading.
    """
    if type(grant) is not _real_grant_class():
        raise ScopeViolation("exact_real_grant_required")
    if opener is not None and type(opener) is not FixtureOpener:
        raise ScopeViolation("only_owned_fixture_opener_may_be_injected")
    result = UrllibDelegate(scope)
    object.__setattr__(result, "_grant", grant)
    object.__setattr__(result, "_opener", opener)
    return result
