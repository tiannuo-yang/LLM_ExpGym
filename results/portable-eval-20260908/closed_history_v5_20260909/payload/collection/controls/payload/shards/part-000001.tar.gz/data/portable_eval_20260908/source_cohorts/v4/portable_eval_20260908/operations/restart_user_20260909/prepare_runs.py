"""Prepare explicit fresh full/smoke specs, without credentials or model calls."""
import argparse
import copy
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
N = HERE.parents[1]
B = N.parents[2]
WS = B.parent
REPO = B / 'source_cohorts/v5/LLM_ExpGym'
sys.path.insert(0, str(HERE / 'planner_candidate_v1'))
import planner
import launcher
import support as s


def runtime(prefix):
    prefix = Path(prefix)
    executable = prefix / 'bin/python'
    return {'executable': str(executable), 'resolved_executable_ref': s.ref(executable.resolve()),
            'prefix': str(prefix), 'pyvenv_config_ref': s.ref(prefix / 'pyvenv.cfg')}


def replace_flag(command, name, value):
    assert command.count(name) == 1, name
    command[command.index(name) + 1] = str(value)


def selected_smoke(config):
    data = planner.inventory(REPO, config['source_acceptance_ref']['path'], config['legacy_runtime_root'])
    matrix = planner.build_manifest(config['run_id'], [config['model']], config['repeat_policy'],
                                    config['schedule_seed'], config['base_seed'], data,
                                    supersedes=config['supersedes'])
    all_jobs = launcher.formal_jobs(config, matrix)
    rows_by_id = {row['logical_id']: row for row in matrix['logical_rows']}
    jobs = []
    for full in all_jobs:
        if full['outerrep'] != 0:
            continue
        rows = [rows_by_id[lid] for lid in full['logical_ids']]
        row = rows[0]
        selector, scenario = row['selector'], row['scenario']
        if scenario == 'restricted_search':
            # Reuse a shape from the formal planner, then bind the separate
            # previously used seed-1 development snapshot explicitly below.
            wanted = selector['data_source'] == 'phantom_seed2' and selector['question_index'] == 0
        elif scenario == 'evidence_audit':
            wanted = selector['question_index'] == 0
        else:
            wanted = selector['tuning_task'] == 'hpobench:nasbench101:A'
            wanted |= (full['system'] == 'expgym' and selector['tuning_task'] == 'hpobench:paramnet:adult:steps'
                       and row['regime'] == 'cost_moderate')
        if not wanted:
            continue
        job = copy.deepcopy(full)
        if scenario == 'restricted_search':
            flag = '--search-data-source' if job['system'] == 'expgym' else '--data-source'
            replace_flag(job['command'], flag, 'phantom_seed1')
            replace_flag(job['selection_argv'], flag, 'phantom_seed1')
            old_output = job['output_dir']
            new_output = str(Path(config['output_root']) / 'results' / 'smoke-seed1' / job['invocation_id'])
            job['output_dir'] = new_output
            job['output_relative_dir'] = str(Path(new_output).relative_to(config['output_root']))
            replace_flag(job['command'], '--output-dir', new_output)
            for key in ('expected_files', 'terminal_artifacts'):
                job[key] = [path.replace(old_output, new_output, 1).replace('phantom_seed2', 'phantom_seed1') for path in job[key]]
            job['smoke_selection'] = {'data_source': 'phantom_seed1', 'question_index': 0}
        if scenario == 'evidence_audit' and job['system'] == 'expgym':
            # Smoke exercises order zero only; formal retains all three orders.
            rows = [r for r in rows if r['order'] == 0]
            assert len(rows) == 1
            replace_flag(job['command'], '--audit-reps', 1)
            replace_flag(job['selection_argv'], '--audit-reps', 1)
            job['logical_ids'] = [rows[0]['logical_id']]
            job['expected_model_terminals'] = 1
            job['sampling_seed_labels'] = [config['base_seed']]
            job['terminal_artifacts'] = [str(Path(config['output_root']) / rows[0]['result_artifact'])]
            job['expected_files'] = list(job['terminal_artifacts'])
        if job['system'] == 'poolact':
            replace_flag(job['command'], '--agents', 2)
            replace_flag(job['selection_argv'], '--agents', 2)
            job['expected_model_terminals'] = 2
            job['sampling_seed_labels'] = job['sampling_seed_labels'][:2]
            job['expected_files'] = [path for path in job['expected_files']
                                     if not path.endswith(('/agents/agent_2.json', '/agents/agent_3.json'))]
        job['smoke_only'] = True
        jobs.append(job)
    assert len(jobs) == 28, len(jobs)
    assert sum(j['expected_model_terminals'] for j in jobs) == 46
    assert sum(j['system'] == 'expgym' for j in jobs) == 10
    assert sum(j['system'] == 'poolact' for j in jobs) == 18
    assert sum(j['runtime_profile_required'] == 'paramnet_legacy' for j in jobs) == 1
    refs = [dict(path=r['path'], sha256=r['sha256']) for r in data['files'].values()]
    for kind in ('qa', 'corpus'):
        path = Path(data['files']['search2.' + kind]['path'].replace('seed_2-', 'seed_1-'))
        assert path.is_file()
        refs.append(s.ref(path))
    return jobs, refs


def prepare(model, mode):
    smoke = mode == 'selected_smoke'
    run_id = 'restart-20260909-v5-%s-%s' % (model, 'smoke' if smoke else 'formal')
    service = ('dual_k3_v1/runs/1203653/k3_formal' if model == 'kimi-k3'
               else 'dual_glm_v1/runs/1203652/glm_formal')
    profile = (B / 'request_profiles/kimi-k3-v3.json' if model == 'kimi-k3'
               else N / 'profiles/development_declared_v1/glm-5.3.json')
    config = {
        'repo_root': str(REPO), 'run_id': run_id, 'model': {'label': model, 'model_id': model},
        'output_root': str(N / 'formal_runs' / run_id),
        'source_acceptance_ref': s.ref(HERE / 'source_acceptance_v5_final.json'),
        'profile_ref': s.ref(profile),
        'deployment_ref': s.ref(B / 'serving/phase_candidates' / service / 'deployment.json'),
        'runtime_validation_ref': s.ref(B / 'serving/runtime_candidates/gumbel_midpoint_v1/manifests/validation_v6.json'),
        'legacy_runtime_root': str(WS / 'kimi_k3_eval/data_runtime'),
        'runtimes': {'native': runtime(WS / 'LLM_ExpGym/.venv'),
                     'paramnet_legacy': runtime(WS / 'kimi_k3_eval/data_runtime/.venv-hpo')},
        'repeat_policy': copy.deepcopy(planner.DEFAULT_REPEAT_POLICY),
        'schedule_seed': 20260909, 'base_seed': 1210 if smoke else 2200,
        'supersedes': ['parallel-full-20260908-k3-r3', 'parallel-full-20260908-glm-r3'],
        'environment': {'PYTHONNOUSERSITE': '1',
            'HPOBENCH_ROOT': str(WS / 'LLM_ExpGym/data/hpo_tuning/HPOBench'),
            'XDG_DATA_HOME': str(WS / 'LLM_ExpGym/data/hpo_tuning/hpobench_data'),
            'XDG_CACHE_HOME': str(WS / 'LLM_ExpGym/data/hpo_tuning/hpobench_cache'),
            'XDG_CONFIG_HOME': str(WS / 'kimi_k3_eval/data_runtime/hpobench_config'),
            'OMP_NUM_THREADS': '1', 'OPENBLAS_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1'},
        'policy': {'workers': 8 if smoke else 32, 'max_steps': 4 if smoke else 30,
            'max_evals': 3 if smoke else 30, 'max_tokens': 32768, 'max_context_tokens': 131072,
            'max_protocol_retries': 1, 'max_retries': 2, 'request_timeout': 1800 if smoke else 3600,
            'retry_base_seconds': 3, 'retry_max_seconds': 30, 'tuning_final_policy': 'legacy',
            'missing_final_policy': 'task-abstention-v1', 'stop_new_before_deadline_seconds': 3600,
            'max_wall_seconds': 7200 if smoke else 86400},
    }
    spec = {'schema_version': 'restart-compile-input-v1', 'mode': mode, 'config': config}
    if smoke:
        config['profiles'] = {model: launcher.normalized_profile(json.loads(profile.read_bytes()))}
        deployment = json.loads(Path(config['deployment_ref']['path']).read_bytes())
        config['endpoint'] = launcher.wire._endpoint(deployment['router_url'])
        spec['jobs'], spec['selected_input_refs'] = selected_smoke(config)
    directory = HERE / 'prepared_specs_v1' / run_id
    directory.parent.mkdir(exist_ok=True)
    s.io.new_directory(directory)
    ref = s.put(directory, 'spec.json', spec)
    print(json.dumps(ref, sort_keys=True))


if __name__ == '__main__':
    args = argparse.ArgumentParser(description=__doc__)
    args.add_argument('--model', required=True, choices=['kimi-k3', 'glm-5.3'])
    args.add_argument('--mode', required=True, choices=['selected_smoke', 'formal_mixed'])
    parsed = args.parse_args()
    prepare(parsed.model, parsed.mode)
