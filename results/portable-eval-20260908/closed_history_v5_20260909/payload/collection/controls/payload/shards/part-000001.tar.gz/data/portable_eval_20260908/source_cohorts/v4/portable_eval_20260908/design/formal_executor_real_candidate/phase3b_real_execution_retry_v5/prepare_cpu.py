"""Bounded CPU acceptance; no real key/API/health/Slurm or live pilot data."""
import argparse
import difflib
import os
from pathlib import Path
import subprocess
import re
import time

import real_common as common

HISTORICAL_REAL = Path("/lustrefs/users/chufan.shi/codex_space_tn/portable_eval_20260908/design/formal_executor_real_candidate/phase3b_real_execution_candidate")


def prepare(output, *, native_python=None, legacy_runtime=None):
    output = common.scoped(output)
    output.relative_to(common.HERE / "validation")
    if output.exists():
        raise ValueError("fresh_CPU_acceptance_directory_required")
    fd = common.directory(output, create=True)
    os.close(fd)
    identity = common.identity()
    old_examples = set((common.HERE / "validation").glob("cpu_real_*/CPU_ONLY_*v3.json")) | set((common.HERE / "validation").glob("cpu_real_*/CPU_ONLY_source_adapter_report.json"))
    old_abort_examples = set((common.HERE / "validation").glob("cpu_real_*/CPU_ONLY_provider_abort_source.json"))
    started = time.time()
    results = []
    native = Path(native_python or os.environ["FORMAL_CPU_NATIVE_PYTHON"]).expanduser().absolute()
    runtime_root = Path(legacy_runtime or os.environ["FORMAL_CPU_LEGACY_RUNTIME"]).expanduser().absolute()
    interpreters = [native, runtime_root / ".venv-hpo/bin/python"]
    if any(not path.is_file() for path in interpreters):
        raise ValueError("explicit_existing_native_and_legacy_interpreters_required")
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    for key in list(env):
        if key.lower() in ("http_proxy", "https_proxy", "all_proxy") or any(x in key.upper() for x in ("API_KEY", "ACCESS_TOKEN", "AUTH_TOKEN")):
            env.pop(key, None)
    env.update(NO_PROXY="*", no_proxy="*", FORMAL_CPU_NATIVE_PYTHON=str(native), FORMAL_CPU_LEGACY_RUNTIME=str(runtime_root))
    for index, interpreter in enumerate(interpreters):
        log = output / ("python_%d.log" % index)
        command = [str(interpreter), "-B", "-m", "unittest", "discover", "-s", str(common.HERE), "-p", "test_*.py", "-v"]
        began = time.monotonic()
        with log.open("xb") as stream:
            process = subprocess.run(command, cwd=str(common.frozen.WORKSPACE), env=env,
                stdout=stream, stderr=subprocess.STDOUT, check=False)
        results.append({"command": command, "exit_code": process.returncode, "elapsed_seconds": time.monotonic() - began,
            "interpreter_resolved": str(interpreter.resolve()), "interpreter_sha256": common.sha(interpreter.resolve()),
            "log": {"path": str(log), "sha256": common.sha(log)}})
        body = common.read_bytes(log).decode(errors="replace")
        counts = re.findall(r"Ran (\d+) tests? in", body)
        results[-1]["tests_run"] = int(counts[-1]) if counts else None
        results[-1]["skipped_test_count"] = len(re.findall(r"\.\.\. skipped ", body))
        results[-1]["expected_failure_count"] = len(re.findall(r"\.\.\. expected failure", body))
        results[-1]["unittest_terminal_line"] = body.rstrip().splitlines()[-1] if body.strip() else None
        print("CPU_INTERPRETER_FINISHED=%d EXIT=%d" % (index, process.returncode), flush=True)
    pairs = {"real_journal.py": "journal_store.py", "real_attempt_gate.py": "attempt_gate.py",
        "real_runner_child.py": "runner_child.py", "real_invocation.py": "invocation.py", "real_dispatch.py": "controller.py"}
    diffs = {}
    for target, source in pairs.items():
        before, after = common.read_bytes(common.CPU / source).decode().splitlines(True), common.read_bytes(common.HERE / target).decode().splitlines(True)
        diffs[target] = {"frozen_source": str(common.CPU / source), "source_sha256": common.sha(common.CPU / source),
            "new_sha256": common.sha(common.HERE / target), "unified_diff": "".join(difflib.unified_diff(before, after, fromfile=source, tofile=target))}
    common.write(output / "mechanical_diffs.json", diffs)
    current_examples = set((common.HERE / "validation").glob("cpu_real_*/CPU_ONLY_*v3.json")) | set((common.HERE / "validation").glob("cpu_real_*/CPU_ONLY_source_adapter_report.json"))
    examples = []
    for path in sorted(current_examples - old_examples):
        wrapper = common.read(path)
        report = wrapper["result"]
        folder = path.parent
        iid = report["invocation_id"]
        logs = folder / "run/logs" / iid
        refs = {}
        for label, candidate in (("wrapper", path), ("invocation_receipt", logs / "invocation_receipt.json"),
                ("child_spec", logs / "child_spec.json"), ("child_entry", logs / "real_child_entry.json"),
                ("raw_audit", logs / "raw_audit.json"), ("manifest", folder / "run/journal/manifest.json"),
                ("definition", folder / "definition.json"), ("epoch", folder / "epoch.json")):
            if candidate.is_file():
                refs[label] = {"path": str(candidate), "sha256": common.sha(candidate)}
        examples.append({"classification": "CPU fake wire and synthetic private grant; NOT real model/ROOT authority",
            "example_kind": "capture_accounting" if "fault" in wrapper else "original_source_success",
            "fault": wrapper.get("fault"), "invocation_id": iid, "passed": report["passed"],
            "accounting_namespace_complete": report.get("accounting", {}).get("namespace_accounting_complete"),
            "bindings": refs})
        for name in ("outer_test_interpreter", "source_child_interpreter"):
            if name in wrapper:
                examples[-1][name] = wrapper[name]
    common.write(output / "source_examples.json", {"classification": "CPU ONLY; no five real roles or six real ROOT anchors", "examples": examples})
    abort_examples = []
    new_abort_paths = set((common.HERE / "validation").glob("cpu_real_*/CPU_ONLY_provider_abort_source.json")) - old_abort_examples
    for path in sorted(new_abort_paths):
        wrapper = common.read(path)
        report, folder = wrapper["result"], path.parent
        iid = report["invocation_id"]
        logs = folder / "run/logs" / iid
        refs = {}
        for label, candidate in (("wrapper", path), ("invocation_receipt", logs / "invocation_receipt.json"),
                ("child_spec", logs / "child_spec.json"), ("child_entry", logs / "real_child_entry.json"),
                ("raw_audit", logs / "raw_audit.json"), ("manifest", folder / "run/journal/manifest.json"),
                ("definition", folder / "definition.json"), ("epoch", folder / "epoch.json")):
            if candidate.is_file():
                refs[label] = {"path": str(candidate), "sha256": common.sha(candidate)}
        abort_examples.append({"classification": "CPU fake wire and synthetic private grant; NOT real model/ROOT authority",
            "example_kind": "capture_accounting", "fault": "provider_abort", "invocation_id": iid,
            "passed": report["passed"], "accounting_namespace_complete": report.get("accounting", {}).get("namespace_accounting_complete"),
            "source_child_interpreter": wrapper["source_child_interpreter"],
            "outer_test_interpreter": wrapper["outer_test_interpreter"], "bindings": refs})
    common.write(output / "provider_abort_examples.json", {"classification": "CPU ONLY; separately retained terminal abort examples, never mixed into the original twenty", "examples": abort_examples})
    archive = HISTORICAL_REAL / "correction/v2_before/preservation_receipt.json"
    if common.sha(archive) != "265b12eed01c3015d627f4dd0ec491d1be9d6b3a8d490dfb83bbb983132f19eb":
        raise ValueError("historical_rejected_v2_preservation_changed")
    v2_diffs = {}
    for original in sorted(archive.parent.glob("*.py")):
        current = common.HERE / original.name
        v2_diffs[original.name] = {"historical_v2_sha256": common.sha(original), "current_sha256": common.sha(current),
            "unified_diff": "".join(difflib.unified_diff(common.read_bytes(original).decode().splitlines(True),
                common.read_bytes(current).decode().splitlines(True), fromfile="historical-v2/" + original.name, tofile="cohort-v4/" + original.name))}
    common.write(output / "historical_v2_to_cohort_v4_diffs.json", v2_diffs)
    receipt = {"schema_version": "phase3b-real-candidate-CPU-acceptance-v1", "classification": "CPU ONLY: not real registration, five-role evidence, or ROOT GO",
        "implementation_before": identity, "implementation_after": common.identity(), "started_at_unix": started, "finished_at_unix": time.time(),
        "interpreter_runs": results, "mechanical_diffs": {"path": str(output / "mechanical_diffs.json"), "sha256": common.sha(output / "mechanical_diffs.json")},
        "actual_model_calls": 0, "actual_health_calls": 0, "actual_Slurm_calls": 0, "real_secrets_read": 0,
        "implementation_version": "v4_source_cohort_retry_v5_known_stdlib_audit",
        "external_runtime_paths": {"native_python": str(native), "legacy_runtime": str(runtime_root), "legacy_python": str(interpreters[1])},
        "historical_evidence_source": "Rejected v2 source and preservation stay at their original pre-v4 absolute paths; not current acceptance",
        "rejected_v2_preservation": {"path": str(archive), "sha256": common.sha(archive)},
        "source_examples": {"path": str(output / "source_examples.json"), "sha256": common.sha(output / "source_examples.json")},
        "provider_abort_examples": {"path": str(output / "provider_abort_examples.json"), "sha256": common.sha(output / "provider_abort_examples.json")},
        "historical_v2_to_current_diffs": {"path": str(output / "historical_v2_to_cohort_v4_diffs.json"), "sha256": common.sha(output / "historical_v2_to_cohort_v4_diffs.json")},
        "passed": all(x["exit_code"] == 0 and x["skipped_test_count"] == 0
            and x["expected_failure_count"] == 0 and x["unittest_terminal_line"] == "OK"
            for x in results) and identity == common.identity(),
        "limitations": ["CPU metadata authority tests explicitly stub scientific compilers; fixture is rejected without those stubs",
            "Source subprocess tests use separately named unconditional-blocked-network fixture driver and synthetic key",
            "No registered formal definition or actual GO is produced", "No actual server receipt, provider cost or throughput inferred"]}
    common.write(output / "receipt.json", receipt)
    print("CPU_RECEIPT=" + str(output / "receipt.json"), flush=True)
    print("CPU_RECEIPT_SHA256=" + common.sha(output / "receipt.json"), flush=True)
    return 0 if receipt["passed"] else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True)
    parser.add_argument("--python", required=True)
    parser.add_argument("--legacy-runtime", required=True)
    args = parser.parse_args()
    raise SystemExit(prepare(args.output, native_python=args.python, legacy_runtime=args.legacy_runtime))
