"""Externally pinned formal authority. Definitions and CPU receipts grant nothing.

No credentials are accepted here. A real grant is local, nonserializable, and
authorizes a single durable gate for each exact Request object before transport.
"""
import copy
import math
import os
from pathlib import Path
import re
import threading
import time
from urllib.parse import urlsplit

import real_common as common

frozen = common.cpu_module("authority")
AuthorityError = frozen.AuthorityError
ROLES = frozen.ROLES
NOAUTH = "EXPGYM_REAL_CHILD_PLACEHOLDER_NOT_A_SECRET"
PRODUCER_SCHEMA = "phase3b-real-owner-raw-score-producer-v1"
_TOKEN = object()


def _hash(value):
    if not isinstance(value, str) or re.fullmatch(r"[0-9a-f]{64}", value) is None:
        raise AuthorityError("exact_external_sha256_required")
    return value


def _positive(value):
    if type(value) not in (int, float) or not math.isfinite(value) or value <= 0:
        raise AuthorityError("positive_finite_bound_required")
    return value


def endpoint(value, cpu=False):
    value = frozen.endpoint(value)
    if urlsplit(value).hostname.endswith(".invalid") or urlsplit(value).hostname == "invalid":
        raise AuthorityError("real_endpoint_not_cpu_reserved_domain")
    return value


def pinned(ref):
    if not isinstance(ref, dict) or set(ref) != {"path", "sha256"}:
        raise AuthorityError("external_path_and_bytes_pin_required")
    if common.sha(ref["path"]) != _hash(ref["sha256"]):
        raise AuthorityError("external_anchor_bytes_changed")
    return common.read(ref["path"])


def define_real(draft, whole_study):
    """Pure compiler: an explicit non-CPU definition, still not registration."""
    frozen.verify_study(draft)
    if any(m["model_id"].startswith("fixture/") for m in draft["validated_plan_view"]["candidate"]["models"]):
        raise AuthorityError("fixture_models_cannot_become_formal_definition")
    if draft["kind"] != "formal_draft":
        raise AuthorityError("CPU_definition_cannot_be_upgraded")
    value = copy.deepcopy(draft)
    value.update(schema_version="phase3b-real-study-definition-v1", kind="formal_real_definition",
        producer_schema=PRODUCER_SCHEMA, whole_study=copy.deepcopy(whole_study))
    verify_study(value)
    return value


def verify_study(study):
    if (study.get("schema_version") != "phase3b-real-study-definition-v1" or study.get("kind") != "formal_real_definition"
            or study.get("producer_schema") != PRODUCER_SCHEMA):
        raise AuthorityError("explicit_real_3B_definition_required")
    draft = copy.deepcopy(study)
    budget = draft.pop("whole_study")
    draft.pop("producer_schema")
    draft.update(schema_version="phase3b-study-definition-v1", kind="formal_draft")
    frozen.verify_study(draft)
    if any(m["model_id"].startswith("fixture/") for m in draft["validated_plan_view"]["candidate"]["models"]):
        raise AuthorityError("fixture_models_cannot_become_formal_definition")
    if set(budget) != {"not_before", "absolute_deadline", "max_allocation_gpu_seconds"}:
        raise AuthorityError("whole_study_absolute_and_allocation_bounds_required")
    for value in budget.values():
        _positive(value)
    if budget["not_before"] >= budget["absolute_deadline"]:
        raise AuthorityError("invalid_whole_study_window")
    common.scoped(study["output_root"])


def compile_epoch(study, *, model, epoch_id, previous, identity, evidence, prior_inventory_sha256):
    """Pure compilation. Five independently accepted real evidence roles required."""
    verify_study(study)
    plan = study["validated_plan_view"]
    selected = next((x for x in plan["candidate"]["models"] if x["label"] == model), None)
    fields = {"model_id", "endpoint", "credential", "native_python", "legacy_python", "deployment_id", "valid_until"}
    if (selected is None or type(epoch_id) is not int or epoch_id < 0 or set(identity) != fields
            or identity["model_id"] != selected["model_id"] or not identity["deployment_id"]
            or identity["credential"] != {"mode": "bearer_anonymous_fd"} or set(evidence) != ROLES):
        raise AuthorityError("incomplete_real_deployment_identity")
    endpoint(identity["endpoint"])
    _positive(identity["valid_until"])
    if epoch_id == 0:
        if previous is not None or prior_inventory_sha256 is not None:
            raise AuthorityError("initial_epoch_has_no_predecessor")
    elif (not isinstance(previous, dict) or previous.get("epoch_id") != epoch_id - 1 or previous.get("model") != model
            or previous.get("study_sha256") != common.digest(study)):
        raise AuthorityError("continuation_cannot_change_science_or_skip_epoch")
    else:
        _hash(prior_inventory_sha256)
    target, profile = study["targets"][model], plan["profiles"][model]
    checks = {"checkpoint": {"checkpoint_sha256": target["checkpoint_sha256"]},
        "runtime": {"runtime_semantics_sha256": target["runtime_semantics_sha256"], "template_parser_sha256": target["template_parser_sha256"]},
        "capacity": {"server_context_tokens": target["server_context_tokens"]},
        "ready": {"endpoint": identity["endpoint"], "healthy": True, "inflight": 0},
        "protocol": {"source_tree_sha256": common.frozen.SOURCE_SHA, "profile_sha256": profile["sha256"],
            "native_tools": True, "rendered_task_context": True, "assistant_tool_history": True}}
    proofs = {}
    for role, ref in evidence.items():
        data = pinned(ref)
        if (data.get("schema_version") != "phase3b-real-evidence-v1" or data.get("evidence_kind") != "real_observation"
                or data.get("role") != role or data.get("model_id") != identity["model_id"]
                or data.get("deployment_id") != identity["deployment_id"] or data.get("passed") is not True
                or not isinstance(data.get("source_artifacts"), list) or not data["source_artifacts"]):
            raise AuthorityError("CPU_flags_are_not_real_evidence")
        if set(data.get("producer", {})) != {"schema", "source"} or data["producer"]["schema"] != "independent-real-evidence-normalizer-v1":
            raise AuthorityError("independent_evidence_producer_required")
        source = data["producer"]["source"]
        if common.sha(source["path"]) != _hash(source["sha256"]):
            raise AuthorityError("evidence_producer_changed")
        for artifact in data["source_artifacts"]:
            if common.sha(artifact["path"]) != _hash(artifact["sha256"]):
                raise AuthorityError("real_evidence_source_bytes_changed")
        if any(common.encoded(data.get(k)) != common.encoded(v) for k, v in checks[role].items()):
            raise AuthorityError("real_evidence_semantics_mismatch")
        proofs[role] = dict(ref, contents=data)
    if profile["profile"]["randomness_contract"] == "strict" and proofs["protocol"]["contents"].get("strict_repeatability") is not True:
        raise AuthorityError("strict_repeatability_not_demonstrated")
    runtimes = {}
    for key in ("native_python", "legacy_python"):
        p = Path(identity[key]).absolute()
        # Interpreter symlinks are normal; bind resolved executable and venv cfg.
        cfg = p.parent.parent / "pyvenv.cfg"
        runtimes[key] = {"path": str(p), "resolved": str(p.resolve()), "sha256": common.sha(p.resolve()),
            "pyvenv_sha256": common.sha(cfg) if cfg.is_file() else None}
    commands = []
    for invocation in plan["candidate"]["invocations"]:
        if invocation["model"] != model:
            continue
        argv = common.core().fake_command(plan, invocation, study["output_root"], identity["native_python"], identity["legacy_python"])
        argv[argv.index("--backend") + 1] = "openai"
        argv[argv.index("--tool-protocol") + 1] = "native"
        argv += ["--base-url", identity["endpoint"]]
        commands.append({"invocation_id": invocation["invocation_id"], "outerrep": invocation["outerrep"], "command": argv, "sha256": common.digest(argv)})
    return {"schema_version": "phase3b-real-deployment-epoch-v1", "study_sha256": common.digest(study), "model": model,
        "epoch_id": epoch_id, "previous_epoch_sha256": common.digest(previous) if previous is not None else None,
        "prior_inventory_sha256": prior_inventory_sha256, "identity": copy.deepcopy(identity), "evidence": proofs,
        "runtime_files": runtimes, "commands": commands, "commands_sha256": common.digest(commands),
        "implementation": common.identity(), "profile_sha256": profile["sha256"], "real_authorized": False}


def verify_epoch(study, epoch, previous=None):
    expected = compile_epoch(study, model=epoch["model"], epoch_id=epoch["epoch_id"], previous=previous,
        identity=epoch["identity"], evidence={k: {x: v[x] for x in ("path", "sha256")} for k, v in epoch["evidence"].items()},
        prior_inventory_sha256=epoch["prior_inventory_sha256"])
    if common.encoded(expected) != common.encoded(epoch):
        raise AuthorityError("real_epoch_runtime_command_or_source_changed")


class RealGrant:
    """Non-pickleable process-local capability, never minted by CPU validation."""
    def __init__(self, token, *, study, epoch, anchors, go):
        if token is not _TOKEN:
            raise AuthorityError("external_real_validator_required")
        self.study_sha256, self.epoch_sha256 = common.digest(study), common.digest(epoch)
        self.epoch, self.anchors, self.go = copy.deepcopy(epoch), copy.deepcopy(anchors), copy.deepcopy(go)
        self.scope, self.pid = frozenset(go["invocation_ids"]), os.getpid()
        self.deadline = min(go["valid_until"], epoch["identity"]["valid_until"], study["whole_study"]["absolute_deadline"])
        self.not_before = max(go["not_before"], study["whole_study"]["not_before"])
        self.max_attempts, self._attempts_consumed = study["operations"]["max_http_attempts"], 0
        self.revoked, self._permits, self._lock = False, {}, threading.RLock()
        self.authorized_kind = "externally_registered_real"
        self._tracked = {}
        for label, folder in (("real_execution", common.HERE), ("frozen_3b", common.CPU), ("delegate", common.DELEGATE)):
            for name in epoch.get("implementation", {}).get(label, {}):
                path = folder / name
                self._tracked[str(path)] = self._stat(path)
        for value in epoch.get("runtime_files", {}).values():
            self._tracked[value["resolved"]] = self._stat(value["resolved"])
            cfg = Path(value["path"]).parent.parent / "pyvenv.cfg"
            if value.get("pyvenv_sha256") is not None:
                self._tracked[str(cfg)] = self._stat(cfg)

    @staticmethod
    def _stat(path):
        path = common.scoped(path)
        value = path.stat()
        return (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns, value.st_nlink)

    def __reduce_ex__(self, protocol):
        raise AuthorityError("real_grant_is_process_local")

    def check(self, invocation_id, now=None):
        now = time.time() if now is None else now
        if (self.pid != os.getpid() or self.revoked or invocation_id not in self.scope or not self.not_before <= now < self.deadline):
            raise AuthorityError("expired_revoked_or_outside_real_scope")
        for ref in self.anchors.values():
            if common.sha(ref["path"]) != ref["sha256"]:
                self.revoked = True
                raise AuthorityError("externally_pinned_authority_changed")
        if any(self._stat(path) != value for path, value in self._tracked.items()):
            self.revoked = True
            raise AuthorityError("accepted_code_or_runtime_metadata_changed")

    def consume_attempt(self, invocation_id):
        with self._lock:
            self.check(invocation_id)
            if self._attempts_consumed >= self.max_attempts:
                raise AuthorityError("request_attempt_reservation_exhausted")
            self._attempts_consumed += 1

    def arm_transport(self, invocation_id, request, timeout, gate_path, enter_path):
        """Called only after both durable records exist; no wire headers added."""
        with self._lock:
            self.check(invocation_id)
            if id(request) in self._permits:
                raise AuthorityError("request_object_already_armed")
            gate, enter = common.read(gate_path), common.read(enter_path)
            if (gate.get("kind") != "attempt_gate" or enter.get("kind") != "transport_enter"
                    or any(gate.get(k) != enter.get(k) for k in ("request_id", "epoch_sha256", "invocation_id"))
                    or gate.get("epoch_sha256") != self.epoch_sha256 or gate.get("invocation_id") != invocation_id):
                raise AuthorityError("durable_attempt_binding_required")
            self._permits[id(request)] = (request, invocation_id, timeout, str(gate_path), common.sha(gate_path),
                str(enter_path), common.sha(enter_path), request.data, tuple(request.header_items()))

    def check_transport(self, request, timeout, *, scope_endpoint):
        with self._lock:
            value = self._permits.pop(id(request), None)
            if value is None or value[0] is not request:
                raise AuthorityError("one_shot_durable_attempt_required")
            _, iid, wanted_timeout, gate, gate_sha, enter, enter_sha, data, headers = value
            self.check(iid)
            wanted_url = endpoint(self.epoch["identity"]["endpoint"]) + "/chat/completions"
            if (scope_endpoint != wanted_url or request.full_url != wanted_url or timeout != wanted_timeout
                    or request.data != data or tuple(request.header_items()) != headers
                    or common.sha(gate) != gate_sha or common.sha(enter) != enter_sha
                    or time.time() + timeout >= self.deadline):
                self.revoked = True
                raise AuthorityError("transport_scope_changed_after_gate")


def validate_real_authority(study, epoch, anchors, previous=None):
    # Caller must supply the exact externally obtained hashes. Internal self-SHA
    # fields, draft booleans, and CPU acceptance are deliberately insufficient.
    if not isinstance(anchors, dict) or set(anchors) != {"definition", "registration", "acceptance", "epoch", "go", "allocation"}:
        raise AuthorityError("six_external_ROOT_anchors_required")
    values = {key: pinned(ref) for key, ref in anchors.items()}
    if values["definition"] != study or values["epoch"] != epoch:
        raise AuthorityError("caller_inputs_not_external_bytes")
    for role in ("registration", "acceptance", "go", "allocation"):
        value = values[role]
        if value.get("schema_version") != "phase3b-real-" + role + "-v1" or value.get("kind") != "real_external_authority":
            raise AuthorityError("CPU_or_DRAFT_cannot_authorize_real")
        if value.get("definition_sha256") != anchors["definition"]["sha256"]:
            raise AuthorityError("whole_study_external_anchor_mismatch")
    registration, accepted, go, allocation = (values[k] for k in ("registration", "acceptance", "go", "allocation"))
    if (registration.get("registered") is not True or accepted.get("accepted") is not True or go.get("authorize") != "formal_real_dispatch"
            or accepted.get("producer_schema") != PRODUCER_SCHEMA or registration.get("producer_schema") != PRODUCER_SCHEMA):
        raise AuthorityError("registered_3B_real_producer_required")
    for role in ("registration", "acceptance", "epoch", "allocation"):
        if go.get(role + "_sha256") != anchors[role]["sha256"]:
            raise AuthorityError("ROOT_GO_must_bind_each_external_anchor")
    common.verify()
    if accepted.get("implementation") != common.identity() or epoch.get("implementation") != accepted["implementation"]:
        raise AuthorityError("accepted_complete_real_implementation_changed")
    verify_study(study)
    verify_epoch(study, epoch, previous)
    if (registration.get("output_root") != study["output_root"] or go.get("output_root") != study["output_root"]
            or go.get("model") != epoch["model"] or go.get("epoch_sha256") != anchors["epoch"]["sha256"]):
        raise AuthorityError("registered_scope_or_epoch_mismatch")
    registry = pinned(registration.get("global_registry"))
    if (registry.get("schema_version") != "phase3b-real-global-registry-v1" or registry.get("kind") != "real_external_authority"
            or not isinstance(registry.get("entries"), list)):
        raise AuthorityError("global_unique_registration_index_required")
    entries = registry["entries"]
    if (any(not isinstance(x, dict) for x in entries) or len({x.get("study_id") for x in entries}) != len(entries)
            or len({x.get("output_root") for x in entries}) != len(entries)):
        raise AuthorityError("duplicate_global_study_or_root_registration")
    current = [x for x in entries if x.get("study_id") == study["study_id"]]
    if len(current) != 1 or current[0] != {"study_id": study["study_id"], "definition_sha256": anchors["definition"]["sha256"],
            "output_root": study["output_root"], "producer_schema": PRODUCER_SCHEMA}:
        raise AuthorityError("definition_not_the_unique_global_registration")
    approved = registration.get("evidence", {}).get(epoch["model"], {}).get(str(epoch["epoch_id"]))
    wanted = {role: {x: value[x] for x in ("path", "sha256")} for role, value in epoch["evidence"].items()}
    if approved != wanted:
        raise AuthorityError("five_real_roles_not_independently_registered")
    ids = go.get("invocation_ids")
    all_ids = [x["invocation_id"] for x in epoch["commands"]]
    if not isinstance(ids, list) or not ids or len(ids) != len(set(ids)) or [iid for iid in all_ids if iid in ids] != ids:
        raise AuthorityError("unique_frozen_order_exact_invocation_scope_required")
    for key in ("not_before", "valid_until"):
        _positive(go.get(key))
    if go["not_before"] >= go["valid_until"]:
        raise AuthorityError("invalid_deployment_GO_window")
    if go["not_before"] < study["whole_study"]["not_before"] or go["valid_until"] > study["whole_study"]["absolute_deadline"]:
        raise AuthorityError("deployment_GO_cannot_reset_whole_study_deadline")
    _positive(allocation.get("gpu_count"))
    if type(allocation["gpu_count"]) is not int or allocation["gpu_count"] != 64:
        raise AuthorityError("registered_64_GPU_allocation_required")
    for key in ("allocation_start", "allocation_end", "prior_gpu_seconds"):
        value = allocation.get(key)
        if type(value) not in (float, int) or not math.isfinite(value) or value < 0:
            raise AuthorityError("explicit_whole_study_allocation_ledger_required")
    history = pinned(allocation.get("closed_allocation_ledger"))
    if (history.get("schema_version") != "phase3b-real-closed-allocation-ledger-v1"
            or history.get("kind") != "real_external_authority"
            or history.get("definition_sha256") != anchors["definition"]["sha256"]
            or not isinstance(history.get("allocations"), list)):
        raise AuthorityError("independent_closed_allocation_ledger_required")
    total, previous_end, seen = 0, 0, set()
    for row in history["allocations"]:
        if (not isinstance(row, dict) or set(row) != {"deployment_id", "gpu_count", "start", "end"}
                or row["deployment_id"] in seen or row["deployment_id"] == allocation["deployment_id"]
                or type(row["gpu_count"]) is not int or row["gpu_count"] != 64):
            raise AuthorityError("nonduplicate_closed_64_GPU_allocations_required")
        _positive(row["start"])
        _positive(row["end"])
        if row["start"] < previous_end or row["end"] <= row["start"] or row["end"] > allocation["allocation_start"]:
            raise AuthorityError("closed_allocation_chronology_changed")
        total += 64 * (row["end"] - row["start"])
        previous_end = row["end"]
        seen.add(row["deployment_id"])
    if total != allocation["prior_gpu_seconds"]:
        raise AuthorityError("whole_study_allocation_history_must_not_reset")
    if (allocation.get("deployment_id") != epoch["identity"]["deployment_id"]
            or allocation["allocation_end"] <= allocation["allocation_start"]
            or go["valid_until"] > allocation["allocation_end"]
            or allocation["prior_gpu_seconds"] + 64 * (allocation["allocation_end"] - allocation["allocation_start"])
                > study["whole_study"]["max_allocation_gpu_seconds"]):
        raise AuthorityError("whole_study_allocation_budget_or_deployment_mismatch")
    grant = RealGrant(_TOKEN, study=study, epoch=epoch, anchors=anchors, go=go)
    grant.check(ids[0])
    return grant


# Reservation arithmetic stays the frozen implementation. Epoch admission adds
# a global deployment-head check; the frozen local-chain writer alone is not
# sufficient when a new model starts at epoch zero.
reserve_invocation_attempts = frozen.reserve_invocation_attempts


def ensure_epoch_record(study, epoch, anchors, journal):
    with journal._op_lock:
        transition = journal.deployment_transition(epoch)
        if transition["mode"] == "same_epoch":
            return next(v for v in journal._read_operations().values()
                if v["payload"].get("kind") == "epoch" and v["payload"]["epoch_binding_sha256"] == common.digest(epoch))
        previous_event = None
        if transition["mode"] == "initial":
            prior = journal.snapshot_inventory()["inventory_sha256"]
            drain = epoch["evidence"]["ready"]["sha256"]
        else:
            linked = journal._continuation_link
            if (not isinstance(linked, dict) or linked["epoch_target_sha256"] != common.digest(epoch)
                    or linked["go_sha256"] != anchors["go"]["sha256"]
                    or linked["deployment_transition"] != transition):
                raise AuthorityError("new_deployment_requires_accepted_global_head_continuation")
            prior, drain = linked["prior_inventory_sha256"], linked["quiescence_sha256"]
            if transition["mode"] == "same_model_new_epoch":
                if epoch["prior_inventory_sha256"] != prior:
                    raise AuthorityError("new_epoch_prior_inventory_mismatch")
                previous_event = journal._epoch_records[epoch["model"]][-1]["event_sha256"]
        return journal.write_epoch(epoch["model"], epoch["epoch_id"], previous_event,
            common.digest(study), common.digest(epoch), prior, drain)
