"""Exact multi-owner native wire audit. No transport, scoring, or writes."""
from collections import Counter
import copy
from datetime import datetime
import hashlib
import json
import math
import os
from pathlib import Path
import stat

import retry_dependencies as dependencies
if Path(dependencies.__file__).resolve() != Path(__file__).resolve().parent / "retry_dependencies.py":
    raise ValueError("wrong_local_retry_dependencies_module")
_bridge = dependencies.frozen_scope().bridge
core, module, repository, sha = _bridge.core, _bridge.module, _bridge.repository, _bridge.sha
import retry_policy as _retry_policy
if Path(_retry_policy.__file__).resolve() != Path(__file__).resolve().parent / "retry_policy.py":
    raise ValueError("wrong_local_retry_policy_module")
retry_is_transient = _retry_policy.retry_is_transient


def same(a, b):
    return json.dumps(a, sort_keys=True, ensure_ascii=False, allow_nan=False) == json.dumps(b, sort_keys=True, ensure_ascii=False, allow_nan=False)


def strict_record(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("duplicate_dump_key")
            result[key] = value
        return result
    return json.loads(raw, object_pairs_hook=pairs)


def read_regular(path):
    """No FIFO, links, or parent-symlink traversal while inventorying raw files."""
    absolute = Path(path).absolute()
    descriptor = os.open(absolute.anchor, os.O_RDONLY | os.O_DIRECTORY)
    try:
        for part in absolute.parts[1:-1]:
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=descriptor)
            os.close(descriptor)
            descriptor = child
        file_descriptor = os.open(absolute.name, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW, dir_fd=descriptor)
        try:
            info = os.fstat(file_descriptor)
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                raise ValueError("raw_or_artifact_is_not_single_link_regular_file")
            with os.fdopen(file_descriptor, "rb", closefd=False) as source:
                return source.read(), info
        finally:
            os.close(file_descriptor)
    finally:
        os.close(descriptor)


def native_history_errors(messages):
    pending, errors = set(), []
    for message in messages:
        role = message.get("role")
        if role == "assistant":
            if pending:
                errors.append("assistant_before_all_tool_results")
            calls = message.get("tool_calls") or []
            ids = [call.get("id") for call in calls if isinstance(call, dict)]
            if len(ids) != len(calls) or any(not isinstance(i, str) or not i for i in ids) or len(ids) != len(set(ids)):
                errors.append("invalid_native_ids")
            pending = set(i for i in ids if isinstance(i, str))
        elif role == "tool":
            key = message.get("tool_call_id")
            if key not in pending:
                errors.append("orphan_or_duplicate_tool_result")
            else:
                pending.remove(key)
    if pending:
        errors.append("missing_tool_results")
    return errors


def generation_payload(profile, policy, seed):
    expected = {"model": profile["model"], "temperature": profile["temperature"],
                "top_p": profile["top_p"], "seed": seed, "max_tokens": policy["max_tokens"]}
    for key in ("top_k", "reasoning_effort"):
        if profile[key] is not None:
            expected[key] = profile[key]
    if profile["chat_template_kwargs"]:
        expected["chat_template_kwargs"] = profile["chat_template_kwargs"]
    return expected


def reported_usage(usage):
    """Delivered scalar semantics exactly match the frozen client; unknown stays null."""
    if usage is None:
        return {key: None for key in ("input_tokens", "output_tokens", "cache_read_tokens", "cache_write_tokens")}
    module("expgym.llm_clients").OpenAICompatibleLLM._validate_usage(usage)
    json.dumps(usage, allow_nan=False)
    details = usage.get("prompt_tokens_details") or usage.get("input_tokens_details") or {}
    first = lambda a, b: usage.get(a) if usage.get(a) is not None else usage.get(b)
    return {"input_tokens": first("prompt_tokens", "input_tokens"), "output_tokens": first("completion_tokens", "output_tokens"),
            "cache_read_tokens": details.get("cached_tokens"), "cache_write_tokens": details.get("cache_write_tokens")}


def usage_totals(records):
    results = {key: {"known_sum": 0, "reported_attempts": 0, "unknown_attempts": 0, "complete_total": None}
               for key in ("input_tokens", "output_tokens", "cache_read_tokens", "cache_write_tokens", "reasoning_tokens", "provider_total_tokens")}
    text_chars = nonempty = 0
    conflicts, finishes, states = [], Counter(), Counter()
    for record in records:
        states[record.get("state")] += 1
        response = record.get("response_json")
        if "response_raw" in record:
            # Cost is derived from retained wire bytes even when the separately
            # serialized parsed field is corrupt; the audit rejects that mismatch.
            try:
                response = json.loads(record["response_raw"])
            except (ValueError, TypeError):
                response = None
        usage = response.get("usage") if isinstance(response, dict) else None
        usage_valid = True
        try:
            values = reported_usage(usage)
        except (ValueError, TypeError):
            values = reported_usage(None)
            usage_valid = False
        reasoning = None
        if usage_valid and isinstance(usage, dict):
            candidates = [usage.get("reasoning_tokens")]
            candidates += [(usage.get(name) or {}).get("reasoning_tokens") for name in ("completion_tokens_details", "output_tokens_details") if isinstance(usage.get(name) or {}, dict)]
            candidates = [value for value in candidates if type(value) is int and value >= 0]
            if candidates:
                reasoning = candidates[0]
                if len(set(candidates)) != 1:
                    conflicts.append(record.get("request_id"))
                    reasoning = None
        values["reasoning_tokens"] = reasoning
        values["provider_total_tokens"] = usage.get("total_tokens") if usage_valid and isinstance(usage, dict) else None
        for name, value in values.items():
            if value is None:
                results[name]["unknown_attempts"] += 1
            else:
                results[name]["known_sum"] += value
                results[name]["reported_attempts"] += 1
        choices = response.get("choices") if isinstance(response, dict) else None
        if isinstance(choices, list) and choices and isinstance(choices[0], dict):
            finishes[choices[0].get("finish_reason")] += 1
            message = choices[0].get("message") or {}
            content = message.get("reasoning_content") if isinstance(message, dict) else None
            if isinstance(content, str) and content:
                nonempty += 1
                text_chars += len(content)
    for value in results.values():
        if value["unknown_attempts"] == 0:
            value["complete_total"] = value["known_sum"]
    return {"http_attempts": len(records), "states": dict(states), "finish_reasons": dict(finishes), "provider_usage": results,
            "reasoning_content_nonempty_attempts": nonempty, "reasoning_content_characters": text_chars,
            "reasoning_usage_conflicting_request_ids": conflicts, "reasoning_included_in_output_not_added": True}


def expgym_owners(rows, preflight, output_root, run_id):
    """Every expected trace is loaded and validated, not globbed/first-selected."""
    c, trace_module = core(), module("expgym.trace_v2")
    c.check_exp_probe(rows, preflight, output_root)
    probes = {row["path"]: row for row in preflight["rows"]}
    owners = []
    for row in rows:
        path = Path(output_root) / row["result_artifact"]
        trace = trace_module.load_trace_v2(path)
        probe = probes[str(path)]
        if trace["run"]["evaluation_identity"] != probe["evaluation_identity"]:
            raise ValueError("trace_evaluation_identity_mismatch")
        metadata = trace["run"].get("api_dump") or {}
        if metadata.get("run_id") != run_id:
            raise ValueError("trace_run_namespace_mismatch")
        schemas = probe["native_tool_schemas"]
        calls = []
        for i, call in enumerate(trace["llm_calls"], 1):
            usage = call.get("usage") or {}
            cache = usage.get("cache") or {}
            calls.append({"call_index": i, "attempts": call.get("attempt_usage"),
                "messages": trace_module.materialize_llm_input(trace, call["id"]),
                "output_message": call.get("output_message"), "finish_reason": call.get("finish_reason"),
                "forced": call.get("forced"), "request_attempts": call.get("request_attempts"),
                "delivered_usage": {"input_tokens": usage.get("input_tokens"), "output_tokens": usage.get("output_tokens"),
                    "cache_read_tokens": cache.get("read_tokens"), "cache_write_tokens": cache.get("write_tokens")}})
        owners.append({"owner_id": row["logical_id"], "logical_id": row["logical_id"], "client_id": metadata.get("client_id"),
            "run_id": run_id, "seed": row["sampling_seed_labels"][0], "schemas": schemas, "calls": calls,
            "context": {"runner": "expgym", "job": probe["job"], "trace_path": str(path)},
            "api_calls": len(calls), "http_request_attempts": trace["outcome"].get("http_request_attempts"),
            "history": [trace_module.materialize_message(trace, message["id"]) for message in trace["messages"] if not message.get("request_only")],
            "artifact": {"path": str(path), "sha256": sha(path)}})
    return owners


def pool_owners(row, preflight, output_root, run_id, max_context_tokens):
    """Uses frozen full prefix/graph augmentation and trim; no task execution."""
    loop = module("expgym.react_loop")
    schemas = preflight["native_tool_schemas"]
    schema_tokens = len(json.dumps(schemas, ensure_ascii=False, allow_nan=False)) // 3
    owners = []
    if len(row["agent_artifacts"]) != 4:
        raise ValueError("pool_requires_exactly_four_agents")
    for agent_id, relative in enumerate(row["agent_artifacts"]):
        path = Path(output_root) / relative
        agent = json.loads(path.read_text())
        metadata = agent.get("api_dump") or {}
        if (agent.get("agent_id") != agent_id or agent.get("seed") != row["sampling_seed_labels"][agent_id]
                or agent.get("strategy") != row["strategy"] or agent.get("repeat_index") != 0
                or metadata.get("run_id") != run_id or agent.get("tool_protocol") != "native"):
            raise ValueError("agent_identity_or_native_protocol_mismatch")
        messages, ledger = agent["messages"], agent["usage_attempts"]
        indices = [i for i, message in enumerate(messages) if message.get("role") == "assistant"]
        if len(indices) != len(ledger) or len(ledger) != agent.get("api_calls"):
            raise ValueError("agent_logical_call_count_mismatch")
        calls = []
        for number, (entry, index) in enumerate(zip(ledger, indices), 1):
            if entry.get("llm_call_index") != number:
                raise ValueError("agent_call_sequence_mismatch")
            prefix = copy.deepcopy(messages[:index])
            if max_context_tokens is not None:
                prefix = loop._trim_messages(prefix, max_context_tokens - schema_tokens)
                if loop._estimate_tokens(prefix) + schema_tokens > max_context_tokens:
                    raise ValueError("agent_reconstructed_context_over_budget")
            calls.append({"call_index": number, "attempts": entry["attempts"], "messages": prefix,
                          "output_message": messages[index], "forced": None, "finish_reason_not_serialized": True})
        owners.append({"owner_id": row["logical_id"] + ":agent%d" % agent_id, "logical_id": row["logical_id"],
            "client_id": metadata.get("client_id"), "seed": agent["seed"], "schemas": schemas, "run_id": run_id,
            "context": preflight["agent_dump_contexts"][agent_id], "calls": calls, "history": messages,
            "api_calls": agent["api_calls"], "http_request_attempts": agent["http_request_attempts"],
            "delivered_counters": {"input_tokens": agent["prompt_tokens"], "output_tokens": agent["completion_tokens"],
                                   "cache_read_tokens": agent["cached_prompt_tokens"]},
            "artifact": {"path": str(path), "sha256": sha(path)}})
    return owners


def audit_owners(owners, dump_dir, *, expected_owner_ids, profile, policy, endpoint, run_id, secret=None):
    """One exact invocation raw namespace. Partial/orphan cost is retained, never passed."""
    repository()
    clients = module("expgym.llm_clients")
    normalized_endpoint = clients._normalize_chat_completions_url(endpoint)
    redact = lambda value: core().helper("a21").redact_wire(value, secret, clients.OpenAICompatibleLLM._is_secret_field)
    errors, records, by_request, by_generation, snapshots = [], [], {}, {}, {}
    unparseable_files, owner_artifacts = [], {}
    if not expected_owner_ids or len(set(expected_owner_ids)) != len(expected_owner_ids) or Counter(owner["owner_id"] for owner in owners) != Counter(expected_owner_ids):
        errors.append({"rule": "planned_owner_set_mismatch"})
    root = Path(dump_dir)
    if root.is_symlink() or root.absolute() != root.resolve():
        totals = usage_totals([])
        totals["http_attempts"] = None
        for value in totals["provider_usage"].values():
            value["complete_total"] = None
        return {"passed": False, "errors": [{"rule": "raw_root_symlink"}], "owners": [],
                "totals_all_attempts": totals, "files": [], "raw_file_count": None,
                "limitations": ["Unsafe root not traversed; no costs inferred from unread files"]}
    all_paths = list(root.rglob("*")) if root.exists() else []
    paths = sorted(path for path in all_paths if path.parent == root)
    if any(path.is_symlink() or not path.is_file() or path.suffix != ".json" or path.parent != root for path in all_paths):
        errors.append({"rule": "unexpected_raw_file_or_directory"})
    for path in paths:
        try:
            raw_bytes, info = read_regular(path)
        except (OSError, ValueError):
            errors.append({"rule": "unreadable_or_unsafe_raw_file", "path": str(path)})
            unparseable_files.append(str(path))
            continue
        snapshots[str(path)] = {"sha256": hashlib.sha256(raw_bytes).hexdigest(), "bytes": len(raw_bytes), "mtime_ns": info.st_mtime_ns}
        if path.suffix != ".json":
            errors.append({"rule": "unexpected_raw_extension", "path": str(path)})
            unparseable_files.append(str(path))
            continue
        try:
            record = strict_record(raw_bytes)
            if not isinstance(record, dict):
                raise ValueError("attempt_must_be_object")
        except (ValueError, UnicodeDecodeError, RecursionError):
            errors.append({"rule": "unparseable_raw_dump_file", "path": str(path)})
            unparseable_files.append(str(path))
            continue
        records.append(record)
        identifier = record.get("request_id")
        if not isinstance(identifier, str) or not identifier or path.name != identifier + ".json" or identifier in by_request:
            errors.append({"rule": "raw_request_id_or_filename_duplicate", "path": str(path)})
        if not isinstance(identifier, str):
            continue
        by_request[identifier] = record
        generation = record.get("generation_id")
        if not isinstance(generation, str):
            errors.append({"rule": "invalid_generation_attempt_metadata", "request_id": identifier})
            continue
        by_generation.setdefault(generation, []).append(record)
        wall = record.get("wall_time_seconds")
        required_fields = {"response_raw", "response_json", "request_payload", "error", "will_retry", "retry_delay_seconds",
            "endpoint", "client_id", "run_id", "context", "max_attempts", "generation_id", "request_id", "attempt"}
        metadata_valid = (required_fields <= set(record) and record.get("schema_version") == "expgym.api_attempt.v1"
            and type(record.get("pid")) is int and record["pid"] > 0
            and type(record.get("thread_id")) is int and isinstance(record.get("thread_name"), str)
            and type(wall) in (int, float) and math.isfinite(wall) and wall >= 0)
        try:
            started = datetime.fromisoformat(record.get("started_at_utc"))
            finished = datetime.fromisoformat(record.get("finished_at_utc"))
            metadata_valid = metadata_valid and started.tzinfo is not None and finished.tzinfo is not None
        except (ValueError, TypeError):
            metadata_valid = False
        if not metadata_valid:
            errors.append({"rule": "invalid_raw_schema_or_transport_metadata", "request_id": identifier})
        if record.get("state") not in {"success", "error", "malformed_response"} or record.get("finished_at_utc") is None:
            errors.append({"rule": "unfinished_or_unknown_attempt", "request_id": identifier})
        if record.get("endpoint") != normalized_endpoint or record.get("run_id") != run_id:
            errors.append({"rule": "endpoint_or_run_namespace_mismatch", "request_id": identifier})
        try:
            raw_response = json.loads(record.get("response_raw"))
        except (ValueError, TypeError):
            raw_response = None
        if not same(raw_response, record.get("response_json")):
            errors.append({"rule": "response_raw_json_mismatch", "request_id": identifier})
    for generation, group in by_generation.items():
        if not isinstance(generation, str) or not generation or any(type(record.get("attempt")) is not int for record in group):
            errors.append({"rule": "invalid_generation_attempt_metadata"})
            continue
        ordered = sorted(group, key=lambda record: record["attempt"])
        if [record["attempt"] for record in ordered] != list(range(1, len(ordered) + 1)) or len(ordered) > policy["max_retries"] + 1:
            errors.append({"rule": "retry_sequence_mismatch", "generation_id": generation})
        if any(record.get("max_attempts") != policy["max_retries"] + 1 for record in ordered):
            errors.append({"rule": "retry_bound_mismatch", "generation_id": generation})
        if any(record.get("will_retry") is not True or record.get("state") != "error" for record in ordered[:-1]) or ordered[-1].get("will_retry") is not False:
            errors.append({"rule": "invalid_retry_state_chain", "generation_id": generation})
        for record in ordered[:-1]:
            if not retry_is_transient(record):
                errors.append({"rule": "nontransport_failure_retried", "generation_id": generation})
        if any(not same(record.get("request_payload"), ordered[0].get("request_payload")) for record in ordered[1:]):
            errors.append({"rule": "retry_payload_mutated", "generation_id": generation})
    client_ids = [owner.get("client_id") for owner in owners]
    if len(set(client_ids)) != len(owners) or any(not isinstance(value, str) or not value for value in client_ids):
        errors.append({"rule": "missing_or_nonunique_owner_client_ids"})
    linked_requests, linked_generations, owner_reports = [], [], []
    for owner in owners:
        owner_errors, delivered_records = [], []
        def fail(rule):
            owner_errors.append(rule)
        artifact = owner.get("artifact")
        if artifact is not None:
            try:
                path = Path(artifact["path"])
                artifact_bytes, _ = read_regular(path)
                if hashlib.sha256(artifact_bytes).hexdigest() != artifact["sha256"]:
                    raise ValueError("artifact_bytes_changed")
                owner_artifacts[str(path)] = artifact["sha256"]
            except (OSError, ValueError, TypeError, KeyError):
                fail("owner_artifact_sha_mismatch")
        if owner.get("run_id") != run_id or owner.get("api_calls") != len(owner["calls"]):
            fail("owner_run_or_logical_calls_mismatch")
        owner_errors.extend(native_history_errors(owner["history"]))
        attempts_count = 0
        for index, call in enumerate(owner["calls"], 1):
            entries = call.get("attempts")
            if call.get("call_index") != index or not isinstance(entries, list) or not entries:
                fail("missing_or_nonsequential_call_ledger")
                continue
            generation = entries[0].get("generation_id")
            linked_generations.append(generation)
            attempts_count += len(entries)
            if "request_attempts" in call and call["request_attempts"] != len(entries):
                fail("call_attempt_count_mismatch")
            if [entry.get("attempt") for entry in entries] != list(range(1, len(entries) + 1)):
                fail("call_retry_sequence_mismatch")
            owner_errors.extend(native_history_errors(call["messages"]))
            for entry in entries:
                request_id = entry.get("request_id")
                linked_requests.append(request_id)
                record = by_request.get(request_id)
                if record is None:
                    fail("ledger_request_missing")
                    continue
                if record.get("client_id") != owner["client_id"] or not same(record.get("context"), redact(owner["context"])):
                    fail("raw_owner_or_context_mismatch")
                if entry.get("generation_id") != generation or any(not same(entry.get(key), record.get(key)) for key in ("generation_id", "attempt", "state", "http_status")):
                    fail("attempt_ledger_metadata_mismatch")
                payload = record.get("request_payload") or {}
                expected = generation_payload(profile, policy, owner["seed"])
                expected.update(messages=redact(call["messages"]), tools=redact(owner["schemas"]), parallel_tool_calls=False,
                                tool_choice=("none" if call["forced"] else "auto") if type(call.get("forced")) is bool else payload.get("tool_choice"))
                if payload.get("tool_choice") not in {"auto", "none"} or not same(payload, expected):
                    fail("exact_wire_profile_schema_history_or_choice_mismatch")
                response = record.get("response_json")
                usage = response.get("usage") if isinstance(response, dict) else None
                usage_error = None
                try:
                    clients.OpenAICompatibleLLM._validate_usage(usage)
                    json.dumps(usage, allow_nan=False)
                except (ValueError, TypeError, RecursionError) as exc:
                    usage_error = str(exc)
                expected_entry = {key: record.get(key) for key in ("attempt", "request_id", "generation_id", "state", "http_status")}
                expected_entry["usage"] = None if usage_error is not None else usage
                if usage_error is not None:
                    expected_entry["usage_error"] = usage_error
                if not same(entry, expected_entry):
                    fail("attempt_usage_mismatch")
            delivered = by_request.get(entries[-1].get("request_id"))
            if delivered is None:
                continue
            if delivered.get("state") != "success":
                fail("call_not_delivered_infrastructure_failure_retained")
                continue
            delivered_records.append(delivered)
            response = delivered.get("response_json") or {}
            choices = response.get("choices") or []
            message = choices[0].get("message") if choices and isinstance(choices[0], dict) else None
            if not isinstance(message, dict):
                fail("success_without_assistant_envelope")
                continue
            if isinstance(message, dict):
                message = dict(message)
                message.setdefault("role", "assistant")
            if not same(message, redact(call["output_message"])):
                fail("delivered_full_assistant_message_mismatch")
            if not call.get("finish_reason_not_serialized") and choices[0].get("finish_reason") != call.get("finish_reason"):
                fail("delivered_finish_reason_mismatch")
            try:
                values = reported_usage(response.get("usage"))
            except (ValueError, TypeError):
                fail("invalid_delivered_usage")
                continue
            if "delivered_usage" in call and not same(values, call["delivered_usage"]):
                fail("delivered_scalar_usage_mismatch")
        if attempts_count != owner.get("http_request_attempts"):
            fail("owner_http_attempt_count_mismatch")
        for key, actual in owner.get("delivered_counters", {}).items():
            # Frozen loop counters are known sums of delivered responses only,
            # not total transport/retry cost and not a complete provider bill.
            try:
                known_sum = sum(reported_usage(record["response_json"].get("usage"))[key] or 0 for record in delivered_records)
            except (ValueError, TypeError):
                fail("invalid_delivered_usage")
                continue
            if actual != known_sum:
                fail("delivered_counter_mismatch:" + key)
        owner_reports.append({"owner_id": owner["owner_id"], "logical_id": owner["logical_id"], "client_id": owner["client_id"],
            "artifact": owner.get("artifact"), "passed": not owner_errors, "errors": owner_errors,
            "logical_calls": len(owner["calls"]), "http_attempts": attempts_count, "delivered_usage": usage_totals(delivered_records)})
        errors.extend({"rule": rule, "owner_id": owner["owner_id"]} for rule in owner_errors)
    if Counter(linked_requests) != Counter(by_request.keys()) or any(value != 1 for value in Counter(linked_requests).values()):
        errors.append({"rule": "raw_ledger_request_bijection_failed"})
    if Counter(linked_generations) != Counter(by_generation.keys()) or any(value != 1 for value in Counter(linked_generations).values()):
        errors.append({"rule": "raw_ledger_generation_bijection_failed"})
    changed = sorted(str(path) for path in root.rglob("*")) != sorted(str(path) for path in all_paths)
    for path, item in snapshots.items():
        try:
            body, info = read_regular(path)
            changed = changed or hashlib.sha256(body).hexdigest() != item["sha256"] or info.st_mtime_ns != item["mtime_ns"]
        except (OSError, ValueError):
            changed = True
    if changed:
        errors.append({"rule": "raw_files_changed_during_audit"})
    for path, expected in owner_artifacts.items():
        try:
            body, _ = read_regular(path)
            valid = hashlib.sha256(body).hexdigest() == expected
        except (OSError, ValueError):
            valid = False
        if not valid:
            errors.append({"rule": "owner_artifact_changed_during_audit", "path": path})
    repository()
    totals = usage_totals(records)
    if unparseable_files:
        totals["parseable_http_attempts"] = totals["http_attempts"]
        totals["http_attempts"] = None
        for value in totals["provider_usage"].values():
            value["complete_total"] = None
        totals["unknown_unparseable_file_count"] = len(unparseable_files)
    return {"passed": not errors, "errors": errors, "owners": owner_reports, "totals_all_attempts": totals,
            "raw_file_count": len(paths), "unparseable_files": unparseable_files,
            "unmatched_request_ids": sorted(set(by_request) - set(linked_requests)),
            "files": [{"path": path, **item} for path, item in sorted(snapshots.items())],
            "limitations": ["Pool result format omits forced/finish per call; raw values are retained without inventing saved flags", "Provider usage unknown remains null in complete totals; delivered loop counters are separately known-sum reconciled", "This audit neither reexecutes tools nor independently rewrites the scorer"]}
