"""Real journal adapter: mechanically preserved frozen event/lease/inventory logic.

Hard-coded root/type/schema boundaries are new; original files remain untouched.
See README for the exact adaptation list. Real observation is not authorization.
"""
from contextlib import contextmanager
import copy
import fcntl
import hashlib
import json
import os
from pathlib import Path
import stat
import threading
import types

HERE = Path(__file__).resolve().parent
import real_common as common
import real_authority as authority
BASE_PATH = common.CPU.parent.parent / "journal.py"
BASE_SHA256 = "c6a0445b0052cf9ffcd923505d91e9bd2a61d27bbf964c10229e323925865ff4"
OP_SCHEMA = "phase3b-real-operation-v1"
OPERATION_KINDS = frozenset(("study", "epoch", "stage_begin", "stage_finish", "lease",
    "identity", "attempt_gate", "attempt_rejected", "transport_enter", "transport_return",
    "transport_error", "drain", "stop_new"))


def _read_regular(path):
    # Absolute no-follow component walk; never block on an unsafe object.
    path = Path(path)
    fd = os.open(path.anchor, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for part in path.parts[1:-1]:
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = child
        child = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=fd)
        try:
            info = os.fstat(child)
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                raise ValueError("unsafe_regular_file")
            chunks = []
            while True:
                chunk = os.read(child, 1024 * 1024)
                if not chunk:
                    break
                chunks.append(chunk)
            return b"".join(chunks)
        finally:
            os.close(child)
    finally:
        os.close(fd)


def verify_dependencies():
    body = _read_regular(BASE_PATH)
    if hashlib.sha256(body).hexdigest() != BASE_SHA256:
        raise ValueError("frozen_journal_dependency_changed")
    return body


verify_dependencies()
_BASE = common.cpu_module("journal_store")._BASE
JournalError = _BASE.JournalError
encoded, digest, _seal = _BASE.encoded, _BASE.digest, _BASE._seal
_sha, _identifier, _relative = _BASE._sha, _BASE._identifier, _BASE._relative
_TOKEN = object()


def _real_path(root):
    raw = Path(root)
    if ".." in raw.parts or not raw.is_absolute():
        raise JournalError("Absolute nontraversing root required")
    if raw != raw.resolve():
        raise OSError("Symlinked run root or parent forbidden")
    path = common.scoped(root)
    if len(path.parts) < 6:
        raise JournalError("Narrow registered run root required")
    # Reject nested journals, including existing ancestors.
    for parent in path.parents:
        if (parent / "journal").exists():
            raise JournalError("Run root cannot nest in another journal")
    return path


class RunRootCapability:
    def __init__(self, token, grant):
        if token is not _TOKEN or type(grant) is not authority.RealGrant:
            raise JournalError("Validated real grant required")
        self._token, self._pid, self.grant = token, os.getpid(), grant
        self.values = {"root": grant.go["output_root"]}

    def __reduce_ex__(self, protocol):
        raise JournalError("Root capability is process local")


class RealContinuationPermit(RunRootCapability):
    pass


def real_root_capability(grant):
    grant.check(next(iter(grant.scope)))
    return RunRootCapability(_TOKEN, grant)


def real_continuation_permit(grant, journal, quiescence):
    if type(grant) is not authority.RealGrant:
        raise JournalError("Validated real grant required")
    grant.check(next(iter(grant.scope)))
    if grant.study_sha256 != journal.plan_sha256 or grant.go["output_root"] != str(journal.root):
        raise JournalError("Continuation grant must bind exact journal science and root")
    linked = grant.go.get("continuation")
    if not isinstance(linked, dict):
        raise JournalError("New explicit continuation GO required")
    if authority.pinned(linked["quiescence"]) != quiescence:
        raise JournalError("Quiescence differs from external ROOT bytes")
    transition = journal.deployment_transition(grant.epoch)
    head = transition["head"]
    expected_prior = linked.get("prior_deployment_epoch_sha256")
    if head is None or expected_prior != head["epoch_binding_sha256"] or quiescence.get("deployment_epoch_sha256") != expected_prior:
        raise JournalError("Drain must bind the actual prior deployment epoch")
    current = journal.snapshot_inventory()
    if transition["mode"] == "same_model_new_epoch" and grant.epoch.get("prior_inventory_sha256") != current["inventory_sha256"]:
        raise JournalError("New local epoch must bind the global prior inventory")
    eligible = eligible_inventory(journal, current)
    ids = grant.go["invocation_ids"]
    if (linked.get("prior_inventory_sha256") != current["inventory_sha256"]
            or linked.get("never_begun_ids") != current["never_begun_ids"]
            or not set(ids).issubset(eligible["eligible_never_begun_ids"])
            or [iid for iid in current["never_begun_ids"] if iid in ids] != ids):
        raise JournalError("Reserved, begun, reordered or changed continuation scope")
    value = RealContinuationPermit(_TOKEN, grant)
    value.values = {"root": str(journal.root), "plan_sha256": journal.plan_sha256,
        "manifest_sha256": journal.manifest_sha256, "prior_inventory_sha256": current["inventory_sha256"],
        "never_begun_ids": current["never_begun_ids"], "allowed_ids": ids,
        "go_sha256": grant.anchors["go"]["sha256"], "quiescence_sha256": digest(quiescence),
        "deployment_transition": transition, "epoch_target_sha256": grant.epoch_sha256}
    return value


def eligible_inventory(journal, current=None):
    current = journal.snapshot_inventory() if current is None else current
    reserved = {v["payload"]["invocation_id"] for v in journal._read_operations().values()
        if v["payload"].get("purpose") == "request_attempt_reservation"}
    never = current["never_begun_ids"]
    return {"eligible_never_begun_ids": [x for x in never if x not in reserved],
        "reserved_without_start": [x for x in never if x in reserved],
        "reserved_cost_status": "unknown; never automatically release or rerun"}


def _check_capability(value, expected):
    if type(value) is not expected or value._token is not _TOKEN or value._pid != os.getpid():
        raise JournalError("Explicit local real capability required")
    value.grant.check(next(iter(value.grant.scope)))
    if value.values.get("root") != value.grant.go["output_root"]:
        raise JournalError("Root capability differs from exact ROOT GO")
    if "allowed_ids" in value.values and value.values["allowed_ids"] != value.grant.go["invocation_ids"]:
        raise JournalError("Continuation scope differs from exact ROOT GO")
    return copy.deepcopy(value.values)


class Journal(common.cpu_module("journal_runtime").Journal):
    def __init__(self, root, plan_sha256, invocations, logical_rows, create=False, capability=None):
        self._lease_fd = None
        self._lease_pid = None
        self._stop_new = False
        self._initializing = True
        self._op_lock = threading.RLock()
        self._op_names_expected = set()
        self._epoch_records = {}
        self._allowed_ids = set()
        self._continuation_link = None
        root = _real_path(root)
        if create is True:
            cap = _check_capability(capability, RunRootCapability)
            if cap["root"] != str(root):
                raise JournalError("Real capability root mismatch")
            self.root = root
            try:
                with self._directory() as fd:
                    if os.listdir(fd):
                        raise FileExistsError("Fresh empty registered run root required before journal creation")
            except FileNotFoundError:
                pass
        verify_dependencies()
        try:
            self._initialize_manifest(root, plan_sha256, invocations, logical_rows, create=create)
            if create is True:
                with self._directory() as fd:
                    if self._exists(fd, "operations"):
                        raise FileExistsError("Fresh operations namespace required")
                    os.mkdir("operations", mode=0o700, dir_fd=fd)
                    os.fsync(fd)
                self._acquire_writer()
                self._allowed_ids = set(capability.grant.scope)
            self._initializing = False
            try:
                operations = self._read_operations()
                self._op_names_expected = set(operations)
                self._epoch_records = self._check_epochs(operations)
            except (JournalError, OSError, ValueError, TypeError, KeyError):
                if create is True:
                    raise
                # Reopen remains useful for full read-only failed accounting.
                self._stop_new = True
        except BaseException:
            self.close()
            raise

    def _initialize_manifest(self, root, plan_sha256, invocations, logical_rows, create=False):
        # Mechanical base __init__ after its path check. The absolute root was
        # already validated by _real_path; no old HERE/global is modified.
        self.root = root
        self._writable = create is True
        self.plan_sha256 = _sha(plan_sha256)
        self._invocations = copy.deepcopy(invocations)
        self._rows = copy.deepcopy(logical_rows)
        self._validate_plan()
        body = {"schema_version": _BASE.SCHEMA, "kind": "manifest", "plan_sha256": self.plan_sha256,
                "invocations": self._invocations, "logical_rows": self._rows,
                "claimed_counts": {"invocations": len(self._invocations), "logical_rows": len(self._rows)}}
        self._manifest = _seal(body)
        self.manifest_sha256 = self._manifest["event_sha256"]
        if self._writable:
            with self._directory((), create=True) as fd:
                for name in ("results", "raw", "dumps", "logs", "journal"):
                    if self._exists(fd, name):
                        raise FileExistsError("Fresh results/raw/dumps/logs/journal required")
                for invocation in self._invocations:
                    for parts in self._output_paths(invocation):
                        self._assert_absent(parts)
                os.mkdir("journal", mode=0o700, dir_fd=fd)
                os.fsync(fd)
            self._write_new("manifest.json", self._manifest)
        self._verify_manifest()

    def deployment_transition(self, epoch, operations=None):
        """Derive the unique global head from frozen model order and epoch chains.

        Epoch operation filenames, dictionary order and mtimes are irrelevant.
        An existing earlier-model/epoch is never the current deployment.
        """
        order = []
        for inv in self._invocations:
            model = inv.get("model")
            if not isinstance(model, str):
                raise JournalError("Frozen model labels required for deployment continuation")
            if not order or order[-1] != model:
                if model in order:
                    raise JournalError("Frozen invocation model order is not contiguous")
                order.append(model)
        groups = self._check_epochs(self._read_operations() if operations is None else operations)
        if set(groups) - set(order):
            raise JournalError("Unknown recorded deployment model")
        if any(value["payload"]["scientific_sha256"] != self.plan_sha256 for values in groups.values() for value in values):
            raise JournalError("Recorded deployment scientific identity differs from manifest")
        present = [model for model in order if model in groups]
        if present != order[:len(present)]:
            raise JournalError("Recorded deployment models skipped frozen order")
        head = copy.deepcopy(groups[present[-1]][-1]["payload"]) if present else None
        model, number = epoch["model"], epoch["epoch_id"]
        if model not in order or type(number) is not int:
            raise JournalError("Unknown target deployment model or epoch")
        target = digest(epoch)
        if head is None:
            if model != order[0] or number != 0 or epoch.get("previous_epoch_sha256") is not None:
                raise JournalError("Initial deployment must be first frozen model epoch zero")
            return {"mode": "initial", "head": None}
        current_model, current_number = head["model_id"], head["epoch_number"]
        if model == current_model and number == current_number:
            if target != head["epoch_binding_sha256"]:
                raise JournalError("Current deployment binding changed")
            mode = "same_epoch"
        elif model == current_model and number == current_number + 1:
            if epoch.get("previous_epoch_sha256") != head["epoch_binding_sha256"]:
                raise JournalError("New epoch must follow actual global head")
            mode = "same_model_new_epoch"
        elif order.index(model) == order.index(current_model) + 1 and number == 0:
            if epoch.get("previous_epoch_sha256") is not None:
                raise JournalError("New model epoch zero has no local predecessor")
            names = self._names()
            if any(inv["model"] == current_model and inv["invocation_id"] + ".finish.json" not in names for inv in self._invocations):
                raise JournalError("Prior frozen model has unfinished invocations")
            mode = "next_model_epoch_zero"
        else:
            raise JournalError("Stale, skipped or reversed global deployment")
        return {"mode": mode, "head": head}

    def activate_grant(self, grant):
        self._writer()
        if type(grant) is not authority.RealGrant or grant.study_sha256 != self.plan_sha256 or grant.go["output_root"] != str(self.root):
            raise JournalError("Exact same-science stage grant required")
        for iid in grant.scope:
            grant.check(iid)
            self._invocation(iid)
        self._allowed_ids = set(grant.scope)

    @contextmanager
    def _directory(self, relative=(), create=False):
        # This replaces the base accessor; the frozen base module's HERE is untouched.
        parts = self.root.parts[1:] + tuple(relative)
        fd = os.open(self.root.anchor, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            for part in parts:
                if part in ("", ".", "..") or "/" in part:
                    raise JournalError("Unsafe path component")
                if create:
                    try:
                        os.mkdir(part, mode=0o700, dir_fd=fd)
                    except FileExistsError:
                        pass
                    else:
                        os.fsync(fd)
                child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
                os.close(fd)
                fd = child
            yield fd
        finally:
            os.close(fd)

    @contextmanager
    def _operation_guard(self, mode):
        # Fixed order: local RLock, then the existing operations-directory inode.
        # This is NOT the manifest's lifetime writer lease. No child wait or
        # SH->EX upgrade occurs while this short publication/read lock is held.
        # No extra lock file enters the append-only inventory.
        with self._op_lock:
            with self._directory(("operations",)) as fd:
                fcntl.flock(fd, mode)
                try:
                    yield fd
                finally:
                    fcntl.flock(fd, fcntl.LOCK_UN)

    def _read_operations(self):
        operations = {}
        with self._operation_guard(fcntl.LOCK_SH) as fd:
            names = sorted(os.listdir(fd))
            for name in names:
                if not name.endswith(".json"):
                    raise JournalError("Unknown operations entry")
                _identifier(name[:-5])
                child = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=fd)
                try:
                    info = os.fstat(child)
                    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                        raise JournalError("Unsafe operation record")
                    chunks = []
                    while True:
                        chunk = os.read(child, 1024 * 1024)
                        if not chunk: break
                        chunks.append(chunk)
                    value = _BASE._strict_load(b"".join(chunks))
                finally:
                    os.close(child)
                required = {"schema_version", "name", "plan_sha256", "manifest_sha256", "root",
                    "classification", "payload", "event_sha256"}
                if (set(value) != required or value["schema_version"] != OP_SCHEMA
                        or value["name"] + ".json" != name or value["plan_sha256"] != self.plan_sha256
                        or value["manifest_sha256"] != self.manifest_sha256 or value["root"] != str(self.root)
                        or value["classification"] != "real_observation"
                        or not isinstance(value["payload"], dict) or value["payload"].get("kind") not in OPERATION_KINDS):
                    raise JournalError("Operation identity/schema mismatch")
                self._check_operation_identity(value["payload"])
                operations[name] = value
            self._check_epochs(operations)
        return operations

    def write_operation(self, name, value):
        self._writer()
        _identifier(name)
        if len((name + ".json").encode()) > 255 or not isinstance(value, dict) or value.get("kind") not in OPERATION_KINDS:
            raise JournalError("Invalid operation schema")
        encoded(value)
        self._check_operation_identity(value)
        with self._operation_guard(fcntl.LOCK_EX):
            self._check_operation_names()
            if name + ".json" in self._op_names_expected:
                raise FileExistsError("Operation already exists")
            if self._stop_new:
                raise JournalError("Stop-new after durable write failure")
            event = _seal({"schema_version": OP_SCHEMA, "name": name, "plan_sha256": self.plan_sha256,
                "manifest_sha256": self.manifest_sha256, "root": str(self.root), "classification": "real_observation",
                "payload": copy.deepcopy(value)})
            if value["kind"] == "epoch":
                existing = {item["name"] + ".json": item for values in self._epoch_records.values() for item in values}
                existing[name + ".json"] = event
                epochs = self._check_epochs(existing)
            else:
                epochs = self._epoch_records
            body = encoded(event) + b"\n"
            with self._directory(("operations",)) as fd:
                try:
                    child = os.open(name + ".json", os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=fd)
                except FileExistsError:
                    raise
                except OSError:
                    self._stop_new = True
                    raise
                try:
                    view = memoryview(body)
                    while view:
                        count = os.write(child, view)
                        if count <= 0:
                            raise OSError("Short operation write")
                        view = view[count:]
                    os.fsync(child)
                except OSError:
                    self._stop_new = True
                    raise
                finally:
                    os.close(child)
                    try:
                        os.fsync(fd)
                    except OSError:
                        self._stop_new = True
                        raise
            self._op_names_expected.add(name + ".json")
            self._epoch_records = epochs
            return event

    def reconcile(self):
        report = _BASE.Journal.reconcile(self)
        try:
            operations = self._read_operations()
            self._inventory()
            report["operation_integrity_passed"] = True
            report["operations"] = [operations[key] for key in sorted(operations)]
        except (JournalError, OSError, ValueError, TypeError, KeyError):
            report["valid"] = report["passed"] = False
            report["operation_integrity_passed"] = False
            report["operations"] = []
            report["issues"].append({"code": "operation_or_project_inventory_integrity"})
            for key in ("logical_coverage_complete", "score_coverage_complete",
                    "invocation_coverage_complete", "invocation_integrity_passed"):
                report[key] = False
            for row in report["ledger"]:
                row["invocation_integrity_passed"] = False
        report["journal_extension_schema"] = "phase3b-real-journal-v1"
        report["real_authority"] = "not established by reconciliation; external RealGrant required"
        return report

    def authorize_never_started(self, permit, quiescence, exact_ids):
        fields = _check_capability(permit, RealContinuationPermit)
        if self._writable or self._stop_new:
            raise JournalError("Continuation requires an unpoisoned readonly journal")
        required = {"schema_version", "kind", "root", "prior_inventory_sha256",
            "children", "http_inflight", "writers", "deployment_epoch_sha256"}
        if (not isinstance(quiescence, dict) or set(quiescence) != required
                or quiescence["schema_version"] != "phase3b-real-quiescence-v1"
                or quiescence["kind"] != "real_observation" or quiescence["root"] != str(self.root)
                or any(type(quiescence[key]) is not int or quiescence[key] != 0
                    for key in ("children", "http_inflight", "writers"))):
            raise JournalError("Explicit independently bound real quiescence required")
        _sha(quiescence["deployment_epoch_sha256"])
        if (fields["root"] != str(self.root) or fields["plan_sha256"] != self.plan_sha256
                or fields["manifest_sha256"] != self.manifest_sha256
                or fields["quiescence_sha256"] != digest(quiescence)
                or fields["allowed_ids"] != exact_ids):
            raise JournalError("Continuation authority binding mismatch")
        self._acquire_writer()
        try:
            transition = self.deployment_transition(permit.grant.epoch)
            if transition != fields["deployment_transition"]:
                raise JournalError("Actual global deployment changed before writer lease")
            current = self.snapshot_inventory()
            if (fields["prior_inventory_sha256"] != current["inventory_sha256"]
                    or quiescence["prior_inventory_sha256"] != current["inventory_sha256"]
                    or fields["never_begun_ids"] != current["never_begun_ids"]
                    or not set(exact_ids).issubset(eligible_inventory(self, current)["eligible_never_begun_ids"])):
                raise JournalError("Prior inventory or never-begun scope changed")
            operations = self._read_operations()
            self._op_names_expected = set(operations)
            self._epoch_records = self._check_epochs(operations)
            self._writable = True
            self._allowed_ids = set(exact_ids)
            self._continuation_link = copy.deepcopy(fields)
            self.write_operation("lease." + fields["go_sha256"], {"kind": "lease",
                "go_sha256": fields["go_sha256"], "prior_inventory_sha256": current["inventory_sha256"],
                "quiescence_sha256": fields["quiescence_sha256"], "allowed_ids": list(exact_ids),
                "never_begun_ids": list(current["never_begun_ids"])})
        except BaseException:
            self.close()
            raise
        return self


# Full-byte manifest verification is inherited from the exact frozen runtime.
