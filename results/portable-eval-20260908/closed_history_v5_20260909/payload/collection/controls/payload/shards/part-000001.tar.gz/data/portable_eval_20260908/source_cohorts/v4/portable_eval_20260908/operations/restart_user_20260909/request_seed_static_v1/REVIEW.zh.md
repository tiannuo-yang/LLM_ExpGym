# 当前两部署请求 seed 静态核对

2026-09-09。仅沿当前已安装源码与此前已获准的真实 metadata；无新请求、import、GPU 调用、参数修改或资格授权。22 个精确源码/版本文件 SHA、8 份已采 server_info 与 2 个新客户端文件绑定见 evidence.json。服务 owner 独立重核全部这些 SHA，并读关键分支；完整链由 bounded helper 读取。

## 结论

| 部署 | 请求 seed 的实际路径 | R3 解释 |
|---|---|---|
| Kimi-K3，deterministic=true / pytorch，进程初始化 seed=42 | 显式 JSON seed 转 sampling_seed，按请求进入 MurmurHash(seed, position, column) 与已冻结 midpoint Gumbel；只有缺省才补42 | 2200/2204/2208 是不同 seed/hash 输入。并不保证不同输出、整程跨批次重放或严格 iid |
| GLM-5.3，deterministic=false / flashinfer，进程初始化 seeds=4200–4203 | JSON seed 被解析，但构造 SamplingBatchInfo 时置为 None；FlashInfer 使用并推进默认 CUDA generator 的 seed/offset | 这些数字只是 sampling_seed_labels，不提供按标签精确重放；持续随机流的三次重复不因此无效，也未发现每请求固定重置导致重复退化 |

GLM 此边界与已冻结 seed_labels_only 设计一致。不是缺答根因，不授权停止实验或换采样后端。仅语法上有 seed 或全局初始化 seed 不等于请求级 seed 控制。

## 精确源码链

下文 R 为当前 runtime 的 .venv/lib/python3.12/site-packages；绝对路径与原字节 SHA 全在 evidence.json。

1. 当前客户端 planner.py:255 以 base_seed+4*outer 产生重复标签；wire.py:185–215 核 source config 与 JSON seed 精确相同，:237 原 Request 直接交 opener。
2. R/sglang/srt/entrypoints/http_server.py:1686 解析 ChatCompletionRequest；openai/protocol.py:757 声明 seed，:1026 明确转为 sampling_seed。serving_chat.py:759/805–810 保留到 GenerateReqInput。
3. managers/tokenizer_manager.py:1194–1200 合并并实例化 SamplingParams，显式参数优先；sampling_params.py:112 定义字段。scheduler.py:2157–2161 → schedule_batch.py:826/2463 → sampling_batch_info.py:114–129。
4. K3 的 deterministic 分支仅在请求 sampling_seed=None 时补42。batch filter/merge 同步 seed tensor（sampling_batch_info.py:299–314/430–440）。sampler.py:256–260、:281–290、:601/741–742 传入 seeded sampler；:704–706 与 kernels/ops/sampling/murmur_hash.py:76–98 混合 seed/position/token-column；:713 是冻结 midpoint 映射。greedy :124–131 直接 argmax，不使用 seed。
5. GLM 的 sampling_batch_info.py:127–128 将 batch seed 设 None；sampler.py:264–280 的 FlashInfer 分支断言 None，调用时不传 generator/seed/offset。当前 GLM top_p=.95 适用 joint top-k/top-p 分支；若无过滤，则 sampler.py:737–738 使用 torch.multinomial 的默认 RNG，同样不传请求 seed。
6. FlashInfer 0.6.15.post1：sampling.py:47–63 在 generator=None 时取 utils.py:1339–1341 的 torch.cuda.default_generators[device.index]；读取 seed/offset，增加 ceil(increment/4)*4 后 set_state。joint 分支 :432–433 的 increment=batch_size*32；min-p :364–365 为 batch_size。之后 seed/offset 传给采样内核。默认流按调用与批大小推进，不是按 JSON 标签重新播种。
7. 全局初始化在 tp_worker.py:344–355、scheduler.py:916–964，由 server_args.random_seed 调用 utils/common.py:1502–1508 的 torch.manual_seed/cuda.manual_seed_all。所追请求路径未发现每请求重新初始化。
8. RNG 获取不是仅 graph capture 时运行：tp_worker.py:564 先 forward，model_runner.py:1526–1532 replay 并返回 logits，tp_worker.py:596–600 随后每次 sample。grammar+overlap 延后闭包 :587–593 在 scheduler.py:3605–3607 为该 batch 执行。适用当前普通非 speculative、非 prefill-only、合法非 greedy 采样。

## 版本与证据限制

FlashInfer distribution METADATA 与 _build_meta.py 均 0.6.15.post1，git de358e829443d2cab2261b4c2b403444f6925ab6。这是磁盘元数据/源码版本，未执行 import 读取进程模块版本。SGLang server 原报告仍 0.5.16+pr32477，distribution 的 gumbelmidpoint1 后缀另属冻结安装身份，不能互相覆写。

静态检查未观察实际每步 RNG 张量/offset、未做输出重复或独立性检验，也不证明完整模型跨设备、路由、并发顺序的精确重放。不同 seed/hash 输入可能得到同一输出。GLM 随机流的批处理顺序会影响 state/offset 分配；严格 iid 不在本次证明范围。既有 metadata 为各自采集时点，不是新 fresh-ready 或正式运行 GO。
