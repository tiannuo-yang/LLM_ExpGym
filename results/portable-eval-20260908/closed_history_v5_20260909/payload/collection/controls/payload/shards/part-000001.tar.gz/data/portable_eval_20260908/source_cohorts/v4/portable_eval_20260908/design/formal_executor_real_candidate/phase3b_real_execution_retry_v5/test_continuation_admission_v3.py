"""R1/R2/R3 red-green regressions; private CPU grants and blocked network only."""
import copy
from pathlib import Path
import tempfile
import time
import unittest
from unittest import mock

import real_common as c
import real_authority as auth
import real_journal as j
import real_runner_child as child
from test_real_execution import FixtureBase, URL
import test_source_integration as source_fixture


class ContinuationBoundary(FixtureBase):
    def setup_journal(self, external=False):
        if external:
            base = c.HERE.parents[1] / "phase3b_real_execution_v3_external_cpu_roots"
            base.mkdir(exist_ok=True)
            self.root = Path(tempfile.mkdtemp(prefix="CPU_ONLY_", dir=str(base))) / "registered-run"
        self.invs = [{"invocation_id": iid, "logical_ids": ["l" + iid], "model": model, "system": "expgym",
            "output_relative_dir": "results/" + iid, "dump_relative_dir": "raw/" + iid}
            for iid, model in (("first", "m0"), ("second", "m0"), ("third", "m1"))]
        self.rows = [{"invocation_id": x["invocation_id"], "logical_id": x["logical_ids"][0], "model": x["model"],
            "outerrep": 0, "result_artifact": x["output_relative_dir"] + "/one.json", "agent_artifacts": []} for x in self.invs]
        now = time.time()
        self.study = {"output_root": str(self.root), "operations": {"max_http_attempts": 100},
            "whole_study": {"not_before": now - 100, "absolute_deadline": now + 3600},
            "validated_plan_view": {"candidate": {"invocations": self.invs, "logical_rows": self.rows}}}
        self.e0 = self.epoch("m0", 0)
        grant = self.grant(self.e0)
        live = j.Journal(self.root, c.digest(self.study), self.invs, self.rows, create=True, capability=j.real_root_capability(grant))
        self.addCleanup(live.close)
        auth.ensure_epoch_record(self.study, self.e0, {}, live)
        return live

    def epoch(self, model, number, previous=None, prior=None):
        return {"model": model, "epoch_id": number, "previous_epoch_sha256": previous,
            "prior_inventory_sha256": prior, "evidence": {"ready": {"sha256": "b" * 64}},
            "identity": {"endpoint": URL.rsplit("/chat", 1)[0], "valid_until": time.time() + 3600}}

    def grant(self, epoch, linked=None, ids=None):
        go = {"output_root": str(self.root), "invocation_ids": ids or [x["invocation_id"] for x in self.invs],
            "not_before": time.time() - 100, "valid_until": time.time() + 3600}
        if linked: go["continuation"] = linked
        reference = self.ref("go-" + str(time.time_ns()), go)
        return auth.RealGrant(auth._TOKEN, study=self.study, epoch=epoch, anchors={"go": reference}, go=go)

    def reopen(self, live):
        live.close()
        value = j.Journal(self.root, c.digest(self.study), self.invs, self.rows)
        self.addCleanup(value.close)
        return value

    def continuation(self, rd, epoch, drained, ids=None):
        prior = rd.snapshot_inventory()
        q = {"schema_version": "phase3b-real-quiescence-v1", "kind": "real_observation", "root": str(self.root),
            "prior_inventory_sha256": prior["inventory_sha256"], "children": 0, "http_inflight": 0,
            "writers": 0, "deployment_epoch_sha256": drained}
        qref = self.ref("q-" + str(time.time_ns()), q)
        linked = {"quiescence": qref, "prior_deployment_epoch_sha256": drained,
            "prior_inventory_sha256": prior["inventory_sha256"], "never_begun_ids": prior["never_begun_ids"]}
        if epoch["epoch_id"] > 0 and epoch["previous_epoch_sha256"] == drained:
            epoch["prior_inventory_sha256"] = prior["inventory_sha256"]
        grant = self.grant(epoch, linked, ids=ids or prior["never_begun_ids"])
        return grant, q

    def test_R1_real_registered_root_outside_old_base_create_and_reopen(self):
        before = j._BASE.HERE
        live = self.setup_journal(external=True)
        self.assertNotIn(j._BASE.HERE, self.root.parents)
        self.assertTrue(live.reconcile()["valid"])
        self.assertTrue(self.reopen(live).reconcile()["valid"])
        self.assertEqual(j._BASE.HERE, before)

    def test_R2_recorded_old_epoch_cannot_drain_new_head(self):
        live = self.setup_journal()
        e1 = self.epoch("m0", 1, c.digest(self.e0))
        old = live._epoch_records["m0"][-1]
        live.write_epoch("m0", 1, old["event_sha256"], c.digest(self.study), c.digest(e1), "c" * 64, "d" * 64)
        rd = self.reopen(live)
        e2 = self.epoch("m0", 2, c.digest(e1))
        grant, q = self.continuation(rd, e2, c.digest(self.e0))
        with self.assertRaises(j.JournalError): j.real_continuation_permit(grant, rd, q)
        grant, q = self.continuation(rd, e2, c.digest(e1))
        permit = j.real_continuation_permit(grant, rd, q)
        rd.authorize_never_started(permit, q, grant.go["invocation_ids"])
        auth.ensure_epoch_record(self.study, e2, grant.anchors, rd)
        self.assertEqual(rd.deployment_transition(e2)["mode"], "same_epoch")

    def test_same_epoch_reopen_binds_that_epoch_and_never_begun(self):
        live = self.setup_journal()
        live.begin("first", {})
        live.finish("first", {"lfirst": {"state": "scored", "score": 0}}, True, [])
        rd = self.reopen(live)
        grant, q = self.continuation(rd, copy.deepcopy(self.e0), c.digest(self.e0), ids=["second"])
        permit = j.real_continuation_permit(grant, rd, q)
        rd.authorize_never_started(permit, q, ["second"])
        self.assertEqual(rd.deployment_transition(self.e0)["mode"], "same_epoch")
        self.assertEqual(len(rd._epoch_records["m0"]), 1)

    def test_next_model_epoch_zero_local_null_global_previous_bound(self):
        live = self.setup_journal()
        for iid in ("first", "second"):
            live.begin(iid, {})
            live.finish(iid, {"l" + iid: {"state": "scored", "score": 0}}, True, [])
        rd = self.reopen(live)
        new = self.epoch("m1", 0)
        grant, q = self.continuation(rd, new, c.digest(self.e0), ids=["third"])
        permit = j.real_continuation_permit(grant, rd, q)
        self.assertEqual(permit.values["deployment_transition"]["mode"], "next_model_epoch_zero")
        rd.authorize_never_started(permit, q, ["third"])
        auth.ensure_epoch_record(self.study, new, grant.anchors, rd)
        self.assertIsNone(new["previous_epoch_sha256"])
        self.assertIsNone(new["prior_inventory_sha256"])
        with self.assertRaises(j.JournalError): rd.deployment_transition(self.e0)

    def test_lease_rechecks_global_head_not_only_prior_membership(self):
        live = self.setup_journal()
        rd = self.reopen(live)
        grant, q = self.continuation(rd, copy.deepcopy(self.e0), c.digest(self.e0))
        permit = j.real_continuation_permit(grant, rd, q)
        original = rd._acquire_writer
        def acquire_and_change():
            original()
            rd._writable = True
            rd._allowed_ids = set(self.invs[i]["invocation_id"] for i in range(3))
            old = rd._epoch_records["m0"][-1]
            rd.write_epoch("m0", 1, old["event_sha256"], c.digest(self.study), "f" * 64, "c" * 64, "d" * 64)
            rd._writable = False
        with mock.patch.object(rd, "_acquire_writer", acquire_and_change), self.assertRaises(j.JournalError):
            rd.authorize_never_started(permit, q, grant.go["invocation_ids"])

    def test_new_model_cannot_skip_unfinished_prior_model(self):
        live = self.setup_journal()
        with self.assertRaises(j.JournalError): live.deployment_transition(self.epoch("m1", 0))


class ChildAdmissionBoundary(source_fixture.SourceIntegration):
    # Do not inherit the costly source-execution tests into this suite.
    test_audit_three_original_orders_native_runtime = None
    test_pool_n4_original_runner_raw_scorer_and_resume = None
    test_legacy_paramnet_original_runner_and_interpreter = None

    def admission(self, mode="valid"):
        study, epoch, anchors, inv, live, grant = self.make_case("poolact", "restricted_search")
        iid, root = inv["invocation_id"], live.root
        static = c.a3_module("owners").static_owners(c.core().logical_rows(study["validated_plan_view"], inv))
        record = epoch["commands"][0]
        auth.ensure_epoch_record(study, epoch, anchors, live)
        if mode != "no_reservation": auth.reserve_invocation_attempts(study, live, iid)
        bindings = {"design_sha256": c.digest(study), "binding_sha256": c.digest(epoch), "phase3_implementation": c.identity(),
            "command_sha256": record["sha256"], "static_owners": static,
            "execution_kind": "phase3b_real_gated_original_source", "producer_schema": auth.PRODUCER_SCHEMA}
        if mode == "wrong_epoch": bindings["binding_sha256"] = "e" * 64
        begin = root / "journal" / (iid + ".start.json")
        if mode == "fake_start": c.write(begin, {"not_a_journal_begin_record": True})
        else: live.begin(iid, bindings)
        identity = root / "logs" / iid / "actual_owner_identity.json"
        c.write(identity, {"static_owners_sha256": c.digest(static), "command_sha256": record["sha256"],
            "planned_owners": [{"owner_id": x["owner_id"]} for x in static]})
        spec = {"invocation_id": iid, "command": record["command"], "logs": str(identity.parent),
            "dump_dir": str(root / inv["dump_relative_dir"]), "identity_path": str(identity), "identity_sha256": c.sha(identity),
            "begin_path": str(begin), "begin_sha256": c.sha(begin)}
        if mode == "finished": live.finish(iid, {lid: {"state": "infrastructure_failed"} for lid in inv["logical_ids"]}, False, [])
        if mode == "bad_reservation":
            path = root / "operations" / ("budget." + iid + ".json")
            value = c.read(path); value["payload"]["upper_bound"] -= 1
            value.pop("event_sha256"); path.write_bytes(c.encoded(j._seal(value)) + b"\n")
        return spec, study, epoch, grant

    def test_R3_self_pinned_nonjournal_start_rejected_before_entry(self):
        spec, study, epoch, grant = self.admission("fake_start")
        with self.assertRaises(child.GateError): child.claim_child(spec, study, epoch, grant)
        self.assertFalse((Path(spec["logs"]) / "real_child_entry.json").exists())

    def test_exact_durable_reservation_required(self):
        spec, study, epoch, grant = self.admission("no_reservation")
        with self.assertRaises(child.GateError): child.claim_child(spec, study, epoch, grant)

    def test_wrong_epoch_rejected(self):
        with self.assertRaises(child.GateError): child.claim_child(*self.admission("wrong_epoch"))

    def test_finished_start_rejected(self):
        with self.assertRaises(child.GateError): child.claim_child(*self.admission("finished"))

    def test_bad_budget_rejected(self):
        with self.assertRaises(child.GateError): child.claim_child(*self.admission("bad_reservation"))

    def test_valid_journal_entry_once_then_O_EXCL(self):
        args = self.admission()
        path = child.claim_child(*args)
        value = c.read(path)
        self.assertIn("reservation", value["journal_admission"])
        self.assertFalse(value["generation_allowed_before_entry"])
        with self.assertRaises(FileExistsError): child.claim_child(*args)


if __name__ == "__main__":
    unittest.main(verbosity=2)
