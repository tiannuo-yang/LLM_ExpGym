"""CPU-only actual full main(--dry-run); never reads key or constructs model."""
import argparse
import contextlib
import io
import json
import os
from pathlib import Path
import runpy
import socket
import sys
import time
from unittest import mock
import launcher as l
import test_launcher


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--repo",required=True)
    parser.add_argument("--acceptance",required=True)
    parser.add_argument("--acceptance-sha256",required=True)
    parser.add_argument("--profile",action="append",required=True)
    parser.add_argument("--output-dir",required=True)
    args=parser.parse_args()
    repo=Path(args.repo)
    acceptance={"path":args.acceptance,"sha256":args.acceptance_sha256}
    l.s.io.read_ref(acceptance)
    data=l.planner.inventory(repo,args.acceptance,"/lustrefs/users/chufan.shi/codex_space_tn/kimi_k3_eval/data_runtime")
    output=l.s.io.new_directory(args.output_dir)
    source_before={str(repo/k):v for k,v in data["source_files"].items()}
    sys.path.insert(0,str(repo))
    from expgym.llm_clients import OpenAICompatibleLLM
    modules={system:runpy.run_path(str(repo/"scripts"/name),run_name="restart_cpu_dry_"+system)
             for system,name in (("expgym","run_paper_sweep.py"),("poolact","run_poolact.py"))}
    results=[];began=time.monotonic()
    def blocked(*unused,**kwargs):raise AssertionError("CPU_DRY_FORBIDS_MODEL_KEY_NETWORK")
    with mock.patch.object(OpenAICompatibleLLM,"__init__",side_effect=blocked),mock.patch.object(socket,"create_connection",side_effect=blocked),mock.patch.object(socket,"socket",side_effect=blocked):
        for profile_path in args.profile:
            full=l.s.profile_helper.load_profile(profile_path)[0]
            config=test_launcher.config()
            config.update(repo_root=str(repo),run_id="cpu-dry-"+full["model"],model={"label":full["model"],"model_id":full["model"]},
                          output_root=str(output/(full["model"]+"-NEVER-CREATED")),profiles={full["model"]:l.normalized_profile(full)})
            for runtime in config["runtimes"].values():runtime["executable"]=sys.executable
            matrix=l.planner.build_manifest(config["run_id"],[config["model"]],l.planner.DEFAULT_REPEAT_POLICY,20260908,2200,data,supersedes=["invalidated-cpu-label"])
            jobs=l.formal_jobs(config,matrix)
            for job in jobs:
                original=modules[job["system"]]["main"]
                original.__globals__["_load_api_key"]=lambda *a,**k: None
                argv=job["command"][3:]+["--dry-run"]
                stdout=io.StringIO();stderr=io.StringIO();code=None;error=None
                with mock.patch.object(sys,"argv",argv),contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
                    try:code=original()
                    except BaseException as exc:error=type(exc).__name__
                stem=full["model"]+"_"+job["invocation_id"]
                outref=l.s.io.write_new(output,stem+".stdout",stdout.getvalue().encode())
                errref=l.s.io.write_new(output,stem+".stderr",stderr.getvalue().encode())
                results.append({"model":full["model"],"invocation_id":job["invocation_id"],"resolved_argv":argv,
                    "exit_code":code,"error_type":error,"stdout_ref":outref,"stderr_ref":errref})
                if code!=0 or error is not None:break
            if Path(config["output_root"]).exists():raise AssertionError("dry_created_source_output")
            if len(results)%705:break
    source_after={path:l.s.ref(path)["sha256"] for path in source_before}
    receipt={"schema_version":"restart-full-actual-cli-dry-v1","classification":"CPU actual source dry-run, not execution",
        "source_acceptance_ref":acceptance,"source_bytes_unchanged":source_after==source_before,"profile_refs":[l.s.ref(p) for p in args.profile],
        "results":results,"actual_dry_calls":len(results),"passed":len(results)==705*len(args.profile) and all(r["exit_code"]==0 and r["error_type"] is None for r in results) and source_after==source_before,
        "model_constructed":False,"network_calls":0,"key_read":False,"elapsed_seconds":time.monotonic()-began,
        "interpreter":sys.executable,"data_inventory":data,"validation_code_ref":l.s.ref(__file__)}
    reference=l.s.put(output,"receipt.json",receipt)
    print(json.dumps(dict(reference,passed=receipt["passed"],actual_dry_calls=len(results)),sort_keys=True))
    return 0 if receipt["passed"] else 2


if __name__=="__main__":sys.exit(main())
