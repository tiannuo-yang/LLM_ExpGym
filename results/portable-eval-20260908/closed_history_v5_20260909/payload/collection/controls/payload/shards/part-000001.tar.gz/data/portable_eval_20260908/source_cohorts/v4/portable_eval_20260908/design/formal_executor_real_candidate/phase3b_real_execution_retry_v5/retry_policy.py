"""Known stdlib retry classes for the pinned client; no dynamic class imports.

This predicate classifies exception/status/delay only. The raw audit separately
checks error state, will_retry, attempt budget, ordering and identical payloads.
Unknown serialized class names remain rejected: a raw type-name string cannot
prove inheritance for arbitrary custom exceptions.
"""
import http.client
import math
import urllib.error

POLICY_VERSION = 'pinned-client-known-stdlib-retry-v4'
HTTP_STATUSES = frozenset((429, 500, 502, 503, 504))
KNOWN_CONNECTION_EXCEPTIONS = {
    cls.__name__: cls for cls in (
        urllib.error.URLError, urllib.error.ContentTooShortError,
        TimeoutError, ConnectionError, BrokenPipeError, ConnectionAbortedError,
        ConnectionRefusedError, ConnectionResetError, http.client.RemoteDisconnected,
    )
}


def retry_is_transient(record):
    if type(record) is not dict or type(record.get('error')) is not dict:
        return False
    delay, status = record.get('retry_delay_seconds'), record.get('http_status')
    if type(delay) not in (int, float) or not 0 <= delay <= 30 or not math.isfinite(delay):
        return False
    name = record['error'].get('type')
    if type(name) is not str:
        return False
    # HTTPError subclasses URLError but the original client handles it FIRST.
    if name == 'HTTPError':
        return type(status) is int and status in HTTP_STATUSES
    known = KNOWN_CONNECTION_EXCEPTIONS.get(name)
    return status is None and known is not None and issubclass(
        known, (urllib.error.URLError, TimeoutError, ConnectionError))
