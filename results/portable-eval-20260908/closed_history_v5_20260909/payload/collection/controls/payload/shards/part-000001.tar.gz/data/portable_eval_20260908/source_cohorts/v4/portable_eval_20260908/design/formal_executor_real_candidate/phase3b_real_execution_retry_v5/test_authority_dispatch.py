"""Pure authority/control regressions; scientific compilers explicitly stubbed.

These incomplete synthetic schemas cannot pass production verify_study/epoch.
No five real evidence roles or actual ROOT approval are asserted by this suite.
"""
import copy
import time
from unittest import mock
import unittest

import real_common as common
import real_authority as auth
import real_dispatch as dispatch
import real_journal as journal
from test_real_execution import FixtureBase, KEY, synthetic_grant


class MetadataAuthorityTests(FixtureBase):
    def bundle(self, change=None):
        now = time.time()
        identity = common.identity()
        study = {"study_id": "synthetic-incomplete-unit", "output_root": str(self.root),
            "operations": {"max_http_attempts": 12}, "whole_study": {"not_before": now - 100,
                "absolute_deadline": now + 2000, "max_allocation_gpu_seconds": 64 * 3000}}
        epoch = {"model": "m0", "epoch_id": 0, "implementation": identity,
            "identity": {"endpoint": "http://127.0.0.1:1/v1", "valid_until": now + 1000, "deployment_id": "unit-allocation"},
            "commands": [{"invocation_id": "audit"}], "evidence": {}}
        refs = {"definition": self.ref("definition", study), "epoch": self.ref("epoch", epoch)}
        index = {"schema_version": "phase3b-real-global-registry-v1", "kind": "real_external_authority", "entries": [
            {"study_id": study["study_id"], "definition_sha256": refs["definition"]["sha256"],
                "output_root": study["output_root"], "producer_schema": auth.PRODUCER_SCHEMA}]}
        history = {"schema_version": "phase3b-real-closed-allocation-ledger-v1", "kind": "real_external_authority",
            "definition_sha256": refs["definition"]["sha256"], "allocations": []}
        shared = {"kind": "real_external_authority", "definition_sha256": refs["definition"]["sha256"]}
        registration = dict(shared, schema_version="phase3b-real-registration-v1", registered=True, producer_schema=auth.PRODUCER_SCHEMA,
            output_root=study["output_root"], evidence={"m0": {"0": {}}})
        accepted = dict(shared, schema_version="phase3b-real-acceptance-v1", accepted=True,
            producer_schema=auth.PRODUCER_SCHEMA, implementation=identity)
        allocation = dict(shared, schema_version="phase3b-real-allocation-v1", deployment_id="unit-allocation", gpu_count=64,
            allocation_start=now - 50, allocation_end=now + 1100, prior_gpu_seconds=0)
        go = dict(shared, schema_version="phase3b-real-go-v1", authorize="formal_real_dispatch", output_root=study["output_root"],
            model="m0", invocation_ids=["audit"], not_before=now - 20, valid_until=now + 1000)
        values = {"study": study, "epoch": epoch, "index": index, "history": history, "registration": registration,
            "acceptance": accepted, "allocation": allocation, "go": go}
        if change:
            change(values)
        registration["global_registry"] = self.ref("index", index)
        allocation["closed_allocation_ledger"] = self.ref("history", history)
        for name in ("registration", "acceptance", "allocation"):
            refs[name] = self.ref(name, values[name])
        for name in ("registration", "acceptance", "allocation", "epoch"):
            go[name + "_sha256"] = refs[name]["sha256"]
        refs["go"] = self.ref("go", go)
        return study, epoch, refs

    def validate_metadata(self, change=None):
        study, epoch, refs = self.bundle(change)
        with mock.patch.object(auth, "verify_study"), mock.patch.object(auth, "verify_epoch"), mock.patch.object(common, "verify"):
            return auth.validate_real_authority(study, epoch, refs)

    def test_external_metadata_chain_structural_unit_only(self):
        grant = self.validate_metadata()
        grant.check("audit")
        with self.assertRaises(auth.AuthorityError):
            # Without the explicit compiler stubs this fixture is not real authority.
            auth.validate_real_authority(common.read(grant.anchors["definition"]["path"]), grant.epoch, grant.anchors)

    def test_registration_cannot_claim_old_phase1_producer(self):
        with self.assertRaises(auth.AuthorityError):
            self.validate_metadata(lambda v: v["registration"].update(producer_schema="phase1"))

    def test_duplicate_global_registration_rejected(self):
        with self.assertRaises(auth.AuthorityError):
            self.validate_metadata(lambda v: v["index"]["entries"].append(copy.deepcopy(v["index"]["entries"][0])))

    def test_go_may_not_reset_absolute_whole_study_limit(self):
        with self.assertRaises(auth.AuthorityError):
            self.validate_metadata(lambda v: v["go"].update(valid_until=v["study"]["whole_study"]["absolute_deadline"] + 1))

    def test_non64_gpu_and_overbudget_rejected(self):
        with self.assertRaises(auth.AuthorityError):
            self.validate_metadata(lambda v: v["allocation"].update(gpu_count=8))

    def test_closed_allocation_cost_cannot_be_reset_to_zero(self):
        def change(v):
            end = v["allocation"]["allocation_start"] - 10
            v["history"]["allocations"] = [{"deployment_id": "prior-unit", "gpu_count": 64, "start": end - 100, "end": end}]
        with self.assertRaises(auth.AuthorityError): self.validate_metadata(change)

    def test_incomplete_go_scope_rejected(self):
        with self.assertRaises(auth.AuthorityError):
            self.validate_metadata(lambda v: v["go"].update(invocation_ids=["other"]))


class DispatchTests(FixtureBase):
    def setup_dispatch(self):
        invs = [{"invocation_id": "first", "logical_ids": ["l0"], "model": "m0", "outerrep": 0,
                    "system": "expgym", "output_relative_dir": "results/first", "dump_relative_dir": "raw/first"},
                {"invocation_id": "second", "logical_ids": ["l1"], "model": "m1", "outerrep": 0,
                    "system": "expgym", "output_relative_dir": "results/second", "dump_relative_dir": "raw/second"}]
        rows = [{"invocation_id": x["invocation_id"], "logical_id": x["logical_ids"][0],
            "model": x["model"], "outerrep": 0, "result_artifact": x["output_relative_dir"] + "/one.json", "agent_artifacts": []} for x in invs]
        plan = {"candidate": {"invocations": invs, "logical_rows": rows}, "policy": {"max_steps": 1, "max_retries": 1},
            "stages": [{"stage_id": x["model"] + ".outer0", "model": x["model"], "invocation_ids": [x["invocation_id"]]} for x in invs]}
        now = time.time()
        study = {"output_root": str(self.root), "validated_plan_view": plan,
            "operations": {"workers": 1, "max_http_attempts": 16, "max_wall_seconds": 3600, "stop_new_before_deadline_seconds": 1},
            "whole_study": {"absolute_deadline": now + 3600, "not_before": now - 20}}
        grants, bindings = {}, {}
        for inv in invs:
            grant = synthetic_grant(self.root, [inv["invocation_id"]])
            grant.study_sha256 = common.digest(study)
            grant.epoch["model"] = inv["model"]
            grants[inv["model"]] = grant
            bindings[inv["model"]] = (grant.epoch, {}, None)
        instance = journal.Journal(self.root, common.digest(study), invs, rows, create=True,
            capability=journal.real_root_capability(grants["m0"]))
        self.addCleanup(instance.close)
        return study, instance, grants, bindings

    def run_dispatch(self, study, instance, grants, bindings, fail=False):
        calls = []
        def source_worker(study, epoch, anchors, iid, journal, **kwargs):
            calls.append(iid)
            journal.begin(iid, {"CPU_lifecycle_only": True})
            ok = not (fail and iid == "first")
            lids = journal._invocation(iid)["logical_ids"]
            journal.finish(iid, {lid: {"state": "scored" if ok else "infrastructure_failed", "score": -1} for lid in lids}, ok, [])
            return {"passed": ok, "invocation_id": iid}
        with mock.patch.object(auth, "verify_study"), mock.patch.object(auth, "ensure_epoch_record"), \
             mock.patch.object(auth, "validate_real_authority", side_effect=lambda study, epoch, anchors, previous: grants[epoch["model"]]), \
             mock.patch.object(dispatch, "execute_real_invocation", source_worker):
            result = dispatch.dispatch_real(study, instance, bindings, secrets={"m0": KEY, "m1": KEY}, prefix="unit")
        return result, calls

    def test_model_then_outer_fixed_order_and_grant_changes(self):
        study, instance, grants, bindings = self.setup_dispatch()
        result, calls = self.run_dispatch(study, instance, grants, bindings)
        self.assertEqual(calls, ["first", "second"])
        self.assertTrue(result["passed"])
        self.assertEqual(result["max_active_workers"], 1)

    def test_completed_prior_model_does_not_require_old_live_go(self):
        study, instance, grants, bindings = self.setup_dispatch()
        instance.begin("first", {})
        instance.finish("first", {"l0": {"state": "scored", "score": 0}}, True, [])
        bindings["m0"] = None
        result, calls = self.run_dispatch(study, instance, grants, bindings)
        self.assertEqual(calls, ["second"])
        self.assertTrue(result["passed"])

    def test_reserved_without_start_skipped_but_full_receipt_not_passed(self):
        study, instance, grants, bindings = self.setup_dispatch()
        instance.write_operation("budget.first", {"kind": "identity", "purpose": "request_attempt_reservation", "invocation_id": "first", "upper_bound": 4})
        result, calls = self.run_dispatch(study, instance, grants, bindings)
        self.assertEqual(calls, ["second"])
        self.assertEqual(result["reserved_without_start"], ["first"])
        self.assertFalse(result["passed"])

    def test_infrastructure_stops_next_stage_without_score_filter(self):
        study, instance, grants, bindings = self.setup_dispatch()
        result, calls = self.run_dispatch(study, instance, grants, bindings, fail=True)
        self.assertEqual(calls, ["first"])
        self.assertFalse(result["passed"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
