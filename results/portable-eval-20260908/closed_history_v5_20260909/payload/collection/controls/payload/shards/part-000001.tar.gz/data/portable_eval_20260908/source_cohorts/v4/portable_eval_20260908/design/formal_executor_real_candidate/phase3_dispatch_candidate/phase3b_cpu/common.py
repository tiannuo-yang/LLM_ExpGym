"""CPU3B exact frozen dependencies; no network or real dispatch capability."""
import hashlib
import importlib
import json
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
A3 = HERE.parent
WORKSPACE = A3.parents[3]
STUDY = WORKSPACE / "portable_eval_20260908"
CPU_ROOT = HERE / "validation"
NARROW_SHA = "df04ba12f316ccc40d85f4ac26e8f37c34a418b281063e70204f6455fe11c76e"
ROOT_ACCEPTANCE_SHA = "428ecc69f52913b8b28914cf64be2d1655297328923251f0e8bd9974bcc6c06c"
SOURCE_SHA = "b280a0f640ffab8aa90bc74df4c9ecf3189b375cdd674094a005b3569bb4b608"


def sha(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def digest(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def a3_module(name):
    if str(A3) not in sys.path:
        sys.path.insert(0, str(A3))
    loaded = importlib.import_module(name)
    if Path(loaded.__file__).resolve() != A3 / (name + ".py"):
        raise ValueError("wrong_frozen_module_resolved")
    return loaded


def verify():
    narrow = A3 / "validation/narrow_review_v4_v1/review.json"
    accepted = STUDY / "validation/phase3a_root_acceptance_v4.json"
    if sha(narrow) != NARROW_SHA or sha(accepted) != ROOT_ACCEPTANCE_SHA:
        raise ValueError("phase3a_prior_acceptance_changed")
    identity = json.loads(narrow.read_text())["new_code_identity"]
    actual = {p.name: sha(p) for p in A3.iterdir() if p.is_file() and p.suffix in (".py", ".md", ".json")}
    if identity != actual:
        raise ValueError("phase3a_complete_identity_changed")
    a3_module("support").verify()
    return {"phase3a": identity, "phase3a_root_acceptance_sha256": ROOT_ACCEPTANCE_SHA, "source_tree_sha256": SOURCE_SHA}


def identity():
    return {p.name: sha(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.suffix in (".py", ".md", ".json")}


def read(path):
    return a3_module("support").read_json(path)[0]


def scoped(path):
    p = Path(path).absolute()
    if ".." in p.parts or p != p.resolve() or p == CPU_ROOT:
        raise ValueError("fresh_nonalias_cpu_root_required")
    p.relative_to(CPU_ROOT)
    return p


def write(path, value):
    p = scoped(path)
    p.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    body = encoded(value) + b"\n"
    fd = os.open(str(p), os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        view = memoryview(body)
        while view:
            length = os.write(fd, view)
            if length <= 0:
                raise OSError("short_evidence_write")
            view = view[length:]
        os.fsync(fd)
    finally:
        os.close(fd)
    parent = os.open(str(p.parent), os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(parent)
    finally:
        os.close(parent)


def blocked(*args, **kwargs):
    raise RuntimeError("CPU3B_NETWORK_AND_MODEL_DELEGATE_BLOCKED")


def no_network():
    import socket
    import urllib.request
    socket.socket.connect = blocked
    socket.create_connection = blocked
    urllib.request.urlopen = blocked


def core():
    return a3_module("support").bridge.core()


def main_source():
    return a3_module("support").bridge.repository()
