#!/usr/bin/env python3
"""Synthetic-first, pure score-record conversion. No live raw-result adapter/audit."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import io
import json
import math
from pathlib import Path
import statistics
import types

HERE = Path(__file__).resolve().parent
PLANNER = HERE.parent / "formal_matrix_candidate/planner.py"
PLANNER_SHA = "13914a8341765d0c0ed75812d9b79d2281478b7fc82accef64deaa70a5ead68a"
IDENTITY = ("model", "system", "scenario", "item", "regime", "strategy", "outerseed")
CSV_FIELDS = IDENTITY + ("metric", "value", "artifact")
TELEMETRY = ("feedback_attempts", "feedback_visible", "duplicate_action_attempts",
             "feedback_cost_seconds", "input_tokens", "output_tokens", "wall_time_seconds",
             "protocol_failure_rate")
COUNTS = set(TELEMETRY[:3]) | {"input_tokens", "output_tokens"}
SUMMABLE = set(TELEMETRY) - {"protocol_failure_rate"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def dump(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False,
                      separators=(",", ":"), allow_nan=False).encode()


def sha(blob):
    return hashlib.sha256(blob).hexdigest()


def load(blob):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "duplicate JSON key: " + key)
            result[key] = value
        return result
    def bad_constant(value):
        raise ValueError("nonfinite JSON constant: " + value)
    return json.loads(blob, object_pairs_hook=unique, parse_constant=bad_constant)


def planner():
    source = PLANNER.read_bytes()
    require(sha(source) == PLANNER_SHA, "frozen planner changed; explicit adapter review required")
    namespace = {"__file__": str(PLANNER), "__name__": "frozen_candidate_planner"}
    # Avoid writing a __pycache__ into the frozen planner directory.
    exec(compile(source, str(PLANNER), "exec"), namespace)
    return types.SimpleNamespace(**namespace)


def finite(value, label, *, low=0, high=None, integer=False):
    require(type(value) in (int, float) and math.isfinite(value), label + " must be finite numeric, not missing/bool")
    require(value >= low and (high is None or value <= high), label + " outside declared range")
    require(not integer or type(value) is int, label + " must be an integer")
    return float(value)


def gap(performance, oracle):
    value = finite(performance, "answer_perf", high=1)
    mean, best = finite(oracle["mean_perf"], "oracle mean", high=1), finite(oracle["best_perf"], "oracle best", high=1)
    require(best > mean, "Gap denominator must be positive")
    return max(0.0, 100.0 * (value - mean) / (best - mean))


def record_paths(row, invocation):
    paths = [row["result_artifact"]]
    if row["system"] == "poolact":
        paths += row["agent_artifacts"] + [invocation["summary_artifact"]]
    return paths


def expected_metric_names(system, scenario, regime):
    performance = {
        ("expgym", "restricted_search"): {"f1"},
        ("expgym", "evidence_audit"): {"label_acc", "evidence_acc"},
        ("expgym", "tuning"): {"gap", "raw_perf"},
        ("poolact", "restricted_search"): {"f1_mv", "f1_mi"},
        ("poolact", "evidence_audit"): {"label_acc_mv", "evidence_acc_mv", "label_acc_mi", "evidence_acc_mi"},
        ("poolact", "tuning"): {"gap_mi", "gap_bon", "raw_perf_mi", "raw_perf_bon"},
    }
    return performance[(system, scenario)] | set(TELEMETRY) | ({"budget_utilization"} if regime != "cost_free" else set())


def numeric_metrics(row, record, oracles):
    n = 1 if row["system"] == "expgym" else 4
    agents = record["agents"]
    require(isinstance(agents, list) and len(agents) == n, "wrong score-record agent count")
    require(all(type(a.get("agent_id")) is int for a in agents), "agent IDs must be integer")
    require({a["agent_id"] for a in agents} == set(range(n)), "duplicate/missing agent IDs")
    agents = sorted(agents, key=lambda a: a["agent_id"])
    scenario, pool = row["scenario"], row["system"] == "poolact"
    if scenario == "restricted_search":
        scores = [finite(a["f1"], "individual F1", high=1) for a in agents]
        metrics = {"f1_mv": finite(record["aggregate"]["f1"], "voted F1", high=1),
                   "f1_mi": statistics.mean(scores)} if pool else {"f1": scores[0]}
    elif scenario == "evidence_audit":
        metric_arrays = {key: [finite(a[key], key, high=1) for a in agents]
                         for key in ("label_acc", "evidence_acc")}
        metrics = {}
        for key, scores in metric_arrays.items():
            if pool:
                metrics[key + "_mv"] = finite(record["aggregate"][key], "voted " + key, high=1)
                metrics[key + "_mi"] = statistics.mean(scores)
            else:
                metrics[key] = scores[0]
    else:
        require(record.get("tuning_final_policy") == "legacy", "candidate endpoint requires explicit legacy final policy")
        scores = [finite(a["answer_perf"], "raw HPO performance", high=1) for a in agents]
        gaps = [gap(score, oracles[row["selector"]["tuning_task"]]) for score in scores]
        metrics = {"gap_mi": statistics.mean(gaps), "gap_bon": max(gaps),
                   "raw_perf_mi": statistics.mean(scores), "raw_perf_bon": max(scores)} if pool else {
                   "gap": gaps[0], "raw_perf": scores[0]}
    telemetry = record["telemetry"]
    expected = set(TELEMETRY) | ({"budget_utilization"} if row["regime"] != "cost_free" else set())
    require(set(telemetry) == expected, "telemetry fields missing/extra for the predeclared regime")
    for key, value in telemetry.items():
        metrics[key] = finite(value, key, high=1 if key == "protocol_failure_rate" else None, integer=key in COUNTS)
    require(telemetry["feedback_visible"] <= telemetry["feedback_attempts"], "visible feedback exceeds attempts")
    require(telemetry["duplicate_action_attempts"] <= telemetry["feedback_attempts"], "duplicates exceed attempts")
    return metrics


def metric_definition(name):
    if name.startswith("gap"):
        return {"unit": "Gap points", "minimum": 0, "maximum": None, "higher_is_better": True}
    if name in TELEMETRY or name == "budget_utilization":
        return {"unit": "fraction" if name in {"protocol_failure_rate", "budget_utilization"} else
                ("seconds" if name.endswith("seconds") else "count"),
                "minimum": 0, "maximum": 1 if name == "protocol_failure_rate" else None,
                "higher_is_better": name == "feedback_visible"}
    return {"unit": "fraction", "minimum": 0, "maximum": 1, "higher_is_better": True}


def build_comparisons(formal, artifact_specs, bootstrap):
    result = []
    outerseeds = [f"outer_{i:05d}" for i in range(formal["outer_repeats"])]
    for model in formal["models"]:
        for system in ("expgym", "poolact"):
            selected = [a for a in artifact_specs if a["model"] == model["label"] and a["system"] == system]
            slices = []
            for scenario in ("restricted_search", "evidence_audit", "tuning"):
                group = [a for a in selected if a["scenario"] == scenario]
                by_item = {a["item"]: a for a in group}
                if scenario == "restricted_search":
                    for family in ("whois", "whatis"):
                        subset = [a for a in by_item.values() if a["selector"]["question_family"] == family]
                        if subset:
                            slices.append((scenario, family, subset))
                else:
                    slices.append((scenario, "all", list(by_item.values())))
                    if scenario == "tuning":
                        for family in sorted({a["selector"]["family"] for a in group}):
                            slices.append((scenario, "family=" + family, [a for a in by_item.values() if a["selector"]["family"] == family]))
                        for item, spec in sorted(by_item.items()):
                            slices.append((scenario, "task=" + item, [spec]))
            for scenario, slice_name, subset in slices:
                metrics = set.intersection(*(set(a["metrics"]) for a in selected if a["scenario"] == scenario
                                            and a["item"] in {s["item"] for s in subset}))
                # Free utilization is undefined: registered aggregate rows retain Moderate/Tight values,
                # but it must not be fabricated for a Free/Tight paired comparison.
                if system == "expgym":
                    metrics.discard("budget_utilization")
                for regime in ([None] if system == "expgym" else ["cost_moderate", "cost_tight"]):
                    for strategy in (["single"] if system == "expgym" else ["cached", "poolact"]):
                        for metric in sorted(metrics):
                            primary_id = None
                            if system == "expgym":
                                primary_id = {("restricted_search", "whois", "f1"): "E-S",
                                    ("evidence_audit", "all", "evidence_acc"): "E-A",
                                    ("tuning", "all", "gap"): "E-H"}.get((scenario, slice_name, metric))
                            elif strategy == "poolact":
                                primary_id = {("restricted_search", "whois", "cost_tight", "f1_mv"): "P-S",
                                    ("evidence_audit", "all", "cost_moderate", "evidence_acc_mv"): "P-A",
                                    ("tuning", "task=hpobench:nasbench101:A", "cost_tight", "gap_mi"): "P-H"}.get((scenario, slice_name, regime, metric))
                            first = subset[0]
                            key = [model["label"], system, scenario, slice_name, regime, strategy, metric]
                            spec = {"id": model["label"] + "__" + (primary_id or "secondary_" + sha(dump(key))[:20]),
                                "kind": "expgym_free_tight" if system == "expgym" else "poolact_vs_naive",
                                "model": model["label"], "scenario": scenario, "slice": slice_name,
                                "strategy": strategy, "metric": metric, "split": first["split"],
                                "items": sorted(a["item"] for a in subset), "outerseeds": outerseeds,
                                "role": "primary" if primary_id else "secondary", "family": "all_six_primaries_across_registered_models",
                                "bootstrap_method": "fixed_items_outer_repeats", "minimum_items": len(subset),
                                "minimum_outerseeds": len(outerseeds), "minimum_effect": 0.0, "quality_gate_ids": [],
                                "scope": {"data_snapshots": sorted({a["snapshot"] for a in subset}),
                                    "item_status": first["item_status"], "inference_population": "registered_items_only",
                                    "outer_repetition_interpretation": "seed_labels_only"}}
                            if regime is not None:
                                spec["regime"] = regime
                            result.append(spec)
    counts = Counter(s["model"] for s in result if s["role"] == "primary")
    require(counts == {m["label"]: 6 for m in formal["models"]}, "exactly six primary comparisons per model required")
    require(Counter(s["model"] for s in result) == {m["label"]: 514 for m in formal["models"]},
            "fixed secondary catalogue incomplete: require 158 ExpGym +356 PoolAct comparisons/model")
    require(len({s["id"] for s in result}) == len(result), "comparison ID collision")
    return result


def describe(rows, comparisons, metrics):
    indexed = {(tuple(row[k] for k in IDENTITY), row["metric"]): row for row in rows}
    require(len(indexed) == len(rows), "duplicate CSV identity/metric")
    effects, pairs = [], []
    for spec in comparisons:
        exp = spec["kind"] == "expgym_free_tight"
        system = "expgym" if exp else "poolact"
        base_regime, target_regime = ("cost_free", "cost_tight") if exp else (spec["regime"], spec["regime"])
        base_strategy = "single" if exp else "naive"
        orientation = (1 if metrics[spec["metric"]]["higher_is_better"] else -1) * (-1 if exp else 1)
        item_means = []
        for item in spec["items"]:
            item_pairs = []
            for outer in spec["outerseeds"]:
                key = lambda regime, strategy: ((spec["model"], system, spec["scenario"], item, regime, strategy, outer), spec["metric"])
                require(key(base_regime, base_strategy) in indexed and key(target_regime, spec["strategy"]) in indexed,
                        "missing paired Cartesian cell: " + spec["id"])
                base, target = indexed[key(base_regime, base_strategy)], indexed[key(target_regime, spec["strategy"])]
                pair = {"comparison": spec["id"], "item": item, "outerseed": outer,
                        "baseline": base["value"], "target": target["value"],
                        "effect": orientation * (target["value"] - base["value"])}
                item_pairs.append(pair)
                pairs.append(pair)
            item_means.append({field: statistics.mean(p[field] for p in item_pairs) for field in ("baseline", "target", "effect")})
        effects.append({"comparison": spec["id"], "role": spec["role"], "model": spec["model"],
            "scenario": spec["scenario"], "slice": spec["slice"], "metric": spec["metric"],
            **{field: statistics.mean(i[field] for i in item_means) for field in ("baseline", "target", "effect")},
            "n_items": len(spec["items"]), "n_outer_repeats": len(spec["outerseeds"]),
            "n_pairs_descriptive_not_independent_n": len(spec["items"]) * len(spec["outerseeds"]),
            "effect_definition": "utility-oriented Free minus Tight" if exp else "utility-oriented candidate minus naive",
            "status": "descriptive_only", "ci": None, "p_value": None})
    return effects, pairs


def csv_bytes(rows, fields):
    output = io.StringIO(newline="")
    writer = csv.DictWriter(output, fieldnames=fields)
    writer.writeheader()
    writer.writerows(rows)
    return output.getvalue().encode()


def aggregate_rows(rows, specs):
    """All regime/strategy displays: first average outer repeats per item."""
    by_path = {a["artifact"]: a for a in specs}
    groups = defaultdict(lambda: defaultdict(list))
    for row in rows:
        spec = by_path[row["artifact"]]
        if row["scenario"] == "restricted_search":
            slices = [spec["selector"]["question_family"]]
        elif row["scenario"] == "tuning":
            slices = ["all", "family=" + spec["selector"]["family"], "task=" + row["item"]]
        else:
            slices = ["all"]
        for slice_name in slices:
            key = (row["model"], row["system"], row["scenario"], slice_name,
                   row["regime"], row["strategy"], row["metric"])
            groups[key][row["item"]].append(row["value"])
    names = ("model", "system", "scenario", "slice", "regime", "strategy", "metric")
    return [{**dict(zip(names, key)), "mean": statistics.mean(statistics.mean(v) for v in items.values()),
             "n_items": len(items), "rows_per_item": sorted({len(v) for v in items.values()}),
             "aggregation": "equal items after mean outer repetitions"}
            for key, items in sorted(groups.items())]


def convert(formal_bytes, normalized_bytes, source_blobs, oracle_bytes, *, bootstrap):
    """Convert hash-bound declarations; does NOT establish that scores are true."""
    p = planner()
    require(isinstance(bootstrap, dict) and set(bootstrap) == {"samples", "seed", "confidence"}, "explicit descriptive bootstrap metadata required")
    require(type(bootstrap["samples"]) is int and bootstrap["samples"] >= 100
            and type(bootstrap["seed"]) is int and bootstrap["seed"] >= 0, "invalid descriptive bootstrap metadata")
    finite(bootstrap["confidence"], "descriptive confidence", high=1)
    require(0 < bootstrap["confidence"] < 1, "confidence must lie strictly in (0,1)")
    formal = load(formal_bytes)
    p.validate(formal)
    source_manifest_sha = sha(formal_bytes)
    records_input = load(normalized_bytes)
    require(records_input.get("schema_version") == "normalized-score-candidate-v1", "unknown normalized contract")
    require(records_input.get("formal_manifest_sha256") == source_manifest_sha, "formal manifest hash mismatch")
    records = records_input["records"]
    require(isinstance(records, list), "score records must be explicit list")
    by_id = {r["logical_id"]: r for r in records}
    require(len(by_id) == len(records), "duplicate normalized logical ID")
    expected_ids = {r["logical_id"] for r in formal["logical_rows"]}
    require(set(by_id) == expected_ids, "missing/extra formal cells; complete-case filtering forbidden")
    require(sha(oracle_bytes) == formal["source_and_inputs"]["files"]["hpo.oracle"]["sha256"], "oracle bytes differ from planned data")
    oracles = load(oracle_bytes)["tasks"]
    require(set(p.HPO) <= set(oracles), "missing frozen HPO oracle task")
    invocations = {i["invocation_id"]: i for i in formal["invocations"]}
    expected_sources = {path for row in formal["logical_rows"] for path in record_paths(row, invocations[row["invocation_id"]])}
    require(set(source_blobs) == expected_sources, "source blob set missing/extra; no file discovery allowed")
    source_hashes = {path: sha(blob) for path, blob in source_blobs.items()}
    grouped, telemetry_totals = defaultdict(list), defaultdict(lambda: defaultdict(float))
    for row in formal["logical_rows"]:
        record = by_id[row["logical_id"]]
        require(record.get("state") in {"scored", "model_failure_scored"}, "infrastructure/pending/unscored input is incomplete, not zero")
        paths = record_paths(row, invocations[row["invocation_id"]])
        require(record.get("source_sha256") == {path: source_hashes[path] for path in paths}, "source byte/declaration mismatch")
        values = numeric_metrics(row, record, oracles)
        require(set(values) == expected_metric_names(row["system"], row["scenario"], row["regime"]),
                "fixed performance/telemetry metric catalogue mismatch")
        identity = dict(zip(IDENTITY, (row["model"], row["system"], row["scenario"], row["item"],
                                     row["regime"], row["strategy"], f"outer_{row['outerrep']:05d}")))
        grouped[tuple(identity.values())].append((row, record, values))
        for metric in SUMMABLE:
            telemetry_totals[row["model"]][metric] += record["telemetry"][metric]
    specs, csv_rows, derived = [], [], {}
    for key, components in sorted(grouped.items()):
        row = components[0][0]
        audit = row["system"] == "expgym" and row["scenario"] == "evidence_audit"
        require(len(components) == (3 if audit else 1), "unexpected aggregation component count")
        if audit:
            require({c[0]["order"] for c in components} == {0, 1, 2}, "Audit must contain exactly orders 0,1,2")
        components.sort(key=lambda c: c[0]["order"] if audit else 0)
        metric_names = set(components[0][2])
        require(all(set(c[2]) == metric_names for c in components), "component metric set mismatch")
        values = {metric: statistics.mean(c[2][metric] for c in components) for metric in sorted(metric_names)}
        identity = dict(zip(IDENTITY, key))
        artifact = "derived/" + sha(dump(identity)) + ".json"
        unit = "document_outerrep" if audit else ("pool_aggregate" if row["system"] == "poolact" else "single_trace")
        body = {"schema_version": "derived-score-candidate-v1", "identity": identity, "unit": unit,
            "derivation": "mean_of_three_fixed_Audit_orders" if audit else "one_formal_outcome_projection",
            "formal_manifest_sha256": source_manifest_sha, "normalized_bundle_sha256": sha(normalized_bytes),
            "metrics": values, "components": [{"logical_id": r["logical_id"], "order": r["order"],
                "selected_input_sha256": r["selected_input_sha256"], "source_sha256": record["source_sha256"],
                "normalized_record_sha256": sha(dump(record)), "state": record["state"],
                "nullable_metrics": record.get("nullable_metrics", {})} for r, record, _ in components],
            "score_recomputation_verified": False, "source_hashes_do_not_prove_score_truth": True}
        if audit:
            body["source_telemetry_totals"] = {metric: sum(c[1]["telemetry"][metric] for c in components) for metric in sorted(SUMMABLE)}
        derived[artifact] = dump(body)
        specs.append({**identity, "artifact": artifact, "unit": unit,
            "split": "reserved" if row["item_status"] == "prospectively_reserved" else "known",
            "item_status": row["item_status"], "snapshot": row["snapshot"], "selector": row["selector"],
            "metrics": sorted(values), "derivation_component_count": len(components)})
        csv_rows += [{**identity, "metric": metric, "value": value, "artifact": artifact} for metric, value in sorted(values.items())]
    expected_artifacts = 615 * formal["outer_repeats"] * len(formal["models"])
    require(len(specs) == expected_artifacts, "derived doc/pool matrix count mismatch")
    require(len(csv_rows) == 6643 * formal["outer_repeats"] * len(formal["models"]), "fixed artifact-by-metric Cartesian coverage mismatch")
    metrics = {name: metric_definition(name) for spec in specs for name in spec["metrics"]}
    comparisons = build_comparisons(formal, specs, bootstrap)
    analysis_manifest = {"schema_version": 1, "study_id": formal["candidate_id"] + "-export-candidate",
        "registration": {"selection_rule": "fixed_manifest_no_outcome_selection", "frozen_before_evaluation": False,
                         "protocol_id": "UNREGISTERED-CANDIDATE:" + source_manifest_sha},
        "bootstrap": dict(bootstrap), "metrics": metrics, "artifacts": specs, "quality_gates": [], "comparisons": comparisons,
        "executable": False, "registered": False, "adapter_required": [
            "main analyzer unit schema rejects document_outerrep; do not relabel it single_trace",
            "virtual derived artifact bundle needs explicit materialization before any file audit",
            "real raw-result extraction and independent full score/aggregate audit are unimplemented"],
        "audit_receipt": None, "confirmatory_inference_available": False}
    effects, pairs = describe(csv_rows, comparisons, metrics)
    return {"analysis_manifest_candidate": analysis_manifest, "metrics_csv": csv_bytes(csv_rows, CSV_FIELDS),
        "rows": csv_rows, "derived_artifacts": derived, "effects": effects, "paired_rows": pairs,
        "aggregate_metrics": aggregate_rows(csv_rows, specs),
        "input_telemetry_totals": {m: dict(values) for m, values in telemetry_totals.items()},
        "provenance": {"formal_manifest_sha256": source_manifest_sha, "normalized_bundle_sha256": sha(normalized_bytes),
            "oracle_sha256": sha(oracle_bytes), "source_artifact_sha256": source_hashes,
            "derived_artifact_sha256": {k: sha(v) for k, v in derived.items()},
            "conversion_structure_complete": True, "independent_score_audit_complete": False,
            "registration_complete": False, "model_calls": 0}}


def synthetic_inputs(repeats=1):
    p = planner()
    oracle = dump({"tasks": {task: {"mean_perf": 0.5, "best_perf": 0.8} for task in p.HPO}, "synthetic": True})
    labels = {key for system in ("expgym", "poolact") for item in p.items(system) for key in item["inputs"]}
    order = sorted(p.AUDIT_HYPOTHESES)
    data = {"files": {key: {"path": "/synthetic/" + key, "sha256": "a" * 64, "bytes": 1} for key in labels},
            "source_tree_sha256": "b" * 64, "audit_orders": [order, list(reversed(order)), order[1:] + order[:1]]}
    data["files"]["hpo.oracle"]["sha256"] = sha(oracle)
    formal = p.build_manifest("synthetic-export-only", [{"label": "fixture", "model_id": "not-a-served-model"}], repeats, 20260908, 1206, data)
    formal_bytes = dump(formal)
    invocations = {i["invocation_id"]: i for i in formal["invocations"]}
    blobs, records = {}, []
    for row in formal["logical_rows"]:
        paths = record_paths(row, invocations[row["invocation_id"]])
        for path in paths:
            blobs[path] = dump({"synthetic_source_path": path, "native_repeat_index": 0})
        pool = row["system"] == "poolact"
        agents = []
        for agent in range(4 if pool else 1):
            if row["scenario"] == "restricted_search":
                score = 0.8 if row["regime"] == "cost_tight" else 0.6
                agents.append({"agent_id": agent, "f1": score})
            elif row["scenario"] == "evidence_audit":
                order = row["order"] if type(row["order"]) is int else 0
                agents.append({"agent_id": agent, "label_acc": [0.3, 0.6, 0.9][order],
                               "evidence_acc": [0.1, 0.2, 0.9][order]})
            else:
                agents.append({"agent_id": agent, "answer_perf": [0.2, 0.6, 0.8, 1.0][agent]})
        telemetry = {name: 0 for name in TELEMETRY}
        telemetry.update(feedback_attempts=2, feedback_visible=1, feedback_cost_seconds=600,
                         input_tokens=100, output_tokens=50, wall_time_seconds=2)
        if row["regime"] != "cost_free": telemetry["budget_utilization"] = 0.2
        record = {"logical_id": row["logical_id"], "source_sha256": {path: sha(blobs[path]) for path in paths},
            "state": "scored", "agents": agents, "telemetry": telemetry, "native_repeat_index": 0,
            "nullable_metrics": {"verification_eff": None} if row["scenario"] == "evidence_audit" else {}}
        if row["scenario"] == "tuning": record["tuning_final_policy"] = "legacy"
        elif pool:
            record["aggregate"] = {"f1": 0.6 if row["strategy"] == "poolact" else 0.7} if row["scenario"] == "restricted_search" else {
                "label_acc": 0.8, "evidence_acc": 0.4 if row["strategy"] == "poolact" else 0.5}
        records.append(record)
    normalized = dump({"schema_version": "normalized-score-candidate-v1", "formal_manifest_sha256": sha(formal_bytes), "records": records})
    return formal_bytes, normalized, blobs, oracle


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--synthetic-demo", action="store_true", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    output = args.output_dir.resolve()
    require(output != HERE and output.is_relative_to(HERE) and not output.exists(), "output must be new and strictly inside this candidate directory")
    inputs = synthetic_inputs()
    result = convert(*inputs, bootstrap={"samples": 1000, "seed": 20260908, "confidence": 0.95})
    output.mkdir(parents=True, exist_ok=False)
    (output / "metrics.csv").write_bytes(result["metrics_csv"])
    for name, value in (("analysis_manifest_candidate.json", result["analysis_manifest_candidate"]),
                        ("derived_artifacts_bundle.json", {k: load(v) for k, v in result["derived_artifacts"].items()}),
                        ("conversion_provenance.json", result["provenance"]),
                        ("input_telemetry_totals.json", result["input_telemetry_totals"]),
                        ("synthetic_input_bundle.json", {"formal_manifest": load(inputs[0]), "normalized": load(inputs[1]),
                            "source_blob_utf8": {k: v.decode() for k, v in inputs[2].items()}, "oracle": load(inputs[3])})):
        (output / name).write_bytes(dump(value) + b"\n")
    for name, rows in (("effects.csv", result["effects"]), ("paired_rows.csv", result["paired_rows"]),
                       ("aggregate_metrics.csv", result["aggregate_metrics"])):
        (output / name).write_bytes(csv_bytes(rows, list(rows[0])))
    print(json.dumps({"synthetic_only": True, "registered": False, "independent_score_audit_complete": False,
        "derived_outcomes": len(result["derived_artifacts"]), "metric_rows": len(result["rows"]),
        "primary_effects": sum(r["role"] == "primary" for r in result["effects"]), "model_calls": 0}))


if __name__ == "__main__":
    main()
