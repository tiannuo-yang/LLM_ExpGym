# 混合重复数离线转换与描述性报告候选 v2

本目录只实现新 restart 的离线转换、算术和呈现，不修改任何旧 frozen/source/result，不调用模型、API、scorer 或投票函数。合成 CPU 成功不等于真实实验、独立评分、运行资格或最终 fresh audit 通过。

## 输入接口

`analysis.convert(manifest_bytes, records_bytes, source_blobs, oracle_bytes, *, pins)` 返回完整 Python 数据；`analysis.render(result)` 返回十个新输出文件的原 bytes。只执行固定旧 metric catalogue 中的纯定义、Gap 算术、比较目录，以及固定 item catalogue；旧 uniform-R convert/validate、runner/scorer 均不调用。依赖源码 SHA 在生产文件和回执内明确锁定。

`pins` 必须从外部给定，精确为 `manifest_sha256`、`records_sha256`、`oracle_sha256`，分别绑定传入同一份实际 bytes。source_blobs 是 `{计划相对路径: 原 bytes}`，只含 records 显式列出的原件；不发现目录、不重序列化原件冒充原 bytes。oracle 文件 SHA 还必须等于 manifest 的 `hpo.oracle`。这些绑定证明输入一致，不证明发布者诚实、评分正确、无旧数据复用、独立审计通过或绝无并发修改。

新 manifest：`restart-mixed-matrix-v1`，每模型显式 repeat_policy 为 ExpGym/PoolAct Search=1、Audit=1、tuning=3，outer_repeats=3 只是最大调度块。必须新 candidate、supersedes、restart_from_scratch=true、reuse_old_completion=false。独立检查全部 item/order/regime/strategy/outer、logical ID、selector、selected input SHA、invocation 链和无路径碰撞，不按结果选择题目。未调用仍在开发的 planner 入口；测试只借新 planner 制造 synthetic manifest。正式 source、执行规范与 invocation argv 正确性仍由外部验收绑定，本工具不是 launcher/authority 验证器。

records bytes schema：

```json
{
  "schema_version": "restart-analysis-records-v1",
  "manifest_sha256": "外部冻结 manifest bytes SHA",
  "source_tree_sha256": "同 manifest.source_and_inputs",
  "records": [{
    "logical_id": "必须每个 planned logical ID 恰有一条",
    "state": "terminal | not_started | infrastructure_error | integrity_error",
    "reason": "未开始或错误必须明确；terminal 可省略",
    "source_sha256": {"计划原件相对路径": "实际原 bytes SHA"},
    "tuning_final_policy": "legacy（tuning 必填）",
    "telemetry": {
      "feedback_attempts": 2, "feedback_visible": 1,
      "duplicate_action_attempts": 0, "feedback_cost_seconds": 600,
      "input_tokens": 100, "output_tokens": 50,
      "wall_time_seconds": 2, "protocol_failure_rate": 0,
      "budget_utilization": 0.2
    },
    "telemetry_unknown_reasons": {},
    "reasoning_tokens": 40
  }]
}
```

`telemetry` 恰需八个公共字段；budget_utilization 仅 Moderate/Tight 必须有，Free 不得有。缺失数据须写 null 并逐字段给 unknown reason，不能写零。计数字段要求整数；reasoning 可 null，已知时不得超过 output（它是其子集）。外部 extraction 必须将 Pool telemetry 记为整个 N4 pool 的总量，而不是只一个 agent；包括所有调用/重试及失败所耗已知成本。实际 episode wall 与 feedback 模拟 seconds 分开，逐 invocation wall 之和不等于调度跨度。这里仅验证数值/绑定，不从 HTTP dumps 独立核实费用；queue/loading/Slurm GPU-h 和全部历史作废成本另由全项目账单提供，不能声称此表覆盖这些成本。

state=terminal 要求原 Exp v2 trace（schema2.1.0）或 Pool result.json+四个独立 agent.json 全部存在；Pool嵌入/独立 agent 的投影必须相同。三份 Exp Audit 原件保持三个 logical 记录；源路径必须由 manifest 指定。summary.json、HTTP dump、状态日志、所有失败尝试并不包含于这个最小输入集合，后续完整审计/发布必须另外保留和验证，不能把本工具的 source inventory 称为所有原件清单。

读取原件显式 `answer/scoring_input/score_status/terminal_status/missing_final_policy/terminal_origin/terminal_scenario`。v2 outcome.score 保持原 value 或 metrics+primary_metric 结构；绝不从消息找一个替代答案。执行资格是 `task-abstention-v1` 的 normal_loop_return，且状态字段与缺答/score 状态一致。Pool 顶层与 aggregate 的 terminal_status 必须逐 canonical 相等。原 result 中其余历史、raw 与错误原件不被删除或改写。

state 不是 terminal 时允许仅有现存原件子集或空集，其 SHA 仍绑定。该单元输出 error/not_started，不把不完整池中残余成绩提升为完整成绩；原始 answer 未被此转换器读取时 `answer_observed=false`，不可误数成 model_no_answer。每条原计划单元始终在 logical_outcomes 中明示状态，不允许省略记录后做完整案例分析。

## 统计和缺失传播

每模型固定 705 invocation、783 logical、1,881 agents；Audit文档内合并后705展示单元、7,687 metric cells。M来自显式模型列表，不硬编码为2。每模型固定514对照（6主+508次），全部负值、零、unknown保留。

- Search/Audit仅 outer_00000：SD/CI都 null，不能用0冒充不确定性为零。Audit三个固定 orders 先文档内等权均值；缺一个完整分数则文档端点 unknown，不平均剩余 orders。固定orders不是独立随机重复。原 Audit verification_eff 可 null，原 metrics保留，不将它新增为514目录的数值终点。
- HPO/NAS outer0/1/2：每个 outer 中先在固定题目集合上算均值，再对三个完整 bundle 给描述性 mean/SD。任何必要 pair unknown，则该完整效应/SD为null。item×outer数量仅是描述性配对单元数，不是独立N；N4 agent不是重复。SD仅描述这三次，所有CI、p值及确认性结论始终不存在。
- Search/Audit正常模型缺答保留原 answer=None，projection为空字符串，由原 evaluator 已报告的分数进入端点，转换器不硬编码零（空预测与空gold之类边界仍由原 evaluator 决定）。与原答为字面空串的正常答复区分。
- HPO/NAS缺配置保持 perf/metrics null。N4只要一个unknown，MI/BoN及raw完整池端点均unknown；known_subsets另列已知数、均值、best，不冒充完整池。每agent的Gap先 `max(0,100*(perf-mean)/(best-mean))` 再MI/BoN，不先平均perf后clip。各task等权；九个Exp任务每家族三项，故固定矩阵下也家族等权；PoolNAS三个task等权。
- ExpGym比较效用方向Free−Tight；Pool cached和poolact分别比较同regime naive N4。Higher-is-better得分正值分别意味着成本退化/候选更好，lower-is-better费用反向；不能把两类“正值”都叫提升。Searchwhois/whatis按原目录跨两个固定world的项目等权；每个原world snapshot仍在artifact_specs中，可分层查验，不宣称新corpus普适性。

## 输出与运行

返回/导出包括：十列metrics.csv，全部effects/paired_rows，逐原agent raw_terminals（原始缺答与投影分开）、逐logical状态、known_subsets，含全结果/派生Audit三source SHA的results.json，provenance.json，以及输出bytes索引。csv的空数值对应JSON null，读取方不得填0。结果 provenance 明示 score_recomputed=false、independent_scoring_algorithm=false、fresh_post_analysis_audit=pending。主仓库旧 analyzer 不直接支持document_outerrep/nullable混合重复数，因此不伪造可执行旧analysis manifest或receipt。

实际授权转换后可运行：

```bash
PYTHONDONTWRITEBYTECODE=1 python3 analysis.py \
  --manifest manifest.json --records records.json --oracle oracle.json \
  --pins input_pins.json --source-index source_index.json \
  --output-dir /一个全新且不存在的输出目录
```

source_index 是计划相对路径→实际文件绝对路径，仅供本地显式映射读取。CLI不是安全发布边界/secret scanner，也不强制预先登记；由调用者选择明确输入与独占输出。它一次读取输入 bytes、校验/转换完才建新输出目录，输出每文件使用 `xb`，拒绝覆盖；多文件写入不是POSIX事务，写入中断会留下可查的部分目录（无完整索引则不得称完整）。原件可大于100MiB，当前内存实现未提供资源承诺或拆片；正式全量后的大IO/发布容量、成本抽取、原件扫描、最终fresh review须另验收。本次没有调用真实转换。

CPU tests：`PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s <本目录> -p test_analysis.py -v`。24项包括完整M2、M1实际CLI新文件导出及拒绝覆盖、所有单元not_started、缺配置/缺order、反向/零效应、正确的full-bundle SD。新planner仅是synthetic测试依赖，pin为7f4ff5dcdc16ecf3292a74dae5683c2e54892ed94fd126f625faa8a8d0591724；生产不调用它。全部fixture显式synthetic/no-server、source目录/snapshot哈希为假，只用于工程测试。当前输入raw scope/科学生成不受这些fixture影响。原始模型答案可能含不可信文本；CSV只做标准CSV编码，不对其语义背书，原件JSON始终保留。

## v2 唯一修复范围

v1 原件保持不动，原22项CPU通过不足以排除源映射错误。独立同行确认：若仅互换同题Free/Tight两行的Exp agent_artifacts，v1可能从另行取分，却在components中保留本行result_artifact的SHA。v2在manifest层强制Exp agent_artifacts恰为[result_artifact]；project也直接从本行已校验SHA的payload提取Exp分数，不再通过该别名二次选择原件。新增两个纯合成回归分别验证换路后即使刷新外部manifest pin仍拒绝，以及单独调用project也只使用本行原件。Pool路径、统计矩阵、nullable、Gap、SD、所有比较与费用口径均保持原样。provenance额外标adapter_revision=source-binding-v2，原输出schema未改。独立复核和真实post-analysis验收仍各自需要，不因本修补自动通过。
