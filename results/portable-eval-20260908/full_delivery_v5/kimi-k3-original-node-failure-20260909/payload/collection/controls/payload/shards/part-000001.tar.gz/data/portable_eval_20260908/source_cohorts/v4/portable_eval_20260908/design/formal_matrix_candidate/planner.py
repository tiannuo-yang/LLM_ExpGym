#!/usr/bin/env python3
"""CPU-only candidate matrix planner. No runner, model, network or score calls."""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[2]
SNAPSHOT = "9369f9c64655f4e8146afee75ae5d3e3a95d7df5"
REGIMES = ("cost_free", "cost_moderate", "cost_tight")
STRATEGIES = ("naive", "cached", "poolact")
HPO = (
    "hpobench:paramnet:adult:steps", "hpobench:paramnet:higgs:steps",
    "hpobench:paramnet:letter:steps", "hpobench:nasbench101:A",
    "hpobench:nasbench101:B", "hpobench:nasbench101:C",
    "hpobench:nasbench201:cifar10-valid", "hpobench:nasbench201:cifar100",
    "hpobench:nasbench201:imagenet16-120",
)
SEARCH = {
    2: (36, 20,
        "0bac202d2a2fed310d2cdae4d75a344011d108dc3f21231310692e864d28a795",
        "3d896ca3bbb740f21aa6c9d3ccc82062a7664a0141e96bf749290b1789b26f33"),
    3: (37, 19,
        "43bb9b2a09a5230abdacbd175ebb7328b0703e9c6d99707ed1494a82a6624581",
        "37b26d5c06fed0a3dc4b49f38804603ba199a461b6c483516a472189c77861c8"),
}
AUDIT_IDS = (1, 2, 4, 5, 6, 8, 11, 18, 21, 22, 23, 24, 25)
AUDIT_HYPOTHESES = {f"nda-{i}" for i in (1, 2, 3, 4, 5, 7, 8, 10, 11, 12, 13, 15, 16, 17, 18, 19, 20)}
KEY_FIELDS = ("model", "system", "scenario", "snapshot", "item", "order",
              "regime", "strategy", "outerrep")


def encoded(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False,
                      separators=(",", ":"), allow_nan=False).encode()


def digest(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def file_hash(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def sanitize(value):
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", value).strip("_") or "x"


def identifier(value):
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*", value):
        raise ValueError("IDs must be nonempty ASCII path-safe labels")
    if len(value) > 80:
        raise ValueError("ID is too long")
    return value


def positive(value):
    if type(value) is not int or value < 1:
        raise ValueError("outer repeats must be an explicit positive integer")
    return value


def checked_orders(config):
    orders = config["orders"]
    if (config.get("cc_split") != "cc-large" or len(orders) != 3
            or any(len(o) != 17 or set(o) != AUDIT_HYPOTHESES for o in orders)):
        raise ValueError("three exact cc-large 17-hypothesis permutations are required")
    return orders


def inventory(repo, acceptance, legacy_runtime=None):
    """Hash exact local input bytes, without loading questions or any scores."""
    repo, acceptance = Path(repo).resolve(), Path(acceptance).resolve()
    raw = acceptance.read_bytes()
    receipt = json.loads(raw)
    files = receipt.get("files")
    if not isinstance(files, dict) or not files:
        raise ValueError("acceptance lacks frozen source files")
    for relative, expected in files.items():
        path = (repo / relative).resolve()
        if not path.is_relative_to(repo) or file_hash(path) != expected:
            raise ValueError("source acceptance mismatch: " + relative)
    selected = {}

    def add(label, path, expected=None):
        path = Path(path).resolve()
        checksum = file_hash(path)
        if expected is not None and checksum != expected:
            raise ValueError("fixed input hash mismatch: " + label)
        selected[label] = {"path": str(path), "sha256": checksum,
                           "bytes": path.stat().st_size}

    base = repo / "data/phantom-wiki/datasets--kilian-group--phantom-wiki-v1/snapshots" / SNAPSHOT
    for seed, (_, _, qa_hash, corpus_hash) in SEARCH.items():
        filename = f"depth_20_size_5000_seed_{seed}-00000-of-00001.parquet"
        add(f"search{seed}.qa", base / "question-answer" / filename, qa_hash)
        add(f"search{seed}.corpus", base / "text-corpus" / filename, corpus_hash)
    add("audit.evidence", repo / "data/contract-nli/test_segments.json",
        "a81e3ecfc1d423f11289a1711ccd4d5cf3167f4d75576f5180bcc0b4c928fd23")
    add("audit.hints", repo / "data/contract-nli/test_nda_span_dims.json",
        "25e9a4092a2688dcb1e933161056b4a6362e1b3941610fd0b5aa205745c96c59")
    order_path = repo / "configs/audit_hypothesis_orders.json"
    order_bytes = order_path.read_bytes()
    order_config = json.loads(order_bytes)
    orders = checked_orders(order_config)
    add("audit.orders", order_path, hashlib.sha256(order_bytes).hexdigest())
    hpo = repo / "data/hpo_tuning"
    add("hpo.config", repo / "configs/hpobench_tasks.yaml")
    add("hpo.oracle", hpo / "oracle3.json")
    tables = hpo / "hpobench_data"
    add("nas101.table", tables / "nasbench_101_compact.pkl",
        "09271ca32f545aac7718be80a0109f79c6244e7853d2f8989aed3b614c590178")
    add("nas101.manifest", tables / "nasbench_101_compact.manifest.json")
    add("nas201.manifest", tables / "nasbench_201_compact/manifest.json")
    for dataset, expected in (
        ("cifar10-valid", "c7983f199b89e1e0dc52c7963f850f8162095b2bbf0c090fb9a4d543bea8616e"),
        ("cifar100", "c941f8c94feb0f9f1985669f160b931a25929e51de7a845a26e76612ac2688aa"),
        ("imagenet16-120", "8a1b743aef5cf74a4867147d5d60d6bed0d1e1b74485e7a0a5bf592d259cb4d3"),
    ):
        add("nas201." + dataset, tables / "nasbench_201_compact" / (dataset + ".pkl"), expected)
    for dataset in ("adult", "higgs", "letter"):
        for prefix in ("rf_surrogate", "rf_cost_surrogate"):
            add(f"paramnet.{dataset}.{prefix}", tables / "Surrogates" / f"{prefix}_paramnet_{dataset}.pkl")
    # Byte bindings, not a claim that the runtime has been validated by this planner.
    runtime = (repo.parent / "kimi_k3_eval/data_runtime" if legacy_runtime is None
               else Path(legacy_runtime).resolve())
    add("paramnet.wrapper", runtime / "run_hpo.sh")
    add("paramnet.runtime_config", runtime / "hpobench_config/.hpobenchrc")
    if acceptance.read_bytes() != raw:
        raise ValueError("acceptance changed during inventory")
    for record in selected.values():
        if file_hash(record["path"]) != record["sha256"]:
            raise ValueError("input changed during inventory")
    return {
        "repo": str(repo), "acceptance_path": str(acceptance),
        "acceptance_sha256": hashlib.sha256(raw).hexdigest(),
        "source_tree_sha256": receipt["source_tree_sha256"],
        "source_files": files, "files": selected, "audit_orders": orders,
        "scope": "local selected input bytes; not rendered prompts, runtime attestation or score audit",
        "search_filter": {"types": [11, 12, 27, 28], "max_answer_count": 20,
                          "stable_sort": ["type", "difficulty"],
                          "counts_bound_to_pinned_parquet_hashes": True},
    }


def make_item(scenario, item, code, snapshot, inputs, **selector):
    return {"scenario": scenario, "item": item, "code": code,
            "snapshot": snapshot, "inputs": inputs, "selector": selector}


def items(system):
    result = []
    for seed, (count, whois, _, _) in SEARCH.items():
        for index in range(count if system == "expgym" else whois):
            result.append(make_item("restricted_search", f"phantom_seed{seed}/q{index}",
                f"phantom_seed{seed}-q{index}", SNAPSHOT,
                [f"search{seed}.qa", f"search{seed}.corpus"],
                data_source=f"phantom_seed{seed}", question_index=index,
                question_family="whois" if index < whois else "whatis"))
    for index, doc_id in enumerate(AUDIT_IDS):
        result.append(make_item("evidence_audit", f"contract-nli/doc{doc_id}",
            f"audit-index{index}-doc{doc_id}", "contract-nli-test-pinned-v1",
            ["audit.evidence", "audit.hints", "audit.orders"],
            question_index=index, doc_id=doc_id, cc_split="cc-large"))
    for task in HPO if system == "expgym" else HPO[3:6]:
        family, dataset = task.split(":")[1:3]
        inputs = ["hpo.config", "hpo.oracle"]
        if family == "paramnet":
            inputs += [f"paramnet.{dataset}.{p}" for p in ("rf_surrogate", "rf_cost_surrogate")]
            inputs += ["paramnet.wrapper", "paramnet.runtime_config"]
        elif family == "nasbench101":
            inputs += ["nas101.table", "nas101.manifest"]
        else:
            inputs += ["nas201." + dataset, "nas201.manifest"]
        result.append(make_item("tuning", task, sanitize(task), "hpobench-pinned-tables-v1",
                               inputs, tuning_task=task, family=family))
    return result


def build_manifest(candidate_id, models, repeats, schedule_seed, base_seed, data, *, _validate=True):
    identifier(candidate_id)
    positive(repeats)
    if type(schedule_seed) is not int or type(base_seed) is not int or base_seed < 0:
        raise ValueError("schedule seed and nonnegative base seed must be explicit integers")
    if base_seed + 4 * repeats - 1 > 2**31 - 1:
        raise ValueError("planned sampling seed exceeds signed int32")
    if not models or any(not isinstance(m, dict) or set(m) != {"label", "model_id"} for m in models):
        raise ValueError("explicit model label/model_id list required")
    for model in models:
        identifier(model["label"])
        if not isinstance(model["model_id"], str) or not model["model_id"].strip():
            raise ValueError("model_id must be nonempty")
    if len({m["label"] for m in models}) != len(models) or len({m["model_id"] for m in models}) != len(models):
        raise ValueError("duplicate model labels/IDs do not create independent models")
    rows, invocations = [], []
    for model in models:
        for outer in range(repeats):
            run_seed = base_seed + 4 * outer
            for system in ("expgym", "poolact"):
                for item in items(system):
                    scenario, selector = item["scenario"], item["selector"]
                    for regime in REGIMES if system == "expgym" else REGIMES[1:]:
                        for strategy in ("single",) if system == "expgym" else STRATEGIES:
                            invocation_key = [model["label"], outer, system, scenario, item["item"], regime, strategy]
                            invocation_id = digest(invocation_key)
                            output = "/".join(("results", candidate_id, model["label"], f"outer_{outer:05d}", system,
                                               scenario, item["code"], regime, strategy))
                            params = ["--scenarios" if system == "expgym" else "--scenario", scenario,
                                      "--cost-regimes" if system == "expgym" else "--cost-regime", regime,
                                      "--seed", str(run_seed)]
                            if system == "expgym":
                                params += ["--models", model["label"], "--model-alias", model["label"] + "=" + model["model_id"],
                                           "--tuning-reps", "1", "--search-reps", "1", "--audit-reps",
                                           "3" if scenario == "evidence_audit" else "1", "--trace-format", "v2"]
                            else:
                                params += ["--model", model["model_id"], "--agents", "4", "--repeats", "1", "--strategies", strategy]
                            if scenario == "restricted_search":
                                params += ["--search-data-source" if system == "expgym" else "--data-source", selector["data_source"],
                                           "--search-indices" if system == "expgym" else "--question-index", str(selector["question_index"])]
                            elif scenario == "evidence_audit":
                                params += ["--audit-indices" if system == "expgym" else "--question-index", str(selector["question_index"]),
                                           "--cc-split", "cc-large"]
                                if system == "expgym":
                                    params += ["--audit-orders", data["files"]["audit.orders"]["path"]]
                            else:
                                params += ["--tuning-tasks" if system == "expgym" else "--tuning-task", selector["tuning_task"]]
                            logical_ids = []
                            orders = range(3) if system == "expgym" and scenario == "evidence_audit" else [None]
                            for order in orders:
                                identity = dict(zip(KEY_FIELDS, (model["label"], system, scenario, item["snapshot"],
                                    item["item"], order if order is not None else ("default" if scenario == "evidence_audit" else "none"),
                                    regime, strategy, outer)))
                                logical_id = digest(identity)
                                logical_ids.append(logical_id)
                                seed = run_seed + (order or 0)
                                if system == "expgym":
                                    if scenario == "tuning":
                                        name = f"tuning_{sanitize(selector['tuning_task'])}_r0_s{seed}.json"
                                    elif scenario == "restricted_search":
                                        name = f"restricted_search_{selector['data_source']}_{selector['question_index']}_r0_s{seed}.json"
                                    else:
                                        name = f"evidence_audit_cc-large_{selector['question_index']}_r{order}_s{seed}.json"
                                    artifact = f"{output}/{model['label']}_{regime}/traces-v2/{name}"
                                    agents = [artifact]
                                else:
                                    artifact = f"{output}/{strategy}/result.json"
                                    agents = [f"{output}/{strategy}/agents/agent_{a}.json" for a in range(4)]
                                order_values = data["audit_orders"][order] if order is not None else None
                                selected = {"selector": selector, "hypothesis_order": order_values,
                                            "files": {k: data["files"][k]["sha256"] for k in item["inputs"]}}
                                rows.append({**identity, "logical_id": logical_id, "invocation_id": invocation_id,
                                    "model_id": model["model_id"], "selector": selector,
                                    "unit": "single_trace" if system == "expgym" else "independent_pool_aggregate",
                                    "item_status": "prospectively_reserved" if scenario == "restricted_search" else "previously_inspected",
                                    "selected_input_sha256": digest(selected), "input_file_ids": item["inputs"],
                                    "hypothesis_order": order_values, "result_artifact": artifact,
                                    "agent_artifacts": agents, "sampling_seed_labels": [seed] if system == "expgym" else list(range(run_seed, run_seed + 4)),
                                    "seed_control": "not_verified_by_planner"})
                            invocations.append({"invocation_id": invocation_id, "model": model["label"], "outerrep": outer,
                                "system": system, "scenario": scenario, "logical_ids": logical_ids,
                                "runtime_profile_required": "paramnet_legacy" if selector.get("family") == "paramnet" else "native",
                                "runner": "scripts/run_paper_sweep.py" if system == "expgym" else "scripts/run_poolact.py",
                                "selection_argv": params, "output_relative_dir": output,
                                "summary_artifact": output + "/summary.json" if system == "poolact" else None,
                                "dump_relative_dir": "dumps/" + candidate_id + "/" + invocation_id,
                                "schedule_rank_hash": digest([schedule_seed, invocation_key]),
                                "executable": False})
    # Models remain sequential candidates; each model/outer block has a fixed outcome-independent order.
    order_of_model = {m["label"]: i for i, m in enumerate(models)}
    invocations.sort(key=lambda x: (order_of_model[x["model"]], x["outerrep"], x["schedule_rank_hash"]))
    for index, invocation in enumerate(invocations):
        invocation["schedule_index"] = index
    result = {
        "schema_version": "formal-matrix-candidate-v1", "classification": "Custom study / CPU-only candidate",
        "candidate_id": candidate_id, "registered": False, "launch_authorized": False,
        "models": models, "outer_repeats": repeats, "schedule_seed": schedule_seed, "base_seed": base_seed,
        "source_and_inputs": data, "logical_rows": rows, "invocations": invocations,
        "counts": {"expgym_traces": 363 * repeats * len(models), "poolact_pools": 330 * repeats * len(models),
                   "poolact_agent_traces": 1320 * repeats * len(models), "agent_traces": 1683 * repeats * len(models),
                   "logical_outcomes": 693 * repeats * len(models), "invocations": 615 * repeats * len(models)},
        "scheduling": {"algorithm": "sha256_rank_within_model_outer_block_v1",
                       "not_a_fisher_pair_assignment": True, "worker_completion_order_not_prescribed": True,
                       "model_order_is_input_order": True, "isolation": "fresh invocation/pool; no cross-condition graph/cache"},
        "unresolved_g6_requirements": ["explicit real model/checkpoint readiness and hash identity",
            "approved source/environment/runtime/data identity at launch", "per-model generation/transport/context profile",
            "runtime-pilot-based final R/M/resource authorization", "effective sampling seed level",
            "statistical method/estimand/assumptions/multiplicity/stopping registration",
            "independent full artifact/score/raw-dump audit", "a dated externally retained registration receipt"],
        "coverage_contract": {"all_logical_ids_required": True, "retain_zero_negative_model_failures": True,
            "infrastructure_failure_is_incomplete_not_dropped": True, "pool_agents_are_not_independent_repeats": True,
            "raw_attempt_filenames_enumerated_by_postrun_audit_not_guessed": True},
    }
    if _validate:
        validate(result)
    return result


def validate(manifest):
    rows, invocations = manifest["logical_rows"], manifest["invocations"]
    count = manifest["outer_repeats"] * len(manifest["models"])
    if len(rows) != 693 * count or len(invocations) != 615 * count:
        raise ValueError("matrix count mismatch")
    if len({encoded([row[k] for k in KEY_FIELDS]) for row in rows}) != len(rows):
        raise ValueError("duplicate logical key")
    if len({row["logical_id"] for row in rows}) != len(rows):
        raise ValueError("duplicate logical ID")
    if len({i["invocation_id"] for i in invocations}) != len(invocations):
        raise ValueError("duplicate invocation ID")
    expected_keys = set()
    for model in manifest["models"]:
        for outer in range(manifest["outer_repeats"]):
            for system in ("expgym", "poolact"):
                for item in items(system):
                    for regime in REGIMES if system == "expgym" else REGIMES[1:]:
                        for strategy in ("single",) if system == "expgym" else STRATEGIES:
                            orders = range(3) if system == "expgym" and item["scenario"] == "evidence_audit" else ["default" if item["scenario"] == "evidence_audit" else "none"]
                            for order in orders:
                                expected_keys.add(encoded([model["label"], system, item["scenario"], item["snapshot"],
                                    item["item"], order, regime, strategy, outer]))
    if {encoded([r[k] for k in KEY_FIELDS]) for r in rows} != expected_keys:
        raise ValueError("exact item/order/regime/strategy/repeat matrix mismatch")
    item_specs = {(system, item["scenario"], item["item"]): item
                  for system in ("expgym", "poolact") for item in items(system)}
    by_invocation = {i["invocation_id"]: i for i in invocations}
    for row in rows:
        if row["logical_id"] != digest({k: row[k] for k in KEY_FIELDS}):
            raise ValueError("logical ID is not bound to its identity")
        spec = item_specs[(row["system"], row["scenario"], row["item"])]
        if row["selector"] != spec["selector"] or row["input_file_ids"] != spec["inputs"]:
            raise ValueError("selected item metadata mismatch")
        selected = {"selector": row["selector"], "hypothesis_order": row["hypothesis_order"],
                    "files": {k: manifest["source_and_inputs"]["files"][k]["sha256"] for k in row["input_file_ids"]}}
        if row["selected_input_sha256"] != digest(selected):
            raise ValueError("selected input digest mismatch")
        invocation = by_invocation[row["invocation_id"]]
        if row["logical_id"] not in invocation["logical_ids"]:
            raise ValueError("row/invocation link mismatch")
        if len(row["agent_artifacts"]) != (1 if row["system"] == "expgym" else 4):
            raise ValueError("wrong agent count")
    owned = []
    for row in rows:
        owned.extend([row["result_artifact"]] if row["system"] == "expgym" else [row["result_artifact"], *row["agent_artifacts"]])
    owned.extend(i["summary_artifact"] for i in invocations if i["summary_artifact"])
    if len(set(owned)) != len(owned):
        raise ValueError("output paths collide")
    if any(Path(p).is_absolute() or ".." in Path(p).parts for p in owned):
        raise ValueError("unsafe output path")
    linked = [r for i in invocations for r in i["logical_ids"]]
    if Counter(linked) != Counter(r["logical_id"] for r in rows):
        raise ValueError("invocations do not cover logical rows exactly once")
    expected = {("expgym", "restricted_search"): 219, ("expgym", "evidence_audit"): 117,
                ("expgym", "tuning"): 27, ("poolact", "restricted_search"): 234,
                ("poolact", "evidence_audit"): 78, ("poolact", "tuning"): 18}
    for model in manifest["models"]:
        for outer in range(manifest["outer_repeats"]):
            actual = Counter((r["system"], r["scenario"]) for r in rows if r["model"] == model["label"] and r["outerrep"] == outer)
            if dict(actual) != expected:
                raise ValueError("per-model/repeat matrix mismatch")
    regenerated = build_manifest(manifest["candidate_id"], manifest["models"], manifest["outer_repeats"],
        manifest["schedule_seed"], manifest["base_seed"], manifest["source_and_inputs"], _validate=False)
    for key, expected_value in regenerated.items():
        if manifest.get(key) != expected_value:
            raise ValueError("candidate differs from the fixed construction contract: " + key)


def coverage(manifest, ledger):
    """Check supplied completion labels only, never score values or artifact truth."""
    validate(manifest)
    allowed = {"scored", "model_failure_scored", "infrastructure_failed", "pending"}
    expected = {r["logical_id"] for r in manifest["logical_rows"]}
    observed = [r["logical_id"] for r in ledger]
    if len(set(observed)) != len(observed) or set(observed) != expected:
        raise ValueError("completion ledger must contain each planned outcome exactly once")
    if any(r.get("state") not in allowed for r in ledger):
        raise ValueError("unknown completion state")
    counts = Counter(r["state"] for r in ledger)
    return {"ledger_coverage_complete": counts["pending"] == counts["infrastructure_failed"] == 0,
            "states": dict(counts), "artifact_integrity_verified": False,
            "score_recomputation_verified": False, "statistical_confirmation": False}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate-id", required=True)
    parser.add_argument("--model", action="append", required=True, metavar="LABEL=MODEL_ID")
    parser.add_argument("--outer-repeats", type=int, required=True)
    parser.add_argument("--schedule-seed", type=int, required=True)
    parser.add_argument("--base-seed", type=int, required=True)
    parser.add_argument("--acceptance", type=Path, required=True)
    parser.add_argument("--repo", type=Path, default=WORKSPACE / "LLM_ExpGym")
    parser.add_argument("--legacy-runtime", type=Path,
                        help="Explicit existing runtime data directory; default preserves repo sibling layout")
    parser.add_argument("--output-dir", type=Path, required=True,
                        help="New directory strictly below this candidate planner directory")
    args = parser.parse_args(argv)
    output = args.output_dir.resolve()
    if output == HERE or not output.is_relative_to(HERE) or output.exists():
        parser.error("output must be a new directory strictly inside formal_matrix_candidate")
    try:
        models = []
        for value in args.model:
            label, model_id = value.split("=", 1)
            models.append({"label": label, "model_id": model_id})
        data = inventory(args.repo, args.acceptance, legacy_runtime=args.legacy_runtime)
        manifest = build_manifest(args.candidate_id, models, args.outer_repeats,
                                  args.schedule_seed, args.base_seed, data)
        design = HERE.parent / "PILOT_AND_INFERENCE.zh.md"
        design_bytes = design.read_bytes()
        manifest["design_reference"] = {"path": str(design),
            "sha256": hashlib.sha256(design_bytes).hexdigest(),
            "sections_4_onwards_sha256": hashlib.sha256(design_bytes.split("## 4. 真机 smoke".encode(), 1)[1]).hexdigest()}
    except (KeyError, ValueError, OSError, TypeError) as exc:
        parser.error(str(exc))
    output.mkdir(parents=True, exist_ok=False)
    raw = json.dumps(manifest, sort_keys=True, ensure_ascii=False, indent=2, allow_nan=False).encode() + b"\n"
    (output / "candidate_manifest.json").write_bytes(raw)
    receipt = {"candidate_manifest_sha256": hashlib.sha256(raw).hexdigest(),
               "planner_sha256": file_hash(__file__), "counts": manifest["counts"],
               "registered": False, "launch_authorized": False,
               "model_calls": 0, "source_or_data_writes": 0}
    (output / "candidate_receipt.json").write_bytes(encoded(receipt) + b"\n")
    print(json.dumps(receipt, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
