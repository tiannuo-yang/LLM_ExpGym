#!/usr/bin/env python3
"""Capture one ROOT-authorized frozen v1 format diagnostic CLI; no retry."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys

HERE = Path(__file__).resolve().parent
OP = HERE.parent
PY = '/lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python'
TOOL = OP / 'format_diagnostics_candidate_v1/diagnostics.py'
TOOL_SHA = 'cddf8f05c5c23ffa92373c45ed42a07507b890ebd3dc5f31017f1c150d9d6427'
GO = OP / 'ROOT_K3_FORMAT_DIAG_GO.json'
GO_SHA = 'ad434a9218a7e9f4eafeea74237b531e528e2d3d2862485cca13fd8420744cae'
OUTPUT = OP / 'actual_format_diagnostics_k3_node_failure_v1'
ARGV = [PY, '-B', str(TOOL), '--go', str(GO), '--go-sha256', GO_SHA]


def write(name, obj):
    with (HERE / name).open('x', encoding='utf-8') as handle:
        json.dump(obj, handle, sort_keys=True, separators=(',', ':'))
        handle.write('\n'); handle.flush(); os.fsync(handle.fileno())


def main():
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    if OUTPUT.exists() or OUTPUT.is_symlink() or OUTPUT.parent.resolve() != OUTPUT.parent:
        raise RuntimeError('output_not_fresh_canonical')
    if hashlib.sha256(TOOL.read_bytes()).hexdigest() != TOOL_SHA or hashlib.sha256(GO.read_bytes()).hexdigest() != GO_SHA:
        raise RuntimeError('tool_or_go_pin')
    go = json.loads(GO.read_bytes())
    if go['output_dir'] != str(OUTPUT) or go['program_sha256'] != TOOL_SHA:
        raise RuntimeError('go_binding')
    for ref in go['inputs'].values():
        if hashlib.sha256(Path(ref['path']).read_bytes()).hexdigest() != ref['sha256']:
            raise RuntimeError('go_input_pin')
    write('STARTED.json', dict(schema='frozen-format-diagnostics-operator-start-v1',
          utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), operator_pid=os.getpid(), argv=ARGV,
          go_sha256=GO_SHA, program_sha256=TOOL_SHA, input_refs=go['inputs'],
          python_version_prechecked='3.11.15', invocation_limit=1, retry=False, caps_changed=False, core_limit=[0, 0]))
    with (HERE / 'diagnostics.stdout.log').open('xb') as stdout, (HERE / 'diagnostics.stderr.log').open('xb') as stderr:
        child = subprocess.Popen(ARGV, stdout=stdout, stderr=stderr)
        write('CHILD_STARTED.json', dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), pid=child.pid, argv=ARGV))
        code = child.wait()
    write('CLI_EXIT.json', dict(schema='frozen-format-diagnostics-operator-exit-v1',
          utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), actual_exit_code=code, pid=child.pid, argv=ARGV))
    print(json.dumps(dict(actual_diagnostics_exit_code=code, output=str(OUTPUT))), flush=True)
    return code


if __name__ == '__main__':
    sys.exit(main())
