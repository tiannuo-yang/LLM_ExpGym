#!/usr/bin/env python3
"""One frozen, sealed K3 request-input audit invocation; no retry."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys

HERE = Path(__file__).resolve().parent
OP = HERE.parent
PY = '/lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python'
TOOL = OP / 'formal_prompt_audit_candidate_v2/audit_prompts.py'
PLAN = OP / 'compiled_restart-20260909-v5-kimi-k3-formal/plan.json'
EXECUTION = OP.parent.parent / 'formal_runs/restart-20260909-v5-kimi-k3-formal/execution.json'
SEAL = OP / 'sealed_restart_runs_v1/kimi-k3-formal-node-failure-20260909/inventory.json'
OUTPUT = OP / 'actual_formal_prompt_audit_k3_node_failure_v2'
PINS = {
    TOOL: '243ce28615b0c0bbfe7bf004f9ade8b0d03aa95718012b70e0a8ff24c75c0656',
    PLAN: '52e42a7464d28433ca350bc4d9aedf417c92bb8595662a5fdb22f545073870e9',
    EXECUTION: 'bb77a79f4a4979702f135aa5947747a73e08d4b375521a541d83cbec6f294a1b',
    SEAL: 'b98bbd8d06627b7fb757fb0beac661d40d98d1d94da5098b0fbf1c5d6ab97c66',
}
ARGV = [PY, '-B', str(TOOL), '--plan', str(PLAN), '--plan-sha256', PINS[PLAN],
        '--execution', str(EXECUTION), '--execution-sha256', PINS[EXECUTION],
        '--seal', str(SEAL), '--seal-sha256', PINS[SEAL], '--output', str(OUTPUT)]


def write(name, obj):
    with (HERE / name).open('x', encoding='utf-8') as handle:
        json.dump(obj, handle, sort_keys=True, separators=(',', ':'))
        handle.write('\n'); handle.flush(); os.fsync(handle.fileno())


def main():
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    if OUTPUT.exists() or OUTPUT.is_symlink() or OUTPUT.parent.resolve() != OUTPUT.parent:
        raise RuntimeError('output_not_fresh_canonical')
    for path, expected in PINS.items():
        if path.resolve() != path or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise RuntimeError('input_pin_mismatch')
    write('STARTED.json', dict(schema='frozen-prompt-audit-operator-start-v1',
          utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), operator_pid=os.getpid(), argv=ARGV,
          input_refs=[dict(path=str(path), sha256=sha) for path, sha in PINS.items()],
          invocation_limit=1, retry=False, caps_changed=False, core_limit=[0, 0],
          private_keys_read=False, interpretation_scope='request_payload and declared attempt/owner metadata only; raw JSON containers necessarily read and deserialized'))
    with (HERE / 'audit.stdout.log').open('xb') as stdout, (HERE / 'audit.stderr.log').open('xb') as stderr:
        child = subprocess.Popen(ARGV, stdout=stdout, stderr=stderr)
        write('CHILD_STARTED.json', dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), pid=child.pid, argv=ARGV))
        code = child.wait()
    write('CLI_EXIT.json', dict(schema='frozen-prompt-audit-operator-exit-v1',
          utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), actual_exit_code=code, pid=child.pid, argv=ARGV))
    print(json.dumps(dict(actual_audit_exit_code=code, output=str(OUTPUT))), flush=True)
    return code


if __name__ == '__main__':
    sys.exit(main())
