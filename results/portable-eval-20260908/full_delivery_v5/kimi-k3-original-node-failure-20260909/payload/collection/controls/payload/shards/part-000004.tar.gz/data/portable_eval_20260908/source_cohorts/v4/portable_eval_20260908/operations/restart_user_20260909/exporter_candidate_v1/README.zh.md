# 新正式结果离线 exporter 候选 v1

此候选连接真实新 launcher 文件格式与已冻结 analysis_candidate_v2。它不是新的执行器、评分器、授权系统或发布器；不启动原CLI、不调用模型/API、不读取key、不改变旧结果。当前仅 synthetic CPU 与已保留 Static/fake source E2E原件测试，尚未读取本轮真实smoke/formal成绩。

## 精确输入及执行

```bash
PYTHONDONTWRITEBYTECODE=1 python3 exporter.py \
  --plan /ABS/plan.json --plan-sha256 EXTERNAL_PLAN_SHA \
  --execution /ABS/run/execution.json --execution-sha256 EXTERNAL_EXECUTION_SHA \
  --source-acceptance /ABS/source_acceptance_v5_final.json \
  --source-acceptance-sha256 EXTERNAL_SOURCE_ACCEPTANCE_SHA \
  --output-dir /ABS/A_NEW_EXPORT_DIRECTORY
```

API：`export(plan_ref, execution_ref, acceptance_ref, Reader()) -> (files_bytes, evidence)`。三个refs精确为path+原文件SHA，由调用者外部提供。只接受 `restart-executable-plan-v1/formal_mixed` + `restart-bounded-study-execution-v1` 且local_workers=0的同plan/run执行；selected_smoke和CPU计划不会被转换成正式结果。

从 plan.matrix/jobs 读取全部705 invocation、783 logical、1881 agents（一模型），调用固定分析器独立验证混合矩阵。每个started job必须有report，其他job明确列于unstarted；不按结果删题。两模型分别使用自己的plan/execution导出，不能串接一个模型的结果冒另一模型。M2完整联合报告仍由ROOT组合两个已审计产品，本工具不选新M/R。

原分数依据是已冻结 producer 写出的**同源原CLI禁LLM重算回执**：核verified_resume原文件SHA、schema、invocation、source exit0、construction/generation各0、model_calls_forbidden、independent_source_cli_resume等字段；绑定source_capture的原log SHA、进程退出/EOF/wait/排空证据、verified_resume.log及原终态旁证。不是只看到 `passed=true` 就导出。固定launcher/wire/evidence/dispatch/support/planner六生产文件必须出现在plan.file_bindings并逐原bytes核SHA；source acceptance的86个源文件也核SHA（不执行它们）。算法仍是原仓库同一算法，不能称独立算法实现；这些是 externally pinned 历史证据的校验，不是密码学证明或重新执行评分。

execution原件内report/decision绑定物理logs/iid/terminal.json的相同字段。原execution schema并没有terminal文件SHA，本工具在指定路径只读该原件并记录实际SHA；其记录时间仅保留，不伪称这个新观察SHA原先就由ROOT外部签过。verified_resume.log同理为指定路径观察SHA。其他原artifacts/raw_audit/verified_resume/source_capture log均使用原report已有SHA。所有新观察/绑定原件在EXPORT_EVIDENCE完整索引。

## 分账与完整性

- 逐logical从manifest规定的result/agent路径取原件，保持原answer=None、scoring_input、score_status和terminal_status；继续使用冻结分析器的两道Exp单原件绑定防线。
- Exp每个order使用本trace run.api_dump.client_id、seed以及llm_calls.attempt_usage逐request/generation/attempt校对原raw；每条raw只归属一个logical。Audit三orders各自token/feedback/wall计数，绝不把整个invocation总量复制三次。再由分析器文档内严格三order均值，缺一不偷做available-case均值。
- Pool每个logical对应整个N4，分别校对四agent client/seed/usage_attempts并合并所有HTTP重试；feedback模拟成本相加，wall用闭合source_capture的整个并发pool elapsed，不是四agent wall之和。原预算是每agent budget×4，合计cost/合计budget作utilization。
- 原Pool v1没有逐tool可见性，沿旧extractor：有tools时feedback_visible=null，零tools才0；不从模型文本猜反馈可见性。duplicate_action_attempts沿旧canonical(tool name,JSON raw arguments)标识，将整N4所有调用一起去重；不是只统计cache hit。
- protocol_failure_rate为原protocol_failures的不同llm_call_index数/原LLM决策数（含forced）；零分母null。unknown使用量不补零，每个字段保留known_sum、unknown_attempts、complete_total。reasoning只按原completion_tokens_details记录，已含于output，不相加；未报告reasoning时null，不按reasoning_content长度估token。
- raw_audit.inventory全部raw/wire原件SHA核对，已验证count/bijection与原ledger精确匹配。正常模型缺答Search/Audit使用原reported empty-prediction score，HPO配置缺失unknown，交冻结分析器处理N4 MI/BoN完整端点unknown。
- 未派发job仍产生每个logical的not_started记录。失败job用preserved_artifacts/raw并保留failure_code，原raw按已声明seed归属只用于费用观察，不把残余分数提升为完整pool。无法确定的工具cost/wall/visibility为null；模型missing和基础设施/完整性失败不混成模型零分。整个账单及失败已知费用另可查records.telemetry_sidecar，不能将“不完整端点”理解为没花钱。

此工具只读输入一次快照，不主动重跑已有原CLI；实际input根已经闭合仍是前提。Reader拒绝final symlink/非regular、读取时inode/size/mtime变动；它不是恶意并发攻击的原子快照，不承诺发现change-and-revert或结束后变动，也不是完整目录extra-file扫描。所有已知原件SHA/bytes被保存；新final独立全树/raw/评分/报告审查依然pending。runtime数据、checkpoint完整性、server真实prompt渲染/清空、累计GPU费用不由此转换器重新证明。

## 产物与边界

17个文件：冻结分析器十个文件（含全部514对照/7687cells/原终态/派生Audit三source SHA），加records.json、manifest.json、input_pins.json、oracle.json、source_index.json、EXPORT_EVIDENCE.json、EXPORT_INDEX.json。manifest.json是从外部已pin plan.matrix提取后canonical编码的新派生文件，**不是**原plan bytes的另一个SHA名称。原件一律不改、不删、不重新序列化代替源bytes；source_index仅映射实际原路径，完整raw/日志索引在evidence中，不复制占用更多raw空间。

不覆盖现有输出。导出成功后有EXPORT_INDEX记录每产物SHA/bytes；多文件写入不是事务，异常留下部分新目录，无完整index不得称完整。内存实现显式1GiB单文件、32GiB累计读取上限；达到上限安全失败，不自动扩大或重序列化截断。该容量不是最终实际run的大小保证，需要ROOT按实际体积另做窄review。不是secret scanner或自动发布器；key从不在本入口指定输入集，不能把任意外来index当可信发布授权。

provenance一直保持fresh_post_analysis_audit=pending、scorer_calls=0、model_calls=0、无provider quiescence证明。CPU候选通过不等于真实转换验收；实际转换必须在本轮formal自然闭合并得到明确许可后进行，smoke不计正式结果。

测试：`PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s <本目录> -p test_exporter.py -v`。synthetic全matrix只有四个job（六个logical）填入合成已闭合结果，其余明确not_started，验证全矩阵不删样；并读取已封存sourceE2E的两组Audit原fake traces/禁LLM重算回执检验真实字段，绝不把这些fake打上formal授权。
