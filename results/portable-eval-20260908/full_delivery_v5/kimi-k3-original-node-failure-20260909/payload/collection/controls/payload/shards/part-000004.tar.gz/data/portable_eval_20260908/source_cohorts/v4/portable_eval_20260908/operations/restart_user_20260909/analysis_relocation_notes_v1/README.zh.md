# 异地恢复后重跑描述性分析：静态交付说明

可以保留全部原始字节与身份，只派生一个本地路径索引来调用冻结 `analysis.py`。这与重新运行 exporter、重新评分或重跑模型是三件不同的事。本页只核源码接口，未读取任何实际结果/恢复 payload，也没有运行 CLI；不代表异地重放已经通过。

## 最小代码闭包

保留下面相对布局，根目录可以任意选择；三份源码必须维持 [exactrefs.json](exactrefs.json) 的原 SHA：

```text
ANALYSIS_ROOT/
  operations/restart_user_20260909/analysis_candidate_v2/analysis.py
  design/formal_export_candidate/converter.py
  design/formal_matrix_candidate/planner.py
```

`analysis.py:14–17,48–53` 按自身目录的第三级父目录定位 converter，并校验固定 SHA；converter :16–18,54–60 继续按相对目录加载固定 planner。二者经不同于 `__main__` 的名字执行，只使用定义/目录；不会调用旧 uniform-R converter、planner 的 inventory/build/main 或 launcher。生产依赖的是旧 item catalogue SHA `13914a…`，**不是**合成测试使用的新 planner `7f4ff5…`。三份脚本只有 Python 标准库 import，不需要模型权重、SGLang、HPOBench、数据库或网络。不能只复制 analysis.py 一件，也不能将目录扁平化；exporter.py 不属于这一步的运行闭包。

## 交付物与本地映射

每份已封存的 exporter product 应保留原 `manifest.json`、`records.json`、`oracle.json`、`input_pins.json`、原 `source_index.json`、`EXPORT_EVIDENCE.json`、`EXPORT_INDEX.json`，以及 records 明确引用的所有 source 原件。前三份 bytes SHA、source SHA、manifest 内 source tree/source input pins 均保持原值；**不要为了本地路径而改写原 manifest、records、oracle 或 source 原件**。manifest 内原绝对路径可作为历史 provenance 保留，analysis 本身不沿它们加载数据库。

未来操作顺序：

1. 使用已验证的公共 collection 恢复入口与外部 INDEX SHA 得到完整恢复目录；确认 COMPLETE 与原 bytes/path 身份，不把历史 DEV/作废/smoke 包当成本轮正式分析输入。
2. 根据 `OWNERSHIP_INDEX.json` 找到每个 bundle 的 `restored_payload` 与原索引位置，再查相应 member index 的 `files[].path`。结合交付清单明确的原 run/source 根与 publication namespace，将原 source_index 的“计划相对 key → 旧绝对路径”对应到实际恢复位置。必须逐一绑定，不按 basename、目录猜测或同内容文件替换归属；跨 bundle 或不同模型也不能省略 namespace 后混合。
3. 新建独立的 `source_index.relocated.json`：**key 原样保留**，value 改为该原件在本机恢复目录中的绝对路径。每个 key 的 bytes/SHA 必须匹配原 records 中的引用，并有准确的交付归属。key 集合必须恰好等于所有 records.source_sha256 的并集；有冲突/缺项即停止，不删行补零。不在 records 中的完整 raw/失败成本档案仍须保留，但不混入这个最小索引。
4. 给派生索引另存 SHA/来源清单；原索引及旧证据保持不变。使用外部发布清单认可的 input pins，不能把篡改后的输入自算 SHA 当成原证据。只有受信本地路径才可传入：analysis CLI 的 source_index 不是安全路径沙箱或 secret scanner。

接口上现有的命令为（仅示例，路径由未来交付清单填写）：

```bash
PYTHONDONTWRITEBYTECODE=1 python3 /ABS/ANALYSIS_ROOT/operations/restart_user_20260909/analysis_candidate_v2/analysis.py \
  --manifest /ABS/original_export/manifest.json \
  --records /ABS/original_export/records.json \
  --oracle /ABS/original_export/oracle.json \
  --pins /ABS/original_export/input_pins.json \
  --source-index /ABS/derived/source_index.relocated.json \
  --output-dir /ABS/a_fresh_nonexistent_analysis_output
```

`analysis.py:298–309` 校验外部三 pins、source key 集与 oracle 绑定；:188–195 逐原件校验 SHA；:416–430 读取派生索引并输出十份描述性文件。选择既有 CPU 验证覆盖的 Python3.10/3.11；它一次读取全部输入，不承诺小内存或跨解释器字节完全一致。必须另对输出索引/原发布输出做核对；部分写出或非零退出不能称完整成功。现有 provenance 的 `fresh_post_analysis_audit=pending` 等字段不会因重放自动升级。

## exporter 与未验证边界

`exporter.py:60–108,244–265,298–302` 使用旧绝对 path、原 output/repo root、源86与 producer refs；只把 plan/execution 参数改成新位置，并不能移走全部嵌套引用。它还把 execution.plan_ref 等作为精确身份比较。因此不能宣称原 exporter 无需适配即可异地重新抽取 records。保留已发布的、外部 pin 的 records 是最薄描述性重放路线；以后若需从完整 raw 重新抽取，须另外明确映射 Reader/路径归属且保留原证据，当前没有实现或验证这种适配。

本次仅核4份源码+2份README的静态路径/接口与 SHA，没有新建 relocator、执行分析/恢复、检查本轮实际发布闭包或验证输出相等。最终正式包是否含三份代码、原 exporter product、全部 source 引用及 namespace 对照，仍需在实际交付时按精确清单核实。分析读取已报告分数，不独立重新评分；最小 source_index 也不是全项目 raw/失败尝试/费用的完整交付清单。最终独立结果审计仍单列。
