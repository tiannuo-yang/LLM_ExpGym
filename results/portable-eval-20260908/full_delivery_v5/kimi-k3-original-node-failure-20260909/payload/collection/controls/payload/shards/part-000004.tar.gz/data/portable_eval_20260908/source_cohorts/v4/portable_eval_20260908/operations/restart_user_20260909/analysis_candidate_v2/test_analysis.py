"""Only synthetic data, standard-library arithmetic and no model/scorer imports."""
import copy
import builtins
import contextlib
import io
import json
from pathlib import Path
import socket
import sys
import statistics
import tempfile
import types
import unittest
from unittest import mock

import analysis as a


def fixture(models=2):
    path = a.HERE.parent / "planner_candidate_v1/planner.py"
    source = path.read_bytes()
    a.require(a.sha(source) == "7f4ff5dcdc16ecf3292a74dae5683c2e54892ed94fd126f625faa8a8d0591724", "synthetic fixture planner dependency changed")
    ns = {"__file__": str(path), "__name__": "synthetic_restart_planner"}
    exec(compile(source, str(path), "exec"), ns)
    p = types.SimpleNamespace(**ns)
    oracle = a.dump({"synthetic": True, "tasks": {t: {"mean_perf": .5, "best_perf": .8} for t in p.HPO}})
    labels = {key for system in a.REPEATS for item in p.items(system) for key in item["inputs"]}
    order = sorted(p.AUDIT_HYPOTHESES)
    data = {"files": {k: {"path": "/synthetic/" + k, "sha256": "a" * 64, "bytes": 1} for k in labels},
            "source_tree_sha256": "b" * 64, "audit_orders": [order, list(reversed(order)), order[1:] + order[:1]]}
    data["files"]["hpo.oracle"]["sha256"] = a.sha(oracle)
    manifest = p.build_manifest("synthetic-restart-analysis", [{"label": "m" + str(i), "model_id": "synthetic/no-server-" + str(i)} for i in range(models)],
                                a.REPEATS, 101, 1206, data, supersedes=["synthetic-old-superseded"])
    c = a.catalogue()
    blobs, records = {}, []
    for row in manifest["logical_rows"]:
        pool, scenario = row["system"] == "poolact", row["scenario"]
        perf = .6 + .03 * row["outerrep"]
        if scenario == "restricted_search":
            perf = .8 if row["regime"] == "cost_tight" else .6  # negative Exp degradation
        metrics = {"label_acc": [.3, .6, .9][row["order"]], "evidence_acc": [.1, .2, .9][row["order"]]} if type(row["order"]) is int else {"label_acc": .7, "evidence_acc": .4}
        if scenario == "evidence_audit":
            perf = metrics["evidence_acc"]
        agents = []
        for index in range(4 if pool else 1):
            value = [.2, .6, .8, 1.][index] + .01 * row["outerrep"] if pool and scenario == "tuning" else perf
            value = min(value, 1.)
            agents.append({"agent_id": index, "score_check": {"ok": True}, "answer": "synthetic answer", "scoring_input": "synthetic answer", "score_status": "scored_final_answer",
                "missing_final_policy": a.POLICY, "terminal_origin": "normal_loop_return", "terminal_scenario": scenario,
                "answer_perf": value, "answer_metrics": metrics if scenario == "evidence_audit" else None,
                "terminal_status": status(0, 1)})
        if pool:
            aggregate_perf = .6 if row["strategy"] == "poolact" else .7
            if scenario == "tuning":
                aggregate_perf = max(v["answer_perf"] for v in agents)
            aggregate = {"answer": "synthetic voted answer", "answer_perf": aggregate_perf,
                         "answer_metrics": {"label_acc": .7, "evidence_acc": .4} if scenario == "evidence_audit" else None,
                         "terminal_status": status(0, 4)}
            payload = {"agent_results": agents, "aggregate": aggregate, "terminal_status": status(0, 4)}
            blobs[row["result_artifact"]] = a.dump(payload)
            for path, agent in zip(row["agent_artifacts"], agents):
                blobs[path] = a.dump(agent)
        else:
            agent = agents[0]
            score = {"metrics": agent["answer_metrics"], "primary_metric": "evidence_acc"} if scenario == "evidence_audit" else {"value": agent["answer_perf"]}
            blobs[row["result_artifact"]] = a.dump({"schema": {"name": "expgym.trace", "version": "2.1.0"}, "outcome": {**agent, "score": score, "validation": {"passed": True, "method": "repository_score_recompute"}}})
        telemetry = {k: 0 for k in c.TELEMETRY}
        telemetry.update(feedback_attempts=2, feedback_visible=1, feedback_cost_seconds=600, input_tokens=100, output_tokens=50, wall_time_seconds=2)
        if row["regime"] != "cost_free":
            telemetry["budget_utilization"] = .2
        records.append({"logical_id": row["logical_id"], "state": "terminal", "tuning_final_policy": "legacy",
                        "source_sha256": {p: a.sha(blobs[p]) for p in a.required_paths(row)}, "telemetry": telemetry, "reasoning_tokens": 40})
    return manifest, {"schema_version": "restart-analysis-records-v1", "manifest_sha256": a.sha(a.dump(manifest)),
                      "source_tree_sha256": data["source_tree_sha256"], "records": records}, blobs, oracle


def status(missing, n, unknown=False):
    return {"schema_version": "expgym.execution-terminal.v1", "policy_version": a.POLICY,
            "execution_complete": True, "score_complete": not unknown,
            "terminal_classification": "model_no_answer" if missing else "completed_scored",
            "model_no_answer_count": missing, "expected_model_terminals": n, "reported_model_terminals": n}


def execute(f):
    manifest, records, blobs, oracle = f
    mb, rb = a.dump(manifest), a.dump(records)
    return a.convert(mb, rb, blobs, oracle, pins={"manifest_sha256": a.sha(mb), "records_sha256": a.sha(rb), "oracle_sha256": a.sha(oracle)})


def repin(f, row):
    record = next(r for r in f[1]["records"] if r["logical_id"] == row["logical_id"])
    record["source_sha256"] = {p: a.sha(f[2][p]) for p in a.required_paths(row) if p in f[2]}
    return record


def missing(f, row, index=0):
    blobs, scenario = f[2], row["scenario"]
    unknown = scenario == "tuning"
    path = row["agent_artifacts"][index]
    original = a.load(blobs[path])
    agent = original.get("outcome", original)
    agent.update(answer=None, scoring_input=None if unknown else "", score_status="unscorable_missing_configuration" if unknown else "scored_empty_prediction",
                 answer_perf=None if unknown else .0, answer_metrics=None if scenario != "evidence_audit" else {"label_acc": .0, "evidence_acc": .0, "verification_eff": None},
                 terminal_status=status(1, 1, unknown))
    agent["score_check"] = {"ok": False, "reason": "unscorable_missing_configuration", "score_complete": False} if unknown else {"ok": True}
    if "outcome" in original:
        agent["score"] = {"metrics": agent["answer_metrics"], "primary_metric": "evidence_acc"} if scenario == "evidence_audit" else {"value": agent["answer_perf"]}
        agent["validation"] = {"passed": not unknown, "method": "explicit_model_terminal_unscored" if unknown else "repository_score_recompute"}
    blobs[path] = a.dump(original)
    if row["system"] == "poolact":
        payload = a.load(blobs[row["result_artifact"]])
        payload["agent_results"][index] = agent
        payload["terminal_status"] = status(1, 4, unknown)
        payload["aggregate"]["terminal_status"] = status(1, 4, unknown)
        if unknown:
            payload["aggregate"].update(answer=None, answer_perf=None, answer_metrics=None)
        blobs[row["result_artifact"]] = a.dump(payload)
    repin(f, row)


class AnalysisTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base = fixture()
        cls.good = execute(cls.base)

    def test_full_two_model_mixed_success_render(self):
        r = self.good
        self.assertEqual((len(r["rows"]), len(r["effects"]), len(r["raw_terminals"])), (15374, 1028, 3762))
        self.assertEqual(sum(e["role"] == "primary" for e in r["effects"]), 12)
        self.assertTrue(r["provenance"]["execution_complete"])
        self.assertEqual(r["provenance"]["fresh_post_analysis_audit"], "pending")
        files = a.render(r)
        self.assertEqual(len(files), 10)
        index = a.load(files["OUTPUT_INDEX.json"])
        self.assertTrue(all(a.sha(files[p]) == ref["sha256"] for p, ref in index["files"].items()))
        self.assertEqual(len(files["metrics.csv"].splitlines()), 15375)

    def test_all_negative_zero_unknown_not_selected_away(self):
        effects = self.good["effects"]
        self.assertTrue(any(e["effect"] < 0 for e in effects))
        self.assertTrue(any(e["effect"] == 0 for e in effects))
        self.assertTrue(all(e["ci"] is None and e["p_value"] is None for e in effects))
        self.assertTrue(all(e["n_outer_repeats"] == (3 if e["scenario"] == "tuning" else 1) for e in effects))

    def test_r1_null_r3_descriptive_sd(self):
        self.assertTrue(all(e["outerrep_descriptive_sd"] is None for e in self.good["effects"] if e["scenario"] != "tuning"))
        self.assertTrue(all(e["outerrep_descriptive_sd"] is not None for e in self.good["effects"] if e["scenario"] == "tuning"))

    def test_audit_doc_mean_and_three_source_hashes(self):
        body = next(b for b in self.good["derived_artifacts"].values() if b["unit"] == "document_outerrep")
        self.assertAlmostEqual(body["metrics"]["evidence_acc"], .4)
        self.assertEqual({c["order"] for c in body["components"]}, {0, 1, 2})
        self.assertEqual(len({next(iter(c["source_sha256"])) for c in body["components"]}), 3)
        self.assertTrue(all(c["source_sha256"] for c in body["components"]))

    def test_audit_missing_order_not_available_case_mean(self):
        f = copy.deepcopy(self.base)
        row = next(r for r in f[0]["logical_rows"] if r["system"] == "expgym" and r["order"] == 1)
        record = next(r for r in f[1]["records"] if r["logical_id"] == row["logical_id"])
        record.update(state="infrastructure_error", reason="synthetic transport failure", source_sha256={})
        del f[2][row["result_artifact"]]
        result = execute(f)
        body = next(b for b in result["derived_artifacts"].values() if row["logical_id"] in {c["logical_id"] for c in b["components"]})
        self.assertIsNone(body["metrics"]["evidence_acc"])
        self.assertFalse(result["provenance"]["execution_complete"])
        self.assertEqual(len(result["effects"]), 1028)

    def test_search_missing_answer_preserved_separate_empty_projection(self):
        f = copy.deepcopy(self.base)
        row = next(r for r in f[0]["logical_rows"] if r["system"] == "expgym" and r["scenario"] == "restricted_search")
        missing(f, row)
        result = execute(f)
        raw = next(r for r in result["raw_terminals"] if r["logical_id"] == row["logical_id"])
        self.assertIsNone(raw["raw_answer"])
        self.assertEqual(raw["scoring_input"], "")
        self.assertEqual(raw["score_status"], "scored_empty_prediction")
        self.assertEqual(result["provenance"]["raw_model_no_answer_count"], 1)

    def test_empty_prediction_not_hardcoded_zero(self):
        f = copy.deepcopy(self.base)
        row = next(r for r in f[0]["logical_rows"] if r["system"] == "expgym" and r["scenario"] == "restricted_search")
        missing(f, row)
        payload = a.load(f[2][row["result_artifact"]])
        payload["outcome"]["score"]["value"] = 1.
        f[2][row["result_artifact"]] = a.dump(payload)
        repin(f, row)
        result = execute(f)
        body = next(b for b in result["derived_artifacts"].values() if row["logical_id"] == b["components"][0]["logical_id"])
        self.assertEqual(body["metrics"]["f1"], 1.)

    def test_missing_nas_full_endpoints_unknown_known_subset_retained(self):
        f = copy.deepcopy(self.base)
        row = next(r for r in f[0]["logical_rows"] if r["system"] == "poolact" and r["scenario"] == "tuning")
        missing(f, row)
        result = execute(f)
        body = next(b for b in result["derived_artifacts"].values() if row["logical_id"] == b["components"][0]["logical_id"])
        self.assertTrue(all(body["metrics"][k] is None for k in ("gap_mi", "gap_bon", "raw_perf_mi", "raw_perf_bon")))
        subset = next(s for s in result["known_subsets"] if s["logical_id"] == row["logical_id"])
        self.assertEqual((subset["n_known"], subset["n_total"]), (3, 4))
        self.assertTrue(subset["not_full_pool_endpoint"])
        self.assertTrue(result["provenance"]["execution_complete"])
        self.assertEqual(result["provenance"]["logical_score_states"]["unknown"], 1)

    def test_gap_clip_before_mean(self):
        subset = next(s for s in self.good["known_subsets"] if s["system"] == "poolact" and s["outerseed"] == "outer_00000")
        self.assertAlmostEqual(subset["mean_clipped_gap"], statistics.mean([0, 100 / 3, 100, 500 / 3]))
        self.assertNotAlmostEqual(subset["mean_clipped_gap"], max(0, 100 * (statistics.mean([.2, .6, .8, 1.]) - .5) / .3))

    def test_missing_extra_duplicate_record_rejected(self):
        for operation in (lambda r: r.pop(), lambda r: r.append(copy.deepcopy(r[0]))):
            f = copy.deepcopy(self.base)
            operation(f[1]["records"])
            with self.assertRaises(ValueError):
                execute(f)

    def test_exp_cross_row_agent_swap_rejected_with_refreshed_manifest_pin(self):
        f = copy.deepcopy(self.base)
        free = next(r for r in f[0]["logical_rows"] if r["model"] == "m0" and r["system"] == "expgym" and r["scenario"] == "restricted_search" and r["regime"] == "cost_free")
        tight = next(r for r in f[0]["logical_rows"] if r["model"] == free["model"] and r["system"] == "expgym" and r["item"] == free["item"] and r["regime"] == "cost_tight")
        free["agent_artifacts"], tight["agent_artifacts"] = tight["agent_artifacts"], free["agent_artifacts"]
        f[1]["manifest_sha256"] = a.sha(a.dump(f[0]))
        with self.assertRaisesRegex(ValueError, "Exp single-agent path"):
            execute(f)

    def test_exp_project_uses_bound_result_even_without_manifest_validator(self):
        f = copy.deepcopy(self.base)
        free = next(r for r in f[0]["logical_rows"] if r["model"] == "m0" and r["system"] == "expgym" and r["scenario"] == "restricted_search" and r["regime"] == "cost_free")
        tight = next(r for r in f[0]["logical_rows"] if r["model"] == free["model"] and r["system"] == "expgym" and r["item"] == free["item"] and r["regime"] == "cost_tight")
        free["agent_artifacts"] = tight["agent_artifacts"]
        record = next(r for r in f[1]["records"] if r["logical_id"] == free["logical_id"])
        values, raw, _ = a.project(free, record, f[2], a.load(f[3])["tasks"], a.catalogue())
        self.assertEqual(values["f1"], .6)
        self.assertEqual(raw[0]["original_terminal"]["answer_perf"], .6)
        self.assertEqual(list(record["source_sha256"]), [free["result_artifact"]])

    def test_wrong_repeat_or_outer_rejected(self):
        f = copy.deepcopy(self.base)
        f[0]["repeat_policy"]["expgym"]["restricted_search"] = 3
        with self.assertRaises(ValueError):
            execute(f)

    def test_original_blob_mutation_rejected(self):
        f = copy.deepcopy(self.base)
        path = next(iter(f[2]))
        f[2][path] += b" "
        with self.assertRaises(ValueError):
            execute(f)

    def test_synthetic_zero_for_hpo_missing_rejected(self):
        f = copy.deepcopy(self.base)
        row = next(r for r in f[0]["logical_rows"] if r["system"] == "expgym" and r["scenario"] == "tuning")
        missing(f, row)
        payload = a.load(f[2][row["result_artifact"]])
        payload["outcome"]["score"]["value"] = 0
        f[2][row["result_artifact"]] = a.dump(payload)
        repin(f, row)
        with self.assertRaises(ValueError):
            execute(f)

    def test_embedded_pool_agent_disagreement_rejected(self):
        f = copy.deepcopy(self.base)
        row = next(r for r in f[0]["logical_rows"] if r["system"] == "poolact")
        payload = a.load(f[2][row["result_artifact"]])
        payload["agent_results"][0]["answer"] = "different"
        f[2][row["result_artifact"]] = a.dump(payload)
        repin(f, row)
        with self.assertRaises(ValueError):
            execute(f)

    def test_cost_once_per_logical_not_comparison_or_pool_agent(self):
        cost = self.good["cost_coverage"]["m0"]
        self.assertEqual(cost["input_tokens"]["total"], 78300)
        self.assertEqual(cost["output_tokens"]["total"], 39150)
        self.assertEqual(cost["reasoning_tokens_included_in_output"]["total"], 31320)

    def test_unknown_usage_retains_known_cost_subset_not_fake_total(self):
        f = copy.deepcopy(self.base)
        rec = f[1]["records"][0]
        rec["telemetry"]["output_tokens"] = None
        rec["telemetry_unknown_reasons"] = {"output_tokens": "usage not reported"}
        result = execute(f)
        cost = result["cost_coverage"]["m0"]["output_tokens"]
        self.assertIsNone(cost["total"])
        self.assertEqual(cost["known_subset_total_not_complete"], 39100)

    def test_no_network_and_no_scorer_import(self):
        real_import = builtins.__import__
        def allowed_import(name, *args, **kwargs):
            if name.split(".")[0] in {"expgym", "sglang", "torch", "hpobench", "toy_tuning", "toy_audit", "toy_search"}:
                raise AssertionError("runner/scorer/model import forbidden: " + name)
            return real_import(name, *args, **kwargs)
        with mock.patch.object(socket, "socket", side_effect=AssertionError("network forbidden")), mock.patch.object(builtins, "__import__", side_effect=allowed_import):
            result = execute(self.base)
        self.assertFalse(result["provenance"]["score_recomputed"])
        self.assertFalse(result["provenance"]["confirmatory_inference"])

    def test_all_not_started_keeps_full_unknown_matrix(self):
        f = copy.deepcopy(self.base)
        f[2].clear()
        for record in f[1]["records"]:
            record.update(state="not_started", reason="synthetic not launched", source_sha256={})
            record["telemetry"] = {k: None for k in record["telemetry"]}
            record["telemetry_unknown_reasons"] = {k: "not observed" for k in record["telemetry"]}
            record["reasoning_tokens"] = None
        result = execute(f)
        self.assertEqual(len(result["effects"]), 1028)
        self.assertTrue(all(e["effect"] is None and e["outerrep_descriptive_sd"] is None for e in result["effects"]))
        self.assertEqual(result["provenance"]["logical_score_states"], {"not_started": 1566})
        # Empty known-subset table still renders with a declared schema.
        files = a.render(result)
        self.assertIn("logical_outcomes.csv", files)

    def test_integrity_error_not_silently_model_missing(self):
        f = copy.deepcopy(self.base)
        record = f[1]["records"][0]
        record.update(state="integrity_error", reason="synthetic independent checksum failure")
        result = execute(f)
        self.assertEqual(result["provenance"]["logical_score_states"]["error"], 1)
        self.assertEqual(result["provenance"]["raw_model_no_answer_count"], 0)

    def test_outerrep_sd_is_full_bundle_not_agent_or_item_sd(self):
        f = copy.deepcopy(self.base)
        for row in f[0]["logical_rows"]:
            if row["model"] == "m0" and row["system"] == "expgym" and row["scenario"] == "tuning" and row["regime"] == "cost_tight":
                payload = a.load(f[2][row["result_artifact"]])
                payload["outcome"]["score"]["value"] = [.55, .6, .8][row["outerrep"]]
                f[2][row["result_artifact"]] = a.dump(payload)
                repin(f, row)
        result = execute(f)
        e = next(e for e in result["effects"] if e["comparison"] == "m0__E-H")
        expected = [100 * (x - y) / .3 for x, y in zip([.6, .63, .66], [.55, .6, .8])]
        self.assertAlmostEqual(e["outerrep_descriptive_sd"], statistics.stdev(expected))
        self.assertEqual(e["n_outer_repeats"], 3)
        self.assertEqual(e["n_pairs_descriptive_not_independent_n"], 27)

    def test_actual_cli_fresh_file_export_success_then_refuses_overwrite(self):
        manifest, records, blobs, oracle = fixture(models=1)
        mb, rb = a.dump(manifest), a.dump(records)
        pins = {"manifest_sha256": a.sha(mb), "records_sha256": a.sha(rb), "oracle_sha256": a.sha(oracle)}
        with tempfile.TemporaryDirectory(prefix="synthetic-mixed-analysis-") as tmp:
            root = Path(tmp)
            source_index = {}
            for index, (logical, blob) in enumerate(blobs.items()):
                path = root / ("source_" + str(index) + ".json")
                path.write_bytes(blob)
                source_index[logical] = str(path)
            args = ["analysis.py"]
            for name, value in (("manifest", mb), ("records", rb), ("oracle", oracle), ("pins", a.dump(pins)), ("source-index", a.dump(source_index))):
                path = root / (name + ".json")
                path.write_bytes(value)
                args += ["--" + name, str(path)]
            output = root / "fresh-export"
            args += ["--output-dir", str(output)]
            with mock.patch.object(sys, "argv", args), mock.patch.object(socket, "socket", side_effect=AssertionError("no network")), contextlib.redirect_stdout(io.StringIO()):
                a.main()
                first = {p.name: a.sha(p.read_bytes()) for p in output.iterdir()}
                with self.assertRaises(ValueError):
                    a.main()
            self.assertEqual(first, {p.name: a.sha(p.read_bytes()) for p in output.iterdir()})
            self.assertEqual(len(first), 10)
            self.assertEqual(a.load((output / "provenance.json").read_bytes())["comparisons"], 514)

    def test_legacy_trace_schema_cannot_claim_new_terminal_policy(self):
        f = copy.deepcopy(self.base)
        row = f[0]["logical_rows"][0]
        payload = a.load(f[2][row["result_artifact"]])
        payload["schema"]["version"] = "2.0.0"
        f[2][row["result_artifact"]] = a.dump(payload)
        repin(f, row)
        with self.assertRaises(ValueError):
            execute(f)


if __name__ == "__main__":
    unittest.main()
