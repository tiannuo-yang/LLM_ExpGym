#!/usr/bin/env python3
"""One real independent usage review; capture real CLI status, never retry."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys

HERE = Path(__file__).resolve().parent
PROGRAM = HERE / 'review_usage.py'
PROGRAM_SHA = '9be66561689643e3ab01a8f814f2c8e9cf08e8a2293c152e7249cbac1d1433c9'
ARGV = ['/lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python', '-B', str(PROGRAM), '--actual-output', str(HERE/'actual_v1')]


def write(name, data):
    with (HERE/name).open('x') as handle:
        json.dump(data, handle, sort_keys=True, separators=(',', ':'))
        handle.write('\n'); handle.flush(); os.fsync(handle.fileno())


resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
assert hashlib.sha256(PROGRAM.read_bytes()).hexdigest() == PROGRAM_SHA
assert not (HERE/'actual_v1').exists() and not (HERE/'actual_v1').is_symlink()
write('STARTED.json', dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), operator_pid=os.getpid(), argv=ARGV,
      program_sha256=PROGRAM_SHA, invocation_limit=1, retry=False, core_limit=[0, 0]))
with (HERE/'actual.stdout.log').open('xb') as stdout, (HERE/'actual.stderr.log').open('xb') as stderr:
    child = subprocess.Popen(ARGV, stdout=stdout, stderr=stderr)
    write('CHILD_STARTED.json', dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), pid=child.pid, argv=ARGV))
    code = child.wait()
write('CLI_EXIT.json', dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), pid=child.pid, actual_exit_code=code, argv=ARGV,
      program_sha256_after=hashlib.sha256(PROGRAM.read_bytes()).hexdigest()))
print(json.dumps(dict(actual_usage_review_exit_code=code)), flush=True)
sys.exit(code)
