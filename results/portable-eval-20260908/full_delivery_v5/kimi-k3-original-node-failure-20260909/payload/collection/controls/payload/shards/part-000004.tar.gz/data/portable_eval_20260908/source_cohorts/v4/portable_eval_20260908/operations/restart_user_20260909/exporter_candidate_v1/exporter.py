#!/usr/bin/env python3
"""Explicit closed restart artifacts -> frozen mixed-R analysis. No scoring/API."""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
import os
from pathlib import Path
import stat
import types

HERE = Path(__file__).resolve().parent
ANALYSIS = HERE.parent / "analysis_candidate_v2/analysis.py"
ANALYSIS_SHA = "5df8525973261d61b5c3c373945129db22979131e6ce3b586c8913efeed256bf"
PRODUCERS = {"launcher.py":"c934c6234619cc35c8ce2e19710f69fbd8ce931bcda7bf2f7d745f5a78511a41",
             "wire.py":"bac690bc5976dad609e4544e10d0e2b31596b8cb34e996ca721ce878b4e4e52f",
             "evidence.py":"077979bc9c4f403750b7d99173a0ac4579876b0c23dfb00d6eb526fa066f4968",
             "dispatch.py":"e9d2984b41aece5bf78ba2ef01816dc52fa95d83d8d5babf2866bbcee0e594aa",
             "support.py":"68fe53445cd1cbff348f004cb578fa91957c33d46a180244bbeb97cf6e3df030",
             "planner.py":"7f4ff5dcdc16ecf3292a74dae5683c2e54892ed94fd126f625faa8a8d0591724"}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(blob):
    return hashlib.sha256(blob).hexdigest()


def dump(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()


def load(blob):
    def unique(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate JSON key")
            result[key] = value
        return result
    return json.loads(blob, object_pairs_hook=unique, parse_constant=lambda _: (_ for _ in ()).throw(ValueError("nonfinite JSON")))


def analyzer():
    source = ANALYSIS.read_bytes()
    require(sha(source) == ANALYSIS_SHA, "frozen analysis adapter changed")
    ns = {"__file__": str(ANALYSIS), "__name__": "restart_export_frozen_analysis"}
    exec(compile(source, str(ANALYSIS), "exec"), ns)
    return types.SimpleNamespace(**ns)


def finite(value, label):
    require(type(value) in (int, float) and math.isfinite(value) and value >= 0, "invalid " + label)
    return value


def under(path, root):
    p, r = Path(path), Path(root)
    require(p.is_absolute() and ".." not in p.parts and r in p.parents, "path outside declared original root")
    return str(p)


class Reader:
    """One read/hash/parse snapshot, no directory discovery and no code execution."""
    def __init__(self, read=None, max_file_bytes=1024**3, max_total_bytes=32*1024**3):
        self.read = read or self.disk
        self.max_file_bytes, self.max_total_bytes = max_file_bytes, max_total_bytes
        self.blobs, self.refs, self.total = {}, {}, 0

    def disk(self, path):
        p = Path(path)
        require(p.is_absolute() and ".." not in p.parts, "absolute lexical source path required")
        before = p.lstat()
        require(stat.S_ISREG(before.st_mode) and before.st_size <= self.max_file_bytes, "nonregular/oversized source file")
        fd = os.open(str(p), os.O_RDONLY | os.O_NOFOLLOW)
        try:
            opened = os.fstat(fd)
            require((before.st_dev, before.st_ino) == (opened.st_dev, opened.st_ino), "source changed before open")
            with os.fdopen(fd, "rb", closefd=False) as stream:
                blob = stream.read(self.max_file_bytes + 1)
            after = os.fstat(fd)
            signature = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns)
            require(signature(before) == signature(after) == signature(p.lstat()), "source changed during read")
            return blob
        finally:
            os.close(fd)

    def ref(self, ref, root=None):
        require(type(ref) is dict and set(ref) in ({"path", "sha256"}, {"path", "sha256", "bytes"}, {"path", "sha256", "bytes", "mtime_ns", "kind"}), "unsupported source ref")
        path = ref["path"]
        require(isinstance(path, str) and Path(path).is_absolute() and ".." not in Path(path).parts, "invalid original path")
        if root is not None:
            under(path, root)
        if path not in self.blobs:
            blob = self.read(path)
            require(type(blob) is bytes and len(blob) <= self.max_file_bytes, "source exceeds explicit per-file ceiling")
            self.total += len(blob)
            require(self.total <= self.max_total_bytes, "source inventory exceeds explicit memory ceiling")
            self.blobs[path] = blob
        blob = self.blobs[path]
        require(sha(blob) == ref["sha256"] and ("bytes" not in ref or ref["bytes"] == len(blob)), "original byte pin mismatch")
        normalized = {"path": path, "sha256": sha(blob), "bytes": len(blob)}
        require(path not in self.refs or self.refs[path] == normalized, "conflicting ref")
        self.refs[path] = normalized
        return blob

    def observed(self, path, root):
        """Hash a specifically named terminal, then bind its content to execution."""
        under(path, root)
        if path not in self.blobs:
            blob = self.read(path)
            require(type(blob) is bytes and len(blob) <= self.max_file_bytes, "observed source exceeds ceiling")
            self.total += len(blob)
            require(self.total <= self.max_total_bytes, "source inventory exceeds explicit memory ceiling")
            self.blobs[path] = blob
        return self.ref({"path": path, "sha256": sha(self.blobs[path])}, root)


def verify_resume(value, iid):
    require(value.get("schema_version") == "restart-source-verified-resume-v1" and value.get("invocation_id") == iid,
            "wrong original source resume receipt")
    require(type(value.get("source_exit_code")) is int and value["source_exit_code"] == 0
            and value.get("passed") is True and value.get("model_calls_forbidden") is True
            and value.get("independent_source_cli_resume") is True
            and dump(value.get("forbidden_model_attempts")) == dump({"construction": 0, "generation": 0})
            and value.get("artifact_bytes_verified_by_this_helper") is False,
            "no successful original CLI no-model recomputation evidence")


def action(name, argument):
    require(isinstance(name, str) and isinstance(argument, str), "raw tool action must be retained")
    try:
        return name, "json", dump(load(argument))
    except (ValueError, TypeError, RecursionError):
        return name, "raw", argument


def agent_telemetry(original, *, pool, expected_seed, run_id):
    """Only original persisted numeric/timing/attempt fields, not model content."""
    if pool:
        metadata, seed = original["api_dump"], original["seed"]
        actions = [action(t[0], t[1]) for t in original["tool_records"]]
        require(original["evaluations"] == len(actions), "Pool evaluation/tool count differs")
        cost = finite(original["total_overhead"], "Pool total overhead")
        require(math.isclose(cost, finite(original["eval_time"], "Pool eval time"), rel_tol=1e-9, abs_tol=1e-9), "Pool simulated costs differ")
        calls = original["usage_attempts"]
        require([v["llm_call_index"] for v in calls] == list(range(1, original["api_calls"] + 1)), "Pool call ledger order differs")
        attempts = [v for call in calls for v in call["attempts"]]
        failures = original["protocol_failures"]
        expected_attempts = original["http_request_attempts"]
        wall = finite(original["wall_time_seconds"], "agent wall")
        visible = 0 if not actions else None
    else:
        require(original["schema"] == {"name": "expgym.trace", "version": "2.1.0"}, "new Exp schema required")
        metadata, seed = original["run"]["api_dump"], original["run"]["seed"]
        tools, calls = original["tool_calls"], original["llm_calls"]
        actions = [action(t["name"], t["raw_arguments"]) for t in tools]
        require(all(type(t["visible_to_model"]) is bool for t in tools), "Exp exact visibility missing")
        visible = sum(t["visible_to_model"] for t in tools)
        cost = finite(original["timing"]["total_simulated_cost_seconds"], "Exp overhead")
        require(math.isclose(cost, sum(finite(t["simulated_cost_seconds"], "tool cost") for t in tools), rel_tol=1e-9, abs_tol=1e-9), "Exp tool/runtime costs differ")
        attempts = [v for call in calls for v in call["attempt_usage"]]
        failures = original["outcome"]["protocol_failures"]
        expected_attempts = original["outcome"]["http_request_attempts"]
        wall = finite(original["timing"]["wall_time_seconds"], "Exp per-order wall")
    require(type(seed) is int and seed == expected_seed and metadata["run_id"] == run_id, "agent run/seed differs")
    require(metadata["schema_version"] == "expgym.api_attempt.v1" and isinstance(metadata["client_id"], str), "missing original client identity")
    require(len(attempts) == expected_attempts and len({v["request_id"] for v in attempts}) == len(attempts), "attempt ledger incomplete/duplicate")
    require(type(failures) is list and all(type(v.get("llm_call_index")) is int and 1 <= v["llm_call_index"] <= len(calls) for v in failures)
            and len({v["llm_call_index"] for v in failures}) == len(failures), "protocol failures do not match logical calls")
    return {"client_id": metadata["client_id"], "seed": seed, "attempts": attempts, "actions": actions,
            "cost": cost, "visible": visible, "wall": wall, "failures": len(failures), "calls": len(calls)}


def usage(raws):
    fields = {"input_tokens": ("prompt_tokens",), "output_tokens": ("completion_tokens",), "reasoning_tokens": ("completion_tokens_details", "reasoning_tokens")}
    result = {}
    for name, path in fields.items():
        known, missing = [], 0
        for raw in raws:
            value = (raw.get("response_json") or {}).get("usage") if type(raw.get("response_json")) is dict else None
            for key in path:
                value = value.get(key) if type(value) is dict else None
            if type(value) is int and value >= 0:
                known.append(value)
            else:
                missing += 1
        result[name] = {"complete_total": sum(known) if missing == 0 else None, "known_sum": sum(known), "unknown_attempts": missing, "attempts": len(raws)}
    if result["reasoning_tokens"]["complete_total"] is not None and result["output_tokens"]["complete_total"] is not None:
        require(result["reasoning_tokens"]["complete_total"] <= result["output_tokens"]["complete_total"], "reasoning exceeds inclusive output")
    return result


def job_inputs(plan, job, wrapped, reader):
    report = wrapped["report"]
    iid, root = job["invocation_id"], plan["config"]["output_root"]
    require(wrapped["invocation_id"] == report["invocation_id"] == iid, "job/report identity mismatch")
    terminal_blob = reader.observed(str(Path(job["log_dir"]) / "terminal.json"), root)
    terminal = load(terminal_blob)
    require(set(terminal) == {"invocation_id", "decision", "report", "recorded_at_utc"}, "unexpected physical job terminal schema")
    require(all(dump(terminal[k]) == dump(wrapped[k]) for k in ("invocation_id", "decision", "report")), "physical job terminal differs from execution")
    success = wrapped["decision"].get("continue") is True
    artifacts = report["artifacts"] if success else report.get("preserved_artifacts", [])
    require(len({r["path"] for r in artifacts}) == len(artifacts), "duplicate artifact ref")
    require(set(r["path"] for r in artifacts) == set(job["expected_files"]) if success else set(r["path"] for r in artifacts) <= set(job["expected_files"]), "planned result inventory differs")
    for ref in artifacts:
        reader.ref(ref, job["output_dir"])
    evidence_refs = report.get("original_terminal_evidence", report.get("preserved_terminal_evidence", []))
    for ref in evidence_refs + report.get("verification_terminal_evidence", []):
        reader.ref(ref, root)
    if success:
        require(all(report.get(k) is True for k in ("execution_evidence_complete", "artifact_integrity_complete", "raw_integrity_complete", "source_identity_valid", "runtime_identity_valid")), "complete execution evidence fields missing")
        require(report.get("source_capture", {}).get("exit_code") == 0 and report["source_capture"].get("drain_proven") is True, "source process not closed")
        capture = report["source_capture"]
        require(all(capture.get(k) is True for k in ("capture_complete", "child_started", "stdout_eof_observed", "wait_returned")), "source capture process evidence incomplete")
        reader.ref({"path":capture["log"],"sha256":capture["sha256"]}, job["log_dir"])
        verify_resume(load(reader.ref(report["verified_resume_ref"], job["log_dir"])), iid)
        reader.observed(str(Path(job["log_dir"])/"verified_resume.log"), job["log_dir"])
        require(evidence_refs, "source terminal evidence absent")
        audit = load(reader.ref(report["raw_audit_ref"], job["log_dir"]))
        require(audit.get("schema_version") == "restart-raw-wire-audit-v1" and audit.get("verified") is True and audit.get("errors") == [], "raw/wire audit incomplete")
        inventory = audit["inventory"]
        require(len({r["path"] for r in inventory}) == len(inventory), "raw/wire inventory duplicate")
        for ref in inventory:
            require(ref["kind"] in ("raw", "wire"), "unknown raw audit inventory role")
            reader.ref(ref, job["dump_dir"] if ref["kind"] == "raw" else str(Path(job["log_dir"]) / "wire"))
        raw_refs = [r for r in inventory if r["kind"] == "raw"]
        require(audit["counts"]["raw_files"] == audit["counts"]["joined_attempts"] == len(raw_refs), "raw count/bijection differs")
    else:
        raw_refs = report.get("preserved_raw", [])
        for ref in raw_refs:
            reader.ref(ref, job["dump_dir"])
    raws = [load(reader.blobs[r["path"]]) for r in raw_refs]
    require(len({r["request_id"] for r in raws}) == len(raws), "raw request ID duplicate")
    for raw in raws:
        require(raw["run_id"] == plan["config"]["run_id"] and raw["request_payload"]["model"] == job["model_id"]
                and raw["request_payload"]["seed"] in job["sampling_seed_labels"], "raw outside exact run/model/seed")
    return success, artifacts, raw_refs, raws


def export(plan_ref, execution_ref, acceptance_ref, reader):
    """All selectors come from an explicit full compiled matrix; no discovery."""
    a = analyzer()
    catalogue = a.catalogue()
    plan, execution, accepted = [load(reader.ref(r)) for r in (plan_ref, execution_ref, acceptance_ref)]
    require(plan.get("schema_version") == "restart-executable-plan-v1" and plan.get("mode") == "formal_mixed", "smoke/CPU/other plans cannot be formal analysis")
    require(execution.get("schema_version") == "restart-bounded-study-execution-v1" and execution.get("local_workers") == 0
            and execution.get("plan_ref") == plan_ref and execution.get("run_id") == plan["config"]["run_id"] and execution.get("mode") == "formal_mixed", "closed same-plan execution required")
    config, matrix = plan["config"], plan["matrix"]
    a.validate_manifest(matrix, catalogue)
    # Pin the producers of no-model resume/raw/dispatch evidence without executing them.
    for name, digest in PRODUCERS.items():
        matches = [{"path":p,"sha256":h} for p,h in plan["file_bindings"].items() if Path(p).name == name and h == digest]
        require(len(matches) == 1, "frozen producer binding absent/ambiguous: " + name)
        reader.ref(matches[0])
    require(config["source_acceptance_ref"] == acceptance_ref and config["repo_root"] == accepted["repo_root"]
            and matrix["source_and_inputs"]["source_tree_sha256"] == accepted["source_tree_sha256"] and len(accepted["files"]) == 86, "source86 acceptance binding differs")
    for name, digest in accepted["files"].items():
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "unsafe source relative path")
        reader.ref({"path": str(Path(config["repo_root"]) / name), "sha256": digest}, config["repo_root"])
    for rel in ("expgym/trace_v2.py", "expgym/missing_final.py", "scripts/run_paper_sweep.py", "scripts/run_poolact.py"):
        require(rel in accepted["files"], "source acceptance missing scoring producer")
    jobs = {j["invocation_id"]: j for j in plan["jobs"]}
    require(matrix["models"] == [config["model"]] and matrix["candidate_id"] == config["run_id"], "single-model study identity differs")
    require(len(jobs) == len(plan["jobs"]) == len(matrix["invocations"]) == 705, "single-model full job count required")
    require(set(jobs) == {r["invocation_id"] for r in matrix["logical_rows"]}, "job/logical scope differs")
    require(len(set(execution["started_invocation_ids"])) == len(execution["started_invocation_ids"])
            and len(set(execution["unstarted_invocation_ids"])) == len(execution["unstarted_invocation_ids"]), "duplicate started/unstarted ID")
    require(set(execution["started_invocation_ids"]) | set(execution["unstarted_invocation_ids"]) == set(jobs)
            and not set(execution["started_invocation_ids"]) & set(execution["unstarted_invocation_ids"]), "started/unstarted partition differs")
    reports = {r["invocation_id"]: r for r in execution["reports"]}
    require(len(reports) == len(execution["reports"]) and set(reports) == set(execution["started_invocation_ids"]), "closed execution reports missing/duplicate")
    manifest_bytes = dump(matrix)
    records, sources, source_index, per_job = [], {}, {}, []
    claimed_raw = set()
    for iid, job in jobs.items():
        rows = [r for r in matrix["logical_rows"] if r["invocation_id"] == iid]
        require(set(job["logical_ids"]) == {r["logical_id"] for r in rows} and job["expected_files"] == [str(Path(config["output_root"]) / p) for p in matrix["expected_files"][iid]], "compiled result path mapping differs")
        if iid in reports:
            wrapped = dict(reports[iid])
            success, artifacts, raw_refs, raws = job_inputs(plan, job, wrapped, reader)
        else:
            wrapped, success, artifacts, raw_refs, raws = None, False, [], [], []
        artifact_map = {r["path"]: r for r in artifacts}
        owners = set()
        statuses = []
        for row in rows:
            telemetry = {k: None for k in catalogue.TELEMETRY}
            if row["regime"] != "cost_free":
                telemetry["budget_utilization"] = None
            record = {"logical_id": row["logical_id"], "state": "terminal" if success else "infrastructure_error" if wrapped else "not_started",
                      "reason": None if success else wrapped["report"].get("failure_code", "source_or_integrity_failure") if wrapped else "not_started",
                      "source_sha256": {}, "tuning_final_policy": config["policy"]["tuning_final_policy"], "telemetry": telemetry}
            for relative in a.required_paths(row):
                absolute = str(Path(config["output_root"]) / relative)
                if absolute in artifact_map:
                    record["source_sha256"][relative] = artifact_map[absolute]["sha256"]
                    sources[relative] = reader.blobs[absolute]
                    source_index[relative] = absolute
            owned_raw = [r for r in raws if r["request_payload"]["seed"] in row["sampling_seed_labels"]]
            if success:
                original = load(sources[row["result_artifact"]])
                pool = row["system"] == "poolact"
                statuses.append(original["terminal_status"] if pool else original["outcome"]["terminal_status"])
                originals = [load(sources[p]) for p in row["agent_artifacts"]] if pool else [original]
                facts = [agent_telemetry(v, pool=pool, expected_seed=seed, run_id=config["run_id"]) for v, seed in zip(originals, row["sampling_seed_labels"])]
                require(len(facts) == len(row["sampling_seed_labels"]) and len({v["client_id"] for v in facts}) == len(facts), "model terminal owner count differs")
                require(not owners & {v["client_id"] for v in facts}, "client reused across logical outcomes")
                owners.update(v["client_id"] for v in facts)
                by_request = {r["request_id"]: r for r in owned_raw}
                ledgers = [attempt for fact in facts for attempt in fact["attempts"]]
                require(len(ledgers) == len(by_request) and {v["request_id"] for v in ledgers} == set(by_request), "per-order/agent original attempt ledger/raw mismatch")
                for fact in facts:
                    for attempt in fact["attempts"]:
                        raw = by_request[attempt["request_id"]]
                        require(raw["client_id"] == fact["client_id"] and raw["request_payload"]["seed"] == fact["seed"]
                                and raw["generation_id"] == attempt["generation_id"] and raw["attempt"] == attempt["attempt"]
                                and raw["state"] == attempt["state"], "attempt owner/generation binding differs")
                actions = [action for fact in facts for action in fact["actions"]]
                cost = sum(v["cost"] for v in facts)
                visible = None if any(v["visible"] is None for v in facts) else sum(v["visible"] for v in facts)
                calls = sum(v["calls"] for v in facts)
                if pool:
                    require(original["config"]["agent_seeds"] == row["sampling_seed_labels"] and original["config"]["scenario"] == row["scenario"]
                            and original["config"]["cost_regime"] == row["regime"] and original["strategy"] == row["strategy"]
                            and original["config"]["model"] == row["model_id"], "Pool original identity differs")
                    for key in ("question_index", "data_source", "cc_split", "tuning_task"):
                        require(key not in row["selector"] or original["config"].get(key) == row["selector"][key], "Pool original selector differs")
                    budget = original["config"]["time_budget"]
                    budget = None if budget is None else len(facts) * finite(budget, "Pool budget")
                    # Closed source capture wall includes whole concurrent pool, not sum(agent wall).
                    wall = finite(wrapped["report"]["source_capture"]["elapsed_seconds"], "whole Pool source wall")
                else:
                    require(original["task"]["scenario"] == row["scenario"] and original["task"]["budget"]["regime"] == row["regime"]
                            and original["task"].get("hypothesis_order") == row["hypothesis_order"], "Exp original item/order budget differs")
                    require(original["run"]["model"]["id"] == row["model_id"]
                            and original["task"]["item"]["id"] == row["selector"].get("question_index",row["selector"].get("tuning_task"))
                            and original["task"]["rep"] == (row["order"] if row["scenario"] == "evidence_audit" else 0), "Exp original model/item/rep differs")
                    budget, wall = original["task"]["budget"]["limit_seconds"], facts[0]["wall"]
                telemetry.update(feedback_attempts=len(actions), feedback_visible=visible,
                    duplicate_action_attempts=len(actions)-len(set(actions)), feedback_cost_seconds=cost,
                    wall_time_seconds=wall, protocol_failure_rate=sum(v["failures"] for v in facts)/calls if calls else None)
                if row["regime"] != "cost_free":
                    require(budget is not None and finite(budget, "feedback budget") > 0, "budget missing")
                    telemetry["budget_utilization"] = cost/budget
            counts = usage(owned_raw)
            if wrapped:
                telemetry.update(input_tokens=counts["input_tokens"]["complete_total"], output_tokens=counts["output_tokens"]["complete_total"])
            record["reasoning_tokens"] = counts["reasoning_tokens"]["complete_total"] if wrapped else None
            record["telemetry_unknown_reasons"] = {k: "Pool original omits exact tool visibility" if k == "feedback_visible" and success else "unavailable original evidence or incomplete attempt usage" for k,v in telemetry.items() if v is None}
            record["telemetry_sidecar"] = {"attempt_usage": counts, "raw_request_ids": [r["request_id"] for r in owned_raw], "raw_source_sha256": {r["path"]:r["sha256"] for r in raw_refs if Path(r["path"]).stem in {v["request_id"] for v in owned_raw}}, "audit_orders_not_duplicated": True}
            ids = {r["request_id"] for r in owned_raw}
            require(not claimed_raw & ids, "raw charged to multiple logical outcomes")
            claimed_raw.update(ids)
            records.append(record)
        require({r["request_id"] for r in raws} <= claimed_raw, "unallocated raw attempts")
        if success:
            merged=dict(statuses[0])
            for name in ("model_no_answer_count","expected_model_terminals","reported_model_terminals"):
                merged[name]=sum(s[name] for s in statuses)
            merged.update(execution_complete=all(s["execution_complete"] for s in statuses),score_complete=all(s["score_complete"] for s in statuses),
                          terminal_classification="model_no_answer" if merged["model_no_answer_count"] else "completed_scored")
            require(dump(merged) == dump(wrapped["report"]["terminal_status"])
                    and wrapped["decision"]["classification"] == merged["terminal_classification"]
                    and wrapped["decision"]["score_complete"] is merged["score_complete"], "job/source aggregate terminal mismatch")
        per_job.append({"invocation_id": iid, "state": "verified_original_resume" if success else "error" if wrapped else "not_started", "raw_attempts":len(raws)})
    oracle_ref = matrix["source_and_inputs"]["files"]["hpo.oracle"]
    oracle_bytes = reader.ref({k:oracle_ref[k] for k in ("path","sha256")})
    records_bytes = dump({"schema_version":"restart-analysis-records-v1", "manifest_sha256":sha(manifest_bytes), "source_tree_sha256":accepted["source_tree_sha256"], "records":records})
    pins={"manifest_sha256":sha(manifest_bytes),"records_sha256":sha(records_bytes),"oracle_sha256":sha(oracle_bytes)}
    result=a.convert(manifest_bytes,records_bytes,sources,oracle_bytes,pins=pins)
    evidence={"schema_version":"restart-real-export-evidence-v1","plan_ref":plan_ref,"execution_ref":execution_ref,"source_acceptance_ref":acceptance_ref,
        "exporter_sha256":sha(Path(__file__).read_bytes()),"analysis_sha256":ANALYSIS_SHA,"original_refs":list(reader.refs.values()),"jobs":per_job,
        "logical_records":len(records),"unique_raw_attempts":len(claimed_raw),"model_calls":0,"scorer_calls":0,
        "score_basis":"externally pinned original CLI --resume with model construction/generation forbidden; same algorithm, not independent scoring implementation",
        "fresh_post_analysis_audit":"pending","actual_provider_quiescence_proven":False}
    files=a.render(result)
    files.update({"records.json":records_bytes,"manifest.json":manifest_bytes,"input_pins.json":dump(pins),"oracle.json":oracle_bytes,"source_index.json":dump(source_index),"EXPORT_EVIDENCE.json":dump(evidence)})
    # The analyzer's index covers its ten-file product only; exporter index covers both products.
    files["EXPORT_INDEX.json"]=dump({"files":{p:{"sha256":sha(b),"bytes":len(b)} for p,b in files.items()},"fresh_post_analysis_audit":"pending"})
    return files,evidence


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ("plan","execution","source-acceptance"):
        parser.add_argument("--"+name,required=True)
        parser.add_argument("--"+name+"-sha256",required=True)
    parser.add_argument("--output-dir",required=True,type=Path)
    args=parser.parse_args()
    refs=[{"path":getattr(args,n),"sha256":getattr(args,n+"_sha256")} for n in ("plan","execution","source_acceptance")]
    require(not args.output_dir.exists(),"fresh exporter output directory required")
    files,evidence=export(*refs,Reader())
    args.output_dir.mkdir(parents=True,exist_ok=False)
    for name,blob in files.items():
        with (args.output_dir/name).open("xb") as stream: stream.write(blob)
    print(json.dumps({"logical_records":evidence["logical_records"],"unique_raw_attempts":evidence["unique_raw_attempts"],"fresh_post_analysis_audit":"pending"}))


if __name__=="__main__":
    main()
