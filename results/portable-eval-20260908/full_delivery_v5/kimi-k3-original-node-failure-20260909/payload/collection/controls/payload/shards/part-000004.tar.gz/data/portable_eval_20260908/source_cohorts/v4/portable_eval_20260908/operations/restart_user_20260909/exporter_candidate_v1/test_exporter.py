"""Synthetic complete matrix + preserved CPU source fixtures, never a real run."""
import contextlib
import copy
import importlib.util
import io
import json
from pathlib import Path
import socket
import sys
import tempfile
import unittest
from unittest import mock

import exporter as e


def fixture_helpers():
    directory = e.HERE.parent / "analysis_candidate_v2"
    spec = importlib.util.spec_from_file_location("export_fixture_analysis", directory / "analysis.py")
    analysis = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(analysis)
    with mock.patch.dict(sys.modules, {"analysis": analysis}):
        spec = importlib.util.spec_from_file_location("export_fixture_helper", directory / "test_analysis.py")
        helper = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(helper)
    return helper


def fixture(base="/synthetic-export-fixture"):
    h = fixture_helpers()
    manifest, bundle, originals, oracle = h.fixture(models=1)
    base = Path(base)
    root, repo = base / "run", base / "repo"
    manifest["source_and_inputs"]["files"]["hpo.oracle"]["path"] = str(base / "oracle.json")
    blobs = {str(base / "oracle.json"): oracle}
    def put(path, value):
        blob = value if isinstance(value, bytes) else e.dump(value)
        blobs[str(path)] = blob
        return {"path":str(path),"sha256":e.sha(blob)}
    names = ["expgym/trace_v2.py", "expgym/missing_final.py", "scripts/run_paper_sweep.py", "scripts/run_poolact.py"] + ["synthetic_%02d.py" % i for i in range(82)]
    source_files = {name: put(repo/name, ("# synthetic "+name).encode())["sha256"] for name in names}
    producer_bindings={}
    for name,expected in e.PRODUCERS.items():
        code=(e.HERE.parent/"planner_candidate_v1"/name).read_bytes()
        if e.sha(code)!=expected: raise ValueError("fixture producer source changed")
        ref=put(base/"producer"/name,code);producer_bindings[ref["path"]]=ref["sha256"]
    acceptance = {"classification":"synthetic fixture only", "repo_root":str(repo), "source_tree_sha256":manifest["source_and_inputs"]["source_tree_sha256"], "files":source_files}
    acceptance_ref = put(base / "acceptance.json", acceptance)
    config = {"run_id":manifest["candidate_id"],"output_root":str(root),"repo_root":str(repo),"model":manifest["models"][0],
              "source_acceptance_ref":acceptance_ref,"policy":{"tuning_final_policy":"legacy"}}
    selected = {}
    for scenario, system in (("restricted_search","expgym"),("evidence_audit","expgym"),("tuning","expgym"),("tuning","poolact")):
        row=next(r for r in manifest["logical_rows"] if r["scenario"]==scenario and r["system"]==system and r["regime"]=="cost_tight")
        selected[row["invocation_id"]]=(scenario,system)
        if scenario=="tuning" and system=="expgym": h.missing((manifest,bundle,originals,oracle),row)
    jobs,reports=[],[]
    counter=0
    for invocation in manifest["invocations"]:
        iid=invocation["invocation_id"]
        rows=[r for r in manifest["logical_rows"] if r["invocation_id"]==iid]
        job={**invocation,"model_id":config["model"]["model_id"],"sampling_seed_labels":sorted({s for r in rows for s in r["sampling_seed_labels"]}),
             "expected_files":[str(root/p) for p in manifest["expected_files"][iid]],"output_dir":str(root/invocation["output_relative_dir"]),
             "log_dir":str(root/"logs"/iid),"dump_dir":str(root/"dumps"/iid)}
        jobs.append(job)
        if iid not in selected: continue
        inventory=[]
        statuses=[]
        for row in rows:
            pool=row["system"]=="poolact"
            payload=e.load(originals[row["result_artifact"]])
            agents=[e.load(originals[p]) for p in row["agent_artifacts"]] if pool else [payload]
            for index,(agent,seed) in enumerate(zip(agents,row["sampling_seed_labels"])):
                counter+=1
                rid,cid,gid=[e.sha((str(counter)+t).encode())[:32] for t in ("r","c","g")]
                order=row["order"] if type(row["order"]) is int else 0
                inp=11*(order+1) if row["scenario"]=="evidence_audit" else 10+index
                usage={"prompt_tokens":inp,"completion_tokens":5+index,"total_tokens":inp+5+index,"completion_tokens_details":{"reasoning_tokens":2}}
                raw={"schema_version":"expgym.api_attempt.v1","request_id":rid,"client_id":cid,"generation_id":gid,"attempt":1,"state":"success",
                     "run_id":config["run_id"],"request_payload":{"seed":seed,"model":job["model_id"]},"response_json":{"usage":usage}}
                ref=put(Path(job["dump_dir"])/(rid+".json"),raw)
                inventory.append({**ref,"bytes":len(blobs[ref["path"]]),"mtime_ns":0,"kind":"raw"})
                attempt={"request_id":rid,"generation_id":gid,"attempt":1,"state":"success","usage":usage}
                metadata={"schema_version":"expgym.api_attempt.v1","client_id":cid,"run_id":config["run_id"]}
                cost=100*(order+1) if not pool else 100
                if pool:
                    agent.update(api_dump=metadata,seed=seed,tool_records=[["synthetic_tool",'{}',None]],evaluations=1,total_overhead=cost,eval_time=cost,
                                 wall_time_seconds=2+index,protocol_failures=[],api_calls=1,http_request_attempts=1,usage_attempts=[{"llm_call_index":1,"attempts":[attempt]}])
                else:
                    agent["run"]={"api_dump":metadata,"seed":seed,"model":{"id":job["model_id"]}}
                    agent["task"]={"scenario":row["scenario"],"hypothesis_order":row["hypothesis_order"],"budget":{"regime":row["regime"],"limit_seconds":900},
                                   "item":{"id":row["selector"].get("question_index",row["selector"].get("tuning_task"))},"rep":row["order"] if row["scenario"]=="evidence_audit" else 0}
                    agent["tool_calls"]=[{"name":"synthetic_tool","raw_arguments":'{}',"simulated_cost_seconds":cost,"visible_to_model":True}]
                    agent["llm_calls"]=[{"attempt_usage":[attempt]}]
                    agent["timing"]={"total_simulated_cost_seconds":cost,"wall_time_seconds":.5*(order+1)}
                    agent["outcome"].update(protocol_failures=[],http_request_attempts=1)
                put(root/row["agent_artifacts"][index],agent)
            if pool:
                payload["agent_results"]=agents
                payload["config"]={"agent_seeds":row["sampling_seed_labels"],"scenario":row["scenario"],"cost_regime":row["regime"],"time_budget":900,"model":row["model_id"],**row["selector"]}
                payload["strategy"]=row["strategy"]
                put(root/row["result_artifact"],payload)
                statuses.append(payload["terminal_status"])
            else: statuses.append(agents[0]["outcome"]["terminal_status"])
        for p in job["expected_files"]:
            if p not in blobs: put(p,{"synthetic_summary":True})
        arts=[{"path":p,"sha256":e.sha(blobs[p])} for p in job["expected_files"]]
        verify={"schema_version":"restart-source-verified-resume-v1","invocation_id":iid,"source_exit_code":0,"passed":True,
                "model_calls_forbidden":True,"independent_source_cli_resume":True,"forbidden_model_attempts":{"construction":0,"generation":0},"artifact_bytes_verified_by_this_helper":False}
        verifyref=put(Path(job["log_dir"])/"verified_resume.json",verify)
        logref=put(Path(job["log_dir"])/"source.log",b"synthetic original source stdout")
        put(Path(job["log_dir"])/"verified_resume.log",b"synthetic no-model resume stdout")
        auditref=put(Path(job["log_dir"])/"raw_audit.json",{"schema_version":"restart-raw-wire-audit-v1","verified":True,"errors":[],"inventory":inventory,"counts":{"raw_files":len(inventory),"joined_attempts":len(inventory)}})
        evidenceref=put(root/"evidence"/iid/"score_check.json",{"synthetic":True})
        status=h.status(sum(s["model_no_answer_count"] for s in statuses),sum(s["expected_model_terminals"] for s in statuses),not all(s["score_complete"] for s in statuses))
        report={"invocation_id":iid,"terminal_status":status,"source_capture":{"exit_code":0,"drain_proven":True,"elapsed_seconds":9.5,"log":logref["path"],"sha256":logref["sha256"],
                **{k:True for k in ("capture_complete","child_started","stdout_eof_observed","wait_returned")}},"artifacts":arts,
                "original_terminal_evidence":[evidenceref],"verification_terminal_evidence":[],"verified_resume_ref":verifyref,"raw_audit_ref":auditref,
                **{k:True for k in ("execution_evidence_complete","artifact_integrity_complete","raw_integrity_complete","source_identity_valid","runtime_identity_valid")}}
        wrapped={"invocation_id":iid,"report":report,"decision":{"continue":True,"classification":status["terminal_classification"],"score_complete":all(s["score_complete"] for s in statuses)}}
        put(Path(job["log_dir"])/"terminal.json",{**wrapped,"recorded_at_utc":"synthetic"})
        reports.append(wrapped)
    plan={"schema_version":"restart-executable-plan-v1","mode":"formal_mixed","config":config,"matrix":manifest,"jobs":jobs,"file_bindings":producer_bindings}
    planref=put(base/"plan.json",plan)
    execution={"schema_version":"restart-bounded-study-execution-v1","mode":"formal_mixed","local_workers":0,"plan_ref":planref,"run_id":config["run_id"],
               "reports":reports,"started_invocation_ids":[r["invocation_id"] for r in reports],"unstarted_invocation_ids":[j["invocation_id"] for j in jobs if j["invocation_id"] not in selected]}
    executionref=put(base/"execution.json",execution)
    return [planref,executionref,acceptance_ref],blobs


def run_fixture(f):
    refs,blobs=f
    with mock.patch.object(socket,"socket",side_effect=AssertionError("no network")):
        return e.export(*refs,e.Reader(read=blobs.__getitem__))


class ExportTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fixture=fixture()
        cls.files,cls.evidence=run_fixture(cls.fixture)

    def test_full_matrix_actual_conversion_output(self):
        result=e.load(self.files["results.json"])
        self.assertEqual((len(result["effects"]),len(result["rows"]),len(result["logical_outcomes"])),(514,7687,783))
        self.assertEqual(self.evidence["unique_raw_attempts"],9)
        self.assertEqual(self.evidence["fresh_post_analysis_audit"],"pending")

    def test_audit_order_usage_cost_and_wall_not_triplicated(self):
        records=e.load(self.files["records.json"])["records"]
        manifest=e.load(self.files["manifest.json"])
        ids={r["logical_id"]:r for r in manifest["logical_rows"]}
        rows=[r for r in records if r["state"]=="terminal" and ids[r["logical_id"]]["scenario"]=="evidence_audit"]
        self.assertEqual(sorted(r["telemetry"]["input_tokens"] for r in rows),[11,22,33])
        self.assertEqual(sorted(r["telemetry"]["feedback_cost_seconds"] for r in rows),[100,200,300])
        self.assertEqual(sorted(r["telemetry"]["wall_time_seconds"] for r in rows),[.5,1,1.5])

    def test_pool_whole_n4_and_visibility_unknown(self):
        manifest=e.load(self.files["manifest.json"])
        ids={r["logical_id"]:r for r in manifest["logical_rows"]}
        row=next(r for r in e.load(self.files["records.json"])["records"] if r["state"]=="terminal" and ids[r["logical_id"]]["system"]=="poolact")
        self.assertEqual((row["telemetry"]["input_tokens"],row["telemetry"]["output_tokens"],row["telemetry"]["wall_time_seconds"]),(46,26,9.5))
        self.assertEqual(row["telemetry"]["duplicate_action_attempts"],3)
        self.assertIsNone(row["telemetry"]["feedback_visible"])
        self.assertEqual(row["reasoning_tokens"],8)

    def test_unknown_nas_keeps_none_not_zero(self):
        result=e.load(self.files["results.json"])
        unknown=[r for r in result["logical_outcomes"] if r["score_state"]=="unknown"]
        self.assertEqual(len(unknown),1)
        raw=next(r for r in result["raw_terminals"] if r["logical_id"]==unknown[0]["logical_id"])
        self.assertIsNone(raw["raw_answer"])
        self.assertIsNone(raw["scoring_input"])

    def test_raw_mutation_rejected(self):
        f=copy.deepcopy(self.fixture)
        p=next(p for p in f[1] if "/dumps/" in p)
        f[1][p]+=b" "
        with self.assertRaises(ValueError): run_fixture(f)

    def test_missing_no_model_receipt_not_boolean_acceptance(self):
        value={"schema_version":"restart-source-verified-resume-v1","invocation_id":"i","passed":True}
        with self.assertRaises(ValueError): e.verify_resume(value,"i")

    def test_smoke_never_formal(self):
        f=copy.deepcopy(self.fixture)
        plan=e.load(f[1][f[0][0]["path"]]);plan["mode"]="selected_smoke"
        f[1][f[0][0]["path"]]=e.dump(plan);f[0][0]["sha256"]=e.sha(e.dump(plan))
        with self.assertRaises(ValueError): run_fixture(f)

    def test_usage_unknown_not_zero_and_reasoning_not_added(self):
        values=e.usage([{"response_json":{"usage":{"prompt_tokens":10,"completion_tokens":5,"completion_tokens_details":{"reasoning_tokens":3}}}}, {"response_json":None}])
        self.assertIsNone(values["output_tokens"]["complete_total"])
        self.assertEqual(values["output_tokens"]["known_sum"],5)
        self.assertEqual(values["reasoning_tokens"]["known_sum"],3)
        self.assertEqual(values["output_tokens"]["unknown_attempts"],1)

    def test_no_model_resume_attempt_even_if_passed_true_rejected(self):
        refs,blobs=self.fixture
        value=e.load(next(b for p,b in blobs.items() if p.endswith("/verified_resume.json")))
        value["forbidden_model_attempts"]["generation"]=1
        with self.assertRaises(ValueError): e.verify_resume(value,value["invocation_id"])

    def test_reader_ceiling_fails_closed(self):
        with self.assertRaises(ValueError): e.Reader(read=lambda _:b"abcd",max_file_bytes=3).ref({"path":"/synthetic/large","sha256":e.sha(b"abcd")})

    def test_source_identity_mutation_rejected(self):
        f=copy.deepcopy(self.fixture)
        path=next(p for p in f[1] if "/repo/expgym/" in p)
        f[1][path]+=b"\n"
        with self.assertRaises(ValueError): run_fixture(f)

    def test_failed_job_preserves_raw_cost_without_score_promotion(self):
        f=copy.deepcopy(self.fixture)
        refs,blobs=f
        plan=e.load(blobs[refs[0]["path"]]);execution=e.load(blobs[refs[1]["path"]])
        jobs={j["invocation_id"]:j for j in plan["jobs"]}
        wrapped=next(r for r in execution["reports"] if jobs[r["invocation_id"]]["scenario"]=="restricted_search")
        old=wrapped["report"];audit=e.load(blobs[old["raw_audit_ref"]["path"]])
        wrapped["report"]={"invocation_id":wrapped["invocation_id"],"failure_code":"synthetic failed integrity check",
                           "preserved_artifacts":old["artifacts"],"preserved_raw":[r for r in audit["inventory"] if r["kind"]=="raw"],
                           "preserved_terminal_evidence":old["original_terminal_evidence"]}
        wrapped["decision"]={"continue":False,"classification":"infrastructure_or_integrity_failure","reason":"synthetic"}
        terminal=str(Path(jobs[wrapped["invocation_id"]]["log_dir"])/"terminal.json")
        blobs[terminal]=e.dump({**wrapped,"recorded_at_utc":"synthetic"})
        blobs[refs[1]["path"]]=e.dump(execution);refs[1]["sha256"]=e.sha(blobs[refs[1]["path"]])
        files,evidence=run_fixture(f)
        records=e.load(files["records.json"])["records"]
        failed=next(r for r in records if r["state"]=="infrastructure_error")
        self.assertEqual(failed["telemetry"]["input_tokens"],10)
        self.assertIsNone(failed["telemetry"]["feedback_cost_seconds"])
        self.assertEqual(evidence["unique_raw_attempts"],9)
        result=e.load(files["results.json"])
        self.assertEqual(result["provenance"]["logical_score_states"]["error"],1)

    def test_actual_cli_materializes_fresh_success(self):
        with tempfile.TemporaryDirectory(prefix="synthetic-restart-export-") as tmp:
            refs,blobs=fixture(tmp)
            for path,blob in blobs.items():
                p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(blob)
            output=Path(tmp)/"exported"
            args=["exporter.py"]
            for name,ref in zip(("plan","execution","source-acceptance"),refs):
                args += ["--"+name,ref["path"],"--"+name+"-sha256",ref["sha256"]]
            args += ["--output-dir",str(output)]
            with mock.patch.object(sys,"argv",args),mock.patch.object(socket,"socket",side_effect=AssertionError("no network")),contextlib.redirect_stdout(io.StringIO()): e.main()
            self.assertEqual(len(list(output.iterdir())),17)
            self.assertEqual(e.load((output/"EXPORT_EVIDENCE.json").read_bytes())["logical_records"],783)

    def test_preserved_original_source_fake_telemetry(self):
        base=e.HERE.parent/"planner_candidate_v1/validation_source_e2e/cpu_v3_20260909"
        summary=e.load((base/"summary.json").read_bytes())
        self.assertEqual(summary["classification"],"Static/fake validation")
        for name,expected in (("exp_audit_normal",[19070,19071,19072]),("exp_audit_missing",[19050,19051,19052])):
            ref=next(v["report_ref"] for v in summary["cases"] if v["invocation_id"]==name)
            reader=e.Reader();report=e.load(reader.ref(ref));e.verify_resume(report["verified_resume"],name)
            facts=[]
            for artifact in report["local_artifacts"]["output_dir"]:
                original=e.load(reader.ref(artifact))
                facts.append(e.agent_telemetry(original,pool=False,expected_seed=original["run"]["seed"],run_id=base.name))
            self.assertEqual(sorted(f["seed"] for f in facts),expected)
            self.assertEqual(len({f["client_id"] for f in facts}),3)
            self.assertEqual(sum(len(f["attempts"]) for f in facts),3 if name.endswith("normal") else 6)


if __name__=="__main__": unittest.main()
