# K3 首2闭合证据：独立有限语义复核

结论：本次明确范围内未发现需要否定首2工程接受的实质逻辑漏洞。实际只读检查 `3196bb` exit 0；并非整8或科学结果验收，也不追溯授权后6启动。

首stage `execution.json` SHA `b4817ff1280b7cb9189770ac2d1c0b55bca1c571e507fe3d7cb31640d3c477af`、ROOT check `6c68ad0f8ec9106ff4a09764dceb6290bf5accc99fdc28ce137b5d1dd3130cf6` 与 acceptance `9db1a2eb0c781d6a1e36099586d9f42bee2814eb3dfc1c306ff03be18679a324` 精确绑定。共27个明确输入/元数据文件前后SHA一致；完整路径和字节数见 CHECKS.json。

- 两个 source capture 的整数 exit 0、capture_complete、child_started、EOF、wait_returned、drain_proven 均完整，且与 terminal.report 对应；source log 仅核 snapshot 对其SHA的绑定，没有读日志正文。
- 两个已产生 verified_resume 均 passed、source_exit_code=0、construction/generation=0、model_calls_forbidden、independent_source_cli_resume 为 true。没有重新运行 resume；`artifact_bytes_verified_by_this_helper=false` 是既有 caller 负责前后对账的正常边界，不能误判成失败。
- 原两个 result 容器只抽取 terminal_status/outcome.terminal_status，与报告一致；五个独立 evidence flags 与原纯 typed decision 一致。Pool N4：15 raw /34 wire；Exp N1：31 raw /63 wire；合计5 owners/46 raw/97 wire，所有143个 inventory refs 与首stage snapshot 的path/SHA一致，owner路径不串、无重复，starts/terminals/joins完整、无abort或未读raw下界。
- 实际两个 typed classification 都为 completed_scored、missing=0；未查看任何分数或答案。另对原冻结 dispatch 仅作纯合成 typed-status 检查：将 tuning 终态设为合法 model_no_answer、score_complete=false，两个N都 continue=true。ROOT FIRST2_VERIFY 源码和 acceptance 的 gate 不要求质量/score_complete=true；未发现按优劣选择后6的逻辑。
- stage parent及两source/verify caller共5个PID身份，与ROOT在22:12保存的 absent证明一致。当前已启动后6，本复核没有再检查整个active RUN、没有对184件重复全树哈希，也没有宣称重新测得当前PID不存在；该部分依赖ROOT已固定的历史证明和真实session53399 exit0。

范围：仅首2的stage/plan/first2 GO、已有闭合报告/capture/resume/raw_audit/typed终态与ROOT原检查。未打开任何 raw/wire 请求或响应原件，未解读数值质量、回答、reasoning；未读后6文件、key，未运行model/API/scorer/backend或Slurm，未修改RUN及原proof。允许的两个结果JSON容器被反序列化以取终态字段，不能表述为“完全未解析结果JSON”。

独立性：复核者不是 recovery producer 或 ROOT首2验收作者；曾编写另行冻结的sealer候选。本项是闭合证据语义的有限交叉复核，不替代全8最终seal/merge、费用对账、分析或fresh科学审计。provider quiescence仍未被证明。

本新目录STOP-WRITE，旧证据不变。完整27件引用、实际计数与边界保存在CHECKS.json；不新增GO、重试或参数修改。
