"""Limited local drain check for resource release; NOT full seal admission."""
from pathlib import Path
import json, hashlib, importlib.util, resource
from datetime import datetime, timezone
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
OP=Path("/lustrefs/users/chufan.shi/codex_space_tn/portable_eval_20260908/source_cohorts/v4/portable_eval_20260908/operations/restart_user_20260909")
code=OP/'k3_eight_infra_seal_candidate_v1/seal.py'
assert hashlib.sha256(code.read_bytes()).hexdigest()=='41bdf7511a70eb94fbc6661d9e293c3bdf08fa113e51a10f7515b199f866e0a7'
spec=importlib.util.spec_from_file_location('root_limited_drain_original',code)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
pr=dict(path=str(OP/'compiled_restart-20260909-v5-kimi-k3-infra8-recovery/plan.json'),sha256='6daf5455100de2e4cef8adcdc8fd651e616b4fc653fc4b8e36e326f6abad97ea')
plan,ap=m.bound(pr); root=Path(plan['config']['output_root'])
er=dict(path=str(root/'execution.json'),sha256='d72a672f9009b485c9aaff167935f8a2ff63a71b24234a7b8d99918966b11ad9')
execution,ae=m.bound(er)
ids=[j['invocation_id'] for j in plan['jobs']]
assert len(ids)==len(set(ids))==8 and execution['started_invocation_ids']==ids and execution['unstarted_invocation_ids']==[]
assert execution['local_workers']==0 and len(execution['reports'])==8 and execution['allocation_id']=='1203933'
parents=[];starts=[]
for name,expected_pid,sha in [('first2_only',1515685,'b4817ff1280b7cb9189770ac2d1c0b55bca1c571e507fe3d7cb31640d3c477af'),('remaining6_once',1536152,'8c19e1bcdcdb181763df79fa9693f5183a5f9d219efde135653bda09171d58ae')]:
    ref=next(x for x in execution['stage_execution_refs'] if Path(x['path']).parent.name==name)
    assert ref['sha256']==sha
    stage,sr=m.bound(ref)
    start,start_ref=m.read_json(root/'stages'/name/'STARTED.json')
    assert stage['parent_pid']==start['pid']==expected_pid and stage['parent_ppid']==start['ppid']==1213245
    assert stage['local_workers']==0 and not m.pid_exists(expected_pid)
    parents.append(expected_pid);starts.append(start_ref)
result=m._local_closure(pr,er,root,plan,ap,execution,ae,8,{j['invocation_id']:j for j in plan['jobs']},ids,[],execution['reports'],parents[0],starts[0])
pids=sorted(set(result['known_pids'])|set(parents))
assert not any(m.pid_exists(p) for p in pids)
assert not result['raw_issues'] and set(result['raw_states'])=={'success'}
assert all(row['source_exit_code']==0 for row in result['rows'])
assert m.bound(pr)[1]==ap and m.bound(er)[1]==ae
summary={k:result[k] for k in ('expected_invocations','mode','run_id','raw_count','raw_states','raw_issues','local_workers','provider_quiescence_proven')}
summary['known_pids']=pids
summary['rows']=[{k:row[k] for k in ('invocation_id','source_exit_code','decision_classification','terminal_classification','score_complete','model_no_answer_count','error_type')} for row in result['rows']]
print(json.dumps(dict(schema='root-k3-fixed8-limited-local-drain-v1',issuer='ROOT',passed=True,utc=datetime.now(timezone.utc).isoformat(),plan_ref=pr,execution_ref=er,allocation_id='1203933',summary=summary,full_sealer_admission_passed=False,sealer_admission_failure_preserved='source_terminal_refs_required',purpose='local caller/process/raw-state closure before final metadata GET and owned GPU release only',score_used_as_acceptance_gate=False,source_or_raw_modified=False,model_or_network_calls=0),sort_keys=True))
