# K3 fixed8 controls：独立 metadata-only 复核

结论：355 原候选与追加 20 项后的 375 历史快照主映射，在本次限定的元数据、归属和路径检查中通过。
未发现应阻断该候选的计数或归属错误；这不是最终 inventory、隐私通过、打包/发布许可，
也不是科学结论或全部候选原件的独立 SHA 复核。

## 确切对象与权限边界

当前主映射 CANDIDATE_MAPPING_WITH_EXPORT.json：348,820 bytes，SHA256
43f8f141ad1ad7e3aeb25d73ab56a1b93b9c7dcf852434e902a0bbdc4cf8893c。
355 原映射 SHA853c99c05bce5846b9092c446f842a074ddab86dc05959a03e72fe9aa1429d0c
及其 README 原字节保持；新 EXPORT_ADDENDUM 独立描述后续补齐，不倒写当时的 pending。

本 peer 仅读明确授权的基线 mapping/README/CONTROL_ADDENDUM、旧 collection/index/member
pages 元数据、新两份映射及说明、已给定的 EXPORT_INDEX.json 元数据。未打开或 stat/hash
tar、成员正文、17 个导出 payload、raw、答案、密钥、新 RUN、capture/process 正文；未执行
scanner、seal、pack、restore、Git、模型、网络或 Slurm。没有新建通用 driver；仅一次性
内存元数据检查与 6 个纯规则案例，自身证据只写 peer_review。

作者确实读取并重核 7 个旧归属的代码/控制/原 execution 文件以及当前其它候选字节；
不能说“整个选择任务没有读任何旧 member 原件”。但本 peer 没有读取这些成员本体，
不把作者实际 SHA 证据改称独立再次核原件。对 ROOT 两份新终态控制也只核明确引用，未读正文。

口径补充：本轮确实读取/hash 了当前 375 集合中的四个 metadata control，即旧选择
CANDIDATE_MAPPING.json、README.zh.md、CONTROL_ADDENDUM.json 和新 EXPORT_INDEX.json。
工具回执的 body/payload 零读取计数仅指科学/runtime 正文，不能被解释为没有读取任何
候选 metadata 文件。其余成员本体不因此获得本 peer 独立 SHA 确认。

## 旧归属独立重建

从旧 collection 固定 SHA a78227369423e71e8c4380e46416b8a4ed88464f3e8a502fe1747e7e703103f5
出发，核 34 bundle INDEX、261 member pages；含 collection 共 296 metadata 文件、
21,402,657 bytes，每个索引/页的原 bytes/SHA 均匹配。全部 65,105 成员路径唯一、无前缀冲突，
声明原件字节合计 1,521,531,633。未沿 archive 字段或任何成员路径读取原件。

完整旧 namespace 独立重建后，按完整 WS-relative path 查 owner；不按 basename、IID 或 SHA
猜 owner。7 个匹配项的 bundle_index_ref、member_page_ref、路径、bytes、SHA 全部按实际
受审旧页重建后与新映射富引用相等；其中 6 个属于 controls，原 execution 属 batch-000011。
旧 metadata 的独立 digest 连同其明确序列化定义留在 OLD_OWNERSHIP_READBACK.json，
不声称与定义不同的历史 digest 字符串应相同。

## 当前计数与差异

| 范围 | 数量 | 声明字节 |
| --- | ---: | ---: |
| 355 原候选：新条目 | 348 | 38,907,989 |
| 新增 export：含 EXPORT_INDEX 自身 | 18 | 75,085,889 |
| 追加 ROOT 终态引用 | 2 | 3,896 |
| 当前 375 主映射：新条目 | 368 | 113,997,774 |
| 当前精确声明匹配旧 owner | 7 | 8,580,841 |
| 当前候选总计 | 375 | 122,578,615 |

原 272 + 4 = 276 条均保留；既有非空 bytes 和全部 SHA 不漂移，原 reasons 不丢失。
原 122 个 bytes=null 在新映射均为整数；本 peer 核的是作者填入值和归属/已有声明的一致性，
不是再次打开 122 个本体。355 到 375 原条目逐对象相等，仅多 20 项。

EXPORT_INDEX 的 1,991 bytes/SHA 已实际核，17 个 refs 精确组成 18 项 export 范围；
加 ROOT 明确两项才是 20。未解码 source_index，2247 不属于本 peer 独立确认的计数。
该 INDEX 仍标 fresh_post_analysis_audit=pending，工程接受不升级为科学接受。

全部新增 20 项均不在旧 namespace 或原 355 路径内。375 加旧 65,105、去掉 7 个同路径
复用后共有 65,473 个唯一声明路径，无任何文件前缀冲突；该联合路径集与新 RUN 根前缀
也无等同、祖先或后代冲突。本 peer 未展开/读取新 RUN 的 1,072 成员，实际 RUN 内部闭包
仍由其已批准封存范围负责，不用本次字符串排斥检查替代。

5 组不同路径、同 bytes/SHA 的候选均完整保留；没有内容去重。355 内六个快照声明的名称
集合与对应 entries 精确相等，计数 6/4/7/5/4/42。未独立枚举实际目录；主映射保留当时
ROOT42 快照，另精确加 2 个 ROOT refs，不虚称这个历史快照已经变为一次新 44 件目录快照。

## 规则与 pending

六个有限纯规则案例覆盖：同路径/bytes/SHA 复用；不同路径即使同内容仍新条目；同 SHA
但 bytes 未知保留 pending；同路径 SHA 冲突、bytes 冲突拒绝；bytes=null 也不能掩盖已知 SHA
冲突。这是候选规则检查，不是新写或实际执行打包器。最终冻结工具仍须独立落实这些门。

映射中的 capture 原值 false 和 9 个 137 均保留，不改写为全成功；本次未读底层 capture 或
进程回执，不能据此独立判断退出原因或模型质量。资源接受和科学评价继续分开。

当前五个后续组仍无编造 path/SHA：科学/全 attempt 费用独立复核、最终报告与再复核、
未来 ROOT 接受、最终 controls/scan/pack/发布/恢复/replay，以及本次选择/peer 旁证。
candidate=true、approved=false、publication_or_seal_authorized=false，最终 delta/member/
bundle/联合计数仍 null。当前 375 不是最终发布物理文件数。

## 新增 runtime pending：不能将历史快照冒充最终选择

本 peer 封存前 ROOT 通知：375 中的已闭合 18 export 来自 Python 3.10；严格 341 项
检查有 18 个次要 SD 的 1 ULP 差异，ROOT 与另一 peer 已定位双 runtime 标准库差异，
另一个 fresh 目录中的 Python 3.11 原 merge 正在运行。这些是 ROOT 报告的后续状态，
本 peer 未读取科学 payload、严格复核数据或 active 3.11 产物，不独立背书数值诊断。

355/375 映射和原说明字节保持，不删除、不改写 3.10 历史；375 只表示已闭合历史候选
快照，绝不表示最终 experiment/export 来源选择。当前状态由作者新增 RUNTIME_PENDING.zh.md
与 PENDING.json、最终 INDEX 明确绑定。未来 3.11 的完整 18 输出、GO/exit/接受以及严格
失败诊断、科学/费用复核、报告与再次复核须另行精确枚举；未因路径已知就预纳或预填 SHA。

## 工具证据与保留失败

- 旧完整 ownership：d8a720 自然 exit 0；OLD_OWNERSHIP_READBACK.json。
- 355 修正后 checker：563488 自然 exit 0；MAPPING355_READBACK.json。
- 375 主映射、18 refs、旧完整 namespace 再核：1f2ebe 自然 exit 0，3.485763 秒；
  COMBINED375_READBACK.json。README/ADDENDUM pins 检查 fea65f exit 0。
- 首次 355 checker 77a545 exit 1 已保留在 CHECKER_INITIAL_FAILURE.json：复核者错误地把
  基线简版 old_owner 整 dict 与新富引用比较。30b1b9 定位后，checker 从已核 bundle/page
  重新构造完整富引用再比较，并未改候选或删字段放宽比较。

所有生产、候选和旧旁证均未由本 peer 修改；有限 metadata 检查不证明无所有漏洞。
本目录 6 份文件随最终 INDEX 回读后 STOP_WRITE；后续主映射变化须重新评估，不能沿用 pin。
