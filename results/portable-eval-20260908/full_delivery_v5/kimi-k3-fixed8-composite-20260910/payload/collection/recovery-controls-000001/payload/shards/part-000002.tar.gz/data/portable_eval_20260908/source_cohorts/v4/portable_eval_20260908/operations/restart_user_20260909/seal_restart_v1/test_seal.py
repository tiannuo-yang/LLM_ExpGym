"""CPU-only seal checks using disposable synthetic restart runs."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

import seal


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True) + "\n", encoding="utf-8")


def file_ref(path: Path) -> dict:
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


class RunFixture:
    """Complete plan partition with a bounded number of started invocations."""

    def __init__(self, base: Path, count: int = 28, started_count: int = 2):
        self.base = base
        self.run_id = "synthetic-smoke" if count == 28 else "synthetic-formal"
        self.mode = "selected_smoke" if count == 28 else "formal_mixed"
        self.run_root = base / "runs" / self.run_id
        self.output_dir = base / "sealed"
        self.plan_path = base / "plan.json"
        self.execution_path = self.run_root / "execution.json"
        self.ids = [f"invocation-{index:04d}" for index in range(count)]
        self.started = self.ids[:started_count]
        self.plan = {
            "schema_version": "restart-executable-plan-v1",
            "mode": self.mode,
            "expected_invocations": count,
            "config": {
                "output_root": str(self.run_root),
                "run_id": self.run_id,
                "model": {"model_id": "synthetic-model"},
                "credential_path": str(base / "outside-run-credential"),
            },
            "jobs": [
                {
                    "invocation_id": iid,
                    "log_dir": str(self.run_root / "logs" / iid),
                    "output_dir": str(self.run_root / "outputs" / iid),
                    "dump_dir": str(self.run_root / "dumps" / iid),
                    "terminal_evidence_dir": str(self.run_root / "terminal_evidence" / iid),
                }
                for iid in self.ids
            ],
        }
        self.rows = []
        for iid in self.started:
            log_dir = self.run_root / "logs" / iid
            capture = {
                "child_started": True,
                "stdout_eof_observed": True,
                "wait_returned": True,
                "drain_proven": True,
                "exit_code": 0,
            }
            row = {
                "invocation_id": iid,
                "decision": {"classification": "completed_scored", "continue": True},
                "report": {
                    "invocation_id": iid,
                    "source_capture": capture,
                    "terminal_status": {
                        "terminal_classification": "completed_scored",
                        "score_complete": True,
                        "model_no_answer_count": 0,
                    },
                },
            }
            self.rows.append(row)
            write_json(log_dir / "reserved.json", {"invocation_id": iid})
            write_json(log_dir / "source_started.json", {"pid": 2147483000, "invocation_id": iid})
            write_json(log_dir / "source_capture.json", capture)
            write_json(log_dir / "terminal.json", {**row, "recorded_at_utc": "2026-09-09T00:00:00Z"})
        self.execution = {
            "schema_version": "restart-bounded-study-execution-v1",
            "run_id": self.run_id,
            "mode": self.mode,
            "local_workers": 0,
            "started_invocation_ids": list(self.started),
            "unstarted_invocation_ids": self.ids[started_count:],
            "reports": self.rows,
            "stages": [
                {
                    "local_workers": 0,
                    "started_invocation_ids": list(self.started),
                    "unstarted_invocation_ids": self.ids[started_count:],
                    "reports": self.rows,
                }
            ],
        }
        write_json(self.run_root / "journal" / "drain_0000.json", {"local_workers": 0})
        self.refresh_refs()

    def refresh_refs(self) -> None:
        write_json(self.plan_path, self.plan)
        self.plan_ref = file_ref(self.plan_path)
        self.execution["plan_ref"] = self.plan_ref
        write_json(self.execution_path, self.execution)
        self.execution_ref = file_ref(self.execution_path)
        write_json(
            self.run_root / "execution_started.json",
            {"pid": 2147483001, "plan_ref": self.plan_ref},
        )

    def update_row(self, index: int, *, capture: dict | None = None, terminal_status: dict | None = None) -> None:
        row = self.rows[index]
        if capture is not None:
            row["report"]["source_capture"] = capture
            write_json(self.run_root / "logs" / row["invocation_id"] / "source_capture.json", capture)
        if terminal_status is not None:
            row["report"]["terminal_status"] = terminal_status
            classification = terminal_status["terminal_classification"]
            row["decision"] = {
                "classification": classification,
                "continue": classification != "infrastructure_or_integrity_failure",
            }
        write_json(
            self.run_root / "logs" / row["invocation_id"] / "terminal.json",
            {**row, "recorded_at_utc": "2026-09-09T00:00:00Z"},
        )
        self.refresh_refs()

    def seal(self, control_refs: tuple = ()) -> dict:
        return seal.seal(self.plan_ref, self.execution_ref, self.run_root, self.output_dir, control_refs)


class SealTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory(prefix="restart-seal-test-")
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.pid_patch = mock.patch.object(seal, "pid_exists", return_value=False)
        self.pid_patch.start()
        self.addCleanup(self.pid_patch.stop)

    def fixture(self, name: str = "fixture", count: int = 28, started_count: int = 2) -> RunFixture:
        return RunFixture(self.base / name, count=count, started_count=started_count)

    def assert_sealed(self, fixture: RunFixture, control_refs: tuple = ()) -> dict:
        result = fixture.seal(control_refs)
        self.assertIsInstance(result, dict)
        self.assertEqual(result["sha256"], hashlib.sha256(Path(result["path"]).read_bytes()).hexdigest())
        manifest = json.loads(Path(result["path"]).read_text(encoding="utf-8"))
        self.assertEqual(manifest["schema_version"], "restart-closed-run-inventory-v1")
        self.assertIs(manifest["full_second_read_equal"], True)
        self.assertEqual(manifest["expected_invocations"], len(fixture.ids))
        self.assertEqual(manifest["started_count"], len(fixture.started))
        self.assertEqual(manifest["unstarted_count"], len(fixture.ids) - len(fixture.started))
        inventory = []
        for part in manifest["file_parts"]:
            body = Path(part["path"]).read_bytes()
            self.assertEqual(part["sha256"], hashlib.sha256(body).hexdigest())
            inventory.extend(json.loads(body))
        self.assertEqual(manifest["file_count"], len(inventory))
        self.assertEqual(manifest["total_bytes"], sum(row["bytes"] for row in inventory))
        for row in inventory:
            self.assertEqual(row["sha256"], hashlib.sha256(Path(row["path"]).read_bytes()).hexdigest())
        return manifest

    def test_no_answer_and_false_score_are_accepted_and_preserved(self) -> None:
        fixture = self.fixture()
        fixture.execution["score_complete"] = False
        fixture.update_row(0, terminal_status={
            "terminal_classification": "model_no_answer",
            "score_complete": False,
            "model_no_answer_count": 1,
        })
        before = {
            path.relative_to(fixture.run_root).as_posix(): path.read_bytes()
            for path in fixture.run_root.rglob("*")
            if path.is_file()
        }
        manifest = self.assert_sealed(fixture)
        closure = json.loads(Path(manifest["closure_ref"]["path"]).read_text(encoding="utf-8"))
        row = closure["rows"][0]
        self.assertEqual(row["decision_classification"], "model_no_answer")
        self.assertEqual(row["terminal_classification"], "model_no_answer")
        self.assertIs(row["score_complete"], False)
        self.assertEqual(row["model_no_answer_count"], 1)
        self.assertIs(manifest["original_score_complete"], False)
        after = {
            path.relative_to(fixture.run_root).as_posix(): path.read_bytes()
            for path in fixture.run_root.rglob("*")
            if path.is_file()
        }
        self.assertEqual(before, after)

    def test_drained_nonzero_infrastructure_exit_is_accepted(self) -> None:
        for source_start_record in (True, False):
            with self.subTest(source_start_record=source_start_record):
                fixture = self.fixture(str(source_start_record))
                capture = {**fixture.rows[0]["report"]["source_capture"], "exit_code": 17}
                fixture.update_row(0, capture=capture, terminal_status={
                    "terminal_classification": "infrastructure_or_integrity_failure",
                    "score_complete": False,
                })
                if not source_start_record:
                    (fixture.run_root / "logs" / fixture.started[0] / "source_started.json").unlink()
                manifest = self.assert_sealed(fixture)
                closure = json.loads(Path(manifest["closure_ref"]["path"]).read_text(encoding="utf-8"))
                self.assertEqual(closure["rows"][0]["source_exit_code"], 17)
                self.assertEqual(closure["rows"][0]["terminal_classification"], "infrastructure_or_integrity_failure")
                self.assertIs(closure["rows"][0]["score_complete"], False)

    def test_missing_capture_and_incomplete_drain_are_rejected(self) -> None:
        for issue in ("missing", "stdout_eof_observed", "wait_returned", "drain_proven"):
            with self.subTest(issue=issue):
                fixture = self.fixture(issue)
                if issue == "missing":
                    (fixture.run_root / "logs" / fixture.started[0] / "source_capture.json").unlink()
                else:
                    capture = {**fixture.rows[0]["report"]["source_capture"], issue: False}
                    fixture.update_row(0, capture=capture)
                with self.assertRaises(seal.SealError):
                    fixture.seal()

    def test_worker_booleans_and_nonzero_counts_are_rejected(self) -> None:
        for location in ("execution", "stage", "journal"):
            for value in (False, True, 1):
                with self.subTest(location=location, value=value):
                    fixture = self.fixture(f"{location}-{value}")
                    if location == "execution":
                        fixture.execution["local_workers"] = value
                    elif location == "stage":
                        fixture.execution["stages"][0]["local_workers"] = value
                    else:
                        write_json(fixture.run_root / "journal" / "drain_0000.json", {"local_workers": value})
                    fixture.refresh_refs()
                    with self.assertRaises(seal.SealError):
                        fixture.seal()

    def test_live_supervisor_or_source_pid_is_rejected(self) -> None:
        for pid in (2147483000, 2147483001):
            with self.subTest(pid=pid):
                fixture = self.fixture(str(pid))
                with mock.patch.object(seal, "pid_exists", side_effect=lambda candidate: candidate == pid):
                    with self.assertRaises(seal.SealError):
                        fixture.seal()

    def test_smoke_and_formal_counts_and_exact_partitions(self) -> None:
        for count in (28, 705):
            for started_count in (0, 2):
                with self.subTest(count=count, issue="valid", started_count=started_count):
                    self.assert_sealed(self.fixture(f"valid-{count}-{started_count}", count, started_count))
            for issue in ("count", "job-count", "missing", "overlap", "duplicate", "foreign",
                          "stage-overlap", "stage-foreign", "stage-duplicate"):
                with self.subTest(count=count, issue=issue):
                    fixture = self.fixture(f"{count}-{issue}", count)
                    if issue == "count":
                        fixture.plan["expected_invocations"] = count - 1
                    elif issue == "job-count":
                        fixture.plan["jobs"].pop()
                    elif issue == "missing":
                        fixture.execution["unstarted_invocation_ids"].pop()
                    elif issue == "overlap":
                        fixture.execution["unstarted_invocation_ids"].append(fixture.started[0])
                    elif issue == "duplicate":
                        fixture.execution["started_invocation_ids"].append(fixture.started[0])
                    elif issue == "foreign":
                        fixture.execution["unstarted_invocation_ids"][-1] = "not-in-plan"
                    elif issue == "stage-overlap":
                        fixture.execution["stages"][0]["unstarted_invocation_ids"].append(fixture.started[0])
                    elif issue == "stage-foreign":
                        fixture.execution["stages"][0]["unstarted_invocation_ids"][-1] = "not-in-plan"
                    else:
                        fixture.execution["stages"][0]["unstarted_invocation_ids"].append(fixture.ids[2])
                    fixture.refresh_refs()
                    with self.assertRaises(seal.SealError):
                        fixture.seal()

    def test_text_control_refs_are_accepted_and_declared_credential_is_never_read(self) -> None:
        fixture = self.fixture("text-control")
        control = fixture.base / "launch-notes.txt"
        control.write_text("Synthetic launch notes, deliberately not JSON.\n", encoding="utf-8")
        control_ref = file_ref(control)
        credential = Path(fixture.plan["config"]["credential_path"])
        with mock.patch.object(seal, "regular", wraps=seal.regular) as reads:
            manifest = self.assert_sealed(fixture, (control_ref,))
        self.assertNotIn(credential, [Path(call.args[0]) for call in reads.call_args_list])
        saved_ref = next(row for row in manifest["control_refs"] if row["path"] == str(control))
        self.assertEqual(saved_ref["sha256"], control_ref["sha256"])

        fixture = self.fixture("credential-control")
        credential = fixture.base / "outside-auth-material.dat"
        fixture.plan["config"]["credential_path"] = str(credential)
        fixture.refresh_refs()
        forbidden_ref = {"path": str(credential), "sha256": "0" * 64}
        with mock.patch.object(seal, "regular", wraps=seal.regular) as reads:
            with self.assertRaisesRegex(seal.SealError, "credential_control_ref_forbidden"):
                fixture.seal((forbidden_ref,))
        self.assertNotIn(credential, [Path(call.args[0]) for call in reads.call_args_list])
        self.assertFalse(fixture.output_dir.exists())

    def test_raw_errors_unfinished_and_malformed_json_are_preserved_with_issues(self) -> None:
        fixture = self.fixture()
        fixture.execution.update(execution_complete=False, score_complete=False)
        fixture.update_row(0, capture={
            **fixture.rows[0]["report"]["source_capture"], "exit_code": 17,
        }, terminal_status={
            "terminal_classification": "infrastructure_or_integrity_failure", "score_complete": False,
        })
        fixture.update_row(1, terminal_status={
            "terminal_classification": "model_no_answer", "score_complete": False, "model_no_answer_count": 1,
        })
        raw_dir = fixture.run_root / "dumps" / fixture.started[0]
        write_json(raw_dir / "error.json", {
            "state": "failed", "pid": 2147483010, "finished_at_utc": "2026-09-09T00:00:00Z",
            "error": {"type": "SyntheticRuntimeError", "message": "synthetic raw error"},
        })
        write_json(raw_dir / "unfinished.json", {
            "state": "in_progress", "pid": 2147483011, "finished_at_utc": None, "error": None,
        })
        (raw_dir / "malformed.json").write_bytes(b'{"state":')
        (raw_dir / "deeply-nested.json").write_bytes(b"[" * 2000 + b"0" + b"]" * 2000)
        before = {str(path): path.read_bytes() for path in raw_dir.iterdir()}

        manifest = self.assert_sealed(fixture)
        closure = json.loads(Path(manifest["closure_ref"]["path"]).read_text(encoding="utf-8"))
        self.assertEqual(closure["raw_count"], 4)
        issues = {(Path(row["path"]).name, row["issue"]) for row in closure["raw_issues"]}
        self.assertEqual(issues, {
            ("error.json", "original_raw_error_present"),
            ("unfinished.json", "raw_not_recorded_terminal"),
            ("malformed.json", "unparseable_raw"),
            ("deeply-nested.json", "unparseable_raw"),
        })
        self.assertEqual(closure["raw_states"], {"failed": 1, "in_progress": 1})
        self.assertIs(manifest["original_execution_complete"], False)
        self.assertIs(manifest["original_score_complete"], False)
        self.assertEqual([row["terminal_classification"] for row in closure["rows"]],
                         ["infrastructure_or_integrity_failure", "model_no_answer"])
        self.assertTrue(all(row["score_complete"] is False for row in closure["rows"]))
        inventory_paths = {
            row["path"]
            for part in manifest["file_parts"]
            for row in json.loads(Path(part["path"]).read_text(encoding="utf-8"))
        }
        self.assertTrue(set(before).issubset(inventory_paths))
        self.assertEqual(before, {str(path): path.read_bytes() for path in raw_dir.iterdir()})

    def test_terminal_and_capture_report_mismatches_are_rejected(self) -> None:
        for issue in ("decision", "terminal_status", "capture", "invocation_id"):
            with self.subTest(issue=issue):
                fixture = self.fixture(issue)
                terminal_path = fixture.run_root / "logs" / fixture.started[0] / "terminal.json"
                terminal = json.loads(terminal_path.read_text(encoding="utf-8"))
                if issue == "decision":
                    terminal["decision"] = "different-decision"
                elif issue == "terminal_status":
                    terminal["report"]["terminal_status"]["score_complete"] = False
                elif issue == "capture":
                    terminal["report"]["source_capture"]["exit_code"] = 9
                else:
                    terminal["report"]["invocation_id"] = fixture.started[1]
                write_json(terminal_path, terminal)
                with self.assertRaises(seal.SealError):
                    fixture.seal()

    def test_symlinks_and_overlapping_output_are_rejected(self) -> None:
        for issue in ("file-symlink", "directory-symlink", "inside", "same", "ancestor"):
            with self.subTest(issue=issue):
                fixture = self.fixture(issue)
                if issue == "file-symlink":
                    (fixture.run_root / "linked-plan.json").symlink_to(fixture.plan_path)
                elif issue == "directory-symlink":
                    (fixture.run_root / "linked-logs").symlink_to(fixture.run_root / "logs", target_is_directory=True)
                elif issue == "inside":
                    fixture.output_dir = fixture.run_root / "sealed"
                elif issue == "same":
                    fixture.output_dir = fixture.run_root
                else:
                    fixture.output_dir = fixture.run_root.parent
                with self.assertRaises(seal.SealError):
                    fixture.seal()

    def test_mutation_between_inventories_is_rejected(self) -> None:
        fixture = self.fixture()
        original_collect_tree = seal.collect_tree
        calls = 0

        def mutate_after_first_inventory(root: Path):
            nonlocal calls
            inventory = original_collect_tree(root)
            calls += 1
            if calls == 1:
                write_json(fixture.run_root / "added-between-inventories.json", {"changed": True})
            return inventory

        with mock.patch.object(seal, "collect_tree", side_effect=mutate_after_first_inventory):
            with self.assertRaises(seal.SealError):
                fixture.seal()
        self.assertGreaterEqual(calls, 2)
        self.assertFalse((fixture.output_dir / "inventory.json").exists())


if __name__ == "__main__":
    unittest.main()
