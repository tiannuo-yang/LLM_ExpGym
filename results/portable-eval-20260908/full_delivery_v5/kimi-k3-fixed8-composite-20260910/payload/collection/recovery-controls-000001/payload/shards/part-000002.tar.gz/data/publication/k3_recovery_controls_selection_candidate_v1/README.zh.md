# K3 fixed8：delta controls 候选映射

只读候选，`approved=false`。不执行 seal/scan/pack/restore/Git；不读 active RUN、raw、答案、key，不动 publishing repo、旧原件或旧 proof。范围和联合 INDEX 方法沿用 OP/k3_recovery_delivery_design_v1/README.zh.md。

## 核对结果

实际只读检查 `0ef812` exit 0：原公开 K3 collection 的 34 个 bundle INDEX 与 261 页 member INDEX，连总 INDEX 共 296 件 / 21,402,657 B metadata，逐件核 bytes/SHA；完整原成员集合 **65,105 / 1,521,531,633 B**、全路径唯一、无前缀冲突。没有读取 tar 或任何原实验成员。

原公开总 INDEX SHA：
`a78227369423e71e8c4380e46416b8a4ed88464f3e8a502fe1747e7e703103f5`。

CANDIDATE_MAPPING.json 列出每个固定候选 control 的精确 workspace-relative path、SHA、已有 bytes、身份依据、旧 owner 和选择状态；还列出 34 个原 INDEX pins、member 集合 digest 及本次读取记录。当前只枚举了 **272 个固定探针：265 项未在旧成员中找到，7 项声明身份与旧 owner 相符**。这不是最终 delta 文件数；新 RUN/seal/merge/审阅尚待真实闭合，所有最终计数均为 null。

90 件固定候选/ROOT/plan/source-acceptance 原件实际读 SHA；其它 refs 只取自已 pin 的计划、ROOT readiness/接受或 source acceptance，**没有把引用声明伪装成本次实际读了其原件**。122 项 bytes 仍 null，最终 seal 必须补实。四份用于展开有限声明的 ROOT 文档再核原 SHA：`a31225` exit 0。前一次 plan 字段投影 `c65103` exit 0 的显示被截断；正式 mapping 直接读取原 plan，不依赖被截断显示。

## 已覆盖，只复用原 owner

| 原件，路径前缀均保留原 workspace namespace | 旧 owner |
| --- | --- |
| AN2 analysis_candidate_v2/analysis.py | controls |
| design/formal_export_candidate/converter.py | controls |
| design/formal_matrix_candidate/planner.py（13914a…） | controls |
| exporter_candidate_v2/exporter.py | controls |
| k3_node_failure_root_v1/ROOT_TERMINAL.json | controls |
| sealed_restart_runs_v1/kimi-k3-formal-node-failure-20260909/inventory.json | controls |
| 原 K3 formal execution.json | batch-000011 |

这 7 项只是“声明 SHA 与旧 member 相符”的复用候选；最终 closure inventory 的 path、bytes、SHA 仍须完全相等才不新增。尤其不能换成 recovery planner 7f4ff5…来运行旧 AN2。

## 确定需要补齐的固定 controls

- 新 fixed8 plan（SHA6daf5455…，108,885 B）与 21 件已固定 ROOT 控制：scope/用户范围、readiness、compile/dry-run 原实录、两次 GO、首2工程检查/接受、各候选接受。未把 remaining6 GO 当最终完成。
- 64 件 recovery/seal/merge v1+v2/prompt/peer/CPU 证据：按精确文件清单，不整棵 OP 递归收集。recovery 首轮 CPU exit1 与后续各轮原 log/receipt 全留；merge v1 的限制、v2 修正及旧 peer 记录不重写为全成功。
- profile、runtime validation、source_acceptance_v5_final、source86 **全86件**、原 recovery helper refs **全34件**，均不在旧 65,105 成员内，不能仅因过去验过就当作已有公共物理 owner。
- 原完整 compiled formal plan（6,250,162 B）也未被旧成员覆盖；旧 execution/terminal/seal 已覆盖，不能把这四类旧锚点统称全都在旧包。
- ROOT readiness 精确列出的 45 个非 secret 证据 refs、新 deployment/12 serving source、资格验证/metadata capture 原件，按同路径身份逐条补齐；同内容但不同路径的各 replica metadata 仍保留各自路径。原 capture 的失败状态不改。
- 原 prompt inspector 与原 sealer 等直接代码依赖按 mapping 补入；旧 AN2/exporter 已覆盖。只附资格/provenance 所需源代码和公开证明，不附 checkpoint、数据集、Python/venv 二进制。

这里的“最小”是完整保留这些固定接受链、失败和复用代码身份的有限集合，不是声称重新调用模型所需的一切环境都可离线重建。64 件候选证据清单由独立只读子审查提出；本代理核其实际固定 bytes/SHA 并按旧 ownership 分类。merge v1 保留作接口/历史和回归对照，不声明正式 v2 CLI 需要 import v1。原 v2 的实际源片段明确依赖 frozen exporter；prompt 依赖 inspect_wire_v2；sealer 直接加载原 seal_restart_v1。

## 闭合后才确定

候选 mapping 的 pending_groups 列出未捏造 path/ref/pin 的剩余组：

1. **整个新 RUN**：两阶段全部原件、完整 raw/wire/capture/log/terminal、成功/缺答/infra/未开始及最终 execution，不仅38个结果JSON；这些由实际最终 seal 提供。
2. 实际新 seal 的 inventory、全部 file/directory parts、closure、GO/operator exit/ROOT接受。
3. 唯一实际 merge v2 的18输出（AN2十输出＋五输入＋provenance/全attempt费用/EXPORT_INDEX）及真实GO/退出/接受；固定新8不回退旧partial，不按成绩选择。
4. 新 prompt audit 的每固定IID job、COVERAGE、RECEIPT，以及真实GO/退出/接受。
5. fresh独立后分析/费用复核、最终合成报告、公开资源排空/释放证明。
6. 后续 delta 发布、联合 INDEX、fresh 公共恢复和 AN2 replay 证明。不要把仍生成的交付旁证塞进已封 RUN。

## ROOT 后续沿原工具处理

实际 closure 后，把完整 new RUN 与上述必要 new controls 组成精确、互不重叠的 inventory。主键始终是完整 WS 相对路径：同 path+bytes+SHA 才复用原 owner；同 path 内容冲突立即拒绝；不同 path 即使同 SHA 也不合并。RUN 已拥有的阶段 execution/proof 不再复制进 controls。所有 declared SHA/bytes-null 项以最后封存结果补齐并比较，不凭本候选宣布通过。

按原 inventory schema/metadata 分批→原 scanner→原 pack/local restore，仅处理 delta；旧34 bundles 的原 bytes、路径和身份不改。新联合 INDEX 放公共共同祖先、平铺旧34行和实际新行；原 collection restore/relocator/AN2继续复用。这里没有新 inventory/authority/进程框架，只有候选 mapping 和本文；没有实际封存、打包或发布许可。
