# K3 fixed8：已闭合 controls 选择候选 v2

仅只读元数据/源文件身份选择，candidate=true、approved=false。不是 sealed-publication-file-inventory-v1，不是 scan/pack/Git/发布或最终联合范围授权。旧 mapping、ADDENDUM、公开34 bundles、所有失败和实际实验数据均不改。本目录待 ROOT 最后提供闭合合并/科学审阅/最终报告 refs 后，才能另行确定最终 scope；当前候选不倒填未来成功。

## 当前精确集合

CANDIDATE_MAPPING.json SHA853c99c05bce5846b9092c446f842a074ddab86dc05959a03e72fe9aa1429d0c，334767字节，355条唯一完整 workspace-relative 路径：

| 选择 | 文件数 | 字节 |
|---|---:|---:|
| 新 controls 候选 | 348 | 38907989 |
| 精确复用旧 owner | 7 | 8580841 |
| 当前候选总计 | 355 | 47488830 |

旧基线272条（265新+7声明复用）和 ADDENDUM 四条全部保留；原122条 bytes=null 已对明确非secret原件逐一实际读取、核声明SHA、补全实际字节。此次7条复用均已实际对 path+bytes+SHA 三者及旧member ownership交叉核实，不再只是声明SHA相同；它们仍须最终 ROOT controls seal 核准。

旧34 bundle INDEX与261页member metadata，加总INDEX共296件/21402657B均实际核SHA/bytes。原65105成员路径全唯一、无前缀冲突，总1521531633B。未读原raw或压缩包；确实读取并重核了7个已由旧包拥有的代码/控制/原execution文件，不能误称“没有读取任何旧member原件”。

## 相对原272+4，新增79条

| 新闭合范围 | 新增条目 |
|---|---:|
| 原选择 mapping / README / CONTROL_ADDENDUM 的历史记录 | 3 |
| sealer v2 候选 / 独立 peer | 6 + 4 |
| prompt v2 候选 / 独立 peer（包括首轮文档失败） | 7 + 5 |
| 实际新 prompt 十输出 / 单独 operator四输出 | 10 + 4 |
| 新 accepted seal 的inventory、part、directories、closure，仅metadata | 4 |
| ROOTDIR当前42件闭合快照中尚未包含的20件 | 20 |
| finish四件 + 精确command/events两件 + final_metadata十件 | 4 + 2 + 10 |

原source86全部86件、原recovery helper全部34件继续完整保留。ROOT明确允许仅列举 k3_recovery_root_v1 既有regular files形成快照；42件包括旧实际merge失败及下一GO，不因此代表后续merge已成功。ROOT未来新增文件不自动跟随读取或纳入，另列pending。其他范围只依固定清单/已核index/body refs，未递归WS、OP或serving/run目录。

finish只含finish_v1的BEGIN/EXIT/RECEIPT/FINAL_OBSERVATION，以及RECEIPT指定的commands/0002.json和events.jsonl。final_metadata只含capture.json和其九个body refs。保留capture原passed=false、all_http_captured=true的原始状态和9个服务子进程137退出，不把这些有限工程标志重写为全成功或新的模型失败；ROOT资源接受单独保留。

## ownership 与原件边界

主键始终为完整WS相对路径。同path+bytes+SHA才复用旧bundle；同path任何内容冲突即拒绝，不能覆盖或改名冒充同一原件。不同path即便内容SHA完全相同也保留：当前有5组同内容不同路径，未按内容去重。

新恢复RUN的1072文件/34520799B由另一原raw bundle范围拥有。这里只读取已accepted seal的part metadata核完整成员namespace，对355条controls逐条排除该RUN前缀及1072成员重叠；实际新RUN member bytes未读取。全旧members、controls和新RUN的联合路径集合也核了无前缀冲突。不能在controls重复原stage/raw/results。

明确排除mutable OP/PLAN.zh.md、private/keys/credential原件、venv、checkpoint、模型权重、未闭合后台文件。原冻结peer目录内PLAN.md只是基线固定SHA的历史文档，未混入mutable操作总计划。secret_fd.py是已明确批准的旧helper源代码路径，不是密钥文件。只读源文件内容不等于执行这些程序；未运行模型、scorer、网络、Slurm、scan、seal、pack、restore或Git。

## 校验与证据

第一次完整构建 c6c895 自然exit0（session29064），核651份唯一已知metadata/source文件，共68891487B，末尾重新读取同一已准入集合。790906再次核全部355 control bytes及5个冻结INDEX的子文件绑定；当前每个control均小于100MiB，最大为既定runtime validation_v6.json的27156392B，不随意丢弃大文件。

独立peer从原34组metadata单独重建65105 ownership，再检查本候选对基线276的保留、旧owner判断、计数、namespace和pending边界。原始工具回执与peer refs见 CHECKS.json / peer_review。不能把peer只查metadata/映射说成独立再次读完所有355控制原件或原raw。

准备期间保留两次只读路径假设失败：efc72b把实际CONTROL_ADDENDUM.json误写为ADDENDUM.zh.md；538d88把INDEX实际indexes页目录误作member-index。之后均按已读取的精确文件/ref完成核验，没有删除、改写或据此认定数据缺失。一次较长映射显示c29480被截断，671856完整列272路径，实际构建直接解析原固定JSON而非使用截断显示。

## 仍待补齐，禁止伪造pins

- 唯一实际merge的18件完整输出、对应最终自然退出和ROOT接受。
- fresh科学结论/全部attempt费用的独立审查。
- 最终两段合成报告与结论相符之后的再次逻辑复核。
- 当前42件快照之后新产生的ROOT completion/acceptance；此次选择及peer自身的最终控制旁证，待ROOT精确枚举。
- 最终delta controls seal、隐私scan、pack、联合INDEX、fresh公共恢复与原AN2重放证明，均另需授权。

上述各组当前path/SHA为null；未来delta member/bundle/联合数量也为null。GLM公开新proofs属于独立增量，不塞入K3 science raw。本文是有限公开provenance闭包，不声称可离线重新serve模型、重建所有GPU环境或重新评分全部任务。最终交付继续沿 OP/k3_recovery_delivery_design_v1 的原collection/relocator/AN2接口。
