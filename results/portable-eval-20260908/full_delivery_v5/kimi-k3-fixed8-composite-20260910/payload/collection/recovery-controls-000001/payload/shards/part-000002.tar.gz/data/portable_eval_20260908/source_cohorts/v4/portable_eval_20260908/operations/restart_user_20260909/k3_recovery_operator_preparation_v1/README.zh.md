# K3 fixed8 operator：只读待命清单

状态：2026-09-09 21:21:29 UTC 的有界静态准备；不是 compile/dry-run/模型执行许可。本次只读公开计划和授权元数据、两个冻结 runner 的源码以及目标路径 metadata，只新增本文件。未运行 recovery 入口、原 CLI、tests、scorer、GET/模型/Slurm；未访问任何实际 key 文件（连 key lstat 也未做），未读原 raw、答案或成绩。

## 拟定路径和原件

```text
WS=/lustrefs/users/chufan.shi/codex_space_tn
B=WS/portable_eval_20260908
N=B/source_cohorts/v4/portable_eval_20260908
OP=N/operations/restart_user_20260909
PY=WS/LLM_ExpGym/.venv/bin/python
REPO=B/source_cohorts/v5/LLM_ExpGym
ENTRY=OP/k3_eight_infra_recovery_candidate_v1/recovery.py
run_id=restart-20260909-v5-kimi-k3-infra8-recovery
RUN=N/formal_runs/restart-20260909-v5-kimi-k3-infra8-recovery
COMPILED=OP/compiled_restart-20260909-v5-kimi-k3-infra8-recovery
```

上述缩写仅文档说明，不建 symlink/别名。f60d6d 预检及 b6d616 纠正显示已确认 RUN 和 COMPILED 的 `os.path.lexists` 均 false；父目录存在，父链无 symlink。它们保持未创建。此为当时观察，不能代替真正单次编译/启动前重新核实 unused。

公开文件逐字节 SHA 已核：

| 原件（相对 OP，除显式 B） | SHA256 |
|---|---|
| k3_recovery_root_v1/RECOVERY_CANDIDATE_ACCEPTANCE.json | 5bb8cacfe930e666186cd625e7e547b03b61e61330272bf28c4cc1fd2b88788a |
| k3_recovery_root_v1/RECOVERY_SCOPE.json | a685cf14f26dc2bb3f0346b2adcd1f1c58693c006dd429052292bb054115d4b3 |
| B/serving/phase_candidates/k3_infra_recovery_v1/runs/1203933/k3_formal/deployment.json | 6107f0a3bf9fe8a05c23895f8e93c98c2690f4faaed30961579bba49707379c6 |
| compiled_restart-20260909-v5-kimi-k3-formal/plan.json | 52e42a7464d28433ca350bc4d9aedf417c92bb8595662a5fdb22f545073870e9 |
| source_acceptance_v5_final.json | 0b1166cb5549ceb606bd98086809548cb0d83c3e94070e3570cc4783e1b1a744 |

deployment 公开 model=kimi-k3，router_url=http://azure-uk-hpc-H200-instance-410:31241。新 command 的规范 endpoint 应为 `http://azure-uk-hpc-H200-instance-410:31241/v1/chat/completions`；不能继续用旧 001 主机。这里只核公开 runtime_receipt/path+SHA 等于原 config，不把已落 deployment 或已加载 weights 当 ready/metadata 验收。

原 runtime ref：B/serving/runtime_candidates/gumbel_midpoint_v1/manifests/validation_v6.json / 6ae2baf43591acaad1be8b4f0dfe7fc705996313d1f588ce7cb63990cb892111；profile ref：B/request_profiles/kimi-k3-v3.json / e7af613955f65b7cac104d90e02458dd05b5677fd3804592040e302de7f3a837。这里只重核 ref 一致性，未重跑 runtime 或模型 profile 资格。

两 source runner 字节与 source_acceptance_v5_final 的 files 精确相符：

- REPO/scripts/run_poolact.py：f69619eb7361058311c5e14da5af064dc710efcd4d1a4a8ab7ca349be3b6ed15。
- REPO/scripts/run_paper_sweep.py：3eda1ac8eb5d48311dd94a374519d220eabd58046b3f9dfbbf2f68453df6298f。

已接受 recovery.py 仍 d152f716d27c570f1fc257a914953b7ef76411a5582f44d8a10e80dc812965a5；本次不改它或旧 helper/source。

## 最少待补实际输入

ROOT 尚需基于新实际 readiness/metadata 创建 `restart-recovery-ROOT-readiness-v1`，原 source/profile/runtime refs、真实 allocation_id/gpu_count=64 和真实时间字段按已接受 README；不得用旧 readiness 或本文件代填 passed。

ROOT给出的 allocation 原始时间是 start=2026-09-09T21:02:03Z、end=2026-09-10T21:02:03Z。此处保留为 ROOT 来信事实，未发 Slurm 查询；未来实际 readiness/GO 必须据真实公开原件核定这两个时间。已报告 21:13:17 开始加载不能重置 allocation start。原 policy max_wall=86400、stop_new=3600 不改；GO 的独立绝对 deadline 严格早于 actual end，并小于等于 whole 原始起点+86400，loading 成本不归零。

然后 ROOT 另写 compile spec，schema 与精确四 old refs/new_binding 等见已接受 ENTRY 同目录 README。spec 中只使用本次新 run_id/output_root/deployment_ref/readiness_ref 和 CLI RECOVERY_SCOPE；工程 acceptance 与用户范围不当执行 GO。不要先造带 placeholder 的实际 spec/plan。

将来单次编译命令（当前未执行；ABS_SPEC/SPEC_SHA 待 ROOT 原件）：

```text
PY -B ENTRY compile --spec ABS_SPEC --spec-sha256 SPEC_SHA --output-dir COMPILED
```

ROOT 直接持有此 CLI 的实际退出码与 stdout，记录 plan 原 bytes SHA 和 canonical SHA。编译完成不启动 source；RUN 仍须不存在。失败原件保留，不自动重试或改 validator。

## 精确八条 source dry-run 的准备

dry-run 的权威 argv 定义只有一种：**各新 compiled plan 的原 job.command 完整数组，末尾追加一个 `--dry-run`**。不是调用 recovery launch/child，也不提供 `--execute-real`、`--secret-fd`、`--api-key` 或 `--api-key-file`。这里不另写拼 command 的 driver 或实际执行脚本；ROOT 编译后原数组已经完整解析 source/runtime/profile/endpoint/输出路径。

已从原 plan 只抽 command/selector/path/计数元数据核对，八条旧 command 全部 `--backend openai`、无两个 key flags、无已有 --dry-run。新 producer 只准重绑 endpoint 与新 root，其他 tokens 不变。后续新 plan 核对后，ROOT 直接按以下有序 IID 提取 argv，不按输出/效果选择：

| 顺序 | IID | runner | task / cost-regime / strategy | terminals |
|---|---|---|---|---|
| 0 | 17e194780d358412d10ac736d5c00626d087e5209e0ee55ee8db1489e8ba5524 | run_poolact.py | hpobench:nasbench101:C / cost_tight / poolact | 4 |
| 1 | 2128eec1bc885ca8e9268a941c99c832daba57e2211a95b86739b35ac7834d8c | run_paper_sweep.py | hpobench:nasbench101:C / cost_free / single | 1 |
| 2 | 70994c0fc3e69d730ef6c52df8ceccddf99cbf7aa6b5d772160a3e30b8b8ce4e | run_poolact.py | hpobench:nasbench101:B / cost_moderate / poolact | 4 |
| 3 | 8d34d89066626e712a83355e91931c2c9f901ae6196d5eb8140f17b122194466 | run_poolact.py | hpobench:nasbench101:C / cost_moderate / naive | 4 |
| 4 | 2db6e0051763ac23b797170e7608afceac029c91c430796918a19d666bb83934 | run_paper_sweep.py | hpobench:nasbench101:C / cost_moderate / single | 1 |
| 5 | 1926939d7c70125a7b1b29208d0217ce2a938333a8f59e639aab7e25fef48720 | run_poolact.py | hpobench:nasbench101:C / cost_moderate / poolact | 4 |
| 6 | f41fd4716d949c1ffc0275a3723d9c9e59bc09b7a94026af8b0f345918483efa | run_poolact.py | hpobench:nasbench101:A / cost_moderate / poolact | 4 |
| 7 | dbf6b81b2b569ea676580e8579046d1198e1a7ef4e760efab76df3378194a26c | run_poolact.py | hpobench:nasbench101:C / cost_moderate / cached | 4 |

共同原 argv 前缀是 `PY -u -B REPO/scripts/<runner>`。六 Pool selector 的精确形状为 `--scenario tuning --cost-regime REGIME --seed 2208 --model kimi-k3 --agents 4 --repeats 1 --strategies STRATEGY --tuning-task TASK`；两 Exp 为 `--scenarios tuning --cost-regimes REGIME --seed 2208 --models kimi-k3 --model-alias kimi-k3=kimi-k3 --tuning-reps 1 --search-reps 1 --audit-reps 1 --trace-format v2 --tuning-tasks TASK`。

共同 flags 保留 `--backend openai --base-url 新endpoint --max-steps 30 --max-evals 30 --max-tokens 32768 --max-protocol-retries 1 --max-retries 2 --request-timeout 3600 --retry-base-seconds 3 --retry-max-seconds 30 --tool-protocol native --tuning-final-policy legacy --missing-final-policy task-abstention-v1 --top-p 1.0 --terminal-evidence-dir RUN/evidence/IID --output-dir RUN/<原job.output_relative_dir>`。

Pool 附 `--temperature 1.0 --max-context-tokens 131072`；Exp 附 `--temperature-eval 1.0 --temperature-tuning 1.0 --prompt-cache-scope disabled`。全部保留 `--reasoning-effort max --chat-template-kwargs {"thinking":true,"thinking_effort":"max"}` 作为单个 JSON argv 元素；top_k 原为 null，不加该 flag。最后仅追加 --dry-run。

新 run 的 result-relative 路径中仍有原设计名 `results/restart-20260909-v5-kimi-k3-formal/kimi-k3/outer_00002/...`，这是固定设计相对路径，不表示写回旧 run。不要手改它、重复增加 results/ 或把新 physical run_id 改回旧值。

## 无 key / 无模型的实际 dry-run 边界

- Pool `parse_args:628–631` 的 api-key-file 默认 None；仅 backend=openrouter 在 main:688–691 自动补旧默认 key 路径。固定 backend=openai 无此补值。
- Pool `main:717` **先执行 _load_api_key，再于729–751 dry-run返回**。`_load_api_key:154–168` 检查 args.api_key、对应 API key 环境变量，再检查 args.api_key_file。故必须三个来源均为空；不能仅依赖 --dry-run。无 argv key、清环境后不会打开 key 文件。dry-run 只 print 配置，在753 mkdir 和后续 source/model 构造之前返回。
- Exp `main:1126–1128` dry-run 在1129 key读取、1141 preflight、1142输出mkdir之前返回。_build_jobs:305 会解析设计字段并读取固定 orders config；这是有限 source 配置读取，不是执行 source scorer/模型。
- 使用原 `launcher.clean_environment` 的精确环境规则：移除大小写 *_PROXY、名字含 API_KEY/ACCESS_TOKEN/SECRET，EXPGYM_/OPENAI_/OPENROUTER_/SUB2API_/GEMINI_ 前缀及 *_TOKEN；仅加入原 config.environment 已验证的非秘密项，NO_PROXY/no_proxy='*'、PYTHONDONTWRITEBYTECODE='1'。不输出原环境值。不得传原服务 API key 文件或加载用户 shell 私密 env。
- 原 CLI argv 已有 -B，不产生 Python bytecode缓存。dry-run 仅 source 配置预览，不代表原 scorer/E2E、HTTP raw、真实 ready 或工程首两项验收。没有 dry-run GO 时连此无模型入口也不运行。

未来获得单次 dry-run GO 后，只在独立 operator/dry 日志目录保存八条 resolved argv/stdout/stderr/start/exit；不在 RUN 写收据，也不生成 source result/raw/terminal。核八条全部 exit0、计数8/26与配置，并确认 RUN 仍不存在。ROOT 直接掌握原 CLI 会话，不新增 Popen wrapper。失败保留并报告，不改参数补跑。

## 真正执行前的等待项

尚待新 actual readiness、一次 compile 与原 plan pins、一次上述8 dry-run、ROOT 首2 GO（不是此文档）。首2 GO 只两项；自然闭合后另 ROOT 独立工程验收及 remaining6_once GO，同 plan/deployment/allocation。合法 NAS model_no_answer 不因质量触发重抽；剩六不能自动启动。已有 697 和旧8保持不动。实际 launch 使用原 accepted recovery.py CLI，不使用原 source --dry-run 命令当模型执行路径。

## 本次检查记录

tool f60d6d：在所有公开pins/unused路径/source hashes/无keyflag断言通过后，显示器误取不存在的 job 顶层 strategy，KeyError，exit1。策略真实在 selection_argv；不是实际 runner/CLI 失败，无调用、无输出目录创建。此首次错误在此明确保留。

tool b6d616：仅修正元数据显示字段，旧 plan bytes pin再次核对、八项 selector和路径读取、两拟定目录再确认不存在，exit0；随后 clock=21:21:29 UTC。tool aa855c/b9e962 完整核必要 dry-run/key-loader/配置打印分支及两runner SHA。没有实际 compile/dry-run/模型请求、source/scorer执行、真实 key访问或新测试。
