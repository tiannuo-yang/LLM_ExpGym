# K3 固定恢复首 2 项：工程验收清单（离线准备）

本文件只解释冻结代码的工程 gate，不是实际验收、新 GO 或请求生成工具。ROOT 的实际 caller/session 53399 仍由 ROOT 自己追踪；本任务没有读取实际 stage、raw、答案、key 或当前进程状态，没有运行 launcher/dispatch/verify/scorer，没有写 run root。所有实际 refs、SHA、PID、退出码和剩余时间由 ROOT 在 caller 自然退出后取得，不在本文预填成功。

**准入必须与模型质量独立。** 正常 `model_no_answer` 不是 infra；本次 8 项都是 tuning，原 typed policy 明确允许 `score_complete=false` 的正常缺答继续。不得用分数、优于旧结果与否、是否符合预期结论、缺答率或 token 数决定是否运行后 6 项。以下所有工程条件满足才可继续；存在真实 infra/证据缺口时不能仅因分数好看放行。

## 固定读取依据

相对根 `OP=/lustrefs/users/chufan.shi/codex_space_tn/portable_eval_20260908/source_cohorts/v4/portable_eval_20260908/operations/restart_user_20260909`：

| 固定源码 | SHA-256 | 本次阅读范围 |
| --- | --- | --- |
| `k3_eight_infra_recovery_candidate_v1/recovery.py` | `d152f716d27c570f1fc257a914953b7ef76411a5582f44d8a10e80dc812965a5` | 完整 538 行 / 34,973 B |
| `planner_candidate_v1/launcher.py` | `c934c6234619cc35c8ce2e19710f69fbd8ce931bcda7bf2f7d745f5a78511a41` | 完整 512 行 / 29,566 B |
| `planner_candidate_v1/dispatch.py` | `e9d2984b41aece5bf78ba2ef01816dc52fa95d83d8d5babf2866bbcee0e594aa` | 完整 106 行 / 5,992 B |
| `planner_candidate_v1/wire.py` | `bac690bc5976dad609e4544e10d0e2b31596b8cb34e996ca721ce878b4e4e52f` | `verify_source`（351 行至文件末） |
| `planner_candidate_v1/evidence.py` | `077979bc9c4f403750b7d99173a0ac4579876b0c23dfb00d6eb526fa066f4968` | `audit_raw`（130 行至文件末） |

本次全文工具 `3a84ef/732dda/7c7ed2`、`6926dd/6a5944/ca0fe1`、`aaf7bb`；相关函数读取 `e447fc/51aed8/e431bd`；SHA 核对 `406bfa/c22243/563711`，均实际 exit 0。只是读代码，不 import 或执行这些入口。

## A. 先确认自然闭合与精确身份

1. ROOT 持有的唯一 first2 启动 session 必须实际自然返回，记录真实 exit；成功 stage 应 exit 0。`execution.json` 存在或 `local_workers=0` 单独都不证明 caller 已退出。异常退出/缺失证据保留，不补造 marker、不重试、不自动发后 6 GO。
2. 第一阶段路径只取已批准 plan 的 `config.output_root/stages/first2_only/execution.json`，schema 恰为 `restart-infra-recovery-stage-execution-v1`。`stage=first2_only`、`mode=infra_recovery_exact8`、`plan_ref/run_id/deployment_ref/allocation_id/original_plan_ref/recovery_scope_ref/producer_code_refs` 与已冻结 plan/first2 GO 一致。
3. 首两 IDs 顺序固定：`17e194780d358412d10ac736d5c00626d087e5209e0ee55ee8db1489e8ba5524`（Pool NAS C Tight，N=4）和 `2128eec1bc885ca8e9268a941c99c832daba57e2211a95b86739b35ac7834d8c`（Exp NAS C Free，N=1）。`started_invocation_ids` 恰为上述两项，`unstarted_invocation_ids=[]`，reports 恰好 2 个不同 IID 且集合相同。reports 是并发完成顺序，不要求与 started 列表顺序相同。合计 **5 model terminals，不是 5 raw HTTP attempts**。
4. 工程通过需 `execution_complete is true`、`local_workers` 是整数 0、`stop_reasons=[]`、`provider_quiescence_proven is false`、`score_not_used_for_stage_selection is true`。`score_complete` 必须保留原 bool 值，但不是准入条件。dispatch 的 operator stop/before_start 失败也会形成合法 incomplete；不能因为两个报告最终都有结果就忽略 stop_reasons。
5. 阶段 `parent_pid/parent_ppid` 与 `STARTED.json` 的 `pid/ppid` 相同；STARTED 的 stage、plan_ref、外部 go_ref、bound_go_ref 必须正确。`GO.bound.json` 为外部 first2 GO 的逐字节副本、SHA 相同，reservation 使用 bound ref，不把外部和内部路径误当成完全相同的 ref。保留 `started_unix/run_started_unix/finished_at_utc/elapsed_seconds` 的真实值。

依据：recovery.py 244–307、442–495；dispatch.py 40–106。首2成功时只写 stage execution，**正常没有 `run/execution.json`**；后者只在首2失败或后6闭合时写。不能把“没有 final”误判为首2失败，也不能对成功但未进行后6的中间状态调用整8最终 sealer。

## B. 两个 invocation 的工程证据，不解释质量

逐 IID 核原 `job.log_dir` 下 reservation、terminal、source/verify 启动、capture、raw_audit、verified_resume 的精确 path/SHA；不得猜出不存在的 `verify_exit.json` 或自行生成证据。

- source capture 与 terminal.report 的 capture 完全一致，`exit_code` 为整数 0，`child_started/stdout_eof_observed/wait_returned/drain_proven` 全为 true。source exit 0 不能代替 EOF/wait。source_started、verify_started 的 IID/stage、正整数 PID、PPID 与 stage caller 对齐；stage parent、source caller、verify caller 以及 raw 中已知 caller PID 必须都消失。PID 仍存在需 ROOT 核身份，不能假定只是复用而跳过；外部 shell 的 parent_ppid 本身不必消失。
- `verified_resume` schema 为 `restart-source-verified-resume-v1`，IID 正确、`passed=true`、source_exit_code 整数 0、forbidden_model_attempts 中 construction/generation 均整数 0、`model_calls_forbidden=true`、`independent_source_cli_resume=true`。这是已执行的原 CLI `--resume`，模型构造/生成均被禁止；不再运行一次来“看看”。原 producer 通过 `subprocess.run` 自然 wait，并要求返回码 0。该返回码不另存专用文件；不能补造。
- `artifact_bytes_verified_by_this_helper=false` 是正常的职责边界，不是失败：原 producer 负责 resume 前后原 results、raw、original terminal evidence 的 path-set/SHA 一致。PoolAct resume 可能重写 summary 的 mtime，只要求原 bytes 与路径一致，不把 mtime 改动误当成结果变更。source terminal evidence 与 verification terminal evidence 使用不同原目录，均保留。
- report 的五个独立证据字段 `execution_evidence_complete/artifact_integrity_complete/raw_integrity_complete/source_identity_valid/runtime_identity_valid` 必须全部精确 true。`artifacts` 覆盖原 job.expected_files 的完整集合；原 typed terminal 来自原 job.terminal_artifacts，不能拿 summary 质量指标代替。
- typed terminal 必须符合 `expgym.execution-terminal.v1` + `task-abstention-v1`，execution_complete=true，expected/reported model terminals 都是对应 N（4 或 1），model_no_answer_count 是 0…N 的整数。按原 dispatch.py 10–37 判定并要求报告里保存的 decision 相同，两个 decision.continue 都必须 true。
- `completed_scored` 要 missing=0 且 score_complete=true；`model_no_answer` 要 missing>0，且因为 scenario=tuning，score_complete=false **合法继续**。本清单不要求每个 agent 提交答案，也不要求指标非零。无答案不是 transport abort、未终态 raw 或缺失文件；这些工程问题仍应拒绝。
- 已有 `raw_audit` 必须为 `restart-raw-wire-audit-v1`、verified=true、errors=[]。inventory 覆盖该 IID 的两个完整扁平目录（dump 与 log/wire），逐原件 path/bytes/SHA 对账；clients=N，start/terminal/join/raw 数量一一对应，无未读 raw 下界、无 provider abort、owner seed 覆盖正确。Exp seed label 为 2208，Pool 为 2208…2211。全5个 client 是合计逻辑 owner，不是固定生成轮数。
- 原 raw-wire audit 已核请求/响应字节、owner/retry/时间链与 assistant-tool 历史结构；检查其已闭合产物不等于重做 scorer 或重新解释答案。**合法原 retry 可以留下 state=error 的早期 raw，只要原 audit 对完整 retry 链 verified 且最后成功交付，就不能要求所有 raw state 都为 success。** provider abort、不可交付终态或未成对 wire 会被原 audit 拒绝。内部已注册 max_retries=2 保持原设定；不新增恢复 invocation 尝试。

依据：recovery.py 309–394；launcher.py 294–319；wire.py 351–末；evidence.py 130–末。raw_audit 的旧 usage 汇总不是新的完整费用审计，未知费用也不能被拿来当 0 或用作分数 gate。

## C. `closed_file_inventory` 是后6前的不可变输入边界

在首2 caller 自然退出后，ROOT 先核 stage execution 原件 SHA，然后只读新 run 完整文件集合。期望集合精确等于：

`stage.closed_file_inventory + [{path: first_stage_execution_path, sha256: first_stage_execution_sha}]`

按 path 排序，逐路径 SHA 比较，无重复、symlink、特殊文件、少件或多件。不要只抽样，也不要只比数量。`closed_file_inventory` 在写该 stage execution **之前**生成，因此不包含自己；这不是漏件。snapshot 只允许首2各 job 的 output/dump/log/terminal_evidence、verification_evidence 和 first2 stage 的 STARTED/GO.bound/drain 等文件。

`safe_tree` 返回 path/SHA refs，不含完整 POSIX metadata；不能将它描述成旧 sealer 的完整双遍 stat 封存。ROOT 可独立留验证收据，但 **全部 first2 acceptance / operator / seal / review 文档必须在 run 外**。任何写进 run 的额外文件都会使后6入口 `first_stage_bytes_or_run_scope_changed` 拒绝；不要为消除拒绝去删原证据或改 snapshot。

依据：recovery.py 297–307、397–409、475；launcher.py 38–51。当前 frozen final sealer 对整8或已失败闭合 partial 取证，不负责在成功 first2 中间状态凭空生成 final。

## D. 仅工程通过后，ROOT 新签 remaining6 GO

没有沿用 first2 GO 自动续跑。后6 GO 为外部全新文件；schema/action 沿原 `restart-root-launch-go-v1` / `execute_once`，并至少精确绑定下列字段：

| 组 | 必需内容 |
| --- | --- |
| 身份 | issuer=ROOT、stage=remaining6_once、mode=infra_recovery_exact8、同一 plan_ref/run_id/model_id=kimi-k3/output_root/deployment_ref、policy_sha256 |
| 固定范围 | invocation_ids 恰为 plan.stage_ids.remaining6_once 原顺序（固定余6）；同一 recovery_scope_ref/readiness_ref；不重跑首2、不增删任务、seed 或策略 |
| 首2 gate | first_stage_execution_ref 为首2确切原 path/SHA；first_stage_acceptance_ref 为新的外部 ROOT acceptance path/SHA |
| 资源 | allocation_id、gpu_count=64、allocation_start_unix/allocation_deadline_unix 与已绑定 readiness 一致；not_before_unix/latest_start_unix/deadline_unix/gpu_seconds_cap 均真实有限数 |

ROOT acceptance schema 恰为 `restart-recovery-first2-ROOT-acceptance-v1`，包含 issuer=ROOT、passed=true、first_stage_execution_ref、plan_ref、deployment_ref、allocation_id、caller_drained=true、engineering_only_not_quality_selection=true。该 true 只能在本清单实际工程核验后填写；本文没有创建 acceptance 或 GO。不能将 score_complete=true 加成额外准入条件。

时间约束全部同时满足：

- allocation 总跨度 `0 < allocation_deadline_unix - allocation_start_unix <= 86400`；后6不能申请/暗加更长窗口。
- `allocation_start <= not_before <= latest_start < deadline < allocation_deadline`；最后严格 `<` 来自 recovery 对原 Authority 的补充。
- `(deadline - allocation_start) × 64 <= gpu_seconds_cap`，不是只从后6启动时重算预算。
- `deadline <= first_stage.run_started_unix + 原 config.policy.max_wall_seconds`，不能为后6重置整个 run 的 wall 起点。
- 实际入场 `now <= latest_start`；每次请求 `now >= not_before` 且 `now + request_timeout < deadline`；新 dispatch 还要 `now + stop_new_before_deadline_seconds < deadline`，并满足原 whole-wall 检查。
- 后6 stage 目录必须此前不存在，run final execution 也必须不存在。保留原 W=32 policy；此 stage 只有6个 jobs，不能把 W32 解释为补充启动更多 invocation。

依据：launcher.py 251–275；recovery.py 92–96、244–268、412–456。readiness/时间条件不足时，是资源或工程 gate 未通过，不是因模型缺答拒绝；保留原件交 ROOT，不改时间上限、不重试、不自动扩节点。

## 判定与保存

首2满足 A–C 且 D 有真实足够窗口：可由 ROOT 给后6工程 GO，**即使正常缺答或结果不符合预期**。若首2 infra/证据异常或收到 operator stop：保留真实 started/unstarted、原失败和 final incomplete，后6不擅自开始。若首2成功而时间不足：保留成功 stage，报告具体时间围栏，不假造后6结果。

首2通过不等于固定8恢复完成，更不等于 K3 结论或整个项目验收。后6仍须真实自然闭合，完整新 seal、固定选择规则 merge、所有旧/新 attempt 费用、后续分析与独立审计另做。provider_quiescence_proven 仍 false；本地 caller 消失不证明服务队列空。本文无 actual pass/score/token/费用断言。
