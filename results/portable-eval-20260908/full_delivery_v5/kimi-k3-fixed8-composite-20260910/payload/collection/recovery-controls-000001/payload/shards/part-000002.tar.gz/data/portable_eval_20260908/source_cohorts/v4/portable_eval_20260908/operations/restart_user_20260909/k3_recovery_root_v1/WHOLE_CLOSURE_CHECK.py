"""Prepared read-only closure entry; ROOT invokes only after actual caller exit."""
from pathlib import Path
import json, hashlib, importlib.util, resource
from datetime import datetime, timezone
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
W=Path('/lustrefs/users/chufan.shi/codex_space_tn')
OP=W/'portable_eval_20260908/source_cohorts/v4/portable_eval_20260908/operations/restart_user_20260909'
P=OP/'compiled_restart-20260909-v5-kimi-k3-infra8-recovery/plan.json'
PLAN_SHA='6daf5455100de2e4cef8adcdc8fd651e616b4fc653fc4b8e36e326f6abad97ea'
raw=P.read_bytes(); assert hashlib.sha256(raw).hexdigest()==PLAN_SHA
plan=json.loads(raw); root=Path(plan['config']['output_root'])
execution=root/'execution.json'; body=execution.read_bytes()
er=dict(path=str(execution),sha256=hashlib.sha256(body).hexdigest())
pr=dict(path=str(P),sha256=PLAN_SHA)
code=OP/'k3_eight_infra_seal_candidate_v1/seal.py'
assert hashlib.sha256(code.read_bytes()).hexdigest()=='41bdf7511a70eb94fbc6661d9e293c3bdf08fa113e51a10f7515b199f866e0a7'
spec=importlib.util.spec_from_file_location('root_fixed8_closed_run_sealer',code)
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
result=m.closure(pr,er,root)
assert execution.read_bytes()==body and hashlib.sha256(P.read_bytes()).hexdigest()==PLAN_SHA
assert result['local_workers']==0 and result['expected_invocations']==8
assert result['started_ids']+result['unstarted_ids'] and result['provider_quiescence_proven'] is False
summary_keys=('expected_invocations','mode','run_id','started_ids','unstarted_ids','parent_pid','known_pids','original_execution_complete','original_score_complete','raw_count','raw_states','raw_issues','local_workers','provider_quiescence_proven')
summary={key:result[key] for key in summary_keys}
summary['rows']=[{key:row[key] for key in ('invocation_id','source_exit_code','decision_classification','terminal_classification','score_complete','model_no_answer_count','error_type')} for row in result['rows']]
summary['stage_execution_refs']=[{key:ref[key] for key in ('path','sha256')} for ref in result['recovery_stage_execution_refs']]
print(json.dumps(dict(schema_version='root-fixed8-readonly-whole-closure-check-v1',issuer='ROOT',passed=True,verified_utc=datetime.now(timezone.utc).isoformat(),plan_ref=pr,execution_ref=er,allocation_id=json.loads(body)['allocation_id'],closure_summary=summary,model_or_network_calls=0,source_or_raw_modified=False,score_used_as_engineering_gate=False,full_file_seal_performed=False),ensure_ascii=False,sort_keys=True))
