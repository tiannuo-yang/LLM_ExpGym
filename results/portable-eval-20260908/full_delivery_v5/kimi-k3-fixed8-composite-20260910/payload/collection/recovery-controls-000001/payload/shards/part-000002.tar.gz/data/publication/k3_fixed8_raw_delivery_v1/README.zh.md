# K3 fixed8：完整 raw 元数据交付候选

本目录仅将 ROOT 已接受的 `kimi-k3-fixed8-recovery-20260910-v2` 完整 raw seal 投影为原 publication inventory，并实际调用一次冻结 prepare CLI。**全部 1072 件 / 34,520,799 B，实际 1 batch**；没有按成绩、失败或原件类型选择，没有 controls，也没有重打包旧 K3 65,105 成员。

`inventory.json` 恰为原 `sealed-publication-file-inventory-v1` 五字段 schema；`authority_ref` 为真实原 seal 的完整 workspace-relative 路径及 SHA `b1d1dd3f17b4eb6ccd9cda4026e02f3423674a84b2af15d58db263921794a5ce`。每行保留原 workspace-relative path/bytes/SHA。`SELECTION.candidate.json` 记录 ROOT seal acceptance、唯一 part、原 true/true 状态和全部只读 metadata 身份。目录计数 159 不当作文件或 batches；批数由原 prepare 实际产生。

## 真实执行及核验

- 单用途 `project_inventory.py`：`07253b`，真实 exit 0。
- 原 `full_scope_batch_candidate_v1/prepare.py`：`8a3044`，真实 exit 0，恰一次 CLI；`--max-files 2000 --manifest-bytes 4194304`。完整命令在 `CLI_RECEIPT.json`。
- 独立后置 metadata 核验：`dd4d99`，真实 exit 0；11 refs 前后 bytes/SHA 相同，每次读取 stat 稳定；全部 1072 batch rows 精确等于完整 seal union，路径无重复/前缀冲突。唯一 batch 的编码长度 869,940 B，小于 4 MiB。
- 独立 peer 只读本投影源：`e118ef`，未见阻断性漏洞。所有实际命令均带 `-B`。两份投影输出不是多文件原子事务；若失败必须保留 partial，禁止覆盖重试。

投影只读 seal、唯一 part、ROOT acceptance 和三个冻结工具 source/自身 source；没有 stat、resolve 或打开任何原 raw 路径。closure/directories 仅沿接受链绑定 ref，未打开。冻结 validator 仅由原 metadata helper 加载 source，未调用 validate/scan 或 secret loader。

## Pins

| 文件 | bytes | SHA256 |
| --- | ---: | --- |
| project_inventory.py | 8041 | cc2cf5a8cbe9de93af476b62503dc5b8786d44a850e45342f0e9e39d5e557266 |
| SELECTION.candidate.json | 4884 | a801f8b453373f727ce55ee2b1512511b4a8de310f5b59861bca0c1d8cc626fc |
| inventory.json | 359440 | 506f11ef63485b83b0760e5665a2106aa5a8320ff0391faf0fc786480f8ca978 |
| batches/INDEX.candidate.json | 1746 | a6233cc8d7c71d88a1e901c9255d76db892adccb1d71eeeb393e7eb8b0a052e9 |
| batches/batch-000001.candidate.json | 869940 | 7e0bee3903e8f7a681b9e19bf990a86b1e71cb9c4b5234e5c46cb6cb95fc9a2a |

这里的 `sealed=true` 继承原始证据 seal；不是扫描/打包许可。所有 candidate/spec 仍 `approved=false`、`publication_authorized=false`。下一步仅等待 ROOT 批准明确 spec；本轮未读取 keys，未执行 validator、pack、restore、Git 或网络动作，也没有新建 pipeline driver。
