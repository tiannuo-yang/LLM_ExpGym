# K3 原件 + fixed8 恢复：最薄 composite 公开交付设计

状态：2026-09-09 21:43:33 UTC，仅只读接口/元数据设计。本次只新增本文，不实现 assembler/merge/relocator，不读原件 raw、答案、成绩或 keys，不执行 pack/scan/restore/Git/模型/Slurm。新八项实际数据、seal、合成导出及独立审查尚未形成，本页不捏造它们的 pin、文件数、字节数或成功状态。

## 结论

最薄方案是**一个新的联合 collection INDEX，指向原34个 bundle 的既有位置和未来新增 bundle**。旧 gzip、member INDEX、root INDEX、SOURCE_SCAN、COMPLETE 全部原 bytes 复用，不重新 pack 原705、不重复上传旧数据、不修改原失败 collection。

恢复继续使用原 collection_restore v2；合成分析的路径迁移继续使用原 relocator v2。两段 source 原绝对路径都在同一个旧 workspace 下，relocator 已按完整 workspace-relative member 查唯一 ownership，不要求全部来源在同一个 run_root；因此当前接口不需要新的“双段 relocator”或跨collection恢复框架。

唯一必要的新公开 metadata 是联合 INDEX、增量包和增量 controls 的精确 scope/原件、合成 provenance/费用旁账/分析输出，以及将来对应的外部 pins 和恢复重放收据。ROOT 仍须在实际产物形成后分别授权封存、扫描、pack、发布和 fresh GitHub restore/replay。

## 本次核过的固定基线

路径缩写：WS=/lustrefs/users/chufan.shi/codex_space_tn；P=WS/publication；OP=WS/portable_eval_20260908/source_cohorts/v4/portable_eval_20260908/operations/restart_user_20260909。

读取并重核原公开副本 metadata：

```text
P/k3_full_remote.0bzBaFG7/repo/results/portable-eval-20260908/full_delivery_v5/
  kimi-k3-original-node-failure-20260909/payload/collection/INDEX.json
SHA a78227369423e71e8c4380e46416b8a4ed88464f3e8a502fe1747e7e703103f5
```

该固定 INDEX 声明34 bundles / 65,105 files / 1,521,531,633 original bytes：原 run 33批（batch-000001…batch-000033，64,188文件/1,268,512,973B）+ controls 1批（917文件/253,018,660B）。原705中697完成和8 infra的完整原文件均在既定交付范围；已实际全restore/replay的接受是 ROOT 提供的既有事实，本次没有重做这些操作。

controls/payload/INDEX.json 原 SHA：3877766e19695a7c6ae61b29f167210aeb1b70e4cce8aea5a2c0bc67df4bc424。仅额外读取其明确四页 member metadata，917路径唯一，原页 SHA/bytes 全符：

| member page | bytes | SHA256 |
|---|---:|---|
| part-000001.json | 76084 | cd3950af5a8318c6e5eb8c7b2ea143314af38a325d23d3a92bc8f1f7040d6bd8 |
| part-000002.json | 81657 | 345788bff18e09475635bae844b5ddcf3f6856e6598d172ecb9c2b2122a5d16e |
| part-000003.json | 81668 | 49c2b43fa30003ed72fe160ee62169f8d16be2c482eb4694d684cfb68a20577d |
| part-000004.json | 38760 | d85b3f933ade7efbfa4006c295516c0911b5104b50d331aa7cac1f3318eb4ce5 |

原 controls 已物理包含 AN2 三源码，同一个 bundle 下保持原相对根：

| 完整 workspace-relative member | bytes | SHA256 |
|---|---:|---|
| portable_eval_20260908/source_cohorts/v4/portable_eval_20260908/operations/restart_user_20260909/analysis_candidate_v2/analysis.py | 30377 | 5df8525973261d61b5c3c373945129db22979131e6ce3b586c8913efeed256bf |
| portable_eval_20260908/source_cohorts/v4/portable_eval_20260908/design/formal_export_candidate/converter.py | 28464 | 0261660a38d80c9135efc498f11580ef3fea26de00e6061824e9c9380662547f |
| portable_eval_20260908/source_cohorts/v4/portable_eval_20260908/design/formal_matrix_candidate/planner.py | 26895 | 13914a8341765d0c0ed75812d9b79d2281478b7fc82accef64deaa70a5ead68a |

因此不需在新controls复制这三条 member。就已读917清单而言，原 profile/runtime validation/source_acceptance 及 source_cohorts/v5 源码并不在其中；不能口头说“旧controls有全部source86”。完整联合 scope 形成时，只对实际必需且尚无 owner 的已接受小文件补入 delta；不要为此重新加入整个旧32历史集合或任意历史依赖树。本次没展开33个run包全部 member，也没追索旧32，因此这些未读范围不冒称已再次验证。

## 联合 INDEX 的具体位置：不需要改恢复代码

建议新的 INDEX 放在公共 checkout 的共同祖先：

```text
results/portable-eval-20260908/full_delivery_v5/
  INDEX.kimi-k3-composite-v1.json                # 未来新外部pin，当前不存在
  kimi-k3-original-node-failure-20260909/
    payload/collection/{batch-000001...batch-000033,controls}/...
  <未来K3固定8交付目录>/payload/collection/
    {recovery-batch-000001...,recovery-controls...}/...
```

这只是布局提案，未来目录名尚未实际批准/创建。原34行保留 bundle_id/category/sha256/file_count/original_bytes；只在新联合 INDEX 的 index 字段前添加：

```text
kimi-k3-original-node-failure-20260909/payload/collection/
```

例如原 batch-000001 的新 row.index 为 `kimi-k3-original-node-failure-20260909/payload/collection/batch-000001/payload/INDEX.json`，其原 root INDEX SHA bc8b155b0d14648b5c05f997f578b0c07eb39ba5db7be90bf6626bfe91a827a2 不变。原 controls bundle_id 继续是 controls，SHA3877766e…不变；新 bundle_id 使用唯一且不冲突的 recovery-* 名称。

依据 `P/collection_restore_candidate_v2/restore_collection.py:33–101`：入口 INDEX 文件名不要求恰为 INDEX.json；逐row.index相对该文件父目录解析，:58–61仅要求规范向下相对路径、末尾payload/INDEX.json、包根不重复/不嵌套。因此可直接指向原目录，**不需要复制旧 archive 到新collection子目录**。:83和:96全局检查原member去重/前缀冲突。

确认的接口限制：不能把新联合 INDEX 放进新交付子目录，再用 `../旧兄弟目录` 指原包；原relative规则拒绝 `..`。不能用symlink/hardlink捷径替代公开原路径身份，不能把原whole-file collection INDEX本身作为一个 shard-delivery bundle嵌套。联合 INDEX 应平铺34个旧bundle行加实际delta行，而非嵌套collection。

用户从一个 fresh GitHub checkout 保留上述共同目录后，以新外部联合 INDEX SHA 执行原restore即可。不应依赖用户原先本地已经恢复过K3，也不通过本地旧恢复目录冒充 fresh公共副本。下载/checkout旧blob与重复pack/重复上传是不同事：前者是独立重放需要，后者可避免。当前公开工具的具体导航/路径须在未来发布清单固定，本次没有Git/remote查询。

## 增量范围与唯一 ownership

新增数据分为两个有界集合，不按答案/分数过滤：

1. 新恢复run的完整封闭原文件。包括全部实际first2/remaining6 stage原件、GO.bound、source/verify started与capture/log、全部result/raw/wire/terminal evidence、成功/缺答/infra/未开始状态及最终execution。不是只拿38个结果JSON或只取新成功raw。若实际只首2失败或后6部分闭合，保留那次明确partial，不虚构满8文件数。
2. 新增精确controls。包括实际新plan/两次GO/首2ROOT工程验收/最终ROOT接受、新run seal/inventory parts/closure与operator、实际新部署/资源/ready/排空/释放的公开证据、已接受recovery/merge/sealer代码与有限CPU/peer/ROOT证据、唯一实际merge输出、fresh独立post-analysis审阅和最终合成报告/交付声明。收据放原run外，不改变已封run；不把key值/文件、活跃文件、mutable PLAN或正在生成的发布旁证放入封闭scope。

精确去重以完整workspace-relative path为主键，不以basename、iid或SHA为主键：

- 若候选新control的path已由原917或原33run包拥有，且bytes/SHA完全相同：复用原bundle owner，在新控制关系表引用，不再pack一份。原execution既在原run包中，也不要再复制进controls。
- 同path但SHA/bytes冲突：拒绝，不覆盖旧bundle、不改名假装同一原件。确有新的修订应先形成新的独立原文件路径及revision说明，再获ROOT接受。
- 不同path、相同bytes：仍是两个物理身份，不能仅按SHA合并而破坏source/ref归属。
- 新run与旧run命名空间不同；logical/IID复用合法，member绝对归属必须不同。Pool一个N4只属一个attempt，不能把旧部分agent与新agent混装为一个有效池。

不要重建泛用inventory/authority框架。新run已有闭合sealer可复用；发布metadata只需将实际seal分片rows按完整workspace-relative path投影成已有 `sealed-publication-file-inventory-v1`，声明issuer/authority必须来自ROOT实际接受，不能只改schema贴标签。`P/full_scope_batch_candidate_v1/prepare.py:33–50` 精确要求该publication schema，不能直接喂recovery run的不同inventory schema。再复用原metadata分批、ROOT精确scope、原scanner/pack/restore流程；只对delta做新payload工作。

既有 source/runtime/profile小闭包若原34中确实无owner，需按明确已有pin物理补入新controls（或一个精确不重叠小bundle），不能要求fresh用户依赖未列明的旧32/Git之外历史包。AN2描述性重放不需要模型权重、实际服务或完整HPO数据库；若另称可从raw重抽取/重新评分，则是不同且本任务未授权的闭包，不能顺带扩展。

## 合成 AN2 重放：沿原接口，不重跑 merge/scorer

merge v2在既定两段输入上生成：原AN2十输出，加manifest.json/records.json/oracle.json/input_pins.json/source_index.json、COMPOSITE_PROVENANCE.json、ALL_ATTEMPT_COST_LEDGER.json、EXPORT_INDEX.json。按代码是18个预定输出名，不代表当前已存在18个实际文件；实际逐件SHA/bytes/完整输出集合待唯一merge结束后确定。

merge v1/v2 README与 `merge.py:410–418` 保持：设计705/783/1881，原697固定来源，固定新8无论低分/unknown/infra/未开始都不回退旧partial；manifest candidate_id是历史设计身份，provenance明确not_a_single_fresh_705_run。713只是“705旧+全部8实际开始时”的attempt数，不是样本数；若只新2则707。发布导航和报告必须明示两段，不以归档名字暗示新全705单次运行。

五个输入均按原bytes封在增量controls。source_index是 `logical-relative-key -> 实际原绝对路径字符串`，COMPOSITE_PROVENANCE.effective_source_map另存path/SHA/bytes/segment/run_id/invocation_id/attempt_ordinal。不能将rich dict直接交原AN2。

完整联合collection先用原恢复器全量restore并独立接受后，原 `analysis_relocation_candidate_v2/relocate.py:112–183,187–254` 可以直接复用：

- old_workspace仍是完整 WS；restore_root是此次联合恢复新目录，collection三pins换为这次新COLLECTION_INDEX/OWNERSHIP_INDEX/COLLECTION_COMPLETE原bytes。
- original_inputs五个member全部指向**此次合成export**的完整workspace-relative位置及原pins，不能选旧K3 export或GLM。
- 原source_index中每个old absolute path相对WS转换为member，逐一查联合ownership，保持key原样。原697指旧bundle，新8实际有source的行指新bundle；不做全局旧runroot字符串替换，不按同内容择路。
- 原程序核record.source_sha256并集恰等索引keys、每源byteSHA/size、五输入互绑，生成新的plain source_index.relocated.json及MAPPING_EVIDENCE.json。原输入、raw/source、run_id、provenance和原AN2输出不改。若新infra没有对应source，按合成records的明确缺项处理，不从旧partial补它。
- 现relocator不解析rich composite provenance，也不再次执行merge选择审计。实际合成导出须先经ROOT/fresh独立审阅；交付复核再把MAPPING_EVIDENCE的key/path/SHA/bytes逐项与封闭rich map比对，保留segment身份。这只需一个有界metadata对账，不必改relocator科学逻辑或重跑merge。

AN2三代码已在原controls同bundle。联合restore保留旧bundle_id=controls后，可直接把 `RESTORE/controls/payload/portable_eval_20260908/source_cohorts/v4/portable_eval_20260908` 当 ANALYSIS_ROOT，保持analysis→converter→旧planner相对路径。无需新拷贝三件或换成新planner7f4ff5；旧planner13914a…才是原AN2依赖。

随后用户另执行原AN2 CLI：

```text
python3 -B ANALYSIS_ROOT/operations/restart_user_20260909/analysis_candidate_v2/analysis.py
  --manifest RESTORED_COMPOSITE/manifest.json
  --records RESTORED_COMPOSITE/records.json
  --oracle RESTORED_COMPOSITE/oracle.json
  --pins RESTORED_COMPOSITE/input_pins.json
  --source-index FRESH_RELOCATED/source_index.relocated.json
  --output-dir FRESH_ANALYSIS_OUTPUT
```

这是说明而非本次实际命令；所有路径/pins待未来真实产物。完整比较原AN2十个输出文件与此合成export内十文件；不只比六主终点。它是重放已报告统计，不重新评分、不从raw重抽取，不单凭exit0升级fresh科学审计。

## 失败与费用原件必须另有完整闭包

ALL_ATTEMPT_COST_LEDGER.requests[].source_ref覆盖两段全部persisted raw，按(run_id,request_id)去重；invocation_attempts保留旧705及新8slots，未开始明确false。旧8失败/63 error原件与旧费用不能因新8选入而消失。reasoning已包含在output中；unknown不补0，未落盘请求/供应商实际账单范围不凭归档推断。

原AN2费用表只描述effective selected scope；完整attempt账必须单列、可由联合collection完整恢复的两段raw和对应indices/报告校对。relocator只流读selected sources，不能证明所有失败raw费用已审完；collection restore全量byte验证也不是usage语义审计。费用fresh复核与模型报告fresh复核各需实际原件接受，不能通过本设计冒名完成。

## 最少待实际形成的常量与 identity

| 项目 | 当前可固定 | 必须继续 pending |
|---|---|---|
| 原bundle组 | 34，65105files，1521531633B；原34行全部外部pin | 本次不重做旧全量payload检查 |
| 新run | fixed8设计/两stage schema，原科学参数 | 实际started/closed/unknown/infra、原件数/bytes/raw数量、seal parts/count/SHA、所有GO/闭合接受 |
| 新controls | 完整workspace-relative namespace及去重规则 | 与全部oldowners精确difference后的成员list/count/bytes/pins、许可/隐私scanner接受 |
| 联合INDEX | 原schema与共同祖先布局，old34原字节不改 | 新rows、全局count=65105+delta_files、bytes=1521531633+delta_bytes、bundle_count=34+delta_bundles、新外部SHA |
| 合成结果 | merge v2接口、5inputs/plain index/rich provenance/全费用旁账 | 实际18名集合及SHA、有效source key数量（不能沿用旧2215）、报告及独立审阅 |
| 新重放 | 原restore+relocator+AN2代码身份 | fresh GitHub commit/精确文件集、全restore exit/COMPLETE/pins、映射和AN2全部输出对比 |

保留原工具限制：collection最多512 bundles、metadata累计256MiB、每metadata8MiB；whole member100MiB、256files/shard、4096shards/bundle、48MiB compressed/256MiB expanded；relocator五输入/每source和派生输出均100MiB。当前不能根据“只八项”保证metadata/大cost-ledger必在上限内，实际大小到齐后核，超限要报告，不能静默扩限或丢失败记录。

恢复工具与其common/restore/scanner需按原相对布局物理存在于fresh公开副本；无需known-secret值，公共恢复known_secret_sources_checked=0。发布者原扫描与公共恢复分别说明。不得把本地已恢复目录、只复制member metadata的目录或private凭据当作可公开standalone包。

## 精确代码/文档 pins 与本次边界

| 文件 | SHA256 |
|---|---|
| P/collection_restore_candidate_v2/restore_collection.py | 24a2ff6da7521c7920ce50ea7491aa682310e78874ba2d552649e9d2d88bb6b2 |
| 同README.zh.md | 21f33b6fcf9265d93c68471eaa560d94f9f2d68ecbf3e62c04f91e30b6710d1c |
| P/full_scope_batch_candidate_v1/prepare.py | 77a69230c7ef2fd9de1767c63d237f8514411372ce10eac902d71b1d2af65c60 |
| OP/analysis_relocation_candidate_v2/relocate.py | 94f866d34a07eecd0062c3c81698597d7b5845abab75e5d2758449d5f1b61f35 |
| 同README.zh.md | cec19a92f7f961e7cc15af7961de100d47f400ac553892d91e9a6442b9c0427e |
| OP/k3_eight_infra_merge_candidate_v2/merge.py | ccad452db74e9840042520699f0cfa2f0f6a9ef1737a141215598a911ac554ad |
| 同projection.py | 8f26d3237672f0d06c5c6a8436977616c5aee29c806b58f460e2bf3285ea6566 |
| 同README.zh.md | 1e9fd0bca65188fb2dd45f1ffbd0713abc1532056906aea4b916bf30a0edeaba |
| OP/k3_eight_infra_merge_candidate_v1/README.zh.md | e426661720b527a236e743e41c98f57a9a2ade91f597b36f4b9a57aff2dedcb0 |

原restore源码固定依赖：common.py7147524d5799dc1264f088518db19251c5f906bc2da501854ce279f56d73263e；restore.py ec20a0e22c8f810b09e894e0ddc6cc8dec114a66be4fe23cab8a55f3b62ac710；validate_bundle_v2.py aea61a9309cb6069240b90e0ca706403b0f21b3e7f77a2f88d462e6ba8734116。本次只从固定源码声明读取这些pins，未运行依赖或再读全部payload。

依据：d50c3f读merge v1/v2和relocator README；d316d4完整读collection restore README/代码；22a9f5读并核原INDEX及controls四页metadata并只投影AN2相关成员；a6b81a读relocator ownership/relocate必要代码；22cd7a只核所列工具/文档SHA。早期两个猜测的publication目录不存在，rg exit2（72c16e）原工具记录保留，随后按旧sealer源码定位P=WS/publication；没有将找不到路径冒充缺失公开数据。

没有实现或执行任何新恢复/合并/发布逻辑；没有follow所有proof refs，没有读取压缩包、真实raw/答案/分数/key，没有scan/pack/restore/Git操作、测试或新模型调用。新数据和新联合collection一切实际成功声明仍pending。
