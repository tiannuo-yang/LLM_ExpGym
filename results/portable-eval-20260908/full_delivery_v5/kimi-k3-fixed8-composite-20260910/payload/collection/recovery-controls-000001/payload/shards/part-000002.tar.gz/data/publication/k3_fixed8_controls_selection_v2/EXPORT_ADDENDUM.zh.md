# Export 闭合补充：当前主映射为 WITH_EXPORT

ROOT在355条候选已交peer后明确提供已闭合18export及两份ROOT终态记录。本补充不改 CANDIDATE_MAPPING.json（SHA853c99c…）或原README（58a134c…），不抹除它们在当时标记merge pending的事实。最终本候选INDEX的primary_mapping指向 CANDIDATE_MAPPING_WITH_EXPORT.json。

当前主映射 SHA43f8f141ad1ad7e3aeb25d73ab56a1b93b9c7dcf852434e902a0bbdc4cf8893c，348820字节：

| 当前映射 | 文件数 | 字节 |
|---|---:|---:|
| 新 control 候选 | 368 | 113997774 |
| 旧owner精确复用 | 7 | 8580841 |
| 当前合计 | 375 | 122578615 |

相对355条只新增20项，无删除、替换或重新选择原条目。18份export共75085889B，来源固定 OP/actual_k3_fixed8_composite_export_v2_refshape/EXPORT_INDEX.json，SHA9c54d4055dcac270f5c3971f4e3bc1694c96fe29416ee43f15d20167b8146eb0，1991B；其中17份完整bytes/SHA逐条核对，EXPORT_INDEX自身也计入18。目录exact18、全regular file、SHA/stat前后稳定。只把17导出payload当字节流hash，不解析oracle/records/results等科学内容。

两份额外ROOT闭合控制：

- MERGE_V2_REFSHAPE_EXIT.json：1729B，b13b3732b7b4194fd7971d82b17e3a2e2e28f68ca1ae1a816b4f48f4235ee4c4。
- MERGE_V2_ACTUAL_ACCEPTANCE.json：2167B，f6eb6eaa63e64edd328ffec2042947767e63eaa52f3cc05d58ad00ec7e491106。

两者记录原merge自然exit0及文件身份/数量接受，不是科学结果接受。原首次GO ref-shape失败和原GO也仍在355条中；没有改代码、原raw、评分或选择来源。ROOT接受文件报告source_index_keys=2247，此选择任务没有独立解码source_index再次计数，不冒称亲核。

新增20共75089785B，全部不在旧65105 ownership或原355路径里。核原明确页metadata后按完整WS相对路径排查冲突；新RUN前缀仍严格排除。总375条中的5组不同路径同内容仍分别保留，不根据SHA去重。没有把原697与fixed8的合成结果描述为新的705次单段实验。

实际选择工具9b8ecf自然exit0，20件在完成后再核相同bytes/SHA；独立peer只读取本combined映射和EXPORT_INDEX等已指定元数据来核20项差集与ownership，不读取17payload，也不承担科学复核。完整实际工具结果/peer refs见 CHECKS.json。

以下仍明确pending：fresh科学和全部attempt费用复核、最终合成报告及结论之后的独立逻辑复核、未来新增ROOT接受、最终controls封存/隐私scan/pack/联合INDEX/fresh公共恢复与AN2重放。本次selection及peer自身旁证也待ROOT最终精确枚举，未用自引用inventories混入当前375文件。

最终delta member/bundle/联合数量保持null，未收未冻结PREPARATION，GLM proof不混入K3 science raw。整个包仍只提供有限公开provenance和分析重放所需的选择候选，不承诺离线重serve所有环境；未获最终seal/scan/pack/Git许可。
