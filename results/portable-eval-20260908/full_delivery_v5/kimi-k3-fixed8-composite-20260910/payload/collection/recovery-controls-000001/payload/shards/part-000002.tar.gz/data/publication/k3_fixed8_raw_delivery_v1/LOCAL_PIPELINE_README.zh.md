# K3 fixed8 raw：本地交付已闭合

ROOT `ROOT_PIPELINE_GO.json`（05caeb38…）授权的单次本地 pipeline 已完成；原件 **1072 / 34,520,799 B**，全量纳入、无结果筛选，旧 K3 34 包和 controls 均未触碰。

| 原工具 | 实际 session | start → natural exit 0 |
| --- | ---: | --- |
| validator | 7164 | 9e57b6 → e88a9d |
| pack | 18119 | f1c8ac → 85ff49 |
| restore | 84484 | b1c2f1 → c0005a |

三个原 CLI 各且仅调用一次、严格串行；`taskset -c 0 /usr/bin/python3 -B`，Python 3.10.12。只有原工具加载 GO 绑定的四件 key，operator/gates 没有读取、stat、hash 或打印 key 内容；CLI 记录用保序占位符引用原 GO 的四路径，不复制路径或密钥。全部实际命令、等待和 stdout 见 `ACTUAL_CLI_RECORDS.json`，不存在待 reap 进程。

扫描 gate `ba24c6` exit 0：0 findings、0 advisories、4 sources、全部 required stages 满足，1072 rows 精确等于 approved spec/inventory；spec/tool pins 前后不变。闭合 lock 的实际 SHA `eb2a89105c1a25fd99df7372474cfaca2ee3f48c0ca108237afc15183e3e5433` 随后才传给 pack。

打包得到 5 个 whole-file gzip shards，压缩原件归档共 6,178,203 B。gate `eed5ef` exit 0 核全部 tar 文件 SHA/bytes、member union、bundle exact tree 和 COMPLETE。`FILES.json` 是每个 tar 的归档成员清单，不计作原始实验文件。

- bundle INDEX：2309 B，`feacce1769ae8fa7358d753cee2b5d33994c6527407e8b7effe0d7f6399405ae`。
- bundle COMPLETE：300 B，`507157ce637dd16fa9b9cb475553301b4456c66c1b6803213c5213c34fadf8b5`。
- restore COMPLETE：338 B，`7fac15cc20bf9670296a247759c733095c3603d0367bcd42beece22ad925125d`。

独立 whole-byte check `77054/a690ff → 2829ff` 自然 exit 0，开始 00:36:58 UTC、结束 00:37:03 UTC。复用已冻结且全文重读的 GLM controls verifier 的纯只读函数，不调用其旧 main。1072 source +1072 restored 全文件流式 SHA/bytes 与原 seal 均相等，source mode/device/inode/mtime/ctime/size 也与 seal 相等；2,171 个读入 refs 最终 stat 保持，17 件 metadata 最后重新核 bytes/SHA；完整 source/bundle/restore 文件和目录集合前后稳定。证明为 `WHOLE_FILE_COMPARISON.json`。

恢复树为 COMPLETE +1072 原件，共1073常规文件；恢复路径派生165个目录（含根），不声称恢复原159个目录的 POSIX metadata。原件行流式 digest 为 `4a0890ef87ee92f5e9dfae82d253bc8bcad770d23815a025d8730653f47a08c4`，不是对 rows 数组一次JSON编码的digest。

本轮没有失败或自动重试，没有删改原件、原 spec、冻结工具或输出限制。此页与 `LOCAL_OPERATOR.json` 是本地交付收据，**不是公开发布/公开恢复通过，也不是科学结论通过**。未执行 Git、网络、模型调用，未解析 raw 内容或重算成绩；后续须由 ROOT 独立接受并另行授权 controls/union/public replay。
