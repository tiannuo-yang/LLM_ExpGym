#!/usr/bin/env python3
"""Project one accepted closed raw seal; metadata only, no pipeline driver."""
import hashlib
import importlib.util
import json
from pathlib import Path
import stat

W = Path('/lustrefs/users/chufan.shi/codex_space_tn')
OP = W / 'portable_eval_20260908/source_cohorts/v4/portable_eval_20260908/operations/restart_user_20260909'
OUT = W / 'publication/k3_fixed8_raw_delivery_v1'
SEAL = OP / 'sealed_restart_runs_v1/kimi-k3-fixed8-recovery-20260910-v2/inventory.json'
SEAL_SHA = 'b1d1dd3f17b4eb6ccd9cda4026e02f3423674a84b2af15d58db263921794a5ce'
ACCEPTANCE = OP / 'k3_recovery_root_v1/SEAL_V2_ACCEPTANCE.json'
ACCEPTANCE_SHA = 'd4b3cf79b91d9d3ac41bc8d1c33272bc4404f8035538c08fca8e1679d2bae219'
RUN = W / 'portable_eval_20260908/source_cohorts/v4/portable_eval_20260908/formal_runs/restart-20260909-v5-kimi-k3-infra8-recovery'
PREPARE = W / 'publication/full_scope_batch_candidate_v1/prepare.py'
TOOLS = {
    str(PREPARE): '77a69230c7ef2fd9de1767c63d237f8514411372ce10eac902d71b1d2af65c60',
    str(W / 'publication/shard_delivery_candidate_v2/common.py'): '7147524d5799dc1264f088518db19251c5f906bc2da501854ce279f56d73263e',
    str(W / 'publication/validate_bundle_v2.py'): 'aea61a9309cb6069240b90e0ca706403b0f21b3e7f77a2f88d462e6ba8734116',
}
for path, sha in TOOLS.items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == sha, 'frozen_tool_identity'
loader = importlib.util.spec_from_file_location('frozen_metadata_prepare', PREPARE)
b = importlib.util.module_from_spec(loader)
loader.loader.exec_module(b)
c = b.c
observed = {}


def metadata(path, sha, size=None, again=False):
    path = c.lexical(path)
    before = path.lstat()
    c.need(stat.S_ISREG(before.st_mode), 'metadata_not_regular')
    raw = b.validator.stable_read(path, limit=c.MEMBER)
    after = path.lstat()
    signature = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    c.need(signature(before) == signature(after), 'metadata_stat_changed')
    c.need(c.sha(raw) == c.checksum(sha) and (size is None or len(raw) == size), 'metadata_pin_changed')
    ref = {'path': str(path), 'bytes': len(raw), 'sha256': sha,
           'stat_signature_decimal': [str(v) for v in signature(before)]}
    if again:
        c.need(observed[str(path)] == ref, 'metadata_after_changed')
    else:
        c.need(str(path) not in observed, 'duplicate_metadata_read')
        observed[str(path)] = ref
    return c.strict_json(raw)


def main():
    for name in ('inventory.json', 'SELECTION.candidate.json', 'batches'):
        c.fresh(OUT / name)
    seal = metadata(SEAL, SEAL_SHA, 7146)
    acceptance = metadata(ACCEPTANCE, ACCEPTANCE_SHA)
    c.need(acceptance['issuer'] == 'ROOT' and acceptance['passed'] is True
           and acceptance['inventory_ref'] == {'path': str(SEAL), 'sha256': SEAL_SHA, 'bytes': 7146}, 'root_seal_acceptance')
    c.need(seal['schema_version'] == 'restart-closed-run-inventory-v1' and seal['run_root'] == str(RUN), 'wrong_sealed_run')
    for key, expected in {'file_count': 1072, 'total_bytes': 34520799, 'directory_count': 159,
                          'expected_invocations': 8, 'started_count': 8, 'unstarted_count': 0}.items():
        c.need(type(seal[key]) is int and seal[key] == expected, 'wrong_sealed_count')
    c.need(seal['original_execution_complete'] is True and seal['original_score_complete'] is True
           and seal['full_second_read_equal'] is True, 'original_completion_identity')
    c.need(len(seal['file_parts']) == 1, 'wrong_part_count')
    c.need({k: seal['closure_ref'][k] for k in ('path', 'bytes', 'sha256')} == acceptance['closure_ref'], 'closure_binding')
    rows = []
    for number, ref in enumerate(seal['file_parts']):
        c.need(ref['path'] == str(SEAL.parent / ('inventory.part%03d.json' % number)), 'unexpected_part_path')
        part = metadata(ref['path'], ref['sha256'], ref['bytes'])
        c.need(type(part) is list and type(ref['file_count']) is int
               and 0 < len(part) == ref['file_count'] <= 2000, 'part_file_count')
        c.need(type(ref['total_bytes']) is int and sum(r['bytes'] for r in part) == ref['total_bytes'], 'part_bytes')
        for row in part:
            relative = b.relative(row['relative_path'])
            absolute = RUN / relative  # Lexical only: never resolve/stat/open a raw path.
            c.need(str(absolute) == row['path'] and type(row['mode']) is int and stat.S_ISREG(row['mode']), 'original_path_or_type')
            path = absolute.relative_to(W).as_posix()
            b.relative(path)
            c.number(row['bytes'], c.MEMBER, 'invalid_original_size')
            c.checksum(row['sha256'])
            rows.append({'path': path, 'bytes': row['bytes'], 'sha256': row['sha256']})
    rows.sort(key=lambda row: row['path'])
    c.need(len(rows) == seal['file_count'] and sum(r['bytes'] for r in rows) == seal['total_bytes'], 'full_raw_union_count_bytes')
    c.need(len({r['path'] for r in rows}) == len(rows), 'duplicate_raw_path')
    c.no_path_prefixes(r['path'] for r in rows)
    inventory = {'schema_version': b.INPUT_SCHEMA, 'issuer': 'ROOT', 'sealed': True,
                 'authority_ref': {'path': SEAL.relative_to(W).as_posix(), 'sha256': SEAL_SHA}, 'files': rows}
    raw = c.encoded(inventory)
    c.need(len(raw) <= c.MEMBER, 'inventory_size_limit')
    for ref in list(observed.values()):
        metadata(ref['path'], ref['sha256'], ref['bytes'], again=True)
    for path, sha in TOOLS.items():
        c.need(hashlib.sha256(Path(path).read_bytes()).hexdigest() == sha, 'frozen_tool_after_changed')
    selection = {
        'schema': 'k3-fixed8-raw-metadata-selection-v1', 'candidate': True, 'approved': False,
        'source_seal_ref': observed[str(SEAL)], 'root_seal_acceptance_ref': observed[str(ACCEPTANCE)],
        'metadata_inputs_read': list(observed.values()), 'workspace': str(W), 'original_run_root': str(RUN),
        'inventory_ref': {'path': str(OUT / 'inventory.json'), 'bytes': len(raw), 'sha256': c.sha(raw)},
        'file_count': len(rows), 'original_bytes': sum(r['bytes'] for r in rows),
        'original_execution_complete': seal['original_execution_complete'], 'original_score_complete': seal['original_score_complete'],
        'started_count': seal['started_count'], 'unstarted_count': seal['unstarted_count'],
        'directory_count_inherited_not_original_files': seal['directory_count'],
        'closure_ref_bound_not_opened': acceptance['closure_ref'],
        'directories_ref_bound_not_opened': {k: seal['directories_ref'][k] for k in ('path', 'bytes', 'sha256')},
        'ordered_rows_sha256': c.sha(c.encoded(rows)), 'all_sealed_raw_rows_included': True,
        'controls_included': False, 'old_k3_members_repacked': False, 'paths_changed': False,
        'original_payloads_read_or_statted': False, 'metadata_before_after_sha_bytes_stat_equal': True,
        'security_scan_performed': False, 'known_secrets_read': False, 'pack_or_restore_performed': False,
        'publication_authorized': False, 'publication_performed': False,
        'frozen_tools': TOOLS, 'projection_sha256': c.sha(Path(__file__).read_bytes()),
        'note': 'All 1072 original rows are included irrespective of result; no score or failure selection. This is metadata projection, not a new seal or scientific qualification. Batch count is left to the separate unchanged prepare CLI.'}
    selection_raw = c.encoded(selection)
    c.write_new(OUT / 'inventory.json', raw)
    c.write_new(OUT / 'SELECTION.candidate.json', selection_raw)
    c.sync_directory(OUT)
    print(json.dumps({'passed': True, 'file_count': len(rows), 'original_bytes': selection['original_bytes'],
                      'inventory_ref': selection['inventory_ref'],
                      'selection_ref': {'path': str(OUT / 'SELECTION.candidate.json'), 'bytes': len(selection_raw), 'sha256': c.sha(selection_raw)},
                      'security_scan_performed': False, 'raw_read_or_stat': False}, sort_keys=True))


if __name__ == '__main__':
    main()
