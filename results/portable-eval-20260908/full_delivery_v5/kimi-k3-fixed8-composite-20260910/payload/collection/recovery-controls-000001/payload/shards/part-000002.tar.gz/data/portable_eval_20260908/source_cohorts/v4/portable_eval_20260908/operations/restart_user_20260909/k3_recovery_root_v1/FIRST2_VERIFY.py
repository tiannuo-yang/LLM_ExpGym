from pathlib import Path
import json, hashlib, importlib.util
from datetime import datetime, timezone
W=Path('/lustrefs/users/chufan.shi/codex_space_tn')
OP=W/'portable_eval_20260908/source_cohorts/v4/portable_eval_20260908/operations/restart_user_20260909'
R=OP/'k3_recovery_root_v1'
code=OP/'k3_eight_infra_recovery_candidate_v1/recovery.py'
assert hashlib.sha256(code.read_bytes()).hexdigest()=='d152f716d27c570f1fc257a914953b7ef76411a5582f44d8a10e80dc812965a5'
spec=importlib.util.spec_from_file_location('root_first2_readonly_recovery',code)
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
plan_ref={'path':str(OP/'compiled_restart-20260909-v5-kimi-k3-infra8-recovery/plan.json'),'sha256':'6daf5455100de2e4cef8adcdc8fd651e616b4fc653fc4b8e36e326f6abad97ea'}
plan=m.read_json(plan_ref)
run=Path(plan['config']['output_root']); stage=run/'stages/first2_only'
stage_ref={'path':str(stage/'execution.json'),'sha256':'b4817ff1280b7cb9189770ac2d1c0b55bca1c571e507fe3d7cb31640d3c477af'}
v=m.read_json(stage_ref)
go_ref={'path':str(R/'FIRST2_GO.json'),'sha256':'d61e057195f74d983ba94cb196ba45a0bec5cfd97eeb311e867724397515e9b2'}
go=m.read_json(go_ref); started=json.loads((stage/'STARTED.json').read_bytes())
assert v['schema_version']==m.STAGE_SCHEMA and v['stage']=='first2_only' and v['mode']=='infra_recovery_exact8'
assert v['plan_ref']==plan_ref and v['go_ref']==go_ref and v['run_id']==plan['config']['run_id']
assert v['deployment_ref']==plan['config']['deployment_ref'] and v['allocation_id']=='1203933'
assert v['original_plan_ref']==plan['original_plan_ref'] and v['recovery_scope_ref']==plan['recovery_scope_ref']
assert v['producer_code_refs']==plan['producer_code_refs']
for ref in v['producer_code_refs']: m.public_ref(ref)
assert v['execution_complete'] is True and type(v['local_workers']) is int and v['local_workers']==0
assert v['provider_quiescence_proven'] is False and v['score_not_used_for_stage_selection'] is True
assert type(v['score_complete']) is bool and v['stop_reasons']==[] and v['unstarted_invocation_ids']==[]
assert v['started_invocation_ids']==m.FIXED_IDS[:2] and len(v['reports'])==2
assert v['parent_pid']==started['pid']==1515685 and v['parent_ppid']==started['ppid']==1213245
assert started['stage']=='first2_only' and started['plan_ref']==plan_ref and started['go_ref']==go_ref
assert started['bound_go_ref']==m.s.ref(stage/'GO.bound.json')
assert (stage/'GO.bound.json').read_bytes()==Path(go_ref['path']).read_bytes()
expected=sorted(v['closed_file_inventory']+[stage_ref],key=lambda r:r['path'])
assert len(expected)==184 and m.l.safe_tree(run)==expected
assert not (run/'execution.json').exists() and not (run/'stages/remaining6_once').exists()
byid={x['invocation_id']:x for x in v['reports']};assert len(byid)==2 and set(byid)==set(m.FIXED_IDS[:2])
pids={v['parent_pid']}; receipts=[]; nraw=0; nwire=0; nterm=0
for j in plan['jobs'][:2]:
 iid=j['invocation_id']; wrapped=byid[iid]; report=wrapped['report']; log=Path(j['log_dir'])
 assert report['invocation_id']==iid and wrapped['decision']==m.d.terminal_decision(j,report) and wrapped['decision']['continue'] is True
 assert all(report[k] is True for k in m.d.EVIDENCE_FIELDS)
 assert report['terminal_status']==m.l.terminal_status(j)
 status=report['terminal_status']; nterm+=status['reported_model_terminals']
 assert report['artifacts']==m.l.safe_tree(j['output_dir'])
 assert {r['path'] for r in report['artifacts']}==set(j['expected_files'])
 assert report['original_terminal_evidence']==m.l.safe_tree(j['terminal_evidence_dir'])
 assert report['verification_terminal_evidence']==m.l.safe_tree(run/'verification_evidence'/iid)
 capture=json.loads((log/'source_capture.json').read_bytes()); assert capture==report['source_capture']
 assert type(capture['exit_code']) is int and capture['exit_code']==0
 assert all(capture[k] is True for k in ('capture_complete','child_started','drain_proven','stdout_eof_observed','wait_returned'))
 assert hashlib.sha256(Path(capture['log']).read_bytes()).hexdigest()==capture['sha256']
 for name in ('source_started.json','verify_started.json'):
  a=json.loads((log/name).read_bytes());assert a['invocation_id']==iid and a['stage']=='first2_only' and a['ppid']==v['parent_pid']
  assert type(a['pid']) is int and a['pid']>0; pids.add(a['pid'])
 reservation=json.loads((log/'reserved.json').read_bytes())
 assert reservation['invocation_id']==iid and reservation['stage']=='first2_only' and reservation['plan_ref']==plan_ref and reservation['go_ref']==started['bound_go_ref']
 verification=m.read_json(report['verified_resume_ref'])
 assert verification['schema_version']=='restart-source-verified-resume-v1' and verification['invocation_id']==iid and verification['passed'] is True
 assert type(verification['source_exit_code']) is int and verification['source_exit_code']==0
 assert verification['forbidden_model_attempts']=={'construction':0,'generation':0}
 assert all(type(x) is int for x in verification['forbidden_model_attempts'].values())
 assert verification['model_calls_forbidden'] is True and verification['independent_source_cli_resume'] is True
 audit=m.read_json(report['raw_audit_ref'])
 assert audit['schema_version']=='restart-raw-wire-audit-v1' and audit['verified'] is True and audit['errors']==[]
 raw_files=m.l.safe_tree(j['dump_dir']); wire_files=m.l.safe_tree(log/'wire')
 assert sorted([{'path':r['path'],'sha256':r['sha256']} for r in audit['inventory']],key=lambda r:r['path'])==sorted(raw_files+wire_files,key=lambda r:r['path'])
 for r in audit['inventory']: assert Path(r['path']).stat().st_size==r['bytes']
 for r in raw_files:
  raw=json.loads(Path(r['path']).read_bytes()); assert type(raw['pid']) is int and raw['pid']>0; pids.add(raw['pid'])
 counts=audit['counts']; assert counts['clients']==j['expected_model_terminals'] and counts['provider_aborts']==0 and counts['wire_attempts_without_readable_raw_lower_bound']==0
 assert counts['raw_files']==len(raw_files)==counts['joined_attempts']==counts['wire_attempt_starts']==counts['wire_attempt_terminals']
 nraw+=len(raw_files);nwire+=len(wire_files)
 receipts.append({'invocation_id':iid,'terminal_status':status,'decision':wrapped['decision'],'raw_counts':counts,'source_capture_ref':m.s.ref(log/'source_capture.json'),'verified_resume_ref':report['verified_resume_ref'],'raw_audit_ref':report['raw_audit_ref']})
assert nterm==5 and nraw==46 and nwire==97
assert all(not Path('/proc',str(pid)).exists() for pid in pids)
assert m.l.safe_tree(run)==expected
print(json.dumps({'schema_version':'root-first2-engineering-check-v1','issuer':'ROOT','passed':True,'verified_utc':datetime.now(timezone.utc).isoformat(),'first_stage_execution_ref':stage_ref,'plan_ref':plan_ref,'deployment_ref':plan['config']['deployment_ref'],'allocation_id':'1203933','caller_actual_exit':{'session_id':53399,'start_chunk':'eaa01a','exit_chunk':'86cc6c','exit_code':0},'whole_closed_file_count':184,'full_snapshot_sha_comparisons':2,'all_registered_pids_absent':sorted(pids),'invocations':2,'model_terminals':nterm,'raw_requests':nraw,'wire_events':nwire,'reports':receipts,'score_not_used_for_acceptance':True,'provider_quiescence_proven':False,'no_model_or_scorer_or_resume_called':True,'key_files_read':0,'remaining6_started':False},ensure_ascii=False))
