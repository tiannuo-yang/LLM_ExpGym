# Restart 原始证据封存器（准备阶段）

仅标准库的独立只读入口；不导入 launcher、模型客户端、评分器、resume 或授权模块。旧 `retired_k3_epoch000_seal_v1` 不变。实际封存须等 ROOT 指定终态输入后调用，本目录的 CPU 测试不构成真实运行验收。

## 输入和调用

`seal.py --plan PATH --plan-sha256 SHA --execution PATH --execution-sha256 SHA --run-root ROOT --output-dir NEW`，可重复附加 `--control-ref PATH SHA`。所有路径必须绝对、无软链；NEW 必须不存在、父目录存在，且与 run root 无包含关系。plan/execution 必须是 ROOT 显式给出的原文件 refs。额外 control ref 只读取该单文件，不递归跟随它的 refs；不得提供凭据文件。程序不会追踪 plan.file_bindings，也不扫描 workspace、环境或 serving 目录。

固定支持当前 `restart-executable-plan-v1` 与 `restart-bounded-study-execution-v1`：`selected_smoke` 恰好 28 项，`formal_mixed` 恰好 705 项。完整、部分停止、基础设施失败后的自然 drain 都可保存；必须满足原 started/unstarted 唯一且合并为整个固定集合，逐 started 恰有原 terminal，stage 和全局 local_workers 都是整数 0。

## 闭合边界

- 原 parent 必须不在 `/proc`；原 source/verify/raw 中有效的 PID 也必须不在。PID 仍存在只触发 ROOT 身份复核，不自动断言 PID 未被复用或本 run 仍在执行。
- 每个 started 的原 source_capture 必须有 `child_started / stdout_eof_observed / wait_returned / drain_proven = true`，且与原 terminal report 一致。不要求源 exit 为 0，也不要求 score_complete。缺失 capture（包括 reserved 后、child 启动前的捕获故障）不能自动封存，需要 ROOT 另查。
- `completed_scored`、`model_no_answer`、已 drain 的基础设施失败均保留原字段，不赋新分数、不翻转 false、不重跑。完整 run 树里的 raw 错误、损坏或残留 in_progress 也原字节保存，closure.raw_issues 明示；不能据此称 raw 全成功或 provider 已清空。
- 这是本地 caller 闭合和文件冻结证明，不是私有 provider 队列证明。没有模型请求、网络调用、GET、Slurm、signal、scorer 或 resume 调用。

## 产物

每 2,000 个 run 文件一份 inventory.partNNN.json，独立目录清单、closure.json 和最终 inventory.json。完整 run 树两遍流式 SHA256、bytes、inode/device/mode、mtime/ctime 与集合逐项相等；额外明确 control refs 单独二次核对。符号链接、特殊文件、不可读遍历或期间变化不能产生成功 inventory.json。失败时已生成的新报告保留，不修改原 run；不会自动重试或覆盖同名输出。

file_count / total_bytes 仅统计整个 run root；control_refs 单独列出，可能包含已经位于树内的 execution.json。原答案和分数均在原文件中保留，封存摘要不选择或汇总它们。

## CPU 验证

在本目录运行 `PYTHONPATH=. /lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python -B -m unittest -v test_seal`。测试只使用临时合成目录和模拟 PID 状态，未读取实际在途 run；不构成真实服务、实际 PID 闭合或真实结果验证。
