"""Tiny synthetic request bodies; no actual raw, gold, score, or task execution."""
import copy
import hashlib
import json
from pathlib import Path
import socket
import tempfile
import unittest
from unittest import mock

import audit_prompts as a

HERE = Path(__file__).resolve().parent
SOURCE = Path('/lustrefs/users/chufan.shi/codex_space_tn/portable_eval_20260908/source_cohorts/v5/LLM_ExpGym')


def h(value, size=64):
    return hashlib.sha256(str(value).encode()).hexdigest()[:size]


def payload(scenario='restricted_search', seed=2200):
    content = {'restricted_search': 'You are answering a question by searching a wiki of fictional characters.\nTool: search\nQuestion: synthetic question',
               'evidence_audit': 'You are auditing a legal document against 1 hypotheses.\nDocument segments:\nsynthetic text',
               'tuning': 'Goal: tune the system for high performance.\nSynthetic parameter ranges.'}[scenario]
    tool = {'restricted_search': 'search', 'evidence_audit': 'human_feedback', 'tuning': 'evaluate_config'}[scenario]
    return {'model': 'MOCK-serving', 'temperature': 1.0, 'top_p': 1.0, 'max_tokens': 32768, 'seed': seed,
            'reasoning_effort': 'max', 'chat_template_kwargs': {'thinking': True}, 'parallel_tool_calls': False,
            'tool_choice': 'auto', 'tools': [{'type': 'function', 'function': {'name': tool, 'description': 'synthetic tool'}}],
            'messages': [{'role': 'system', 'content': 'Synthetic protocol'}, {'role': 'user', 'content': content}]}


def fixture(all_started=False, add=None):
    fs = {}
    def put(name, obj):
        raw = obj if isinstance(obj, bytes) else a.encoded(obj)
        fs[name] = raw
        return {'path': name, 'sha256': a.sha(raw), 'bytes': len(raw)}
    root, jobs, rows, raw_entries = '/MOCK-run', [], [], []
    profile = {'model': 'MOCK', 'temperature': 1.0, 'top_p': 1.0, 'top_k': None, 'reasoning_effort': 'max', 'chat_template_kwargs': {'thinking': True}}
    config = {'run_id': 'MOCK-run', 'output_root': root, 'repo_root': '/MOCK-source', 'model': {'label': 'MOCK', 'model_id': 'MOCK-serving'},
              'policy': {'max_tokens': 32768, 'max_retries': 2}, 'credential_path': '/MOCK/private/router_api_key',
              'profiles': {'MOCK': {k: v for k, v in profile.items() if k != 'model'}}}
    config['profile_ref'] = put('/MOCK-controls/profile.json', profile)
    config['source_acceptance_ref'] = put('/MOCK-controls/source.json', {'repo_root': '/MOCK-source', 'files': a.SOURCE,
                                                                       'unfollowed_raw_ref': {'path': '/FORBIDDEN-raw', 'sha256': '0' * 64}})
    for rel, digest in a.SOURCE.items():
        raw = (SOURCE / rel).read_bytes()
        assert a.sha(raw) == digest
        fs['/MOCK-source/' + rel] = raw
    for i in range(705):
        audit = i == 0 or 3 <= i <= 40
        pool = i == 1 or 41 <= i <= 405
        scenario = 'evidence_audit' if audit else 'tuning' if i == 2 else 'restricted_search'
        iid = h('job' + str(i)); seeds = [2200, 2201, 2202] if audit else [2200, 2201, 2202, 2203] if pool else [2200]
        job = {'invocation_id': iid, 'system': 'poolact' if pool else 'expgym', 'scenario': scenario,
               'dump_dir': root + '/dumps/' + iid, 'sampling_seed_labels': seeds, 'expected_model_terminals': len(seeds)}
        jobs.append(job)
        for order in range(3 if audit else 1):
            lid = h('logical' + str(i) + ':' + str(order))
            row = {'logical_id': lid, 'invocation_id': iid, 'sampling_seed_labels': [seeds[order]] if audit else seeds,
                   'selector': {'tuning_task': 'MOCK-task'} if scenario == 'tuning' else {'question_index': i},
                   'regime': 'cost_tight', 'strategy': 'poolact' if pool else 'single', 'order': order if audit else None, 'hypothesis_order': None}
            rows.append(row)
            if not all_started and i not in (0, 1, 2): continue
            for agent, seed in enumerate(row['sampling_seed_labels']):
                rid = h(lid + ':' + str(seed), 32)
                ctx = {'scenario': scenario, 'cost_regime': row['regime'], 'seed': seed, **row['selector']}
                if audit: ctx.update(rep=order, hypothesis_order=None)
                ctx = dict(ctx, runner='poolact', strategy='poolact', agent_id=agent) if pool else {'runner': 'expgym', 'job': ctx}
                record = {'schema_version': 'expgym.api_attempt.v1', 'request_id': rid, 'client_id': h('client' + rid, 32),
                          'generation_id': h('generation' + rid, 32), 'attempt': 1, 'state': 'success', 'run_id': config['run_id'],
                          'context': ctx, 'request_payload': payload(scenario, seed), 'finished_at_utc': '2026-09-09T00:00:01+00:00',
                          'response_raw': 'DO_NOT_EXAMINE_oracle', 'response_json': {'oracle': 'NOT_A_REQUEST_FIELD'}}
                raw_entries.append((job, row, record))
    if add: add(raw_entries)
    config_ref = put('/MOCK-controls/plan.json', {'schema_version': 'restart-executable-plan-v1', 'mode': 'formal_mixed', 'expected_invocations': 705,
                                                'config': config, 'jobs': jobs, 'matrix': {'logical_rows': rows}})
    started = [j['invocation_id'] for j in jobs] if all_started else [j['invocation_id'] for j in jobs[:3]]
    execution_ref = put(root + '/execution.json', {'schema_version': 'restart-bounded-study-execution-v1', 'mode': 'formal_mixed',
        'local_workers': 0, 'plan_ref': config_ref, 'run_id': config['run_id'], 'started_invocation_ids': started,
        'unstarted_invocation_ids': [j['invocation_id'] for j in jobs if j['invocation_id'] not in started], 'reports': [{'invocation_id': iid} for iid in started]})
    inventory = [{**execution_ref, 'relative_path': 'execution.json'}]
    for job, row, record in raw_entries:
        ref = put(job['dump_dir'] + '/' + record['request_id'] + '.json', record)
        inventory.append({**ref, 'relative_path': ref['path'][len(root) + 1:]})
    # Metadata may enumerate results/keys elsewhere, but no bytes are provided:
    # any attempt to follow these forbidden objects fails the test reader.
    inventory.append({'path': root + '/results/DO_NOT_READ.json', 'relative_path': 'results/DO_NOT_READ.json', 'sha256': '0' * 64, 'bytes': 1})
    closure = put('/MOCK-seal/closure.json', {'local_workers': 0, 'mode': 'formal_mixed', 'run_id': config['run_id'], 'plan_ref': config_ref, 'execution_ref': execution_ref})
    part = put('/MOCK-seal/part.json', inventory)
    seal = put('/MOCK-seal/inventory.json', {'schema_version': 'restart-closed-run-inventory-v1', 'full_second_read_equal': True, 'expected_invocations': 705,
        'run_root': root, 'sealer_source_ref': {'sha256': a.SEALER_SHA}, 'control_refs': [config_ref, execution_ref], 'closure_ref': closure,
        'file_parts': [{**part, 'file_count': len(inventory), 'total_bytes': sum(r['bytes'] for r in inventory)}],
        'file_count': len(inventory), 'total_bytes': sum(r['bytes'] for r in inventory)})
    return fs, (config_ref, execution_ref, seal), put


class PromptTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='synthetic-', dir=HERE)
        self.addCleanup(self.temp.cleanup); self.base = Path(self.temp.name)
        self.block = mock.patch.object(socket, 'socket', side_effect=AssertionError('no_network'))
        self.block.start(); self.addCleanup(self.block.stop)
        self.rules = a.old_module()
        self.config = {'model': {'label': 'MOCK', 'model_id': 'MOCK-serving'}, 'policy': {'max_tokens': 32768},
                       'profiles': {'MOCK': {'temperature': 1.0, 'top_p': 1.0, 'top_k': None, 'reasoning_effort': 'max', 'chat_template_kwargs': {'thinking': True}}}}
        self.job = {'scenario': 'restricted_search', 'sampling_seed_labels': [2200]}

    def inspect(self, value):
        return a.inspect_payload(value, self.job, {}, self.config, self.rules)

    def test_full_planned_positive_branch_is_not_leakage_or_server_proof(self):
        fs, refs, _ = fixture(all_started=True)
        read_paths = []
        def read(name): read_paths.append(name); return fs[name]
        result = a.audit(*refs, self.base / 'output', a.Reader(read))
        self.assertIs(result['all_planned_attempt_input_coverage'], True)
        self.assertEqual((result['planned_invocations'], result['planned_logical_rows'], result['planned_model_terminals']), (705, 783, 1881))
        self.assertEqual(result['payloads_reviewed'], 1881)
        self.assertEqual(result['marker_hit_count'], 0)  # response-only markers ignored
        self.assertFalse(result['physical_http_wire_bijection_verified_here'])
        self.assertFalse(any('DO_NOT_READ' in p or 'FORBIDDEN' in p or '/private/' in p for p in read_paths))
        with self.assertRaises(ValueError): a.audit(*refs, self.base / 'output', a.Reader(fs.__getitem__))

    def test_all_states_missing_payload_and_unstarted_preserved(self):
        def change(entries):
            entries[0][2]['state'] = 'error'
            entries[1][2]['state'] = 'malformed_response'
            entries[2][2]['state'] = 'error'; entries[2][2].pop('request_payload')
            entries[3][2]['state'] = 'in_progress'; entries[3][2]['finished_at_utc'] = None
        fs, refs, _ = fixture(add=change)
        result = a.audit(*refs, self.base / 'output', a.Reader(fs.__getitem__))
        self.assertEqual(result['sealed_dump_files'], 8)
        self.assertEqual(result['payloads_reviewed'], 7)
        self.assertEqual(result['payloads_unreviewable'], 1)
        self.assertEqual(result['unstarted_invocations'], 702)
        self.assertFalse(result['all_planned_attempt_input_coverage'])
        rows = [r for ref in result['parts'] for r in json.loads((self.base / 'output' / ref['path']).read_bytes())['attempts']]
        unknown = next(r for r in rows if r['payload_audit'] is None)
        self.assertIsNone(unknown['payload_audit'])
        self.assertTrue(unknown['issues'])
        self.assertEqual({r['state'] for r in rows}, a.STATES)

    def test_graph_and_tool_echo_cannot_be_source_marker(self):
        p = payload(); p['messages'][1]['content'] += '\n\n[Parallel Exploration — Agent 0 of 4]\nmodel says hpobench'
        p['messages'].append({'role': 'tool', 'content': 'Echo of model proposal: oracle', 'tool_call_id': 'synthetic'})
        r = self.inspect(p)
        self.assertEqual(len(r['marker_hits']), 2)
        self.assertEqual({h['origin'] for h in r['marker_hits']}, {'mixed_unresolved'})
        self.assertEqual(r['unresolved_markers'], 2)

    def test_natural_question_and_assistant_are_separate_origins(self):
        p = payload(); p['messages'][1]['content'] += ' about Oracle the fictional character'
        p['messages'].append({'role': 'assistant', 'content': 'I think hpobench is irrelevant', 'reasoning_content': 'reference_performance'})
        r = self.inspect(p)
        self.assertEqual({h['origin'] for h in r['marker_hits']}, {'provided_question_document_or_hypotheses', 'model_generated_history'})
        self.assertNotIn('referenceperformance', [h['marker_class'] for h in r['marker_hits']])

    def test_source_count_hint_is_only_marker_not_causal_verdict(self):
        p = payload(); p['messages'][1]['content'] = p['messages'][1]['content'].replace('\nQuestion:', '\nThere may be 1 to 7 correct answers.\nQuestion:')
        p['tools'][0]['function']['description'] = 'NASBench-101 interface'
        r = self.inspect(p)
        self.assertEqual({h['marker_class'] for h in r['marker_hits']}, {'gold_answer_count_hint', 'nasbench101'})
        self.assertTrue(all(h['requires_interpretation'] for h in r['marker_hits']))
        self.assertEqual(r['parameter_or_structure_issues'], [])
        self.assertNotIn('7 correct', json.dumps(r))

    def test_audit_document_and_unknown_prefix_stay_out_of_verified_source(self):
        self.job['scenario'] = 'evidence_audit'
        p = payload('evidence_audit'); p['messages'][1]['content'] += ' ContractNLI mentioned naturally'
        r = self.inspect(p)
        self.assertEqual(r['marker_hits'][0]['origin'], 'provided_question_document_or_hypotheses')
        p['messages'][1]['content'] = 'unknown wrapper oracle'
        r = self.inspect(p)
        self.assertEqual(r['marker_hits'][0]['origin'], 'mixed_unresolved')
        self.assertIn('unrecognized_initial_task_boundary', r['parameter_or_structure_issues'])

    def test_parameter_failures_separate_from_marker_findings(self):
        p = payload(); p['top_p'] = 0.5; p['tool_choice'] = 'required'; p['parallel_tool_calls'] = 0
        r = self.inspect(p)
        self.assertEqual(r['marker_hits'], [])
        self.assertEqual(set(r['parameter_or_structure_issues']), {'parameter_top_p', 'parameter_parallel_tool_calls', 'unexpected_task_tool_choice'})

    def test_pin_and_closure_or_source_model_mismatch_rejected(self):
        for key in ('plan', 'source', 'closure'):
            fs, refs, put = fixture()
            changed_path = '/MOCK-controls/plan.json' if key == 'plan' else '/MOCK-source/expgym/react_loop.py' if key == 'source' else '/MOCK-seal/closure.json'
            fs[changed_path] += b' '
            with self.assertRaises(ValueError): a.setup(*refs, a.Reader(fs.__getitem__))
        fs, refs, put = fixture()
        plan = a.parse(fs[refs[0]['path']]); profile_ref = plan['config']['profile_ref']
        profile = a.parse(fs[profile_ref['path']]); profile['model'] = 'OTHER'
        # Unchanged external plan binding prevents silently swapping profile bytes.
        put(profile_ref['path'], profile)
        with self.assertRaises(ValueError): a.setup(*refs, a.Reader(fs.__getitem__))

    def test_retry_gap_or_client_reuse_does_not_disappear(self):
        def change(entries):
            entries[0][2]['attempt'] = 2
            entries[4][2]['client_id'] = entries[0][2]['client_id']
        fs, refs, _ = fixture(add=change)
        result = a.audit(*refs, self.base / 'output', a.Reader(fs.__getitem__))
        coverage = json.loads((self.base / 'output/COVERAGE.json').read_bytes())
        self.assertTrue(any('generation_attempt_gap' in row['coverage_issues'] for row in coverage))
        self.assertEqual(result['payloads_unreviewable'], 1)
        self.assertEqual(result['sealed_dump_files'], 8)

    def test_strict_json_bounds_and_private_path(self):
        for raw in [b'{"x":1,"x":2}', b'{"x":NaN}']:
            with self.assertRaises(ValueError): a.parse(raw)
        for name in ['/MOCK/private/router_api_key', '/MOCK/../x', 'relative']:
            with self.assertRaises(ValueError): a.path(name)
        with self.assertRaises(ValueError): self.inspect({'messages': []})

    def test_unmapped_dump_is_metadata_only_not_silently_omitted(self):
        fs, refs, put = fixture()
        seal = a.parse(fs[refs[2]['path']]); old_part = seal['file_parts'][0]
        rows = a.parse(fs[old_part['path']])
        rows.append({'path': '/MOCK-run/dumps/unplanned/DO_NOT_READ.json', 'relative_path': 'dumps/unplanned/DO_NOT_READ.json', 'sha256': '0' * 64, 'bytes': 1})
        changed = put(old_part['path'], rows)
        seal['file_parts'] = [{**changed, 'file_count': len(rows), 'total_bytes': sum(r['bytes'] for r in rows)}]
        seal.update(file_count=len(rows), total_bytes=sum(r['bytes'] for r in rows))
        new_seal = put(refs[2]['path'], seal)
        result = a.audit(refs[0], refs[1], new_seal, self.base / 'output', a.Reader(fs.__getitem__))
        self.assertEqual(result['unmapped_dump_files'], 1)
        self.assertEqual(result['sealed_dump_files'], 8)
        self.assertFalse(result['all_planned_attempt_input_coverage'])


    def test_business_reasoning_names_scanned_but_assistant_explicit_fields_excluded(self):
        p = payload()
        names = ('analysis', 'reasoning', 'reasoning_content', 'thinking')
        p['tools'][0]['function']['parameters'] = {
            'type': 'object', 'properties': {name: {'type': 'string', 'description': 'oracle'} for name in names}}
        p['messages'].append({'role': 'assistant', 'content': 'ordinary history',
                              **{name: 'hpobench' for name in names},
                              'tool_calls': [{'type': 'function', 'function': {
                                  'name': 'search', 'arguments': '{"analysis":"oracle"}'}}]})
        result = self.inspect(p)
        hits = result['marker_hits']
        self.assertEqual(len(hits), 5)
        source = [hit for hit in hits if hit['origin'] == 'source_tool_schema_position_bound']
        self.assertEqual({hit['pointer'] for hit in source},
                         {'/tools/0/function/parameters/properties/' + name + '/description' for name in names})
        self.assertEqual([hit['marker_class'] for hit in hits], ['oracle'] * 5)
        self.assertEqual(sum(hit['origin'] == 'model_generated_history' for hit in hits), 1)
        self.assertFalse(result['marker_free_in_examined_fields'])
        self.assertEqual(result['parameter_or_structure_issues'], [])

    def test_unmapped_dump_blocks_all_sealed_flag_without_reading_or_losing_denominator(self):
        fs, refs, put = fixture()
        seal = a.parse(fs[refs[2]['path']]); old_part = seal['file_parts'][0]
        rows = a.parse(fs[old_part['path']])
        missing = {'path': '/MOCK-run/dumps/unknown-job/NOT_READ.json',
                   'relative_path': 'dumps/unknown-job/NOT_READ.json', 'sha256': '0' * 64, 'bytes': 1}
        rows.append(missing)
        changed = put(old_part['path'], rows)
        seal['file_parts'] = [{**changed, 'file_count': len(rows), 'total_bytes': sum(r['bytes'] for r in rows)}]
        seal.update(file_count=len(rows), total_bytes=sum(r['bytes'] for r in rows))
        seal_ref = put(refs[2]['path'], seal)
        reads = []
        def read(name):
            reads.append(name)
            return fs[name]
        result = a.audit(refs[0], refs[1], seal_ref, self.base / 'output', a.Reader(read))
        self.assertEqual((result['sealed_dump_files'], result['payloads_reviewed'],
                          result['payloads_unreviewable'], result['unmapped_dump_files'],
                          result['total_sealed_dump_files']), (8, 8, 0, 1, 9))
        self.assertFalse(result['all_sealed_dump_files_payload_reviewable'])
        self.assertFalse(result['all_planned_attempt_input_coverage'])
        self.assertEqual(result['unstarted_invocations'], 702)
        self.assertEqual(result['marker_hit_count'], 0)  # Only the eight reviewed payloads.
        self.assertEqual(result['unmapped_dump_metadata_only_refs'],
                         [{key: missing[key] for key in ('path', 'sha256', 'bytes')}])
        self.assertNotIn(missing['path'], reads)


if __name__ == '__main__':
    unittest.main(verbosity=2)
