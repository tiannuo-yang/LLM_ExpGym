"""Closed-invocation raw/wire evidence checks; no model calls or score reads."""
import builtins
from collections import Counter, defaultdict
import copy
from datetime import datetime
import hashlib
import http.client
import importlib
import json
import math
import os
from pathlib import Path
import re
import sys
import urllib.error

import support


USAGE_FIELDS = ("prompt_tokens", "completion_tokens", "total_tokens")
RETRY_HTTP = {429, 500, 502, 503, 504}
PRIMITIVE_SHA256 = "b733a6d9b04b9e9a8fa8191dcf3d306cb5b4b7c5d02d09fbf290fec09cc1e492"


def _stamp(value):
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("evidence_timestamp_requires_timezone")
    return parsed.timestamp()


def _id(value):
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{32}", value) is not None


def _same(left, right):
    return support.canonical(left) == support.canonical(right)


def _decoder(plan):
    repo = support.io.lexical(plan["config"]["repo_root"])
    prior = list(sys.path)
    try:
        sys.path.insert(0, str(repo))
        module = importlib.import_module("expgym.llm_clients")
        if Path(module.__file__).resolve() != repo / "expgym/llm_clients.py":
            raise ValueError("original_decoder_source_origin_differs")
        # Classmethod only: no client construction, generation or scoring.
        return module.OpenAICompatibleLLM._decode_response
    finally:
        sys.path[:] = prior


def _retry_types():
    classes = [value for value in vars(builtins).values() if isinstance(value, type)]
    classes += [urllib.error.URLError, http.client.RemoteDisconnected]
    return {cls.__name__ for cls in classes if issubclass(cls, (urllib.error.URLError, TimeoutError, ConnectionError))}


def _profile_errors(payload, plan, job):
    p = plan["config"]["policy"]
    profile = plan["config"]["profiles"][job["model_id"]]
    expected = {"model": job["model_id"], "temperature": profile["temperature"], "top_p": profile["top_p"],
                "max_tokens": p["max_tokens"], "parallel_tool_calls": False}
    for key in ("reasoning_effort", "top_k"):
        if profile.get(key) is not None:
            expected[key] = profile[key]
    if profile["chat_template_kwargs"]:
        expected["chat_template_kwargs"] = profile["chat_template_kwargs"]
    if (type(payload) is not dict or set(payload) != set(expected) | {"seed", "messages", "tools", "tool_choice"}
            or any(payload.get(k) != v for k, v in expected.items())
            or type(payload.get("seed")) is not int or payload["seed"] not in job["sampling_seed_labels"]
            or type(payload.get("max_tokens")) is not int or payload.get("parallel_tool_calls") is not False
            or any(type(payload.get(k)) not in (int, float) or not math.isfinite(payload[k]) for k in ("temperature", "top_p"))
            or ("top_k" in expected and type(payload.get("top_k")) is not int)
            or not _same(payload.get("chat_template_kwargs", {}), profile["chat_template_kwargs"])
            or payload.get("tool_choice") not in ("auto", "none")
            or type(payload.get("tools")) is not list or not payload["tools"]
            or type(payload.get("messages")) is not list):
        return ["raw_request_profile_or_native_shape_differs"]
    return []


def _history(messages, delivered):
    """Exact retained assistant history plus complete native call/result pairing.

    Old groups may be removed by the original context trimmer. Tool observation
    text can be trimmed/augmented by the source; it is not scored or interpreted.
    """
    assistants, pending = [], set()
    for message in messages:
        if type(message) is not dict:
            return ["history_message_not_object"]
        role = message.get("role")
        if role == "tool":
            identifier = message.get("tool_call_id")
            if identifier not in pending:
                return ["orphan_or_duplicate_tool_result"]
            pending.remove(identifier)
            continue
        if pending:
            return ["native_tool_results_not_complete"]
        if role not in ("system", "developer", "user", "assistant"):
            return ["unknown_message_role"]
        if role == "assistant":
            assistants.append(message)
            calls = message.get("tool_calls")
            calls = [] if calls is None else calls
            if type(calls) is not list:
                return ["native_history_calls_not_list"]
            for call in calls:
                identifier = call.get("id") if type(call) is dict else None
                if not isinstance(identifier, str) or not identifier or identifier in pending:
                    return ["native_history_call_id_invalid"]
                pending.add(identifier)
    if pending:
        return ["native_tool_results_not_complete"]
    prior_index = 0
    for message in assistants:
        while prior_index < len(delivered) and not _same(message, delivered[prior_index]):
            prior_index += 1
        if prior_index == len(delivered):
            return ["assistant_history_not_original_delivered_message"]
        prior_index += 1
    if delivered and (not assistants or not _same(assistants[-1], delivered[-1])):
        return ["latest_delivered_assistant_missing_from_history"]
    return []


def audit_raw(plan, job, raw_paths, event_paths):
    """Audit supplied closed namespaces, returning only safe metadata and hashes.

    Request bytes are reconstructed with the ORIGINAL json.dumps(payload)
    insertion-order/default formatting, not canonical/sorted serialization. The
    legacy raw schema has no request-body field. Redaction that prevents matching
    wire hashes is explicitly unverified; it is never silently waived.
    """
    errors, inventory, raws, events = [], [], [], []
    known, unknown = Counter(), Counter()
    def error(code, path=None, **meta):
        errors.append(dict(meta, code=code, **({"path": str(path)} if path is not None else {})))
    def load(paths, root, kind):
        loaded = []
        try:
            root = support.io.lexical(root)
            supplied = [support.io.lexical(path) for path in paths]
            if len(set(supplied)) != len(supplied):
                error("duplicate_supplied_path", kind=kind)
            if any(path.parent != root or path.suffix != ".json" for path in supplied):
                raise ValueError("flat_declared_namespace_required")
            fd = support.io._directory(root)
            try:
                actual = {root / name for name in os.listdir(fd)}
            finally:
                os.close(fd)
            if actual != set(supplied):
                error("physical_namespace_coverage_differs", kind=kind,
                      missing_supplied=len(actual - set(supplied)), extra_supplied=len(set(supplied) - actual))
            for path in sorted(set(supplied)):
                try:
                    before = path.lstat()
                    body = support.io.read_regular(path)
                    after = path.lstat()
                    before_sig = (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
                    after_sig = (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
                    if before_sig != after_sig:
                        raise ValueError("evidence_changed_during_read")
                    inventory.append({"path": str(path), "kind": kind, "bytes": len(body),
                        "sha256": hashlib.sha256(body).hexdigest(), "mtime_ns": after.st_mtime_ns})
                    value = support.parse_json(body)
                    if type(value) is not dict:
                        raise ValueError("evidence_record_not_object")
                    loaded.append((path, value))
                except Exception as exc:
                    error("unreadable_or_invalid_evidence", path, error_type=type(exc).__name__, kind=kind)
        except Exception as exc:
            error("unreadable_or_invalid_namespace", root, error_type=type(exc).__name__, kind=kind)
        return loaded
    raw_root = Path(job["dump_dir"])
    event_root = Path(job["log_dir"]) / "wire"
    raws = load(raw_paths, raw_root, "raw")
    events = load(event_paths, event_root, "wire")
    try:
        decode = _decoder(plan)
    except Exception as exc:
        decode = None
        error("original_decoder_unavailable", error_type=type(exc).__name__)
    identities, wire_starts, wire_ends, raw_by_client = {}, {}, {}, defaultdict(list)
    request_ids, gen_clients = set(), {}
    expected_seeds = set(job["sampling_seed_labels"])
    limit = job["expected_model_terminals"] * (plan["config"]["policy"]["max_steps"] + 1) * (plan["config"]["policy"]["max_retries"] + 1)
    for path, event in events:
        try:
            if (event.get("schema_version") != "restart-source-wire-metadata-v1"
                    or event.get("primitive_sha256") != PRIMITIVE_SHA256
                    or event.get("invocation_id") != job["invocation_id"] or event.get("model_id") != job["model_id"]
                    or event.get("run_id") != plan["config"]["run_id"] or not _id(event.get("source_client_id"))
                    or not _id(event.get("wire_client_id")) or type(event.get("seed")) is not int
                    or event["seed"] not in expected_seeds):
                raise ValueError("wire_identity_differs")
            key = event["source_client_id"]
            if event["kind"] == "client_identity":
                if key in identities:
                    raise ValueError("duplicate_source_client_identity")
                identities[key] = event
            elif event["kind"] in ("attempt_start", "attempt_terminal"):
                sequence = event["attempt_sequence"]
                target = wire_starts if event["kind"] == "attempt_start" else wire_ends
                if type(sequence) is not int or sequence < 1 or sequence in target:
                    raise ValueError("duplicate_or_invalid_attempt_sequence")
                target[sequence] = (path, event)
            else:
                raise ValueError("unknown_wire_event_kind")
        except Exception as exc:
            error("invalid_wire_event", path, error_type=type(exc).__name__)
    if (len(identities) != job["expected_model_terminals"]
            or {v["seed"] for v in identities.values()} != expected_seeds
            or len({v["wire_client_id"] for v in identities.values()}) != len(identities)):
        error("client_owner_identity_coverage_differs")
    if set(wire_starts) != set(wire_ends) or set(wire_starts) != set(range(1, len(wire_starts) + 1)):
        error("wire_attempt_start_terminal_bijection_differs")
    if len(wire_starts) > limit or len(raws) > limit:
        error("physical_attempt_ceiling_exceeded")
    for path, raw in raws:
        try:
            rid, cid, gid = raw["request_id"], raw["client_id"], raw["generation_id"]
            if (raw.get("schema_version") != "expgym.api_attempt.v1" or not all(_id(x) for x in (rid, cid, gid))
                    or path.name != rid + ".json" or rid in request_ids
                    or raw.get("run_id") != plan["config"]["run_id"] or raw.get("endpoint") != job["endpoint"]
                    or type(raw.get("attempt")) is not int or raw["attempt"] < 1
                    or type(raw.get("max_attempts")) is not int
                    or raw.get("max_attempts") != plan["config"]["policy"]["max_retries"] + 1
                    or raw.get("state") not in ("success", "error", "malformed_response")
                    or type(raw.get("will_retry")) is not bool or raw.get("finished_at_utc") is None):
                raise ValueError("raw_terminal_identity_or_schema_differs")
            request_ids.add(rid)
            if gid in gen_clients and gen_clients[gid] != cid:
                raise ValueError("generation_reused_by_different_clients")
            gen_clients[gid] = cid
            for code in _profile_errors(raw["request_payload"], plan, job):
                error(code, path)
            if cid not in identities or raw["request_payload"].get("seed") != identities[cid]["seed"]:
                error("raw_client_not_bound_to_exact_owner", path)
            raw_by_client[cid].append((path, raw))
            usage = (raw.get("response_json") or {}).get("usage") if type(raw.get("response_json")) is dict else None
            for field in USAGE_FIELDS:
                value = usage.get(field) if type(usage) is dict else None
                if type(value) is int and value >= 0:
                    known[field] += value
                else:
                    unknown[field] += 1
        except Exception as exc:
            error("invalid_raw_record", path, error_type=type(exc).__name__)
            for field in USAGE_FIELDS:
                unknown[field] += 1
    joins, delivered_count, aborts, generations = 0, 0, 0, 0
    for cid, rows in raw_by_client.items():
        try:
            rows.sort(key=lambda pair: (_stamp(pair[1]["started_at_utc"]), pair[1]["attempt"]))
            if any(_stamp(prior[1]["finished_at_utc"]) > _stamp(current[1]["started_at_utc"])
                   for prior, current in zip(rows, rows[1:])):
                error("same_client_attempts_overlap", client_id=cid)
            attempts = [(seq, value) for seq, value in sorted(wire_starts.items()) if value[1]["source_client_id"] == cid]
            if len(rows) != len(attempts):
                error("raw_wire_client_attempt_count_differs", client_id=cid)
            delivered, groups, seen_generations = [], [], set()
            for (path, raw), (sequence, (_, start)) in zip(rows, attempts):
                end_pair = wire_ends.get(sequence)
                if end_pair is None:
                    continue
                end = end_pair[1]
                identity = identities.get(cid, {})
                fields = ("source_client_id", "wire_client_id", "seed")
                if (any(start.get(k) != end.get(k) or start.get(k) != identity.get(k) for k in fields)
                        or start.get("request_body_sha256") != end.get("request_body_sha256")
                        or start.get("request_bytes") != end.get("request_bytes")
                        or start.get("timeout_seconds") != plan["config"]["policy"]["request_timeout"]):
                    error("wire_start_terminal_identity_differs", path)
                if end.get("state") not in ("bytes_returned", "error"):
                    error("unknown_wire_terminal_state", path)
                body = json.dumps(raw["request_payload"]).encode("utf-8")
                if start.get("request_body_sha256") != hashlib.sha256(body).hexdigest() or start.get("request_bytes") != len(body):
                    error("request_bytes_not_reconstructible_or_wire_hash_differs", path)
                if not (_stamp(raw["started_at_utc"]) <= _stamp(start["started_at_utc"])
                        <= _stamp(end["finished_at_utc"]) <= _stamp(raw["finished_at_utc"])):
                    error("raw_wire_attempt_time_order_differs", path)
                if _stamp(identity["observed_at_utc"]) > _stamp(start["started_at_utc"]):
                    error("client_identity_after_attempt", path)
                raw_text, parsed = raw.get("response_raw"), raw.get("response_json")
                response_bytes = raw_text.encode("utf-8") if isinstance(raw_text, str) else None
                if raw["state"] == "success" or end.get("state") == "bytes_returned":
                    if (response_bytes is None or end.get("response_bytes_sha256") != hashlib.sha256(response_bytes).hexdigest()
                            or end.get("response_bytes") != len(response_bytes)):
                        error("response_bytes_not_reconstructible_or_wire_hash_differs", path)
                if raw["state"] == "success":
                    if (end.get("state") != "bytes_returned" or end.get("error_type") is not None
                            or end.get("http_status") is not None or raw.get("http_status") is not None
                            or raw.get("error") is not None):
                        error("success_raw_wire_terminal_differs", path)
                    if not _same(support.parse_json(response_bytes), parsed):
                        error("response_raw_json_disagrees", path)
                elif end.get("http_status") is not None:
                    if (end["http_status"] != raw.get("http_status") or end.get("state") != "error"
                            or end.get("error_type") != "HTTPError" or end.get("response_body_owned_by_source_client") is not True
                            or end.get("response_bytes_sha256") is not None or end.get("response_bytes") is not None):
                        error("http_error_wire_source_contract_differs", path)
                elif end.get("state") == "error":
                    if (raw.get("http_status") is not None or end.get("error_type") != (raw.get("error") or {}).get("type")
                            or end.get("response_bytes_sha256") is not None or end.get("response_bytes") is not None):
                        error("transport_error_wire_source_contract_differs", path)
                elif raw.get("http_status") is not None or end.get("error_type") is not None:
                    error("delivered_bytes_wire_source_contract_differs", path)
                joins += 1
                if not groups or groups[-1][0][1]["generation_id"] != raw["generation_id"]:
                    if raw["generation_id"] in seen_generations:
                        error("generation_attempts_interleaved", path)
                    seen_generations.add(raw["generation_id"])
                    groups.append([])
                groups[-1].append((path, raw))
            stopped = False
            for group in groups:
                generations += 1
                if stopped:
                    error("continued_after_terminal_error_or_abort", group[0][0])
                first_payload = group[0][1]["request_payload"]
                for code in _history(first_payload["messages"], delivered):
                    error(code, group[0][0])
                if [raw["attempt"] for _, raw in group] != list(range(1, len(group) + 1)):
                    error("retry_attempt_sequence_not_contiguous", group[0][0])
                if len(group) > plan["config"]["policy"]["max_retries"] + 1:
                    error("retry_chain_exceeds_policy", group[0][0])
                for index, (path, raw) in enumerate(group):
                    if not _same(raw["request_payload"], first_payload):
                        error("retry_changed_request_payload", path)
                    retry = raw["will_retry"]
                    if retry != (index < len(group) - 1):
                        error("retry_terminal_or_continuation_flag_differs", path)
                    if retry:
                        etype = (raw.get("error") or {}).get("type")
                        status = raw.get("http_status")
                        delay = raw.get("retry_delay_seconds")
                        if (raw["state"] != "error" or not ((status in RETRY_HTTP and etype == "HTTPError")
                                or (status is None and etype in _retry_types()))
                                or type(delay) not in (int, float) or not math.isfinite(delay)
                                or not 0 <= delay <= plan["config"]["policy"]["retry_max_seconds"]):
                            error("unregistered_semantic_or_unbounded_retry", path)
                    elif raw.get("retry_delay_seconds") is not None:
                        error("nonretry_terminal_has_delay", path)
                    choices = (raw.get("response_json") or {}).get("choices") if type(raw.get("response_json")) is dict else None
                    finish = choices[0].get("finish_reason") if type(choices) is list and choices and type(choices[0]) is dict else None
                    if finish == "abort" or (raw.get("error") or {}).get("type") == "APICompletionAbortedError":
                        aborts += 1
                        stopped = True
                        error("provider_abort_not_publishable_or_retryable", path)
                path, terminal = group[-1]
                if terminal["state"] != "success":
                    stopped = True
                    error("terminal_generation_not_delivered", path)
                elif decode is not None:
                    decoded = decode(terminal["response_raw"].encode("utf-8"))
                    if decoded[-1] == "abort":
                        error("abort_marked_success", path)
                    else:
                        delivered.append(copy.deepcopy(decoded[3]))
                        delivered_count += 1
            if len(groups) > plan["config"]["policy"]["max_steps"] + 1:
                error("logical_generation_horizon_exceeded", client_id=cid)
        except Exception as exc:
            error("client_evidence_chain_invalid", client_id=cid, error_type=type(exc).__name__)
    if set(raw_by_client) != set(identities) or joins != len(raws) or joins != len(wire_starts):
        error("raw_wire_owner_attempt_bijection_incomplete")
    unread_wire_attempts = max(0, len(wire_starts) - len(raws))
    for field in USAGE_FIELDS:
        unknown[field] += unread_wire_attempts
    counts = {"raw_files": len(raws), "wire_events": len(events), "clients": len(identities),
              "wire_attempt_starts": len(wire_starts), "wire_attempt_terminals": len(wire_ends),
              "wire_attempts_without_readable_raw_lower_bound": unread_wire_attempts,
              "joined_attempts": joins, "logical_generations": generations, "delivered_generations": delivered_count,
              "provider_aborts": aborts, "raw_states": dict(Counter(raw.get("state") if type(raw.get("state")) is str else "invalid_state" for _, raw in raws))}
    return {"schema_version": "restart-raw-wire-audit-v1", "verified": not errors, "errors": errors,
            "counts": counts, "inventory": inventory, "known_usage_sum": {key: known[key] for key in USAGE_FIELDS},
            "unknown_usage_counts": {key: unknown[key] for key in USAGE_FIELDS}, "provider_cost_total": None,
            "usage_accounting": "Provider-reported values only; unknown counters include wire attempts lacking readable raw. Incomplete evidence cannot establish a complete usage total; cost is never inferred as zero.",
            "request_body_rule": "Exact original json.dumps insertion-order formatting, not canonical JSON; redaction mismatch is unverified.",
            "history_verification": "Bounded original-decoder replay: retained assistants form an exact ordered subsequence including the latest delivery, and native tool IDs are completely paired. Original trimming of old groups and tool observation text is allowed; complete prompt reconstruction is not claimed.",
            "scope": "Closed raw/wire metadata and native assistant/tool-history integrity only; no score/answer judgment or provider-drain proof."}
