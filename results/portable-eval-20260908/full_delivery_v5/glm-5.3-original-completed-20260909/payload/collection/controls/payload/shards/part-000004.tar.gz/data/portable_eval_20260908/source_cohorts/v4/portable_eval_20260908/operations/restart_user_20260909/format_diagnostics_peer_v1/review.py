#!/usr/bin/env python3
"""Four bounded, synthetic-only peer checks; no actual outcome/scorer/network."""
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import time
import unittest

HERE = Path(__file__).resolve().parent
OP = HERE.parent
CANDIDATE = OP / 'format_diagnostics_candidate_v1'
# Use the fixed source without searching run/output directories.
SOURCE = Path('/lustrefs/users/chufan.shi/codex_space_tn/portable_eval_20260908/source_cohorts/v5/LLM_ExpGym')
PINS = {
    CANDIDATE / 'diagnostics.py': 'cddf8f05c5c23ffa92373c45ed42a07507b890ebd3dc5f31017f1c150d9d6427',
    CANDIDATE / 'test_diagnostics.py': 'e0cf2571f2c48660b0e53ee2acf66027fd5042cb1cb35ea8229429d1e707a0bd',
    CANDIDATE / 'README.zh.md': '79fc877883ef1298d7e7bec14eb258d4423bdc43973285bf09007eb5fdb55ca7',
    OP / 'exporter_candidate_v1/exporter.py': 'e555578c35795aba6fffc8ee90eb60751b5e60739c656c31db86ab2cb02cb4cd',
    OP / 'analysis_candidate_v2/analysis.py': '5df8525973261d61b5c3c373945129db22979131e6ce3b586c8913efeed256bf',
    OP / 'seal_restart_v1/seal.py': '1d30bf17c4cbe19fea21c2d65ab50e83db4aed9770ae6d1320c2fb3c34a424f2',
    SOURCE / 'expgym/poolact.py': '3638b3f75fc253e6a971c409e116fc352512984bccb24892d3d62a6d7fc834d2',
    SOURCE / 'expgym/task_restricted_search.py': '5cf8d0ea856279f3fd982a60d947c37511242292c26c631cf6f84e6bb479c098',
    SOURCE / 'expgym/task_evidence_audit.py': 'f874e36965e087d9771aca23bfdf221b00c86d63060b6c8f79e364b52a19c536',
}


def snapshot():
    rows = []
    for p, expected in PINS.items():
        blob, st = p.read_bytes(), p.stat()
        digest = hashlib.sha256(blob).hexdigest()
        if digest != expected:
            raise ValueError('fixed_source_pin_mismatch')
        rows.append(dict(path=str(p), sha256=digest, bytes=len(blob), mode=st.st_mode,
                         mtime_ns=st.st_mtime_ns, inode=st.st_ino, device=st.st_dev))
    return rows


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


class Peer(unittest.TestCase):
    def test_all_planned_denominators_and_null_unavailable(self):
        fs, go, _ = owner.fixture()
        files, provenance = d.diagnose(go, d.Reader(read=fs.__getitem__))
        rows, groups = d.load(files['pool_diagnostics.json']), d.load(files['group_counts.json'])
        self.assertEqual((len(rows), provenance['planned_agents']), (312, 1248))
        self.assertEqual(sum(g['diagnosed_agents'] + g['unavailable_agents'] for g in groups), 1248)
        self.assertEqual(sum(g['missing_agents'] for g in groups), 1)
        self.assertEqual(sum(r['structural'] is None for r in rows), 308)
        self.assertTrue(all(r['structural'] is None and r['reason'] is not None for r in rows if r['state'] != 'terminal'))
        self.assertEqual(sum(g['search_diagnosed_pairs'] for g in groups), 12)
        self.assertEqual(sum(sum(v.values()) for g in groups for v in g['score_gain_cooccurrence'].values()), 6)

    def test_search_equivalence_and_original_representative(self):
        frozen = owner.frozen_functions('expgym/task_restricted_search.py', ['_normalize_name', '_extract_names'])
        vote = owner.frozen_functions('expgym/poolact.py', ['_search_vote_key'])['_search_vote_key']
        cases = [None, '', '  ', '[]', '[null,true,{},[1]]']
        for name in ['A B', 'A B C D E F', 'a\u00a0b', '\u0130 A', '']:
            for prefix in ['', '- ', '\u2022 ', '1. ', '\u0661. ', '2) ']:
                cases += [prefix + name, json.dumps([prefix + name, name])]
        for answer in cases:
            key, extracted, _ = d.search_sets(answer)
            self.assertEqual(key, vote(answer))
            self.assertEqual(set(extracted), frozen['_extract_names'](answer or ''))
        answers = ['A B C D E F', '["A B C D E F"]', '["A B C D E F"]', 'Z']
        result = d.search_pool(answers, answers[0])
        self.assertEqual(result['selected_agent_index'], 0)
        self.assertTrue(result['flags']['winning_key_scorer_disagreement'])
        with self.assertRaisesRegex(ValueError, 'stored_search_aggregate'):
            d.search_pool(answers, answers[1])

    def test_audit_conditional_evidence_and_earliest_ties(self):
        names = ['_canonical_audit_label', '_canonical_evidence_ids', 'aggregate_results', '_evaluate_aggregate', '_require_finite_scores']
        frozen = owner.frozen_functions('expgym/poolact.py', names)
        answers = [json.dumps({'H': {'label': label, 'evidence_ids': evidence}}) for label, evidence in
                   [('neutral', [9]), ('Entailment', [1]), ('NotMentioned', [8]), ('Entailment', [1])]]
        # Evaluator is None: source aggregation only, not scoring or gold access.
        original = frozen['aggregate_results']('evidence_audit', [{'answer': a, 'answer_perf': 0.0} for a in answers])['answer']
        result = d.audit_pool(answers, original)
        hypothesis = result['hypotheses'][0]
        self.assertEqual(hypothesis['label_supporter_indices'], [0, 2])
        self.assertEqual(hypothesis['evidence_supporter_indices'], [0])
        self.assertEqual(hypothesis['first_winning_label_supporter'], 0)
        self.assertEqual(hypothesis['first_winning_evidence_supporter'], 0)
        self.assertTrue(hypothesis['label_tie'] and hypothesis['evidence_tie'])
        self.assertEqual(d.scorer_evidence('12'), ({1, 2}, False))
        self.assertEqual(d.vote_evidence('12'), ())
        self.assertEqual(d.scorer_evidence([1, 'bad']), (set(), True))
        self.assertEqual(d.vote_evidence([1, 'bad']), (1, 'bad'))

    def test_original_identity_and_seal_export_cross_binding(self):
        fs, go, put = owner.fixture()
        control = d.load(fs[go['path']])
        plan = d.load(fs[control['inputs']['plan']['path']])
        row = plan['matrix']['logical_rows'][0]
        payload = d.load(fs['/MOCK-run/' + row['result_artifact']])
        agents = [d.load(fs['/MOCK-run/' + name]) for name in row['agent_artifacts']]
        for mutate in [lambda p: p['config'].update(agent_seeds=[2201,2200,2202,2203]),
                       lambda p: p['agent_results'][0].update(scoring_input='not the original'),
                       lambda p: p['config'].update(model='OTHER')]:
            bad = copy.deepcopy(payload)
            mutate(bad)
            with self.assertRaises(ValueError):
                d.pool_diagnostics(row, {}, bad, agents)
        # Even a newly externally pinned export index cannot silently substitute
        # a different plan identity while the original execution/seal stay fixed.
        ix = d.load(fs[control['inputs']['export_index']['path']])
        evidence_path = '/MOCK-export/EXPORT_EVIDENCE.json'
        evidence = d.load(fs[evidence_path])
        evidence['plan_ref']['sha256'] = '0' * 64
        changed = put(evidence_path, evidence)
        ix['files']['EXPORT_EVIDENCE.json'] = {k: changed[k] for k in ('sha256', 'bytes')}
        control['inputs']['export_index'] = put(control['inputs']['export_index']['path'], ix)
        go = put(go['path'], control)
        with self.assertRaisesRegex(ValueError, 'frozen_export_evidence_mismatch'):
            d.diagnose(go, d.Reader(read=fs.__getitem__))


if __name__ == '__main__':
    before = snapshot()
    d = module('diagnostics', CANDIDATE / 'diagnostics.py')
    owner = module('peer_owner_helpers', CANDIDATE / 'test_diagnostics.py')
    log, started = io.StringIO(), time.monotonic()
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Peer))
    after = snapshot()
    assert before == after
    receipt = dict(schema_version='format-diagnostics-peer-cpu-v1', tests=result.testsRun,
                   failures=len(result.failures), errors=len(result.errors), passed=result.wasSuccessful(),
                   elapsed_seconds=time.monotonic() - started, interpreter=sys.executable,
                   python_version=sys.version, protected_before_after_equal=True, protected=before,
                   reviewer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                   actual_outcomes_read=False, raw_or_key_files_read=False, gold_or_scorer_calls=0,
                   model_or_network_calls=0, finite_pre_execution_engineering_review_only=True)
    destination = HERE / ('cpu_' + str(sys.version_info.major) + str(sys.version_info.minor) + '_v1')
    destination.mkdir(mode=0o700)
    for name, blob in [('TEST.log', log.getvalue().encode()), ('RECEIPT.json', json.dumps(receipt, indent=2, sort_keys=True).encode())]:
        with (destination / name).open('xb') as stream:
            stream.write(blob)
    print(json.dumps(receipt, sort_keys=True))
    raise SystemExit(not result.wasSuccessful())
