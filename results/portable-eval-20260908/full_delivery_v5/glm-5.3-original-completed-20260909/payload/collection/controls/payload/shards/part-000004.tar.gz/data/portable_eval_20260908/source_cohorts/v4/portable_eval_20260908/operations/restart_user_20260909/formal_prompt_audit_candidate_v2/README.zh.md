# 正式全量 request-input provenance：离线候选 v2

状态：仅静态与合成 CPU 准备。没有执行真实审计、读取当前/历史 raw 或结果、调用 scorer/模型、读取 gold 或私钥。真正运行必须等整次正式运行闭合并封存；该程序不签 ROOT GO，不代替已有原始 HTTP 审计、源评分重算或最终 post-analysis 独立复查。

v1 原件及同行反例原样保留。v2 仅修复两项候选问题：工具 schema 同名业务属性的 value 漏扫，以及未映射 dump 被全称可审标志遗漏；不改变运行源码、marker 规则、科学终点或真实读取授权。输出 schema 名沿用 v1，具体修订由本目录与 `program_sha256` 标识。

## 单一入口与原件边界

```bash
python3 -B /ABS/formal_prompt_audit_candidate_v2/audit_prompts.py \
  --plan /ABS/plan.json --plan-sha256 EXTERNAL_PLAN_SHA \
  --execution /ABS/execution.json --execution-sha256 EXTERNAL_EXECUTION_SHA \
  --seal /ABS/inventory.json --seal-sha256 EXTERNAL_SEAL_SHA \
  --output /ABS/A_NEW_AUDIT_DIRECTORY
```

三个外部原字节 SHA 是显式输入，不从文件自算后冒充信任来源。只接受已冻结 v5 `restart-executable-plan-v1/formal_mixed` 的单模型完整705 invocation/783 logical row计划；外部 execution 必须属于同一 plan/run、`local_workers` 为整数0，started/unstarted 精确划分全部计划，started 各有终态报告。seal 必须是固定 sealer 的 `restart-closed-run-inventory-v1`，plan/execution/closure相同，完整各part计数/路径/SHA相符且声明双次全树相同。

只按 seal 的文件表、每 job 显式 `dump_dir` 选择请求尝试文件，**不 glob 或重新发现实际目录**。已声明 dump 目录内每个文件均保留计数：正常 JSON、error、malformed_response、in_progress、坏JSON、未知状态、非规范文件名/临时文件一律不静默删除。seal 中 `run_root/dumps/` 下未映射到计划 job 的文件只列元数据 refs 和不可完整标记，不扩大读取范围。results、wire、终态评分原件、gold数据和凭据路径不跟随。

从 plan 只进一步读取两项明确的 `source_acceptance_ref`、`profile_ref`，以及 repo_root 下**固定九份**源码（两个CLI、client/loop/native-protocol、三个任务模板、Pool graph模块）。不递归跟随这些 JSON 的其他绝对 refs；source table 其他文件、data/oracle refs、deployment/private refs 均不读取。两模型实际正式 plan/profile 的 model与采样子集已做纯元数据兼容核对，但不是实际请求检验。

原 `actual_prompt_peer_v1/inspect_wire_v2.py` SHA `865a7b966a127926d82bf07921d4116f3c273235b6e99b7f903c3b62d44348cd` 只提供固定 marker 正则与规则身份；不运行其 hardcoded smoke main，不改该文件。

## 所有 attempt、所有 planned owner，而非只看成功

每个请求比对 request/client/generation ID、attempt编号、run、模型、采样、seed、context owner与selector。Exp Audit 固定order/hypothesis顺序按其自身 logical row/seed核对；Pool按N4 agent_id→seed核对，不能将原repeat_index0冒充outerrep。generation编号缺口、跨job client复用、重复request/attempt均保留问题。重复尝试不压成一次 success。

冻结 `scripts/run_poolact.py:212–224` 的 raw context 没有 `data_source`、`cc_split` 或 `hypothesis_order`；本程序不补造这些字段，也不声称逐 raw 直接核对它们。Pool 的这些选择只能由外部固定 plan、冻结 source 与封存目录/owner 归属间接绑定；Exp context 实际具有相关字段，按原值检查。

705 job 全部输出覆盖行，同时列完整1,881个计划 owner slot的未覆盖数量/每job缺失列表。未启动任务显式计数；已启动但零sealed attempt与部分Pool/Audit owner尚无请求均明确列出。输入缺失/坏JSON/缺request_payload/不可归属时 `payload_audit=null`，不产生“无标记”结论；pending即使payload可读也不获得闭合覆盖。源报告失败的请求只要有合法payload仍检查该payload，不要求success。

分母与覆盖分开：`sealed_dump_files` 保持原意，仅计已映射文件；`unmapped_dump_files` 计未映射且未读取的原件；新增 `total_sealed_dump_files` 精确为两者之和。`payloads_reviewed`/`payloads_unreviewable` 仅划分已映射文件；总不可审数还须加未映射数，不能把它们当 0 markers。`all_sealed_dump_files_payload_reviewable` 只有已映射均可审且未映射数为0才为真，不代表所有计划已启动、所有请求已闭合或输入稳定。更强的计划覆盖独立如下。

三个问题分开：

- `all_planned_attempt_input_coverage`：完整计划 owner均有可审的封存请求，身份/闭合/范围/稳定性无未决；不是所有任务成绩完成或质量通过。
- `parameter_or_structure_issue_count`：模型、temperature/top-p/top-k/max_tokens、reasoning/chat-template kwargs、native单tool及auto/none等请求字段是否与固定plan一致；参数不符不被当成标记泄漏，也不会把已读取请求从分母删去。
- `marker_hit_count`：**已审字段的观察次数**，不含不可审请求的未知值；0不能覆盖unreviewable或未启动部分，标记不等于自动泄漏。

枚举所有sealed dump不独立证明所有物理 HTTP 都被dump记录。`physical_http_wire_bijection_verified_here=false`：仍需已有独立 raw/wire 完整性审计。进程/服务队列也不由本程序重新探测。

## 来源分层与不确定性

输出只含 marker 类、相对 `request_payload` 的 JSON pointer、受控region标签、状态/计数/原件 refs和来源分类；不复制prompt正文、question/document、模型答案、配置值、gold计数中的实际N或任意异常文本。

| 来源标签 | 边界与含义 |
| --- | --- |
| `source_system_position_bound` / `source_tool_schema_position_bound` | 根据冻结producer的system/tools位置归因，**不是与完整渲染模板逐字重建相等，也不是server tokenizer渲染实测**。 |
| `source_task_template_position_bound` | Search/Audit已知开头与 `Question:`/`Document segments:` 前的固定模板位置；异常开头转为unresolved，不擅自清洗。 |
| `provided_question_document_or_hypotheses` | 原题/原文/公开hypotheses；其中自然出现benchmark名字单列，既不改输入也不自动指控泄漏。 |
| `source_task_or_runtime_config_candidate` | HPO/NAS动态配置空间描述/提示未调用后端重建，其来源与内容结论保留未决，不读取oracle或完整gold来比较。 |
| `model_generated_history` | 请求里assistant content与tool_calls的marker-only历史；与源码提示分开，不据模型自己说出名字反推原始模板泄漏。 |
| `mixed_unresolved` | tool回显、后续user/环境历史、graph候选后缀及无法识别的初始模板；可能混合源控制语句、工具反馈、缓存和模型生成文本。 |

特别是 Pool `react_loop.py:222–234,355` 会增强第一条user消息；`parallel_cache.py:1951–1958` 将graph追加到该消息，并非只有后续tool结果包含graph。这里使用已知graph分隔符定位**候选后缀**并保持mixed_unresolved；原题自身也可能含相同分隔符，故分隔符不是可信的逐字符来源证明。不得将整个首user一概归为源码。

沿用原 `MARKERS`：hpobench、nasbench、ParamNet、PhantomWiki、ContractNLI、oracle、reference-performance，以及原 `There may be 1 to N correct answers` COUNT_HINT。这是有限、value-string层的词法规则，不是完整gold答案识别器；不匹配全部同义词或仅由schema/预算/参数范围推知的benchmark身份，不能证明不存在训练污染/任何形式泄漏。规则也用于历史字符串，但来源标签不同。JSON对象键本身、其他request顶层字段不作额外词法扩展。

assistant 消息顶层显式 `reasoning/reasoning_content/analysis/thinking` 字段不遍历：字段选择层只传入 assistant 的 `content` 与 `tool_calls`。该排除不适用于 tools schema 或已选择的业务对象；例如 `tools[0].function.parameters.properties.analysis.description` 必须扫描其字符串 value，其他三个同名业务属性同理。`response_raw`、`response_json`、结果/usage/score等原字段不访问其内容。读取整个raw文件与JSON反序列化不可避免，故**不是声称从磁盘上从未读到响应字节**；声明的是检查逻辑仅使用request_payload及必要attempt/owner元数据，不解释质量或评分。非法容器JSON即使可能包含可恢复子串也记不可审，不实现新的容错JSON提取器。

## 输出、限额与验收

每job一个 `jobs/<invocation_id>.json`，含全部已枚举attempt行；`COVERAGE.json`列全部705job；小 `RECEIPT.json`绑定各part/覆盖表SHA与源/profile/control refs，汇总未知、未覆盖与标记。没有巨大全请求重复汇总JSON。已观察输入最后再按原SHA读核；未读取raw范围不会因refs而扩大。

单原件128MiB，总实际读取量（包括最终复读）256GiB；单输出part32MiB；嵌套最多80层、每request marker最多10,000。超限保留不可审/失败，不自动扩容或截断后当完整。这些是原字节/输出界限，不是Python JSON DOM峰值RSS保证。输出必须全新且不在run/source内；多文件写入非事务，失败可留下部分新目录，没有完整receipt不得称成功。不resume、不覆盖、不删除原件或重跑模型。

保留 v1 原11项测试，新增两项回归（合计13项）：四个同名业务属性必须命中而 assistant 显式字段仍排除；8个已审映射文件加1个未映射文件时总分母为9、全称可审标志为false且不读取未映射原件。

CPU测试使用完全合成的705/783/1881形状（请求正文仅短占位），以及success/error/malformed/pending/缺payload、未启动、未映射dump、source/profile/closure pin错误、client复用/retry缺口、Pool初始graph、工具echo、自然题名、assistant历史、source计数提示、参数不符、重复JSON与私密路径拒绝。测试不调用原scorer，不加载真实任务数据。完整正分支覆盖通过也只是合成工程检查，真实执行与输出后独立审阅仍待全量封存。
