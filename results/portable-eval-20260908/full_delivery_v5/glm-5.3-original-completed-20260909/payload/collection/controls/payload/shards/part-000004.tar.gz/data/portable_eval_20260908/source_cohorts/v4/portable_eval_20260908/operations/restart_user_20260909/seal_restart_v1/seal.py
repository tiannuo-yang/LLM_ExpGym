"""Seal one explicitly bound, locally closed restart run. Standard library only.

This inventories evidence, not model performance. It neither imports nor runs
the launcher, scorer, resume checker, network client, or authorization helpers.
"""
import argparse
import collections
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat


class SealError(ValueError):
    pass


def require(condition, code):
    if not condition:
        raise SealError(code)


def utc():
    return datetime.now(timezone.utc).isoformat()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def path(value):
    p = Path(value)
    require(p.is_absolute() and ".." not in p.parts and p.resolve() == p,
            "absolute_nonalias_path_required")
    return p


def under(p, root):
    p = path(p)
    require(root in p.parents, "path_outside_explicit_run")
    return p


def stat_fields(s):
    return dict(device=s.st_dev, inode=s.st_ino, bytes=s.st_size, mode=s.st_mode,
                mtime_ns=s.st_mtime_ns, ctime_ns=s.st_ctime_ns)


def regular(value, keep_bytes=False):
    p = path(value)
    require(not any(k in p.name.lower() for k in
                    ("secret", "credential", "password", "api_key", "id_rsa", ".env")),
            "credential_like_filename_not_read")
    before = p.lstat()
    require(stat.S_ISREG(before.st_mode), "regular_file_required")
    digest, blocks = hashlib.sha256(), []
    fd = os.open(p, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, "rb") as stream:
        require(stat_fields(os.fstat(stream.fileno())) == stat_fields(before), "file_changed_before_read")
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
            if keep_bytes:
                blocks.append(block)
        require(stat_fields(os.fstat(stream.fileno())) == stat_fields(before), "file_changed_during_read")
    require(stat_fields(p.lstat()) == stat_fields(before), "file_changed_after_read")
    return dict(path=str(p), sha256=digest.hexdigest(), **stat_fields(before)), b"".join(blocks)


def strict_json(body):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate_json_key")
            result[key] = value
        return result
    def constant(unused):
        raise SealError("nonfinite_json_number")
    return json.loads(body, object_pairs_hook=pairs, parse_constant=constant)


def read_json(p):
    ref, body = regular(p, True)
    return strict_json(body), ref


def checked_ref(ref):
    require(type(ref) is dict and set(ref) in ({"path", "sha256"}, {"path", "sha256", "bytes"}),
            "explicit_file_ref_required")
    actual, body = regular(ref["path"], True)
    require(type(ref["sha256"]) is str and actual["sha256"] == ref["sha256"], "file_ref_hash_mismatch")
    if "bytes" in ref:
        require(type(ref["bytes"]) is int and ref["bytes"] == actual["bytes"], "file_ref_size_mismatch")
    return actual, body


def bound(ref):
    actual, body = checked_ref(ref)
    return strict_json(body), actual


def same_ref(left, right):
    return (type(left) is dict and {k: left.get(k) for k in ("path", "sha256")} ==
            {k: right.get(k) for k in ("path", "sha256")})


def pid_exists(pid):
    return Path("/proc", str(pid)).exists()


def unique_ids(value):
    require(type(value) is list and all(type(x) is str and x for x in value)
            and len(value) == len(set(value)), "unique_id_list_required")
    return value


def collect_tree(root):
    root = path(root)
    require(root.is_dir(), "explicit_run_directory_required")
    files, directories = [], []
    def failed(error):
        raise error
    for current, dirs, names in os.walk(root, followlinks=False, onerror=failed):
        directory = path(current)
        before = directory.lstat()
        require(stat.S_ISDIR(before.st_mode), "directory_required")
        directories.append(dict(path=str(directory), relative_path=str(directory.relative_to(root)),
                                **stat_fields(before)))
        dirs.sort()
        for name in dirs:
            require(stat.S_ISDIR((directory / name).lstat().st_mode), "directory_symlink_or_special")
        for name in sorted(names):
            p = directory / name
            ref, _ = regular(p)
            files.append(dict(relative_path=str(p.relative_to(root)), **ref))
    return sorted(files, key=lambda x: x["path"]), sorted(directories, key=lambda x: x["path"])


def closure(plan_ref, execution_ref, root):
    plan, actual_plan = bound(plan_ref)
    execution, actual_execution = bound(execution_ref)
    require(plan.get("schema_version") == "restart-executable-plan-v1" and
            execution.get("schema_version") == "restart-bounded-study-execution-v1", "wrong_restart_schema")
    expected = {"selected_smoke": 28, "formal_mixed": 705}.get(plan.get("mode"))
    require(expected is not None and type(plan.get("expected_invocations")) is int
            and plan["expected_invocations"] == expected, "exact_28_or_705_scope_required")
    require(path(plan["config"]["output_root"]) == root and path(execution_ref["path"]) == root / "execution.json",
            "plan_execution_run_root_mismatch")
    require(same_ref(execution.get("plan_ref"), plan_ref) and execution.get("mode") == plan["mode"]
            and execution.get("run_id") == plan["config"]["run_id"], "execution_identity_mismatch")
    require(type(execution.get("local_workers")) is int and execution["local_workers"] == 0,
            "local_workers_not_exact_zero")
    jobs = plan["jobs"]
    ids = unique_ids([j["invocation_id"] for j in jobs])
    require(len(ids) == expected, "exact_28_or_705_scope_required")
    by_id = {j["invocation_id"]: j for j in jobs}
    for job in jobs:
        for key in ("log_dir", "output_dir", "dump_dir", "terminal_evidence_dir"):
            under(job[key], root)
    started = unique_ids(execution["started_invocation_ids"])
    unstarted = unique_ids(execution["unstarted_invocation_ids"])
    require(not set(started) & set(unstarted) and set(started) | set(unstarted) == set(ids),
            "started_unstarted_partition_mismatch")
    reports = execution["reports"]
    require(type(reports) is list and set(unique_ids([r["invocation_id"] for r in reports])) == set(started),
            "one_terminal_report_per_started_required")
    flattened_ids, flattened_reports = [], []
    for index, stage in enumerate(execution["stages"]):
        require(type(stage.get("local_workers")) is int and stage["local_workers"] == 0,
                "stage_workers_not_exact_zero")
        stage_started = unique_ids(stage["started_invocation_ids"])
        stage_unstarted = unique_ids(stage["unstarted_invocation_ids"])
        require(not set(stage_started) & set(stage_unstarted) and set(stage_unstarted).issubset(unstarted),
                "stage_unstarted_partition_mismatch")
        flattened_ids.extend(stage_started)
        flattened_reports.extend(stage["reports"])
        drain, _ = read_json(root / "journal" / ("drain_%04d.json" % index))
        require(type(drain.get("local_workers")) is int and drain["local_workers"] == 0,
                "source_stage_drain_missing")
    require(flattened_ids == started and canonical(flattened_reports) == canonical(reports),
            "stage_execution_report_mismatch")
    initial, initial_ref = read_json(root / "execution_started.json")
    require(same_ref(initial.get("plan_ref"), plan_ref), "source_start_plan_mismatch")
    parent = initial.get("pid")
    require(type(parent) is int and parent > 0, "positive_parent_pid_required")
    require(not pid_exists(parent), "known_pid_present_identity_requires_root_review")
    pids, rows = {parent}, []
    by_report = {r["invocation_id"]: r for r in reports}
    for iid in started:
        logdir = path(by_id[iid]["log_dir"])
        reservation, _ = read_json(logdir / "reserved.json")
        require(reservation.get("invocation_id") == iid, "reservation_identity_mismatch")
        terminal, terminal_ref = read_json(logdir / "terminal.json")
        terminal.pop("recorded_at_utc", None)
        require(canonical(terminal) == canonical(by_report[iid]), "terminal_execution_report_mismatch")
        require(terminal["report"].get("invocation_id") == iid, "nested_terminal_identity_mismatch")
        require((logdir / "source_capture.json").is_file(), "source_capture_missing_requires_root_review")
        capture, capture_ref = read_json(logdir / "source_capture.json")
        require(type(capture.get("exit_code")) is int and all(capture.get(k) is True for k in
                ("child_started", "stdout_eof_observed", "wait_returned", "drain_proven")),
                "source_child_capture_not_closed")
        require(canonical(capture) == canonical(terminal["report"].get("source_capture")),
                "source_capture_report_mismatch")
        for name in ("source_started.json", "verify_started.json"):
            p = logdir / name
            if p.exists():
                value, _ = read_json(p)
                require(value.get("invocation_id") == iid and type(value.get("pid")) is int
                        and value["pid"] > 0, "child_pid_identity_missing")
                pids.add(value["pid"])
        status = terminal["report"].get("terminal_status") or {}
        rows.append(dict(invocation_id=iid, terminal_ref=terminal_ref, source_capture_ref=capture_ref,
                         source_exit_code=capture["exit_code"],
                         decision_classification=terminal.get("decision", {}).get("classification"),
                         terminal_classification=status.get("terminal_classification"),
                         score_complete=status.get("score_complete"),
                         model_no_answer_count=status.get("model_no_answer_count"),
                         error_type=terminal["report"].get("error_type")))
    for iid in unstarted:
        require(not (path(by_id[iid]["log_dir"]) / "source_started.json").exists(),
                "source_started_for_declared_unstarted_job")
    raw_states, raw_issues, raw_count = collections.Counter(), [], 0
    for p in sorted((root / "dumps").rglob("*.json")):
        raw_count += 1
        try:
            raw, _ = read_json(p)
        except (ValueError, UnicodeError, RecursionError, OverflowError) as error:
            # Preserve malformed original evidence; closure comes from the
            # already-waited source process, not an invented successful raw.
            raw_issues.append(dict(path=str(p), issue="unparseable_raw", error_type=type(error).__name__))
            continue
        if not isinstance(raw, dict):
            raw_issues.append(dict(path=str(p), issue="nonobject_raw"))
            continue
        raw_states[str(raw.get("state"))] += 1
        pid = raw.get("pid")
        if type(pid) is int and pid > 0:
            pids.add(pid)
        else:
            raw_issues.append(dict(path=str(p), issue="raw_pid_missing_or_invalid"))
        if raw.get("state") == "in_progress" or raw.get("finished_at_utc") is None:
            raw_issues.append(dict(path=str(p), issue="raw_not_recorded_terminal"))
        if raw.get("error") is not None:
            raw_issues.append(dict(path=str(p), issue="original_raw_error_present"))
    require(not any(pid_exists(pid) for pid in pids), "known_pid_present_identity_requires_root_review")
    return dict(expected_invocations=expected, mode=plan["mode"], run_id=execution["run_id"],
                started_ids=started, unstarted_ids=unstarted, parent_pid=parent, known_pids=sorted(pids),
                rows=rows, original_execution_complete=execution.get("execution_complete"),
                original_score_complete=execution.get("score_complete"),
                plan_ref=actual_plan, execution_ref=actual_execution, execution_started_ref=initial_ref,
                raw_count=raw_count, raw_states=dict(raw_states), raw_issues=raw_issues,
                local_workers=0, provider_quiescence_proven=False)


def write_new(root, name, value):
    p = root / name
    with p.open("xb") as stream:
        stream.write(canonical(value) + b"\n")
    return regular(p)[0]


def seal(plan_ref, execution_ref, run_root, output_dir, control_refs=()):
    source_ref = regular(Path(__file__).resolve())[0]
    root, output = path(run_root), path(output_dir)
    require(root.is_dir() and not output.exists() and output.parent.is_dir(), "existing_run_and_fresh_report_required")
    require(root != output and root not in output.parents and output not in root.parents,
            "report_run_overlap")
    plan, _ = bound(plan_ref)
    # Check the declared secret PATH only. Never stat, hash, open or recurse it.
    credential = Path(plan["config"]["credential_path"])
    require(credential.is_absolute() and ".." not in credential.parts and
            credential != root and root not in credential.parents, "credential_inside_run_forbidden")
    refs = [plan_ref, execution_ref] + list(control_refs)
    require(all(Path(ref["path"]) != credential for ref in refs), "credential_control_ref_forbidden")
    controls = [checked_ref(ref)[0] for ref in refs]
    began = utc()
    initial_closure = closure(plan_ref, execution_ref, root)
    files, dirs = collect_tree(root)
    output.mkdir(mode=0o700)
    parts = []
    for offset in range(0, len(files), 2000):
        values = files[offset:offset + 2000]
        parts.append(dict(file_count=len(values), total_bytes=sum(v["bytes"] for v in values),
                          **write_new(output, "inventory.part%03d.json" % (offset // 2000), values)))
    directory_ref = write_new(output, "inventory.directories.json", dirs)
    closure_ref = write_new(output, "closure.json", initial_closure)
    files2, dirs2 = collect_tree(root)
    require(files == files2 and dirs == dirs2, "run_changed_between_complete_inventories")
    require(controls == [checked_ref(ref)[0] for ref in refs], "control_refs_changed_during_seal")
    require(canonical(initial_closure) == canonical(closure(plan_ref, execution_ref, root)),
            "local_closure_changed_during_seal")
    require(source_ref == regular(Path(__file__).resolve())[0], "sealer_source_changed_during_seal")
    inventory = dict(schema_version="restart-closed-run-inventory-v1", run_root=str(root),
        started_utc=began, finished_utc=utc(), file_count=len(files), directory_count=len(dirs),
        total_bytes=sum(f["bytes"] for f in files), file_parts=parts, directories_ref=directory_ref,
        closure_ref=closure_ref, control_refs=controls, full_second_read_equal=True,
        file_count_scope="Complete run tree; explicit control files are separately listed, never recursively followed.",
        sealer_source_ref=source_ref,
        original_execution_complete=initial_closure["original_execution_complete"],
        original_score_complete=initial_closure["original_score_complete"],
        expected_invocations=initial_closure["expected_invocations"],
        started_count=len(initial_closure["started_ids"]), unstarted_count=len(initial_closure["unstarted_ids"]),
        model_or_network_calls_by_sealer=0, provider_quiescence_proven=False,
        limitations=["Evidence preservation, not a new score, protocol pass, authority or performance qualification.",
          "Normal model_no_answer and drained infrastructure failures retain their original status and bytes.",
          "No private provider queue assertion; raw errors or incomplete records are retained explicitly.",
          "No new caller request can be issued by absent known callers; no API, resume or scorer is invoked here.",
          "Any PID still present requires ROOT identity review; PID reuse is not diagnosed as an active run."])
    return write_new(output, "inventory.json", inventory)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("plan", "plan-sha256", "execution", "execution-sha256", "run-root", "output-dir"):
        parser.add_argument("--" + name, required=True)
    parser.add_argument("--control-ref", action="append", nargs=2, default=[], metavar=("PATH", "SHA256"))
    args = parser.parse_args(argv)
    try:
        result = seal({"path": args.plan, "sha256": args.plan_sha256},
                      {"path": args.execution, "sha256": args.execution_sha256}, args.run_root,
                      args.output_dir, [{"path": p, "sha256": h} for p, h in args.control_ref])
    except (SealError, OSError, ValueError, TypeError, KeyError, RecursionError, OverflowError) as error:
        # Never print artifact content, credential paths, or arbitrary errors.
        print(json.dumps({"sealed": False, "error_type": type(error).__name__,
                          "reason": str(error) if isinstance(error, SealError) else "original_evidence_unavailable_or_invalid"}))
        return 2
    print(json.dumps({"sealed": True, "inventory_ref": result}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
