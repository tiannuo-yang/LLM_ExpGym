# GLM 正式 exporter v2 单次操作记录

ROOT GO `a18dc75b…` 与 seal 接受 `b8f16699…` 核对后，原 frozen exporter v2 单次真实执行；session **27504**，最终 chunk **c877b6**，exit **0**。没有外加 Popen wrapper、没有第二次 AN2、原 scorer、模型/API 或重试。

原 CLI 前 UTC 标记为 2026-09-09 18:57:36.270724868；18:59:11 UTC 已观察真实退出。后者不是精确进程结束打点，不能据此声称精确 CPU duration。

新产物目录：`../actual_formal_export_glm_completed_v2/`。exact 17 files / **57,121,223 bytes**，全部文件 SHA/bytes 与 EXPORT_INDEX 一致，内部 OUTPUT_INDEX 的 9 个条目也逐项一致。program 与三个显式输入、seal、ROOT 接受和 GO 前后 SHA 均不变。完整 refs 见 [OPERATOR_RECEIPT.json](OPERATOR_RECEIPT.json) 和 [POSTCHECK.json](POSTCHECK.json)。

输出报告 783 logical records / 18,403 unique raw attempts / 514 comparisons（6 primary + 508 secondary）。六个原报告主效应 E-S/E-A/E-H/P-S/P-A/P-H 依次为 **0.4520757021 / 0.1825037707 / 11.8442541020 / 0.0914529915 / 0.1674208145 / 6.3516052814**；均是原描述性输出抄录，不是本操作员独立复算。Exp 表示 Free−Tight 效用差，Pool 表示既定同预算 PoolAct−naive N4，不能混称同一比较；P-H 仅 NAS101A Tight。R1 SD/CI 为 null，R3 仅描述 SD，全 p/CI 仍为空。

[PRIMARY_REPORTED.json](PRIMARY_REPORTED.json) 保留原六行所有字段；[PROGRAM_OUTPUT.txt](PROGRAM_OUTPUT.txt) 与 [EXECUTION_TOOL_OUTPUT.json](EXECUTION_TOOL_OUTPUT.json) 留存工具真实退出记录。新增操作记录在独立目录，未向原 17 个产物增添文件或改写原件。

**角色与界限**：我是 AN2/exporter 作者，本记录不是 fresh 独立科学验收；seal 由外部 ROOT 接受，原 CLI 没有 seal 参数。最终独立原评分、汇总、成本与联合报告复核仍为 pending；这次操作没有执行远端 restored AN2 relocation/replay。
