"""One ROOT-authorized invocation of the unchanged nine-GET collector."""
import hashlib
import json
import os
from pathlib import Path
import resource
import stat
import subprocess
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
GO = HERE / 'ROOT_CAPTURE_GO.json'
GO_SHA = '3db10e6c4bd94875e279c8bb2b555c7b7809d5ec3f9a775a6e833f9f21cb4c74'

def utc():
    return datetime.now(timezone.utc).isoformat()

def raw(path):
    fd = os.open(str(path), os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        s = os.fstat(fd)
        assert stat.S_ISREG(s.st_mode) and s.st_nlink == 1
        with os.fdopen(fd, 'rb', closefd=False) as f:
            return f.read()
    finally:
        os.close(fd)

def ref(path):
    data = raw(path)
    return {'path': str(path), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}

def write(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2, sort_keys=True)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())

def main():
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    assert ref(GO)['sha256'] == GO_SHA
    go = json.loads(raw(GO))
    for key in ('program_ref', 'deployment_ref', 'root_terminal_ref'):
        assert ref(Path(go[key]['path']))['sha256'] == go[key]['sha256']
    deployment = Path(go['deployment_ref']['path'])
    dep = json.loads(raw(deployment))
    assert dep['job_id'] == '1203652' and dep['phase'] == 'glm_formal'
    base = deployment.parents[3]
    for name, digest in dep['source_sha256'].items():
        assert ref(base / name)['sha256'] == digest
    assert ref(Path(dep['runtime_receipt']))['sha256'] == dep['runtime_receipt_sha256'] == '6ae2baf43591acaad1be8b4f0dfe7fc705996313d1f588ce7cb63990cb892111'
    output = Path(go['output_dir'])
    assert output == HERE / 'capture' and not output.exists()
    key = Path(dep['router_api_key_file'])
    assert key == deployment.parent / 'private/router_api_key'
    metadata = []
    for path in list(reversed(key.parents)) + [key]:
        s = path.lstat()
        assert not stat.S_ISLNK(s.st_mode)
        assert stat.S_ISREG(s.st_mode) if path == key else stat.S_ISDIR(s.st_mode)
        metadata.append({'path': str(path), 'uid': s.st_uid, 'mode': oct(stat.S_IMODE(s.st_mode)), 'nlink': s.st_nlink})
    assert metadata[-1]['uid'] == 1071 and metadata[-1]['mode'] == '0o600' and metadata[-1]['nlink'] == 1
    assert not stat.S_IMODE(key.parent.lstat().st_mode) & 0o077
    operator = HERE / 'operator_capture_v1'
    operator.mkdir(exist_ok=False)
    write(operator / 'begin.json', {'utc': utc(), 'go': ref(GO), 'source': ref(Path(__file__)), 'core_limit': list(resource.getrlimit(resource.RLIMIT_CORE)), 'key_metadata_only': metadata})
    for stem, argv in [('pre_job', ['scontrol', 'show', 'job', '-o', '1203652']), ('pre_steps', ['squeue', '-h', '--steps', '-j', '1203652', '-o', '%i %j %N'])]:
        write(operator / (stem + '.command.json'), {'utc': utc(), 'argv': argv})
        with (operator / (stem + '.stdout')).open('xb') as out, (operator / (stem + '.stderr')).open('xb') as err:
            code = subprocess.run(argv, stdout=out, stderr=err, timeout=30).returncode
        write(operator / (stem + '.exit.json'), {'utc': utc(), 'exit_code': code})
        assert code == 0
    job = raw(operator / 'pre_job.stdout').decode()
    for item in ('JobId=1203652', 'JobName=portable-glm-8n', 'UserId=chufan.shi(1071)', 'Account=k2p', 'Partition=higherprio', 'StartTime=2026-09-08T21:52:40', 'JobState=RUNNING', 'Requeue=0', 'Restarts=0', 'NodeList=azure-uk-hpc-H200-instance-[300-307]', 'NumNodes=8', 'gres/gpu=64', 'Command=' + str(base / 'phase_8nodes.sbatch')):
        assert item in job
    ids = {line.split()[0] for line in raw(operator / 'pre_steps.stdout').decode().splitlines()}
    assert ids == {'1203652.' + str(i) for i in range(18, 27)} | {'1203652.batch', '1203652.extern'}
    argv = ['/usr/bin/python3', '-B', go['program_ref']['path'], '--deployment', str(deployment), '--output', str(output), '--root-reference', str(GO), '--root-reference-sha256', GO_SHA]
    write(operator / 'capture.command.json', {'utc': utc(), 'argv': argv})
    with (operator / 'capture.stdout').open('xb') as out, (operator / 'capture.stderr').open('xb') as err:
        child = subprocess.Popen(argv, stdout=out, stderr=err)
        write(operator / 'capture.child.json', {'pid': child.pid, 'utc': utc()})
        code = child.wait()
    write(operator / 'capture.exit.json', {'utc': utc(), 'exit_code': code})
    receipt = {'utc': utc(), 'exit_code': code, 'go': ref(GO), 'capture': ref(output / 'capture.json') if (output / 'capture.json').is_file() else None, 'model_calls': 0, 'retries': 0, 'finish_or_signal_performed': False}
    write(operator / 'receipt.json', receipt)
    print(json.dumps(ref(operator / 'receipt.json')))
    raise SystemExit(code)

if __name__ == '__main__':
    main()
