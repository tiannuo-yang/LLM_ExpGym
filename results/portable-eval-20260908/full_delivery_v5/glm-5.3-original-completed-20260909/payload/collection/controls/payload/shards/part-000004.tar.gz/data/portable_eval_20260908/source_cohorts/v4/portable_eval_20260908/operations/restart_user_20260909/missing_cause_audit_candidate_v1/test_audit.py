"""Hand-built synthetic contracts; never open an actual run or answer dump."""
import copy
import json
from pathlib import Path
import socket
import subprocess
import tempfile
import unittest
from unittest import mock

import audit as a


def pure():
    d = a.dependency('format_diagnostics_candidate_v2/diagnostics.py')
    return a.pure_source(d.Reader(), a.SOURCE)


def fixture(*, final=True, content=None, finish='length', extra=None, retry=False, cap=131072, initial_reason='Time budget exceeded'):
    """One tool decision then an optional forced final; hand-written expectations."""
    identity = {'client_id': 'c' * 32, 'seed': 101, 'model_id': 'SYNTHETIC', 'run_id': 'SYNTHETIC'}
    schema = [{'type': 'function', 'function': {'name': 'search', 'parameters': {'type': 'object'}}}]
    messages = [{'role': 'system', 'content': 'SYNTHETIC instructions'}, {'role': 'user', 'content': 'SYNTHETIC task'}]
    first = {'role': 'assistant', 'content': None, 'tool_calls': [{'id': 'tool1', 'type': 'function',
              'function': {'name': 'search', 'arguments': '{}'}}]}
    if not final:
        first['reasoning_content'] = 'x' * 5000
    final_message = dict({'role': 'assistant', 'content': content}, **(extra or {}))
    raws, calls, captured = {}, [], []
    note = 'System: Loop aborted (' + initial_reason + '). Respond immediately with Answer: <your final choice> and no other text.'
    def put_call(message, reason, forced, index):
        payload = {'model': 'SYNTHETIC', 'seed': 101, 'max_tokens': 32768,
                   'tools': schema, 'tool_choice': 'none' if forced else 'auto', 'messages': copy.deepcopy(messages)}
        usage = {'prompt_tokens': 100, 'completion_tokens': 32768 if reason == 'length' else 5,
                 'completion_tokens_details': {'reasoning_tokens': 4}}
        data = {'choices': [{'message': message, 'finish_reason': reason}], 'usage': usage}
        attempts = []
        for i in range(2 if retry and forced else 1):
            is_retry = retry and forced and i == 0
            rid, gid = str(index) * 30 + str(i + 1) * 2, str(index) * 32
            raw = {'schema_version': 'expgym.api_attempt.v1', 'request_id': rid, 'client_id': identity['client_id'],
                   'generation_id': gid, 'attempt': i + 1, 'run_id': identity['run_id'],
                   'state': 'error' if is_retry else 'success', 'will_retry': is_retry,
                   'request_payload': copy.deepcopy(payload), 'response_raw': None if is_retry else json.dumps(data),
                   'response_json': None if is_retry else copy.deepcopy(data),
                   'error': {'type': 'TimeoutError', 'message': 'SYNTHETIC'} if is_retry else None,
                   'http_status': None}
            raws[rid] = raw
            attempts.append({k: raw[k] for k in ('request_id', 'generation_id', 'attempt', 'state', 'http_status')})
            attempts[-1]['usage'] = None if is_retry else copy.deepcopy(usage)
        calls.append({'llm_call_index': index, 'attempts': attempts})
        captured.append({'forced': forced, 'finish_reason': reason, 'output_message': copy.deepcopy(message),
                         'attempt_usage': copy.deepcopy(attempts)})
        messages.append(copy.deepcopy(message))
    put_call(first, 'tool_calls', False, 1)
    messages.append({'role': 'tool', 'tool_call_id': 'tool1', 'content': 'Observation: [over-budget — result withheld.]'})
    messages.append({'role': 'user', 'content': note})
    failures = []
    if final:
        put_call(final_message, finish, True, 2)
        branch = 'tools_disabled' if final_message.get('tool_calls') else 'length' if finish == 'length' else 'text_action' if type(content) is str and content.startswith('Action:') else 'empty'
        failures.append({'llm_call_index': 2, 'agent_step': 1, 'forced': True,
                         'reason': a.FORCED_REASONS[branch], 'finish_reason': finish})
    snapshot = {'answer': None, 'aborted': True, 'termination_reason': initial_reason, 'tool_protocol': 'native',
                'api_calls': len(calls), 'agent_steps': 1, 'http_request_attempts': len(raws), 'usage_attempts': calls,
                'messages': messages, 'protocol_failures': failures, 'tool_records': [['search', '{}', 'SYNTHETIC']],
                'evaluations': 1, 'total_overhead': 1.0, 'eval_time': 1.0, 'wall_time_seconds': 1.0,
                '_trace_v2_capture': {'llm_calls': captured}}
    return snapshot, calls, raws, identity, cap, captured


def run(f, source=None, system='poolact'):
    snapshot, calls, raws, identity, cap, captured = copy.deepcopy(f)
    return a.classify(snapshot, calls, raws, identity, source or pure(), system=system,
                      context_cap=cap if system == 'poolact' else None, exp_calls=captured if system == 'expgym' else None)


class Mechanisms(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pure = pure()

    def test_length_nonempty_is_intentional_loop_rejection(self):
        result = run(fixture(content='SYNTHETIC partial answer'), self.pure)
        self.assertEqual(result['mechanism'], 'forced_length_nonempty_text_rejected')
        self.assertTrue(result['final_request_delivered'])
        self.assertTrue(result['call_observations'][-1]['response']['reported_32768_length_exhaustion'])
        self.assertNotIn(b'SYNTHETIC partial answer', a.dump(result))

    def test_context_cap_prevents_final_not_model_refusal(self):
        result = run(fixture(final=False, cap=200), self.pure)
        self.assertFalse(result['final_request_delivered'])
        self.assertEqual(result['mechanism'], 'execution_context_cap_prevented_final_request')
        self.assertFalse(result['context_gate']['would_admit'])

    def test_no_final_but_admissible_or_exp_is_unknown(self):
        f = fixture(final=False)
        for system in ('poolact', 'expgym'):
            result = run(f, self.pure, system)
            self.assertEqual(result['mechanism'], 'unknown')
            self.assertFalse(result['final_request_delivered'])

    def test_reasoning_and_refusal_are_not_answer_content(self):
        for content in (None, '', '  '):
            result = run(fixture(content=content, finish='stop', extra={'reasoning_content': 'PRIVATE REASON', 'refusal': 'PRIVATE REFUSAL'}), self.pure)
            final = result['call_observations'][-1]['response']
            self.assertEqual(result['mechanism'], 'forced_response_empty_decoder_text')
            self.assertTrue(final['reasoning_content']['nonblank'])
            self.assertTrue(final['refusal']['nonblank'])
            self.assertNotIn(b'PRIVATE', a.dump(result))

    def test_content_list_decoder_projection_and_malformed(self):
        result = run(fixture(content=[{'type': 'output_text', 'text': 'PRIVATE'}], finish='stop'), self.pure)
        self.assertEqual(result['call_observations'][-1]['response']['content_part_types'], ['output_text'])
        self.assertEqual(result['mechanism'], 'forced_response_empty_decoder_text')
        result = run(fixture(content=[{'type': 'text', 'text': 'PRIVATE'}]), self.pure)
        self.assertEqual(result['mechanism'], 'forced_length_nonempty_text_rejected')
        with self.assertRaises(ValueError):
            run(fixture(content=[{'type': 'text', 'text': 7}]), self.pure)

    def test_retry_uses_final_accepted_attempt_not_filename(self):
        result = run(fixture(retry=True, finish='stop'), self.pure)
        final = result['call_observations'][-1]
        self.assertEqual(len(final['attempts']), 2)
        self.assertEqual(result['final_request_id'], final['attempts'][1]['request_id'])
        self.assertEqual(result['mechanism'], 'forced_response_empty_decoder_text')

    def test_http_503_body_with_choices_is_still_transport_retry(self):
        f = fixture(retry=True)
        earlier = f[2][f[1][-1]['attempts'][0]['request_id']]
        earlier.update(error={'type': 'HTTPError'}, http_status=503,
                       response_json={'choices': []}, response_raw='{"choices": []}')
        result = run(f, self.pure)
        self.assertEqual(result['mechanism'], 'forced_length_empty_decoder_text')

    def test_completion_null_uses_original_output_tokens_fallback(self):
        f = fixture()
        rid = f[1][-1]['attempts'][-1]['request_id']
        raw = f[2][rid]
        raw['response_json']['usage'].update(completion_tokens=None, output_tokens=32768)
        raw['response_raw'] = json.dumps(raw['response_json'])
        f[1][-1]['attempts'][-1]['usage'] = copy.deepcopy(raw['response_json']['usage'])
        self.assertTrue(run(f, self.pure)['call_observations'][-1]['response']['reported_32768_length_exhaustion'])

    def test_raw_owner_identity_mismatches_are_integrity_errors(self):
        for field, value in (('client_id', 'other'), ('generation_id', 'other'), ('attempt', 4), ('run_id', 'other')):
            f = fixture()
            f[2][f[1][-1]['attempts'][-1]['request_id']][field] = value
            with self.assertRaises(ValueError):
                run(f, self.pure)
        f = fixture()
        f[2][f[1][-1]['attempts'][-1]['request_id']]['request_payload']['seed'] = True
        with self.assertRaises(ValueError):
            run(f, self.pure)

    def test_missing_extra_and_reordered_calls_fail_closed(self):
        f = fixture()
        f[2].pop(f[1][-1]['attempts'][-1]['request_id'])
        with self.assertRaises(ValueError):
            run(f, self.pure)

    def test_boolean_call_and_attempt_indices_rejected(self):
        for kind in ('call', 'attempt'):
            f = fixture()
            if kind == 'call':
                f[1][0]['llm_call_index'] = True
            else:
                rid = f[1][0]['attempts'][0]['request_id']
                f[1][0]['attempts'][0]['attempt'] = True
                f[2][rid]['attempt'] = True
            with self.assertRaises(ValueError):
                run(f, self.pure)

    def test_boolean_terminal_event_agent_id_rejected(self):
        snapshot = fixture()[0]
        event = {'event': 'loop_terminal', 'schema_version': 'expgym.terminal-evidence.v1',
                 'owner': {'runner': 'poolact', 'seed': 101, 'agent_id': False, 'strategy': 'naive'},
                 'completion_marker': False, 'score_acceptance_authority': False,
                 'payload': {'capture_point': 'raw_return_before_caller_and_scorer_mutations', 'loop_result': snapshot}}
        with self.assertRaises(ValueError):
            a.snapshot_for([({}, event)], 101, True, 0, dict(snapshot, strategy='naive'))
        f = fixture()
        f[2]['orphan'] = copy.deepcopy(next(iter(f[2].values())))
        with self.assertRaises(ValueError):
            run(f, self.pure)
        f = fixture()
        f[1].reverse()
        with self.assertRaises(ValueError):
            run(f, self.pure)

    def test_transport_abort_and_semantic_retry_not_model_missing(self):
        f = fixture()
        rid = f[1][-1]['attempts'][-1]['request_id']
        f[2][rid].update(state='error', error={'type': 'TimeoutError'})
        f[1][-1]['attempts'][-1]['state'] = 'error'
        with self.assertRaises(ValueError):
            run(f, self.pure)
        with self.assertRaises(ValueError):
            run(fixture(finish='abort'), self.pure)
        f = fixture(retry=True)
        earlier = f[2][f[1][-1]['attempts'][0]['request_id']]
        earlier['response_json'] = {'choices': [{'finish_reason': 'length'}]}
        with self.assertRaises(ValueError):
            run(f, self.pure)

    def test_nonempty_stop_cannot_be_called_missing(self):
        with self.assertRaises(ValueError):
            run(fixture(content='Answer: SYNTHETIC', finish='stop'), self.pure)

    def test_forced_tools_and_text_action_follow_original_precedence(self):
        tool = {'id': 'forbidden', 'type': 'function', 'function': {'name': 'search', 'arguments': '{}'}}
        r = run(fixture(content=None, extra={'tool_calls': [tool]}), self.pure)
        self.assertEqual(r['mechanism'], 'forced_response_tools_rejected')
        r = run(fixture(content='Action: search {}', finish='stop'), self.pure)
        self.assertEqual(r['mechanism'], 'forced_text_action_rejected')

    def test_unknown_usage_not_zero_or_cumulative_limit_evidence(self):
        f = fixture()
        rid = f[1][-1]['attempts'][-1]['request_id']
        raw = f[2][rid]
        raw['response_json']['usage'] = None
        raw['response_raw'] = json.dumps(raw['response_json'])
        f[1][-1]['attempts'][-1]['usage'] = None
        result = run(f, self.pure)
        self.assertIsNone(result['call_observations'][-1]['response']['reported_32768_length_exhaustion'])
        self.assertTrue(result['unknown_reasons'])

    def test_untrusted_usage_finish_and_abort_text_not_exported(self):
        f = fixture(initial_reason="Unknown tool 'PRIVATE ARGUMENT'", finish='PRIVATE FINISH')
        rid = f[1][-1]['attempts'][-1]['request_id']
        raw = f[2][rid]
        raw['response_json']['usage']['debug'] = 'PRIVATE REASON'
        raw['response_json']['usage']['completion_tokens_details']['debug'] = 'PRIVATE MORE'
        raw['response_raw'] = json.dumps(raw['response_json'])
        f[1][-1]['attempts'][-1]['usage'] = copy.deepcopy(raw['response_json']['usage'])
        result = run(f, self.pure)
        self.assertNotIn(b'PRIVATE', a.dump(result))
        self.assertEqual(result['call_observations'][-1]['response']['usage_extra_fields_omitted'], 2)

    def test_capture_or_terminal_assistant_disagreement_fails(self):
        f = fixture()
        f[-1][-1]['forced'] = False
        with self.assertRaises(ValueError):
            run(f, self.pure, 'expgym')
        f = fixture()
        f[0]['messages'][-1]['content'] = 'altered'
        with self.assertRaises(ValueError):
            run(f, self.pure)

    def test_rejection_marker_is_required(self):
        f = fixture()
        f[0]['protocol_failures'] = []
        with self.assertRaises(ValueError):
            run(f, self.pure)

    def test_no_network_or_subprocess_needed(self):
        with mock.patch.object(socket, 'socket', side_effect=AssertionError('network forbidden')), mock.patch.object(subprocess, 'Popen', side_effect=AssertionError('subprocess forbidden')):
            self.assertTrue(run(fixture(), self.pure)['final_request_delivered'])

    def test_source_pin_fail_closed(self):
        d = a.dependency('format_diagnostics_candidate_v2/diagnostics.py')
        with self.assertRaises(ValueError):
            a.pure_source(d.Reader(read=lambda _: b'# mutated'), a.SOURCE)


if __name__ == '__main__':
    unittest.main(verbosity=2)
