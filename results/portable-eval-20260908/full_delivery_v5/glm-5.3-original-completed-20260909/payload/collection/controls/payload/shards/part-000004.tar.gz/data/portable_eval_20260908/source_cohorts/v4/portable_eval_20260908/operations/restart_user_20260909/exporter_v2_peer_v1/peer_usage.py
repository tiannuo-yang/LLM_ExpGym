#!/usr/bin/env python3
"""Bounded synthetic usage-only peer; never imports exporter or executes export."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import platform
import stat
import sys
import unittest

OP = Path(__file__).resolve().parent.parent
PINS = {
    "exporter_candidate_v1/exporter.py": "e555578c35795aba6fffc8ee90eb60751b5e60739c656c31db86ab2cb02cb4cd",
    "exporter_candidate_v1/test_exporter.py": "fd5a2d77c25483c8f9a0cb2f9891a59a78d58d5745fb122d80683a1faf5c73e6",
    "exporter_candidate_v2/exporter.py": "c70319b2c1cd586859572f7c4d066acb847c36ef2424e84027553aa72346747c",
    "exporter_candidate_v2/test_exporter.py": "cc873d7a3f1772b86ca1242e0ae83f9ad8d96a99edf0de87957a6a94ec76c97d",
    "exporter_candidate_v2/README.zh.md": "506909f4849f0c35081aaaba711e4d48991c28be06faade2c4cd70cf3a1290a3",
    "exporter_candidate_v2/CPU_RECEIPT.json": "9a9acce22a60e20e80102b0612b183dbe675f30e4bb406aab0393b76232f7698",
    "exporter_candidate_v2/PRODUCTION_DIFF.patch": "1b400bb3e197a4b05098015b97f67595b7a0dfb6c58c6fc80e77d536a2cd7c88",
}


def snapshot():
    blobs, refs = {}, []
    for relative, expected in PINS.items():
        p = OP / relative
        before = p.lstat()
        assert stat.S_ISREG(before.st_mode) and before.st_size < 1024 * 1024
        blob = p.read_bytes()
        after = p.lstat()
        signature = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
        assert signature(before) == signature(after)
        assert hashlib.sha256(blob).hexdigest() == expected
        blobs[relative] = blob
        refs.append({"path": str(p), "bytes": len(blob), "sha256": expected,
                     "mtime_ns_decimal": str(before.st_mtime_ns)})
    return blobs, refs


def static_check(blobs):
    old = blobs["exporter_candidate_v1/exporter.py"].decode()
    new = blobs["exporter_candidate_v2/exporter.py"].decode()
    ot, nt = ast.parse(old), ast.parse(new)
    oun = next(n for n in ot.body if isinstance(n, ast.FunctionDef) and n.name == "usage")
    nun = next(n for n in nt.body if isinstance(n, ast.FunctionDef) and n.name == "usage")
    def outside(text, node):
        lines = text.splitlines(keepends=True)
        return "".join(lines[:node.lineno - 1] + lines[node.end_lineno:])
    assert outside(old, oun) == outside(new, nun)
    diff = "".join(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
        fromfile="exporter_candidate_v1/exporter.py", tofile="exporter_candidate_v2/exporter.py"))
    assert diff.encode() == blobs["exporter_candidate_v2/PRODUCTION_DIFF.patch"]
    old_tests = ast.parse(blobs["exporter_candidate_v1/test_exporter.py"])
    new_tests = ast.parse(blobs["exporter_candidate_v2/test_exporter.py"])
    new_classes = [n for n in new_tests.body if isinstance(n, ast.ClassDef) and n.name == "ReasoningUsageV2Tests"]
    assert len(new_classes) == 1
    new_tests.body.remove(new_classes[0])
    assert ast.dump(old_tests, include_attributes=False) == ast.dump(new_tests, include_attributes=False)
    old_class = next(n for n in old_tests.body if isinstance(n, ast.ClassDef) and n.name == "ExportTests")
    count = sum(isinstance(n, ast.FunctionDef) and n.name.startswith("test_") for n in old_class.body)
    assert count == 14
    return {"only_usage_changed_bytewise": True, "owner_patch_matches_exact_diff": True,
            "all_original_test_module_AST_unchanged_after_removing_new_class": True, "original_tests": count}


def isolated_usage(blob):
    tree = ast.parse(blob)
    nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in ("require", "usage")]
    assert {n.name for n in nodes} == {"require", "usage"}
    module = ast.Module(body=nodes, type_ignores=[])
    ns = {"__name__": "usage_only_peer"}
    exec(compile(module, "<pinned-usage-only>", "exec"), ns)
    return ns["usage"]


def raw(**usage):
    return {"response_json": {"usage": usage}}


class UsagePeer(unittest.TestCase):
    def test_flat_red_green_single_valid_zero_and_error(self):
        sample = raw(prompt_tokens=11, completion_tokens=7, reasoning_tokens=5)
        self.assertIsNone(V1([sample])["reasoning_tokens"]["complete_total"])
        got = V2([sample])
        self.assertEqual(got["reasoning_tokens"], dict(complete_total=5, known_sum=5, unknown_attempts=0, attempts=1))
        self.assertEqual(got["input_tokens"], V1([sample])["input_tokens"])
        self.assertEqual(got["output_tokens"], V1([sample])["output_tokens"])
        zero = raw(completion_tokens=0, reasoning_tokens=0, completion_tokens_details={"reasoning_tokens": True})
        self.assertEqual(V2([zero])["reasoning_tokens"]["complete_total"], 0)
        mixed = V2([sample, {"state": "error", "response_json": None}])
        self.assertEqual(mixed["reasoning_tokens"], dict(complete_total=None, known_sum=5, unknown_attempts=1, attempts=2))
        self.assertIsNone(mixed["output_tokens"]["complete_total"])

    def test_valid_dual_conflict_fails_without_preference(self):
        sample = raw(completion_tokens=None, reasoning_tokens=3, completion_tokens_details={"reasoning_tokens": 2})
        self.assertEqual(V1([sample])["reasoning_tokens"]["complete_total"], 2)
        with self.assertRaisesRegex(ValueError, "conflicting flat/nested"):
            V2([sample])

    def test_same_attempt_bound_survives_other_unknown_or_spare_tokens(self):
        invalid = raw(completion_tokens=5, completion_tokens_details={"reasoning_tokens": 6})
        other_unknown = {"state": "error", "response_json": None}
        self.assertEqual(V1([invalid, other_unknown])["reasoning_tokens"]["known_sum"], 6)
        with self.assertRaisesRegex(ValueError, "attempt reasoning exceeds"):
            V2([invalid, other_unknown])
        spare = raw(completion_tokens=50, completion_tokens_details={"reasoning_tokens": 0})
        self.assertEqual(V1([invalid, spare])["output_tokens"]["complete_total"], 55)
        with self.assertRaisesRegex(ValueError, "attempt reasoning exceeds"):
            V2([invalid, spare])

    def test_original_nested_unchanged_equal_dual_counted_once(self):
        original = raw(prompt_tokens=8, completion_tokens=5, completion_tokens_details={"reasoning_tokens": 2})
        self.assertEqual(V1([original]), V2([original]))
        equal = raw(prompt_tokens=8, completion_tokens=5, reasoning_tokens=2, completion_tokens_details={"reasoning_tokens": 2})
        self.assertEqual(V2([equal]), V1([original]))
        sole_nested = raw(completion_tokens=5, reasoning_tokens=-1, completion_tokens_details={"reasoning_tokens": 2})
        self.assertEqual(V2([sole_nested])["reasoning_tokens"]["complete_total"], 2)
        no_valid = raw(completion_tokens=5, reasoning_tokens=False, completion_tokens_details={"reasoning_tokens": 2.0})
        self.assertEqual(V2([no_valid])["reasoning_tokens"], dict(complete_total=None, known_sum=0, unknown_attempts=1, attempts=1))


if __name__ == "__main__":
    blobs, refs = snapshot()
    checks = static_check(blobs)
    V1 = isolated_usage(blobs["exporter_candidate_v1/exporter.py"])
    V2 = isolated_usage(blobs["exporter_candidate_v2/exporter.py"])
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(UsagePeer))
    after, after_refs = snapshot()
    assert after == blobs and after_refs == refs
    print("PEER_SUMMARY_JSON " + json.dumps({"python": platform.python_version(), "tests": result.testsRun,
        "passed": result.wasSuccessful(), "static_checks": checks, "before_after_pins_equal": True,
        "protected_refs": refs, "full_export_run": False, "real_payload_reads": 0, "scorer_or_model_calls": 0,
        "prior_gold_exposure_record_preserved": True, "fully_blinded": False,
        "eligible_as_fresh_scientific_reviewer": False}, sort_keys=True), flush=True)
    sys.exit(0 if result.wasSuccessful() else 1)
