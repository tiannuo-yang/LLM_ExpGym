# Pool 答案格式与原投票语义：离线候选 v2

本版唯一生产差异为 `diagnostics.py` 的 `EXPORTER_SHA`：由冻结旧 exporter `e555578c35795aba6fffc8ee90eb60751b5e60739c656c31db86ab2cb02cb4cd` 改为费用字段兼容后的 exporter v2 `c70319b2c1cd586859572f7c4d066acb847c36ef2424e84027553aa72346747c`。归一化这一赋值后，其余 AST 完全相同；正文 diff 也只有这一行。`test_diagnostics.py` fixture 已使用 `d.EXPORTER_SHA`，所以测试与 `run_cpu.py` 无需修改、字节照录。

此 pin 兼容不使格式诊断器提取、解释或使用任何费用/token/usage 数值；原先对完整 export 字节与 required JSON 容器的读取不变，不能把这一语义边界误写为磁盘 I/O 从未碰到包含费用字段的字节。所有 parser、原 scorer-set、投票规则、原分数读取、MV−MI 共现和计划分母不变，无新端点、替代评分或费用分析。

本次只运行原 20 项合成测试的双 Python CPU 验证。没有读取实际 GLM 输出、签发或运行真实 GO、执行 actual 诊断；K3 原 v1 诊断与所有 v1 源码/产物保留不动、不重跑。后续 actual 仍须最终 run/analysis 冻结及 ROOT 另行授权，并使用本版程序 SHA。

用途是在 **正式输出封存、主分析产物冻结并得到 ROOT 明确许可之后**，检查完整计划分母内的答案格式与投票规范化现象。当前只做静态/合成测试，没有读取本轮真实正式答案、分数或 HTTP raw。不是正在运行实验的补丁，不是主评分器，不替代用户要求的最终 post-output/post-analysis 独立审查。

## 固定范围与分母

每次只处理一个模型的冻结 v5 formal_mixed 计划：先绑定全部 705 invocation / 783 logical records，再选择全部 Pool N4 Search/Audit。

| 范围 | 计划池 | 计划 agent | 分组分母 |
| --- | ---: | ---: | --- |
| Search | 234 | 936 | 每预算/策略 39 池 |
| Audit | 78 | 312 | 每预算/策略 13 池 |
| 合计 | 312 | 1,248 | 12 个模型/场景/预算/策略组 |

另外 471 个计划 logical rows 明确列为预先不在此诊断场景范围内；不是按成绩排除。两模型分别运行，不能把重复执行同一模型的产品拼成第二个模型。

所有计划目标池都保留一行。`terminal` 才能解析完整 result+4 agent 的原答案；原始 `None` 单列 missing，仍属于已观察模型终态，不变成 infrastructure error。`not_started`、`infrastructure_error`、`integrity_error` 保留原状态/原因/已有原件 refs，四名 agent 计为 diagnostic unavailable；即使有部分原件，也不提升成完整 N4 指标。部分原件只核 bytes/SHA，不解析成池结论。计划分母、可诊断分母、缺答分母都分别输出，缺失不补零；Counter 中未列出的标志计数为 0。

## 做什么、不做什么

Search 的 scorer-set 仅指原 `_extract_names` 的**解析集合**，不是 F1 数值或 gold 集合。每个完整 N4 输出 6 个无序 agent 对的拆票/合票标志、两种解析等价类编号、集合大小、JSON-list/非 JSON-list、编号/符号、长片段过滤、非字符串 JSON 成员等。记录最高票平局、空票参与和非空优先、是否严格多数、获胜支持者、最早输入位置代表以及获胜 key 内 scorer-set 是否分歧。输入顺序已经绑定 agent 0–3，不用完成顺序替代。**不计算以另一解析器投票的胜者或分数。**

Audit 严格复制冻结 parser 的原接受顺序：首次 `json.loads` 失败后才 strip/去末尾分号/去 fence/重试；投票仍是 JSON-only。分别保留 scorer 侧和 vote 侧有效 entry 的格式计数；有效 label 别名→公开规范标签、原本规范标签、missing→空字符串和未知标签分别计数。evidence 区分缺字段、空 list、非 list、可 int 转换类型、去重/重排、坏成员；原 scorer 遇一坏项整集合回空，原 vote 只接受 list 并把坏项保留为文本。答案**字符串内部** NaN/Infinity/重复 JSON 键仍按原 `json.loads` 历史语义处理；外部控制/结果 JSON 则拒绝非有限数和重复键，不把两层混淆。

逐 hypothesis 记录两端 key/有效 dict entry 是否出现、规范 label 组、获胜 label 支持者、仅这些支持者中的整个 evidence-set 组与平局、最早支持者。hypothesis 用按原 keys 排序的 ordinal，不复制答案文本。这里的 hypothesis 分母只是答案中出现的 key union，**不是 gold/预期覆盖率**；未加载实际文档、gold 或数据表。label 规范化可能间接改变 evidence 投票的支持者集合，但本工具不计算替代政策。

所有个体/aggregate 分数都直接保留原报告值。`reported_score_mi` 用与主分析一致的 `statistics.mean` 计算原四分数均值，`reported_mv_minus_mi` 仅作上下文；按正/零/负与格式边界是否同时出现分账。没有调用 evaluator、工具、模型、API、原 CLI resume 或替代评分。**共现不是因果归因**：即使 MV 提升和 label 规范化同时出现，也不能据此量化“其中多少来自格式”或“多少来自信息共享”；没发现此处格式边界也不证明不存在其他机制。主比较仍是原冻结分析的 PoolAct−Naive/Cached 同 N4 对照，不被这里的 MV−MI 替代。

## 精确输入与拒绝条件

入口只接受外部 pin 的 GO：

```bash
/ABS/PYTHON -B /ABS/diagnostics.py --go /ABS/ROOT_GO.json --go-sha256 EXTERNAL_SHA
```

GO schema 示例（**不是可执行授权文件**）：

```json
{
  "schema_version": "restart-format-diagnostics-go-v1",
  "issuer": "ROOT",
  "approved": true,
  "post_run_and_analysis_frozen": true,
  "program_sha256": "EXACT_REVIEWED_PROGRAM_SHA",
  "output_dir": "/ABS/A_NEW_OUTPUT_DIRECTORY",
  "inputs": {
    "plan": {"path": "/ABS/plan.json", "sha256": "EXTERNAL_SHA"},
    "execution": {"path": "/ABS/run/execution.json", "sha256": "EXTERNAL_SHA"},
    "export_index": {"path": "/ABS/EXPORT_INDEX.json", "sha256": "EXTERNAL_SHA"},
    "run_seal": {"path": "/ABS/seal/inventory.json", "sha256": "EXTERNAL_SHA"}
  }
}
```

要求原 execution local_workers=0，同一 formal plan/run；完整 `restart-closed-run-inventory-v1` 的双次全树相同证据、plan/execution control refs、closure 与全部 inventory parts 计数/路径；run seal 的原 sealer SHA 固定。验证 exporter 的恰好 16 个被索引产品（不含索引自身）的 bytes/SHA，拒绝额外文件或 ref 覆盖路径；验证原 exporter/analysis SHA 与 plan/execution refs。所有 783 records 与 plan 一一对应，目标完整 12 个组分母不缺。它依赖已审阅、外部 pin 的完整 plan/exporter 来认证 item 矩阵，**不声称独立重建整个固定题库矩阵**。

每个目标原件必须同时出现在 manifest 预期路径、record SHA、source_index、export evidence 原件索引和完整 run seal 中。完整池检查独立 agent 0–3 的终态字段与 result 内 embedded agents 一致；模型、场景、预算、策略、种子、任务 selector 对齐；原 `answer`/`scoring_input`/missing policy/normal loop origin 对齐。只复现**原** Search/Audit 投票的结构，以要求存储 aggregate 原字符串与原规则相符；这不是新 scoring policy。固定三个生产模块 SHA 也重新核验，但不 import 它们、不执行模块顶层。

读输入不递归发现文件。每次读取上限 64 MiB，总读取量上限 8 GiB；超过即拒绝，不自动提高限额。reader 校验 regular/无 symlink 或路径 alias、bytes/SHA、读取前后 stat 和重复观察一致；不缓存全体原 payload，仅保留 refs 与少量派生结构。会读取 exporter 的汇总产物和每个目标池的 result/agent 文件；这些原文件本身可能含历史消息，JSON 全文件读取不可避免，但不会遍历累计 HTTP raw/wire、按 reasoning 文本猜结果或复制完整答案。对失败部分原件只核字节不做字段解析。

GO 的 `post_run_and_analysis_frozen` 是 ROOT 的外部审阅声明，不是脚本可自签的授权；CPU 测试中的 MOCK GO 在内存中构造，绝不可用于真实目录。run seal 证明的是曾经闭合且全树双读相同；工具不重新检查所有 PID、provider 队列或所有未读取文件，不证明恶意 change-and-revert、未来文件不再变化，也不是完整目录重新封存或秘密扫描。

输出必须新建，不能位于 run/source/export 根内或覆盖原件。仅输出四个文件：`pool_diagnostics.json`、`group_counts.json`、`PROVENANCE.json`、`INDEX.json`。INDEX 对另外三个文件逐 bytes/SHA 绑定。多文件写入不是事务，失败可能保留新的部分目录；没有完整 index 不算成功。没有自动上传或删除。

## 合成验证与剩余验收

`test_diagnostics.py` 只读取三个已 pin 的冻结源码，AST 仅抽取明确列举的纯 parser/aggregate 函数；原 aggregate 的 evaluator=None，无实际或 MOCK gold scorer 调用，其他依赖用固定合成占位。测试含 705/783 形状的内存 fixture，但只有四池合成终态、其余显式 unavailable；它不是实际 launcher run，也不冒称完整 schema 真实数据验收。

测试覆盖正常/拆票/合票/最早代表/空票平局，Audit wrapper 顺序/重复键/NaN/Infinity/label/条件 evidence 两级平局/错误类型，以及 changed source/export/original、unapproved/unfrozen/unsealed、额外文件/路径覆盖、完整分母、内存限制、新目录和最终 index 精确字节。`run_cpu.py` 在本候选目录内创建新 CPU receipt/log，记录实际测试数量、解释器、静态绑定前后不变；不生成真实 GO。

初始实现审阅中修正了仅存在于候选的新问题：manifest 的 `outerrep` 与展示层 `outerseed` 混淆；NaN/Infinity 答案字符串被诊断器严格序列化误拒；导出索引 path 可覆盖与额外文件范围未锁死。新候选测试及全部修正都未接触正式实验或旧报告。语义审阅 agent 只查看静态源码并运行本候选合成测试；这不能替代最终独立审计。

仍待真实正式结果闭合→run seal→原 exporter 成功→分析冻结→ROOT 审阅批准此候选→实际离线诊断→冻结新产物→新的独立 post-output/post-analysis 复核。届时如出现 schema/绑定/原投票字符串不一致，应保留失败证据并逐项查原因，不在此脚本里静默改原分数、剔除池或重跑模型。
