#!/usr/bin/env python3
"""Closed formal request-input provenance audit; never scorer or response audit."""
import argparse
from collections import Counter
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import resource
import stat

HERE = Path(__file__).resolve().parent
OLD = HERE.parent / 'actual_prompt_peer_v1/inspect_wire_v2.py'
OLD_SHA = '865a7b966a127926d82bf07921d4116f3c273235b6e99b7f903c3b62d44348cd'
SEALER_SHA = '1d30bf17c4cbe19fea21c2d65ab50e83db4aed9770ae6d1320c2fb3c34a424f2'
SOURCE = {
    'scripts/run_poolact.py': 'f69619eb7361058311c5e14da5af064dc710efcd4d1a4a8ab7ca349be3b6ed15',
    'scripts/run_paper_sweep.py': '3eda1ac8eb5d48311dd94a374519d220eabd58046b3f9dfbbf2f68453df6298f',
    'expgym/llm_clients.py': '5823e7bc9be71af40f47c307e079f820bbe4d808dc03e66deeea416677500ebb',
    'expgym/react_loop.py': 'f269934940c6057f149ac07c079b40a29fde97bcf9e69f9753aa6bf5c21a5ec4',
    'expgym/tool_protocol.py': '1806cc9c26cad623d295c528dbb5c13c33121ef33cf41793a15cf9a183fec9c7',
    'expgym/task_restricted_search.py': '5cf8d0ea856279f3fd982a60d947c37511242292c26c631cf6f84e6bb479c098',
    'expgym/task_evidence_audit.py': 'f874e36965e087d9771aca23bfdf221b00c86d63060b6c8f79e364b52a19c536',
    'expgym/task_tuning.py': '9ae9c5027f1ecee06da236a90745cc610415767ba235f45002d3082243289c29',
    'expgym/extras/parallel_cache.py': 'e5600eeef5389551cdf2761ccae716f5378c40e3443c8d1fe354f1cf2b53bcfa'}
STATES = {'success', 'error', 'malformed_response', 'in_progress'}
GRAPH = re.compile(r'\n\n(?=\[Parallel Exploration(?: |\u2014))')
MAX_OUTPUT = 32 * 1024**2


def need(value, code):
    if not value:
        raise ValueError(code)


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def parse(raw):
    def pairs(values):
        obj = {}
        for key, value in values:
            need(key not in obj, 'duplicate_json_key')
            obj[key] = value
        return obj
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite_json')))


def path(value):
    need(type(value) is str, 'absolute_path_string')
    p = Path(value)
    need(p.is_absolute() and '..' not in p.parts and str(p) == value, 'canonical_absolute_path')
    need(not any(part.lower() in ('private', 'secrets') for part in p.parts)
         and not any(word in p.name.lower() for word in ('api_key', 'credential', 'password', '.env')), 'credential_path_forbidden')
    return p


def same(a, b):
    return type(a) is dict and type(b) is dict and all(a.get(k) == b.get(k) for k in ('path', 'sha256'))


def old_module():
    raw = OLD.read_bytes()
    need(sha(raw) == OLD_SHA, 'original_inspector_changed')
    spec = importlib.util.spec_from_file_location('frozen_prompt_inspector_rules', OLD)
    module = importlib.util.module_from_spec(spec)
    exec(compile(raw, str(OLD), 'exec'), module.__dict__)
    return module


class Reader:
    def __init__(self, read=None):
        self.old = old_module()
        self.read = read or self.disk
        self.refs, self.total = {}, 0

    @staticmethod
    def disk(name):
        p = path(name); need(p.resolve() == p, 'symlink_or_alias_input')
        before = p.lstat()
        need(stat.S_ISREG(before.st_mode) and before.st_size <= 128 * 1024**2, 'regular_bounded_input')
        stamp = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
        with os.fdopen(os.open(p, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK), 'rb') as stream:
            need(stamp(before) == stamp(os.fstat(stream.fileno())), 'input_changed_before_read')
            raw = stream.read(128 * 1024**2 + 1)
            need(stamp(before) == stamp(os.fstat(stream.fileno())) == stamp(p.lstat())
                 and len(raw) == before.st_size, 'input_changed_during_read')
        return raw

    def get(self, ref):
        need(type(ref) is dict and set(ref) <= {'path', 'sha256', 'bytes', 'mtime_ns', 'ctime_ns', 'mode', 'inode', 'device', 'relative_path', 'file_count', 'total_bytes'}, 'file_ref_shape')
        p = str(path(ref['path'])); raw = self.read(p)
        need(type(raw) is bytes and len(raw) <= 128 * 1024**2, 'single_input_limit')
        self.total += len(raw)
        need(self.total <= 256 * 1024**3, 'total_input_limit')
        actual = {'path': p, 'sha256': sha(raw), 'bytes': len(raw)}
        need(actual['sha256'] == ref['sha256'] and ('bytes' not in ref or ref['bytes'] == len(raw)), 'raw_byte_pin_mismatch')
        need(p not in self.refs or self.refs[p] == actual, 'input_changed_between_reads')
        self.refs[p] = actual
        return raw

    def obj(self, ref):
        return parse(self.get(ref))


def strings(value, pointer, *, depth=0):
    need(depth <= 80, 'request_nesting_limit')
    if isinstance(value, str):
        yield pointer, value
    elif isinstance(value, dict):
        for key, child in value.items():
            if key.lower() in {'reasoning', 'reasoning_content', 'analysis', 'thinking'}:
                continue
            escaped = key.replace('~', '~0').replace('/', '~1')
            yield from strings(child, pointer + '/' + escaped, depth=depth + 1)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            yield from strings(child, pointer + '/' + str(index), depth=depth + 1)


def inspect_payload(payload, job, logical, config, rules):
    issues, hits, origins = [], [], Counter()
    need(type(payload) is dict and type(payload.get('messages')) is list and payload['messages'], 'request_payload_missing_or_unusable')
    profile = config['profiles'][config['model']['label']]
    expected = {'model': config['model']['model_id'], 'max_tokens': config['policy']['max_tokens'],
                'reasoning_effort': profile['reasoning_effort'], 'chat_template_kwargs': profile['chat_template_kwargs'], 'parallel_tool_calls': False}
    for key, value in expected.items():
        if encoded(payload.get(key)) != encoded(value): issues.append('parameter_' + key)
    for key in ('temperature', 'top_p'):
        value = payload.get(key)
        if type(value) not in (int, float) or not math.isfinite(value) or value != profile[key]: issues.append('parameter_' + key)
    if encoded(payload.get('top_k')) != encoded(profile.get('top_k')): issues.append('parameter_top_k')
    seed = payload.get('seed')
    if type(seed) is not int or seed not in job['sampling_seed_labels']: issues.append('undeclared_owner_seed')
    if payload.get('tool_choice') not in ('auto', 'none'): issues.append('unexpected_task_tool_choice')
    tools = payload.get('tools')
    expected_tool = {'restricted_search': 'search', 'evidence_audit': 'human_feedback', 'tuning': 'evaluate_config'}[job['scenario']]
    if not (type(tools) is list and len(tools) == 1 and type(tools[0]) is dict and tools[0].get('type') == 'function'
            and type(tools[0].get('function')) is dict and tools[0]['function'].get('name') == expected_tool):
        issues.append('tools_schema_identity')
    def scan(value, pointer, origin, region='whole_value'):
        origins[origin] += 1
        for location, text in strings(value, pointer):
            for match in rules.MARKERS.finditer(text):
                hits.append({'pointer': location, 'region': region, 'marker_class': re.sub(r'[-_ ]', '', match.group().lower()), 'origin': origin, 'requires_interpretation': True})
            for _ in rules.COUNT_HINT.finditer(text):
                hits.append({'pointer': location, 'region': region, 'marker_class': 'gold_answer_count_hint', 'origin': origin, 'requires_interpretation': True})
        need(len(hits) <= 10000, 'marker_output_limit')
    scan(payload.get('tools'), '/tools', 'source_tool_schema_position_bound')
    first_user = next((i for i, m in enumerate(payload['messages']) if type(m) is dict and m.get('role') == 'user'), None)
    if first_user is None: issues.append('initial_user_task_missing')
    for index, message in enumerate(payload['messages']):
        need(type(message) is dict, 'invalid_message_shape')
        role, text, pointer = message.get('role'), message.get('content'), '/messages/' + str(index)
        if role not in ('system', 'user', 'assistant', 'tool'): issues.append('unexpected_message_role')
        if role == 'assistant':
            scan({'content': text, 'tool_calls': message.get('tool_calls')}, pointer, 'model_generated_history')
            continue
        if role == 'system':
            if not isinstance(text, str): issues.append('unusable_system_message_content')
            scan(text, pointer + '/content', 'source_system_position_bound')
            continue
        if not isinstance(text, str):
            issues.append('unusable_nonassistant_message_content'); continue
        base, *graph = GRAPH.split(text, maxsplit=1)
        if graph:
            scan(graph[0], pointer + '/content', 'mixed_unresolved', 'graph_suffix_candidate')
        if index == first_user:
            if job['scenario'] in ('restricted_search', 'evidence_audit'):
                delimiter = '\nQuestion: ' if job['scenario'] == 'restricted_search' else '\nDocument segments:'
                opening = 'You are answering a question by searching a wiki of fictional characters.' if job['scenario'] == 'restricted_search' else 'You are auditing a legal document against '
                if delimiter in base and base.startswith(opening):
                    prefix, content = base.split(delimiter, 1)
                    scan(prefix, pointer + '/content', 'source_task_template_position_bound', 'template_prefix')
                    scan(content, pointer + '/content', 'provided_question_document_or_hypotheses', 'provided_task_content')
                else:
                    scan(base, pointer + '/content', 'mixed_unresolved'); issues.append('unrecognized_initial_task_boundary')
            else:
                scan(base, pointer + '/content', 'source_task_or_runtime_config_candidate')
        else:
            scan(base, pointer + '/content', 'mixed_unresolved')
    return {'parameter_or_structure_issues': issues, 'marker_hits': hits, 'origin_segment_counts': dict(origins),
            'marker_free_in_examined_fields': not hits, 'unresolved_markers': sum(h['origin'] in ('mixed_unresolved', 'source_task_or_runtime_config_candidate') for h in hits),
            'other_request_fields_not_examined': True, 'response_and_reasoning_fields_examined': False,
            'source_origin_is_conditional_on_frozen_producer_not_server_rendering': True}


def setup(plan_ref, execution_ref, seal_ref, reader):
    plan, execution, seal = [reader.obj(r) for r in (plan_ref, execution_ref, seal_ref)]
    need(plan.get('schema_version') == 'restart-executable-plan-v1' and plan.get('mode') == 'formal_mixed'
         and plan.get('expected_invocations') == 705 and len(plan['jobs']) == 705, 'full_formal_plan_required')
    ids = [j['invocation_id'] for j in plan['jobs']]
    need(len(set(ids)) == 705 and all(re.fullmatch(r'[0-9a-f]{64}', i) for i in ids), 'planned_ids_not_unique')
    root = path(plan['config']['output_root'])
    need(path(execution_ref['path']) == root / 'execution.json' and execution.get('schema_version') == 'restart-bounded-study-execution-v1'
         and execution.get('mode') == 'formal_mixed' and type(execution.get('local_workers')) is int and execution['local_workers'] == 0
         and execution.get('run_id') == plan['config']['run_id'] and same(execution.get('plan_ref'), plan_ref), 'closed_execution_identity')
    started, unstarted = execution['started_invocation_ids'], execution['unstarted_invocation_ids']
    need(len(started) == len(set(started)) and len(unstarted) == len(set(unstarted))
         and not set(started) & set(unstarted) and set(started) | set(unstarted) == set(ids), 'planned_partition')
    reports = [r['invocation_id'] for r in execution['reports']]
    need(len(reports) == len(set(reports)) and set(reports) == set(started), 'closed_started_reports')
    need(seal.get('schema_version') == 'restart-closed-run-inventory-v1' and seal.get('full_second_read_equal') is True
         and seal.get('expected_invocations') == 705 and path(seal['run_root']) == root
         and seal['sealer_source_ref']['sha256'] == SEALER_SHA, 'complete_pinned_seal_required')
    need(all(any(same(ref, control) for control in seal['control_refs']) for ref in (plan_ref, execution_ref)), 'seal_controls_mismatch')
    closure = reader.obj(seal['closure_ref'])
    need(type(closure.get('local_workers')) is int and closure['local_workers'] == 0 and closure.get('run_id') == execution['run_id']
         and same(closure.get('plan_ref'), plan_ref) and same(closure.get('execution_ref'), execution_ref), 'closure_identity')
    inventory = {}
    for ref in seal['file_parts']:
        rows = reader.obj(ref)
        need(len(rows) == ref['file_count'] and sum(r['bytes'] for r in rows) == ref['total_bytes'], 'part_totals')
        for row in rows:
            p = path(row['path']); relative = p.relative_to(root)
            need(str(relative) == row['relative_path'] and row['path'] not in inventory, 'seal_path_duplicate_or_outside_root')
            inventory[row['path']] = {k: row[k] for k in ('path', 'sha256', 'bytes')}
    need(len(inventory) == seal['file_count'] and sum(r['bytes'] for r in inventory.values()) == seal['total_bytes'], 'seal_global_totals')
    need(same(inventory.get(str(root / 'execution.json')), execution_ref), 'sealed_execution_mismatch')
    config = plan['config']; accepted = reader.obj(config['source_acceptance_ref']); profile = reader.obj(config['profile_ref'])
    need(path(accepted['repo_root']) == path(config['repo_root']), 'source_root_mismatch')
    need(profile.get('model') == config['model']['label'], 'profile_model_mismatch')
    for relative, digest in SOURCE.items():
        need(accepted['files'].get(relative) == digest, 'source_producer_not_accepted')
        reader.get({'path': str(path(config['repo_root']) / relative), 'sha256': digest})
    for key, value in config['profiles'][config['model']['label']].items():
        need(encoded(profile.get(key)) == encoded(value), 'profile_plan_mismatch')
    logical = plan['matrix']['logical_rows']
    need(len(logical) == 783 and len({r['logical_id'] for r in logical}) == 783 and set(r['invocation_id'] for r in logical) == set(ids), 'full_logical_scope')
    return plan, execution, inventory, logical


def audit(plan_ref, execution_ref, seal_ref, output, reader=None):
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    reader = reader or Reader()
    plan, execution, inventory, logical = setup(plan_ref, execution_ref, seal_ref, reader)
    output = path(str(output)); root = path(plan['config']['output_root'])
    need(not output.exists() and output.parent.is_dir() and output.parent.resolve() == output.parent
         and output != root and root not in output.parents and output not in root.parents
         and path(plan['config']['repo_root']) not in output.parents, 'fresh_nonoverlapping_output')
    dump_owners = {}
    for job in plan['jobs']:
        dump = path(job['dump_dir']); need(root / 'dumps' in dump.parents and dump not in dump_owners, 'dump_owner_scope')
        need(all(dump not in p.parents and p not in dump.parents for p in dump_owners), 'overlapping_dump_roots')
        dump_owners[dump] = job['invocation_id']
    selected = {j['invocation_id']: [] for j in plan['jobs']}; unmapped_dumps = []
    for name, ref in inventory.items():
        for parent in Path(name).parents:
            if parent in dump_owners: selected[dump_owners[parent]].append(ref); break
        else:
            if root / 'dumps' in Path(name).parents: unmapped_dumps.append(ref)
    output.mkdir(mode=0o700); summaries, request_ids, clients, generations = [], set(), {}, {}
    input_controls = list(reader.refs.values())
    def write(name, obj):
        raw = encoded(obj); need(len(raw) <= MAX_OUTPUT, 'output_part_limit')
        p = output / name; p.parent.mkdir(parents=True, exist_ok=True)
        with p.open('xb') as stream: stream.write(raw)
        return {'path': name, 'sha256': sha(raw), 'bytes': len(raw)}
    parts = []
    for job in plan['jobs']:
        iid, attempt_rows, states, problems, seen_owners = job['invocation_id'], [], Counter(), [], set()
        owners = [r for r in logical if r['invocation_id'] == iid]
        planned_owners = {(r['logical_id'], seed) for r in owners for seed in r['sampling_seed_labels']}
        need(len(planned_owners) == job['expected_model_terminals'], 'planned_owner_slot_count')
        for ref in sorted(selected[iid], key=lambda r: r['path']):
            entry = {'raw_ref': ref, 'state': 'unreadable', 'payload_audit': None, 'issues': []}
            try:
                raw = reader.obj(ref)
                need(type(raw) is dict and raw.get('schema_version') == 'expgym.api_attempt.v1', 'not_attempt_schema')
                state = raw.get('state'); entry['state'] = state if state in STATES else 'unknown'
                need(state in STATES, 'unknown_attempt_state')
                need(Path(ref['path']).parent == path(job['dump_dir']), 'noncanonical_dump_location')
                rid, cid, gid = [raw.get(k) for k in ('request_id', 'client_id', 'generation_id')]
                need(all(type(x) is str and re.fullmatch(r'[0-9a-f]{32}', x) for x in (rid, cid, gid))
                     and Path(ref['path']).name == rid + '.json' and rid not in request_ids, 'attempt_identity')
                request_ids.add(rid)
                need(cid not in clients or clients[cid] == iid, 'client_cross_job_reuse'); clients[cid] = iid
                need(type(raw.get('attempt')) is int and 1 <= raw['attempt'] <= plan['config']['policy']['max_retries'] + 1, 'attempt_number')
                key = (cid, gid); seen = generations.setdefault(key, set())
                need(raw['attempt'] not in seen, 'duplicate_generation_attempt'); seen.add(raw['attempt'])
                need(raw.get('run_id') == plan['config']['run_id'], 'wrong_run_id')
                context = raw.get('context'); need(type(context) is dict and context.get('runner') == job['system'], 'owner_runner_context')
                owner = context.get('job') if job['system'] == 'expgym' else context
                need(type(owner) is dict and owner.get('scenario') == job['scenario'], 'owner_scenario')
                payload = raw.get('request_payload'); need(type(payload) is dict, 'request_payload_missing_or_unusable')
                matches = [r for r in owners if payload.get('seed') in r['sampling_seed_labels']]
                need(len(matches) == 1, 'owner_seed_not_unique'); row = matches[0]
                for key in ('question_index', 'tuning_task'):
                    need(key not in row['selector'] or owner.get(key) == row['selector'][key], 'owner_selector')
                need(owner.get('cost_regime') == row['regime'], 'owner_regime')
                if job['system'] == 'expgym':
                    need(type(owner.get('seed')) is int and owner['seed'] == payload.get('seed'), 'exp_owner_seed')
                    for key in ('data_source', 'cc_split'):
                        need(key not in row['selector'] or owner.get(key) == row['selector'][key], 'exp_owner_data_selector')
                    if job['scenario'] == 'evidence_audit':
                        need(owner.get('rep') == row.get('order') and owner.get('hypothesis_order') == row.get('hypothesis_order'), 'exp_audit_order')
                if job['system'] == 'poolact':
                    need(owner.get('strategy') == row['strategy'] and type(owner.get('agent_id')) is int
                         and 0 <= owner['agent_id'] < 4 and owner.get('seed') == payload.get('seed')
                         and row['sampling_seed_labels'][owner['agent_id']] == payload['seed'], 'pool_owner_identity')
                entry.update(request_id=rid, client_id=cid, generation_id=gid, attempt=raw['attempt'], logical_id=row['logical_id'])
                entry['payload_audit'] = inspect_payload(payload, job, row, plan['config'], reader.old)
                seen_owners.add((row['logical_id'], payload['seed']))
                if state == 'in_progress' or not raw.get('finished_at_utc'): entry['issues'].append('attempt_not_closed')
            except (ValueError, TypeError, KeyError, OSError, RecursionError, OverflowError):
                entry['issues'].append('attempt_unreviewable_or_identity_failed')
            states[entry['state']] += 1
            attempt_rows.append(entry)
        started = iid in execution['started_invocation_ids']
        if not started and attempt_rows: problems.append('unstarted_job_has_dump_files')
        if started and not attempt_rows: problems.append('started_job_has_no_sealed_dump_attempt')
        for (cid, gid), numbers in generations.items():
            if clients.get(cid) == iid and sorted(numbers) != list(range(1, max(numbers) + 1)): problems.append('generation_attempt_gap')
        reviewed = sum(r['payload_audit'] is not None for r in attempt_rows)
        summary = {'invocation_id': iid, 'system': job['system'], 'scenario': job['scenario'], 'planned_model_terminals': job['expected_model_terminals'],
                   'planned_logical_rows': len(owners), 'started': started, 'sealed_dump_files': len(attempt_rows), 'payloads_reviewed': reviewed,
                   'payloads_unreviewable': len(attempt_rows) - reviewed, 'attempt_states': dict(states), 'coverage_issues': problems,
                   'uncovered_planned_owner_slots': [{'logical_id': lid, 'seed_label': seed} for lid, seed in sorted(planned_owners - seen_owners)],
                   'request_issue_count': sum(len(r['issues']) for r in attempt_rows),
                   'parameter_or_structure_issue_count': sum(len((r['payload_audit'] or {}).get('parameter_or_structure_issues', [])) for r in attempt_rows),
                   'marker_hit_count': sum(len((r['payload_audit'] or {}).get('marker_hits', [])) for r in attempt_rows)}
        ref = write('jobs/' + iid + '.json', {'summary': summary, 'attempts': attempt_rows})
        parts.append(ref); summaries.append(summary)
    coverage_ref = write('COVERAGE.json', summaries)
    stable = True
    for ref in list(reader.refs.values()):
        try: reader.get(ref)
        except (ValueError, OSError): stable = False
    covered = sum(s['started'] and s['sealed_dump_files'] > 0 for s in summaries)
    report = {'schema_version': 'closed-formal-prompt-provenance-v1', 'plan_ref': plan_ref, 'execution_ref': execution_ref, 'seal_ref': seal_ref,
              'source_profile_and_control_refs': input_controls, 'program_sha256': sha(Path(__file__).read_bytes()), 'old_rule_source_sha256': OLD_SHA,
              'model': plan['config']['model']['label'], 'planned_invocations': 705, 'planned_logical_rows': 783,
              'planned_model_terminals': sum(j['expected_model_terminals'] for j in plan['jobs']), 'started_invocations': len(execution['started_invocation_ids']),
              'unstarted_invocations': len(execution['unstarted_invocation_ids']), 'started_with_sealed_attempt_files': covered,
              'sealed_dump_files': sum(s['sealed_dump_files'] for s in summaries), 'payloads_reviewed': sum(s['payloads_reviewed'] for s in summaries),
              'unmapped_dump_files': len(unmapped_dumps), 'unmapped_dump_metadata_only_refs': unmapped_dumps,
              'payloads_unreviewable': sum(s['payloads_unreviewable'] for s in summaries), 'marker_hit_count': sum(s['marker_hit_count'] for s in summaries),
              'uncovered_planned_owner_slots': sum(len(s['uncovered_planned_owner_slots']) for s in summaries),
              'parameter_or_structure_issue_count': sum(s['parameter_or_structure_issue_count'] for s in summaries),
              'all_planned_attempt_input_coverage': stable and not unmapped_dumps and not execution['unstarted_invocation_ids'] and covered == 705
                  and not any(s['coverage_issues'] or s['request_issue_count'] or s['payloads_unreviewable'] or s['uncovered_planned_owner_slots'] for s in summaries),
              'all_sealed_dump_files_payload_reviewable': not any(s['payloads_unreviewable'] for s in summaries),
              'observed_input_bytes_stable': stable, 'parts': parts, 'coverage_ref': coverage_ref, 'response_bodies_quality_gold_and_reasoning_fields_audited': False,
              'marker_means_automatic_leakage': False, 'physical_http_wire_bijection_verified_here': False,
              'server_tokenizer_or_template_rendering_observed': False, 'model_calls': 0, 'scorer_calls': 0,
              'fresh_post_analysis_independent_review': 'still_required'}
    write('RECEIPT.json', report)
    return report


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('plan', 'execution', 'seal'):
        p.add_argument('--' + name, required=True); p.add_argument('--' + name + '-sha256', required=True)
    p.add_argument('--output', required=True)
    args = p.parse_args()
    try:
        refs = [{'path': getattr(args, name), 'sha256': getattr(args, name + '_sha256')} for name in ('plan', 'execution', 'seal')]
        result = audit(*refs, args.output)
        print(json.dumps({k: result[k] for k in ('planned_invocations', 'sealed_dump_files', 'payloads_reviewed', 'payloads_unreviewable', 'all_planned_attempt_input_coverage')}))
    except Exception:
        print(json.dumps({'audit_completed': False, 'rule': 'bounded_prompt_audit_failed'})); raise SystemExit(1)
