#!/usr/bin/env python3
"""Offline mixed-repeat descriptive conversion; never score, vote, or call a model."""
from collections import Counter, defaultdict
import argparse
import csv
import hashlib
import io
import json
import math
from pathlib import Path
import statistics
import types

HERE = Path(__file__).resolve().parent
CATALOG = HERE.parents[2] / "design/formal_export_candidate/converter.py"
# This is the existing immutable metric catalogue, NOT its old uniform-R converter.
CATALOG_SHA = "0261660a38d80c9135efc498f11580ef3fea26de00e6061824e9c9380662547f"
POLICY = "task-abstention-v1"
REPEATS = {s: {"restricted_search": 1, "evidence_audit": 1, "tuning": 3}
           for s in ("expgym", "poolact")}
IDENTITY = ("model", "system", "scenario", "item", "regime", "strategy", "outerseed")


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(blob):
    return hashlib.sha256(blob).hexdigest()


def dump(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def load(blob):
    def pairs(values):
        result = {}
        for key, value in values:
            require(key not in result, "duplicate JSON key")
            result[key] = value
        return result
    return json.loads(blob, object_pairs_hook=pairs,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError("nonfinite JSON")))


def catalogue():
    code = CATALOG.read_bytes()
    require(sha(code) == CATALOG_SHA, "frozen numeric catalogue changed")
    ns = {"__file__": str(CATALOG), "__name__": "mixed_repeat_metric_catalogue"}
    exec(compile(code, str(CATALOG), "exec"), ns)
    return types.SimpleNamespace(**ns)


def number(value, label, high=None, integer=False):
    require(type(value) in (int, float) and math.isfinite(value) and value >= 0
            and (high is None or value <= high) and (not integer or type(value) is int), "invalid " + label)
    return value


def mean(values):
    return statistics.mean(values) if values and all(v is not None for v in values) else None


def total(values):
    return sum(values) if values and all(v is not None for v in values) else None


def validate_manifest(manifest, c):
    """Independent fixed Cartesian check; no executable runner/planner entry."""
    require(manifest.get("schema_version") == "restart-mixed-matrix-v1", "wrong restart manifest")
    require(manifest.get("repeat_policy") == REPEATS and manifest.get("outer_repeats") == 3
            and manifest.get("outer_repeats_is_maximum_not_uniform") is True, "mixed repeat policy mismatch")
    require(manifest.get("restart_from_scratch") is True and manifest.get("reuse_old_completion") is False
            and manifest.get("supersedes"), "explicit fresh restart required")
    models = [m["label"] for m in manifest["models"]]
    require(models and len(set(models)) == len(models), "duplicate/empty models")
    p = c.planner()  # only immutable item catalogue, not its uniform-R validate/build.
    expected = {}
    for model in models:
        for system in REPEATS:
            for item in p.items(system):
                scenario = item["scenario"]
                for outer in range(REPEATS[system][scenario]):
                    for regime in p.REGIMES if system == "expgym" else p.REGIMES[1:]:
                        for strategy in ("single",) if system == "expgym" else p.STRATEGIES:
                            orders = range(3) if system == "expgym" and scenario == "evidence_audit" else ["default" if scenario == "evidence_audit" else "none"]
                            for order in orders:
                                key = (model, system, scenario, item["snapshot"], item["item"], order, regime, strategy, outer)
                                expected[key] = item
    rows = manifest["logical_rows"]
    keys = [tuple(r[k] for k in p.KEY_FIELDS) for r in rows]
    require(len(set(keys)) == len(keys) and set(keys) == set(expected), "missing/extra/duplicate fixed matrix unit")
    ids = set()
    paths = []
    for key, row in zip(keys, rows):
        require(row["logical_id"] == p.digest({k: row[k] for k in p.KEY_FIELDS}), "logical ID mismatch")
        require(row["logical_id"] not in ids, "logical ID collision")
        ids.add(row["logical_id"])
        item = expected[key]
        require(row["selector"] == item["selector"] and row["input_file_ids"] == item["inputs"], "item selector mismatch")
        order = row["order"]
        expected_order = manifest["source_and_inputs"]["audit_orders"][order] if type(order) is int else None
        require(row["hypothesis_order"] == expected_order, "fixed Audit order mismatch")
        selected = {"selector": row["selector"], "hypothesis_order": expected_order,
                    "files": {k: manifest["source_and_inputs"]["files"][k]["sha256"] for k in row["input_file_ids"]}}
        require(row["selected_input_sha256"] == p.digest(selected), "selected input hash mismatch")
        require(len(row["agent_artifacts"]) == (1 if row["system"] == "expgym" else 4), "wrong N")
        if row["system"] == "expgym":
            require(row["agent_artifacts"] == [row["result_artifact"]], "Exp single-agent path must equal its bound result artifact")
        paths += required_paths(row)
    require(len(paths) == len(set(paths)), "result/agent paths collide")
    require(all(not Path(x).is_absolute() and ".." not in Path(x).parts for x in paths), "unsafe artifact path")
    invs = manifest["invocations"]
    require(len(invs) == 705 * len(models) and len({i["invocation_id"] for i in invs}) == len(invs), "invocation count/uniqueness")
    require(Counter(lid for i in invs for lid in i["logical_ids"]) == Counter(ids), "invocation logical coverage")
    by_inv = {i["invocation_id"]: i for i in invs}
    for row in rows:
        inv = by_inv[row["invocation_id"]]
        require(row["logical_id"] in inv["logical_ids"] and all(row[k] == inv[k] for k in ("model", "system", "scenario", "outerrep")), "invocation binding mismatch")
    require(len(rows) == 783 * len(models), "logical count mismatch")
    return models


def required_paths(row):
    return [row["result_artifact"]] + (row["agent_artifacts"] if row["system"] == "poolact" else [])


def extract_agent(payload):
    """Project explicit policy fields, never reconstruct an answer from messages."""
    value = payload.get("outcome", payload)
    fields = ("answer", "scoring_input", "score_status", "terminal_status", "missing_final_policy", "terminal_origin", "terminal_scenario")
    require(all(k in value for k in fields), "explicit terminal projection fields missing")
    result = {k: value[k] for k in fields}
    if "outcome" in payload:
        require(payload.get("schema") == {"name": "expgym.trace", "version": "2.1.0"}, "explicit model-terminal v2 schema required")
        score = value["score"]
        metrics = score.get("metrics")
        result["answer_metrics"] = metrics
        result["answer_perf"] = metrics[score["primary_metric"]] if metrics is not None else score.get("value")
        result["reported_validation"] = {"passed": value["validation"]["passed"], "method": value["validation"]["method"]}
    else:
        require("answer_perf" in value and "answer_metrics" in value, "score fields missing")
        result.update(answer_perf=value["answer_perf"], answer_metrics=value["answer_metrics"])
        check = value["score_check"]
        result["reported_validation"] = {"passed": check["ok"], "method": "explicit_model_terminal_unscored" if check.get("reason") == "unscorable_missing_configuration" and check.get("score_complete") is False else "repository_score_recompute"}
    return result


def terminal(agent, scenario):
    require(agent["missing_final_policy"] == POLICY and agent["terminal_origin"] == "normal_loop_return"
            and agent["terminal_scenario"] == scenario, "unqualified model terminal")
    answer, projection, status = agent["answer"], agent["scoring_input"], agent["score_status"]
    require(answer is None or isinstance(answer, str), "answer is not raw string/null")
    missing = answer is None
    unknown = missing and scenario == "tuning"
    require(agent["reported_validation"] == {"passed": not unknown, "method": "explicit_model_terminal_unscored" if unknown else "repository_score_recompute"}
            and type(agent["reported_validation"]["passed"]) is bool, "reported local validation inconsistent (not independent score proof)")
    expected_status = "unscorable_missing_configuration" if unknown else ("scored_empty_prediction" if missing else "scored_final_answer")
    require(status == expected_status and projection == (None if unknown else "" if missing else answer), "answer/scoring projection mismatch")
    perf, metrics = agent["answer_perf"], agent["answer_metrics"]
    if unknown:
        require(perf is None and metrics is None, "missing HPO configuration must remain unknown")
    else:
        number(perf, "answer performance", 1)
        if scenario == "evidence_audit":
            require(isinstance(metrics, dict), "Audit metric mapping required")
            for key in ("label_acc", "evidence_acc"):
                number(metrics[key], key, 1)
    expected = {"schema_version": "expgym.execution-terminal.v1", "policy_version": POLICY,
                "execution_complete": True, "score_complete": not unknown,
                "terminal_classification": "model_no_answer" if missing else "completed_scored",
                "model_no_answer_count": int(missing), "expected_model_terminals": 1, "reported_model_terminals": 1}
    require(agent["terminal_status"] == expected and all(type(agent["terminal_status"][k]) is bool for k in ("execution_complete", "score_complete"))
            and all(type(agent["terminal_status"][k]) is int for k in ("model_no_answer_count", "expected_model_terminals", "reported_model_terminals")), "terminal status mismatch")
    return unknown


def project(row, record, blobs, oracles, c):
    scenario, pool = row["scenario"], row["system"] == "poolact"
    n = 4 if pool else 1
    state = record["state"]
    require(state in {"terminal", "not_started", "infrastructure_error", "integrity_error"}, "unknown execution state")
    names = c.expected_metric_names(row["system"], scenario, row["regime"])
    values = {name: None for name in names}
    agents, subset = [], None
    refs = record["source_sha256"]
    require(isinstance(refs, dict) and set(refs) <= set(required_paths(row)), "source paths outside planned logical unit")
    require(all(path in blobs and refs[path] == sha(blobs[path]) for path in refs), "source byte hash mismatch")
    if state == "terminal":
        require(set(refs) == set(required_paths(row)), "terminal requires all planned result and agent originals")
        payload = load(blobs[row["result_artifact"]])
        # ExpGym consumes exactly the same original whose SHA was checked above.
        originals = [load(blobs[path]) for path in row["agent_artifacts"]] if pool else [payload]
        if pool:
            require([v.get("agent_id") for v in originals] == list(range(4))
                    and all(type(v.get("agent_id")) is int for v in originals), "Pool agent IDs/order mismatch")
        agents = [extract_agent(v) for v in originals]
        unknown = [terminal(a, scenario) for a in agents]
        if pool:
            require([v.get("agent_id") for v in payload["agent_results"]] == list(range(4)), "embedded Pool agent IDs/order mismatch")
            require([extract_agent(a) for a in payload["agent_results"]] == agents, "embedded/separate Pool agent disagreement")
            agg = payload["aggregate"]
            missing = sum(a["answer"] is None for a in agents)
            expected = {"schema_version": "expgym.execution-terminal.v1", "policy_version": POLICY,
                        "execution_complete": True, "score_complete": not any(unknown),
                        "terminal_classification": "model_no_answer" if missing else "completed_scored",
                        "model_no_answer_count": missing, "expected_model_terminals": 4, "reported_model_terminals": 4}
            require(dump(payload["terminal_status"]) == dump(expected) and dump(agg["terminal_status"]) == dump(expected), "Pool terminal status mismatch")
            if any(unknown):
                require(all(agg.get(k) is None for k in ("answer", "answer_perf", "answer_metrics")), "unknown Pool endpoint must not use subset")
            else:
                number(agg["answer_perf"], "aggregate performance", 1)
        if scenario == "restricted_search":
            values.update({"f1_mv": agg["answer_perf"], "f1_mi": mean([a["answer_perf"] for a in agents])} if pool else {"f1": agents[0]["answer_perf"]})
        elif scenario == "evidence_audit":
            for key in ("label_acc", "evidence_acc"):
                if pool:
                    values[key + "_mv"] = number(agg["answer_metrics"][key], key, 1)
                    values[key + "_mi"] = mean([a["answer_metrics"][key] for a in agents])
                else:
                    values[key] = agents[0]["answer_metrics"][key]
        else:
            require(record.get("tuning_final_policy") == "legacy", "explicit legacy tuning endpoint required")
            perfs = [a["answer_perf"] for a in agents]
            gaps = [None if v is None else c.gap(v, oracles[row["item"]]) for v in perfs]
            known_perf = [v for v in perfs if v is not None]
            known_gap = [v for v in gaps if v is not None]
            subset = {"n_known": len(known_perf), "n_total": n, "not_full_pool_endpoint": len(known_perf) != n,
                      "mean_perf": mean(known_perf), "best_perf": max(known_perf) if known_perf else None,
                      "mean_clipped_gap": mean(known_gap), "best_clipped_gap": max(known_gap) if known_gap else None}
            if not any(unknown):
                values.update({"gap_mi": mean(gaps), "gap_bon": max(gaps), "raw_perf_mi": mean(perfs), "raw_perf_bon": max(perfs)} if pool else {"gap": gaps[0], "raw_perf": perfs[0]})
    else:
        require(isinstance(record.get("reason"), str) and record["reason"], "unexecuted/error record requires reason")
        # Available partial originals remain bound, but are not promoted to a scored pool.
    telemetry_names = set(c.TELEMETRY) | ({"budget_utilization"} if row["regime"] != "cost_free" else set())
    telemetry = record["telemetry"]
    require(set(telemetry) == telemetry_names, "exact telemetry catalogue required, use explicit null")
    for name, value in telemetry.items():
        if value is None:
            require(isinstance(record.get("telemetry_unknown_reasons", {}).get(name), str)
                    and record["telemetry_unknown_reasons"][name], "unknown telemetry requires reason")
        else:
            number(value, name, 1 if name == "protocol_failure_rate" else None, name in c.COUNTS)
        values[name] = value
    for name in ("feedback_visible", "duplicate_action_attempts"):
        require(telemetry[name] is None or telemetry["feedback_attempts"] is None or telemetry[name] <= telemetry["feedback_attempts"], "feedback count inconsistency")
    reasoning = record.get("reasoning_tokens")
    if reasoning is not None:
        number(reasoning, "reasoning tokens", integer=True)
        require(telemetry["output_tokens"] is None or reasoning <= telemetry["output_tokens"], "reasoning must be included in output")
    raw = [{"logical_id": row["logical_id"], "agent_id": index, "state": state,
            "answer_observed": bool(agents), "raw_answer": agents[index]["answer"] if agents else None,
            "scoring_input": agents[index]["scoring_input"] if agents else None,
            "score_status": agents[index]["score_status"] if agents else "error" if state.endswith("error") else "not_started",
            "original_terminal": agents[index] if agents else None} for index in range(n)]
    return values, raw, subset


def describe(rows, comparisons, definitions):
    indexed = {(tuple(r[k] for k in IDENTITY), r["metric"]): r["value"] for r in rows}
    require(len(indexed) == len(rows), "duplicate metric cell")
    effects, pairs = [], []
    for spec in comparisons:
        exp = spec["kind"] == "expgym_free_tight"
        system = "expgym" if exp else "poolact"
        regime = spec.get("regime")
        orientation = (1 if definitions[spec["metric"]]["higher_is_better"] else -1) * (-1 if exp else 1)
        outer_bundles = []
        for outer in spec["outerseeds"]:
            group = []
            for item in spec["items"]:
                def value(reg, strategy):
                    key = ((spec["model"], system, spec["scenario"], item, reg, strategy, outer), spec["metric"])
                    require(key in indexed, "paired Cartesian cell missing")
                    return indexed[key]
                base = value("cost_free" if exp else regime, "single" if exp else "naive")
                target = value("cost_tight" if exp else regime, spec["strategy"])
                effect = None if base is None or target is None else orientation * (target - base)
                pair = {"comparison": spec["id"], "item": item, "outerseed": outer, "baseline": base, "target": target, "effect": effect}
                group.append(pair)
                pairs.append(pair)
            outer_bundles.append({"outerseed": outer, **{f: mean([p[f] for p in group]) for f in ("baseline", "target", "effect")}})
        values = [b["effect"] for b in outer_bundles]
        complete = all(v is not None for v in values)
        effects.append({"comparison": spec["id"], "role": spec["role"], "model": spec["model"], "system": system,
            "scenario": spec["scenario"], "slice": spec["slice"], "metric": spec["metric"], "strategy": spec["strategy"], "regime": regime,
            **{f: mean([b[f] for b in outer_bundles]) for f in ("baseline", "target", "effect")},
            "n_items": len(spec["items"]), "n_outer_repeats": len(values), "n_pairs_descriptive_not_independent_n": len(values) * len(spec["items"]),
            "outer_bundle_effects": values, "outerrep_descriptive_sd": statistics.stdev(values) if complete and len(values) > 1 else None,
            "status": "descriptive_complete" if complete else "unknown_incomplete_endpoint", "ci": None, "p_value": None,
            "effect_definition": "utility-oriented Free minus Tight" if exp else "utility-oriented candidate minus naive"})
    return effects, pairs


def convert(manifest_bytes, records_bytes, source_blobs, oracle_bytes, *, pins):
    require(pins == {"manifest_sha256": sha(manifest_bytes), "records_sha256": sha(records_bytes), "oracle_sha256": sha(oracle_bytes)}, "external input byte pins mismatch")
    c = catalogue()
    manifest, bundle = load(manifest_bytes), load(records_bytes)
    models = validate_manifest(manifest, c)
    require(bundle.get("schema_version") == "restart-analysis-records-v1" and bundle.get("manifest_sha256") == sha(manifest_bytes), "record bundle identity mismatch")
    require(bundle.get("source_tree_sha256") == manifest["source_and_inputs"]["source_tree_sha256"], "source cohort mismatch")
    records = bundle["records"]
    by_id = {r["logical_id"]: r for r in records}
    require(len(by_id) == len(records) and set(by_id) == {r["logical_id"] for r in manifest["logical_rows"]}, "each planned logical unit must be explicit, including unknown/error")
    require(set(source_blobs) == {p for r in records for p in r["source_sha256"]}, "source blob inventory missing/extra")
    require(sha(oracle_bytes) == manifest["source_and_inputs"]["files"]["hpo.oracle"]["sha256"], "oracle differs from frozen input")
    oracles = load(oracle_bytes)["tasks"]
    grouped, raw, subsets, outcomes = defaultdict(list), [], [], []
    telemetry = defaultdict(lambda: defaultdict(list))
    for row in manifest["logical_rows"]:
        record = by_id[row["logical_id"]]
        values, terminal_rows, subset = project(row, record, source_blobs, oracles, c)
        identity = dict(zip(IDENTITY, (row["model"], row["system"], row["scenario"], row["item"], row["regime"], row["strategy"], f"outer_{row['outerrep']:05d}")))
        grouped[tuple(identity.values())].append((row, record, values))
        raw += [{**identity, **r} for r in terminal_rows]
        performance_names = set(values) - set(c.TELEMETRY) - {"budget_utilization"}
        score_state = ("score" if all(values[k] is not None for k in performance_names) else "unknown") if record["state"] == "terminal" else "error" if record["state"].endswith("error") else "not_started"
        outcomes.append({**identity, "logical_id": row["logical_id"], "invocation_id": row["invocation_id"],
                         "order": row["order"], "execution_state": record["state"], "score_state": score_state,
                         "reason": record.get("reason") or ("unscorable_missing_configuration" if score_state == "unknown" else None),
                         "model_no_answer_count": sum(t["answer_observed"] and t["raw_answer"] is None for t in terminal_rows),
                         "telemetry_unknown_reasons": record.get("telemetry_unknown_reasons", {}),
                         "source_sha256": record["source_sha256"]})
        if subset is not None:
            subsets.append({**identity, "logical_id": row["logical_id"], **subset})
        for metric in c.SUMMABLE:
            telemetry[row["model"]][metric].append(record["telemetry"][metric])
        telemetry[row["model"]]["reasoning_tokens_included_in_output"].append(record.get("reasoning_tokens"))
    specs, rows, derived = [], [], {}
    for key, components in sorted(grouped.items()):
        row = components[0][0]
        audit = row["system"] == "expgym" and row["scenario"] == "evidence_audit"
        require(len(components) == (3 if audit else 1) and (not audit or {v[0]["order"] for v in components} == {0, 1, 2}), "Audit requires all three fixed orders")
        identity = dict(zip(IDENTITY, key))
        values = {metric: mean([v[2][metric] for v in components]) for metric in sorted(components[0][2])}
        path = "derived/" + sha(dump(identity)) + ".json"
        unit = "document_outerrep" if audit else "pool_aggregate" if row["system"] == "poolact" else "single_trace"
        body = {"identity": identity, "unit": unit, "metrics": values,
                "derivation": "equal_three_fixed_orders_strict_null" if audit else "one_planned_outcome",
                "components": [{"logical_id": r["logical_id"], "order": r["order"], "state": rec["state"],
                    "selected_input_sha256": r["selected_input_sha256"], "source_sha256": rec["source_sha256"],
                    "record_sha256": sha(dump(rec))} for r, rec, _ in components]}
        derived[path] = body
        specs.append({**identity, "artifact": path, "unit": unit, "metrics": sorted(values), "split": "known",
                      "item_status": row["item_status"], "snapshot": row["snapshot"], "selector": row["selector"]})
        rows += [{**identity, "metric": k, "value": v, "artifact": path} for k, v in values.items()]
    require(len(specs) == 705 * len(models) and len(rows) == 7687 * len(models) and len(raw) == 1881 * len(models), "mixed matrix output count mismatch")
    comparisons = c.build_comparisons(manifest, specs, {})
    for spec in comparisons:
        system = "expgym" if spec["kind"] == "expgym_free_tight" else "poolact"
        spec["outerseeds"] = [f"outer_{i:05d}" for i in range(REPEATS[system][spec["scenario"]])]
        spec["minimum_outerseeds"] = len(spec["outerseeds"])
        spec["bootstrap_method"] = "disabled_descriptive_only"
    definitions = {r["metric"]: c.metric_definition(r["metric"]) for r in rows}
    effects, pairs = describe(rows, comparisons, definitions)
    costs = {model: {metric: {"total": total(v), "n_known": sum(x is not None for x in v), "n_expected": len(v),
                    "known_subset_total_not_complete": sum(x for x in v if x is not None)} for metric, v in fields.items()} for model, fields in telemetry.items()}
    states = Counter(r["state"] for r in records)
    provenance = {"schema_version": "restart-mixed-descriptive-export-v1", "adapter_revision": "source-binding-v2", "study_id": manifest["candidate_id"],
        "input_pins": pins, "source_tree_sha256": bundle["source_tree_sha256"], "adapter_sha256": sha(Path(__file__).read_bytes()),
        "catalogue_sha256": CATALOG_SHA, "item_catalogue_sha256": c.PLANNER_SHA,
        "repeat_policy": REPEATS, "logical_states": dict(states), "logical_count": len(records), "agent_count": len(raw),
        "logical_score_states": dict(Counter(o["score_state"] for o in outcomes)),
        "derived_outcomes": len(specs), "metric_cells": len(rows), "comparisons": len(effects),
        "planned_matrix_accounted_for": True, "execution_complete": states["terminal"] == len(records),
        "all_metric_values_known": all(r["value"] is not None for r in rows),
        "raw_model_no_answer_count": sum(r["answer_observed"] and r["raw_answer"] is None for r in raw),
        "source_artifact_sha256": {p: sha(b) for p, b in source_blobs.items()},
        "independent_scoring_algorithm": False, "score_recomputed": False, "fresh_post_analysis_audit": "pending",
        "main_analyzer_directly_compatible": False, "confirmatory_inference": False, "model_calls": 0,
        "cost_scope": "logical invocation telemetry, not allocation wall/GPU bill; audit orders counted separately in totals"}
    return {"provenance": provenance, "metric_definitions": definitions, "artifact_specs": specs,
            "rows": rows, "derived_artifacts": derived, "comparisons": comparisons, "effects": effects,
            "paired_rows": pairs, "raw_terminals": raw, "logical_outcomes": outcomes, "known_subsets": subsets, "cost_coverage": costs}


def csv_bytes(rows, fields=None):
    stream = io.StringIO(newline="")
    fields = fields or list(rows[0])
    writer = csv.DictWriter(stream, fieldnames=fields)
    writer.writeheader()
    for row in rows:
        writer.writerow({k: json.dumps(row[k], ensure_ascii=False, separators=(",", ":")) if isinstance(row[k], (dict, list)) else row[k] for k in fields})
    return stream.getvalue().encode()


def render(result):
    p = result["provenance"]
    lines = ["# 新方案描述性结果", "", f"研究：{p['study_id']}；计划单元 {p['logical_count']}，全部已列出；实际执行完成：{p['execution_complete']}。",
             f"共 {p['comparisons']} 个预定对照，负值、零值及 unknown 均保留。原始缺答 {p['raw_model_no_answer_count']} 条。",
             "", "Search/Audit R1：SD、CI 均为 null。HPO/NAS R3：仅 outerrep 描述性 SD，全部 CI/p 值为 null。",
             "Audit 三个固定 orders 先在文档内等权平均，缺一则完整端点 unknown；orders 和 N4 agents 均不是额外独立重复。",
             "ExpGym 展示 Free→Tight 的效用退化；PoolAct/cached 分别对比同预算 naive N4。反馈预算匹配不代表真实 token、wall 或 GPU 成本相等。",
             "HPO Gap 每 agent 先 clip，再计算 MI/BoN；缺配置时完整 N4 端点 unknown，可用子集仅另列描述。固定九任务/三家族均衡，任务等权等价家族等权。",
             "reasoning tokens 已包含于 output，禁止相加。费用表是逐 invocation 遥测（Audit 三 orders 分别计费）；实际小时、排队、加载、GPU-h 需独立 allocation 账单。",
             "", "本适配器仅读取已报告分数，不执行 scorer、投票或模型。原件哈希不是独立评分真相；独立评分/实际完整性以及最终 fresh post-analysis review 均尚未由本候选证明。",
             "", "|模型|主对照|效应|描述 SD|状态|", "|---|---|---:|---:|---|"]
    for e in result["effects"]:
        if e["role"] == "primary":
            fmt = lambda v: "unknown" if v is None else f"{v:.6g}"
            lines.append(f"|{e['model']}|{e['comparison']}|{fmt(e['effect'])}|{fmt(e['outerrep_descriptive_sd'])}|{e['status']}|")
    lines += ["", "完整文件：metrics.csv（十列，空 value 表示 null）、effects.csv、paired_rows.csv、logical_outcomes.csv、raw_terminals.csv、known_subsets.csv、results.json、provenance.json。后续 fresh audit 必须另附，不得由 CPU PASS 替代。", ""]
    files = {"SUMMARY.zh.md": "\n".join(lines).encode(), "results.json": dump(result), "provenance.json": dump(p),
             "metrics.csv": csv_bytes(result["rows"], list(IDENTITY) + ["metric", "value", "artifact"])}
    for key in ("effects", "paired_rows", "raw_terminals", "logical_outcomes", "known_subsets"):
        empty_fields = list(IDENTITY) + ["logical_id", "n_known", "n_total", "not_full_pool_endpoint", "mean_perf", "best_perf", "mean_clipped_gap", "best_clipped_gap"] if key == "known_subsets" else None
        files[key + ".csv"] = csv_bytes(result[key], empty_fields if not result[key] else None)
    files["OUTPUT_INDEX.json"] = dump({"schema_version": "restart-analysis-output-index-v1", "fresh_post_analysis_audit": "pending",
                                      "files": {name: {"sha256": sha(blob), "bytes": len(blob)} for name, blob in files.items()}})
    return files


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("manifest", "records", "oracle", "pins", "source-index", "output-dir"):
        parser.add_argument("--" + name, required=True, type=Path)
    args = parser.parse_args()
    source_index = load(args.source_index.read_bytes())
    blobs = {logical: Path(location).read_bytes() for logical, location in source_index.items()}
    result = convert(args.manifest.read_bytes(), args.records.read_bytes(), blobs, args.oracle.read_bytes(), pins=load(args.pins.read_bytes()))
    files = render(result)
    require(not args.output_dir.exists(), "output must be fresh; never overwrite prior results")
    args.output_dir.mkdir(parents=True, exist_ok=False)
    for name, blob in files.items():
        with (args.output_dir / name).open("xb") as stream:
            stream.write(blob)
    print(json.dumps({"planned_matrix_accounted_for": True, "fresh_post_analysis_audit": "pending", "model_calls": 0}))


if __name__ == "__main__":
    main()
