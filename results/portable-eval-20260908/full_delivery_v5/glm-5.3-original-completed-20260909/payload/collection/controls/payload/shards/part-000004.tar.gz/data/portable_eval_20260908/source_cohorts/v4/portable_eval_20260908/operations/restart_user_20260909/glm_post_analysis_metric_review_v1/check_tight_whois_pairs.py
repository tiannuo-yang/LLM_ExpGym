"""Read-only frozen 39-question pairing check; no scoring or model calls."""
import hashlib
import json
import math
import os
from pathlib import Path
import resource
import stat
import statistics
import sys

OP = Path(__file__).resolve().parent.parent
HERE = Path(__file__).resolve().parent
GO = OP / 'glm_formal_postseal_go_v1/ROOT_METRIC_REVIEW_GO.json'
GO_SHA = '1a9da60de67b1fa870537741f6522426236fc87faf9c93f2fb5286b50d7997c6'
MODELS = {
    'kimi-k3': ('actual_formal_export_k3_node_failure_v2', 'ababd4141ab276e32dfa9ec07b39c6b68a571850b6469f3657033f65bd882ba7',
        'k3_post_analysis_metric_review_v1/actual_v1', '8047a5b32217910e159bbfd6fc51fa56771b38a8f388520ea22bcc73cb6b9d30',
        'kimi-k3-formal-node-failure-20260909', 'b98bbd8d06627b7fb757fb0beac661d40d98d1d94da5098b0fbf1c5d6ab97c66',
        'restart-20260909-v5-kimi-k3-formal'),
    'glm-5.3': ('actual_formal_export_glm_completed_v2', 'e32cab1af07054e76503aab79c66b76bcc216d2021cf0f46cd638340023bbca7',
        'glm_post_analysis_metric_review_v1/actual_v1', '445be317b0edd4973381e8290e764c0bef9b74100f1296487456038e174eba83',
        'glm-5.3-formal-completed-20260909', 'da5b89e1041e396c04673b6f363dd01a3f6d64b61bfd9fe6d60f0a6617957f22',
        'restart-20260909-v5-glm-5.3-formal'),
}
REFS = {}


def require(value):
    if not value:
        raise ValueError('frozen_pair_binding_failed')


def read(path, digest, size=None):
    path = Path(path)
    require(path.is_absolute() and '..' not in path.parts and path.resolve() == path)
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_size <= 128 * 1024**2)
    signature = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), 'rb') as f:
        require(signature(before) == signature(os.fstat(f.fileno())))
        raw = f.read(128 * 1024**2 + 1)
        require(signature(before) == signature(os.fstat(f.fileno())) == signature(path.lstat()))
    require(hashlib.sha256(raw).hexdigest() == digest and (size is None or len(raw) == size))
    ref = dict(path=str(path), sha256=digest, bytes=len(raw))
    require(str(path) not in REFS or REFS[str(path)] == ref)
    REFS[str(path)] = ref
    return json.loads(raw)


def indexed(root, index, name):
    ref = index[name]
    return read(root / name, ref['sha256'], ref['bytes'])


def answer_sha(value):
    require(value is None or type(value) is str)
    return hashlib.sha256(value.encode()).hexdigest() if value is not None else None


def execute():
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    def audit(event, args):
        if event.startswith('socket.') or event in ('subprocess.Popen', 'os.system', 'os.exec', 'os.posix_spawn'):
            raise RuntimeError('network_or_subprocess_forbidden')
    sys.addaudithook(audit)
    go = read(GO, GO_SHA)
    require(go['approved'] is True and go['role'] == 'metric' and go['additional_readonly_scope'])
    target = HERE / 'TIGHT_WHOIS_PAIR_CHECK.json'
    require(not target.exists())
    per_model = {}
    for model, (export_dir, export_sha, review_dir, review_sha, seal_name, seal_sha, run_name) in MODELS.items():
        export, review, run = OP / export_dir, OP / review_dir, OP.parents[1] / 'formal_runs' / run_name
        ix = read(export / 'EXPORT_INDEX.json', export_sha)['files']
        manifest = indexed(export, ix, 'manifest.json')
        records = {r['logical_id']: r for r in indexed(export, ix, 'records.json')['records']}
        source_index = indexed(export, ix, 'source_index.json')
        result = indexed(export, ix, 'results.json')
        ri = read(review / 'INDEX.json', review_sha)
        summary = indexed(review, ri, 'SUMMARY.json')
        require(summary['passed'] is True and summary['mismatches'] == 0)
        original_refs = {r['path']: r for r in summary['original_input_refs']}
        seal_path = OP / 'sealed_restart_runs_v1' / seal_name / 'inventory.json'
        require(original_refs[str(seal_path)]['sha256'] == seal_sha)
        seal = read(seal_path, seal_sha)
        require(Path(seal['run_root']) == run and seal['full_second_read_equal'] is True)
        units = {r['logical_id']: r for r in indexed(review, ri, 'logical_units.json')}
        agents = {(r['logical_id'], r['agent_id']): r for r in indexed(review, ri, 'agents.json')}
        votes = {r['logical_id']: r['vote'] for r in indexed(review, ri, 'pools.json')}
        exported = {(r['item'], r['strategy'], r['outerseed']): r for r in result['rows']
            if r['model'] == model and r['system'] == 'poolact' and r['scenario'] == 'restricted_search'
            and r['regime'] == 'cost_tight' and r['metric'] == 'f1_mv' and r['strategy'] in ('poolact', 'naive')}
        planned = [r for r in manifest['logical_rows'] if r['model'] == model and r['system'] == 'poolact'
            and r['scenario'] == 'restricted_search' and r['regime'] == 'cost_tight'
            and r['selector']['question_family'] == 'whois' and r['strategy'] in ('poolact', 'naive')]
        require(len(planned) == 78 and len(exported) == 78)
        grouped = {}
        for row in planned:
            lid, strategy = row['logical_id'], row['strategy']
            key = (row['selector']['data_source'], row['selector']['question_index'], row['outerrep'])
            require(row['model_id'] == model and row['outerrep'] == 0 and len(row['agent_artifacts']) == 4)
            require(records[lid]['state'] == units[lid]['state'] == 'terminal')
            sources, objects = [], []
            for relative in [row['result_artifact'], *row['agent_artifacts']]:
                path = str(run / relative)
                require(source_index[relative] == path and path in original_refs)
                ref = original_refs[path]
                require(records[lid]['source_sha256'][relative] == ref['sha256'])
                objects.append(read(path, ref['sha256'], ref['bytes']))
                sources.append(ref)
            original, children = objects[0], objects[1:]
            require(original['config']['model'] == model and original['strategy'] == strategy
                and original['config']['question_index'] == key[1] and original['config']['data_source'] == key[0]
                and original['config']['agent_seeds'] == row['sampling_seed_labels'])
            child_hashes = []
            for i, child in enumerate(children):
                require(child['agent_id'] == i)
                digest = answer_sha(child['answer'])
                require(digest == agents[(lid, i)]['answer_sha256'])
                child_hashes.append(digest)
            chosen = votes[lid]['selected_agent']
            selected_answer = children[chosen]['answer'] or ''
            require(answer_sha(original['aggregate']['answer']) == answer_sha(selected_answer))
            score = units[lid]['metrics']['f1_mv']
            exported_row = exported[(row['item'], strategy, 'outer_%05d' % row['outerrep'])]
            require(all(math.isclose(value, score, rel_tol=1e-9, abs_tol=1e-9) for value in (
                original['aggregate']['answer_perf'], exported_row['value'], result['derived_artifacts'][exported_row['artifact']]['metrics']['f1_mv'])))
            require(strategy not in grouped.setdefault(key, {}))
            grouped[key][strategy] = dict(logical_id=lid, f1_mv=score, selected_agent=chosen,
                aggregate_answer_sha256=answer_sha(original['aggregate']['answer']),
                agent_answer_sha256=child_hashes, original_refs=sources)
        require(len(grouped) == 39 and all(set(v) == {'poolact', 'naive'} for v in grouped.values()))
        per_model[model] = grouped
    k3, glm = per_model['kimi-k3'], per_model['glm-5.3']
    require(set(k3) == set(glm))
    pairs = []; source_paths_equal = source_sha_equal = 0
    for key in sorted(k3):
        for strategy in ('poolact', 'naive'):
            for left, right in zip(k3[key][strategy]['original_refs'], glm[key][strategy]['original_refs']):
                source_paths_equal += left['path'] == right['path']
                source_sha_equal += left['sha256'] == right['sha256']
        a = k3[key]['poolact']['f1_mv'] - k3[key]['naive']['f1_mv']
        b = glm[key]['poolact']['f1_mv'] - glm[key]['naive']['f1_mv']
        pairs.append(dict(world=key[0], question_index=key[1], outerrep=key[2],
            models={m: per_model[m][key] for m in MODELS}, kimi_delta=a, glm_delta=b, delta_difference=b-a))
    require(source_paths_equal == 0 and source_sha_equal == 0)
    for ref in list(REFS.values()):
        read(ref['path'], ref['sha256'], ref['bytes'])
    report = dict(schema='independent-39-tight-whois-cross-model-pairs-v1', paired_questions=39,
        means={m: {s: statistics.mean(per_model[m][k][s]['f1_mv'] for k in sorted(k3)) for s in ('poolact','naive')} for m in MODELS},
        mean_deltas={m: statistics.mean(per_model[m][k]['poolact']['f1_mv']-per_model[m][k]['naive']['f1_mv'] for k in sorted(k3)) for m in MODELS},
        aligned_original_file_pairs=39*2*5, identical_source_paths=source_paths_equal, identical_source_file_sha256=source_sha_equal,
        identical_question_deltas=sum(p['kimi_delta']==p['glm_delta'] for p in pairs),
        different_question_deltas=sum(p['kimi_delta']!=p['glm_delta'] for p in pairs),
        same_aggregate_answer_sha256={s: sum(k3[k][s]['aggregate_answer_sha256']==glm[k][s]['aggregate_answer_sha256'] for k in k3) for s in ('poolact','naive')},
        same_f1_mv={s: sum(k3[k][s]['f1_mv']==glm[k][s]['f1_mv'] for k in k3) for s in ('poolact','naive')},
        pairs=pairs, source_refs=list(REFS.values()), all_explicit_refs_after_unchanged=True,
        new_scoring_or_model_calls=0, raw_answer_or_reasoning_plaintext_written=False,
        code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    raw = json.dumps(report, sort_keys=True, ensure_ascii=False, allow_nan=False, separators=(',', ':')).encode()
    with target.open('xb') as f:
        f.write(raw)
    print(json.dumps({k: report[k] for k in ('paired_questions','means','mean_deltas','aligned_original_file_pairs',
        'identical_source_paths','identical_source_file_sha256','identical_question_deltas','different_question_deltas','same_aggregate_answer_sha256','same_f1_mv')}))


if __name__ == '__main__':
    execute()
