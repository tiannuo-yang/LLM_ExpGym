# GLM-5.3 冻结结果：独立公式/投票复算

当前状态：ROOT 另行授权的一次 actual 已完成并核验，13,560 项比较 / 0 mismatches；39 题跨模型专项亦完成。实际执行与限制以 [FINDINGS.zh.md](FINDINGS.zh.md)、[OPERATOR_RECEIPT.json](OPERATOR_RECEIPT.json) 及冻结 actual_v1/INDEX.json 为准。下面保留的是此前候选/CPU 阶段说明，不表示当前仍待执行；未改算法或重跑 actual。

## 历史候选/CPU 阶段记录

本目录只完成 ROOT 授权的最小绑定候选与原 12 项合成测试，**没有执行 review.run/main，没有读取 GLM 原答案或 gold，没有评分当前结果**。实际全量复算须 ROOT 主读本差异、给新输出路径及另一次明确授权后单次执行；当前没有 actual 目录或自签 GO。

审阅者仍非实验 runner/exporter 作者。算法来自已验收 K3 独立 review.py SHA `9a05689b6eda15aa8105f458da31df2f0736c2b245c0adae28e82835031003ae`，非复用原 scorer/backend。原 K3 源/测试/结果不改、不重跑。

## 最窄差异

见 `PRODUCTION_DIFF.patch`：只替换 OUT/PLAN/RUN、plan/execution/EXPORT_INDEX/seal/results pins、第二处 seal literal、闭合分区 697+8→705 terminal、summary 相应 705/0 与 GLM 标签。source_acceptance_v5_final 原 pin 不变。额外把 GLM 已冻 `original_execution_complete=true` 与 `original_score_complete=true` 纳入原闭合守卫，属于封存状态绑定，不是新评分规则。

783 logical / 705 jobs、73 Search 问题 / 13 Audit 文档、N4 与 Exp Audit `{0,1,2}` 均由本次允许读取的冻结 plan/原 seal/execution/EXPORT_INDEX 元数据确认后保留（chunk `90f210`）。模型 alias/id 均为 `glm-5.3`；705 started、0 unstarted、local_workers=0、mode=formal_mixed；seal 70,520 文件、36 parts、second read equal、execution/score true。没有读取 seal parts 或原评分文件；records 的 terminal=705 精确分区还将由实际复算入口核验。

EXPORT_INDEX 的 16 条文件 refs 中 results/provenance SHA 与 ROOT 给定值一致；本轮只读 INDEX，未读取这两份正文。ROOT_SEAL_ACCEPTANCE 与 ROOT_EXPORT_FILES_VERIFIED 只核已指定文件 SHA，未把它们解释成评分结果；两份完整 pins 见 CPU_RECEIPT。

22 个算法/辅助函数或类 AST 完全相同；唯一改变函数为 run 的绑定守卫与报告常量（chunk `22c5fb`）。Search set/F1、投票规范化/tie/最早代表，Audit LA/EA、wrapper 差异、label/evidence 投票，HPO Gap 下限 clip、MI/BoN、unknown/known subset、1e-9 容差、全 planned 覆盖和原输入双 hash 均不改。N4 agents 与 Audit 三 orders 不是独立题样本。不能从外部提到的 no-answer 数量推断评分类别，实际只依每个原端点及既定政策复算。

## CPU 检查

原 test_review.py 全部 bytes 不变，SHA `c59a64cebeb2f5458d06bcae6101fec2b8459095be802b5b029acacdcbecbaa5`。新目录中的 `import review` 仅导入候选，未触发 run。

命令：`python3 -B -m unittest discover -s .../glm_post_analysis_metric_review_v1 -p test_review.py -v`。实际完整命令记录于 CPU_RECEIPT。Python 3.10.12，工具 chunk `019320`，exit 0，12 tests / 0 failures / 0 errors，0.001 s，一次执行。只运行原 hand-computed expectations，不引入 GLM 质量驱动的新测试或规则。

## 下一次 actual 待核事项

原算法会对 GLM plan→execution→seal→source_index→原结果/逐 agent 内容进行全绑定核验；所有 raw 必须来自 GLM RUN，所有模型 id/selector/seed/order 与 plan 一致，全部逻辑行都进入覆盖账目。失败保存首个反例，不自动改规则或重试。HPO 仅用已持久化 performance 和固定 oracle 算术，仍不能声称独立 backend 查表；literal final 选取正确性不因本脚本而获得证明。

ROOT 提出的待核巧合：K3 与 GLM Search Tight 的 PoolAct−naive MV F1 主效应同为 `0.09145299145299145`。这是 ROOT 提供的待查现象，本候选未读取质量数据验证它。实际复算获批后，应额外只读对照两模型已冻原路径/内容 SHA、逐题 MV 分数与精确配对，再检查它是不同逐题差值恰同均值，还是共同端点/误绑定；不能先把相同均值认定为复制，也不能因此改算法或选择。

完整覆盖分母、actual exit、产物全索引、首个反例和所有限制需实际执行后另外记录。`full_two_model_acceptance=false` 保留；本候选与 CPU 通过不等于 GLM 评分核验通过或双模型最终验收。当前停止，等待 ROOT。
