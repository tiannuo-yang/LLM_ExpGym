# GLM 缺答近端分类：实际产物后的独立复核

结论：**本次指定范围内通过，未发现缺答遗漏、重复、基础设施错误补零或最终调用机制归因的逻辑反例。** 本复核不是重跑主 audit、评分器、loop 或模型。详细固定引用、真实工具结果及检查边界见 `REVIEW_EVIDENCE.json`。

## 独立重数覆盖

覆盖复核子任务直接读取原 agent 的显式终态，而非照抄主输出的 coverage 数值：

| 核验项 | 独立结果 |
| --- | ---: |
| 唯一 logical rows / terminal records | 783 / 783 |
| planned / started invocations | 705 / 705 |
| 原 agent 终态 | 1,881 |
| completed_scored / model_no_answer | 1,822 / 59 |
| infrastructure、unavailable、not_started | 0 |
| 缺答集合遗漏 / 重复 / 多余 | 0 / 0 / 0 |

59 个源缺答 `(logical_id, exact-int agent_id)` 与主 missing-causes 输出集合完全一致：ExpGym 12、Pool 47；Search 54、Audit 5、HPO 0。每个 agent 的 SHA 同时绑定 export records、export original refs、missing-cause provenance 和封存 inventory；36 个 inventory 分片全部核验。五份主产物（INDEX 加四个被索引文件）的字节和 SHA 一致。

## 逐 59 条核验最后一次调用

主复核者从每条明确引用读取原 loop-terminal snapshot、原 agent artifact、最后一次原 raw、wire start / terminal，不输出正文。独立核对调用账本、client / seed / run / generation / request / attempt 身份、消息一致性、原 forced rejection 记录以及请求/响应字节 SHA。

| 从原证据得到的事实 | 条数 |
| --- | ---: |
| 实际发送并收到 `tool_choice=none` 的最后 forced-final 调用 | 59 |
| 原响应 `finish_reason=length`，无 native tool call | 59 |
| 发送的 `max_tokens=32768` | 59 |
| 该次原 usage 的 `completion_tokens=32768` | 59 |
| 原 content 为长度 0 的字符串，decoder 文本为空 | 59 |
| 原 reasoning_content 为非空白字符串 | 59 |
| 原 loop 记录 forced-final length rejection | 59 |
| 最后请求和响应与 wire 记录逐字节 SHA 一致 | 59 |
| context-cap 阻止 final 发送 / 分类 unknown | 0 / 0 |

59 个终态键、client ID 和 final request ID 各自唯一。共核对 593 条原 ledger attempt 与其同 owner 的 wire-start 顺序；读取并校验 59 份最终 raw 正文（仅在内存比较，不输出或写入正文）。本子检查共验证 875 个原件引用、925 个总引用；工具 `337247` exit 0。

因此可确认本批缺答的近端机制是：最后一次强制收尾请求已送达，但在该次生成上限处返回 length；可见最终正文仍为空，原 frozen loop 随后记录 length 拒绝。原分数、缺答政策及分母未被改动。这不是“final 根本没发送”的 context-cap 情形，也不是把 reasoning 内容恢复为答案。

## 检查过程中保留的失败记录

首次临时独立脚本（工具 `440f37`）因我错误假设 `wire.attempt_sequence == 单 agent http_request_attempts` 而提前失败。该假设不是 frozen candidate 的规则，也不是实际产物反例。

随后从 exact plan 绑定的 `planner_candidate_v1/wire.py`（SHA `bac690bc5976dad609e4544e10d0e2b31596b8cb34e996ca721ce878b4e4e52f`）第 223–227 行确认：sequence 是 invocation 共享 context 的 `c.used`，可跨 agent / Audit order 递增。修正独立校验为“同 owner 序列唯一、单调，最终项与最后 raw/wire 对应”后全部通过；没有更改候选或原产物，也没有隐藏首次失败。

覆盖子任务也保留检查过程问题：环境没有 `python` 命令，改用 `python3`；工具 `8df041`、`8f5abf` 曾错误把 source_index 的绝对路径值当作 SHA，改用 records.source_sha256 后核验通过；工具 `55a51f` 虽 exit 0 但输出被截断，后改为定向摘要，由 `8287b1` 给出完整通过结果。这些均是复核脚本或输出方式问题，不是原件哈希变化。

## 解释边界

- 32,768 是原 provider usage 报告的该次完成 token 数，并与实际请求上限和 length 响应吻合；本复核没有另用 tokenizer 重数 token。
- **观察到当前上限耗尽，不证明提高 max_tokens 一定能生成答案、提高任务分数或改变论文对比结论。** 也不能仅从非空 reasoning 推断推理质量。
- 没有逐一重读其余 534 次非最终调用的 raw 正文；这些调用的 attempt 身份和 wire-start 顺序已与原终态 ledger 比较。此局限不影响上述 59 个最终响应的逐条字节核验。
- 复核依赖明确 pin 的 export/seal 对原件来源与曾经闭合状态的证明；没有重新封存整个运行目录，也不证明 provider 当前队列为空或未来文件永不变化。
- 未调用 candidate 主 audit CLI、模型、API、完整 loop、scorer、Slurm；未读取密钥；未输出或写入答案、reasoning、工具参数正文；未修改候选或原 results。新写入仅为本独立复核目录中的报告和引用摘要。
