# GLM 冻结结果后的独立 aggregation 审阅

结论：ROOT 授权的一次实际审阅通过；没有发现汇总层逻辑反例。真实进程 exit 0、语义 passed=true、失败数 0，最大绝对数值差为 0。没有重跑，没有改结果、端点或算法。此结论仅覆盖冻结 GLM 的汇总/配对/展示一致性，不是评分真值、模型一般性优势或确认性推断。

## 运行与冻结证据

GO SHA-256 为 `42aea1543b85752250d30554a34323856a603bc840ee876982442363bcdab3c6`；脚本 SHA-256 为 `6c044351de490073e97be2d56780fcaa7496f289e6c25f106af3ce40347f04f3`。执行前验证 GO、脚本与冻结 inputs pins；核得输出目录不存在。原 prepared 副本及 K3 原审阅器不变。

仅直接执行一次 `/usr/bin/python3 -B review_glm_v1.py`，core size 为 0；启动 chunk `c925dd` 返回 session `61837`，独占跟踪的完成 chunk `c13c67` 返回真实 exit 0。程序记录开始 2026-09-09 19:12:35.232598 UTC、汇总完成 19:12:37.489813 UTC。真实进程返回与语义 passed 分开见 [OPERATOR_COMPLETION.json](OPERATOR_COMPLETION.json)。

[ACTUAL_READBACK.json](ACTUAL_READBACK.json) 对全部 12 个数据输出及执行收据（共 13 文件）固定 SHA/bytes；回读 328 个既有 input 引用（含 312 个 Pool aggregate 数值投影来源）全部未变，并额外核完出口 INDEX 在内的 17 文件。未修改 actual_v1 中任何输出，也未更改权限。核心结果：

- `actual_v1/REVIEW.json` SHA `65d9c9f4efc5cfa836b104927d6c504982fc9dedbc67e842620f3fbae38bdf30`。
- `actual_v1/EXECUTION_RECEIPT.json` SHA `5c08dd511641b066ef194e9ba7f32df1e8b1c2da97f64a666f55961b46ca3e54`。
- 完整 514 比较 `actual_v1/recomputed_effects.json` SHA `07fdce09e48983bc92852395b5a83bc50a2dd435ecb9fccebfa1cd9894b3ffe3`。

## 全覆盖与缺失状态

完整覆盖 783 logical（全部正常 terminal、0 infra）→ 705 展示 → 7687 cells → 514 比较 / 5393 pairs。全部 6 主与 508 次预先固定；Exp 158 / Pool 356；R1 124 / R3 390。39 个 Audit document、416 个指标/order 检查均保留三固定 order 等权单位，不使用 available-case。64,103 个数值断言、149,607 个结构断言、17 个原 synthetic 全通过。

CSV 与 JSON 全量一致：metrics 7687、effects 514、paired_rows 5393、logical_outcomes 783、known_subsets 135。R1 的 SD/CI/p 为 null；R3 以 outer bundle 等权计算 mean 与 sample SD，CI/p 仍为 null，不把 item×repeat 当独立样本。严格 unknown 传播保持不变；既有输入中合法的零值与 null 不互相替代。

另从已固定的 logical metadata 数得 59 个正常 agent 缺答，分布在 46 个 logical rows；所有 783 logical 的 score_state 均为 score，缺答不因此改成 infra。这不是重新核评分真值。366 个实际 null cells 全为 Pool 的 feedback_visible（Search 234、Audit 78、tuning 54）；28 个 unknown 比较和 316 个 unknown pairs 得以保留，不能称“全部 terminal 就没有 unknown”。135 行 tuning known-subset 诊断均为完整的 1-agent 或 4-agent 记录，不替代 full endpoint。

## 六个预先固定主效应

以下均为原指标单位；E-S / E-A / P-S / P-A 是 0–1 单位差，不是表中数字直接加百分号。Exp 方向是 Free − Tight；Pool 方向是 PoolAct − naive。E-A 是 evidence_acc，不是 label_acc；P-A 是 evidence_acc_mv。

| 主项 | baseline | target | effect | outerrep SD |
|---|---:|---:|---:|---:|
| E-S / F1 | 0.682651009122 | 0.230575307046 | +0.452075702076 | null（R1） |
| E-A / evidence_acc | 0.684766214178 | 0.502262443439 | +0.182503770739 | null（R1） |
| E-H / Gap，9 tasks | 97.911142760485 | 86.066888658437 | +11.844254102048 | 3.633328937252 |
| P-S / F1 MV，Tight | 0.208597285068 | 0.300050276521 | +0.091452991453 | null（R1） |
| P-A / evidence MV，Moderate | 0.809954751131 | 0.977375565611 | +0.167420814480 | null（R1） |
| P-H / NAS A Gap MI，Tight | 88.907336509557 | 95.258941790921 | +6.351605281364 | 2.953988930111 |

E-H 三个 outer effects 为 [10.575221880614967, 9.015643434548231, 15.941896990979595]；P-H 为 [9.55885053844601, 5.75358396294348, 3.7423813427032826]。六主方向本次均正，但不能据此放大为稳定、通用或因果 claim。

## 次要负值与 unknown 的完整范围

全部 514 effects：正 286 / 负 190 / 零 10 / unknown 28；其中六主全部正。全部 508 次：正 280 / 负 190 / 零 10 / unknown 28。全部 5393 pairs：正 2212 / 负 2131 / 零 734 / unknown 316。没有隐藏或用零替换负值/unknown。

[RESULT_SCOPE.json](RESULT_SCOPE.json) 完整列出每一个 190 个次要负值及 28 个次要 unknown 的 comparison ID、设定、baseline/target/effect/SD/outer values，并提供逐 system/scenario/metric 的无筛选计数；完整正值/零值仍在上述 pinned 514-row 文件中。该文件只是已核目录的分类回读，不重选端点或重算分析。

不能把 190 个负值都称为性能退步：其中 182 为资源/协议指标，8 为性能指标。性能次要项共正 118 / 负 8 / 零 2 / unknown 0；资源/协议次要项正 162 / 负 182 / 零 8 / unknown 28。所有 28 个 unknown 均是 Pool feedback_visible（Search 4、Audit 4、tuning 20）。

8 个性能负值完整概括如下，未升格为主项：

- Exp Audit label_acc 的 Free − Tight = −0.04374057315233785，与主项 evidence_acc 的正方向不同。
- cached vs naive / Audit Moderate / label_acc_mi = −0.004524886877828064。
- cached vs naive / NAS A Moderate：Gap BoN = −0.16611886354387195；raw_perf BoN = −0.0011685490608214961。
- cached vs naive / NAS B Moderate：Gap BoN = −0.07423653178797451；raw_perf BoN = −0.00018918514251708984。
- cached vs naive / NAS A Tight：Gap MI = −0.9749488280752464；raw_perf MI = −0.006858194867769914。

Gap/raw_perf 成对指标是相同任务的相关报告量，不是额外独立证据。主 P-H 使用 PoolAct，以上 tuning 负值使用 cached，不能互换策略归因。

## 独立性和未覆盖事项

审阅者非 runner/exporter/AN2 作者；是独立 K3 reviewer 作者，K3 质量曝光已披露，GLM 实际聚合质量在本次 GO 后才读取。未调用模型、网络、scorer、exporter、AN2、原运行 CLI 或 Slurm；未查 HTTP raw、答案/scoring_input 文本、gold 或私钥。answer_perf / answer_metrics 是被审输入，Pool MV 只核 pinned aggregate 数值；评分真值及原投票由另一 reviewer 负责。原始费用/推理计数提取、paper 可比性也不在本次汇总核验内。

无发现的汇总层反例不等于上述边界已验收。此次 GLM 单模型审阅不替代恢复后的 K3 以及最终双模型联合报告复查。
