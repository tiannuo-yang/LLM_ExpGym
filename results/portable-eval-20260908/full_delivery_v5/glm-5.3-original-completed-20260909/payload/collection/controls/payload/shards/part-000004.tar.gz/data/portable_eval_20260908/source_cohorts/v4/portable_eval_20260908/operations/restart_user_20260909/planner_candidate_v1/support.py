"""Pinned reuse of accepted safe I/O and anonymous-FD capture; no authority."""
import hashlib
import importlib.util
import importlib
from pathlib import Path
import sys

HERE = Path(__file__).absolute().parent
STUDY = HERE.parents[2]
IO_PATH = STUDY / "operations/adapters_v1/common_io.py"
IO_SHA = "04a1e3d1db7f86ba02f2fca0c3a1a12ebc97877f551a973b37ad862b7fa0a864"
SECRET_ROOT = STUDY / "design/formal_executor_real_candidate/phase3b_real_execution_retry_v5"
SECRET_SHA = "6aca3545e229f3663d6fe95c389aafbf4dad76b9c9901483474fc3b2e372c97c"
PROFILE_PATH = STUDY.parents[2] / "patches/profile_parameterization_v2/candidate/harness/request_profile.py"
PROFILE_SHA = "64f19f0de7c36a0c8b461ae28056e481aa73f2980ba3d91cd8d34a40a4f6eb70"


def load_file(name, path, expected):
    body = Path(path).read_bytes()
    if hashlib.sha256(body).hexdigest() != expected:
        raise ValueError("pinned_helper_changed")
    spec = importlib.util.spec_from_file_location(name, str(path))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


io = load_file("restart_accepted_safe_io", IO_PATH, IO_SHA)
profile_helper = load_file("restart_accepted_request_profile", PROFILE_PATH, PROFILE_SHA)
canonical, parse_json = io.canonical, io.parse_json


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def ref(path):
    raw = io.read_regular(path)
    return io.file_ref_from_bytes(path, raw)


def put(directory, basename, value):
    return io.write_new(directory, basename, canonical(value) + b"\n")


def secret_helpers():
    path = SECRET_ROOT / "secret_fd.py"
    if hashlib.sha256(io.read_regular(path)).hexdigest() != SECRET_SHA:
        raise ValueError("anonymous_fd_capture_helper_changed")
    # This helper only calls accepted path I/O and subprocess capture functions,
    # not its old authority, matrix, runner, scorer or resume implementation.
    sys.path.insert(0, str(SECRET_ROOT))
    module = importlib.import_module("secret_fd")
    if Path(module.__file__).absolute() != path:
        raise ValueError("wrong_anonymous_fd_helper")
    return module


def new_child_directory(parent, name):
    if not isinstance(name, str) or Path(name).name != name or name in ("", ".", ".."):
        raise ValueError("single_directory_component_required")
    return io.new_directory(Path(parent) / name)


def check_runtime(runtime):
    if set(runtime) != {"executable", "resolved_executable_ref", "prefix", "pyvenv_config_ref"}:
        raise ValueError("complete_runtime_binding_required")
    executable = io.lexical(runtime["executable"])
    if str(executable.resolve()) != runtime["resolved_executable_ref"]["path"]:
        raise ValueError("interpreter_target_changed")
    io.read_ref(runtime["resolved_executable_ref"])
    io.read_ref(runtime["pyvenv_config_ref"])
    if io.lexical(runtime["pyvenv_config_ref"]["path"]).parent != io.lexical(runtime["prefix"]):
        raise ValueError("runtime_prefix_config_mismatch")
