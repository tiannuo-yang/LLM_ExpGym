#!/usr/bin/env python3
"""Independent, stdlib-only review of one pinned GLM aggregation export.

No candidate imports, scorers, voting, models, network, subprocesses, raw HTTP,
gold lookup, or answer-text inspection. The JSON reader discards answer-bearing
fields; reported numeric scores remain inputs, not independently rescored truth.
"""
import argparse
import csv
import hashlib
import io
import json
import math
from collections import Counter, defaultdict
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE / "actual_v1"
OP = HERE.parent
EXPORT = OP / "actual_formal_export_glm_completed_v2"
N = OP.parents[1]
RUN = N / "formal_runs/restart-20260909-v5-glm-5.3-formal"
PLAN = OP / "compiled_restart-20260909-v5-glm-5.3-formal/plan.json"
SEAL = OP / "sealed_restart_runs_v1/glm-5.3-formal-completed-20260909/inventory.json"
CATALOG = N / "design/formal_export_candidate/converter.py"
PINS = {
    str(EXPORT / "EXPORT_INDEX.json"): "e32cab1af07054e76503aab79c66b76bcc216d2021cf0f46cd638340023bbca7",
    str(EXPORT / "results.json"): "619694559402dbc52fbbc24769bd5627d7115109ac4490948cebede4569cdb84",
    str(EXPORT / "provenance.json"): "4ce6a29ee5f93582e9b21627dc8ebd189ba3acfe0de53acf1b0903b00e460a67",
    str(PLAN): "8b9ed4a00674689f62aaca73cc35c84f1d88439fe5f75b636164bfe4d70e574b",
    str(RUN / "execution.json"): "16d4569396aa2dd95393013084b3d3b70eaff06e1a8d95d39dc35a36652344b2",
    str(SEAL): "da5b89e1041e396c04673b6f363dd01a3f6d64b61bfd9fe6d60f0a6617957f22",
    str(CATALOG): "0261660a38d80c9135efc498f11580ef3fea26de00e6061824e9c9380662547f",
}
IDENTITY = ("model", "system", "scenario", "item", "regime", "strategy", "outerseed")
COMMON = {"feedback_attempts", "feedback_visible", "duplicate_action_attempts",
          "feedback_cost_seconds", "input_tokens", "output_tokens",
          "wall_time_seconds", "protocol_failure_rate"}
PERFORMANCE = {
    ("expgym", "restricted_search"): {"f1"},
    ("expgym", "evidence_audit"): {"label_acc", "evidence_acc"},
    ("expgym", "tuning"): {"gap", "raw_perf"},
    ("poolact", "restricted_search"): {"f1_mi", "f1_mv"},
    ("poolact", "evidence_audit"): {"label_acc_mi", "label_acc_mv", "evidence_acc_mi", "evidence_acc_mv"},
    ("poolact", "tuning"): {"gap_mi", "gap_bon", "raw_perf_mi", "raw_perf_bon"},
}
FORBIDDEN = {"answer", "raw_answer", "scoring_input", "individual_answers",
             "messages", "history", "content", "reasoning", "raw_response"}
INPUTS = {}
CHECKS = []
NUMERIC_CHECKS = []


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False,
                      default=lambda obj: sorted(obj) if isinstance(obj,set) else str(obj)).encode()


def redacted_object(pairs):
    result, seen = {}, set()
    for key, value in pairs:
        if key in seen:
            raise ValueError("duplicate JSON key")
        seen.add(key)
        if key not in FORBIDDEN:
            result[key] = value
    return result


def read_bytes(path, expected=None):
    path = Path(path)
    payload = path.read_bytes()
    actual = digest(payload)
    if expected is not None and actual != expected:
        raise ValueError("input pin mismatch: " + str(path))
    INPUTS[str(path)] = {"bytes": len(payload), "sha256": actual}
    return payload


def read_json(path, expected=None):
    return json.loads(read_bytes(path, expected), object_pairs_hook=redacted_object,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError("nonfinite JSON")))


def check(label, condition, detail=None):
    CHECKS.append({"check": label, "passed": bool(condition), "detail": detail})


def same(label, observed, expected):
    check(label, observed == expected, None if observed == expected else {"observed": observed, "expected": expected})


def numeric(label, observed, expected, bucket=None):
    valid = (observed is None and expected is None)
    delta = None
    if observed is not None and expected is not None:
        valid = type(observed) in (int, float) and math.isfinite(observed)
        if valid:
            delta = observed - expected
            valid = math.isclose(observed, expected, rel_tol=1e-9, abs_tol=1e-9)
    entry = {"pointer": label, "reported": observed, "recomputed": expected, "delta": delta, "passed": valid}
    NUMERIC_CHECKS.append(entry)
    if bucket is not None:
        bucket.append(entry)
    if not valid:
        check(label, False, entry)
    return valid


def strict_average(values):
    if not values or any(value is None for value in values):
        return None
    # Rational accumulation of the input floats provides an implementation
    # independent of the target's statistics.mean call and summation order.
    return float(sum((Fraction(value) for value in values), Fraction()) / len(values))


def strict_max(values):
    return None if not values or any(value is None for value in values) else max(values)


def effect_value(baseline, target, higher, exp):
    if baseline is None or target is None:
        return None
    difference = baseline - target if exp else target - baseline
    return difference if higher else -difference


def sample_sd(values):
    if len(values) < 2 or any(value is None for value in values):
        return None
    q = [Fraction(value) for value in values]
    center = sum(q, Fraction()) / len(q)
    return math.sqrt(float(sum(((value-center)**2 for value in q), Fraction()) / (len(q)-1)))


def clipped_gap(perf, oracle):
    if perf is None:
        return None
    low, high = oracle["mean_perf"], oracle["best_perf"]
    if not high > low:
        raise ValueError("nonpositive pinned Gap denominator")
    return max(0.0, 100.0 * (perf-low) / (high-low))


def higher_is_better(metric):
    return metric not in COMMON | {"budget_utilization"} or metric == "feedback_visible"


def synthetic_cases():
    cases = []
    def case(name, observed, expected):
        ok = observed == expected if observed is None or expected is None else math.isclose(observed, expected, abs_tol=1e-12)
        cases.append({"case": name, "observed": observed, "expected": expected, "passed": ok})
    case("three_fixed_orders_equal_weight", strict_average([.2,.4,.9]), .5)
    case("missing_order_is_not_available_case", strict_average([.2,None,.9]), None)
    case("Exp_higher_Free_minus_Tight", effect_value(.8,.3,True,True), .5)
    case("Exp_cost_lower_direction", effect_value(8,3,False,True), -5)
    case("Pool_higher_candidate_minus_naive", effect_value(.8,.3,True,False), -.5)
    case("Pool_lower_candidate_minus_naive", effect_value(8,3,False,False), 5)
    case("missing_pair_propagates", effect_value(None,.3,True,True), None)
    case("R1_SD_null", sample_sd([.5]), None)
    case("R3_sample_SD", sample_sd([1,2,3]), 1)
    case("R3_missing_bundle_SD_null", sample_sd([1,None,3]), None)
    bundles = [strict_average([1,3]),strict_average([2,4]),strict_average([3,5])]
    case("R3_bundle_mean", strict_average(bundles), 3)
    case("R3_bundle_SD_not_pooled_item_SD", sample_sd(bundles), 1)
    case("R3_missing_pair_full_mean_null", strict_average([2,None,4]), None)
    gaps = [clipped_gap(p,{"mean_perf":.5,"best_perf":.75}) for p in [.4,.6,.8,1]]
    case("per_agent_clip_before_MI",strict_average(gaps),90)
    case("Gap_above_100_retained",strict_max(gaps),200)
    case("unknown_N4_not_known_subset",strict_average([40,None,120,200]),None)
    empty_slice_fixture = {"logical_rows":[{"model":"synthetic","system":"poolact","scenario":"restricted_search","item":"known-whois","selector":{"question_family":"whois"}}]}
    case("empty_unplanned_slice_not_registered",len(expected_catalogue(empty_slice_fixture)),44)
    if not all(case["passed"] for case in cases):
        raise ValueError("independent synthetic arithmetic failed")
    return cases


def expected_catalogue(manifest):
    items = defaultdict(dict)
    for row in manifest["logical_rows"]:
        items[(row["model"],row["system"],row["scenario"])][row["item"]] = row
    output = {}
    for (model,system,scenario), item_map in sorted(items.items()):
        slices = {}
        if scenario == "restricted_search":
            for family in ("whois","whatis"):
                subset = sorted(item for item,row in item_map.items() if row["selector"]["question_family"] == family)
                if subset:
                    slices[family] = subset
        else:
            slices["all"] = sorted(item_map)
            if scenario == "tuning":
                for family in sorted({row["selector"]["family"] for row in item_map.values()}):
                    slices["family="+family] = sorted(item for item,row in item_map.items() if row["selector"]["family"] == family)
                slices.update({"task="+item:[item] for item in sorted(item_map)})
        exp = system == "expgym"
        metrics = PERFORMANCE[(system,scenario)] | COMMON | (set() if exp else {"budget_utilization"})
        repeats = ["outer_00000"] if scenario != "tuning" else ["outer_00000","outer_00001","outer_00002"]
        for slice_name, subset in slices.items():
            for regime in ([None] if exp else ["cost_moderate","cost_tight"]):
                for strategy in (["single"] if exp else ["cached","poolact"]):
                    for metric in sorted(metrics):
                        primary = None
                        if exp:
                            primary = {("restricted_search","whois","f1"):"E-S",("evidence_audit","all","evidence_acc"):"E-A",("tuning","all","gap"):"E-H"}.get((scenario,slice_name,metric))
                        elif strategy == "poolact":
                            primary = {("restricted_search","whois","cost_tight","f1_mv"):"P-S",("evidence_audit","all","cost_moderate","evidence_acc_mv"):"P-A",("tuning","task=hpobench:nasbench101:A","cost_tight","gap_mi"):"P-H"}.get((scenario,slice_name,regime,metric))
                        key = [model,system,scenario,slice_name,regime,strategy,metric]
                        cid = model+"__"+(primary if primary else "secondary_"+digest(canonical(key))[:20])
                        output[cid] = {"model":model,"system":system,"scenario":scenario,"slice":slice_name,"regime":regime,"strategy":strategy,"metric":metric,"role":"primary" if primary else "secondary","items":subset,"outerseeds":repeats,"kind":"expgym_free_tight" if exp else "poolact_vs_naive"}
    return output


def review():
    started = datetime.now(timezone.utc).isoformat()
    synthetic = synthetic_cases()
    # Read and validate every externally supplied anchor before numeric review.
    index = read_json(EXPORT / "EXPORT_INDEX.json", PINS[str(EXPORT / "EXPORT_INDEX.json")])
    read_bytes(CATALOG, PINS[str(CATALOG)])  # Hash only; never execute/import.
    plan = read_json(PLAN,PINS[str(PLAN)])
    execution = read_json(RUN / "execution.json",PINS[str(RUN / "execution.json")])
    seal = read_json(SEAL,PINS[str(SEAL)])
    def export_json(name):
        return read_json(EXPORT/name,index["files"][name]["sha256"])
    data, manifest, records, provenance = [export_json(name) for name in ("results.json","manifest.json","records.json","provenance.json")]
    oracle, source_index = export_json("oracle.json")["tasks"], export_json("source_index.json")
    for name in ("results.json","provenance.json"):
        same("ROOT_pin_"+name,index["files"][name]["sha256"],PINS[str(EXPORT/name)])
    same("manifest_equals_frozen_plan_matrix",manifest,plan["matrix"])
    same("export_provenance_equals_json_copy",provenance,data["provenance"])
    same("record_manifest_pin",records["manifest_sha256"],index["files"]["manifest.json"]["sha256"])
    same("provenance_manifest_pin",provenance["input_pins"]["manifest_sha256"],index["files"]["manifest.json"]["sha256"])
    same("provenance_records_pin",provenance["input_pins"]["records_sha256"],index["files"]["records.json"]["sha256"])
    same("execution_complete_retained",execution["execution_complete"],True)
    same("seal_705_started",seal["started_count"],705)
    same("seal_no_unstarted",seal["unstarted_count"],0)
    for ref in seal["control_refs"]:
        if ref["path"] in PINS:
            same("seal_control_pin:"+ref["path"],ref["sha256"],PINS[ref["path"]])
    planned = {row["logical_id"]:row for row in manifest["logical_rows"]}
    recs = {row["logical_id"]:row for row in records["records"]}
    outcomes = {row["logical_id"]:row for row in data["logical_outcomes"]}
    same("planned_logical_783",len(planned),783)
    same("records_complete_ID_set",set(recs),set(planned))
    same("logical_outcomes_complete_ID_set",set(outcomes),set(planned))
    same("records_no_duplicate",len(recs),len(records["records"]))
    same("logical_no_duplicate",len(outcomes),len(data["logical_outcomes"]))
    same("planned_invocations_705",len({row["invocation_id"] for row in planned.values()}),705)
    same("execution_started_exact_set",set(execution["started_invocation_ids"]),{row["invocation_id"] for row in planned.values()})
    same("only_frozen_GLM_model",{row["model"] for row in planned.values()},{"glm-5.3"})
    raw_by_logical = defaultdict(list)
    for terminal in data["raw_terminals"]:
        raw_by_logical[terminal["logical_id"]].append(terminal)
    same("raw_terminal_planned_ID_set",set(raw_by_logical),set(planned))
    same("raw_terminal_count_1881",len(data["raw_terminals"]),1881)
    groups = defaultdict(list)
    logical_metrics, mv_sources = {}, []
    states = Counter()
    for lid,row in planned.items():
        rec, outcome = recs[lid],outcomes[lid]
        states[rec["state"]] += 1
        outer = f"outer_{row['outerrep']:05d}"
        ident = tuple(row[field] if field != "outerseed" else outer for field in IDENTITY)
        groups[ident].append(lid)
        terminals = sorted(raw_by_logical[lid],key=lambda item:item["agent_id"])
        n = 1 if row["system"] == "expgym" else 4
        same("agent_IDs:"+lid,[t["agent_id"] for t in terminals],list(range(n)))
        same("logical_state:"+lid,outcome["execution_state"],rec["state"])
        same("source_binding:"+lid,outcome["source_sha256"],rec["source_sha256"])
        same("invocation_binding:"+lid,outcome["invocation_id"],row["invocation_id"])
        expected_metrics = PERFORMANCE[(row["system"],row["scenario"])] | COMMON | ({"budget_utilization"} if row["regime"] != "cost_free" else set())
        values = {metric:None for metric in expected_metrics}
        values.update({key:rec["telemetry"][key] for key in expected_metrics & (COMMON|{"budget_utilization"})})
        if rec["state"] != "terminal":
            same("infra_score_state:"+lid,outcome["score_state"],"error")
            same("infra_not_model_abstention:"+lid,outcome["model_no_answer_count"],0)
            check("infra_unobserved:"+lid,all(t["answer_observed"] is False for t in terminals))
        else:
            scores = [t["original_terminal"] for t in terminals]
            perfs = [t.get("answer_perf") for t in scores]
            scenario = row["scenario"]
            if scenario == "tuning":
                gaps = [clipped_gap(perf,oracle[row["selector"]["tuning_task"]]) for perf in perfs]
                if n == 1:
                    values.update(raw_perf=perfs[0],gap=gaps[0])
                else:
                    values.update(raw_perf_mi=strict_average(perfs),raw_perf_bon=strict_max(perfs),gap_mi=strict_average(gaps),gap_bon=strict_max(gaps))
            else:
                score_arrays = {"f1":perfs} if scenario == "restricted_search" else {metric:[score.get("answer_metrics",{}).get(metric) for score in scores] for metric in ("label_acc","evidence_acc")}
                for metric,array in score_arrays.items():
                    values[metric if n == 1 else metric+"_mi"] = strict_average(array)
                if n == 4:
                    relative = row["result_artifact"]
                    source_path = Path(source_index[relative]).resolve()
                    if not source_path.is_relative_to(RUN.resolve()):
                        raise ValueError("source outside explicitly frozen GLM run")
                    aggregate = read_json(source_path,rec["source_sha256"][relative])["aggregate"]
                    for metric in score_arrays:
                        values[metric+"_mv"] = aggregate.get("answer_perf") if metric == "f1" else aggregate.get("answer_metrics",{}).get(metric)
                    mv_sources.append({"logical_id":lid,"path":str(source_path),"sha256":rec["source_sha256"][relative]})
        logical_metrics[lid] = values
    same("exact_logical_states",dict(states),{"terminal":783})
    same("groups_705",len(groups),705)
    by_identity = {tuple(spec[k] for k in IDENTITY):spec for spec in data["artifact_specs"]}
    same("display_ID_set",set(by_identity),set(groups))
    same("display_no_duplicate",len(by_identity),len(data["artifact_specs"]))
    rows = {(tuple(row[k] for k in IDENTITY),row["metric"]):row for row in data["rows"]}
    same("metric_no_duplicate",len(rows),len(data["rows"]))
    same("metric_cells_7687",len(rows),7687)
    expected_cells, cell_checks, audit_checks = set(), [], []
    for ident,lids in groups.items():
        spec = by_identity[ident]
        derived = data["derived_artifacts"][spec["artifact"]]
        source_rows = [planned[lid] for lid in lids]
        audit = ident[1:3] == ("expgym","evidence_audit")
        same("display_unit:"+spec["artifact"],derived["unit"],"document_outerrep" if audit else ("single_trace" if ident[1] == "expgym" else "pool_aggregate"))
        same("artifact_spec_unit:"+spec["artifact"],spec["unit"],derived["unit"])
        same("components_IDs:"+spec["artifact"],{c["logical_id"] for c in derived["components"]},set(lids))
        for component in derived["components"]:
            lid = component["logical_id"]
            same("component_source_binding:"+lid,component["source_sha256"],recs[lid]["source_sha256"])
            same("component_input_binding:"+lid,component["selected_input_sha256"],planned[lid]["selected_input_sha256"])
            same("component_record_binding:"+lid,component["record_sha256"],digest(canonical(recs[lid])))
            same("component_state:"+lid,component["state"],recs[lid]["state"])
            same("component_order:"+lid,component["order"],planned[lid]["order"])
        if audit:
            same("Audit_three_orders:"+spec["artifact"],sorted(row["order"] for row in source_rows),[0,1,2])
        else:
            same("single_logical_display:"+spec["artifact"],len(lids),1)
        wanted = set(logical_metrics[lids[0]])
        same("display_metric_catalogue:"+spec["artifact"],set(spec["metrics"]),wanted)
        same("derived_metric_catalogue:"+spec["artifact"],set(derived["metrics"]),wanted)
        for metric in sorted(wanted):
            parts = [logical_metrics[lid][metric] for lid in lids]
            expected = strict_average(parts)
            key = (ident,metric)
            expected_cells.add(key)
            pointer = spec["artifact"]+"/metrics/"+metric
            numeric(pointer,derived["metrics"][metric],expected,cell_checks)
            numeric("rows/"+pointer,rows[key]["value"],expected,cell_checks)
            same("row_artifact:"+pointer,rows[key]["artifact"],spec["artifact"])
            if audit:
                audit_checks.append({"artifact":spec["artifact"],"metric":metric,"logical_ids":lids,"component_values":parts,"expected_equal_three_order_value":expected,"reported":derived["metrics"][metric],"missing_order_mutation_expected":strict_average(parts[:2]+[None])})
    same("all_metric_cell_IDs",set(rows),expected_cells)
    same("Audit_document_endpoints_39",sum(ident[1:3] == ("expgym","evidence_audit") for ident in groups),39)
    # Catalogue derives only from frozen plan item metadata and the fixed metric
    # definitions above, never from values or the reported comparison list.
    catalogue = expected_catalogue(manifest)
    actual_specs = {spec["id"]:spec for spec in data["comparisons"]}
    effects = {effect["comparison"]:effect for effect in data["effects"]}
    actual_pairs = {(pair["comparison"],pair["item"],pair["outerseed"]):pair for pair in data["paired_rows"]}
    same("514_predeclared_catalogue",len(catalogue),514)
    same("comparison_ID_set",set(actual_specs),set(catalogue))
    same("effect_ID_set",set(effects),set(catalogue))
    same("comparison_no_duplicates",len(actual_specs),len(data["comparisons"]))
    same("effect_no_duplicates",len(effects),len(data["effects"]))
    same("pair_no_duplicates",len(actual_pairs),len(data["paired_rows"]))
    same("6_primary_508_secondary",dict(Counter(spec["role"] for spec in catalogue.values())),{"primary":6,"secondary":508})
    same("158_Exp_356_Pool",dict(Counter(spec["system"] for spec in catalogue.values())),{"expgym":158,"poolact":356})
    pair_checks, effect_checks, expected_pair_keys = [], [], set()
    recomputed_effects = []
    for cid,spec in sorted(catalogue.items()):
        if cid not in actual_specs or cid not in effects:
            check("missing_reported_catalogue_entry:"+cid,False,{"expected":spec,"comparison_present":cid in actual_specs,"effect_present":cid in effects})
            continue
        given, reported = actual_specs[cid],effects[cid]
        for field,value in spec.items():
            if field != "system":
                same("catalogue:"+cid+"/"+field,given.get(field),value)
        same("descriptive_bootstrap_disabled:"+cid,given["bootstrap_method"],"disabled_descriptive_only")
        same("metric_orientation:"+spec["metric"],data["metric_definitions"][spec["metric"]]["higher_is_better"],higher_is_better(spec["metric"]))
        outer_results = []
        exp = spec["system"] == "expgym"
        for outer in spec["outerseeds"]:
            group_pairs = []
            for item in spec["items"]:
                def lookup(regime,strategy):
                    identity = (spec["model"],spec["system"],spec["scenario"],item,regime,strategy,outer)
                    return rows[(identity,spec["metric"])]["value"]
                baseline = lookup("cost_free" if exp else spec["regime"],"single" if exp else "naive")
                target = lookup("cost_tight" if exp else spec["regime"],spec["strategy"])
                expected = {"baseline":baseline,"target":target,"effect":effect_value(baseline,target,higher_is_better(spec["metric"]),exp)}
                key = (cid,item,outer)
                expected_pair_keys.add(key)
                for field,value in expected.items():
                    numeric("pairs/"+"/".join(key)+"/"+field,actual_pairs[key][field],value,pair_checks)
                group_pairs.append(expected)
            outer_results.append({field:strict_average([pair[field] for pair in group_pairs]) for field in ("baseline","target","effect")})
        bundle_effects = [bundle["effect"] for bundle in outer_results]
        recomputed = {field:strict_average([bundle[field] for bundle in outer_results]) for field in ("baseline","target","effect")}
        recomputed.update(outerrep_descriptive_sd=sample_sd(bundle_effects),ci=None,p_value=None)
        for field,value in recomputed.items():
            numeric("effects/"+cid+"/"+field,reported[field],value,effect_checks)
        same("outer_bundle_count:"+cid,len(reported["outer_bundle_effects"]),len(bundle_effects))
        for i,value in enumerate(bundle_effects):
            numeric("effects/"+cid+"/outer_bundle/"+str(i),reported["outer_bundle_effects"][i],value,effect_checks)
        same("n_items:"+cid,reported["n_items"],len(spec["items"]))
        same("n_outer_repeats:"+cid,reported["n_outer_repeats"],len(spec["outerseeds"]))
        same("n_pairs:"+cid,reported["n_pairs_descriptive_not_independent_n"],len(spec["items"])*len(spec["outerseeds"]))
        same("descriptive_status:"+cid,reported["status"],"descriptive_complete" if recomputed["effect"] is not None else "unknown_incomplete_endpoint")
        recomputed_effects.append({"comparison":cid,**spec,**recomputed,"outer_bundle_effects":bundle_effects})
    same("all_5393_pairs",len(expected_pair_keys),5393)
    same("pair_exact_ID_set",set(actual_pairs),expected_pair_keys)
    # CSV is a byte-pinned mirror: all fields/rows are checked, including blanks
    # for JSON null. Structured columns compare by JSON, not by text formatting.
    csv_counts = {}
    for filename,json_key in (("metrics.csv","rows"),("effects.csv","effects"),("paired_rows.csv","paired_rows"),("logical_outcomes.csv","logical_outcomes"),("known_subsets.csv","known_subsets")):
        payload = read_bytes(EXPORT/filename,index["files"][filename]["sha256"])
        table = list(csv.DictReader(io.StringIO(payload.decode(),newline="")))
        original = data[json_key]
        csv_counts[filename] = len(table)
        same("CSV_row_count:"+filename,len(table),len(original))
        for i,(csvrow,jsonrow) in enumerate(zip(table,original)):
            same("CSV_fields:"+filename+"/"+str(i),set(csvrow),set(jsonrow))
            for field,value in jsonrow.items():
                exported = csvrow[field]
                pointer = "CSV/"+filename+"/"+str(i)+"/"+field
                if value is None:
                    same(pointer,exported,"")
                elif isinstance(value,bool):
                    same(pointer,exported,str(value))
                elif isinstance(value,(dict,list)):
                    same(pointer,json.loads(exported),value)
                elif isinstance(value,(int,float)):
                    numeric(pointer,float(exported),value)
                else:
                    same(pointer,exported,value)
    # Keep known subset descriptive summaries separate from complete endpoints.
    subset_checks = []
    for row in data["known_subsets"]:
        lid = row["logical_id"]
        planned_row = planned[lid]
        perfs = [terminal["original_terminal"].get("answer_perf") for terminal in raw_by_logical[lid]]
        known = [perf for perf in perfs if perf is not None]
        gaps = [clipped_gap(perf,oracle[planned_row["selector"]["tuning_task"]]) for perf in known]
        same("known_subset_n:"+lid,row["n_known"],len(known))
        same("known_subset_total:"+lid,row["n_total"],len(perfs))
        same("known_subset_not_full:"+lid,row["not_full_pool_endpoint"],len(known) != len(perfs))
        for field,value in {"mean_perf":strict_average(known),"best_perf":strict_max(known),"mean_clipped_gap":strict_average(gaps),"best_clipped_gap":strict_max(gaps)}.items():
            numeric("known_subsets/"+lid+"/"+field,row[field],value,subset_checks)
    effects_sign = Counter("unknown" if row["effect"] is None else "positive" if row["effect"]>0 else "negative" if row["effect"]<0 else "zero" for row in recomputed_effects)
    pair_sign = Counter("unknown" if row["effect"] is None else "positive" if row["effect"]>0 else "negative" if row["effect"]<0 else "zero" for row in data["paired_rows"])
    limitations = [
        "Independent aggregation arithmetic and fixed-plan coverage only; reported answer_perf/answer_metrics are inputs, not rescored truth.",
        "MV values were read from pinned Pool result.aggregate numeric fields; vote construction and scorer/gold truth belong to the separate reviewer.",
        "Telemetry aggregation checked against exported records; original token/cost extraction and allocation/GPU totals are not independently reviewed here.",
        "Answer/scoring_input text is discarded by the JSON reader and never inspected; no HTTP raw, gold lookup, model/API, scorer, original CLI, or Slurm was used.",
        "Frozen GLM metadata records 783 terminal logical outcomes and zero infrastructure errors; terminal does not imply a model answer. This review is not a dual-model final review or confirmatory inference.",
        "Strict missing-order propagation is exercised by one value-local mutation for each Audit metric endpoint plus an independent synthetic example; this is not a production-path missing-order injection.",
    ]
    report = {"schema_version":"glm-independent-aggregation-review-v1","started_at_utc":started,"finished_at_utc":datetime.now(timezone.utc).isoformat(),"reviewer_was_candidate_author":False,"candidate_functions_called":False,"code_sha256":digest(Path(__file__).read_bytes()),"passed":all(row["passed"] for row in CHECKS) and all(row["passed"] for row in NUMERIC_CHECKS),"counts":{"planned_logical":len(planned),"planned_invocations":705,"planned_agents":len(data["raw_terminals"]),"derived":len(groups),"metric_cells":len(rows),"comparisons":len(catalogue),"pairs":len(expected_pair_keys),"logical_states":dict(states),"roles":dict(Counter(row["role"] for row in catalogue.values())),"effect_signs":dict(effects_sign),"pair_signs":dict(pair_sign),"R1_comparisons":sum(len(row["outerseeds"])==1 for row in catalogue.values()),"R3_comparisons":sum(len(row["outerseeds"])==3 for row in catalogue.values()),"Audit_documents":39,"Audit_metric_order_checks":len(audit_checks),"Pool_MV_reported_source_projections":len(mv_sources),"numeric_assertions":len(NUMERIC_CHECKS),"structural_assertions":len(CHECKS),"csv_rows":csv_counts},"primary_recomputed":[row for row in recomputed_effects if row["role"]=="primary"],"failures":[row for row in CHECKS if not row["passed"]],"maximum_absolute_numeric_delta":max((abs(row["delta"]) for row in NUMERIC_CHECKS if row["delta"] is not None),default=0),"limitations":limitations}
    return {"REVIEW.json":report,"inputs.json":INPUTS,"synthetic_cases.json":synthetic,"structural_checks.json":CHECKS,"numeric_checks.json":NUMERIC_CHECKS,"cell_checks.json":cell_checks,"audit_order_checks.json":audit_checks,"pair_checks.json":pair_checks,"effect_checks.json":effect_checks,"recomputed_effects.json":recomputed_effects,"pool_mv_source_projections.json":mv_sources,"known_subset_checks.json":subset_checks}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--synthetic-only",action="store_true")
    args = parser.parse_args()
    if args.synthetic_only:
        cases = synthetic_cases()
        print(json.dumps({"synthetic_cases":len(cases),"passed":all(case["passed"] for case in cases),"code_sha256":digest(Path(__file__).read_bytes())}))
        return 0
    outputs = review()
    OUT.mkdir(exist_ok=False)
    for name,value in outputs.items():
        with (OUT/name).open("xb") as handle:
            handle.write(canonical(value)+b"\n")
    receipt = {"argv":["python3","-B",str(Path(__file__).resolve())],"code_sha256":digest(Path(__file__).read_bytes()),"outputs":{name:{"sha256":digest((OUT/name).read_bytes()),"bytes":(OUT/name).stat().st_size} for name in outputs},"passed":outputs["REVIEW.json"]["passed"]}
    with (OUT/"EXECUTION_RECEIPT.json").open("xb") as handle:
        handle.write(canonical(receipt)+b"\n")
    print(json.dumps({"passed":receipt["passed"],"counts":outputs["REVIEW.json"]["counts"],"failures":len(outputs["REVIEW.json"]["failures"]),"receipt":str(OUT/"EXECUTION_RECEIPT.json")}))
    return 0 if receipt["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
