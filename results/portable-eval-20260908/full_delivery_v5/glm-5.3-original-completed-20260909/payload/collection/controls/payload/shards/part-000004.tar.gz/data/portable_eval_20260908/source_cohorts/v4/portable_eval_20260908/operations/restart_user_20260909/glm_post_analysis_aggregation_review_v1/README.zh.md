# GLM 独立 aggregation 审阅器：最小绑定准备

状态：仅准备与 17 个原 synthetic 通过；等待 ROOT 单独的 actual GO。本文件不是 GO，未执行实际 aggregation review。

新副本为 `review_glm_v1.py`，SHA-256 `6c044351de490073e97be2d56780fcaa7496f289e6c25f106af3ce40347f04f3`（31223 bytes）。原 K3 `review_v2.py` SHA-256 `4cbcb3a63a98f7e100aaf9276d5f60733ee45e89e53a73ed3a69e13c0dc3e31c`（31200 bytes）保持不变。创建前确认本目录不存在。

## 范围与差异

完整文本差异见 [BINDING_DIFF.patch](BINDING_DIFF.patch)，pins、元数据、CPU 与真实工具返回见 [PREPARATION.json](PREPARATION.json)。

只改变 19 行：L2、20、22、24–26、29–34、242、258、304、310、456–457、459。内容限于 GLM 输入/输出路径与六项 pins、模型标签、已冻结完成状态、路径越界错误文字及诚实的报告说明/schema。catalogue pin 保持不变；不修改算法、端点、等权、严格 null、样本 SD、容差、比较选择或测试。static AST 和逐字源码核验确认除 `review()` 的上述绑定/描述行外，其余 17 个函数均未变；原 `synthetic_cases()` 与全部 17 个用例完全保留。

冻结元数据实际核得模型 `glm-5.3`、783 logical 全为 terminal、705 invocation 全启动、0 未启动，execution_complete/score_complete 均为 true；因此预期 logical states 改为 `{"terminal":783}`，不是沿用 K3 775/8。ROOT 告知的 59 个正常 agent 缺答，本准备阶段没有重新计数；它们不因“缺答”被归为 infra，原 terminal/null 分支完全未改。

783→705 展示、1881 slots、7687 cells、514 比较（6 主/508 次、Exp 158/Pool 356）、5393 pairs、39 Audit documents 等原固定设计断言保留；此处并不声称这些 GLM 实际汇总已通过。缺失、负值、unknown、符号等质量统计不预填，也不从 K3 复制。

## 仅 synthetic 的实际执行

唯一被执行的新副本入口带 `--synthetic-only`。工具 chunk `6aef2f`，真实 exit 0，无 session；语义结果为 17 cases / passed true。Python 3.10.12，单 Python 进程、无 multiprocessing、无 GPU 调用；主机 Intel Xeon Platinum 8480C，96 个在线逻辑 CPU。测得 user CPU 0.02 s、system CPU 0.01 s、elapsed 0.04 s、max RSS 18348 KiB。执行前后 `actual_v1` 均不存在。静态 diff 的 exit 1 只表示存在预期文本差异，并非 synthetic 失败。

注意：保留的 `main()` 在不带 `--synthetic-only` 时会直接开始实际审阅。本轮没有执行该分支；不得将本准备记录当作 actual GO。未来真实审阅仍需另记录工具 chunk、process exit 与 session，不能只用语义 passed 代替。

## 独立性与边界

审阅者不是 runner、exporter 或 AN2 作者；是独立 K3 审阅器作者，已经看过 K3 质量。GLM 本轮只核冻结状态元数据与文件哈希，未查看质量字段或原答案；results.json 仅哈希，不读原 run result、HTTP raw、gold、私钥，不调用网络、模型、scorer、原 CLI、Slurm、AN2 或 exporter。原件和已完成 K3 审阅文件不改。具体评分真值/MV 原始投票由另一独立 reviewer 负责。

本准备与未来单模型汇总审查均不能代替恢复后的 K3、GLM 及最终双模型联合报告复查。
