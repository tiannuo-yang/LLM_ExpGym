"""Two independent bounded red/green checks; no real request or result inputs."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import socket
import sys
import tempfile
import time
import unittest
from unittest import mock

sys.dont_write_bytecode = True
HERE = Path(__file__).absolute().parent
OP = HERE.parent
V1 = OP / 'formal_prompt_audit_candidate_v1'
V2 = OP / 'formal_prompt_audit_candidate_v2'
PINS = {
    V1 / 'audit_prompts.py': '5c82373d9d74202bfe997246d7a7b9f5697cfe98845119b7402bc9b3469e7b1e',
    V2 / 'audit_prompts.py': '243ce28615b0c0bbfe7bf004f9ade8b0d03aa95718012b70e0a8ff24c75c0656',
    V1 / 'test_audit_prompts.py': '432b815818c8fef85aa20d52aa57bee05c2d89ce6102b269af0c0f9f0f07b4d5',
    V2 / 'test_audit_prompts.py': '06a8df778a8f43cb5bb00ace5398c40eba44be4c9a1dda9fd1b0ec942daa080e',
    V1 / 'README.zh.md': '796e38b7c950b21b4029b489a591479ca939dc35c3dc673ee502892eb8f5c5e0',
    V2 / 'README.zh.md': '101bd406a0116316f80aae68de2c9eb2b391db4c5036f295649ca09bbf8f8833',
    V1 / 'CPU_RECEIPT.json': '1f58e0f53d6f6c58cf0eb0ce7f2456549b2b14cb5b693451bb74eb6aed637c5d',
    V2 / 'CPU_RECEIPT.json': 'ce9424d7b9bcc9097c485142c08dbc922c55759b0c3c30053a3afb0627f50ab5',
    OP / 'actual_prompt_peer_v1/inspect_wire_v2.py': '865a7b966a127926d82bf07921d4116f3c273235b6e99b7f903c3b62d44348cd',
}


def load(path, name):
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == PINS[path]
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


a1 = load(V1 / 'audit_prompts.py', 'audit_prompts')
a2 = load(V2 / 'audit_prompts.py', 'peer_prompt_audit_v2')
# Only these fixture/payload functions are called; no owner tests or setUp run.
f = load(V1 / 'test_audit_prompts.py', 'peer_original_fixture')
for name, pin in a1.SOURCE.items():
    PINS[f.SOURCE / name] = pin
OBSERVED = {}


def snapshot():
    rows = []
    for path, pin in sorted(PINS.items()):
        info = path.stat(); raw = path.read_bytes()
        assert hashlib.sha256(raw).hexdigest() == pin
        rows.append({'path': str(path), 'bytes': len(raw), 'sha256': pin,
                     'mtime_ns': info.st_mtime_ns})
    return rows


class RedGreen(unittest.TestCase):
    def setUp(self):
        blocker = mock.patch.object(socket, 'socket', side_effect=AssertionError('network_forbidden'))
        blocker.start(); self.addCleanup(blocker.stop)
        self.rules = a1.old_module()
        self.config = {'model': {'label': 'MOCK', 'model_id': 'MOCK-serving'}, 'policy': {'max_tokens': 32768},
                       'profiles': {'MOCK': {'temperature': 1.0, 'top_p': 1.0, 'top_k': None,
                       'reasoning_effort': 'max', 'chat_template_kwargs': {'thinking': True}}}}

    def inspect(self, module, payload):
        return module.inspect_payload(payload, {'scenario': 'restricted_search', 'sampling_seed_labels': [2200]},
                                      {}, self.config, self.rules)

    def test_01_business_schema_red_green_and_explicit_reasoning_stays_excluded(self):
        observations = []
        for field in ('analysis', 'reasoning', 'reasoning_content', 'thinking'):
            payload = f.payload()
            payload['tools'][0]['function']['parameters'] = {
                'type': 'object', 'properties': {field: {'type': 'string', 'description': 'oracle'}}}
            for version, module in [('v1', a1), ('v2', a2)]:
                result = self.inspect(module, payload)
                self.assertEqual(len(result['marker_hits']), 0 if version == 'v1' else 1)
                self.assertEqual(result['marker_free_in_examined_fields'], version == 'v1')
                self.assertEqual(result['parameter_or_structure_issues'], [])
                if version == 'v2':
                    self.assertEqual(result['marker_hits'][0]['origin'], 'source_tool_schema_position_bound')
                observations.append({'version': version, 'property_name': field, 'marker_count': len(result['marker_hits'])})
        payload = f.payload()
        payload['messages'].append({'role': 'assistant', 'content': 'ordinary history',
                                    **{name: 'oracle' for name in ('analysis', 'reasoning', 'reasoning_content', 'thinking')}})
        for version, module in [('v1', a1), ('v2', a2)]:
            result = self.inspect(module, payload)
            self.assertEqual(result['marker_hits'], [])
            selected_history = copy.deepcopy(payload)
            selected_history['messages'][-1]['tool_calls'] = [{'type': 'function', 'function': {
                'name': 'search', 'arguments': '{"analysis":"oracle"}'}}]
            control = self.inspect(module, selected_history)
            self.assertEqual(len(control['marker_hits']), 1)
            self.assertEqual(control['marker_hits'][0]['origin'], 'model_generated_history')
        OBSERVED['schema_business_fields'] = observations
        OBSERVED['explicit_assistant_fields_excluded_both_versions'] = True
        OBSERVED['selected_tool_argument_string_marker_retained_both_versions'] = True

    def test_02_unmapped_denominator_red_green_without_reading_unmapped(self):
        fs, refs, put = f.fixture()
        seal = a1.parse(fs[refs[2]['path']]); part = seal['file_parts'][0]
        rows = a1.parse(fs[part['path']])
        unknown = '/MOCK-run/dumps/unknown-job/NOT_READ.json'
        rows.append({'path': unknown, 'relative_path': 'dumps/unknown-job/NOT_READ.json',
                     'sha256': '0' * 64, 'bytes': 1})
        part_ref = put(part['path'], rows)
        seal.update(file_parts=[{**part_ref, 'file_count': len(rows), 'total_bytes': sum(row['bytes'] for row in rows)}],
                    file_count=len(rows), total_bytes=sum(row['bytes'] for row in rows))
        seal_ref = put(refs[2]['path'], seal)
        observations = []
        with tempfile.TemporaryDirectory(prefix='synthetic-red-green-', dir=HERE) as temporary:
            for version, module in [('v1', a1), ('v2', a2)]:
                reads = []
                def read(name):
                    reads.append(name)
                    return fs[name]
                result = module.audit(refs[0], refs[1], seal_ref, Path(temporary) / version, module.Reader(read))
                self.assertEqual((result['sealed_dump_files'], result['unmapped_dump_files'], result['payloads_reviewed']), (8, 1, 8))
                self.assertEqual(result['payloads_unreviewable'], 0)
                self.assertEqual(result['all_sealed_dump_files_payload_reviewable'], version == 'v1')
                self.assertFalse(result['all_planned_attempt_input_coverage'])
                self.assertNotIn(unknown, reads)
                self.assertFalse(any('/results/' in name or '/private/' in name or 'FORBIDDEN' in name for name in reads))
                if version == 'v1':
                    self.assertNotIn('total_sealed_dump_files', result)
                else:
                    self.assertEqual(result['total_sealed_dump_files'], 9)
                    self.assertEqual(result['total_sealed_dump_files'], result['sealed_dump_files'] + result['unmapped_dump_files'])
                observations.append({'version': version, 'mapped': 8, 'unmapped': 1, 'reviewed': 8,
                    'all_sealed_reviewable': result['all_sealed_dump_files_payload_reviewable'],
                    'total': result.get('total_sealed_dump_files'), 'unmapped_body_read': unknown in reads})
        OBSERVED['unmapped_denominator'] = observations


if __name__ == '__main__':
    label = sys.argv[1]
    assert label in ('310', '311')
    before = snapshot(); started = time.monotonic()
    with (HERE / ('CPU_' + label + '.log')).open('x') as log:
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(RedGreen))
    after = snapshot()
    passed = result.wasSuccessful() and before == after
    receipt = {'schema': 'prompt-audit-v2-narrow-red-green-cpu-v1', 'passed': passed,
               'python': sys.version, 'tests_run': result.testsRun, 'elapsed_seconds': time.monotonic() - started,
               'source_pins': before, 'source_sha_bytes_mtime_unchanged': before == after,
               'observations': OBSERVED, 'real_raw_response_quality_reads': 0, 'model_scorer_network_calls': 0,
               'owner_suite_run': False, 'actual_formal_or_remote_acceptance': False}
    with (HERE / ('CPU_' + label + '.json')).open('x') as handle:
        json.dump(receipt, handle, sort_keys=True, indent=2); handle.write('\n')
    print(json.dumps({'passed': passed, 'tests_run': result.testsRun, 'label': label}))
    sys.exit(0 if passed else 1)
