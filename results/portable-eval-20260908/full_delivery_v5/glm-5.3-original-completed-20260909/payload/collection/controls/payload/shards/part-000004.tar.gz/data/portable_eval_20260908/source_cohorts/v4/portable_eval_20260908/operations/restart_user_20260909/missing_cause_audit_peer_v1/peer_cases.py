#!/usr/bin/env python3
"""Eight independent synthetic checks; no actual run inputs or classifier oracle."""
import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent
CANDIDATE = HERE.parent / 'missing_cause_audit_candidate_v1'


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


a = module('audit', CANDIDATE / 'audit.py')
t = module('peer_candidate_fixture', CANDIDATE / 'test_audit.py')


def update_usage(f, usage):
    """Keep synthetic raw bytes and original usage ledger mutually consistent."""
    attempt = f[1][-1]['attempts'][-1]
    raw = f[2][attempt['request_id']]
    raw['response_json']['usage'] = copy.deepcopy(usage)
    raw['response_raw'] = json.dumps(raw['response_json'])
    attempt['usage'] = copy.deepcopy(usage)


class IndependentCases(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pure = t.pure()

    def test_01_length_nonempty_is_not_automatically_32768_cap(self):
        f = t.fixture(content='SYNTHETIC visible partial')
        f[2][f[1][-1]['attempts'][-1]['request_id']]['request_payload']['max_tokens'] = 65536
        result = t.run(f, self.pure)
        facts = result['call_observations'][-1]['response']
        self.assertEqual(result['mechanism'], 'forced_length_nonempty_text_rejected')
        self.assertTrue(facts['decoder_text_nonempty'])
        self.assertFalse(facts['reported_32768_length_exhaustion'])
        self.assertFalse(facts['reported_request_limit_reached'])

    def test_02_no_final_without_terminal_note_stays_unknown(self):
        f = t.fixture(final=False, cap=200)
        f[0]['messages'][-1] = {'role': 'user', 'content': 'SYNTHETIC unrelated context'}
        result = t.run(f, self.pure)
        self.assertEqual(result['mechanism'], 'unknown')
        self.assertFalse(result['final_request_delivered'])
        self.assertFalse(result['context_gate']['checked'])

    def test_03_refusal_reasoning_and_output_text_part_are_not_decoder_text(self):
        f = t.fixture(content=[{'type': 'output_text', 'text': 'PRIVATE-VISIBLE'}], finish='stop',
                      extra={'reasoning_content': 'PRIVATE-REASONING', 'refusal': 'PRIVATE-REFUSAL'})
        result = t.run(f, self.pure)
        facts = result['call_observations'][-1]['response']
        self.assertEqual(result['mechanism'], 'forced_response_empty_decoder_text')
        self.assertEqual(facts['content']['type'], 'list')
        self.assertFalse(facts['decoder_text_nonempty'])
        self.assertTrue(facts['reasoning_content']['nonblank'])
        self.assertTrue(facts['refusal']['nonblank'])
        self.assertNotIn(b'PRIVATE-', a.dump(result))

    def test_04_http_503_body_choices_is_not_a_delivered_model_retry(self):
        f = t.fixture(retry=True, finish='stop')
        attempt = f[1][-1]['attempts'][0]
        raw = f[2][attempt['request_id']]
        body = {'error': {'message': 'SYNTHETIC unavailable'}, 'choices': []}
        raw.update(http_status=503, response_json=body, response_raw=json.dumps(body),
                   error={'type': 'HTTPError', 'message': 'SYNTHETIC 503'})
        attempt['http_status'] = 503
        result = t.run(f, self.pure)
        self.assertEqual(result['mechanism'], 'forced_response_empty_decoder_text')
        self.assertEqual(result['final_request_id'], f[1][-1]['attempts'][-1]['request_id'])

    def test_05_boolean_attempt_index_is_not_integer_identity(self):
        f = t.fixture()
        attempt = f[1][-1]['attempts'][-1]
        attempt['attempt'] = True
        f[2][attempt['request_id']]['attempt'] = True
        with self.assertRaises(ValueError):
            t.run(f, self.pure)

    def test_06_null_primary_completion_uses_frozen_client_output_alias(self):
        f = t.fixture()
        update_usage(f, {'prompt_tokens': 10, 'completion_tokens': None, 'output_tokens': 32768})
        result = t.run(f, self.pure)
        facts = result['call_observations'][-1]['response']
        self.assertEqual(facts['completion_tokens'], 32768)
        self.assertTrue(facts['reported_32768_length_exhaustion'])

    def test_07_usage_extension_text_is_not_exported(self):
        f = t.fixture()
        usage = copy.deepcopy(f[1][-1]['attempts'][-1]['usage'])
        usage['debug_reasoning'] = 'PRIVATE-USAGE-EXTENSION'
        update_usage(f, usage)
        result = t.run(f, self.pure)
        self.assertNotIn(b'PRIVATE-USAGE-EXTENSION', a.dump(result))

    def test_08_boolean_snapshot_agent_owner_is_not_agent_zero(self):
        f = t.fixture()
        snapshot = f[0]
        original = copy.deepcopy(snapshot)
        original['strategy'] = 'naive'
        event = {'schema_version': 'expgym.terminal-evidence.v1', 'event': 'loop_terminal',
                 'owner': {'runner': 'poolact', 'seed': 101, 'agent_id': False, 'strategy': 'naive'},
                 'completion_marker': False, 'score_acceptance_authority': False,
                 'payload': {'capture_point': 'raw_return_before_caller_and_scorer_mutations',
                             'loop_result': snapshot}}
        with self.assertRaises(ValueError):
            a.snapshot_for([({'path': '/synthetic/terminal.json', 'sha256': '0' * 64}, event)],
                           101, True, 0, original)


if __name__ == '__main__':
    before = {name: hashlib.sha256((CANDIDATE / name).read_bytes()).hexdigest()
              for name in ('audit.py', 'test_audit.py')}
    started = time.monotonic()
    log = io.StringIO()
    with mock.patch.object(socket, 'socket', side_effect=AssertionError('network forbidden')), \
         mock.patch.object(subprocess, 'Popen', side_effect=AssertionError('subprocess forbidden')), \
         mock.patch.object(os, 'system', side_effect=AssertionError('subprocess forbidden')):
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(
            unittest.defaultTestLoader.loadTestsFromTestCase(IndependentCases))
    after = {name: hashlib.sha256((CANDIDATE / name).read_bytes()).hexdigest() for name in before}
    print(log.getvalue())
    print(json.dumps({'schema_version': 'missing-cause-peer-cpu-v1', 'tests_run': result.testsRun,
                      'failures': len(result.failures), 'errors': len(result.errors),
                      'successful': result.wasSuccessful(), 'elapsed_seconds': time.monotonic() - started,
                      'python': sys.version, 'source_sha256_before': before, 'source_sha256_after': after,
                      'source_unchanged_during_cpu': before == after, 'actual_inputs_read': False,
                      'model_calls': 0, 'scorer_calls': 0, 'loop_executions': 0}, sort_keys=True))
    raise SystemExit(0 if result.wasSuccessful() and before == after else 1)
