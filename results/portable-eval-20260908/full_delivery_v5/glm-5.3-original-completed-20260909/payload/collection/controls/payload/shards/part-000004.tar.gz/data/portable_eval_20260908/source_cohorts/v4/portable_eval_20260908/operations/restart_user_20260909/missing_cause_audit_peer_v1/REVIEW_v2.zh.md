# 独立 peer 收口：原 8 项合成核验全部通过

本次仅依指示复跑原 `peer_cases.py` 中的 8 个用例，没有增加或改变测试 oracle。冻结核心 SHA 为 `ca1e4275cc6623f5d76017f56a24bb148fdabd3908680e1fb1999653b62d8fe9`；执行前后核心与 fixture SHA 一致。

结果：Python 3.10.12，8 PASS，0 FAIL，0 ERROR，进程 exit 0。详见 `cpu_v2/receipt.json` 与 `cpu_v2/CPU_LOG.txt`；工具记录 `4d792c`。

首次失败的 `CPU_RECEIPT_v1.json`、`REVIEW_v1.zh.md` 原样保留。先前两个可复现身份缺口（bool attempt 被视为整数 1、bool owner agent ID 被视为整数 0）现在由同一负例确认拒绝。

在本次独立复核的机制与身份边界内，没有剩余已知阻断。该结论不代表运行过 main 的新输出 schema 验证，也不代表新的实际数据审计、全功能证明或实际执行授权。候选作者的其他验证应保留为独立来源，不能合并冒称本 peer 执行。

没有读取任何 K3/GLM actual raw、export、答案、恢复 payload、任务数据或密钥；没有执行模型、网络、Slurm、scorer、完整 loop；没有修改候选或已有冻结文件。仍须在真实 run/analysis 闭合及明确授权后进行 actual，再对实际产物作新的独立 post-output 审计。
