"""Only two pinned-runtime synthetic suites; never accepts an actual run input."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

import audit

HERE = Path(__file__).resolve().parent
INTERPRETERS = ['/lustrefs/users/chufan.shi/codex_space_tn/LLM_ExpGym/.venv/bin/python',
                '/lustrefs/users/chufan.shi/codex_space_tn/kimi_k3_eval/data_runtime/.venv-hpo/bin/python']


def binding(path):
    blob = path.read_bytes()
    return {'sha256': hashlib.sha256(blob).hexdigest(), 'bytes': len(blob), 'mtime_ns': path.stat().st_mtime_ns}


def write(path, value):
    blob = value if type(value) is bytes else (json.dumps(value, indent=2, sort_keys=True) + '\n').encode('utf-8')
    with path.open('xb') as handle:
        handle.write(blob)
    return {'path': str(path), 'sha256': hashlib.sha256(blob).hexdigest(), 'bytes': len(blob)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', required=True)
    args = parser.parse_args()
    out = Path(args.output_dir)
    if not out.is_absolute() or out.resolve() != out or HERE / 'validation' not in out.parents:
        raise ValueError('fresh_candidate_validation_descendant_required')
    out.mkdir(parents=True, exist_ok=False)
    paths = [audit.SOURCE / name for name in audit.PINS] + [HERE.parent / name for name in audit.DEPENDENCIES]
    paths += [HERE / name for name in ('audit.py', 'output.schema.json', 'test_audit.py', 'test_closed_fixture.py', 'README.zh.md', 'validate_cpu.py')]
    before = {str(p): binding(p) for p in paths}
    runs = []
    for index, executable in enumerate(INTERPRETERS):
        began = time.monotonic()
        child = subprocess.run([executable, '-B', '-m', 'unittest', 'test_audit', 'test_closed_fixture', '-v'],
            cwd=str(HERE), stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
        matched = re.search(rb'Ran (\d+) tests in [0-9.]+s\s+OK\s*\Z', child.stderr)
        count = int(matched.group(1)) if matched else None
        runs.append({'interpreter': executable, 'exit_code': child.returncode, 'test_count': count,
            'passed': child.returncode == 0 and count == 26, 'wall_seconds': time.monotonic() - began,
            'stdout': write(out / ('runtime_%d.stdout.log' % index), child.stdout),
            'stderr': write(out / ('runtime_%d.stderr.log' % index), child.stderr)})
    after = {str(p): binding(p) for p in paths}
    receipt = {'schema_version': 'missing-cause-synthetic-validation-v1', 'passed': before == after and all(r['passed'] for r in runs),
        'runs': runs, 'input_bindings': before, 'all_input_bindings_unchanged': before == after,
        'actual_experiment_inputs_read': 0, 'actual_model_calls': 0, 'actual_scorer_calls': 0, 'actual_run_validated': False}
    ref = write(out / 'receipt.json', receipt)
    print(json.dumps({'passed': receipt['passed'], 'receipt': ref}))
    return 0 if receipt['passed'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
