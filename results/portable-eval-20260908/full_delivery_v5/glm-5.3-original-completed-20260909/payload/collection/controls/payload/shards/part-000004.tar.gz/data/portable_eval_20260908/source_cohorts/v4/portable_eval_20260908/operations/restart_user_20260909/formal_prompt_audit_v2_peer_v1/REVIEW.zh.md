# Prompt audit v2：两项独立红绿复核

通过，仅限 ROOT 指定的两项修订。没有重新运行原 11/13 项套件，也没有进行真实正式审计或结果后的独立复查。v1/v2 及冻结源码均未修改；18 份候选、规则和源文件的 SHA／bytes／mtime 前后相同。

生产 diff 仅两处语义修改：删除通用 `strings()` 的四键跳过；增加包含 unmapped 的总分母并收紧全称可审标志。静态 diff 输出见工具 chunk `dbee8c`，实际命令包含后续只读代码显示，整体退出码 0 不冒充 diff 本身没有差异。

1. v2 `audit_prompts.py:114` 的 value 遍历不再丢弃 `analysis/reasoning/reasoning_content/thinking` 同名业务属性。将 `oracle` 放入每个属性的 `description`：v1 均为 0 hit、marker-free；v2 均为 1 hit，归属 `source_tool_schema_position_bound`，无结构问题。v2 `:163` 仍只选择 assistant `content/tool_calls`；显式顶层四字段中的 marker 在两版本均不扫描，而被选择的 tool argument 字符串中的 marker 仍归属模型历史。
2. 同一纯合成 fixture 加入 1 个无法映射的 dump metadata：两版本均保留 mapped=8、unmapped=1、reviewed=8。v1 原全称可审标志错误为 true，且没有 total 字段；v2 `:342` 的 total=9，`:349` 的全称可审标志为 false。两版本更强的 planned coverage 均为 false；reader 记录证明未跟随 unmapped、results、private 或禁止原件路径。

Python 3.10：2/2 PASS，测试日志 10.055 秒，实际 session 12488，exit 0。Python 3.11：2/2 PASS，测试日志 9.961 秒，实际 session 94594，exit 0。日志、观察值、逐源 pin 与执行绑定见本目录 CPU 文件和 `EXECUTION_RECEIPT.json`。red 表示测试明确重现 v1 的缺陷行为；整项测试退出 0 表示既重现 red、也验证 green，不是声称 v1 没有缺陷。

输入仅内存合成 705/783/1881 计划形状和 8 个短占位请求，加一个不提供正文的 unmapped ref；复用原 owner 的 fixture/payload 函数，未调用其套件或 setUp。fixture 只读取固定九份冻结源码以匹配 source pin，旧规则模块只提供 marker 正则；未读取真实 raw、响应、质量、gold 或 key，未调用模型、scorer、网络或 Git。测试临时输出仅在本 peer 目录下，由创建者清理；没有改动运行输出。

局限：验证的是两处逻辑修复及 assistant 选择边界，不证明真实 705 项已闭合、所有物理 HTTP 均已 dump、prompt 不存在任何泄漏或论文效果成立。Pool 缺失 selector 的间接绑定、有限词法 marker 和正式封存后实际审阅的既定边界不变。
