# Exporter v2 reasoning 兼容：独立窄 peer

结论：未发现本次限定范围的阻断项。生产源码除 `usage()` 外字节完全相同，生成的 unified diff 与作者冻结 patch 一致。去掉唯一新增测试类后，新旧完整测试模块 AST 相同，原14项测试及 source-E2E 方法均保留；本次未运行这些完整测试或读取它们的真实/fake 原件。

只对固定 SHA 的 `require`、`usage` 两个函数抽取 AST 后执行，没有 import exporter/AN2、加载目录依赖或运行 export。4组独立 synthetic 反例在 Python3.10.12 / 3.11.15 各运行一次，均4/4通过、实际 exit0；chunk 分别 `6a5572` / `18c4cc`。7份指定候选/旧源码、说明及作者收据 bytes/SHA/mtime 前后相同。

## 覆盖与红绿差异

- flat-only：v1 unknown，v2正确读取5；input/output不变。合法0仍是已知，另一位置bool不成为候选；加入无usage error后保留已知部分5与unknown分母，完整总量仍null。
- 两处合法但冲突：v1悄取nested2；v2即使completion未知也拒绝，不偏好、不相加。
- 同一attempt reasoning6 > completion5：v1可被另一个unknown或另一个completion50掩盖；v2均拒绝。上限不只检查最终合计。
- 原nested输入的新旧返回完全相同；两处合法相等只计一次。单合法候选可以和另一处非法值共存：flat=-1/nested=2取2；两处均非法（bool/float）保持unknown。

静态 `exporter.py:188–195` 与 README 契约一致：合法指精确非负int，单合法值采用；双合法异值fail，双合法同值一次；无合法值unknown；同次合法completion才提供上限。这里接受“一个合法、另一个非法”的行为是本候选明确规则，不把它误报为所有异常字段都拒绝。原aggregate上限与输入/输出计数仍保留，reasoning不加到inclusive output。

## 限定

这不是完整导出集成测试、实际全量计费验收或主科学结论的fresh审阅；未读取任何真实raw、quality、gold、模型、数据库或key，无export/评分/Slurm/Git/网络动作，也没有修改任何候选/原文件。既有35题静态gold暴露记录原样保留，fully_blinded=false，本 agent不作为fresh主科学reviewer。此前真实单例诊断与本次纯合成peer分别留存，不能由本次PASS认证全量reasoning总数。新真实导出由ROOT另行决定。

完整命令、实际退出、日志与7份保护原件pins见 [CPU_RECEIPT.json](CPU_RECEIPT.json)；独立脚本 [peer_usage.py](peer_usage.py)。本目录完成后停写。
