#!/usr/bin/env python3
"""Independent one-cohort usage accounting; no exporter/analyzer imports."""
import argparse
from collections import Counter, defaultdict
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import stat

HERE = Path(__file__).resolve().parent
OP = HERE.parent
RUN_ID = 'restart-20260909-v5-glm-5.3-formal'
RUN = OP.parent.parent / 'formal_runs' / RUN_ID
EXPORT = OP / 'actual_formal_export_glm_completed_v2'
CONTROL = {
    'plan': (OP / 'compiled_restart-20260909-v5-glm-5.3-formal/plan.json', '8b9ed4a00674689f62aaca73cc35c84f1d88439fe5f75b636164bfe4d70e574b'),
    'execution': (RUN / 'execution.json', '16d4569396aa2dd95393013084b3d3b70eaff06e1a8d95d39dc35a36652344b2'),
    'seal': (OP / 'sealed_restart_runs_v1/glm-5.3-formal-completed-20260909/inventory.json', 'da5b89e1041e396c04673b6f363dd01a3f6d64b61bfd9fe6d60f0a6617957f22'),
    'index': (EXPORT / 'EXPORT_INDEX.json', 'e32cab1af07054e76503aab79c66b76bcc216d2021cf0f46cd638340023bbca7'),
}
FIELDS = ('input_tokens', 'output_tokens', 'reasoning_tokens')


class ReviewFailure(ValueError):
    pass


def require(value, code):
    if not value:
        raise ReviewFailure(code)


def encoded(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False) + '\n').encode()


def strict_json(body):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, 'duplicate_json_key'); result[key] = value
        return result
    def reject(_value):
        raise ValueError('nonfinite_json')
    return json.loads(body, object_pairs_hook=pairs, parse_constant=reject)


def good_count(value):
    return type(value) is int and value >= 0


def decode_usage(usage):
    """Three independent optional integer counts; reasoning is part of output."""
    usage = usage if type(usage) is dict else {}
    prompt, completion = usage.get('prompt_tokens'), usage.get('completion_tokens')
    detail = usage.get('completion_tokens_details')
    flat = usage.get('reasoning_tokens')
    nested = detail.get('reasoning_tokens') if type(detail) is dict else None
    has_flat, has_nested = good_count(flat), good_count(nested)
    require(not (has_flat and has_nested and flat != nested), 'conflicting_reasoning_fields')
    reasoning = flat if has_flat else nested if has_nested else None
    output = completion if good_count(completion) else None
    require(reasoning is None or output is None or reasoning <= output, 'attempt_reasoning_exceeds_output')
    values = dict(zip(FIELDS, (prompt if good_count(prompt) else None, output, reasoning)))
    source = 'flat_and_nested_equal' if has_flat and has_nested else 'flat_only_valid' if has_flat else 'nested_only_valid' if has_nested else 'unknown'
    return values, source


def empty_usage():
    return {field: {'known_sum': 0, 'unknown_attempts': 0, 'attempts': 0} for field in FIELDS}


def add_usage(bucket, values):
    for field in FIELDS:
        bucket[field]['attempts'] += 1
        if values[field] is None:
            bucket[field]['unknown_attempts'] += 1
        else:
            require(good_count(values[field]), 'invalid_independent_count')
            bucket[field]['known_sum'] += values[field]


def finish_usage(bucket):
    finished = {field: {**bucket[field], 'complete_total': None if bucket[field]['unknown_attempts'] else bucket[field]['known_sum']} for field in FIELDS}
    r, c = finished['reasoning_tokens']['complete_total'], finished['output_tokens']['complete_total']
    require(r is None or c is None or r <= c, 'complete_reasoning_exceeds_output')
    return finished


def record_endpoints(counts, started):
    return {field: counts[field]['complete_total'] if started else None for field in FIELDS}


def validate_started_scope(started, ids, sources):
    require(started or (ids == [] and sources == {}), 'not_started_has_raw')


def observed_endpoints(record):
    return dict(input_tokens=record['telemetry']['input_tokens'], output_tokens=record['telemetry']['output_tokens'],
                reasoning_tokens=record['reasoning_tokens'])


def validate_identity(raw, source, job, row, run_id, model_id, max_attempt):
    """Only identity metadata and request seed/model; never messages/content."""
    require(raw.get('schema_version') == 'expgym.api_attempt.v1', 'raw_schema')
    rid, cid, gid = (raw.get(key) for key in ('request_id', 'client_id', 'generation_id'))
    require(all(type(value) is str and re.fullmatch('[0-9a-f]{32}', value) for value in (rid, cid, gid)), 'raw_identifiers')
    require(source.name == rid + '.json' and source.parent == Path(job['dump_dir']), 'raw_path_identity')
    require(raw.get('run_id') == run_id and raw.get('state') in ('success', 'error', 'malformed_response'), 'closed_raw_run_state')
    attempt = raw.get('attempt')
    require(type(attempt) is int and 1 <= attempt <= max_attempt, 'attempt_number')
    request, context = raw.get('request_payload'), raw.get('context')
    require(type(request) is dict and type(context) is dict and context.get('runner') == row['system'], 'request_owner_container')
    seed = request.get('seed')
    require(type(seed) is int and seed in row['sampling_seed_labels'] and request.get('model') == model_id, 'request_seed_model')
    owner = context.get('job') if row['system'] == 'expgym' else context
    require(type(owner) is dict and owner.get('scenario') == row['scenario'] and owner.get('cost_regime') == row['regime'], 'owner_scenario_regime')
    require(type(owner.get('seed')) is int and owner['seed'] == seed, 'context_seed')
    for key in ('question_index', 'tuning_task'):
        require(key not in row['selector'] or owner.get(key) == row['selector'][key], 'context_selector')
    if row['system'] == 'poolact':
        agent = owner.get('agent_id')
        require(type(agent) is int and 0 <= agent < len(row['sampling_seed_labels']) and row['sampling_seed_labels'][agent] == seed
                and owner.get('strategy') == row['strategy'], 'pool_agent_owner')
    elif row['scenario'] == 'evidence_audit':
        require(owner.get('rep') == row['order'] and owner.get('hypothesis_order') == row['hypothesis_order'], 'audit_order_owner')
    return rid, cid, gid, attempt, seed


class Inputs:
    def __init__(self):
        self.refs, self.stamps, self.total = {}, {}, 0

    @staticmethod
    def stamp(info):
        return info.st_dev, info.st_ino, info.st_mode, info.st_size, info.st_mtime_ns, info.st_ctime_ns

    def read(self, file, digest, size=None):
        file = Path(file)
        require(file.is_absolute() and '..' not in file.parts and file.resolve() == file, 'noncanonical_input')
        require(not any(part.lower() in ('private', 'secrets') for part in file.parts), 'private_path_forbidden')
        require(str(file) not in self.refs, 'input_read_twice')
        before = file.lstat()
        require(stat.S_ISREG(before.st_mode) and before.st_size <= 128 * 1024**2, 'input_type_limit')
        with os.fdopen(os.open(file, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK), 'rb') as handle:
            require(self.stamp(before) == self.stamp(os.fstat(handle.fileno())), 'input_changed_before')
            body = handle.read(128 * 1024**2 + 1)
            require(self.stamp(before) == self.stamp(os.fstat(handle.fileno())) == self.stamp(file.lstat()), 'input_changed_during')
        require(len(body) == before.st_size and (size is None or len(body) == size) and hashlib.sha256(body).hexdigest() == digest, 'input_sha_size')
        self.total += len(body); require(self.total <= 8 * 1024**3, 'total_input_limit')
        self.refs[str(file)] = dict(path=str(file), sha256=digest, bytes=len(body))
        self.stamps[str(file)] = self.stamp(before)
        return body

    def obj(self, file, digest, size=None):
        return strict_json(self.read(file, digest, size))

    def final_stable(self):
        require(all(self.stamp(Path(name).lstat()) == stamp for name, stamp in self.stamps.items()), 'input_changed_after')


def write_json(file, value):
    body = encoded(value)
    with file.open('xb') as handle:
        handle.write(body); handle.flush(); os.fsync(handle.fileno())
    return dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def actual(output):
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    require(output == HERE / 'actual_v1' and not output.exists() and not output.is_symlink(), 'fresh_fixed_output')
    reader = Inputs()
    docs = {name: reader.obj(*ref) for name, ref in CONTROL.items()}
    plan, execution, seal, index = (docs[name] for name in ('plan', 'execution', 'seal', 'index'))
    require(plan['config']['run_id'] == RUN_ID and Path(plan['config']['output_root']) == RUN and len(plan['jobs']) == 705, 'plan_scope')
    require(execution['run_id'] == RUN_ID and type(execution['local_workers']) is int and execution['local_workers'] == 0
            and execution['plan_ref']['sha256'] == CONTROL['plan'][1] and execution['plan_ref']['path'] == str(CONTROL['plan'][0]), 'execution_binding')
    require(seal['schema_version'] == 'restart-closed-run-inventory-v1' and seal['full_second_read_equal'] is True
            and seal['run_root'] == str(RUN) and seal['sealer_source_ref']['sha256'] == '1d30bf17c4cbe19fea21c2d65ab50e83db4aed9770ae6d1320c2fb3c34a424f2', 'sealed_scope')
    for name in ('plan', 'execution'):
        require(any(ref['path'] == str(CONTROL[name][0]) and ref['sha256'] == CONTROL[name][1] for ref in seal['control_refs']), 'sealed_controls')
    closure_ref = seal['closure_ref']; closure = reader.obj(closure_ref['path'], closure_ref['sha256'])
    require(closure['run_id'] == RUN_ID and type(closure['local_workers']) is int and closure['local_workers'] == 0
            and all(closure[name + '_ref']['path'] == str(CONTROL[name][0]) and closure[name + '_ref']['sha256'] == CONTROL[name][1] for name in ('plan', 'execution')), 'closure_binding')
    inventory = {}
    for part in seal['file_parts']:
        page = reader.obj(part['path'], part['sha256'], part['bytes'])
        require(len(page) == part['file_count'] and sum(row['bytes'] for row in page) == part['total_bytes'], 'seal_part_totals')
        for item in page:
            path = Path(item['path'])
            require(RUN in path.parents and '..' not in path.parts and path.relative_to(RUN).as_posix() == item['relative_path'] and str(path) not in inventory, 'seal_path')
            inventory[str(path)] = item
    require(len(inventory) == seal['file_count'] and sum(row['bytes'] for row in inventory.values()) == seal['total_bytes'], 'seal_totals')
    require(inventory[str(CONTROL['execution'][0])]['sha256'] == CONTROL['execution'][1], 'sealed_execution')
    selected = {}
    for name in ('manifest.json', 'records.json'):
        ref = index['files'][name]; selected[name] = reader.obj(EXPORT / name, ref['sha256'], ref['bytes'])
    manifest, bundle = selected['manifest.json'], selected['records.json']
    require(encoded(manifest) == encoded(plan['matrix']) and bundle['manifest_sha256'] == index['files']['manifest.json']['sha256']
            and bundle['schema_version'] == 'restart-analysis-records-v1', 'record_manifest_binding')
    rows = {row['logical_id']: row for row in manifest['logical_rows']}
    records = {rec['logical_id']: rec for rec in bundle['records']}
    require(len(rows) == len(manifest['logical_rows']) == len(records) == len(bundle['records']) == 783 and set(rows) == set(records), 'logical_scope')
    jobs = {job['invocation_id']: job for job in plan['jobs']}
    started, unstarted = set(execution['started_invocation_ids']), set(execution['unstarted_invocation_ids'])
    require(len(started) + len(unstarted) == 705 and not started & unstarted and started | unstarted == set(jobs), 'started_partition')
    reports = {rec['invocation_id']: rec for rec in execution['reports']}
    require(len(reports) == len(execution['reports']) and set(reports) == started, 'closed_reports')
    seed_owners = {}
    for lid, row in rows.items():
        for seed in row['sampling_seed_labels']:
            key = (row['invocation_id'], seed)
            require(type(seed) is int and key not in seed_owners, 'planned_seed_multiple_logical_owners')
            seed_owners[key] = lid
    require(len(seed_owners) == 1881, 'planned_owner_scope')
    declared, rid_owner, counts = {}, {}, {lid: empty_usage() for lid in rows}
    for lid, record in records.items():
        row, side = rows[lid], record['telemetry_sidecar']
        expected_state = 'not_started' if row['invocation_id'] in unstarted else 'terminal' if reports[row['invocation_id']]['decision'].get('continue') is True else 'infrastructure_error'
        require(record['state'] == expected_state and set(side) == {'attempt_usage', 'raw_request_ids', 'raw_source_sha256', 'audit_orders_not_duplicated'}
                and side['audit_orders_not_duplicated'] is True, 'record_state_sidecar')
        ids = side['raw_request_ids']; require(type(ids) is list and len(ids) == len(set(ids)), 'duplicate_declared_request')
        validate_started_scope(row['invocation_id'] in started, ids, side['raw_source_sha256'])
        require(len(side['raw_source_sha256']) == len(ids), 'declared_request_path_count')
        for rid in ids:
            require(rid not in rid_owner and type(rid) is str and re.fullmatch('[0-9a-f]{32}', rid), 'request_multiple_owners'); rid_owner[rid] = lid
        for name, digest in side['raw_source_sha256'].items():
            require(name not in declared and name in inventory and inventory[name]['sha256'] == digest, 'raw_source_seal_binding')
            require(Path(name).stem in ids and Path(name).parent == Path(jobs[row['invocation_id']]['dump_dir']), 'declared_path_job')
            declared[name] = lid
    sealed_raw = {name for name in inventory if RUN / 'dumps' in Path(name).parents}
    require(set(declared) == sealed_raw and len(sealed_raw) == len(rid_owner) == 18403, 'all_sealed_raw_exact_scope')
    output.mkdir(mode=0o700)
    all_counts, states, representations = empty_usage(), Counter(), Counter()
    by_state = defaultdict(empty_usage); by_record_state = defaultdict(empty_usage)
    clients, generations, actual_ids, attempts_digest, attempts_bytes = {}, {}, set(), hashlib.sha256(), 0
    with (output / 'attempts.jsonl').open('xb') as attempts_file:
        for number, name in enumerate(sorted(sealed_raw), 1):
            ref, lid = inventory[name], declared[name]; row = rows[lid]; job = jobs[row['invocation_id']]
            raw = reader.obj(name, ref['sha256'], ref['bytes'])
            rid, cid, gid, attempt, seed = validate_identity(raw, Path(name), job, row, RUN_ID, plan['config']['model']['model_id'], plan['config']['policy']['max_retries'] + 1)
            require(seed_owners[(row['invocation_id'], seed)] == lid, 'independent_seed_owner')
            require(rid not in actual_ids and rid_owner.get(rid) == lid, 'actual_request_owner'); actual_ids.add(rid)
            require(cid not in clients or clients[cid] == (lid, seed), 'client_cross_owner'); clients[cid] = (lid, seed)
            nums = generations.setdefault((cid, gid), set()); require(attempt not in nums, 'duplicate_generation_attempt'); nums.add(attempt)
            response = raw.get('response_json')
            usage = response.get('usage') if type(response) is dict else None
            values, representation = decode_usage(usage)
            for bucket in (all_counts, counts[lid], by_state[raw['state']], by_record_state[records[lid]['state']]): add_usage(bucket, values)
            states[raw['state']] += 1; representations[representation] += 1
            result = dict(logical_id=lid, request_id=rid, raw_ref={key:ref[key] for key in ('path','sha256','bytes')},
                          state=raw['state'], usage=values, reasoning_source=representation)
            body = encoded(result); attempts_file.write(body); attempts_digest.update(body); attempts_bytes += len(body)
            del raw, response, usage
            if number % 2000 == 0: print(json.dumps(dict(verified_raw_attempts=number)), flush=True)
        attempts_file.flush(); os.fsync(attempts_file.fileno())
    require(actual_ids == set(rid_owner) and all(sorted(v) == list(range(1, max(v)+1)) for v in generations.values()), 'request_or_generation_completeness')
    logical, endpoint_values = [], {field: [] for field in FIELDS}
    record_states = Counter()
    for lid in sorted(rows):
        row, record = rows[lid], records[lid]; result = finish_usage(counts[lid])
        require(encoded(result) == encoded(record['telemetry_sidecar']['attempt_usage']), 'logical_usage_sidecar_mismatch')
        endpoints = record_endpoints(result, row['invocation_id'] in started)
        require(encoded(endpoints) == encoded(observed_endpoints(record)), 'logical_token_endpoint_mismatch')
        for field in FIELDS: endpoint_values[field].append(endpoints[field])
        record_states[record['state']] += 1
        logical.append(dict(logical_id=lid, invocation_id=row['invocation_id'], system=row['system'], scenario=row['scenario'],
                            order=row['order'], state=record['state'], attempt_usage=result, record_token_endpoints=endpoints,
                            sidecar_and_record_match=True))
    subset = {field: dict(n_expected=len(values), n_known=sum(v is not None for v in values),
                         total=None if any(v is None for v in values) else sum(values),
                         known_subset_total_not_complete=sum(v for v in values if v is not None)) for field, values in endpoint_values.items()}
    reader.final_stable()
    summary = dict(schema='independent-sealed-usage-review-v1', passed=True, utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        run_id=RUN_ID, control_and_manifest_refs=[ref for name,ref in reader.refs.items() if name not in sealed_raw],
        input_ref_count=len(reader.refs), raw_refs_in='attempts.jsonl', program_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        logical_records=len(logical), logical_states=dict(record_states), raw_attempts=len(actual_ids), attempt_states=dict(states),
        all_raw_path_sha_size_and_request_owner_bijection=True, generation_attempt_gaps=0,
        all_record_usage_sidecars_and_token_endpoints_match=True, all_attempt_usage=finish_usage(all_counts),
        usage_by_attempt_state={key:finish_usage(value) for key,value in by_state.items()},
        usage_by_record_state={key:finish_usage(value) for key,value in by_record_state.items()},
        reasoning_representation_counts=dict(representations), an2_definition_complete_record_field_subset=subset,
        subset_is_independently_derived_not_read_from_an2_results=True, input_bytes_read_once=reader.total,
        input_stat_stable_at_end=True, reasoning_included_in_output_not_added=True,
        raw_container_json_deserialized=True, fields_semantically_inspected='identity/state plus numeric usage only',
        response_content_or_reasoning_body_inspected=False, model_scorer_backend_calls=0,
        exporter_or_an2_functions_called=False, real_billing_or_gpu_cost_verified=False,
        physical_http_completeness_beyond_sealed_dump_set_verified=False, retries=0)
    outputs = {'attempts.jsonl': dict(bytes=attempts_bytes, sha256=attempts_digest.hexdigest()),
               'logical_usage.json': write_json(output/'logical_usage.json', logical),
               'SUMMARY.json': write_json(output/'SUMMARY.json', summary)}
    write_json(output/'INDEX.json', dict(schema='independent-sealed-usage-review-index-v1', files=outputs))
    print(json.dumps(dict(passed=True, raw_attempts=len(actual_ids), logical_records=len(logical))), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--actual-output', required=True, type=Path)
    args = parser.parse_args()
    try:
        actual(args.actual_output)
    except Exception as error:
        code = str(error) if isinstance(error, ReviewFailure) else 'unexpected_reader_or_json_failure'
        print(json.dumps(dict(passed=False, rule='independent_usage_review_failed_no_retry', code=code)), flush=True)
        raise SystemExit(1)
