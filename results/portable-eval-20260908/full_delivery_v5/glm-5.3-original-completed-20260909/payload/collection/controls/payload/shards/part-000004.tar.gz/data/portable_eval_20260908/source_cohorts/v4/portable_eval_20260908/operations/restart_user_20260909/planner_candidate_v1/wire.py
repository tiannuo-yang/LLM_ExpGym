"""Narrow source-CLI wire hook; authority and credentials come from its caller.

The original client owns response parsing, retries, answers and complete raw
dumps. This module records metadata only and never scores a response. Compatible
with the existing Python 3.7 task runtime; no frozen development matrix imports.
"""
import copy
from datetime import datetime, timezone
import hashlib
import importlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import runpy
import sys
import threading
import time
import urllib.error
import urllib.request
import uuid


PRIMITIVE_PATH = Path("/lustrefs/users/chufan.shi/codex_space_tn/portable_eval_20260908/design/formal_executor_real_candidate/phase3b_real_delegate_candidate_v2/urllib_delegate.py")
PRIMITIVE_SHA256 = "b733a6d9b04b9e9a8fa8191dcf3d306cb5b4b7c5d02d09fbf290fec09cc1e492"
_PRIMITIVE_LOCK = threading.Lock()
_SOURCE_LOCK = threading.Lock()


class WireContractError(RuntimeError):
    pass


class MetadataWriteError(RuntimeError):
    pass


def _encoded(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def _strict(body):
    def pairs(items):
        value = {}
        for key, item in items:
            if key in value:
                raise WireContractError("duplicate_payload_key")
            value[key] = item
        return value
    def constant(unused):
        raise WireContractError("nonfinite_payload_value")
    return json.loads(body.decode("utf-8"), object_pairs_hook=pairs, parse_constant=constant)


def _primitive():
    if hashlib.sha256(PRIMITIVE_PATH.read_bytes()).hexdigest() != PRIMITIVE_SHA256:
        raise WireContractError("urllib_primitive_source_changed")
    name = "restart_user_20260909_frozen_urllib_primitive"
    with _PRIMITIVE_LOCK:
        if name not in sys.modules:
            spec = importlib.util.spec_from_file_location(name, str(PRIMITIVE_PATH))
            module = importlib.util.module_from_spec(spec)
            sys.modules[name] = module
            try:
                spec.loader.exec_module(module)
            except BaseException:
                sys.modules.pop(name, None)
                raise
        module = sys.modules[name]
        if Path(module.__file__).resolve() != PRIMITIVE_PATH.resolve():
            raise WireContractError("urllib_primitive_origin_changed")
        return module


def _number(value, positive=False):
    return (type(value) in (int, float) and math.isfinite(value)
            and (value > 0 if positive else value >= 0))


def _endpoint(value):
    if not isinstance(value, str):
        raise WireContractError("explicit_endpoint_required")
    value = value.rstrip("/")
    return value if value.endswith("/chat/completions") else value + ("/chat/completions" if value.endswith("/v1") else "/v1/chat/completions")


def _directory(value):
    path = Path(value)
    if not path.is_absolute() or ".." in path.parts or path != path.resolve():
        raise WireContractError("absolute_nonalias_path_required")
    return path


class InvocationWire:
    """One invocation's shared client/physical-attempt ceiling and safe recorder."""
    def __init__(self, plan, job, authority, secret, opener_factory=None):
        self.job = copy.deepcopy(job)
        config = plan["config"]
        self.policy = copy.deepcopy(config["policy"])
        self.profile = copy.deepcopy(config["profiles"][job["model_id"]])
        self.run_id = config["run_id"]
        self.authority, self.opener_factory = authority, opener_factory
        if not callable(getattr(authority, "check", None)):
            raise WireContractError("explicit_authority_check_required")
        self.callback = getattr(authority, "record_wire", None)
        if not callable(self.callback):
            raise WireContractError("durable_metadata_callback_required")
        if not isinstance(secret, str) or not secret or len(secret) > 4096 or any(ord(c) < 33 or ord(c) > 126 for c in secret):
            raise WireContractError("invalid_memory_only_secret")
        self.owners = job["expected_model_terminals"]
        self.seeds = list(job["sampling_seed_labels"])
        if (type(self.owners) is not int or self.owners < 1 or len(self.seeds) != self.owners
                or any(type(seed) is not int or not 0 <= seed <= 2**31 - 1 for seed in self.seeds)
                or len(set(self.seeds)) != len(self.seeds)):
            raise WireContractError("exact_unique_owner_seed_scope_required")
        p = self.policy
        if (any(type(p.get(k)) is not int or p[k] < 0 for k in ("max_steps", "max_retries"))
                or type(p.get("max_tokens")) is not int or p["max_tokens"] < 1
                or not _number(p.get("request_timeout"), positive=True)):
            raise WireContractError("explicit_generation_and_timeout_policy_required")
        required = {"temperature", "top_p", "reasoning_effort", "chat_template_kwargs"}
        if (not required.issubset(self.profile) or set(self.profile) - required - {"top_k"}
                or not _number(self.profile["temperature"])
                or not _number(self.profile["top_p"], positive=True) or self.profile["top_p"] > 1
                or type(self.profile["chat_template_kwargs"]) is not dict
                or (self.profile["reasoning_effort"] is not None and
                    (not isinstance(self.profile["reasoning_effort"], str) or not self.profile["reasoning_effort"].strip()))):
            raise WireContractError("explicit_exact_generation_profile_required")
        top_k = self.profile.get("top_k")
        if top_k is not None and (type(top_k) is not int or (top_k != -1 and top_k < 1)):
            raise WireContractError("invalid_explicit_top_k")
        _encoded(self.profile)
        self.limit = self.owners * (p["max_steps"] + 1) * (p["max_retries"] + 1)
        self.used = self.terminal_count = 0
        self.clients = {}
        self.lock = threading.RLock()
        self.primitive = _primitive()
        self.scope = self.primitive.RequestScope(job["endpoint"], p["request_timeout"], "bearer", secret)

    def __reduce_ex__(self, protocol):
        raise TypeError("memory_only_wire_context")

    def emit(self, value):
        event = dict(value, schema_version="restart-source-wire-metadata-v1",
                     invocation_id=self.job["invocation_id"], model_id=self.job["model_id"],
                     run_id=self.run_id, primitive_sha256=PRIMITIVE_SHA256)
        try:
            _encoded(event)
            self.callback(copy.deepcopy(event))
        except Exception:
            # Recorder errors must not become transient client transport retries.
            raise MetadataWriteError("safe_metadata_not_persisted") from None

    def client(self, seed):
        with self.lock:
            if type(seed) is not int or seed not in self.seeds or seed in self.clients or len(self.clients) >= self.owners:
                raise WireContractError("client_owner_seed_scope_exhausted")
            guard = WireGuard(self, seed)
            self.clients[seed] = guard
            return guard

    def summary(self):
        return {"schema_version": "restart-source-wire-summary-v1", "invocation_id": self.job["invocation_id"],
                "clients_created": len(self.clients), "expected_model_terminals": self.owners,
                "attempts_reserved": self.used, "attempt_terminals_recorded": self.terminal_count,
                "physical_attempt_ceiling": self.limit, "provider_quiescence_proven": False,
                "provider_usage_or_cost_total": None, "raw_and_scoring_owned_by_original_source": True}


class WireGuard:
    def __init__(self, context, seed):
        self.context, self.seed = context, seed
        self.wire_client_id = uuid.uuid4().hex
        self.source_client_id = None

    def __reduce_ex__(self, protocol):
        raise TypeError("memory_only_wire_guard")

    def bind_source(self, source_client):
        identifier = getattr(source_client, "_dump_client_id", None)
        metadata = getattr(source_client, "dump_metadata", None)
        if (not isinstance(identifier, str) or re.fullmatch(r"[0-9a-f]{32}", identifier) is None
                or type(getattr(getattr(source_client, "config", None), "seed", None)) is not int
                or source_client.config.seed != self.seed
                or type(metadata) is not dict or metadata.get("client_id") != identifier
                or metadata.get("run_id") != self.context.run_id):
            raise WireContractError("original_client_dump_identity_missing_or_different")
        self.source_client_id = identifier
        self.context.emit(dict(self.identity(), kind="client_identity", observed_at_utc=datetime.now(timezone.utc).isoformat()))

    def identity(self):
        return {"wire_client_id": self.wire_client_id, "source_client_id": self.source_client_id,
                "seed": self.seed}

    def __call__(self, request, timeout):
        c = self.context
        if self.source_client_id is None:
            raise WireContractError("client_identity_not_bound")
        c.scope.validate(request, timeout)
        payload = _strict(request.data)
        expected = {"model": c.job["model_id"], "temperature": c.profile["temperature"],
                    "top_p": c.profile["top_p"], "max_tokens": c.policy["max_tokens"],
                    "parallel_tool_calls": False, "seed": self.seed}
        for key in ("top_k", "reasoning_effort"):
            if c.profile.get(key) is not None:
                expected[key] = c.profile[key]
        if c.profile["chat_template_kwargs"]:
            expected["chat_template_kwargs"] = c.profile["chat_template_kwargs"]
        if (type(payload) is not dict or set(payload) != set(expected) | {"messages", "tools", "tool_choice"}
                or any(payload.get(k) != v for k, v in expected.items())
                or any(not _number(payload.get(k)) for k in ("temperature", "top_p"))
                or type(payload.get("seed")) is not int or type(payload.get("max_tokens")) is not int
                or ("top_k" in expected and type(payload.get("top_k")) is not int)
                or _encoded(payload.get("chat_template_kwargs", {})) != _encoded(c.profile["chat_template_kwargs"])
                or payload.get("parallel_tool_calls") is not False
                or payload.get("tool_choice") not in ("auto", "none")
                or type(payload.get("tools")) is not list or not payload["tools"]
                or type(payload.get("messages")) is not list):
            raise WireContractError("wire_native_generation_contract_differs")
        c.authority.check(c.job["invocation_id"])
        with c.lock:
            if c.used >= c.limit:
                raise WireContractError("physical_attempt_ceiling_exhausted")
            c.used += 1
            sequence = c.used
        common = dict(self.identity(), attempt_sequence=sequence,
                      request_body_sha256=hashlib.sha256(request.data).hexdigest(), request_bytes=len(request.data))
        c.emit(dict(common, kind="attempt_start", started_at_utc=datetime.now(timezone.utc).isoformat(),
                    timeout_seconds=timeout, provider_usage_or_cost=None))
        began = time.monotonic()
        body, error, code, response = None, None, None, None
        try:
            opener = c.opener_factory() if c.opener_factory is not None else c.primitive._build_real_opener()
            response = opener.open(request, timeout=timeout)
            body = response.read()
            if type(body) is not bytes:
                raise TypeError("HTTP_response_not_bytes")
            return body
        except BaseException as exc:
            error = exc
            if isinstance(exc, urllib.error.HTTPError):
                code = exc.code
            raise
        finally:
            close_error = None
            if response is not None:
                try:
                    response.close()
                except BaseException as exc:
                    close_error = exc
            terminal_error = error if error is not None else close_error
            c.emit(dict(common, kind="attempt_terminal", finished_at_utc=datetime.now(timezone.utc).isoformat(),
                wall_time_seconds=time.monotonic() - began,
                state="bytes_returned" if terminal_error is None else "error",
                response_bytes_sha256=hashlib.sha256(body).hexdigest() if type(body) is bytes else None,
                response_bytes=len(body) if type(body) is bytes else None,
                http_status=code, error_type=type(terminal_error).__name__ if terminal_error is not None else None,
                close_error_type=type(close_error).__name__ if close_error is not None else None,
                response_body_owned_by_source_client=isinstance(error, urllib.error.HTTPError),
                provider_usage_or_cost=None))
            with c.lock:
                c.terminal_count += 1
            if error is None and close_error is not None:
                raise close_error


def _source_command(repo, job):
    command = job["command"]
    wanted = {"expgym": "run_paper_sweep.py", "poolact": "run_poolact.py"}.get(job["system"])
    if (wanted is None or type(command) is not list or len(command) < 6
            or any(not isinstance(x, str) or "\x00" in x for x in command)
            or command[1:3] != ["-u", "-B"] or Path(command[3]) != repo / "scripts" / wanted
            or command.count("--backend") != 1 or command[-1] == "--backend"
            or command[command.index("--backend") + 1] != "openai"
            or any(flag in command for flag in ("--resume", "--dry-run", "--api-key"))):
        raise WireContractError("exact_original_source_command_required")
    return command


def run_source(plan, job, authority, secret, opener_factory=None):
    """Run the bound original main with only constructor/key-loader wire hooks.

    No answer value is interpreted here. None from main means exit code zero;
    terminal artifacts, complete raw dumps and scores belong to the caller's
    source-aware validation. No credential is loaded from disk by this module.
    """
    if not _SOURCE_LOCK.acquire(False):
        raise WireContractError("one_original_source_invocation_per_process")
    original_init = original_argv = original_path = source_main = original_loader = None
    client_class = None
    prior_env = {k: os.environ.get(k) for k in ("EXPGYM_API_DUMP_DIR", "EXPGYM_RUN_ID")}
    try:
        context = InvocationWire(plan, job, authority, secret, opener_factory)
        repo = _directory(plan["config"]["repo_root"])
        dump = _directory(job["dump_dir"])
        command = _source_command(repo, job)
        original_argv, original_path = sys.argv, list(sys.path)
        sys.path.insert(0, str(repo))
        os.environ.update(EXPGYM_API_DUMP_DIR=str(dump), EXPGYM_RUN_ID=context.run_id)
        module = importlib.import_module("expgym.llm_clients")
        if Path(module.__file__).resolve() != repo / "expgym/llm_clients.py":
            raise WireContractError("original_client_source_origin_differs")
        client_class = module.OpenAICompatibleLLM
        original_init = client_class.__init__
        def initialize(client, *args, **kwargs):
            profile, policy = context.profile, context.policy
            wanted_kwargs = dict(profile, top_k=profile.get("top_k"), model=job["model_id"], api_key=secret,
                                 max_tokens=policy["max_tokens"], timeout=policy["request_timeout"],
                                 max_retries=policy["max_retries"])
            for name in ("retry_base_seconds", "retry_max_seconds"):
                if name in policy:
                    wanted_kwargs[name] = policy[name]
            if (args or any(kwargs.get(k) != v for k, v in wanted_kwargs.items())
                    or _endpoint(kwargs.get("base_url")) != job["endpoint"]
                    or any(kwargs.get(k) is not None for k in ("provider", "reasoning", "prompt_cache_key"))
                    or kwargs.get("extra_headers") or kwargs.get("nothink_prefix", False)):
                raise WireContractError("original_client_constructor_profile_differs")
            guard = context.client(kwargs.get("seed"))
            kwargs["transport"] = guard
            original_init(client, **kwargs)
            guard.bind_source(client)
        client_class.__init__ = initialize
        sys.argv = list(command[3:])
        scope = runpy.run_path(command[3], run_name="restart_user_registered_source")
        source_main = scope["main"]
        original_loader = source_main.__globals__["_load_api_key"]
        source_main.__globals__["_load_api_key"] = lambda *args, **kwargs: secret
        result = source_main()
        if result is not None and type(result) is not int:
            raise WireContractError("unexpected_source_main_return_type")
        return dict(context.summary(), source_exit_code=0 if result is None else result)
    finally:
        if source_main is not None and original_loader is not None:
            source_main.__globals__["_load_api_key"] = original_loader
        if client_class is not None and original_init is not None:
            client_class.__init__ = original_init
        if original_argv is not None:
            sys.argv = original_argv
        if original_path is not None:
            sys.path[:] = original_path
        for key, value in prior_env.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
        _SOURCE_LOCK.release()


def verify_source(plan, job):
    """Original CLI --resume, with every model construction/generation forbidden.

    The caller must already have closed the source run and checked expected
    artifacts. The caller also owns before/after byte and mtime comparisons:
    PoolAct's original resume rewrites summary.json even when bytes are equal.
    """
    if not _SOURCE_LOCK.acquire(False):
        raise WireContractError("one_original_source_invocation_per_process")
    original_init = original_generate = original_argv = original_path = None
    source_main = original_loader = client_class = None
    attempts = {"construction": 0, "generation": 0}
    prior_env = {k: os.environ.get(k) for k in ("EXPGYM_API_DUMP_DIR", "EXPGYM_RUN_ID")}
    try:
        repo = _directory(plan["config"]["repo_root"])
        command = _source_command(repo, job)
        original_argv, original_path = sys.argv, list(sys.path)
        sys.path.insert(0, str(repo))
        os.environ.update(EXPGYM_API_DUMP_DIR="", EXPGYM_RUN_ID=plan["config"]["run_id"])
        module = importlib.import_module("expgym.llm_clients")
        if Path(module.__file__).resolve() != repo / "expgym/llm_clients.py":
            raise WireContractError("original_client_source_origin_differs")
        client_class = module.OpenAICompatibleLLM
        original_init, original_generate = client_class.__init__, client_class.generate
        def forbidden_init(*args, **kwargs):
            attempts["construction"] += 1
            raise WireContractError("verified_resume_model_construction_forbidden")
        def forbidden_generate(*args, **kwargs):
            attempts["generation"] += 1
            raise WireContractError("verified_resume_model_generation_forbidden")
        client_class.__init__, client_class.generate = forbidden_init, forbidden_generate
        sys.argv = list(command[3:]) + ["--resume"]
        scope = runpy.run_path(command[3], run_name="restart_user_verified_resume")
        source_main = scope["main"]
        original_loader = source_main.__globals__["_load_api_key"]
        source_main.__globals__["_load_api_key"] = lambda *args, **kwargs: "RESTART_VERIFIED_RESUME_PUBLIC_PLACEHOLDER"
        result = source_main()
        if result is not None and type(result) is not int:
            raise WireContractError("unexpected_source_main_return_type")
        code = 0 if result is None else result
        return {"schema_version": "restart-source-verified-resume-v1", "invocation_id": job["invocation_id"],
                "source_exit_code": code, "passed": code == 0 and not any(attempts.values()),
                "forbidden_model_attempts": dict(attempts), "model_calls_forbidden": True,
                "independent_source_cli_resume": True, "artifact_bytes_verified_by_this_helper": False,
                "summary_mtime_comparison_owned_by_caller": True}
    finally:
        if source_main is not None and original_loader is not None:
            source_main.__globals__["_load_api_key"] = original_loader
        if client_class is not None and original_init is not None:
            client_class.__init__ = original_init
            client_class.generate = original_generate
        if original_argv is not None:
            sys.argv = original_argv
        if original_path is not None:
            sys.path[:] = original_path
        for key, value in prior_env.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
        _SOURCE_LOCK.release()
