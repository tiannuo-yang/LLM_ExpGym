# GLM 独立 metric/vote 核验结果

ROOT 授权的一次原 CLI 实际执行 exit 0：**13,560 项比较，0 mismatches，首个反例为空**。覆盖全部 783 logical / 705 terminal invocations、1,881 原 agent 端点、366 个完整 N4 pool、1,455 performance metric cells 和 39 个 Exp Audit 三顺序文档组。73 个 Search 问题、13 个 Audit 文档，不把 N4 或三 orders 当独立题样本。

原算法没有修改，未 import 原 scorer/backend 或调用模型/API。actual_v1 的 8 文件 / 7,030,669 B 全部 INDEX 核验通过，入口用到的 2,394 个显式原 refs / 746,729,979 B 又按原 path/bytes/SHA 稳定重读核验。没有丢弃失败/缺答或按方向筛样；没有第二次 actual。

## 仍应报告的边界与异常形态

- 58 项数值差异非零但在 1e-9 容差内；最大绝对差 1.1102230246251565e-16、最大相对差 1.9880737882822571e-16，属于浮点等价，而非隐藏 mismatches。
- 实际原端点无 final 共 59：Search 54（Exp 10、Pool 44），Audit 5（Exp 2、Pool 3），HPO 0。类别由本次逐端点原状态/投影复算得到，不是事先从总数猜测。Search/Audit 均按已有空预测政策处理，不能把这些样本删掉或改成 infra。
- Search 7 个 pool / 17 对 agent 出现 scorer-equivalent 答案被 vote-key 分裂；本次 merge 为 0。这是既有评分/投票规范化不完全相同的表现，复算忠实复现，不表示已修复或可直接归因某个主效应。
- 6 个 HPO agent 的 Gap 真正超过 100，范围 100.01772072491956–100.41349998628014；并非上述浮点微差。既有公式只下限 clip 到 0，不设 100 上限。仅核 persisted performance + 固定 oracle 的算术，未独立查 backend 证明 performance 本身。
- 个体 answer 及聚合 winner 从已封端点核算；本脚本不能独自证明模型 raw 协议中“真正 final”选取逻辑，也不涵盖成本/reasoning 提取或主效应/置信区间。0 mismatches 不等于整个实验系统没有其他逻辑漏洞，更不等于双模型最终科学验收。

## 两模型相同 Tight whois 主效应：逐题差异抵消

按 ROOT 附加授权，只读两模型的冻结 v2 export、原 seal 与已独立 metric 产物，逐题核 39 个 whois 的 Tight PoolAct/naive MV 端点。没有新评分或模型调用，没有写答案/推理原文。

| 模型 | PoolAct MV F1 均值 | naive MV F1 均值 | 平均配对差 |
| --- | ---: | ---: | ---: |
| Kimi K3 | 0.304323780794369 | 0.21287078934137757 | 0.09145299145299145 |
| GLM-5.3 | 0.30005027652086474 | 0.2085972850678733 | 0.09145299145299145 |

并非相同逐题向量：39 题中 11 题的配对增益不同，28 题相同；11 个变化中 6 正、5 负，总变化恰为 0。GLM 相对 K3 的 PoolAct 和 naive 原分数总和都少 0.16666666666666663，因此两差值均值相同。PoolAct 逐题 F1 有 10 题不同，naive 有 2 题不同。

390 组成对原文件（780 件，含原 pool 及 N4 agent）路径无一相同、文件 SHA 无一相同。各模型 id/selector/seeds 与本模型 manifest 一致；原 agent answer hash、独立 winner、原聚合分数、独立逐题分数及 v2 导出分数均一致。相同聚合答案 SHA 在 PoolAct 为 15/39、naive 为 20/39，任务相同导致答案相同本身不构成复制证据。此有界检查未发现跨模型错绑或重复逐题结果造成相同均值；不能把它扩大为对生成全过程的绝对无复制证明。

完整 39 个数值配对及来源 refs 在 TIGHT_WHOIS_PAIR_CHECK.json（724,705 B）；专项的 803 个显式 refs / 133,661,498 B 前后核验通过，并再做了独立流式 pin 重核。专项只输出 ID、数值与 hash/路径，无答案/推理文本。原 actual_v1 不修改。

## 执行与后续角色

原 CLI session 94560，final chunk 15acbc，真实 exit 0；开始前观测 2026-09-09 19:12:39 UTC，结束后观测 19:13:00 UTC（观测区间，不冒称精确内部耗时）。shell 仅 ulimit -c 0 后直接 exec GO 的原 argv，没有新进程 wrapper。

专项 session 63813，final chunk 6f28be，exit 0；专项 refs 后核 session 36688 / 3851a5，exit 0。完整命令、GO、产物 pins 与核验记录见 OPERATOR_RECEIPT.json。

以上是独立 metric/vote 核验，不是报告完成后的最终非作者审查。将提供给 ROOT 及 `/root/missing_final_policy`（独占 dual_model_analysis_v1 的报告作者），不在该目录写入，也不以本人的报告检查替代最终独立 non-author post-report。到此冻结停止。
