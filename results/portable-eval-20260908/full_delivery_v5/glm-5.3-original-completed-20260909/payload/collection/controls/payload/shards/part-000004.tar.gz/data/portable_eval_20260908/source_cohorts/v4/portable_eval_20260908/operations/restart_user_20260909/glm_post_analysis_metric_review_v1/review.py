"""Independent closed-GLM-5.3 formula/vote audit; no original scorer/backend imports."""
import argparse
from collections import defaultdict, Counter
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import resource
import stat
import statistics
import sys

OP = Path(__file__).resolve().parent.parent
OUT = OP / 'actual_formal_export_glm_completed_v2'
BASE = OP.parents[1]
PLAN = OP / 'compiled_restart-20260909-v5-glm-5.3-formal/plan.json'
RUN = BASE / 'formal_runs/restart-20260909-v5-glm-5.3-formal'
PINS = {
    PLAN: '8b9ed4a00674689f62aaca73cc35c84f1d88439fe5f75b636164bfe4d70e574b',
    RUN / 'execution.json': '16d4569396aa2dd95393013084b3d3b70eaff06e1a8d95d39dc35a36652344b2',
    OUT / 'EXPORT_INDEX.json': 'e32cab1af07054e76503aab79c66b76bcc216d2021cf0f46cd638340023bbca7',
    OP / 'sealed_restart_runs_v1/glm-5.3-formal-completed-20260909/inventory.json': 'da5b89e1041e396c04673b6f363dd01a3f6d64b61bfd9fe6d60f0a6617957f22',
    OP / 'source_acceptance_v5_final.json': '0b1166cb5549ceb606bd98086809548cb0d83c3e94070e3570cc4783e1b1a744',
}
IDENTITY = ('model', 'system', 'scenario', 'item', 'regime', 'strategy', 'outerseed')


def require(ok, code):
    if not ok:
        raise ValueError(code)


def encode(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def checksum(blob):
    return hashlib.sha256(blob).hexdigest()


def strict(blob):
    def pairs(rows):
        obj = {}
        for k, v in rows:
            require(k not in obj, 'duplicate_outer_json_key')
            obj[k] = v
        return obj
    return json.loads(blob, object_pairs_hook=pairs,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite_outer_json')))


class Inputs:
    def __init__(self):
        self.refs = {}

    def read(self, p, expected, size=None):
        p = Path(p)
        require(p.is_absolute() and '..' not in p.parts and p.resolve() == p, 'noncanonical_input')
        require(not any(s in p.name.lower() for s in ('api_key', 'secret', 'password', 'credential')), 'private_input')
        signature = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
        before = p.lstat()
        require(stat.S_ISREG(before.st_mode) and before.st_size <= 128 * 1024**2, 'file_size_or_type')
        with os.fdopen(os.open(p, os.O_RDONLY | os.O_NOFOLLOW), 'rb') as f:
            require(signature(before) == signature(os.fstat(f.fileno())), 'opened_changed')
            blob = f.read(128 * 1024**2 + 1)
            require(signature(before) == signature(os.fstat(f.fileno())) == signature(p.lstat()), 'input_changed')
        require(checksum(blob) == expected and (size is None or len(blob) == size), 'input_pin_mismatch')
        row = dict(path=str(p), sha256=expected, bytes=len(blob))
        require(str(p) not in self.refs or self.refs[str(p)] == row, 'reread_changed')
        self.refs[str(p)] = row
        return blob

    def obj(self, ref):
        return strict(self.read(ref['path'], ref['sha256'], ref.get('bytes')))


def folded(s):
    return ' '.join(s.lower().split())


def fragment(s):
    m = re.match(r'^\s*\d+[.)]\s*', s)
    if m:
        s = s[m.end():]
    s = s.strip()
    while s and s[0] in '-*•':
        s = s[1:]
    while s and s[-1] in '-*•':
        s = s[:-1]
    return s.strip()


def search_answer(text, voting=False):
    if not text.strip():
        return frozenset()
    try:
        parsed = json.loads(text.strip())
    except (json.JSONDecodeError, TypeError):
        parsed = None
    if isinstance(parsed, list):
        parts = [str(x) for x in parsed if str(x).strip()]
        if voting:
            return frozenset(folded(fragment(p)) for p in parts if fragment(p))
        return frozenset(folded(p) for p in parts)
    candidates = [fragment(p) for p in re.split('[,;\n]', text)]
    return frozenset(folded(p) for p in candidates if p and (voting or len(p.split()) <= 5))


def search_f1(text, gold):
    prediction = search_answer(text)
    expected = frozenset(folded(s) for s in gold)
    return 2 * len(prediction & expected) / (len(prediction) + len(expected)) if prediction or expected else 1.0


def audit_object(text, voting=False):
    try:
        obj = json.loads(text)
    except (ValueError, RecursionError, OverflowError):
        if voting:
            return {}
        cleaned = text.strip().rstrip(';').strip()
        if cleaned.startswith('```'):
            # Exact acceptance boundary: remove exterior fence after semicolon removal.
            cleaned = cleaned.split('\n', 1)[-1].rsplit('```', 1)[0].strip()
        try:
            obj = json.loads(cleaned)
        except (ValueError, RecursionError, OverflowError):
            return {}
    return obj if isinstance(obj, dict) else {}


def audit_score(text, gold):
    obj = audit_object(text)
    label_count = evidence_count = 0
    for hid, (label, evidence) in gold.items():
        entry = obj.get(hid)
        if not isinstance(entry, dict):
            continue
        label_count += entry.get('label') == label
        try:
            submitted = {int(x) for x in entry.get('evidence_ids', [])}
        except Exception:
            submitted = set()
        evidence_count += submitted == evidence
    n = len(gold)
    return dict(label_acc=label_count / n if n else 0.0,
                evidence_acc=evidence_count / n if n else 0.0)


def label_key(value):
    text = str(value or '')
    letters = ''.join(c for c in text.lower() if 'a' <= c <= 'z')
    for name, spellings in [('Entailment', {'entailment', 'entailed'}),
                            ('Contradiction', {'contradiction', 'contradicted'}),
                            ('NotMentioned', {'notmentioned', 'neutral'})]:
        if letters in spellings:
            return name
    return text.strip()


def evidence_key(value):
    values = set()
    if isinstance(value, list):
        for item in value:
            try:
                values.add(int(item))
            except (ValueError, TypeError, OverflowError):
                values.add(str(item))
    return tuple(sorted(values, key=lambda x: (str(type(x)), str(x))))


def plurality(values, prefer_nonempty=False):
    # Independently count support and explicitly rank each input position.
    support = [sum(v == item for v in values) for item in values]
    winner = sorted(range(len(values)), key=lambda i: (-support[i],
                     -int(bool(values[i])) if prefer_nonempty else 0, i))[0]
    return values[winner], winner, support[winner]


def search_vote(answers):
    keys = [search_answer(a or '', voting=True) for a in answers]
    _, winner, support = plurality(keys, True)
    score_sets = [search_answer(a or '') for a in answers]
    return answers[winner] or '', dict(selected_agent=winner, support=support,
        split_pairs=sum(score_sets[i] == score_sets[j] and keys[i] != keys[j]
                        for i in range(4) for j in range(i + 1, 4)),
        merge_pairs=sum(keys[i] == keys[j] and score_sets[i] != score_sets[j]
                        for i in range(4) for j in range(i + 1, 4)))


def audit_vote(answers):
    parsed = [audit_object(a or '', voting=True) for a in answers]
    rebuilt, details = {}, []
    for hid in sorted({k for p in parsed for k in p}):
        entries = [(i, p[hid]) for i, p in enumerate(parsed) if isinstance(p.get(hid), dict)]
        if not entries:
            continue
        labels = [label_key(e.get('label')) for _, e in entries]
        winner, local, n = plurality(labels)
        supporters = [(i, e) for (i, e), label in zip(entries, labels) if label == winner]
        evidence, chosen, ev_n = plurality([evidence_key(e.get('evidence_ids')) for _, e in supporters])
        rebuilt[hid] = dict(label=winner, evidence_ids=list(evidence))
        details.append(dict(hypothesis_id=hid, participating_agents=[i for i, _ in entries],
                            label_support=n, evidence_support=ev_n,
                            first_label_supporter=entries[local][0],
                            first_evidence_supporter=supporters[chosen][0]))
    return json.dumps(rebuilt, sort_keys=True), details


def gap(perf, oracle):
    if perf is None:
        return None
    avg, best = oracle['mean_perf'], oracle['best_perf']
    require(all(type(v) in (float, int) and math.isfinite(v) for v in (perf, avg, best)) and best > avg, 'oracle_or_perf')
    return max(0.0, 100.0 * (perf - avg) / (best - avg))


def strict_mean(values):
    return statistics.mean(values) if values and all(v is not None for v in values) else None


def identity(row):
    return tuple(row[k] if k != 'outerseed' else 'outer_%05d' % row['outerrep'] for k in IDENTITY)


class Comparisons:
    def __init__(self):
        self.rows = []

    def check(self, pointer, actual, expected, numerical=False):
        delta = actual - expected if numerical and actual is not None and expected is not None else None
        ok = actual is None and expected is None if numerical and (actual is None or expected is None) else (
            type(actual) in (int, float) and type(expected) in (int, float) and math.isclose(actual, expected, rel_tol=1e-9, abs_tol=1e-9)
            if numerical else type(actual) == type(expected) and actual == expected)
        self.rows.append(dict(pointer=pointer, reported=actual, independently_expected=expected,
                              numerical=numerical, delta=delta, match=ok))

    def answer(self, pointer, actual, expected):
        fingerprint = lambda a: dict(type=type(a).__name__, chars=len(a) if isinstance(a, str) else None,
                                     sha256=checksum(a.encode()) if isinstance(a, str) else None)
        self.check(pointer, fingerprint(actual), fingerprint(expected))


def project_agent(payload, pool):
    if pool:
        return {k: payload.get(k) for k in ('answer', 'scoring_input', 'score_status', 'terminal_status',
            'missing_final_policy', 'terminal_origin', 'terminal_scenario', 'answer_perf', 'answer_metrics',
            'answer_source', 'answer_score_source')}
    outcome = payload['outcome']; score = outcome['score']
    result = {k: outcome.get(k) for k in ('answer', 'scoring_input', 'score_status', 'terminal_status',
        'missing_final_policy', 'terminal_origin', 'terminal_scenario', 'answer_source', 'answer_score_source')}
    metrics = score.get('metrics')
    result.update(answer_metrics=metrics, answer_perf=metrics[score['primary_metric']] if metrics is not None else score.get('value'))
    return result


def metrics_for(row):
    pool = row['system'] == 'poolact'
    if row['scenario'] == 'restricted_search':
        return ('f1_mi', 'f1_mv') if pool else ('f1',)
    if row['scenario'] == 'evidence_audit':
        return ('label_acc_mi', 'label_acc_mv', 'evidence_acc_mi', 'evidence_acc_mv') if pool else ('label_acc', 'evidence_acc')
    return ('gap_mi', 'gap_bon', 'raw_perf_mi', 'raw_perf_bon') if pool else ('gap', 'raw_perf')


def run():
    import pyarrow as pa
    import pyarrow.parquet as pq
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    def audit(event, args):
        if event.startswith('socket.') or event in ('subprocess.Popen', 'os.system', 'os.exec', 'os.posix_spawn'):
            raise RuntimeError('network_or_subprocess_forbidden')
    sys.addaudithook(audit)
    reader = Inputs()
    pinned = {p: strict(reader.read(p, h)) for p, h in PINS.items()}
    plan, execution, ix = pinned[PLAN], pinned[RUN/'execution.json'], pinned[OUT/'EXPORT_INDEX.json']
    seal = pinned[OP/'sealed_restart_runs_v1/glm-5.3-formal-completed-20260909/inventory.json']
    acceptance = pinned[OP/'source_acceptance_v5_final.json']
    require(execution['local_workers'] == 0 and execution['mode'] == 'formal_mixed'
            and seal['original_execution_complete'] is True and seal['original_score_complete'] is True, 'execution_not_closed')
    require(execution['plan_ref']['sha256'] == PINS[PLAN] and seal['full_second_read_equal'] is True, 'run_binding')
    outputs = {}
    for name, ref in ix['files'].items():
        require(Path(name).name == name, 'export_name')
        blob = reader.read(OUT/name, ref['sha256'], ref['bytes'])
        if name in ('manifest.json', 'records.json', 'source_index.json', 'results.json', 'oracle.json'):
            outputs[name] = strict(blob)
    require(ix['files']['results.json']['sha256'] == '619694559402dbc52fbbc24769bd5627d7115109ac4490948cebede4569cdb84', 'results_pin')
    manifest, result = outputs['manifest.json'], outputs['results.json']
    require(manifest == plan['matrix'] and len(manifest['logical_rows']) == 783 and len(plan['jobs']) == 705, 'matrix')
    for name, sha in acceptance['files'].items():
        reader.read(Path(acceptance['repo_root'])/name, sha)
    inventory = {}
    for part in seal['file_parts']:
        entries = reader.obj(part)
        require(len(entries) == part['file_count'], 'seal_part_count')
        for entry in entries:
            require(entry['path'] not in inventory, 'duplicate_seal_path')
            inventory[entry['path']] = entry
    require(len(inventory) == seal['file_count'], 'whole_seal_count')
    bindings = manifest['source_and_inputs']['files']
    qa_gold, qa_mapping = {}, []
    for seed in (2, 3):
        ref = bindings['search%d.qa' % seed]
        blob = reader.read(ref['path'], ref['sha256'], ref['bytes'])
        # Only fixed two small QA containers, never corpus or backend database.
        table = pq.read_table(pa.BufferReader(blob), columns=['answer', 'type', 'difficulty'])
        eligible = [(i, r) for i, r in enumerate(table.to_pylist()) if r['type'] in (11, 12, 27, 28) and len(r['answer']) <= 20]
        eligible.sort(key=lambda pair: (pair[1]['type'], pair[1]['difficulty']))
        selected = sorted({r['selector']['question_index'] for r in manifest['logical_rows']
                           if r['scenario'] == 'restricted_search' and r['selector']['data_source'] == 'phantom_seed%d' % seed})
        for q in selected:
            original_row, value = eligible[q]
            qa_gold[('phantom_seed%d' % seed, q)] = value['answer']
            qa_mapping.append(dict(world=seed, filtered_index=q, original_parquet_row=original_row,
                                   family_type=value['type'], difficulty=value['difficulty'], gold_count=len(value['answer'])))
    audit_data = reader.obj(bindings['audit.evidence']); audit_gold = {}; audit_mapping = []
    for row in manifest['logical_rows']:
        if row['scenario'] != 'evidence_audit':
            continue
        i = row['selector']['question_index']
        if i not in audit_gold:
            doc = audit_data['documents'][i]
            require(row['selector']['cc_split'] == 'cc-large' and int(doc['id']) == row['selector']['doc_id'], 'audit_doc_mapping')
            annotation = doc['annotation_sets'][0]['annotations']
            audit_gold[i] = {h: (v['choice'], {int(s) for s in v.get('spans', [])}) for h, v in annotation.items() if h in audit_data['labels']}
            audit_mapping.append(dict(question_index=i, doc_id=int(doc['id']), annotation_set=0, gold_hypotheses=len(audit_gold[i])))
    require(len(qa_gold) == 73 and len(audit_gold) == 13, 'gold_selected_scope')
    oracle = reader.obj(bindings['hpo.oracle'])
    require(oracle == outputs['oracle.json'], 'oracle_export_mismatch')
    order_config = reader.obj(bindings['audit.orders'])
    records = {r['logical_id']: r for r in outputs['records.json']['records']}
    planned = manifest['logical_rows']; source_index = outputs['source_index.json']
    require(len(records) == len(planned) and set(records) == {r['logical_id'] for r in planned}, 'full_record_ids')
    invocation_states = {}
    for row in planned:
        iid, state = row['invocation_id'], records[row['logical_id']]['state']
        require(iid not in invocation_states or invocation_states[iid] == state, 'inconsistent_invocation_state')
        invocation_states[iid] = state
    require(Counter(invocation_states.values()) == Counter(terminal=705), 'closed_invocation_partition')
    require(set(execution['started_invocation_ids']) == set(invocation_states) and execution['unstarted_invocation_ids'] == [], 'execution_partition')
    check = Comparisons(); agent_rows = []; pool_rows = []; units = []; groups = defaultdict(list)
    coverage = Counter(); provenance = Counter(); partial_refs = 0
    subsets = {r['logical_id']: r for r in result['known_subsets']}
    for row in planned:
        lid = row['logical_id']; record = records[lid]; pool = row['system'] == 'poolact'; scenario = row['scenario']
        n = 4 if pool else 1; state = record['state']; metric_values = {m: None for m in metrics_for(row)}
        coverage[(row['system'], scenario, state, 'logical')] += 1
        coverage[(row['system'], scenario, state, 'planned_agents')] += n
        needed = [row['result_artifact']] + (row['agent_artifacts'] if pool else [])
        payloads = {}
        for relative, sha in record['source_sha256'].items():
            absolute = str(RUN/relative)
            require(relative in needed and source_index[relative] == absolute and inventory[absolute]['sha256'] == sha, 'original_seal_export_binding')
            blob = reader.read(absolute, sha, inventory[absolute]['bytes'])
            if state == 'terminal':
                payloads[relative] = strict(blob)
            else:
                partial_refs += 1
        require(state in ('terminal', 'infrastructure_error', 'integrity_error', 'not_started'), 'unexpected_state')
        if state != 'terminal':
            units.append(dict(logical_id=lid, invocation_id=row['invocation_id'], state=state, metrics=metric_values, planned_agents=n))
            groups[identity(row)].append((row, metric_values))
            continue
        require(set(payloads) == set(needed), 'terminal_originals_incomplete')
        original = payloads[row['result_artifact']]
        original_agents = [payloads[p] for p in row['agent_artifacts']] if pool else [original]
        agents = [project_agent(p, pool) for p in original_agents]
        if pool:
            require(original['config']['scenario'] == scenario and original['config']['cost_regime'] == row['regime']
                    and original['config']['model'] == row['model_id'] and original['strategy'] == row['strategy']
                    and original['config']['agent_seeds'] == row['sampling_seed_labels'], 'pool_task_identity')
            for k in ('question_index', 'data_source', 'cc_split', 'tuning_task'):
                require(k not in row['selector'] or original['config'].get(k) == row['selector'][k], 'pool_selector')
            for i, (a, embedded) in enumerate(zip(original_agents, original['agent_results'])):
                require(a['agent_id'] == i and embedded['agent_id'] == i and type(a['agent_id']) is int, 'agent_order')
                require(project_agent(a, True) == project_agent(embedded, True), 'embedded_agent_mismatch')
            require(len(original['agent_results']) == len(agents) == 4, 'n4_count')
        else:
            require(original['task']['scenario'] == scenario and original['task']['budget']['regime'] == row['regime']
                    and original['run']['model']['id'] == row['model_id'], 'exp_identity')
            require(original['task']['item']['id'] == row['selector'].get('question_index', row['selector'].get('tuning_task')), 'exp_selector')
            if scenario == 'evidence_audit':
                require(original['task']['hypothesis_order'] == row['hypothesis_order'], 'exp_order')
        expected_scores = []
        for i, a in enumerate(agents):
            ptr = lid + '/agent/%d' % i; answer = a['answer']; missing = answer is None
            require(answer is None or type(answer) is str, 'answer_type')
            require(a['terminal_origin'] == 'normal_loop_return' and a['terminal_scenario'] == scenario
                    and a['missing_final_policy'] == 'task-abstention-v1', 'normal_terminal_policy')
            projection = None if missing and scenario == 'tuning' else '' if missing else answer
            check.answer(ptr+'/scoring_input', a['scoring_input'], projection)
            expected_status = 'unscorable_missing_configuration' if missing and scenario == 'tuning' else 'scored_empty_prediction' if missing else 'scored_final_answer'
            check.check(ptr+'/score_status', a['score_status'], expected_status)
            expected_terminal = dict(schema_version='expgym.execution-terminal.v1', policy_version='task-abstention-v1',
                execution_complete=True, score_complete=not (missing and scenario == 'tuning'),
                terminal_classification='model_no_answer' if missing else 'completed_scored',
                model_no_answer_count=int(missing), expected_model_terminals=1, reported_model_terminals=1)
            check.check(ptr+'/terminal_status', a['terminal_status'], expected_terminal)
            provenance[(scenario, a['answer_source'], a['answer_score_source'])] += 1
            if scenario == 'restricted_search':
                score = dict(f1=search_f1(projection, qa_gold[(row['selector']['data_source'], row['selector']['question_index'])]))
                check.check(ptr+'/f1', a['answer_perf'], score['f1'], True)
            elif scenario == 'evidence_audit':
                score = audit_score(projection, audit_gold[row['selector']['question_index']])
                for k, v in score.items():
                    check.check(ptr+'/'+k, a['answer_metrics'][k], v, True)
                check.check(ptr+'/primary_perf', a['answer_perf'], score['label_acc'], True)
            else:
                score = dict(raw_perf=a['answer_perf'], gap=gap(a['answer_perf'], oracle['tasks'][row['item']]))
                if missing:
                    check.check(ptr+'/missing_perf_unknown', a['answer_perf'], None)
                else:
                    require(type(a['answer_perf']) in (int, float) and math.isfinite(a['answer_perf']) and 0 <= a['answer_perf'] <= 1, 'hpo_perf_range')
            expected_scores.append(score)
            agent_rows.append(dict(logical_id=lid, agent_id=i, system=row['system'], scenario=scenario, item=row['item'],
                missing=missing, independently_recomputed=score, original_artifact=row['agent_artifacts'][i],
                answer_sha256=checksum(answer.encode()) if isinstance(answer, str) else None,
                hpo_backend_lookup='not_verified' if scenario == 'tuning' else 'not_applicable'))
        if pool:
            aggregate = original['aggregate']; answers = [a['answer'] for a in agents]
            ptr = lid + '/aggregate'; missing_count = sum(a is None for a in answers)
            status = dict(agents[0]['terminal_status'], expected_model_terminals=4, reported_model_terminals=4,
                          model_no_answer_count=missing_count, score_complete=not (missing_count and scenario == 'tuning'),
                          terminal_classification='model_no_answer' if missing_count else 'completed_scored')
            check.check(ptr+'/terminal_status', aggregate['terminal_status'], status)
            check.check(ptr+'/pool_terminal_status', original['terminal_status'], status)
            if scenario == 'restricted_search':
                answer, vote = search_vote(answers)
                metric_values = dict(f1_mi=strict_mean([s['f1'] for s in expected_scores]),
                                     f1_mv=search_f1(answer, qa_gold[(row['selector']['data_source'], row['selector']['question_index'])]))
                check.answer(ptr+'/winner_answer', aggregate['answer'], answer)
                check.check(ptr+'/f1', aggregate['answer_perf'], metric_values['f1_mv'], True)
            elif scenario == 'evidence_audit':
                answer, vote = audit_vote(answers)
                aggregate_scores = audit_score(answer, audit_gold[row['selector']['question_index']])
                metric_values = {k+'_mi': strict_mean([s[k] for s in expected_scores]) for k in ('label_acc', 'evidence_acc')}
                metric_values.update({k+'_mv': v for k, v in aggregate_scores.items()})
                check.answer(ptr+'/winner_answer', aggregate['answer'], answer)
                for k, v in aggregate_scores.items():
                    check.check(ptr+'/'+k, aggregate['answer_metrics'][k], v, True)
                check.check(ptr+'/primary_perf', aggregate['answer_perf'], aggregate_scores['label_acc'], True)
            else:
                perfs = [s['raw_perf'] for s in expected_scores]; gaps = [s['gap'] for s in expected_scores]
                winner = None if missing_count else sorted(range(4), key=lambda i: (-perfs[i], i))[0]
                vote = dict(selected_agent=winner, whole_pool_unknown=bool(missing_count))
                check.answer(ptr+'/winner_answer', aggregate['answer'], None if missing_count else answers[winner] or '')
                check.check(ptr+'/raw_perf_bon', aggregate['answer_perf'], None if missing_count else perfs[winner], True)
                if missing_count:
                    check.check(ptr+'/unknown_metrics', aggregate['answer_metrics'], None)
                else:
                    metric_values = dict(gap_mi=strict_mean(gaps), gap_bon=max(gaps), raw_perf_mi=strict_mean(perfs), raw_perf_bon=max(perfs))
            pool_rows.append(dict(logical_id=lid, scenario=scenario, strategy=row['strategy'], vote=vote))
        else:
            metric_values = expected_scores[0]
        if scenario == 'tuning':
            known = [s for s in expected_scores if s['raw_perf'] is not None]
            subset = dict(n_known=len(known), n_total=n, not_full_pool_endpoint=len(known) != n,
                mean_perf=strict_mean([s['raw_perf'] for s in known]), best_perf=max((s['raw_perf'] for s in known), default=None),
                mean_clipped_gap=strict_mean([s['gap'] for s in known]), best_clipped_gap=max((s['gap'] for s in known), default=None))
            for k, value in subset.items():
                check.check(lid+'/known_subset/'+k, subsets[lid][k], value, k not in ('n_known', 'n_total', 'not_full_pool_endpoint'))
        units.append(dict(logical_id=lid, invocation_id=row['invocation_id'], state=state, metrics=metric_values, planned_agents=n))
        groups[identity(row)].append((row, metric_values))
    metric_rows = {(tuple(r[k] for k in IDENTITY), r['metric']): r for r in result['rows']}
    metric_cells = 0; document_groups = 0
    for key, components in groups.items():
        row = components[0][0]; audit_group = row['system'] == 'expgym' and row['scenario'] == 'evidence_audit'
        require(len(components) == (3 if audit_group else 1), 'derived_component_count')
        if audit_group:
            require({r['order'] for r, _ in components} == {0, 1, 2}, 'three_fixed_orders')
            document_groups += 1
        for metric in metrics_for(row):
            expected = strict_mean([values[metric] for _, values in components])
            cell = metric_rows[(key, metric)]
            check.check('derived/'+cell['artifact']+'/'+metric, cell['value'], expected, True)
            body = result['derived_artifacts'][cell['artifact']]
            check.check('derived_body/'+cell['artifact']+'/'+metric, body['metrics'][metric], expected, True)
            metric_cells += 1
    # Rehash every explicit input used, never discover unlisted raw files.
    initial = list(reader.refs.values())
    for ref in initial:
        reader.read(ref['path'], ref['sha256'], ref['bytes'])
    failures = [r for r in check.rows if not r['match']]
    summary = dict(schema='glm-independent-formula-vote-review-v1', comparisons=len(check.rows), mismatches=len(failures),
        passed=not failures, first_counterexample=failures[0] if failures else None,
        planned_logical=783, planned_agents=sum(u['planned_agents'] for u in units), inspected_terminal_agents=len(agent_rows),
        inspected_full_n4_pools=len(pool_rows), performance_metric_cells_checked=metric_cells,
        strict_three_order_document_groups=document_groups, partial_original_refs_hashed_not_promoted=partial_refs,
        selected_search_questions=73, selected_audit_documents=13,
        complete_invocations=705, infrastructure_error_invocations=0, full_two_model_acceptance=False,
        coverage=[dict(system=s, scenario=t, state=state, unit=unit, count=count) for (s,t,state,unit),count in sorted(coverage.items())],
        provenance_counts=[dict(scenario=s,answer_source=a,answer_score_source=b,count=n) for (s,a,b),n in provenance.items()],
        nonzero_within_tolerance=sum(r['match'] and r['delta'] is not None and r['delta'] != 0 for r in check.rows),
        hpo_gap_above_100=sum(a['scenario']=='tuning' and a['independently_recomputed']['gap'] is not None and a['independently_recomputed']['gap']>100 for a in agent_rows),
        backend_lookup='not_verified; reported persisted performance plus fixed oracle arithmetic only',
        literal_model_final_selection='not_verified; persisted final answer endpoint only',
        aggregate_effects='assigned to independent /root/runner_integration/formal_scope_readonly/display_m1_readonly/main_analyzer_readonly; paper_matrix author withdrawn', costs='assigned to separate cost reviewer',
        model_api_backend_original_scorer_calls=0, original_source_imports=0,
        source_and_inputs_double_hash_equal=True, original_input_refs=initial,
        code_sha256=checksum(Path(__file__).read_bytes()), python=sys.version, pyarrow=pa.__version__)
    return {'SUMMARY.json':summary, 'checks.json':check.rows, 'agents.json':agent_rows, 'pools.json':pool_rows,
            'logical_units.json':units, 'gold_mapping_no_text.json':dict(search=qa_mapping,audit=audit_mapping), 'counterexamples.json':failures}


if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('--execute', action='store_true'); ap.add_argument('--output-dir', type=Path)
    args = ap.parse_args()
    require(args.execute and args.output_dir and not args.output_dir.exists() and args.output_dir.parent == Path(__file__).resolve().parent, 'fresh_explicit_review_output')
    products = run()
    args.output_dir.mkdir(mode=0o700)
    index = {}
    for name, value in products.items():
        blob = encode(value)
        with (args.output_dir/name).open('xb') as f:
            f.write(blob)
        index[name] = dict(bytes=len(blob),sha256=checksum(blob))
    with (args.output_dir/'INDEX.json').open('xb') as f:
        f.write(encode(index))
    print(json.dumps({k:products['SUMMARY.json'][k] for k in ('passed','comparisons','mismatches','inspected_terminal_agents','inspected_full_n4_pools','performance_metric_cells_checked','first_counterexample')}))
