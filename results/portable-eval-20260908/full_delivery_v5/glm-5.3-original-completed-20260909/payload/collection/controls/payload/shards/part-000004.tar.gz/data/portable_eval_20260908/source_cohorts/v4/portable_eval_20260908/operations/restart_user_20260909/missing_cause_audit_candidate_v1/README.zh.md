# 封存后缺答近端机制审计 v1

当前状态：仅 Static/fake validation。未对 K3、GLM 的实际 raw、答案、export 或恢复 payload 执行。原 v5、既有工具与正式设置不修改；实际入口须等 ROOT 封存后单次 GO。

## 入口与固定产物

沿用既有事后格式诊断的四个控制引用，不另建执行框架：

```json
{
  "schema_version": "restart-missing-cause-go-v1",
  "issuer": "ROOT",
  "approved": true,
  "post_run_and_analysis_frozen": true,
  "program_sha256": "<audit.py SHA256>",
  "inputs": {
    "plan": {"path": "<absolute>", "sha256": "<SHA>"},
    "execution": {"path": "<absolute>", "sha256": "<SHA>"},
    "export_index": {"path": "<absolute>", "sha256": "<SHA>"},
    "run_seal": {"path": "<absolute>", "sha256": "<SHA>"}
  },
  "output_dir": "<fresh absolute directory>"
}
```

授权后使用记录的解释器运行 `audit.py --go <file> --go-sha256 <SHA>`。没有模型、网络、Slurm、密钥、任务工具、评分器或原 loop 执行入口。只读文件必须同时符合 seal/export SHA 绑定；输入损坏、缺 raw、重复 owner、传输终态冒充正常模型终态均拒绝，不伪造缺答原因。

成功只生成五文件：`missing_causes.json`、`coverage.json`、`PROVENANCE.json`、`SUMMARY.zh.md`、`INDEX.json`。新目录排除输入控制所在目录及 v5；先完成所有读取核验再写产物，INDEX 最后写。验证失败无成功产物；写入失败可能留下未闭合的新输出目录，不可将其视为通过。原件不写、不覆盖。

`output.schema.json` 固定逐 agent 产物结构，生产调用 v5 中原有纯 `_schema_errors` 验证，避免新增依赖。CLI 不安装任何包。结果需要 ROOT 的独立输出审计，不把 CPU 通过冒称实际验证。

## 缺答分母与身份

枚举封存 manifest 全部 783 logical rows，并保留 705 invocation 分区。只纳入成功正常返回且明确 `answer is None` 的单 agent 终态；infra、not_started 的未观测 null 排除，另列总数。全体 observed agent client 唯一，缺答数与原 job terminal 汇总交叉核验。所有缺答均保留 logical/invocation/agent/seed/client、artifact SHA、pre-score loop snapshot SHA 和 raw audit SHA。

复用冻结 exporter 的 `agent_telemetry` 获取原账本，逐 call/attempt 核 request ID、client、run、seed、generation、attempt、state 和最终 usage；不能按 raw 文件名或 mtime 猜最后调用。Pool 详细 trace capture 关闭时，必须有原 `usage_attempts`、正常返回 snapshot、原 assistant messages、实际 native 请求 `tool_choice` 与匹配的 forced protocol_failure。Exp 另与 captured forced/finish/output message 交叉核验。

全部 raw 与 wire 元数据来自已 seal 的原 `raw_audit.inventory`。按 source call ledger 的顺序连接同 client 的 wire sequence，再检查请求原 `json.dumps(payload)` 编码的实际 body SHA/bytes，和响应 bytes SHA/bytes。不是把 canonical JSON 相等冒称原 wire 相等。raw 保留顺序不能恢复或发生脱敏差异时拒绝。

## 输出的机制与限制

- `forced_length_nonempty_text_rejected`：明确 final 已送达并返回 length，decoder 有文本，但冻结 loop 按 length 拒绝。不能叫原模型没有 content。
- `forced_length_empty_decoder_text`：上述 length 情况但 decoder 无文本。
- `forced_response_empty_decoder_text`：明确 final 响应文本投影为空；content 缺失/null/空白/list 与 reasoning/refusal 形态分别保留。不会把 reasoning 或 refusal 擅自当答案。
- `forced_response_tools_rejected`、`forced_text_action_rejected`：按原 loop 的分支优先级；有 tools 时其拒绝优先于 length。
- `execution_context_cap_prevented_final_request`：无 `none` 请求、calls=steps、无 forced failure，终态保留 final note，并以实际 tools schema 和冻结 trim/estimate 验证 Pool 的本地 context gate 不接纳。属于执行策略截断，不是模型收到 final 后拒答。
- `unknown`：未发 final 但不足以验证具体 gate、没有原 schema、或重建 gate 能接纳而无 final 等。零调用不会凭经验伪造 schema。

`final_request_delivered` 表示原有调用账本和成功响应支持 final 请求/响应已发生；不宣称新的 provider quiescence 证明。Pool cap 来自原配置/plan，Exp 入口本地 cap 为 None。字符÷3 只验证原 heuristic，不是实际 tokenizer 计数，也没有把 32k 输出额度从 context cap 中扣除。

每 call 留存实际 max_tokens、finish 的有限类别、该次原 usage 的已知数值字段及缺失值、content 类型/长度、decoder 投影状态、tool-call 个数。只在 length、请求上限 32768、该次已知输出 token 达上限共同满足时，`reported_32768_length_exhaustion=true`。未知 usage 不补零，累计 token 不用来证明单次耗尽。可同时保留近端机制与细节 unknown。

不导出回答、推理、refusal、工具参数文本；任意 usage 额外键不复制，只计省略字段数。非白名单 finish/参数化 abort 文本只保留类别和 SHA。所有统计分母、answer、score、Pool 票槽保持原件，不实施替代评分，也不声称增加预算必然改善。

## 纯源码复用与测试

程序 pin 9 个 v5 源文件；仅 AST 提取原 client 的三个纯 decoder 方法、原 context 的两个纯函数、原 schema validator，以及执行无 I/O 的纯 tool_protocol 模块定义。不会导入或执行原 client 构造器、runner、task、scorer 或 loop。另 pin 既有 exporter/format-diagnostics 的只读 helper；全部输入 SHA/bytes 留于 PROVENANCE。

`test_audit.py` 为手工单 agent 原请求/响应形态；`test_closed_fixture.py` 为虚拟文件系统的完整 705/783 控制结构，不是实际实验记录。测试涵盖 forced 未发、非空 length、reasoning/refusal/content-list、重试、503 的 body 含 choices、null completion alias、未知 usage、owner/attempt bool、缺 raw、孤儿 raw、次序/身份冲突、原 snapshot 与消息不符、infra null 分母和 active-run 拒绝。两记录解释器运行，主测试本身禁网络/子进程路径。

开发中已保留并修复：虚拟 raw fixture 最初 canonical 排序导致 wire hash 不符（应保留原 dump 顺序）；peer发现任意 usage 字符串与未知 finish/abort 文本可泄漏，已改数值白名单/类别 SHA；HTTP503 body 不应被当作模型语义 retry；completion null 应按原 decoder fallback；bool attempt/owner ID 必须拒绝。首次红灯不擦除或冒称通过。
