"""Hand-computed synthetic tests; no actual audit/control/raw reads."""
import importlib.util
import json
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location('independent_usage_review', Path(__file__).with_name('review_usage.py'))
review = importlib.util.module_from_spec(spec)
spec.loader.exec_module(review)


class UsageTests(unittest.TestCase):
    def test_flat_zero(self):
        values, source = review.decode_usage(dict(prompt_tokens=2, completion_tokens=0, reasoning_tokens=0))
        self.assertEqual(values, dict(input_tokens=2, output_tokens=0, reasoning_tokens=0))
        self.assertEqual(source, 'flat_only_valid')

    def test_nested(self):
        values, source = review.decode_usage(dict(prompt_tokens=4, completion_tokens=9, completion_tokens_details=dict(reasoning_tokens=7)))
        self.assertEqual(values, dict(input_tokens=4, output_tokens=9, reasoning_tokens=7))
        self.assertEqual(source, 'nested_only_valid')

    def test_equal_two_not_added(self):
        values, source = review.decode_usage(dict(completion_tokens=5, reasoning_tokens=5, completion_tokens_details=dict(reasoning_tokens=5)))
        self.assertEqual(values['reasoning_tokens'], 5)
        self.assertEqual(source, 'flat_and_nested_equal')

    def test_one_legal_candidate(self):
        for invalid in (True, False, -1, 2.0, '2', None, [], {}):
            for flat, nested, expected_source in ((3, invalid, 'flat_only_valid'), (invalid, 3, 'nested_only_valid')):
                with self.subTest(invalid=invalid, source=expected_source):
                    values, source = review.decode_usage(dict(completion_tokens=3, reasoning_tokens=flat, completion_tokens_details=dict(reasoning_tokens=nested)))
                    self.assertEqual((values['reasoning_tokens'], source), (3, expected_source))

    def test_both_invalid_unknown(self):
        for invalid in (True, False, -1, 2.0, '2', None, [], {}):
            values, source = review.decode_usage(dict(prompt_tokens=invalid, completion_tokens=invalid, reasoning_tokens=invalid, completion_tokens_details=dict(reasoning_tokens=invalid)))
            self.assertEqual(values, dict.fromkeys(review.FIELDS))
            self.assertEqual(source, 'unknown')

    def test_conflict_even_output_unknown(self):
        with self.assertRaisesRegex(ValueError, 'conflicting_reasoning_fields'):
            review.decode_usage(dict(reasoning_tokens=5, completion_tokens_details=dict(reasoning_tokens=6)))

    def test_single_attempt_upper_bound(self):
        with self.assertRaisesRegex(ValueError, 'attempt_reasoning_exceeds_output'):
            review.decode_usage(dict(completion_tokens=6, reasoning_tokens=7))

    def test_other_attempt_cannot_offset(self):
        bucket = review.empty_usage()
        review.add_usage(bucket, review.decode_usage(dict(completion_tokens=1000, reasoning_tokens=0))[0])
        with self.assertRaisesRegex(ValueError, 'attempt_reasoning_exceeds_output'):
            review.add_usage(bucket, review.decode_usage(dict(completion_tokens=6, reasoning_tokens=7))[0])

    def test_unknown_output_does_not_invent_zero(self):
        values, _ = review.decode_usage(dict(reasoning_tokens=7))
        self.assertEqual(values, dict(input_tokens=None, output_tokens=None, reasoning_tokens=7))

    def test_error_no_usage_and_inclusive_accounting(self):
        bucket = review.empty_usage()
        for usage in (dict(prompt_tokens=10, completion_tokens=8, reasoning_tokens=5), None, dict(prompt_tokens=2, completion_tokens=3, completion_tokens_details=dict(reasoning_tokens=1))):
            review.add_usage(bucket, review.decode_usage(usage)[0])
        final = review.finish_usage(bucket)
        self.assertEqual(final, {field: dict(known_sum=value, unknown_attempts=1, attempts=3, complete_total=None) for field,value in zip(review.FIELDS,(12,11,6))})
        self.assertEqual(final['output_tokens']['known_sum'], 11)  # not 17

    def test_independent_field_completeness(self):
        bucket = review.empty_usage()
        for usage in (dict(prompt_tokens=2, completion_tokens=3, reasoning_tokens=1), dict(prompt_tokens=4, completion_tokens=5)):
            review.add_usage(bucket, review.decode_usage(usage)[0])
        final = review.finish_usage(bucket)
        self.assertEqual([final[field]['complete_total'] for field in review.FIELDS], [6, 8, None])
        self.assertEqual(final['reasoning_tokens']['known_sum'], 1)

    def test_empty_vs_not_started(self):
        final = review.finish_usage(review.empty_usage())
        self.assertEqual(final, {field: dict(known_sum=0, unknown_attempts=0, attempts=0, complete_total=0) for field in review.FIELDS})
        self.assertEqual(review.record_endpoints(final, False), dict.fromkeys(review.FIELDS))
        self.assertEqual(review.record_endpoints(final, True), dict.fromkeys(review.FIELDS, 0))

    def test_json_safety(self):
        for body in (b'{"a":1,"a":2}', b'{"a":NaN}', b'{"a":Infinity}'):
            with self.assertRaises(ValueError): review.strict_json(body)

    def test_unstarted_nonempty_raw_rejected(self):
        review.validate_started_scope(False, [], {})
        for ids, sources in ((['a'*32], {}), ([], {'/synthetic/a.json':'b'*64})):
            with self.assertRaisesRegex(ValueError, 'not_started_has_raw'):
                review.validate_started_scope(False, ids, sources)

    def test_missing_reasoning_endpoint_not_null(self):
        record = dict(telemetry=dict(input_tokens=None, output_tokens=None))
        with self.assertRaises(KeyError): review.observed_endpoints(record)
        record['reasoning_tokens'] = None
        self.assertEqual(review.observed_endpoints(record), dict.fromkeys(review.FIELDS))

    def test_filename_request_binding_and_owner(self):
        rid = 'a'*32
        row = dict(system='poolact', scenario='restricted_search', regime='cost_tight', sampling_seed_labels=[11,12,13,14], strategy='cached', selector=dict(question_index=2))
        job = dict(dump_dir='/synthetic/dumps/job')
        raw = dict(schema_version='expgym.api_attempt.v1', request_id=rid, client_id='b'*32, generation_id='c'*32,
                   attempt=1, run_id='synthetic', state='error', request_payload=dict(seed=13,model='synthetic-model'),
                   context=dict(runner='poolact', scenario='restricted_search', cost_regime='cost_tight',seed=13,agent_id=2,strategy='cached',question_index=2))
        args = (job,row,'synthetic','synthetic-model',3)
        self.assertEqual(review.validate_identity(raw, Path(job['dump_dir'])/(rid+'.json'), *args)[0], rid)
        with self.assertRaisesRegex(ValueError, 'raw_path_identity'):
            review.validate_identity(raw, Path(job['dump_dir'])/('d'*32+'.json'), *args)
        raw['context']['agent_id'] = 0
        with self.assertRaisesRegex(ValueError, 'pool_agent_owner'):
            review.validate_identity(raw, Path(job['dump_dir'])/(rid+'.json'), *args)


if __name__ == '__main__':
    unittest.main()
