# GLM 独立 usage 核验：固定绑定候选，尚未 actual

状态：已完成绑定准备和两套 Python 的 16 项合成测试，等待 ROOT 全文审查后另行授权 actual。当前没有执行 `review_usage.py` 的实际入口，没有读 GLM raw 正文或解释 usage 数值；不要把此前 format GO 当 usage GO。本目录不是新增授权机制，只保留原工具与明确的外部权限边界。

作者关系：本候选作者也是已验收 K3 独立 usage checker 的作者，但不是 exporter v1/v2 作者。独立重算不 import 或调用 exporter/AN2。自查不能替代非作者工具复核；另一个 agent 已只读核过允许差异，未读实际输入。

## 唯一适配差异

以原 `k3_post_analysis_usage_review_v1/review_usage.py` SHA `9be66561689643e3ab01a8f814f2c8e9cf08e8a2293c152e7249cbac1d1433c9` 为基线：只改第 16、18、20–23、236 行的 run/export/plan/execution/seal/index 绑定与固定 raw 数 16320→18403，共 9 个允许文本替换。完整差异见 PRODUCTION_DIFF.patch；AST_EQUIVALENCE.json 证明反向归一化这些固定绑定后，其余字节及含位置的完整 AST 相同。

候选 `review_usage.py` SHA 为 `b6ce91b372eebefe2441e9355cb974908b63221025d7b7938062960c4f05d898`。705（两处）、783、1881 和 sealer pin 均保持原值，并已用 GLM 冻结元数据独立确认。model_id=`glm-5.3`、max_retries=2 仍由新 plan 动态读取，没有新模型专属逻辑。错误数、状态分布和 token 数没有从 K3 或 observer 转抄；actual 时将从全部原件重新派生。

测试文件与 K3 原件完全相同，SHA `c2f9e17d9cc6a86f2c6d5fb00c68607e372d5ff38cb4bb1ea711c2c52195a49c`。两次仅运行 `test_review_usage.py -v`：Python 3.10.12 真 exit0/0c1de8，Python 3.11.15 真 exit0/190b48，均 16 项通过；完整输出在 CPU_RECEIPT.json。测试不会验证实际 usage、raw 全遍历或当前绑定输入真实性。

## 独立绑定准备的实际范围

BINDING_EVIDENCE.json 固定四个输入的 canonical 路径与 SHA。仅读取并核对 41 个控制/封存元数据引用，共 59,619,298 B，含 36 个 inventory parts 和 closure；没有读取 raw 文件正文、records 的 usage 或答案。

元数据独立推得：705 invocation 全 started、0 unstarted；783 logical rows、1881 个唯一 `(invocation_id, sampling_seed)` owner；18,403 个 sealed dumps 路径。execution_complete 与 score_complete 均为 true，closure 与 plan/execution 绑定相符。

seal 记录 raw 总 1,813,347,865 B、最大文件 741,827 B；预计当前工具选择的输入合计 1,883,953,460 B，低于不变的每文件 128 MiB、累计 8 GiB 限制。这些 raw 大小来自已绑定 seal 元数据，不等同本次已重新读取/核 SHA 的 raw 原件；原件全核和所有 usage 值对账仍待 actual。

## 实际核验仍待授权

后续只接受本冻结脚本绑定的输入，fresh 输出固定为本目录下 `actual_v1`；该目录目前不存在，既有候选说明目录与 K3 实际结果均不改。不要提前生成 actual、重导出或用当前 CPU pass 冒充 actual pass。

算法保持：每 raw 的路径/大小/SHA/身份和唯一 logical owner；flat/nested 合法 int、相等去重、冲突失败、每 attempt reasoning≤completion；缺失保持 unknown；reasoning 属于 output 不额外相加；全部 attempt 的 known_sum/unknown/complete_total 与每 logical sidecar/原 token endpoint 全覆盖对账；另独立派生完整 record 字段子集。not_started 不当零成本，存在 unknown 时 complete_total 为 null。

仍禁止模型、API、scorer、backend、Slurm、keys、答案/正文解释或实际收费/GPU 费用断言。完整 raw JSON 容器反序列化不可避免，但语义读取限 identity/state 和 usage 数字。保持 no-follow、唯一读取、文件稳定性、core=0、exclusive fresh 输出、失败保留且无自动重试；不因 schema/cap/连续 attempt 失败静默放宽。

local_workers=0 是原闭合绑定条件，不单独证明所有 OS 子进程或远端服务静默；原始封存以外的 HTTP 完整性也不由本工具证明。本候选准备与已完成 GLM format actual 分开留存权限和产物，不替代最终 post-output/post-analysis 独立复核。
