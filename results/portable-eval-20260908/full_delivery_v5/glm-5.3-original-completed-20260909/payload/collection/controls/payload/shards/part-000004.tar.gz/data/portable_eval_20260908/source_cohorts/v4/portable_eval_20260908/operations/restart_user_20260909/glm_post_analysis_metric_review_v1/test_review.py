"""Hand-computed synthetic expectations; no original scorer or actual data."""
import json
import unittest
import review as r


class IndependentExpectations(unittest.TestCase):
    def test_search_set_f1(self):
        self.assertEqual(r.search_f1('Alice Jones;alice   JONES;Bob Smith', ['ALICE Jones']), 2/3)

    def test_search_empty(self):
        self.assertEqual(r.search_f1('', []), 1)
        self.assertEqual(r.search_f1('', ['Alice']), 0)
        self.assertEqual(r.search_f1('Alice', []), 0)

    def test_search_json_markers(self):
        self.assertEqual(r.search_answer('["1. Alice Jones"]'), {'1. alice jones'})
        self.assertEqual(r.search_answer('["1. Alice Jones"]', True), {'alice jones'})
        self.assertEqual(r.search_answer('1. Alice Jones'), {'alice jones'})

    def test_search_long_filter_split(self):
        answers=['Alice', 'Alice; these six extra words are explanatory', 'Bob', 'Bob']
        winner, details = r.search_vote(answers)
        self.assertEqual(winner, 'Bob')
        self.assertEqual(details['split_pairs'], 1)

    def test_search_merge_representative(self):
        name='Alpha Bravo Charlie Delta Echo Foxtrot'
        a, d = r.search_vote([name, json.dumps([name]), json.dumps([name]), 'X'])
        self.assertEqual(a, name)
        self.assertEqual(d['selected_agent'], 0)
        self.assertEqual(r.search_f1(a, [name]), 0)
        self.assertEqual(d['merge_pairs'], 2)

    def test_search_empty_tie(self):
        self.assertEqual(r.search_vote([None, '', 'A', 'A'])[0], 'A')
        self.assertEqual(r.search_vote(['B','A','A','B'])[0], 'B')
        self.assertEqual(r.search_vote([None]*4)[0], '')

    def test_audit_independent_ea_and_denominator(self):
        gold={'h':('Entailment',{1}), 'g':('NotMentioned',set())}
        self.assertEqual(r.audit_score('{"h":{"label":"wrong","evidence_ids":[1]}}', gold), {'label_acc':0.,'evidence_acc':.5})
        self.assertEqual(r.audit_score('{}', {}), {'label_acc':0.,'evidence_acc':0.})

    def test_audit_wrapper_rejection(self):
        text='{"h":{"label":"Entailment","evidence_ids":[1]}}'
        wrapped='```json\n'+text+'\n```;'
        self.assertEqual(r.audit_score(wrapped, {'h':('Entailment',{1})}), {'label_acc':1.,'evidence_acc':1.})
        self.assertEqual(r.audit_vote([wrapped]*4)[0], '{}')
        self.assertEqual(r.audit_object('```json\n'+text+';\n```'), {})

    def test_audit_labels_not_individually_normalized(self):
        raw='{"h":{"label":"not_mentioned","evidence_ids":[]}}'
        voted,_=r.audit_vote([raw]*4); gold={'h':('NotMentioned',set())}
        self.assertEqual(r.audit_score(raw,gold)['label_acc'],0)
        self.assertEqual(r.audit_score(voted,gold)['label_acc'],1)

    def test_audit_evidence_coercion_and_invalid(self):
        gold={'h':('Entailment',{1,2})}
        for values in ([True,1.9,'2'],'12'):
            raw=json.dumps({'h':{'label':'Entailment','evidence_ids':values}})
            self.assertEqual(r.audit_score(raw,gold)['evidence_acc'],1)
        self.assertEqual(r.evidence_key('12'), ())
        self.assertEqual(r.evidence_key([1,'bad']), (1,'bad'))
        self.assertEqual(r.audit_score('{"h":{"evidence_ids":[1,"bad"]}}', {'h':('x',set())})['evidence_acc'],1)

    def test_audit_conditional_votes_and_ties(self):
        values=[('Entailment',[2]),('Contradiction',[1]),('entailed',[3]),('contradicted',[1])]
        answer,detail=r.audit_vote([json.dumps({'h':dict(label=l,evidence_ids=e)}) for l,e in values])
        self.assertEqual(json.loads(answer), {'h':dict(label='Entailment',evidence_ids=[2])})
        self.assertEqual(detail[0]['first_evidence_supporter'],0)
        self.assertEqual(r.audit_object('{"h":1,"h":2}'),{'h':2})

    def test_gap_clip_before_mean_and_null_orders(self):
        oracle=dict(mean_perf=.5,best_perf=.75)
        gaps=[r.gap(p,oracle) for p in (.4,.6,.8,1)]
        for actual,expected in zip(gaps,[0,40,120,200]): self.assertAlmostEqual(actual,expected)
        self.assertAlmostEqual(r.strict_mean(gaps),90)
        self.assertEqual(max(gaps),200)
        self.assertIsNone(r.gap(None,oracle))
        self.assertIsNone(r.strict_mean([None,40,120,200]))
        self.assertAlmostEqual(r.strict_mean([.2,.4,.9]),.5)
        self.assertIsNone(r.strict_mean([.2,None,.9]))


if __name__ == '__main__':
    unittest.main(verbosity=2)
