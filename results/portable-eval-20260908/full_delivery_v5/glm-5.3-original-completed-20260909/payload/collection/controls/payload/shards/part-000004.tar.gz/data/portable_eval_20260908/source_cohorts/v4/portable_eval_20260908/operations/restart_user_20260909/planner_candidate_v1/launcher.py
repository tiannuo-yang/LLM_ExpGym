"""Explicit restart compile/launch I/O. No implicit grants, resampling or scores."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time

import dispatch
import planner
import support as s
import wire

HERE = Path(__file__).absolute().parent
SCHEMA = "restart-executable-plan-v1"
POLICY_FIELDS = {"workers", "max_steps", "max_evals", "max_tokens", "max_context_tokens",
    "max_protocol_retries", "max_retries", "request_timeout", "retry_base_seconds",
    "retry_max_seconds", "tuning_final_policy", "missing_final_policy",
    "stop_new_before_deadline_seconds", "max_wall_seconds"}


def utc():
    return datetime.now(timezone.utc).isoformat()


def under(path, root):
    path, root = s.io.lexical(str(path)), s.io.lexical(str(root))
    if root not in path.parents:
        raise ValueError("path_outside_declared_run")
    return path


def safe_tree(root):
    """Only this explicit artifact root, no symlinks or special files."""
    root = s.io.lexical(str(root))
    if not root.exists():
        return []
    result = []
    for current, dirs, files in os.walk(str(root), followlinks=False):
        for name in dirs:
            value = Path(current) / name
            if value.is_symlink():
                raise ValueError("artifact_directory_symlink")
        for name in files:
            result.append(s.ref(Path(current) / name))
    return sorted(result, key=lambda x: x["path"])


def policy_check(value):
    if type(value) is not dict or set(value) != POLICY_FIELDS:
        raise ValueError("complete_explicit_policy_required")
    for key in POLICY_FIELDS - {"tuning_final_policy", "missing_final_policy"}:
        if type(value[key]) not in (int, float) or not 0 <= value[key] < float("inf"):
            raise ValueError("invalid_policy_number")
    for key in ("workers", "max_steps", "max_evals", "max_tokens", "max_context_tokens", "max_protocol_retries", "max_retries"):
        if type(value[key]) is not int:
            raise ValueError("integer_policy_required")
    if not 1 <= value["workers"] <= 64 or min(value["max_steps"], value["max_evals"], value["max_tokens"], value["request_timeout"], value["max_wall_seconds"]) <= 0:
        raise ValueError("positive_bounded_policy_required")
    if value["max_retries"] != 2 or value["tuning_final_policy"] != "legacy" or value["missing_final_policy"] != dispatch.POLICY:
        raise ValueError("frozen_retry_final_policy_required")


def normalized_profile(full):
    full = s.profile_helper.validate_profile(full)
    return {key: full[key] for key in ("temperature", "top_p", "top_k", "reasoning_effort", "chat_template_kwargs")}


def command_for(config, invocation, output_root):
    p = config["policy"]
    profile = config["profiles"][config["model"]["model_id"]]
    runtime = config["runtimes"][invocation["runtime_profile_required"]]
    command = [runtime["executable"], "-u", "-B", str(Path(config["repo_root"]) / invocation["runner"])]
    command += invocation["selection_argv"]
    command += ["--backend", "openai", "--base-url", config["endpoint"],
        "--max-steps", str(p["max_steps"]), "--max-evals", str(p["max_evals"]),
        "--max-tokens", str(p["max_tokens"]), "--max-protocol-retries", str(p["max_protocol_retries"]),
        "--max-retries", str(p["max_retries"]), "--request-timeout", str(p["request_timeout"]),
        "--retry-base-seconds", str(p["retry_base_seconds"]), "--retry-max-seconds", str(p["retry_max_seconds"]),
        "--tool-protocol", "native", "--tuning-final-policy", p["tuning_final_policy"],
        "--missing-final-policy", p["missing_final_policy"], "--top-p", str(profile["top_p"]),
        "--terminal-evidence-dir", str(Path(output_root) / "evidence" / invocation["invocation_id"]),
        "--output-dir", str(Path(output_root) / invocation["output_relative_dir"])]
    if invocation["system"] == "poolact":
        command += ["--temperature", str(profile["temperature"]), "--max-context-tokens", str(p["max_context_tokens"])]
    else:
        command += ["--temperature-eval", str(profile["temperature"]), "--temperature-tuning", str(profile["temperature"]), "--prompt-cache-scope", "disabled"]
    if profile["top_k"] is not None:
        command += ["--top-k", str(profile["top_k"])]
    if profile["reasoning_effort"] is not None:
        command += ["--reasoning-effort", profile["reasoning_effort"]]
    command += ["--chat-template-kwargs", json.dumps(profile["chat_template_kwargs"], sort_keys=True, separators=(",", ":"))]
    return command


def formal_jobs(config, matrix):
    jobs = []
    root = Path(config["output_root"])
    for invocation in matrix["invocations"]:
        rows = [r for r in matrix["logical_rows"] if r["invocation_id"] == invocation["invocation_id"]]
        seeds = sorted({seed for row in rows for seed in row["sampling_seed_labels"]})
        job = dict(invocation, model_id=config["model"]["model_id"],
            expected_model_terminals=len(seeds), sampling_seed_labels=seeds,
            endpoint=config["endpoint"], command=command_for(config, invocation, root),
            output_dir=str(root / invocation["output_relative_dir"]),
            dump_dir=str(root / invocation["dump_relative_dir"]),
            log_dir=str(root / "logs" / invocation["invocation_id"]),
            terminal_evidence_dir=str(root / "evidence" / invocation["invocation_id"]),
            expected_files=[str(root / relative) for relative in matrix["expected_files"][invocation["invocation_id"]]],
            terminal_artifacts=[str(root / row["result_artifact"]) for row in rows])
        jobs.append(job)
    return jobs


def validate_jobs(config, jobs):
    if not jobs or len({j["invocation_id"] for j in jobs}) != len(jobs):
        raise ValueError("nonempty_unique_jobs_required")
    outputs = []
    for job in jobs:
        planner.identifier(job["invocation_id"])
        if job["model_id"] != config["model"]["model_id"] or job["endpoint"] != config["endpoint"]:
            raise ValueError("one_live_model_endpoint_required")
        wire._source_command(Path(config["repo_root"]), job)
        if job["command"][0] != config["runtimes"][job["runtime_profile_required"]]["executable"]:
            raise ValueError("wrong_source_interpreter")
        for key in ("dump_dir", "log_dir", "output_dir", "terminal_evidence_dir"):
            under(job[key], config["output_root"])
        if (not job["expected_files"] or len(set(job["expected_files"])) != len(job["expected_files"])
                or not set(job["terminal_artifacts"]).issubset(job["expected_files"])):
            raise ValueError("explicit_expected_artifacts_required")
        for path in job["expected_files"]:
            under(path, job["output_dir"])
        outputs.extend(job["expected_files"])
        if job["command"].count("--missing-final-policy") != 1 or job["command"][job["command"].index("--missing-final-policy") + 1] != dispatch.POLICY:
            raise ValueError("explicit_missing_final_policy_required")
        if (job["command"].count("--terminal-evidence-dir") != 1 or
                job["command"][job["command"].index("--terminal-evidence-dir") + 1] != job["terminal_evidence_dir"]
                or any(flag in job["command"] for flag in ("--api-key", "--api-key-file"))):
            raise ValueError("separate_terminal_evidence_and_memory_only_key_required")
    if len(outputs) != len(set(outputs)):
        raise ValueError("cross_job_output_collision")


def current_code_refs():
    refs = [s.ref(HERE / name) for name in ("launcher.py", "planner.py", "dispatch.py", "support.py", "wire.py", "evidence.py")]
    refs += [s.ref(s.IO_PATH), s.ref(s.PROFILE_PATH), s.ref(wire.PRIMITIVE_PATH)]
    # Anonymous-FD module imports real_common. Pin its complete local flat import
    # closure; none of those old authority functions are called by this adapter.
    refs += [s.ref(path) for path in sorted(s.SECRET_ROOT.glob("*.py"))]
    refs += [s.ref(s.SECRET_ROOT.parent / "phase3_dispatch_candidate/phase3b_cpu/common.py")]
    return refs


def compile_plan(spec):
    if spec.get("schema_version") != "restart-compile-input-v1" or spec.get("mode") not in ("formal_mixed", "selected_smoke"):
        raise ValueError("explicit_compile_mode_required")
    config = dict(spec["config"])
    policy_check(config["policy"])
    planner.identifier(config["run_id"])
    source = s.io.read_json_ref(config["source_acceptance_ref"])
    profile = s.io.read_json_ref(config["profile_ref"])
    deployment = s.io.read_json_ref(config["deployment_ref"])
    runtime_validation = s.io.read_json_ref(config["runtime_validation_ref"])
    if runtime_validation.get("passed") is not True or not source.get("files"):
        raise ValueError("accepted_source_and_passed_runtime_required")
    model = config["model"]["model_id"]
    if profile["model"] != model or deployment["model"] != model:
        raise ValueError("profile_deployment_model_mismatch")
    config["profiles"] = {model: normalized_profile(profile)}
    config["endpoint"] = wire._endpoint(deployment["router_url"])
    if deployment.get("runtime_receipt") != config["runtime_validation_ref"]["path"] or deployment.get("runtime_receipt_sha256") != config["runtime_validation_ref"]["sha256"]:
        raise ValueError("deployment_runtime_identity_mismatch")
    key = s.io.lexical(deployment["router_api_key_file"])
    s.io.check_secret_metadata(key)
    config["credential_path"] = str(key)  # Never hashed, opened or serialized by ref closure.
    root, repo = s.io.lexical(config["output_root"]), s.io.lexical(config["repo_root"])
    if root.exists() or root == repo or repo in root.parents or root in repo.parents:
        raise ValueError("fresh_separate_run_root_required")
    bindings = [config[k] for k in ("source_acceptance_ref", "profile_ref", "deployment_ref", "runtime_validation_ref")]
    for relative, checksum in source["files"].items():
        path = under(repo / relative, repo)
        bindings.append({"path": str(path), "sha256": checksum})
    for runtime in config["runtimes"].values():
        s.check_runtime(runtime)
        bindings += [runtime["resolved_executable_ref"], runtime["pyvenv_config_ref"]]
    if spec["mode"] == "formal_mixed":
        if config["repeat_policy"] != planner.DEFAULT_REPEAT_POLICY:
            raise ValueError("user_authorized_mixed_repeat_policy_required")
        data = planner.inventory(repo, config["source_acceptance_ref"]["path"], config["legacy_runtime_root"])
        matrix = planner.build_manifest(config["run_id"], [config["model"]], config["repeat_policy"], config["schedule_seed"], config["base_seed"], data, supersedes=config["supersedes"])
        jobs = formal_jobs(config, matrix)
        bindings += [{"path": row["path"], "sha256": row["sha256"]} for row in data["files"].values()]
    else:
        matrix = None
        jobs = spec["jobs"]
        bindings += spec["selected_input_refs"]
    validate_jobs(config, jobs)
    bindings += current_code_refs()
    unique = {}
    for binding in bindings:
        if s.io.lexical(binding["path"]) == key:
            raise ValueError("credential_cannot_be_a_file_binding")
        if binding["path"] in unique and unique[binding["path"]] != binding["sha256"]:
            raise ValueError("conflicting_file_binding")
        s.io.read_ref(binding)
        unique[binding["path"]] = binding["sha256"]
    return {"schema_version": SCHEMA, "mode": spec["mode"], "config": config, "matrix": matrix,
            "jobs": jobs, "file_bindings": unique, "created_at_utc": utc(),
            "launch_authorized": False, "expected_invocations": len(jobs),
            "expected_model_terminals": sum(j["expected_model_terminals"] for j in jobs),
            "expected_result_files": sum(len(j["expected_files"]) for j in jobs)}


def verify_plan(plan):
    if plan.get("schema_version") != SCHEMA:
        raise ValueError("wrong_plan_schema")
    config = plan["config"]
    policy_check(config["policy"])
    key = s.io.lexical(config["credential_path"])
    s.io.check_secret_metadata(key)
    for path, checksum in plan["file_bindings"].items():
        if s.io.lexical(path) == key:
            raise ValueError("credential_ref_forbidden")
        s.io.read_ref({"path": path, "sha256": checksum})
    for binding in current_code_refs():
        if plan["file_bindings"].get(binding["path"]) != binding["sha256"]:
            raise ValueError("launcher_or_dependency_not_bound")
    for runtime in config["runtimes"].values():
        s.check_runtime(runtime)
    validate_jobs(config, plan["jobs"])
    deployment = s.io.read_json_ref(config["deployment_ref"])
    profile = s.io.read_json_ref(config["profile_ref"])
    if (config["profiles"] != {config["model"]["model_id"]: normalized_profile(profile)}
            or profile["model"] != config["model"]["model_id"] or deployment["model"] != profile["model"]
            or config["credential_path"] != deployment["router_api_key_file"]
            or config["endpoint"] != wire._endpoint(deployment["router_url"])):
        raise ValueError("actual_model_endpoint_profile_binding_mismatch")
    if plan["mode"] == "formal_mixed":
        planner.validate(plan["matrix"])
        if formal_jobs(config, plan["matrix"]) != plan["jobs"]:
            raise ValueError("compiled_jobs_differ_from_full_matrix")
    elif plan["mode"] != "selected_smoke":
        raise ValueError("unknown_plan_mode")


class Authority:
    def __init__(self, plan, plan_ref, go, *, now=None):
        self.plan, self.go, self.now = plan, go, now or time.time
        c = plan["config"]
        if (go.get("schema_version") != "restart-root-launch-go-v1" or go.get("action") != "execute_once"
                or go.get("plan_ref") != plan_ref or go.get("run_id") != c["run_id"]
                or go.get("model_id") != c["model"]["model_id"] or go.get("output_root") != c["output_root"]
                or go.get("mode") != plan["mode"] or go.get("invocation_ids") != [j["invocation_id"] for j in plan["jobs"]]
                or go.get("deployment_ref") != c["deployment_ref"] or go.get("policy_sha256") != s.digest(c["policy"])):
            raise ValueError("explicit_root_go_scope_mismatch")
        for key in ("not_before_unix", "latest_start_unix", "deadline_unix", "allocation_start_unix", "allocation_deadline_unix", "gpu_seconds_cap"):
            if type(go.get(key)) not in (int, float) or not 0 < go[key] < float("inf"):
                raise ValueError("finite_authority_times_budget_required")
        if (type(go.get("gpu_count")) is not int or go["gpu_count"] != 64 or not go.get("allocation_id")
                or not go["allocation_start_unix"] <= go["not_before_unix"] <= go["latest_start_unix"] < go["deadline_unix"] <= go["allocation_deadline_unix"]
                or (go["deadline_unix"] - go["allocation_start_unix"]) * go["gpu_count"] > go["gpu_seconds_cap"]):
            raise ValueError("allocation_resource_window_mismatch")
        self.ids = set(go["invocation_ids"])

    def check(self, invocation_id, starting=False):
        p, g, now = self.plan["config"]["policy"], self.go, self.now()
        if invocation_id not in self.ids or not g["not_before_unix"] <= now or now + p["request_timeout"] >= g["deadline_unix"]:
            raise ValueError("request_outside_bound_authority")
        if starting and now + p["stop_new_before_deadline_seconds"] >= g["deadline_unix"]:
            raise ValueError("new_dispatch_window_closed")


def clean_environment(config):
    env = dict(os.environ)
    for name in list(env):
        upper = name.upper()
        if upper.endswith("_PROXY") or any(token in upper for token in ("API_KEY", "ACCESS_TOKEN", "SECRET")):
            env.pop(name, None)
        elif upper.startswith(("EXPGYM_", "OPENAI_", "OPENROUTER_", "SUB2API_", "GEMINI_")) or upper.endswith("_TOKEN"):
            env.pop(name, None)
    for name, value in config["environment"].items():
        if any(token in name.upper() for token in ("KEY", "TOKEN", "SECRET", "PROXY", "PYTHONPATH", "PYTHONHOME")):
            raise ValueError("unsafe_child_environment_override")
        env[name] = value
    env.update(NO_PROXY="*", no_proxy="*", PYTHONDONTWRITEBYTECODE="1")
    return env


def terminal_status(job):
    values = [s.parse_json(s.io.read_regular(path)) for path in job["terminal_artifacts"]]
    statuses = []
    for value in values:
        status = value.get("terminal_status")
        if status is None and isinstance(value.get("outcome"), dict):
            status = value["outcome"].get("terminal_status")
        if type(status) is not dict:
            raise ValueError("source_terminal_status_missing")
        statuses.append(status)
    if len(statuses) == 1:
        return statuses[0]
    base = {"schema_version": "expgym.execution-terminal.v1", "policy_version": dispatch.POLICY}
    if any(any(st.get(k) != v for k, v in base.items()) for st in statuses):
        raise ValueError("source_terminal_schema_mismatch")
    for status in statuses:
        subjob = dict(job, expected_model_terminals=status.get("expected_model_terminals"))
        candidate = dict({k: True for k in dispatch.EVIDENCE_FIELDS}, invocation_id=job["invocation_id"], terminal_status=status)
        if not dispatch.terminal_decision(subjob, candidate)["continue"]:
            raise ValueError("invalid_individual_source_terminal")
    missing = sum(st["model_no_answer_count"] for st in statuses)
    return dict(base, execution_complete=all(st["execution_complete"] is True for st in statuses),
        score_complete=all(st["score_complete"] is True for st in statuses),
        terminal_classification="model_no_answer" if missing else "completed_scored",
        model_no_answer_count=missing, expected_model_terminals=sum(st["expected_model_terminals"] for st in statuses),
        reported_model_terminals=sum(st["reported_model_terminals"] for st in statuses))


def child(plan, plan_ref, go, job, secret_fd, verify_only=False):
    verify_plan(plan)
    authority = Authority(plan, plan_ref, go)
    runtime = plan["config"]["runtimes"][job["runtime_profile_required"]]
    if str(Path(sys.prefix).absolute()) != runtime["prefix"] or str(Path(sys.executable).resolve()) != runtime["resolved_executable_ref"]["path"]:
        raise ValueError("actual_child_interpreter_mismatch")
    logdir = Path(job["log_dir"])
    if not (logdir / "reserved.json").is_file() or (logdir / "terminal.json").exists():
        raise ValueError("child_without_unique_live_reservation")
    s.put(logdir, "verify_started.json" if verify_only else "source_started.json",
          {"pid": os.getpid(), "ppid": os.getppid(), "utc": utc(), "invocation_id": job["invocation_id"]})
    if verify_only:
        verify_job = dict(job, command=list(job["command"]))
        index = verify_job["command"].index("--terminal-evidence-dir")
        verify_job["command"][index+1] = str(Path(plan["config"]["output_root"]) / "verification_evidence" / job["invocation_id"])
        result = wire.verify_source(plan, verify_job)
        s.put(logdir, "verified_resume.json", result)
        return 0 if result["passed"] else 2
    authority.check(job["invocation_id"])
    secret = s.secret_helpers().read_secret_fd(secret_fd)
    eventdir = logdir / "wire"
    def record(value):
        token = value.get("attempt_sequence", value.get("wire_client_id"))
        s.put(eventdir, value["kind"] + "_" + str(token) + ".json", value)
    authority.record_wire = record
    try:
        result = wire.run_source(plan, job, authority, secret)
        s.put(logdir, "source_result.json", result)
        return result["source_exit_code"]
    except BaseException as exc:
        s.put(logdir, "source_exception.json", {"error_type": type(exc).__name__, "utc": utc(),
              "invocation_id": job["invocation_id"], "message_omitted_to_protect_credentials": True})
        return 2


def launch(plan, plan_ref, go, go_ref):
    verify_plan(plan)
    config = plan["config"]
    authority = Authority(plan, plan_ref, go)
    authority.check(plan["jobs"][0]["invocation_id"], starting=True)
    if time.time() > go["latest_start_unix"]:
        raise ValueError("entry_latest_start_expired")
    root = Path(config["output_root"])
    if root.exists():
        raise ValueError("single_fresh_launch_only")
    # All identity/grant/scope checks precede secret content and namespace creation.
    secret = s.io.read_regular(config["credential_path"], max_bytes=2050).decode("ascii").rstrip("\r\n")
    s.secret_helpers().validate_secret(secret)
    env = clean_environment(config)
    s.io.new_directory(root)
    for name in ("logs", "journal", "results", "dumps", "evidence", "verification_evidence"):
        s.new_child_directory(root, name)
    s.put(root, "execution_started.json", {"pid": os.getpid(), "ppid": os.getppid(), "pgid": os.getpgrp(),
        "utc": utc(), "plan_ref": plan_ref, "go_ref": go_ref, "caller": "restart-launcher-v1"})
    stop = threading.Event()
    old_handler = signal.signal(signal.SIGINT, lambda unused_s, unused_f: stop.set())
    began = time.monotonic()
    def before(job):
        authority.check(job["invocation_id"], starting=True)
        if time.monotonic() - began >= config["policy"]["max_wall_seconds"]:
            raise ValueError("dispatcher_wall_limit")
        logdir = Path(job["log_dir"])
        logdir.parent.mkdir(parents=True, exist_ok=True)
        s.io.new_directory(logdir)
        s.new_child_directory(logdir, "wire")
    def record(kind, value):
        iid = value.get("invocation_id")
        directory = Path(next(j["log_dir"] for j in plan["jobs"] if j["invocation_id"] == iid)) if iid else root / "journal"
        s.put(directory, kind + ".json", dict(value, recorded_at_utc=utc()))
    def worker(job):
        logdir = Path(job["log_dir"])
        cmd = [job["command"][0], "-u", "-B", str(HERE / "launcher.py"), "child", "--plan", plan_ref["path"],
            "--plan-sha256", plan_ref["sha256"], "--go", go_ref["path"], "--go-sha256", go_ref["sha256"], "--invocation-id", job["invocation_id"]]
        report = {"invocation_id": job["invocation_id"]}
        try:
            capture, unused = s.secret_helpers().run_child(cmd, config["repo_root"], env, str(logdir / "source.log"), secret=secret)
            s.put(logdir, "source_capture.json", capture)
            report["source_capture"] = capture
            if capture["exit_code"] != 0 or not capture["drain_proven"]:
                raise ValueError("source_failed_or_not_drained")
            actual = safe_tree(job["output_dir"])
            if {r["path"] for r in actual} != set(job["expected_files"]):
                raise ValueError("exact_result_file_set_mismatch")
            before_raw = safe_tree(job["dump_dir"])
            original_evidence = safe_tree(job["terminal_evidence_dir"])
            if not original_evidence:
                raise ValueError("source_terminal_evidence_missing")
            with open(logdir / "verified_resume.log", "xb") as stream:
                result = subprocess.run(cmd + ["--verify-only"], cwd=config["repo_root"], env=env, stdout=stream, stderr=subprocess.STDOUT)
            verification = s.parse_json(s.io.read_regular(logdir / "verified_resume.json"))
            if result.returncode != 0 or verification.get("passed") is not True:
                raise ValueError("original_source_verified_resume_failed")
            if (actual != safe_tree(job["output_dir"]) or before_raw != safe_tree(job["dump_dir"])
                    or original_evidence != safe_tree(job["terminal_evidence_dir"])):
                raise ValueError("verified_resume_changed_original_bytes")
            import evidence
            raw = evidence.audit_raw(plan, job, [r["path"] for r in before_raw], [r["path"] for r in safe_tree(logdir / "wire")])
            s.put(logdir, "raw_audit.json", raw)
            if raw.get("verified") is not True:
                raise ValueError("raw_wire_integrity_failed")
            report.update({key: True for key in dispatch.EVIDENCE_FIELDS})
            report.update(terminal_status=terminal_status(job), artifacts=actual, raw_audit_ref=s.ref(logdir / "raw_audit.json"),
                verified_resume_ref=s.ref(logdir / "verified_resume.json"), original_terminal_evidence=original_evidence,
                verification_terminal_evidence=safe_tree(root / "verification_evidence" / job["invocation_id"]),
                original_comparison="path-set and bytes only; summary mtime may change")
        except BaseException as exc:
            report["error_type"] = type(exc).__name__
            report["failure_code"] = str(exc) if isinstance(exc, ValueError) else "details_in_original_child_log"
            report["preserved_artifacts"] = safe_tree(job["output_dir"])
            report["preserved_raw"] = safe_tree(job["dump_dir"])
            report["preserved_terminal_evidence"] = safe_tree(job["terminal_evidence_dir"])
        return report
    try:
        # Fixed barriers between declared outer blocks; no response-dependent
        # task set, seed labels or number of outer repetitions.
        stages, blocks = [], []
        for job in plan["jobs"]:
            block = job.get("outerrep", 0)
            if not blocks or blocks[-1][0] != block:
                blocks.append((block, []))
            blocks[-1][1].append(job)
        for index, (block, jobs) in enumerate(blocks):
            def stage_record(kind, value):
                if kind == "drain":
                    s.put(root / "journal", "drain_%04d.json" % index, dict(value, outerrep=block, recorded_at_utc=utc()))
                else:
                    record(kind, value)
            stage = dispatch.run_bounded(jobs, worker, workers=config["policy"]["workers"], before_start=before, record=stage_record, stop_event=stop)
            stages.append(stage)
            if not stage["execution_complete"]:
                break
        started = [iid for stage in stages for iid in stage["started_invocation_ids"]]
        execution = {"schema_version":"restart-bounded-study-execution-v1", "stages":stages,
            "reports":[r for stage in stages for r in stage["reports"]], "started_invocation_ids":started,
            "unstarted_invocation_ids":[j["invocation_id"] for j in plan["jobs"] if j["invocation_id"] not in set(started)],
            "execution_complete":len(started)==len(plan["jobs"]) and all(x["execution_complete"] for x in stages),
            "score_complete":len(started)==len(plan["jobs"]) and all(x["score_complete"] for x in stages),
            "local_workers":0,"provider_quiescence_proven":False,"elapsed_seconds":time.monotonic()-began}
        execution.update(plan_ref=plan_ref, go_ref=go_ref, run_id=config["run_id"], mode=plan["mode"], finished_at_utc=utc(),
            classification="execution_complete_not_automatically_performance_complete", whole_study_invalidated_predecessors=config["supersedes"])
        s.put(root, "execution.json", execution)
        return 0 if execution["execution_complete"] else 2
    finally:
        signal.signal(signal.SIGINT, old_handler)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="action", required=True)
    compile_cli = sub.add_parser("compile")
    compile_cli.add_argument("--spec", required=True)
    compile_cli.add_argument("--spec-sha256", required=True)
    compile_cli.add_argument("--output-dir", required=True)
    for action in ("launch", "child"):
        cli = sub.add_parser(action)
        for flag in ("plan", "plan-sha256", "go", "go-sha256"):
            cli.add_argument("--" + flag, required=True)
        if action == "launch":
            cli.add_argument("--execute-real", action="store_true", required=True)
        else:
            cli.add_argument("--invocation-id", required=True)
            cli.add_argument("--secret-fd", type=int)
            cli.add_argument("--verify-only", action="store_true")
    args = parser.parse_args()
    if args.action == "compile":
        spec = s.io.read_json_ref({"path": args.spec, "sha256": args.spec_sha256})
        plan = compile_plan(spec)
        directory = s.io.new_directory(args.output_dir)
        reference = s.put(directory, "plan.json", plan)
        s.put(directory, "compile_receipt.json", {"plan_ref": reference, "canonical_sha256": s.digest(plan),
            "expected_invocations": plan["expected_invocations"], "expected_model_terminals": plan["expected_model_terminals"],
            "model_calls": 0, "key_content_read": False, "source_or_scorer_executed": False})
        print(json.dumps(reference, sort_keys=True))
        return 0
    plan_ref = {"path": args.plan, "sha256": args.plan_sha256}
    go_ref = {"path": args.go, "sha256": args.go_sha256}
    plan, go = s.io.read_json_ref(plan_ref), s.io.read_json_ref(go_ref)
    if args.action == "launch":
        return launch(plan, plan_ref, go, go_ref)
    matches = [j for j in plan["jobs"] if j["invocation_id"] == args.invocation_id]
    if len(matches) != 1:
        raise ValueError("unknown_invocation")
    return child(plan, plan_ref, go, matches[0], args.secret_fd, args.verify_only)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as error:
        print(json.dumps({"error_type": type(error).__name__, "error_message_omitted": True}), file=sys.stderr)
        sys.exit(2)
