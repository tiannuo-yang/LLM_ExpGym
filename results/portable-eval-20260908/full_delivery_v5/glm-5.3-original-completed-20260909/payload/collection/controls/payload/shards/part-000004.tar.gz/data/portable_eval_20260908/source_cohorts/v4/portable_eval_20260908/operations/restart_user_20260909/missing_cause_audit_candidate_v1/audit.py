#!/usr/bin/env python3
"""Sealed-run missing-final proximal mechanisms; never a new score or rerun."""
import argparse
import ast
import builtins
from collections import Counter
import copy
import hashlib
import json
import math
from pathlib import Path
import types

HERE = Path(__file__).resolve().parent
SOURCE = Path('/lustrefs/users/chufan.shi/codex_space_tn/portable_eval_20260908/source_cohorts/v5/LLM_ExpGym')
PINS = {
    'expgym/react_loop.py': 'f269934940c6057f149ac07c079b40a29fde97bcf9e69f9753aa6bf5c21a5ec4',
    'expgym/llm_clients.py': '5823e7bc9be71af40f47c307e079f820bbe4d808dc03e66deeea416677500ebb',
    'expgym/tool_protocol.py': '1806cc9c26cad623d295c528dbb5c13c33121ef33cf41793a15cf9a183fec9c7',
    'expgym/missing_final.py': 'fb5812d3e23f995d0e08912e1a95d3eaa0a42693949f569f16498fcd1767f12f',
    'scripts/run_poolact.py': 'f69619eb7361058311c5e14da5af064dc710efcd4d1a4a8ab7ca349be3b6ed15',
    'scripts/run_paper_sweep.py': '3eda1ac8eb5d48311dd94a374519d220eabd58046b3f9dfbbf2f68453df6298f',
    'expgym/terminal_evidence.py': '74d76fbc8bee5a7135b3c782c2bc6104915a0b8ae2716531826f98d6ecb164f8',
    'demo_experiment.py': '4693160e27eef952b523700869f4101a4ea6250eabc12d953fecdf6ba3dec5da',
    'expgym/trace_v2.py': '5299dc33d3c1d638250602ac37cb31a2a6771b26200955743ba0444d32e1a1c1',
}
DEPENDENCIES = {
    'exporter_candidate_v2/exporter.py': 'c70319b2c1cd586859572f7c4d066acb847c36ef2424e84027553aa72346747c',
    'format_diagnostics_candidate_v2/diagnostics.py': 'cda43f4432552334362cab336d6296d369502764b300a250ab886e189d387c07',
}
POLICY = 'task-abstention-v1'
SCHEMA = 'restart-missing-cause-audit-v1'
OUTPUT_SCHEMA_SHA = 'c6340681592cfe40c902fc3a9353e4604ee4a96cfe611903cdd86fce8f17b22c'
FORCED_REASONS = {
    'tools_disabled': 'Tools are disabled during forced final',
    'length': 'Forced final completion token limit reached',
    'text_action': 'Action received during forced final',
    'empty': 'Forced final returned empty response',
}
FILES = ('missing_causes.json', 'coverage.json', 'PROVENANCE.json', 'SUMMARY.zh.md', 'INDEX.json')


def require(ok, code):
    if not ok:
        raise ValueError(code)


def dump(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')


def sha(blob):
    return hashlib.sha256(blob).hexdigest()


def equal(a, b):
    return dump(a) == dump(b)


def dependency(relative):
    path = HERE.parent / relative
    body = path.read_bytes()
    require(sha(body) == DEPENDENCIES[relative], 'frozen_dependency_changed')
    namespace = {'__file__': str(path), '__name__': 'missing_cause_dependency'}
    exec(compile(body, str(path), 'exec'), namespace)
    return types.SimpleNamespace(**namespace)


def pure_source(reader, repo):
    """Only three decoder methods, two context functions, and pure protocol code.

    No source runner/client constructor, task builder, scorer or loop is imported
    or executed. AST nodes are unmodified except deferred type annotations.
    """
    bodies = {rel: reader.ref({'path': str(repo / rel), 'sha256': pin}) for rel, pin in PINS.items()}
    def compile_nodes(nodes, filename, namespace):
        module = ast.parse('')
        module.body = nodes
        for node in ast.walk(module):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                node.returns = None
                args = node.args
                for arg in getattr(args, 'posonlyargs', []) + args.args + args.kwonlyargs:
                    arg.annotation = None
                for arg in (args.vararg, args.kwarg):
                    if arg is not None:
                        arg.annotation = None
        exec(compile(ast.fix_missing_locations(module), filename, 'exec'), namespace)
        return namespace
    original_class = next(n for n in ast.parse(bodies['expgym/llm_clients.py']).body
                          if isinstance(n, ast.ClassDef) and n.name == 'OpenAICompatibleLLM')
    names = {'_decode_response', '_normalize_tool_calls', '_validate_usage'}
    methods = [n for n in original_class.body if isinstance(n, ast.FunctionDef) and n.name in names]
    require({n.name for n in methods} == names, 'decoder_methods_missing')
    original_class.body, original_class.bases, original_class.keywords = methods, [], []
    ns = compile_nodes([original_class], str(repo / 'expgym/llm_clients.py'), {'copy': copy, 'json': json})
    context_nodes = [n for n in ast.parse(bodies['expgym/react_loop.py']).body
                     if isinstance(n, ast.FunctionDef) and n.name in {'_estimate_tokens', '_trim_messages'}]
    require(len(context_nodes) == 2, 'context_functions_missing')
    context = compile_nodes(context_nodes, str(repo / 'expgym/react_loop.py'), {'copy': copy, 'json': json})
    protocol = {'__name__': 'missing_cause_pure_protocol'}
    exec(compile(bodies['expgym/tool_protocol.py'], str(repo / 'expgym/tool_protocol.py'), 'exec'), protocol)
    validator_nodes = [n for n in ast.parse(bodies['expgym/trace_v2.py']).body
                       if isinstance(n, ast.FunctionDef) and n.name == '_schema_errors']
    require(len(validator_nodes) == 1, 'frozen_schema_validator_missing')
    validator = compile_nodes(validator_nodes, str(repo / 'expgym/trace_v2.py'), {'math': math})
    return types.SimpleNamespace(decode=ns['OpenAICompatibleLLM']._decode_response,
        estimate=context['_estimate_tokens'], trim=context['_trim_messages'], action=protocol['extract_text_action'],
        schema_errors=validator['_schema_errors'])


def field_shape(message, key):
    """Do not export text, refusal text, arguments, or reasoning."""
    if key not in message:
        return {'present': False, 'type': 'absent', 'chars': None, 'nonblank': None}
    value = message[key]
    kind = 'null' if value is None else 'string' if type(value) is str else 'list' if type(value) is list else 'object' if type(value) is dict else 'other'
    return {'present': True, 'type': kind, 'chars': len(value) if type(value) is str else None,
            'nonblank': bool(value.strip()) if type(value) is str else None}


def response_facts(raw, pure):
    require(raw.get('state') == 'success' and raw.get('error') is None, 'terminal_attempt_not_delivered')
    text = raw.get('response_raw')
    require(type(text) is str, 'response_raw_missing')
    data, decoded, tools, message, finish = pure.decode(text.encode('utf-8'))
    require(equal(data, raw.get('response_json')), 'response_raw_json_mismatch')
    require(finish != 'abort', 'provider_abort_not_model_abstention')
    usage = data.get('usage')
    completion = usage.get('completion_tokens') if type(usage) is dict else None
    if completion is None and type(usage) is dict:
        completion = usage.get('output_tokens')
    cap = raw['request_payload'].get('max_tokens')
    if completion is not None:
        require(type(completion) is int and completion >= 0, 'invalid_completion_count')
    require(type(cap) is int and cap > 0, 'invalid_request_output_limit')
    parts = message.get('content')
    part_types = []
    if type(parts) is list:
        for part in parts:
            tag = part.get('type') if type(part) is dict else None
            part_types.append(tag if type(tag) is str and tag in ('text', 'output_text', 'refusal', 'image_url', 'thinking', 'reasoning') else 'other_or_missing')
    counts = ('prompt_tokens', 'input_tokens', 'completion_tokens', 'output_tokens', 'total_tokens', 'reasoning_tokens')
    details = ('prompt_tokens_details', 'input_tokens_details', 'completion_tokens_details', 'output_tokens_details')
    safe_usage = None if usage is None else {k: usage[k] for k in counts if k in usage}
    omitted = 0
    if usage is not None:
        omitted = len(set(usage) - set(counts) - set(details))
        for key in details:
            if key in usage:
                detail = usage[key]
                safe_usage[key] = None if detail is None else {k: detail[k] for k in ('cached_tokens', 'cache_write_tokens', 'reasoning_tokens') if k in detail}
                if detail is not None:
                    omitted += len(set(detail) - {'cached_tokens', 'cache_write_tokens', 'reasoning_tokens'})
    safe_finish = finish if finish in (None, 'stop', 'length', 'tool_calls', 'function_call', 'content_filter', 'abort') else 'other'
    facts = {'finish_reason': safe_finish, 'raw_finish_reason_sha256': sha(dump(finish)),
        'usage': safe_usage, 'usage_extra_fields_omitted': omitted,
        'completion_tokens': completion, 'requested_max_tokens': cap,
        'length_reported': finish == 'length',
        'reported_request_limit_reached': (completion >= cap if completion is not None else None),
        'reported_32768_length_exhaustion': (finish == 'length' and cap == 32768 and completion >= cap) if completion is not None else None,
        'content': field_shape(message, 'content'), 'reasoning_content': field_shape(message, 'reasoning_content'),
        'reasoning': field_shape(message, 'reasoning'), 'refusal': field_shape(message, 'refusal'),
        'content_part_types': part_types, 'tool_call_count': len(tools),
        'decoder_text_nonempty': bool(decoded.strip()), 'decoder_text_chars': len(decoded),
        'text_action_detected': pure.action(decoded.strip()) is not None,
        'decoder_projection': 'string_strip_or_text_parts_only; reasoning_refusal_other_parts_not_final_text',
        'wire_request_body_sha256': None, 'wire_response_bytes_sha256': None}
    return facts, message


def classify(snapshot, calls, raws, identity, pure, *, system, context_cap, exp_calls=None):
    """One qualified missing terminal. raws are keyed by request_id, never mtime.

    Identity/ledger contradictions raise. Absent optional mechanism evidence
    remains unknown. A missing required raw is an integrity failure, not a
    fabricated no-final request. Retries remain in each logical call.
    """
    require(snapshot.get('answer') is None and snapshot.get('aborted') is True, 'not_aborted_missing_loop')
    require(snapshot.get('tool_protocol') == 'native', 'native_source_contract_required')
    count, steps = snapshot.get('api_calls'), snapshot.get('agent_steps')
    require(type(count) is int and type(steps) is int and 0 <= steps <= count <= steps + 1, 'invalid_loop_call_counts')
    require(type(calls) is list and len(calls) == count
            and all(type(c.get('llm_call_index')) is int for c in calls)
            and [c.get('llm_call_index') for c in calls] == list(range(1, count + 1)), 'call_ledger_sequence_mismatch')
    require(type(snapshot.get('messages')) is list and type(snapshot.get('protocol_failures')) is list, 'loop_evidence_missing')
    known_requests, generations, decoded_messages, observations = set(), set(), [], []
    for call in calls:
        attempts = call.get('attempts')
        require(type(attempts) is list and attempts and all(type(a.get('attempt')) is int for a in attempts)
                and [a.get('attempt') for a in attempts] == list(range(1, len(attempts) + 1)), 'retry_ledger_incomplete')
        gid = attempts[0].get('generation_id')
        require(type(gid) is str and gid and gid not in generations, 'generation_reused')
        generations.add(gid)
        payload = None
        chain = []
        for offset, attempt in enumerate(attempts):
            rid = attempt.get('request_id')
            require(type(rid) is str and rid not in known_requests and rid in raws, 'missing_or_duplicate_raw_request')
            known_requests.add(rid)
            raw = raws[rid]
            req = raw.get('request_payload')
            require(type(req) is dict and raw.get('request_id') == rid and raw.get('client_id') == identity['client_id']
                    and req.get('seed') == identity['seed'] and type(req.get('seed')) is int
                    and req.get('model') == identity['model_id'] and raw.get('run_id') == identity['run_id']
                    and raw.get('generation_id') == gid == attempt.get('generation_id')
                    and type(raw.get('attempt')) is int and raw.get('attempt') == attempt.get('attempt')
                    and raw.get('state') == attempt.get('state'), 'attempt_owner_or_generation_mismatch')
            require(req.get('tool_choice') in ('auto', 'none') and type(req.get('tools')) is list and req['tools'], 'native_request_shape_missing')
            require(payload is None or equal(payload, req), 'retry_payload_changed')
            payload = req
            retry = offset < len(attempts) - 1
            require(raw.get('will_retry') is retry, 'retry_terminal_flag_mismatch')
            if retry:
                error_type = (raw.get('error') or {}).get('type')
                http_status = raw.get('http_status')
                retry_types = {v.__name__ for v in vars(builtins).values() if isinstance(v, type)
                               and issubclass(v, (TimeoutError, ConnectionError))} | {'URLError', 'RemoteDisconnected'}
                retry_http = (type(http_status) is int and http_status in (429, 500, 502, 503, 504) and error_type == 'HTTPError')
                retry_transport = (http_status is None and error_type in retry_types
                                   and raw.get('response_raw') is None and raw.get('response_json') is None)
                require(raw.get('state') == 'error' and (retry_http or retry_transport), 'nontransport_decision_must_not_be_retried')
            chain.append({'request_id': rid, 'attempt': attempt['attempt'], 'state': attempt['state']})
        facts, message = response_facts(raw, pure)
        require(equal(attempts[-1].get('usage'), raw['response_json'].get('usage')), 'delivered_usage_ledger_mismatch')
        decoded_messages.append(message)
        if exp_calls is not None:
            captured = exp_calls[call['llm_call_index'] - 1]
            require(captured.get('forced') is (payload['tool_choice'] == 'none')
                    and captured.get('finish_reason') == raw['response_json']['choices'][0].get('finish_reason')
                    and equal(captured.get('output_message'), message), 'exp_capture_raw_mismatch')
        observations.append({'llm_call_index': call['llm_call_index'], 'generation_id': gid,
            'attempts': chain, 'delivered_request_id': raw['request_id'], 'tool_choice': payload['tool_choice'],
            'response': facts})
    require(set(raws) == known_requests, 'extra_unclaimed_owner_raw')
    require(snapshot.get('http_request_attempts') == len(known_requests), 'physical_attempt_count_mismatch')
    assistants = [m for m in snapshot['messages'] if m.get('role') == 'assistant']
    require(equal(assistants, decoded_messages), 'terminal_assistant_messages_not_original_deliveries')
    finals = [c for c in observations if c['tool_choice'] == 'none']
    require(len(finals) <= 1 and (not finals or finals[0] is observations[-1]), 'final_request_not_unique_last_call')
    abort = snapshot.get('termination_reason')
    safe_abort = abort if abort in ('Maximum evaluations reached', 'Time budget exceeded', 'Prompt token budget exceeded',
        'Context token budget exceeded', 'Maximum steps reached', 'Model completion token limit reached',
        'Native tool calls received in text protocol', 'Exactly one native tool call is allowed per decision',
        'Text Action is not a native function call', 'LLM returned empty response', 'Missing Action directive') else 'other_or_parameterized_loop_reason'
    result = {'mechanism': 'unknown', 'unknown_reasons': [], 'initial_abort_reason': safe_abort,
        'initial_abort_reason_sha256': sha(dump(abort)),
        'final_request_delivered': None, 'final_call_index': None, 'final_request_id': None,
        'local_context_cap': context_cap, 'local_prompt_usage_cap': None,
        'context_gate': {'checked': False, 'schema_estimate': None, 'trimmed_messages_estimate': None, 'would_admit': None},
        'loop_rejection_branch': None, 'call_observations': observations,
        'scope': 'proximal frozen execution mechanism; no counterfactual budget improvement claim'}
    failures = snapshot['protocol_failures']
    require(all(type(f.get('llm_call_index')) is int and 1 <= f['llm_call_index'] <= count and type(f.get('forced')) is bool for f in failures), 'protocol_failure_call_mismatch')
    require(len({f['llm_call_index'] for f in failures}) == len(failures), 'duplicate_protocol_failure')
    if finals:
        final = finals[0]
        require(count == steps + 1, 'forced_request_step_accounting_mismatch')
        f = final['response']
        branch = 'tools_disabled' if f['tool_call_count'] else 'length' if f['length_reported'] else 'text_action' if f['text_action_detected'] else 'empty' if not f['decoder_text_nonempty'] else None
        require(branch is not None, 'nonempty_accepted_final_cannot_be_missing')
        matches = [v for v in failures if v['llm_call_index'] == count and v['forced'] is True]
        require(len(matches) == 1 and matches[0].get('reason') == FORCED_REASONS[branch]
                and matches[0].get('finish_reason') == raws[final['delivered_request_id']]['response_json']['choices'][0].get('finish_reason'), 'recorded_forced_rejection_mismatch')
        result.update(final_request_delivered=True, final_call_index=count,
                      final_request_id=final['delivered_request_id'], loop_rejection_branch=branch)
        result['mechanism'] = {'tools_disabled': 'forced_response_tools_rejected', 'text_action': 'forced_text_action_rejected',
                               'empty': 'forced_response_empty_decoder_text', 'length': 'forced_length_nonempty_text_rejected' if f['decoder_text_nonempty'] else 'forced_length_empty_decoder_text'}[branch]
        if f['completion_tokens'] is None:
            result['unknown_reasons'].append('completion_usage_missing_cannot_confirm_output_limit_exhaustion')
    else:
        require(count == steps, 'unobserved_forced_call_count_mismatch')
        require(not any(f['forced'] for f in failures), 'forced_rejection_without_forced_request')
        result['final_request_delivered'] = False
        note = 'System: Loop aborted (' + (snapshot.get('termination_reason') or 'Loop aborted') + '). Respond immediately with Answer: <your final choice> and no other text.'
        tail = snapshot['messages'][-1] if snapshot['messages'] else {}
        if tail.get('role') != 'user' or type(tail.get('content')) is not str or note not in tail['content']:
            result['unknown_reasons'].append('forced_final_note_not_bound_in_terminal_history')
        elif system != 'poolact' or context_cap is None:
            result['unknown_reasons'].append('no_applicable_local_context_cap_to_explain_unsent_final')
        elif not observations:
            result['unknown_reasons'].append('no_raw_tool_schema_to_reconstruct_context_gate')
        else:
            last = raws[observations[-1]['delivered_request_id']]['request_payload']
            schemas = last['tools']
            require(all(equal(raws[c['delivered_request_id']]['request_payload']['tools'], schemas) for c in observations), 'tool_schemas_changed')
            schema_estimate = len(json.dumps(schemas, ensure_ascii=False, allow_nan=False)) // 3
            allowance = context_cap - schema_estimate
            estimate = pure.estimate(pure.trim(snapshot['messages'], allowance)) if allowance >= 0 else None
            admits = allowance >= 0 and estimate + schema_estimate <= context_cap
            result['context_gate'] = {'checked': True, 'schema_estimate': schema_estimate,
                                     'trimmed_messages_estimate': estimate, 'would_admit': admits}
            if not admits:
                result['mechanism'] = 'execution_context_cap_prevented_final_request'
            else:
                result['unknown_reasons'].append('reconstructed_context_gate_admits_but_no_final_request')
    if result['mechanism'] == 'unknown' and not result['unknown_reasons']:
        result['unknown_reasons'].append('insufficient_proximal_evidence')
    return result


def closed_inputs(go_ref, reader, d):
    """Reuse the established four-ref sealed-format-audit input contract."""
    go = reader.obj(go_ref)
    require(go.get('schema_version') == 'restart-missing-cause-go-v1' and go.get('issuer') == 'ROOT'
            and go.get('approved') is True and go.get('post_run_and_analysis_frozen') is True,
            'explicit_post_freeze_input_required')
    require(go.get('program_sha256') == sha(Path(__file__).read_bytes()), 'program_pin_mismatch')
    refs = go['inputs']
    require(set(refs) == {'plan', 'execution', 'export_index', 'run_seal'}, 'exact_four_control_refs_required')
    plan, execution, index, seal = [reader.obj(refs[k]) for k in ('plan', 'execution', 'export_index', 'run_seal')]
    require(plan.get('schema_version') == 'restart-executable-plan-v1' and plan.get('mode') == 'formal_mixed'
            and execution.get('schema_version') == 'restart-bounded-study-execution-v1'
            and execution.get('local_workers') == 0 and execution.get('mode') == 'formal_mixed'
            and d.same_ref(execution['plan_ref'], refs['plan']) and execution['run_id'] == plan['config']['run_id'],
            'closed_same_formal_plan_required')
    root = d.path(plan['config']['output_root'])
    require(d.path(refs['execution']['path']) == root / 'execution.json'
            and seal.get('schema_version') == 'restart-closed-run-inventory-v1'
            and seal.get('full_second_read_equal') is True and seal.get('expected_invocations') == 705
            and d.path(seal['run_root']) == root and seal['sealer_source_ref']['sha256'] == d.SEALER_SHA,
            'original_complete_run_seal_required')
    require(all(any(d.same_ref(r, s) for s in seal['control_refs']) for r in (refs['plan'], refs['execution'])), 'seal_controls_mismatch')
    closure = reader.obj(seal['closure_ref'])
    require(closure.get('local_workers') == 0 and closure.get('mode') == 'formal_mixed'
            and closure.get('run_id') == execution['run_id'] and d.same_ref(closure['plan_ref'], refs['plan'])
            and d.same_ref(closure['execution_ref'], refs['execution']), 'closure_binding_mismatch')
    inventory = {}
    for part in seal['file_parts']:
        entries = reader.obj(part)
        require(len(entries) == part['file_count'] and sum(r['bytes'] for r in entries) == part['total_bytes'], 'seal_part_counts')
        for entry in entries:
            absolute = str(root / d.relative(entry['relative_path']))
            require(entry['path'] == absolute and absolute not in inventory, 'seal_path_or_duplicate')
            inventory[absolute] = entry
    require(len(inventory) == seal['file_count'] and sum(r['bytes'] for r in inventory.values()) == seal['total_bytes'], 'seal_total_counts')
    require(str(root / 'execution.json') in inventory and d.same_ref(inventory[str(root / 'execution.json')], refs['execution']), 'execution_not_sealed')
    export_root = d.path(refs['export_index']['path']).parent
    require(set(index['files']) == d.EXPORT_FILES, 'frozen_export_product_set_differs')
    required = {'manifest.json', 'records.json', 'source_index.json', 'EXPORT_EVIDENCE.json', 'input_pins.json'}
    exported = {}
    for name, ref in index['files'].items():
        require(set(ref) == {'sha256', 'bytes'}, 'export_ref_shape')
        blob = reader.ref(dict(ref, path=str(export_root / d.relative(name))))
        if name in required:
            exported[name] = d.load(blob)
    manifest, bundle, sources, evidence, pins = [exported[n] for n in
        ('manifest.json', 'records.json', 'source_index.json', 'EXPORT_EVIDENCE.json', 'input_pins.json')]
    require(equal(manifest, plan['matrix']) and manifest['schema_version'] == 'restart-mixed-matrix-v1'
            and len(plan['jobs']) == 705 and len(manifest['logical_rows']) == 783, 'formal_matrix_scope_differs')
    require(bundle['schema_version'] == 'restart-analysis-records-v1'
            and bundle['manifest_sha256'] == index['files']['manifest.json']['sha256'] == pins['manifest_sha256']
            and pins['records_sha256'] == index['files']['records.json']['sha256'], 'export_bundle_pins_differ')
    require(evidence.get('schema_version') == 'restart-real-export-evidence-v1'
            and evidence.get('exporter_sha256') == d.EXPORTER_SHA and evidence.get('analysis_sha256') == d.ANALYSIS_SHA
            and d.same_ref(evidence['plan_ref'], refs['plan']) and d.same_ref(evidence['execution_ref'], refs['execution'])
            and evidence.get('model_calls') == 0 and evidence.get('scorer_calls') == 0, 'frozen_export_evidence_mismatch')
    observed = {r['path']: r for r in evidence['original_refs']}
    require(len(observed) == len(evidence['original_refs']), 'duplicate_export_ref')
    records = {r['logical_id']: r for r in bundle['records']}
    jobs = {j['invocation_id']: j for j in plan['jobs']}
    reports = {r['invocation_id']: r for r in execution['reports']}
    require(len(records) == len(bundle['records']) == 783 and set(records) == {r['logical_id'] for r in manifest['logical_rows']}
            and len(jobs) == 705 and set(jobs) == {r['invocation_id'] for r in manifest['logical_rows']}, 'logical_owner_scope_differs')
    started, unstarted = execution['started_invocation_ids'], execution['unstarted_invocation_ids']
    require(len(reports) == len(execution['reports']) == len(started) == len(set(started))
            and set(reports) == set(started) and len(unstarted) == len(set(unstarted))
            and not set(started) & set(unstarted) and set(started) | set(unstarted) == set(jobs), 'closed_execution_partition_differs')
    def original(ref):
        name = ref['path']
        require(name in inventory and name in observed and d.same_ref(ref, inventory[name])
                and d.same_ref(ref, observed[name]), 'original_not_bound_by_seal_and_export')
        return reader.obj(ref)
    return go, plan, manifest, records, sources, reports, jobs, original, inventory


def snapshot_for(events, seed, pool, agent_id, original):
    candidates = []
    for ref, event in events:
        owner = event.get('owner', {})
        if event.get('event') != 'loop_terminal':
            continue
        matches = (owner.get('runner') == 'poolact' and type(owner.get('seed')) is int and owner.get('seed') == seed
                   and type(owner.get('agent_id')) is int and owner.get('agent_id') == agent_id
                   and owner.get('strategy') == original.get('strategy')) if pool else (
                   owner.get('runner') == 'expgym' and type(owner.get('job', {}).get('seed')) is int
                   and owner.get('job', {}).get('seed') == seed)
        if matches:
            require(event.get('schema_version') == 'expgym.terminal-evidence.v1'
                    and event.get('completion_marker') is False and event.get('score_acceptance_authority') is False
                    and event.get('payload', {}).get('capture_point') == 'raw_return_before_caller_and_scorer_mutations', 'raw_terminal_capture_contract')
            candidates.append((ref, event['payload']['loop_result']))
    require(len(candidates) == 1, 'raw_terminal_snapshot_not_unique')
    ref, snapshot = candidates[0]
    require(snapshot.get('answer') is None, 'raw_terminal_answer_not_missing')
    if pool:
        for key in ('messages', 'usage_attempts', 'protocol_failures', 'api_calls', 'agent_steps',
                    'http_request_attempts', 'aborted', 'termination_reason', 'tool_protocol'):
            require(equal(snapshot.get(key), original.get(key)), 'raw_postscore_loop_evidence_differs')
    else:
        for key in ('protocol_failures', 'agent_steps', 'http_request_attempts', 'tool_protocol'):
            require(equal(snapshot.get(key), original['outcome'].get(key)), 'raw_trace_outcome_differs')
        captured = snapshot.get('_trace_v2_capture', {}).get('llm_calls')
        require(type(captured) is list and len(captured) == len(original['llm_calls']), 'raw_trace_capture_missing')
        for a, b in zip(captured, original['llm_calls']):
            require(all(equal(a.get(k), b.get(k)) for k in ('forced', 'finish_reason', 'output_message', 'attempt_usage')), 'raw_trace_capture_differs')
    return ref, snapshot


def wire_bind(observations, raws, raw_refs, wire_events):
    """Join the source ledger order to this client's physical wire sequence."""
    cid = next(iter(raws.values()))['client_id'] if raws else None
    starts, ends = {}, {}
    for ref, event in wire_events:
        if event.get('source_client_id') != cid:
            continue
        kind = event.get('kind')
        if kind in ('attempt_start', 'attempt_terminal'):
            target = starts if kind == 'attempt_start' else ends
            sequence = event.get('attempt_sequence')
            require(type(sequence) is int and sequence > 0 and sequence not in target, 'duplicate_wire_sequence')
            target[sequence] = (ref, event)
    attempts = [a for c in observations for a in c['attempts']]
    require(set(starts) == set(ends) and len(starts) == len(attempts), 'owner_wire_ledger_coverage_differs')
    for attempt, sequence in zip(attempts, sorted(starts)):
        rid = attempt['request_id']
        raw = raws[rid]
        sr, start = starts[sequence]
        er, end = ends[sequence]
        body = json.dumps(raw['request_payload']).encode('utf-8')
        require(start.get('request_body_sha256') == end.get('request_body_sha256') == sha(body)
                and start.get('request_bytes') == end.get('request_bytes') == len(body)
                and start.get('source_client_id') == end.get('source_client_id') == cid
                and start.get('seed') == end.get('seed') == raw['request_payload']['seed'], 'wire_request_byte_identity_differs')
        attempt.update(raw_ref=raw_refs[rid], wire_start_ref=sr, wire_terminal_ref=er)
        if raw['state'] == 'success':
            response = raw['response_raw'].encode('utf-8')
            require(end.get('state') == 'bytes_returned' and end.get('error_type') is None
                    and end.get('response_bytes_sha256') == sha(response)
                    and end.get('response_bytes') == len(response), 'wire_response_bytes_differ')
            call = next(c for c in observations if c['delivered_request_id'] == rid)
            call['response'].update(wire_request_body_sha256=sha(body), wire_response_bytes_sha256=sha(response))


def audit(go_ref, reader):
    d = dependency('format_diagnostics_candidate_v2/diagnostics.py')
    e = dependency('exporter_candidate_v2/exporter.py')
    for name, pin in DEPENDENCIES.items():
        reader.ref({'path': str(HERE.parent / name), 'sha256': pin})
    go, plan, manifest, records, sources, reports, jobs, original, inventory = closed_inputs(go_ref, reader, d)
    repo = d.path(plan['config']['repo_root'])
    require(repo == SOURCE, 'fixed_v5_source_required')
    pure = pure_source(reader, repo)
    output_schema = reader.obj({'path': str(HERE / 'output.schema.json'), 'sha256': OUTPUT_SCHEMA_SHA})
    run_id = plan['config']['run_id']
    all_clients, all_requests, all_generations, missing, states = set(), set(), set(), [], Counter()
    observed_agents, unavailable_agents, expected_missing = 0, 0, 0
    cache = {}
    for row in manifest['logical_rows']:
        record = records[row['logical_id']]
        state = record['state']
        require(state in ('terminal', 'not_started', 'infrastructure_error', 'integrity_error'), 'unknown_logical_state')
        n = len(row['sampling_seed_labels'])
        states[state] += n
        if state != 'terminal':
            unavailable_agents += n
            continue
        iid, pool = row['invocation_id'], row['system'] == 'poolact'
        wrapped = reports[iid]
        require(wrapped['decision'].get('continue') is True
                and all(wrapped['report'].get(k) is True for k in ('raw_integrity_complete', 'execution_evidence_complete', 'artifact_integrity_complete')), 'terminal_report_not_complete')
        names = row['agent_artifacts'] if pool else [row['result_artifact']]
        require(len(names) == n and len(set(names)) == n and (n == 4 if pool else n == 1), 'expected_agent_inventory_differs')
        for aid, (name, seed) in enumerate(zip(names, row['sampling_seed_labels'])):
            require(type(seed) is int, 'planned_sampling_seed_not_integer')
            absolute = str(Path(plan['config']['output_root']) / d.relative(name))
            require(sources.get(name) == absolute and name in record['source_sha256'], 'agent_source_ref_missing')
            ref = {'path': absolute, 'sha256': record['source_sha256'][name]}
            agent = original(ref)
            value = agent if pool else agent['outcome']
            status = value.get('terminal_status', {})
            require(value.get('missing_final_policy') == POLICY and value.get('terminal_origin') == 'normal_loop_return'
                    and value.get('terminal_scenario') == row['scenario'] and status.get('execution_complete') is True
                    and type(status.get('expected_model_terminals')) is int and type(status.get('reported_model_terminals')) is int
                    and status.get('expected_model_terminals') == status.get('reported_model_terminals') == 1,
                    'unqualified_observed_terminal')
            require('answer' in value and (value['answer'] is None or type(value['answer']) is str), 'answer_not_explicit')
            is_missing = value['answer'] is None
            require(type(status.get('model_no_answer_count')) is int and status.get('model_no_answer_count') == int(is_missing)
                    and status.get('terminal_classification') == ('model_no_answer' if is_missing else 'completed_scored'), 'typed_missing_status_differs')
            metadata = agent['api_dump'] if pool else agent['run']['api_dump']
            cid = metadata['client_id']
            require(cid not in all_clients and metadata['run_id'] == run_id, 'model_terminal_client_reused')
            all_clients.add(cid)
            observed_agents += 1
            expected_missing += int(is_missing)
            if not is_missing:
                continue
            facts = e.agent_telemetry(agent, pool=pool, expected_seed=seed, run_id=run_id)
            report = wrapped['report']
            if iid not in cache:
                audit_ref = report['raw_audit_ref']
                raw_audit = original(audit_ref)
                require(raw_audit.get('schema_version') == 'restart-raw-wire-audit-v1' and raw_audit.get('verified') is True
                        and raw_audit.get('errors') == [], 'original_raw_audit_not_verified')
                raw_by_client, refs_by_request, events = {}, {}, []
                for item in raw_audit['inventory']:
                    value_raw = original(item)
                    if item['kind'] == 'raw':
                        rid = value_raw['request_id']
                        require(rid not in refs_by_request, 'duplicate_job_raw_request')
                        refs_by_request[rid] = {k: item[k] for k in ('path', 'sha256', 'bytes')}
                        raw_by_client.setdefault(value_raw['client_id'], {})[rid] = value_raw
                    elif item['kind'] == 'wire':
                        events.append(({k: item[k] for k in ('path', 'sha256', 'bytes')}, value_raw))
                    else:
                        raise ValueError('unknown_raw_inventory_role')
                terminal_events = [(r, original(r)) for r in report['original_terminal_evidence']]
                cache[iid] = (audit_ref, raw_by_client, refs_by_request, events, terminal_events)
            audit_ref, raw_by_client, raw_refs, events, terminal_events = cache[iid]
            raw = raw_by_client.get(cid, {})
            require({a['request_id'] for a in facts['attempts']} == set(raw), 'owner_raw_ledger_inventory_differs')
            require(not all_requests & set(raw), 'request_claimed_by_two_missing_agents')
            all_requests.update(raw)
            gids = {r['generation_id'] for r in raw.values()}
            require(not all_generations & gids, 'generation_claimed_by_two_missing_agents')
            all_generations.update(gids)
            snapshot_ref, snapshot = snapshot_for(terminal_events, seed, pool, aid, agent)
            calls = snapshot['usage_attempts']
            require(equal([a for c in calls for a in c['attempts']], facts['attempts']), 'snapshot_original_attempt_ledger_differs')
            context_cap = plan['config']['policy']['max_context_tokens'] if pool else None
            if pool:
                result_name = row['result_artifact']
                result = original({'path': sources[result_name], 'sha256': record['source_sha256'][result_name]})
                require(result['config']['max_context_tokens'] == context_cap, 'pool_context_config_differs')
            classified = classify(snapshot, calls, raw, {'client_id': cid, 'seed': seed, 'model_id': row['model_id'], 'run_id': run_id}, pure,
                                  system=row['system'], context_cap=context_cap, exp_calls=agent['llm_calls'] if not pool else None)
            wire_bind(classified['call_observations'], raw, raw_refs, events)
            classified.update(logical_id=row['logical_id'], invocation_id=iid, agent_id=aid, seed=seed, client_id=cid,
                system=row['system'], scenario=row['scenario'], regime=row['regime'], strategy=row['strategy'],
                artifact_ref=ref, raw_terminal_ref=snapshot_ref, original_raw_audit_ref=audit_ref,
                terminal_answer_is_none=True, answer_or_score_modified=False)
            missing.append(classified)
        # Job evidence can be large. Retain it only until this job's next row;
        # all Reader refs remain, but no whole-run raw payload cache is needed.
        if iid in cache and not any(r['invocation_id'] == iid for r in manifest['logical_rows'][manifest['logical_rows'].index(row) + 1:]):
            cache.pop(iid)
    expected_job_missing = sum(r['report']['terminal_status']['model_no_answer_count'] for r in reports.values() if r['decision'].get('continue') is True)
    require(expected_missing == len(missing) == expected_job_missing, 'missing_terminal_coverage_mismatch')
    coverage = {'planned_logical_rows': len(manifest['logical_rows']), 'planned_agents': sum(states.values()),
        'observed_agents': observed_agents, 'unavailable_agents_excluded_from_missing': unavailable_agents,
        'agent_states': dict(states), 'missing_terminals': len(missing), 'all_missing_uniquely_attributed': True,
        'mechanism_counts': dict(Counter(r['mechanism'] for r in missing)),
        'mechanism_unknown': sum(r['mechanism'] == 'unknown' for r in missing),
        'with_any_unknown_subfield': sum(bool(r['unknown_reasons']) for r in missing)}
    provenance = {'schema_version': SCHEMA, 'input_refs': list(reader.refs.values()),
        'dependency_sha256': DEPENDENCIES, 'source_sha256': PINS, 'program_sha256': go['program_sha256'],
        'model_calls': 0, 'scorer_calls': 0, 'loop_executions': 0, 'source_clients_constructed': 0,
        'raw_answers_or_reasoning_exported': False, 'primary_scores_or_denominators_modified': False,
        'counterfactual_budget_claim': False, 'causality_scope': 'proximal mechanism only',
        'provider_quiescence_proven_by_this_tool': False, 'fresh_independent_output_audit': 'required'}
    product = {'schema_version': SCHEMA, 'rows': missing}
    require(not pure.schema_errors(product, output_schema, output_schema, 'missing_causes'), 'output_schema_validation_failed')
    files = {'missing_causes.json': dump(product),
             'coverage.json': dump(coverage), 'PROVENANCE.json': dump(provenance),
             'SUMMARY.zh.md': ('# 缺答近端机制审计\n\n缺答终态 %d 条，机制 unknown %d 条。完整分母不变。\n\n%s\n\n只描述冻结执行路径，不证明增加预算必然改善；原回答、推理及评分不修改、不复制。\n' %
                 (len(missing), coverage['mechanism_unknown'], json.dumps(coverage['mechanism_counts'], ensure_ascii=False, sort_keys=True))).encode('utf-8')}
    files['INDEX.json'] = dump({'schema_version': SCHEMA, 'files': {name: {'sha256': sha(blob), 'bytes': len(blob)} for name, blob in files.items()}})
    require(set(files) == set(FILES), 'fixed_output_set_differs')
    return files, provenance


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--go', required=True)
    parser.add_argument('--go-sha256', required=True)
    args = parser.parse_args()
    d = dependency('format_diagnostics_candidate_v2/diagnostics.py')
    reader = d.Reader()
    ref = {'path': args.go, 'sha256': args.go_sha256}
    go = reader.obj(ref)
    output = d.path(go['output_dir'])
    require(not output.exists() and output.parent.is_dir() and output.parent.resolve() == output.parent, 'fresh_nonalias_output_required')
    for control in go['inputs'].values():
        root = d.path(control['path']).parent
        require(output != root and root not in output.parents and output not in root.parents, 'output_overlaps_input_controls')
    require(SOURCE != output and SOURCE not in output.parents and output not in SOURCE.parents, 'output_overlaps_frozen_source')
    files, provenance = audit(ref, reader)
    output.mkdir(exist_ok=False)
    for name in FILES:
        with (output / name).open('xb') as handle:
            handle.write(files[name])
    print(json.dumps({'written': True, 'files': list(FILES), 'model_calls': 0, 'fresh_independent_output_audit': 'required'}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
