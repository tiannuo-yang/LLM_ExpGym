# 缺答近端分类独立复核：预先反例

状态：候选核心尚未就绪；本文件是手工预先设计，不是测试通过凭证。

范围：仅候选源码及最多 8 项人工构造的 CPU 合成核验。不读取 K3/GLM 实际 raw、export、答案、恢复 payload、任务数据或密钥；不调用模型、网络、Slurm、scorer 或原任务 CLI。不修改候选及任何已有冻结文件。本目录由本 peer 独占。

## 预先期望

1. **Final 没有发出。** 正常 loop 终止，但账本没有对应 forced-final 调用。报告未观察到该调用；不得把其他 raw 静默改称 forced-final，也不得把 raw 缺失误报成请求未发。
2. **Length 和非空 content 并存。** 响应 finish_reason 为 length，content 为非空字符串。记录两个事实；不能仅凭 length 断言“没有 content”或“32k 上限导致缺答”。实际 parser 行为只能依冻结源分支验证。
3. **非普通文本形状。** reasoning 非空、content null/空串/缺字段/list、refusal 字段分别构造。缺字段、null、空串、非字符串不得混成同一种传输事实；不能拿 reasoning/refusal/list 凑成原 answer。
4. **Retry。** 同一 generation 的早次尝试异常，后次成功；与文件排序无关。使用原账本/状态选择被接受 attempt，不把早次 length 或异常作为最终响应。
5. **Owner 冲突。** request_id 能连接，但 client/seed/generation/attempt 不匹配，或同一 raw 被两 agent 认领。必须完整性拒绝或明确 unavailable，不产生模型原因。
6. **缺 raw / 多余 raw。** 账本明确存在最后调用但对应 raw 缺失，或存在未归属 raw。不能降格为 final 未发，不能默默忽略从而报告完整分类。
7. **Infrastructure null。** 非正常执行、未开始或异常退出且 answer=null。不得进入已观察正常 model_no_answer 原因分母；原错误保留。
8. **最后调用与历史标志混淆。** 较早 length 后最终 forced-none/stop/空 content，或反向顺序。逐调用事实可共存，近端终态只能与真正最后接受调用连接；累计 usage=32768 不证明单次请求撞上生成上限。

以上期望独立于候选分类函数；后续不复制候选判断逻辑作为 oracle。精确结构/字段名在只读完整候选后适配，若候选不支持某边界则报告未覆盖，不伪造通过。
