#!/usr/bin/env python3
"""Closed v5 Pool Search/Audit format diagnostics, never scoring or model calls."""
import argparse
from collections import Counter
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
import re
import stat
import statistics

SOURCE_PINS = {
    "expgym/poolact.py": "3638b3f75fc253e6a971c409e116fc352512984bccb24892d3d62a6d7fc834d2",
    "expgym/task_restricted_search.py": "5cf8d0ea856279f3fd982a60d947c37511242292c26c631cf6f84e6bb479c098",
    "expgym/task_evidence_audit.py": "f874e36965e087d9771aca23bfdf221b00c86d63060b6c8f79e364b52a19c536",
}
EXPORTER_SHA = "c70319b2c1cd586859572f7c4d066acb847c36ef2424e84027553aa72346747c"
ANALYSIS_SHA = "5df8525973261d61b5c3c373945129db22979131e6ce3b586c8913efeed256bf"
SEALER_SHA = "1d30bf17c4cbe19fea21c2d65ab50e83db4aed9770ae6d1320c2fb3c34a424f2"
EXPORT_FILES = {"SUMMARY.zh.md", "results.json", "provenance.json", "metrics.csv", "effects.csv",
                "paired_rows.csv", "raw_terminals.csv", "logical_outcomes.csv", "known_subsets.csv",
                "OUTPUT_INDEX.json", "records.json", "manifest.json", "input_pins.json", "oracle.json",
                "source_index.json", "EXPORT_EVIDENCE.json"}
SCENARIOS = {"restricted_search": 234, "evidence_audit": 78}
STATES = {"terminal", "not_started", "infrastructure_error", "integrity_error"}
TERMINAL_FIELDS = ("answer", "scoring_input", "score_status", "terminal_status",
                   "missing_final_policy", "terminal_origin", "terminal_scenario",
                   "answer_perf", "answer_metrics", "score_check")


def require(condition, code):
    if not condition:
        raise ValueError(code)


def dump(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode()


def sha(blob):
    return hashlib.sha256(blob).hexdigest()


def load(blob):
    def pairs(values):
        obj = {}
        for key, value in values:
            require(key not in obj, "duplicate_control_or_artifact_json_key")
            obj[key] = value
        return obj
    return json.loads(blob, object_pairs_hook=pairs,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError("nonfinite_json")))


def path(value):
    require(type(value) is str, "path_string_required")
    p = Path(value)
    require(p.is_absolute() and ".." not in p.parts, "absolute_nonalias_path_required")
    require(not any(s in p.name.lower() for s in ("secret", "credential", "password", "api_key", "id_rsa", ".env")),
            "credential_like_input_forbidden")
    return p


def relative(value):
    require(type(value) is str and value and not Path(value).is_absolute()
            and ".." not in Path(value).parts and str(Path(value)) == value, "unsafe_relative_path")
    return value


def same_ref(a, b):
    return all(a.get(k) == b.get(k) for k in ("path", "sha256"))


class Reader:
    """No discovery; bounded per-read bytes, observed refs, no payload cache."""
    def __init__(self, read=None):
        self.read = read or self.disk
        self.refs = {}
        self.total_bytes = 0
        self.max_file_bytes = 64 * 1024**2
        self.max_total_bytes = 8 * 1024**3

    def disk(self, value):
        p = path(value)
        require(p.resolve() == p, "symlink_or_alias_input_forbidden")
        before = p.lstat()
        require(stat.S_ISREG(before.st_mode) and before.st_size <= self.max_file_bytes,
                "nonregular_or_oversized_input")
        signature = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
        fd = os.open(p, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(fd, "rb") as stream:
            require(signature(before) == signature(os.fstat(stream.fileno())), "input_changed_before_read")
            blob = stream.read(self.max_file_bytes + 1)
            require(signature(before) == signature(os.fstat(stream.fileno())) == signature(p.lstat()),
                    "input_changed_during_read")
        return blob

    def ref(self, ref):
        p = str(path(ref["path"]))
        blob = self.read(p)
        require(type(blob) is bytes and len(blob) <= self.max_file_bytes, "input_file_limit")
        self.total_bytes += len(blob)
        require(self.total_bytes <= self.max_total_bytes, "input_total_limit")
        observed = {"path": p, "sha256": sha(blob), "bytes": len(blob)}
        require(observed["sha256"] == ref["sha256"] and
                ("bytes" not in ref or ref["bytes"] == len(blob)), "input_byte_pin_mismatch")
        require(p not in self.refs or self.refs[p] == observed, "input_changed_between_reads")
        self.refs[p] = observed
        return blob

    def obj(self, ref):
        return load(self.ref(ref))


def answer_text(answer):
    require(answer is None or type(answer) is str, "answer_not_string_or_null")
    return answer or ""


def search_sets(answer):
    """Exact frozen parser semantics, no gold, metric, or alternative winner."""
    text = answer_text(answer)
    stripped = text.strip()
    try:
        parsed = json.loads(stripped)
    except (ValueError, TypeError):
        parsed = None
    is_list = isinstance(parsed, list)
    parts = [str(v) for v in parsed] if is_list else re.split(r"[,;\n]", stripped)
    normalize = lambda s: " ".join(s.lower().split())
    clean = lambda s: re.sub(r"^\s*\d+[.)]\s*", "", s).strip().strip("-*•").strip()
    vote = tuple(sorted({normalize(clean(p)) for p in parts if str(p).strip()} - {""}))
    if is_list:
        scorer = tuple(sorted({normalize(str(v)) for v in parsed if str(v).strip()}))
    else:
        scorer = tuple(sorted({normalize(clean(p)) for p in re.split(r"[,;\n]", text)
                               if 1 <= len(clean(p).split()) <= 5}))
    flags = {"missing_answer": answer is None, "empty_nonmissing": answer is not None and not stripped,
             "json_list": is_list, "non_json_list": bool(stripped) and not is_list,
             "numbered_or_bullet_fragment": any(clean(p) != p.strip() for p in parts),
             "nonstring_json_member": is_list and any(not isinstance(v, str) for v in parsed),
             "long_fragment_filtered_by_scorer": not is_list and any(len(clean(p).split()) > 5 for p in parts),
             "json_member_longer_than_five_words": is_list and any(len(str(v).split()) > 5 for v in parsed),
             "vote_set_differs_from_scorer_set": vote != scorer}
    return vote, scorer, flags


def classes(values):
    seen = []
    result = []
    for value in values:
        if value not in seen:
            seen.append(value)
        result.append(seen.index(value))
    return result


def search_pool(answers, aggregate_answer):
    parsed = [search_sets(a) for a in answers]
    keys, scorer = [v[0] for v in parsed], [v[1] for v in parsed]
    counts = Counter(keys)
    winning = max(counts, key=lambda k: (counts[k], bool(k), -keys.index(k)))
    selected = keys.index(winning)
    require(aggregate_answer == answer_text(answers[selected]), "stored_search_aggregate_not_frozen_winner")
    pairs = [{"agents": [i, j], "scorer_set_equal_vote_key_split": scorer[i] == scorer[j] and keys[i] != keys[j],
              "vote_key_equal_scorer_set_merge": keys[i] == keys[j] and scorer[i] != scorer[j]}
             for i, j in itertools.combinations(range(4), 2)]
    supporters = [i for i in range(4) if keys[i] == winning]
    top = [k for k, n in counts.items() if n == counts[winning]]
    flag = {"scorer_set_split_present": any(p["scorer_set_equal_vote_key_split"] for p in pairs),
            "vote_key_merge_present": any(p["vote_key_equal_scorer_set_merge"] for p in pairs),
            "winning_key_scorer_disagreement": len({scorer[i] for i in supporters}) > 1,
            "vote_count_tie": len(top) > 1,
            "nonempty_tie_preference_applies": () in top and any(bool(k) for k in top),
            "strict_majority": counts[winning] > 2}
    return {"agent_flags": [v[2] for v in parsed], "pairs": pairs,
            "vote_key_class_by_agent": classes(keys), "scorer_set_class_by_agent": classes(scorer),
            "vote_set_sizes": [len(k) for k in keys], "scorer_set_sizes": [len(s) for s in scorer],
            "selected_agent_index": selected, "winning_supporter_indices": supporters,
            "selected_is_earliest_input_supporter": True, "aggregate_original_string_match": True,
            "flags": flag,
            "format_boundary_present": any(f[2]["vote_set_differs_from_scorer_set"] for f in parsed)
                                       or flag["scorer_set_split_present"] or flag["vote_key_merge_present"]}


def canonical_label(value):
    raw = re.sub(r"[^a-z]", "", str(value or "").lower())
    return {"entailment": "Entailment", "entailed": "Entailment", "contradiction": "Contradiction",
            "contradicted": "Contradiction", "notmentioned": "NotMentioned", "neutral": "NotMentioned"}.get(raw, str(value or "").strip())


def vote_evidence(value):
    if not isinstance(value, list):
        return ()
    normalized = set()
    for item in value:
        try:
            normalized.add(int(item))
        except (TypeError, ValueError, OverflowError):
            normalized.add(str(item))
    return tuple(sorted(normalized, key=lambda item: (str(type(item)), str(item))))


def scorer_evidence(value):
    try:
        return set(int(v) for v in value), False
    except Exception:
        return set(), True


def audit_parse(answer):
    text = answer_text(answer)
    fallback = False
    try:
        scored = json.loads(text)
    except (ValueError, RecursionError, OverflowError):
        fallback = True
        cleaned = text.strip().rstrip(";").strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.split("\n", 1)[-1].rsplit("```", 1)[0].strip()
        try:
            scored = json.loads(cleaned)
        except (ValueError, RecursionError, OverflowError):
            scored = None
    try:
        voted = json.loads(text)
    except (ValueError, TypeError):
        voted = None
    scorer_dict, vote_dict = isinstance(scored, dict), isinstance(voted, dict)
    return (scored if scorer_dict else {}, voted if vote_dict else {},
            {"missing_answer": answer is None, "empty_nonmissing": answer is not None and not text.strip(),
             "starts_markdown_fence": text.strip().startswith("```"),
             "ends_semicolon": text.strip().endswith(";"), "scorer_fallback_used": fallback,
             "scorer_accepts_object": scorer_dict, "vote_accepts_object": vote_dict,
             "scorer_accepts_vote_rejects": scorer_dict and not vote_dict})


def evidence_flags(entry):
    value = entry.get("evidence_ids", [])
    scored, invalid = scorer_evidence(value)
    voted = vote_evidence(entry.get("evidence_ids"))
    malformed = False
    for item in value if isinstance(value, list) else []:
        try:
            int(item)
        except (TypeError, ValueError, OverflowError):
            malformed = True
    label = entry.get("label")
    public = {"Entailment", "Contradiction", "NotMentioned"}
    return {"label_changes_under_canonicalization": label != canonical_label(label),
            "original_public_label": isinstance(label, str) and label in public,
            "normalized_to_public_label": label != canonical_label(label) and canonical_label(label) in public,
            "canonical_label_is_public_label": canonical_label(label) in public,
            "label_missing": "label" not in entry,
            "label_unknown_after_canonicalization": canonical_label(label) not in public,
            "evidence_nonlist_explicit": "evidence_ids" in entry and not isinstance(value, list),
            "evidence_missing": "evidence_ids" not in entry,
            "evidence_explicit_empty_list": "evidence_ids" in entry and value == [],
            "evidence_list_has_nonint_types": isinstance(value, list) and any(type(v) is not int for v in value),
            "evidence_list_deduplicated": isinstance(value, list) and len(voted) < len(value),
            # Answer strings use json.loads' historical NaN/Infinity acceptance;
            # compare representation locally without emitting those values.
            "evidence_list_reordered_or_coerced": isinstance(value, list) and
                json.dumps(value, sort_keys=True) != json.dumps(list(voted), sort_keys=True),
            "evidence_invalid_list_member": malformed, "scorer_whole_evidence_set_fell_back_empty": invalid,
            "scorer_evidence_differs_from_vote_key": scored != set(voted)}


def audit_pool(answers, aggregate_answer):
    parsed = [audit_parse(a) for a in answers]
    scorer, voted = [p[0] for p in parsed], [p[1] for p in parsed]
    hids = sorted(set().union(*(set(s) | set(v) for s, v in zip(scorer, voted))))
    reconstructed, hypothesis_rows = {}, []
    per_agent = [dict(p[2]) for p in parsed]
    for i in range(4):
        valid = [evidence_flags(v) for v in voted[i].values() if isinstance(v, dict)]
        scored_valid = [evidence_flags(v) for v in scorer[i].values() if isinstance(v, dict)]
        per_agent[i].update({"vote_object_hypothesis_keys": len(voted[i]),
                             "scorer_object_hypothesis_keys": len(scorer[i]),
                             "scorer_valid_entry_count": len(scored_valid),
                             "vote_valid_entry_count": len(valid),
                             "vote_invalid_entry_count": sum(not isinstance(v, dict) for v in voted[i].values()),
                             "scorer_entry_flags_counts": dict(Counter(k for row in scored_valid for k, value in row.items() if value)),
                             "entry_flags_counts": dict(Counter(k for row in valid for k, value in row.items() if value))})
    for ordinal, hid in enumerate(hids):
        entries = [(i, voted[i][hid]) for i in range(4) if isinstance(voted[i].get(hid), dict)]
        labels = [canonical_label(e.get("label")) for _, e in entries]
        row = {"observed_hypothesis_ordinal": ordinal,
               "scorer_key_present_by_agent": [hid in s for s in scorer],
               "vote_key_present_by_agent": [hid in v for v in voted],
               "scorer_entry_present_by_agent": [isinstance(s.get(hid), dict) for s in scorer],
               "vote_entry_present_by_agent": [isinstance(v.get(hid), dict) for v in voted]}
        if labels:
            label_counts = Counter(labels)
            winning = label_counts.most_common(1)[0][0]
            supporters = [(i, e) for (i, e), label in zip(entries, labels) if label == winning]
            ev = [vote_evidence(e.get("evidence_ids")) for _, e in supporters]
            winning_ev = Counter(ev).most_common(1)[0][0]
            reconstructed[hid] = {"label": winning, "evidence_ids": list(winning_ev)}
            row.update(label_class_by_voting_entry=classes(labels), voting_agent_indices=[i for i, _ in entries],
                       label_supporter_indices=[i for i, _ in supporters],
                       evidence_supporter_indices=[i for (i, _), v in zip(supporters, ev) if v == winning_ev],
                       evidence_class_by_label_supporter=classes(ev),
                       first_winning_label_supporter=next(i for (i, _), label in zip(entries, labels) if label == winning),
                       first_winning_evidence_supporter=next(i for (i, _), v in zip(supporters, ev) if v == winning_ev),
                       label_tie=sum(c == max(label_counts.values()) for c in label_counts.values()) > 1,
                       evidence_tie=sum(c == max(Counter(ev).values()) for c in Counter(ev).values()) > 1,
                       label_canonicalization_among_winners=any(e.get("label") != winning for _, e in supporters),
                       evidence_parser_disagreement_among_winners=any(evidence_flags(e)["scorer_evidence_differs_from_vote_key"] for _, e in supporters))
        hypothesis_rows.append(row)
    # This reproduces only the declared existing vote to bind its structural flags;
    # it never invokes a gold/evaluator, alternate normalization, or alternate vote.
    require(aggregate_answer == json.dumps(reconstructed, sort_keys=True), "stored_audit_aggregate_not_frozen_vote")
    boundary = any(a["scorer_accepts_vote_rejects"] or a["entry_flags_counts"].get("label_changes_under_canonicalization", 0)
                   or a["entry_flags_counts"].get("scorer_evidence_differs_from_vote_key", 0) for a in per_agent)
    return {"agent_flags": per_agent, "hypotheses": hypothesis_rows,
            "observed_hypothesis_union_count": len(hids), "gold_hypothesis_denominator": None,
            "hypothesis_ordinal_basis": "sorted union of answer keys, not gold or task completeness",
            "aggregate_frozen_vote_match": True, "format_boundary_present": bool(boundary)}


def scores(payload, agents, scenario):
    keys = ("f1",) if scenario == "restricted_search" else ("label_acc", "evidence_acc")
    result = {}
    for key in keys:
        values = [a["answer_perf"] if key == "f1" else a["answer_metrics"][key] for a in agents]
        mv = payload["aggregate"]["answer_perf"] if key == "f1" else payload["aggregate"]["answer_metrics"][key]
        require(all(type(v) in (int, float) and math.isfinite(v) and 0 <= v <= 1 for v in values + [mv]),
                "reported_score_not_finite_unit_interval")
        mi = statistics.mean(values)
        result[key] = {"original_individual_scores": values, "original_aggregate_score": mv,
                       "reported_score_mi": mi, "reported_mv_minus_mi": mv - mi}
    return result


def pool_diagnostics(row, record, payload, agents):
    require([a.get("agent_id") for a in agents] == [0, 1, 2, 3]
            and all(type(a.get("agent_id")) is int for a in agents), "agent_order_mismatch")
    require(len(payload.get("agent_results", [])) == 4, "embedded_agents_missing")
    for expected, embedded in zip(agents, payload["agent_results"]):
        require(expected["agent_id"] == embedded.get("agent_id") and
                all(k in expected and k in embedded and dump(expected[k]) == dump(embedded[k]) for k in TERMINAL_FIELDS),
                "embedded_agent_terminal_disagreement")
        answer = expected["answer"]
        answer_text(answer)
        require(expected["scoring_input"] == ("" if answer is None else answer)
                and expected["score_status"] == ("scored_empty_prediction" if answer is None else "scored_final_answer")
                and expected["missing_final_policy"] == "task-abstention-v1"
                and expected["terminal_origin"] == "normal_loop_return"
                and expected["terminal_scenario"] == row["scenario"], "terminal_projection_mismatch")
    require(payload.get("agents") == 4 and payload.get("strategy") == row["strategy"]
            and payload["config"]["scenario"] == row["scenario"]
            and payload["config"]["cost_regime"] == row["regime"]
            and payload["config"]["model"] == row["model_id"]
            and payload["config"]["agent_seeds"] == row["sampling_seed_labels"], "pool_identity_mismatch")
    for key in ("question_index", "data_source", "cc_split"):
        require(key not in row["selector"] or payload["config"].get(key) == row["selector"][key], "selector_mismatch")
    answers = [a["answer"] for a in agents]
    fn = search_pool if row["scenario"] == "restricted_search" else audit_pool
    structural = fn(answers, payload["aggregate"]["answer"])
    structural["reported_score_context"] = scores(payload, agents, row["scenario"])
    structural["missing_agents"] = sum(a is None for a in answers)
    structural["interpretation"] = "format and reported-score co-occurrence only; no causal attribution or alternate-policy metric"
    return structural


def diagnose(go_ref, reader):
    go = reader.obj(go_ref)
    require(go.get("schema_version") == "restart-format-diagnostics-go-v1" and go.get("issuer") == "ROOT"
            and go.get("approved") is True and go.get("post_run_and_analysis_frozen") is True,
            "explicit_root_post_freeze_authority_required")
    require(go.get("program_sha256") == sha(Path(__file__).read_bytes()), "program_pin_mismatch")
    refs = go["inputs"]
    require(set(refs) == {"plan", "execution", "export_index", "run_seal"}, "exact_four_input_refs_required")
    plan, execution, index, seal = [reader.obj(refs[k]) for k in ("plan", "execution", "export_index", "run_seal")]
    require(plan.get("schema_version") == "restart-executable-plan-v1" and plan.get("mode") == "formal_mixed"
            and execution.get("schema_version") == "restart-bounded-study-execution-v1"
            and execution.get("local_workers") == 0 and execution.get("mode") == "formal_mixed"
            and same_ref(execution["plan_ref"], refs["plan"])
            and execution["run_id"] == plan["config"]["run_id"], "closed_same_formal_plan_required")
    run_root = path(plan["config"]["output_root"])
    require(path(refs["execution"]["path"]) == run_root / "execution.json"
            and seal.get("schema_version") == "restart-closed-run-inventory-v1"
            and seal.get("full_second_read_equal") is True and seal.get("expected_invocations") == 705
            and path(seal["run_root"]) == run_root and seal["sealer_source_ref"]["sha256"] == SEALER_SHA,
            "complete_original_run_seal_required")
    require(all(any(same_ref(r, control) for control in seal["control_refs"]) for r in (refs["plan"], refs["execution"])),
            "seal_plan_execution_binding_mismatch")
    closure = reader.obj(seal["closure_ref"])
    require(closure.get("local_workers") == 0 and closure.get("mode") == "formal_mixed"
            and closure.get("run_id") == execution["run_id"]
            and same_ref(closure["plan_ref"], refs["plan"]) and same_ref(closure["execution_ref"], refs["execution"]),
            "seal_closure_binding_mismatch")
    inventory = {}
    for part in seal["file_parts"]:
        rows = reader.obj(part)
        require(len(rows) == part["file_count"] and sum(r["bytes"] for r in rows) == part["total_bytes"], "seal_part_count_mismatch")
        for entry in rows:
            absolute = str(run_root / relative(entry["relative_path"]))
            require(entry["path"] == absolute and absolute not in inventory, "seal_path_or_duplicate")
            inventory[absolute] = entry
    require(len(inventory) == seal["file_count"] and sum(r["bytes"] for r in inventory.values()) == seal["total_bytes"],
            "seal_whole_counts_mismatch")
    require(str(run_root / "execution.json") in inventory and same_ref(inventory[str(run_root / "execution.json")], refs["execution"]),
            "sealed_execution_missing_or_different")
    export_root = path(refs["export_index"]["path"]).parent
    required = {"manifest.json", "records.json", "source_index.json", "EXPORT_EVIDENCE.json", "input_pins.json"}
    require(set(index["files"]) == EXPORT_FILES, "exact_frozen_export_product_set_required")
    exported = {}
    for name, ref in index["files"].items():
        require(set(ref) == {"sha256", "bytes"}, "exact_export_file_ref_schema_required")
        blob = reader.ref({**ref, "path": str(export_root / relative(name))})
        if name in required:
            exported[name] = load(blob)
    manifest, bundle, sources, evidence, pins = [exported[n] for n in
        ("manifest.json", "records.json", "source_index.json", "EXPORT_EVIDENCE.json", "input_pins.json")]
    require(dump(manifest) == dump(plan["matrix"]) and manifest["schema_version"] == "restart-mixed-matrix-v1"
            and len(plan["jobs"]) == 705 and len(manifest["logical_rows"]) == 783
            and len({j["invocation_id"] for j in plan["jobs"]}) == 705, "full_frozen_matrix_mismatch")
    require(bundle["schema_version"] == "restart-analysis-records-v1"
            and bundle["manifest_sha256"] == index["files"]["manifest.json"]["sha256"]
            and pins["manifest_sha256"] == bundle["manifest_sha256"]
            and pins["records_sha256"] == index["files"]["records.json"]["sha256"], "export_record_manifest_binding_mismatch")
    require(evidence.get("schema_version") == "restart-real-export-evidence-v1"
            and evidence.get("exporter_sha256") == EXPORTER_SHA and evidence.get("analysis_sha256") == ANALYSIS_SHA
            and same_ref(evidence["plan_ref"], refs["plan"]) and same_ref(evidence["execution_ref"], refs["execution"])
            and evidence.get("model_calls") == 0 and evidence.get("scorer_calls") == 0, "frozen_export_evidence_mismatch")
    for rel, digest in SOURCE_PINS.items():
        reader.ref({"path": str(path(plan["config"]["repo_root"]) / rel), "sha256": digest})
    records = {r["logical_id"]: r for r in bundle["records"]}
    require(len(records) == len(bundle["records"]) == 783
            and set(records) == {r["logical_id"] for r in manifest["logical_rows"]}, "all_planned_record_denominators_required")
    job_ids = {j["invocation_id"] for j in plan["jobs"]}
    started, unstarted = execution["started_invocation_ids"], execution["unstarted_invocation_ids"]
    require(len(set(started)) == len(started) and len(set(unstarted)) == len(unstarted)
            and not set(started) & set(unstarted) and set(started) | set(unstarted) == job_ids
            and set(r["invocation_id"] for r in manifest["logical_rows"]) == job_ids,
            "execution_matrix_partition_mismatch")
    observed_refs = {r["path"]: r for r in evidence["original_refs"]}
    require(len(observed_refs) == len(evidence["original_refs"]), "duplicate_export_original_ref")
    target = [r for r in manifest["logical_rows"] if r["system"] == "poolact" and r["scenario"] in SCENARIOS]
    require(Counter(r["scenario"] for r in target) == Counter(SCENARIOS), "exact_search_audit_pool_scope_required")
    model = plan["config"]["model"]["label"]
    output_rows, groups = [], {}
    for row in target:
        require(row["model"] == model and row["regime"] in ("cost_moderate", "cost_tight")
                and row["strategy"] in ("naive", "cached", "poolact")
                and len(row["agent_artifacts"]) == len(row["sampling_seed_labels"]) == 4, "target_row_identity_or_n_mismatch")
        record = records[row["logical_id"]]
        require(record["state"] in STATES, "unknown_record_state")
        require((record["state"] == "not_started") == (row["invocation_id"] in unstarted),
                "record_started_state_mismatch")
        needed = [row["result_artifact"]] + row["agent_artifacts"]
        require(len(set(needed)) == 5 and set(record["source_sha256"]) <= set(needed), "artifact_scope_or_alias_mismatch")
        refs_used, payloads = [], {}
        for name, digest in record["source_sha256"].items():
            absolute = str(run_root / relative(name))
            ref = {"path": absolute, "sha256": digest}
            require(sources.get(name) == absolute and absolute in inventory and absolute in observed_refs
                    and same_ref(inventory[absolute], ref) and same_ref(observed_refs[absolute], ref),
                    "artifact_not_bound_by_seal_export_and_record")
            # Partial/error artifacts are retained as refs; do not promote their
            # answers or scores to a complete N4 endpoint or denominator.
            if record["state"] == "terminal":
                payloads[name] = reader.obj(ref)
            else:
                reader.ref(ref)
            refs_used.append({**ref, "bytes": inventory[absolute]["bytes"]})
        require(record["state"] != "terminal" or set(payloads) == set(needed), "terminal_n4_artifacts_incomplete")
        item = {k: row[k] for k in ("logical_id", "invocation_id", "model", "scenario", "item", "regime", "strategy", "outerrep")}
        item["outerseed"] = "outer_%05d" % row["outerrep"]
        item.update(state=record["state"], reason=record.get("reason"), planned_agents=4,
                    artifact_refs=refs_used, diagnostic_status="unavailable_incomplete_endpoint", structural=None)
        if record["state"] == "terminal":
            item["structural"] = pool_diagnostics(row, record, payloads[row["result_artifact"]],
                                                  [payloads[p] for p in row["agent_artifacts"]])
            item["diagnostic_status"] = "complete_original_n4_diagnosed"
        output_rows.append(item)
        key = (row["model"], row["scenario"], row["regime"], row["strategy"])
        group = groups.setdefault(key, {"model": key[0], "scenario": key[1], "regime": key[2], "strategy": key[3],
            "planned_pools": 0, "planned_agents": 0, "states": Counter(), "diagnosed_pools": 0,
            "diagnosed_agents": 0, "missing_agents": 0, "unavailable_agents": 0,
            "format_boundary_pools": 0, "agent_flag_counts": Counter(), "pool_flag_counts": Counter(),
            "search_diagnosed_pairs": 0, "search_pair_flag_counts": Counter(),
            "audit_observed_hypothesis_union_sum": 0, "audit_vote_valid_entries": 0,
            "audit_scorer_valid_entries": 0, "audit_scorer_entry_flag_counts": Counter(),
            "audit_entry_flag_counts": Counter(), "audit_hypothesis_flag_counts": Counter(),
            "score_gain_cooccurrence": {}})
        group["planned_pools"] += 1
        group["planned_agents"] += 4
        group["states"][record["state"]] += 1
        if item["structural"] is None:
            group["unavailable_agents"] += 4
            continue
        s = item["structural"]
        group["diagnosed_pools"] += 1
        group["diagnosed_agents"] += 4
        group["missing_agents"] += s["missing_agents"]
        group["format_boundary_pools"] += int(s["format_boundary_present"])
        for agent in s["agent_flags"]:
            group["agent_flag_counts"].update(k for k, v in agent.items() if type(v) is bool and v)
            group["audit_entry_flag_counts"].update(agent.get("entry_flags_counts", {}))
            group["audit_scorer_entry_flag_counts"].update(agent.get("scorer_entry_flags_counts", {}))
            group["audit_vote_valid_entries"] += agent.get("vote_valid_entry_count", 0)
            group["audit_scorer_valid_entries"] += agent.get("scorer_valid_entry_count", 0)
        group["pool_flag_counts"].update(k for k, v in s.get("flags", {}).items() if v)
        for pair in s.get("pairs", []):
            group["search_pair_flag_counts"].update(k for k, v in pair.items() if type(v) is bool and v)
            group["search_diagnosed_pairs"] += 1
        group["audit_observed_hypothesis_union_sum"] += s.get("observed_hypothesis_union_count", 0)
        for hypothesis in s.get("hypotheses", []):
            group["audit_hypothesis_flag_counts"].update(k for k, v in hypothesis.items() if type(v) is bool and v)
        for metric, values in s["reported_score_context"].items():
            cross = group["score_gain_cooccurrence"].setdefault(metric, Counter())
            sign = "positive" if values["reported_mv_minus_mi"] > 0 else "negative" if values["reported_mv_minus_mi"] < 0 else "zero"
            cross[sign + ("_with_format_boundary" if s["format_boundary_present"] else "_without_detected_format_boundary")] += 1
    require(len(groups) == 12 and all(g["planned_pools"] == (39 if g["scenario"] == "restricted_search" else 13) for g in groups.values()),
            "full_per_strategy_budget_denominators_required")
    files = {"pool_diagnostics.json": dump(output_rows), "group_counts.json": dump(list(groups.values()))}
    provenance = {"schema_version": "restart-format-diagnostics-v1", "scope": "Pool N4 Search/Audit only",
                  "model": model, "planned_pools": len(target), "planned_agents": 4 * len(target),
                  "other_planned_logical_rows_excluded_by_prespecified_scenario_system": 783 - len(target),
                  "input_refs": list(reader.refs.values()), "total_input_bytes_read": reader.total_bytes,
                  "program_sha256": go["program_sha256"], "model_calls": 0, "scorer_calls": 0,
                  "raw_or_wire_files_read": 0, "source_modules_imported": 0,
                  "original_policy_structural_vote_reconstruction": True,
                  "alternate_parser_or_vote_scores": False, "primary_outputs_modified": False,
                  "causal_attribution": False, "gold_hypothesis_denominator_loaded": False,
                  "fresh_post_output_and_analysis_independent_audit": "still_required"}
    files["PROVENANCE.json"] = dump(provenance)
    files["INDEX.json"] = dump({"schema_version": "restart-format-diagnostics-index-v1",
                                "files": {name: {"sha256": sha(blob), "bytes": len(blob)} for name, blob in files.items()}})
    return files, provenance


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--go", required=True)
    parser.add_argument("--go-sha256", required=True)
    args = parser.parse_args()
    reader = Reader()
    go_ref = {"path": args.go, "sha256": args.go_sha256}
    try:
        go = reader.obj(go_ref)
        out = path(go["output_dir"])
        require(not out.exists() and out.parent.is_dir() and out.parent.resolve() == out.parent,
                "fresh_output_existing_nonalias_parent_required")
        files, provenance = diagnose(go_ref, reader)
        run_root = path(reader.obj(go["inputs"]["run_seal"])["run_root"])
        plan = reader.obj(go["inputs"]["plan"])
        protected = [run_root, path(plan["config"]["repo_root"]), path(go["inputs"]["export_index"]["path"]).parent]
        require(all(out != p and p not in out.parents and out not in p.parents for p in protected), "output_protected_root_overlap")
        write_product(out, files)
        print(json.dumps({"written": True, "planned_pools": provenance["planned_pools"], "independent_audit": "still_required"}))
        return 0
    except (OSError, ValueError, KeyError, TypeError, RecursionError, OverflowError):
        print(json.dumps({"written": False, "reason": "bounded_input_validation_or_write_failed"}))
        return 2


def write_product(out, files):
    require(not out.exists() and out.parent.is_dir(), "fresh_output_required")
    require(set(files) == {"pool_diagnostics.json", "group_counts.json", "PROVENANCE.json", "INDEX.json"},
            "fixed_output_names_required")
    out.mkdir(mode=0o700)
    for name, blob in files.items():
        with (out / name).open("xb") as stream:
            stream.write(blob)


if __name__ == "__main__":
    raise SystemExit(main())
