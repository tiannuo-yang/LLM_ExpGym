"""Virtual-file closed input contract, not fabricated experimental observations."""
import copy
import json
from pathlib import Path
import unittest

import audit as a
from test_audit import fixture


def closed_fixture(duplicate_owner=False, state='terminal', local_workers=0):
    d = a.dependency('format_diagnostics_candidate_v2/diagnostics.py')
    fs, originals, artifacts, source_index, raw_inventory, terminal_refs = {}, [], [], {}, [], []
    root = Path('/synthetic-missing-cause/run')
    def put(path, obj, original=False):
        blob = obj if type(obj) is bytes else a.dump(obj)
        path = str(path)
        fs[path] = blob
        ref = {'path': path, 'sha256': a.sha(blob), 'bytes': len(blob)}
        if original:
            originals.append(ref)
        return ref
    def two(ref):
        return {k: ref[k] for k in ('path', 'sha256')}
    def status(missing):
        return {'schema_version': 'expgym.execution-terminal.v1', 'policy_version': a.POLICY,
                'execution_complete': True, 'score_complete': True,
                'terminal_classification': 'model_no_answer' if missing else 'completed_scored',
                'model_no_answer_count': int(missing), 'expected_model_terminals': 1, 'reported_model_terminals': 1}
    selected = 'I704'
    rows, records = [], []
    for i in range(783):
        iid = 'I%d' % (i if i < 705 else i - 705)
        pool = iid == selected
        names = ['results/%s/agent%d.json' % (iid, j) for j in range(4)] if pool else ['results/L%d.json' % i]
        row = {'logical_id': 'L%d' % i, 'invocation_id': iid, 'system': 'poolact' if pool else 'expgym',
               'scenario': 'restricted_search', 'regime': 'cost_tight', 'strategy': 'naive' if pool else 'single',
               'sampling_seed_labels': [101, 102, 103, 104] if pool else [1000 + i],
               'model_id': 'SYNTHETIC', 'agent_artifacts': names, 'result_artifact': 'results/%s/result.json' % iid if pool else names[0]}
        rows.append(row)
        records.append({'logical_id': row['logical_id'], 'state': state if pool else 'not_started', 'source_sha256': {}})
    row, record = rows[704], records[704]
    f = fixture(content='PRIVATE PARTIAL')
    snapshot, calls, raws, identity, cap, captured = f
    source_agents = []
    for aid, seed in enumerate(row['sampling_seed_labels']):
        missing = aid == 0
        agent = copy.deepcopy(snapshot)
        agent.pop('_trace_v2_capture')
        agent.update(answer=None if missing else 'PRIVATE ANSWER', answer_perf=0.0, answer_metrics=None,
            scoring_input='' if missing else 'PRIVATE ANSWER', score_status='scored_empty_prediction' if missing else 'scored_final_answer',
            missing_final_policy=a.POLICY, terminal_origin='normal_loop_return', terminal_scenario='restricted_search',
            terminal_status=status(missing), seed=seed, agent_id=aid, strategy='naive',
            api_dump={'schema_version': 'expgym.api_attempt.v1', 'client_id': 'c' * 32 if missing or duplicate_owner and aid == 1 else str(aid) * 32, 'run_id': 'SYNTHETIC'})
        ref = put(root / row['agent_artifacts'][aid], agent, True)
        artifacts.append(ref)
        source_agents.append(agent)
        source_index[row['agent_artifacts'][aid]] = ref['path']
        record['source_sha256'][row['agent_artifacts'][aid]] = ref['sha256']
    aggregate_status = dict(status(True), expected_model_terminals=4, reported_model_terminals=4)
    result_ref = put(root / row['result_artifact'], {'config': {'max_context_tokens': cap}, 'agent_results': source_agents}, True)
    source_index[row['result_artifact']] = result_ref['path']
    record['source_sha256'][row['result_artifact']] = result_ref['sha256']
    for sequence, raw in enumerate(raws.values(), 1):
        # Original client dump preserves dict order; canonical controls do not.
        ref = put(root / 'dumps' / selected / (raw['request_id'] + '.json'), json.dumps(raw).encode('utf-8'), True)
        raw_inventory.append(dict(ref, kind='raw', mtime_ns=0))
        req = json.dumps(raw['request_payload']).encode('utf-8')
        resp = raw['response_raw'].encode('utf-8')
        common = {'source_client_id': raw['client_id'], 'seed': identity['seed'], 'attempt_sequence': sequence,
                  'request_body_sha256': a.sha(req), 'request_bytes': len(req)}
        for kind in ('attempt_start', 'attempt_terminal'):
            event = dict(common, kind=kind)
            if kind == 'attempt_terminal':
                event.update(state='bytes_returned', error_type=None, response_bytes_sha256=a.sha(resp), response_bytes=len(resp))
            ref = put(root / 'logs' / selected / 'wire' / ('%s%d.json' % (kind, sequence)), event, True)
            raw_inventory.append(dict(ref, kind='wire', mtime_ns=0))
    snapshot.pop('_trace_v2_capture')
    event = {'schema_version': 'expgym.terminal-evidence.v1', 'event': 'loop_terminal',
             'owner': {'runner': 'poolact', 'seed': 101, 'agent_id': 0, 'strategy': 'naive'},
             'completion_marker': False, 'score_acceptance_authority': False,
             'payload': {'loop_result': snapshot, 'capture_point': 'raw_return_before_caller_and_scorer_mutations'}}
    terminal_refs.append(put(root / 'evidence' / selected / 'loop_terminal.json', event, True))
    raw_audit = put(root / 'logs' / selected / 'raw_audit.json', {'schema_version': 'restart-raw-wire-audit-v1',
                      'verified': True, 'errors': [], 'inventory': raw_inventory}, True)
    matrix = {'schema_version': 'restart-mixed-matrix-v1', 'logical_rows': rows}
    plan = {'schema_version': 'restart-executable-plan-v1', 'mode': 'formal_mixed', 'matrix': matrix,
            'config': {'output_root': str(root), 'repo_root': str(a.SOURCE), 'run_id': 'SYNTHETIC', 'policy': {'max_context_tokens': cap}},
            'jobs': [{'invocation_id': 'I%d' % i} for i in range(705)]}
    plan_ref = put('/synthetic-missing-cause/plan.json', plan)
    report = {'raw_integrity_complete': True, 'execution_evidence_complete': True, 'artifact_integrity_complete': True,
              'terminal_status': aggregate_status, 'raw_audit_ref': raw_audit, 'original_terminal_evidence': terminal_refs}
    execution = {'schema_version': 'restart-bounded-study-execution-v1', 'mode': 'formal_mixed', 'local_workers': local_workers,
                 'run_id': 'SYNTHETIC', 'plan_ref': two(plan_ref), 'started_invocation_ids': [selected],
                 'unstarted_invocation_ids': ['I%d' % i for i in range(704)],
                 'reports': [{'invocation_id': selected, 'decision': {'continue': state == 'terminal'}, 'report': report}]}
    execution_ref = put(root / 'execution.json', execution, True)
    closure_ref = put('/synthetic-missing-cause/closure.json', {'local_workers': 0, 'mode': 'formal_mixed', 'run_id': 'SYNTHETIC',
                    'plan_ref': two(plan_ref), 'execution_ref': two(execution_ref)})
    entries = [dict(r, relative_path=str(Path(r['path']).relative_to(root))) for r in originals]
    parts = put('/synthetic-missing-cause/part.json', entries)
    parts.update(file_count=len(entries), total_bytes=sum(r['bytes'] for r in entries))
    seal_ref = put('/synthetic-missing-cause/seal.json', {'schema_version': 'restart-closed-run-inventory-v1',
                   'full_second_read_equal': True, 'expected_invocations': 705, 'run_root': str(root),
                   'sealer_source_ref': {'sha256': d.SEALER_SHA}, 'control_refs': [two(plan_ref), two(execution_ref)],
                   'closure_ref': closure_ref, 'file_parts': [parts], 'file_count': len(entries), 'total_bytes': parts['total_bytes']})
    export_root = Path('/synthetic-missing-cause/export')
    manifest_bytes = a.dump(matrix)
    bundle = {'schema_version': 'restart-analysis-records-v1', 'manifest_sha256': a.sha(manifest_bytes), 'records': records}
    values = {'manifest.json': matrix, 'records.json': bundle, 'source_index.json': source_index,
              'input_pins.json': {'manifest_sha256': a.sha(manifest_bytes), 'records_sha256': a.sha(a.dump(bundle))},
              'EXPORT_EVIDENCE.json': {'schema_version': 'restart-real-export-evidence-v1', 'exporter_sha256': d.EXPORTER_SHA,
                  'analysis_sha256': d.ANALYSIS_SHA, 'plan_ref': two(plan_ref), 'execution_ref': two(execution_ref),
                  'model_calls': 0, 'scorer_calls': 0, 'original_refs': originals}}
    index = {}
    for name in d.EXPORT_FILES:
        ref = put(export_root / name, values.get(name, {}))
        index[name] = {k: ref[k] for k in ('sha256', 'bytes')}
    export_ref = put(export_root / 'EXPORT_INDEX.json', {'files': index})
    go = {'schema_version': 'restart-missing-cause-go-v1', 'issuer': 'ROOT', 'approved': True,
          'post_run_and_analysis_frozen': True, 'program_sha256': a.sha(Path(a.__file__).read_bytes()),
          'inputs': {'plan': two(plan_ref), 'execution': two(execution_ref), 'run_seal': two(seal_ref), 'export_index': two(export_ref)},
          'output_dir': '/synthetic-missing-cause/new-output'}
    go_ref = put('/synthetic-missing-cause/go.json', go)
    for name in a.PINS:
        fs[str(a.SOURCE / name)] = (a.SOURCE / name).read_bytes()
    for name in a.DEPENDENCIES:
        fs[str(a.HERE.parent / name)] = (a.HERE.parent / name).read_bytes()
    fs[str(a.HERE / 'output.schema.json')] = (a.HERE / 'output.schema.json').read_bytes()
    return go_ref, fs


class ClosedContract(unittest.TestCase):
    def test_full_shaped_synthetic_pipeline_and_fixed_safe_outputs(self):
        ref, fs = closed_fixture()
        d = a.dependency('format_diagnostics_candidate_v2/diagnostics.py')
        files, provenance = a.audit(ref, d.Reader(read=fs.__getitem__))
        self.assertEqual(set(files), set(a.FILES))
        coverage = json.loads(files['coverage.json'])
        self.assertEqual((coverage['missing_terminals'], coverage['observed_agents'], coverage['unavailable_agents_excluded_from_missing']), (1, 4, 782))
        self.assertEqual(coverage['mechanism_counts'], {'forced_length_nonempty_text_rejected': 1})
        self.assertFalse(any(b'PRIVATE' in blob for blob in files.values()))
        self.assertEqual(provenance['loop_executions'], 0)
        row = json.loads(files['missing_causes.json'])['rows'][0]
        self.assertTrue(row['call_observations'][-1]['response']['wire_response_bytes_sha256'])

    def test_seal_mutation_and_active_execution_fail(self):
        ref, fs = closed_fixture()
        go = json.loads(fs[ref['path']])
        path = go['inputs']['execution']['path']
        fs[path] = fs[path] + b' '
        d = a.dependency('format_diagnostics_candidate_v2/diagnostics.py')
        with self.assertRaises(ValueError):
            a.audit(ref, d.Reader(read=fs.__getitem__))

    def test_multiowner_conflict_is_not_model_cause(self):
        ref, fs = closed_fixture(duplicate_owner=True)
        d = a.dependency('format_diagnostics_candidate_v2/diagnostics.py')
        with self.assertRaises(ValueError):
            a.audit(ref, d.Reader(read=fs.__getitem__))

    def test_infrastructure_null_excluded_and_active_run_refused(self):
        d = a.dependency('format_diagnostics_candidate_v2/diagnostics.py')
        ref, fs = closed_fixture(state='infrastructure_error')
        files, _ = a.audit(ref, d.Reader(read=fs.__getitem__))
        self.assertEqual(json.loads(files['coverage.json'])['missing_terminals'], 0)
        self.assertEqual(json.loads(files['coverage.json'])['unavailable_agents_excluded_from_missing'], 786)
        ref, fs = closed_fixture(local_workers=1)
        with self.assertRaises(ValueError):
            a.audit(ref, d.Reader(read=fs.__getitem__))

    def test_physical_wire_binding_rejects_wrong_response_bytes(self):
        from test_audit import run, pure
        f = fixture()
        observations = run(f, pure())['call_observations']
        with self.assertRaises(ValueError):
            a.wire_bind(observations, f[2], {}, [])


if __name__ == '__main__':
    unittest.main(verbosity=2)
