"""Synthetic only: no current experiment files, data, model, network, or scorer."""
import ast
from collections import Counter
import copy
import inspect
import json
import math
from pathlib import Path
import re
import tempfile
import unittest

import diagnostics as d

SOURCE = Path('/lustrefs/users/chufan.shi/codex_space_tn/portable_eval_20260908/source_cohorts/v5/LLM_ExpGym')


def frozen_functions(relative, names, extra=None):
    """Execute only explicitly named pure functions in pinned source ASTs."""
    body = (SOURCE / relative).read_bytes()
    assert d.sha(body) == d.SOURCE_PINS[relative]
    module = ast.parse(body)
    selected = [node for node in module.body if isinstance(node, ast.FunctionDef) and node.name in names]
    assert {node.name for node in selected} == set(names)
    for node in selected:
        for fn in [n for n in ast.walk(node) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]:
            fn.returns = None
            for arg in fn.args.posonlyargs + fn.args.args + fn.args.kwonlyargs:
                arg.annotation = None
    namespace = {'json': json, 're': re, 'Counter': Counter, 'math': math, 'inspect': inspect,
                 'build_aggregation_diagnostics': lambda *a, **kw: {}}
    namespace.update(extra or {})
    exec(compile(ast.Module(body=selected, type_ignores=[]), str(SOURCE / relative), 'exec'), namespace)
    return namespace


class Parsers(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.search = frozen_functions('expgym/task_restricted_search.py', ['_extract_names', '_normalize_name'])
        cls.pool = frozen_functions('expgym/poolact.py', ['_search_vote_key', '_canonical_audit_label',
             '_canonical_evidence_ids', 'aggregate_results', '_evaluate_aggregate', '_require_finite_scores'])

    def test_search_exact_frozen_parsers(self):
        cases = [None, '', ' ', 'Alice Jones, Bob Smith', '["Bob Smith","ALICE Jones"]',
                 '1. Alice Jones\n- Bob Smith', '["1. Alice Jones", "- Bob Smith"]',
                 'Alice Bea Carol Dana Eva Fox', '["Alice Bea Carol Dana Eva Fox"]',
                 'Alice Jones; these are extra explanatory words not names', '[null, true, 4, [1,2], {}]',
                 '{"not": "list"}', '[]', '0', '[NaN, Infinity, -Infinity]', '-*•', '\n1. • Alice Jones •\n']
        for answer in cases:
            vote, scorer, _ = d.search_sets(answer)
            self.assertEqual(vote, self.pool['_search_vote_key'](answer))
            self.assertEqual(set(scorer), self.search['_extract_names'](answer or ''))

    def frozen_aggregate(self, scenario, answers):
        return self.pool['aggregate_results'](scenario, [{'answer': a, 'answer_perf': 0.0} for a in answers])['answer']

    def test_search_split_pairs(self):
        answers = ['Alice Jones', 'Alice Jones; these are extra explanatory words not names', 'Bob Smith', 'Bob Smith']
        obj = d.search_pool(answers, self.frozen_aggregate('restricted_search', answers))
        self.assertTrue(obj['flags']['scorer_set_split_present'])
        self.assertEqual(obj['selected_agent_index'], 2)
        self.assertEqual(len(obj['pairs']), 6)
        self.assertFalse(obj['flags']['strict_majority'])

    def test_search_merge_representative(self):
        name = 'Alice Bea Carol Dana Eva Fox'
        answers = [name, json.dumps([name]), json.dumps([name]), 'Bob Smith']
        obj = d.search_pool(answers, self.frozen_aggregate('restricted_search', answers))
        self.assertTrue(obj['flags']['vote_key_merge_present'])
        self.assertTrue(obj['flags']['winning_key_scorer_disagreement'])
        self.assertEqual(obj['selected_agent_index'], 0)
        with self.assertRaises(ValueError):
            d.search_pool(answers, answers[1])

    def test_search_empty_vote_and_tie(self):
        answers = [None, '', 'Alice Jones', 'Alice Jones']
        obj = d.search_pool(answers, self.frozen_aggregate('restricted_search', answers))
        self.assertTrue(obj['flags']['nonempty_tie_preference_applies'])
        self.assertEqual(obj['selected_agent_index'], 2)
        self.assertEqual(sum(a['missing_answer'] for a in obj['agent_flags']), 1)
        obj = d.search_pool([None] * 4, '')
        self.assertEqual(obj['selected_agent_index'], 0)
        self.assertTrue(obj['flags']['strict_majority'])

    def test_audit_frozen_vote_labels_and_evidence(self):
        for value in [None, '', 'not_mentioned', 'NOT-2-mentioned', 'neutral', 'entailed', 'unrecognized', 0, False, ['Entailment']]:
            self.assertEqual(d.canonical_label(value), self.pool['_canonical_audit_label'](value))
        for value in [None, '', '12', {'1': 4}, [], [True, 1.9, '2'], ['bad', 2], [[1], 2], [float('nan')], [float('inf')], [2, 1, 1]]:
            self.assertEqual(d.vote_evidence(value), self.pool['_canonical_evidence_ids'](value))

    def test_audit_wrapper_rules(self):
        text = '{"H":{"label":"Entailment","evidence_ids":[1]}}'
        for answer in [text, text + ';', '```json\n' + text + '\n```', '```json\n' + text + '\n```;']:
            scored, voted, flags = d.audit_parse(answer)
            self.assertEqual(scored, json.loads(text))
            self.assertEqual(flags['scorer_accepts_vote_rejects'], answer != text)
            if answer != text:
                self.assertEqual(voted, {})
        self.assertEqual(d.audit_parse(text + '; x')[0], {})
        self.assertEqual(d.audit_parse('[]')[0], {})

    def test_audit_no_wrapper_expansion(self):
        # Frozen scorer does NOT strip an inner semicolon after fence removal.
        text = '```json\n{"H":{}};\n```'
        self.assertFalse(d.audit_parse(text)[2]['scorer_accepts_object'])
        text = '{"H":{"label":"wrong"},"H":{"label":"Entailment"}}'
        self.assertEqual(d.audit_parse(text)[0]['H']['label'], 'Entailment')

    def test_audit_label_canonicalization(self):
        answer = '{"H":{"label":"not_mentioned","evidence_ids":[]}}'
        answers = [answer] * 4
        obj = d.audit_pool(answers, self.frozen_aggregate('evidence_audit', answers))
        self.assertTrue(obj['format_boundary_present'])
        self.assertEqual(obj['agent_flags'][0]['entry_flags_counts']['label_changes_under_canonicalization'], 1)
        self.assertEqual(obj['hypotheses'][0]['label_supporter_indices'], [0, 1, 2, 3])

    def test_audit_conditioned_evidence_and_ties(self):
        answers = [json.dumps({'H': {'label': label, 'evidence_ids': evidence}}) for label, evidence in
                   [('Entailment', [2]), ('Contradiction', [1]), ('entailed', [3]), ('contradicted', [1])]]
        obj = d.audit_pool(answers, self.frozen_aggregate('evidence_audit', answers))
        hyp = obj['hypotheses'][0]
        self.assertEqual(hyp['label_supporter_indices'], [0, 2])
        self.assertEqual(hyp['evidence_supporter_indices'], [0])
        self.assertTrue(hyp['label_tie'])
        self.assertTrue(hyp['evidence_tie'])

    def test_audit_malformed_evidence_and_missing_entry(self):
        self.assertEqual(d.scorer_evidence('12'), ({1, 2}, False))
        self.assertEqual(d.scorer_evidence([1, 'bad']), (set(), True))
        self.assertEqual(d.vote_evidence([1, 'bad']), (1, 'bad'))
        answers = ['{}', '{"H":null}', '{"H":{}}', '{"H":{"evidence_ids":"12"}}']
        obj = d.audit_pool(answers, self.frozen_aggregate('evidence_audit', answers))
        hyp = obj['hypotheses'][0]
        self.assertEqual(hyp['vote_key_present_by_agent'], [False, True, True, True])
        self.assertEqual(hyp['vote_entry_present_by_agent'], [False, False, True, True])
        self.assertIsNone(obj['gold_hypothesis_denominator'])
        self.assertTrue(obj['format_boundary_present'])

    def test_audit_nonfinite_inside_answer_string_is_not_control_json(self):
        for token in ['NaN', 'Infinity', '-Infinity']:
            answers = ['{"H":{"label":"Entailment","evidence_ids":[' + token + ']}}'] * 4
            obj = d.audit_pool(answers, self.frozen_aggregate('evidence_audit', answers))
            self.assertTrue(obj['format_boundary_present'])
            self.assertEqual(obj['agent_flags'][0]['entry_flags_counts']['evidence_invalid_list_member'], 1)
            # No nonfinite values are copied into output diagnostics.
            d.dump(obj)


def fixture():
    """Entire synthetic 705-invocation / 783-record shape, four closed pools."""
    fs = {}
    def put(path, obj):
        blob = d.dump(obj)
        fs[path] = blob
        return {'path': path, 'sha256': d.sha(blob), 'bytes': len(blob)}
    def two(ref):
        return {k: ref[k] for k in ('path', 'sha256')}
    rows, records, source_index, original_refs, artifacts = [], [], {}, [], []
    for scenario, size in [('restricted_search', 39), ('evidence_audit', 13)]:
        for regime in ['cost_moderate', 'cost_tight']:
            for strategy in ['naive', 'cached', 'poolact']:
                for item in range(size):
                    i = len(rows)
                    prefix = 'results/%d' % i
                    row = {'logical_id': 'L%d' % i, 'invocation_id': 'I%d' % i, 'model': 'MOCK', 'model_id': 'MOCK-serving',
                           'system': 'poolact', 'scenario': scenario, 'item': 'MOCK%d' % item, 'regime': regime,
                           'strategy': strategy, 'outerrep': 0, 'selector': {}, 'sampling_seed_labels': [2200,2201,2202,2203],
                           'result_artifact': prefix + '/result.json', 'agent_artifacts': [prefix + '/agent%d.json' % j for j in range(4)]}
                    rows.append(row)
                    state = 'terminal' if i in (0, 1, 234, 235) else 'infrastructure_error' if i == 2 else 'not_started'
                    record = {'logical_id': row['logical_id'], 'state': state, 'reason': None if state == 'terminal' else state, 'source_sha256': {}}
                    records.append(record)
                    if state != 'terminal':
                        continue
                    answers = ['Alice Jones'] * 4 if scenario == 'restricted_search' else ['{"H":{"label":"not_mentioned","evidence_ids":[]}}'] * 4
                    if i == 1:
                        answers[0] = None
                    if i == 235:
                        answers = ['```json\n{"H":{"label":"Entailment","evidence_ids":[1]}}\n```'] * 4
                    agents = []
                    for j, answer in enumerate(answers):
                        agent = {'agent_id': j, 'answer': answer, 'scoring_input': answer or '',
                                 'score_status': 'scored_empty_prediction' if answer is None else 'scored_final_answer',
                                 'terminal_status': {}, 'missing_final_policy': 'task-abstention-v1', 'terminal_origin': 'normal_loop_return',
                                 'terminal_scenario': scenario, 'answer_perf': 0.0 if answer is None else 1.0,
                                 'answer_metrics': {'label_acc': 1.0, 'evidence_acc': 1.0} if scenario == 'evidence_audit' else None,
                                 'score_check': {'ok': True}}
                        agents.append(agent)
                    aggregate_answer = 'Alice Jones' if scenario == 'restricted_search' else '{}' if i == 235 else '{"H": {"evidence_ids": [], "label": "NotMentioned"}}'
                    payload = {'agents': 4, 'strategy': strategy, 'agent_results': agents,
                               'aggregate': {'answer': aggregate_answer, 'answer_perf': 1.0,
                                             'answer_metrics': {'label_acc': 1.0, 'evidence_acc': 1.0} if scenario == 'evidence_audit' else None},
                               'config': {'scenario': scenario, 'cost_regime': regime, 'model': 'MOCK-serving', 'agent_seeds': [2200,2201,2202,2203]}}
                    for rel, obj in [(row['result_artifact'], payload)] + list(zip(row['agent_artifacts'], agents)):
                        ref = put('/MOCK-run/' + rel, obj)
                        record['source_sha256'][rel] = ref['sha256']
                        source_index[rel] = ref['path']
                        original_refs.append(ref)
                        artifacts.append({**ref, 'relative_path': rel})
    for i in range(312, 783):
        iid = i if i < 705 else 312 + i - 705
        rows.append({'logical_id': 'L%d' % i, 'invocation_id': 'I%d' % iid, 'system': 'expgym', 'scenario': 'MOCK-excluded'})
        records.append({'logical_id': 'L%d' % i, 'state': 'not_started', 'reason': 'not_started', 'source_sha256': {}})
    matrix = {'schema_version': 'restart-mixed-matrix-v1', 'logical_rows': rows}
    plan = {'schema_version': 'restart-executable-plan-v1', 'mode': 'formal_mixed', 'matrix': matrix,
            'config': {'run_id': 'MOCK', 'model': {'label': 'MOCK'}, 'repo_root': '/MOCK-source', 'output_root': '/MOCK-run'},
            'jobs': [{'invocation_id': 'I%d' % i} for i in range(705)]}
    plan_ref = two(put('/MOCK-controls/plan.json', plan))
    started = [r['invocation_id'] for r, rec in zip(rows, records) if rec['state'] != 'not_started']
    execution = {'schema_version': 'restart-bounded-study-execution-v1', 'mode': 'formal_mixed', 'local_workers': 0,
                 'plan_ref': plan_ref, 'run_id': 'MOCK', 'started_invocation_ids': started,
                 'unstarted_invocation_ids': ['I%d' % i for i in range(705) if 'I%d' % i not in started]}
    execution_ref = two(put('/MOCK-run/execution.json', execution))
    artifacts.append({**execution_ref, 'bytes': len(fs[execution_ref['path']]), 'relative_path': 'execution.json'})
    part_ref = put('/MOCK-seal/part.json', artifacts)
    closure_ref = put('/MOCK-seal/closure.json', {'local_workers': 0, 'mode': 'formal_mixed', 'run_id': 'MOCK',
                                                'plan_ref': plan_ref, 'execution_ref': execution_ref})
    seal_ref = two(put('/MOCK-seal/inventory.json', {'schema_version': 'restart-closed-run-inventory-v1', 'run_root': '/MOCK-run',
         'full_second_read_equal': True, 'expected_invocations': 705, 'sealer_source_ref': {'sha256': d.SEALER_SHA},
         'control_refs': [plan_ref, execution_ref], 'closure_ref': closure_ref,
         'file_parts': [{**part_ref, 'file_count': len(artifacts), 'total_bytes': sum(a['bytes'] for a in artifacts)}],
         'file_count': len(artifacts), 'total_bytes': sum(a['bytes'] for a in artifacts)}))
    product = {}
    product['manifest.json'] = matrix
    product['records.json'] = {'schema_version': 'restart-analysis-records-v1', 'manifest_sha256': d.sha(d.dump(matrix)), 'records': records}
    product['source_index.json'] = source_index
    product['EXPORT_EVIDENCE.json'] = {'schema_version': 'restart-real-export-evidence-v1', 'exporter_sha256': d.EXPORTER_SHA,
         'analysis_sha256': d.ANALYSIS_SHA, 'plan_ref': plan_ref, 'execution_ref': execution_ref,
         'model_calls': 0, 'scorer_calls': 0, 'original_refs': original_refs}
    product['input_pins.json'] = {'manifest_sha256': d.sha(d.dump(matrix)), 'records_sha256': d.sha(d.dump(product['records.json']))}
    for name in d.EXPORT_FILES - set(product):
        product[name] = {'MOCK_not_actual_analysis': True}
    export_files = {name: {k: ref[k] for k in ('sha256', 'bytes')} for name, value in product.items()
                    for ref in [put('/MOCK-export/' + name, value)]}
    export_ref = two(put('/MOCK-export/EXPORT_INDEX.json', {'files': export_files}))
    for rel in d.SOURCE_PINS:
        fs['/MOCK-source/' + rel] = (SOURCE / rel).read_bytes()
    go = {'schema_version': 'restart-format-diagnostics-go-v1', 'issuer': 'ROOT', 'approved': True,
          'post_run_and_analysis_frozen': True, 'program_sha256': d.sha(Path(d.__file__).read_bytes()),
          'output_dir': '/MOCK-output/fresh', 'inputs': {'plan': plan_ref, 'execution': execution_ref,
          'export_index': export_ref, 'run_seal': seal_ref}}
    go_ref = two(put('/MOCK-controls/GO.json', go))
    return fs, go_ref, put


class InputGates(unittest.TestCase):
    def test_complete_planned_denominators(self):
        fs, go_ref, _ = fixture()
        files, provenance = d.diagnose(go_ref, d.Reader(read=fs.__getitem__))
        rows = d.load(files['pool_diagnostics.json'])
        groups = d.load(files['group_counts.json'])
        self.assertEqual(len(rows), 312)
        self.assertEqual(sum(g['planned_agents'] for g in groups), 1248)
        self.assertEqual(sum(g['diagnosed_pools'] for g in groups), 4)
        self.assertEqual(sum(g['unavailable_agents'] for g in groups), 308 * 4)
        self.assertEqual(sum(g['missing_agents'] for g in groups), 1)
        self.assertEqual(sum(g['states'].get('infrastructure_error', 0) for g in groups), 1)
        self.assertEqual(provenance['other_planned_logical_rows_excluded_by_prespecified_scenario_system'], 471)
        self.assertEqual(provenance['raw_or_wire_files_read'], 0)
        for name, ref in d.load(files['INDEX.json'])['files'].items():
            self.assertEqual(ref, {'sha256': d.sha(files[name]), 'bytes': len(files[name])})

    def mutate_go(self, change):
        fs, go_ref, put = fixture()
        go = d.load(fs[go_ref['path']])
        change(go)
        go_ref = put(go_ref['path'], go)
        return fs, go_ref

    def test_unapproved_and_unfrozen_refused(self):
        for change in [lambda go: go.update(approved=False), lambda go: go.update(post_run_and_analysis_frozen=False),
                       lambda go: go.update(issuer='candidate'), lambda go: go.update(program_sha256='0' * 64)]:
            fs, go_ref = self.mutate_go(change)
            with self.assertRaises(ValueError):
                d.diagnose(go_ref, d.Reader(read=fs.__getitem__))

    def test_changed_original_refused(self):
        fs, go_ref, _ = fixture()
        fs['/MOCK-run/results/0/agent0.json'] += b' '
        with self.assertRaises(ValueError):
            d.diagnose(go_ref, d.Reader(read=fs.__getitem__))

    def test_changed_export_refused(self):
        fs, go_ref, _ = fixture()
        fs['/MOCK-export/records.json'] += b' '
        with self.assertRaises(ValueError):
            d.diagnose(go_ref, d.Reader(read=fs.__getitem__))

    def test_changed_source_refused(self):
        fs, go_ref, _ = fixture()
        fs['/MOCK-source/expgym/poolact.py'] += b'\n'
        with self.assertRaises(ValueError):
            d.diagnose(go_ref, d.Reader(read=fs.__getitem__))

    def test_unsealed_refused(self):
        fs, go_ref, put = fixture()
        go = d.load(fs[go_ref['path']])
        seal = d.load(fs[go['inputs']['run_seal']['path']])
        seal['full_second_read_equal'] = False
        go['inputs']['run_seal'] = put(go['inputs']['run_seal']['path'], seal)
        go_ref = put(go_ref['path'], go)
        with self.assertRaises(ValueError):
            d.diagnose(go_ref, d.Reader(read=fs.__getitem__))

    def test_export_path_override_or_extra_refused(self):
        for mutate in [lambda ix: ix['files']['records.json'].update(path='/MOCK-raw/secret.json'),
                       lambda ix: ix['files'].update({'extra_raw.json': {'sha256': '0' * 64, 'bytes': 0}})]:
            fs, go_ref, put = fixture()
            go = d.load(fs[go_ref['path']])
            index = d.load(fs[go['inputs']['export_index']['path']])
            mutate(index)
            go['inputs']['export_index'] = put(go['inputs']['export_index']['path'], index)
            go_ref = put(go_ref['path'], go)
            with self.assertRaises(ValueError):
                d.diagnose(go_ref, d.Reader(read=fs.__getitem__))

    def test_memory_and_path_bounds(self):
        reader = d.Reader(read=lambda _: b'12345')
        reader.max_file_bytes = 4
        with self.assertRaises(ValueError):
            reader.ref({'path': '/MOCK/x.json', 'sha256': d.sha(b'12345')})
        for value in ['/MOCK/private/api_key', '/MOCK/../x', 'relative']:
            with self.assertRaises(ValueError):
                d.path(value)
        with self.assertRaises(ValueError):
            d.load(b'{"x":1,"x":2}')

    def test_fresh_output_and_exact_index(self):
        fs, go_ref, _ = fixture()
        files, _ = d.diagnose(go_ref, d.Reader(read=fs.__getitem__))
        with tempfile.TemporaryDirectory(prefix='MOCK-product-', dir=Path(__file__).parent) as temporary:
            out = Path(temporary) / 'fresh'
            d.write_product(out, files)
            for name, blob in files.items():
                self.assertEqual((out / name).read_bytes(), blob)
            for name, ref in d.load((out / 'INDEX.json').read_bytes())['files'].items():
                self.assertEqual(ref['sha256'], d.sha((out / name).read_bytes()))
            with self.assertRaises(ValueError):
                d.write_product(out, files)


if __name__ == '__main__':
    unittest.main(verbosity=2)
