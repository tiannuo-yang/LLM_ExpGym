# 缺答近端分类候选：独立静态与 8 项 CPU 复核

状态：**尚未通过最终 peer 验收**。8 项独立合成核验为 6 PASS、2 FAIL；详见 `CPU_RECEIPT_v1.json`。此结论对应 audit.py SHA `e073c2ca4528b02dc5e4cc1857adcb56e1e25b31a2a8c6df1e92c0a9cd546f44`，不代表后续版本。

## 确定缺口

- audit.py 第 175–181、193–197 行：调用/重试序列及 raw attempt 使用普通相等。合成账本和 raw 中的 `attempt=true` 被当作整数 1 接受。须将相关序号限制为 exact int；同类 llm_call_index、计数也应维持该契约。
- audit.py 第 372–374 行：snapshot owner 匹配使用普通相等。合成 `owner.agent_id=false` 被当作目标 agent 0 接受。须校验 owner agent ID/seed 的 exact int；不应靠 equality 接受错误类型。

以上反例只改变结构身份，不改变分类 oracle。未使用真实样本来制造或解释现象。

## 本次已确认的修复

全读初版核心和两份合成测试后，静态发现并向作者反馈：provider usage 任意扩展文本会回显、未知终止原因文本需脱敏、可重试 HTTP 503 body 出现 choices 不等于已交付模型决定、completion_tokens 为 null 时应沿原客户端 fallback 到 output_tokens。作者先行修复后，本次独立 CPU 确认 usage 文本不回显、503 后正常交付、null alias 三项通过；未复刻分类实现作为 oracle。

另有非空 length 且实际上限 65536、缺 final note 不足以解释 context gate、reasoning/refusal/output_text part 不变成原 decoder 文本三项通过。原始 content/reasoning/拒绝文本均只采用合成标记。

## 终态绑定与无 final 的静态结论

核心先绑定已封存 export/run 引用，再从正常 policy 终态识别缺答。Pool snapshot 比较 messages、usage_attempts、协议失败、调用/step/attempt 计数、aborted、termination_reason 和协议；Exp snapshot 比较捕获的 forced/finish/output_message/attempt_usage。分类进一步检查 ledger/raw owner、generation、retry payload、最后交付响应、历史 assistant 消息，并要求 forced 调用唯一且为最后调用。wire 绑定把尝试顺序和请求/响应字节 SHA 接上。这里不是按 mtime 找“最后一条”。

未发 final 的解释要求：正常 aborted-null、calls=steps、没有 forced failure、最终 note 可绑定；只有 Pool 且有 context cap 与实际 raw tool schemas 才重用冻结 trim/estimate 函数。无 note、无 cap、无 raw schema 或重建 gate 仍允许发送，均保持 unknown。这个范围不会证明提高预算必定改善答案；也不能作为 actual 执行授权。

## 边界

仅只读候选、冻结纯函数及相关导出源码；仅执行本目录 `peer_cases.py` 的 8 项 CPU。未读取 K3/GLM 实际 raw、export、答案、恢复 payload、任务数据或密钥；未调用模型、网络、Slurm、scorer 或完整 loop；未改候选或任何冻结原件。实际闭合输出仍须另行授权、执行和 post-output 独立审计。
