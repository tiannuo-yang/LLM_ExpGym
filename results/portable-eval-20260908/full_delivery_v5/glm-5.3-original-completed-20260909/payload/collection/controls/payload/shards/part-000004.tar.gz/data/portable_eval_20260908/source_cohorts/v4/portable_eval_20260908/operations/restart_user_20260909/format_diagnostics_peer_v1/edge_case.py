#!/usr/bin/env python3
"""Synthetic parser exception boundary; no evaluator/gold/model/input outcomes."""
import importlib.util
import json
from pathlib import Path
import sys

base = Path(__file__).resolve().parent.parent / 'format_diagnostics_candidate_v1'
for name, filename in [('diagnostics', 'diagnostics.py'), ('owner_helpers', 'test_diagnostics.py')]:
    spec = importlib.util.spec_from_file_location(name, base / filename)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
d, owner = sys.modules['diagnostics'], sys.modules['owner_helpers']
assert d.sha((base / 'diagnostics.py').read_bytes()) == 'cddf8f05c5c23ffa92373c45ed42a07507b890ebd3dc5f31017f1c150d9d6427'
search = owner.frozen_functions('expgym/task_restricted_search.py', ['_normalize_name', '_extract_names'])
vote = owner.frozen_functions('expgym/poolact.py', ['_search_vote_key'])
answer = '9' * 5000
results = {}
for label, fn in [('source_search_parser', search['_extract_names']),
                  ('source_search_vote', vote['_search_vote_key']), ('candidate_parser', d.search_sets)]:
    try:
        fn(answer)
        results[label] = 'returned'
    except Exception as exc:
        results[label] = type(exc).__name__
print(json.dumps({'synthetic': True, 'digit_limit': sys.get_int_max_str_digits(), 'outcomes': results,
                  'gold_or_scorer_calls': 0, 'actual_terminal_impact_established': False}, sort_keys=True))
