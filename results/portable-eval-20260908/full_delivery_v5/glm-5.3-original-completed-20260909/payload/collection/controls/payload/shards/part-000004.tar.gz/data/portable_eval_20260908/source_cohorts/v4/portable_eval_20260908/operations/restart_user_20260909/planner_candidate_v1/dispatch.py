"""Small bounded dispatcher and typed terminal policy; never scores a task."""
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
import time

POLICY = "task-abstention-v1"
EVIDENCE_FIELDS = ("execution_evidence_complete", "artifact_integrity_complete",
                   "raw_integrity_complete", "source_identity_valid", "runtime_identity_valid")


def terminal_decision(job, report):
    """A source status alone never grants continuation: verified evidence is required."""
    if type(report) is not dict or report.get("invocation_id") != job["invocation_id"]:
        return {"continue": False, "classification": "integrity_failure", "reason": "wrong_invocation"}
    if any(report.get(name) is not True for name in EVIDENCE_FIELDS):
        return {"continue": False, "classification": "infrastructure_or_integrity_failure",
                "reason": "incomplete_independent_execution_evidence"}
    status = report.get("terminal_status")
    expected = job["expected_model_terminals"]
    if (type(status) is not dict or status.get("schema_version") != "expgym.execution-terminal.v1"
            or status.get("policy_version") != POLICY or status.get("execution_complete") is not True
            or type(status.get("score_complete")) is not bool
            or type(status.get("expected_model_terminals")) is not int
            or type(status.get("reported_model_terminals")) is not int
            or status["expected_model_terminals"] != expected
            or status["reported_model_terminals"] != expected
            or type(status.get("model_no_answer_count")) is not int
            or not 0 <= status["model_no_answer_count"] <= expected):
        return {"continue": False, "classification": "integrity_failure", "reason": "invalid_terminal_status"}
    kind = status.get("terminal_classification")
    missing = status["model_no_answer_count"]
    if kind == "completed_scored" and missing == 0 and status["score_complete"] is True:
        return {"continue": True, "classification": kind, "score_complete": True}
    if kind == "model_no_answer" and missing > 0:
        if job["scenario"] != "tuning" and status["score_complete"] is not True:
            return {"continue": False, "classification": "integrity_failure", "reason": "unscored_search_audit"}
        return {"continue": True, "classification": kind, "score_complete": status["score_complete"]}
    return {"continue": False, "classification": "integrity_failure", "reason": "unrecognized_terminal"}


def run_bounded(jobs, worker, *, workers, before_start, record, stop_event=None):
    """One frozen sequence, first infrastructure failure stops dispatch, active work joins.

    worker and callbacks are fixed by the launch module for real execution. Pure
    tests inject synthetic callables here; this function does not issue authority.
    """
    if type(workers) is not int or not 1 <= workers <= 64:
        raise ValueError("bounded_integer_workers_required")
    ids = [job["invocation_id"] for job in jobs]
    if len(ids) != len(set(ids)):
        raise ValueError("duplicate_jobs")
    active, reports, stops, begun = {}, [], [], []
    queue = iter(jobs)
    stopped, exhausted = False, False
    started_at = time.monotonic()
    with ThreadPoolExecutor(max_workers=workers) as pool:
        while active or not exhausted and not stopped:
            while not stopped and not exhausted and len(active) < workers:
                if stop_event is not None and stop_event.is_set():
                    stopped = True
                    stops.append({"reason": "operator_stop_new"})
                    break
                try:
                    job = next(queue)
                except StopIteration:
                    exhausted = True
                    break
                try:
                    before_start(job)
                    record("reserved", {"invocation_id": job["invocation_id"]})
                    future = pool.submit(worker, job)
                except Exception as exc:
                    stopped = True
                    stops.append({"invocation_id": job["invocation_id"], "reason": type(exc).__name__})
                    break
                active[future] = job
                begun.append(job["invocation_id"])
            if not active:
                break
            completed, _ = wait(active, return_when=FIRST_COMPLETED)
            # Consume the whole completed batch before admitting another job.
            for future in completed:
                job = active.pop(future)
                try:
                    report = future.result()
                except BaseException as exc:
                    report = {"invocation_id": job["invocation_id"], "error_type": type(exc).__name__}
                decision = terminal_decision(job, report)
                reports.append({"invocation_id": job["invocation_id"], "decision": decision, "report": report})
                record("terminal", reports[-1])
                if not decision["continue"]:
                    stopped = True
                    stops.append({"invocation_id": job["invocation_id"],
                                  "reason": decision["classification"]})
            if stopped:
                exhausted = True
    record("drain", {"local_workers": 0, "stop_new": stopped,
                     "provider_quiescence_proven": False})
    return {"schema_version": "restart-bounded-dispatch-v1", "reports": reports,
            "started_invocation_ids": begun,
            "unstarted_invocation_ids": [iid for iid in ids if iid not in set(begun)],
            "stop_reasons": stops, "local_workers": 0,
            "execution_complete": len(reports) == len(jobs) and not stops,
            "score_complete": len(reports) == len(jobs) and all(
                row["decision"].get("score_complete") is True for row in reports),
            "provider_quiescence_proven": False,
            "elapsed_seconds": time.monotonic() - started_at}
