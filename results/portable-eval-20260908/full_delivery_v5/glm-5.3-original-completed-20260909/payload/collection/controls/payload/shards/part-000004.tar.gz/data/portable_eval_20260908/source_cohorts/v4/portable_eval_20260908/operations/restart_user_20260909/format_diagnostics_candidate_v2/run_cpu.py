"""Run only the bounded synthetic suite and write a fresh local CPU receipt."""
import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import socket
import subprocess
import sys
import time
import unittest

HERE = Path(__file__).resolve().parent


def snapshot(paths):
    rows = []
    for p in paths:
        before = p.stat()
        blob = p.read_bytes()
        after = p.stat()
        assert (before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns)
        rows.append({'path': str(p), 'sha256': hashlib.sha256(blob).hexdigest(), 'bytes': len(blob),
                     'mtime_ns': after.st_mtime_ns})
    return rows


def forbidden(*args, **kwargs):
    raise AssertionError('network_or_child_process_forbidden_in_synthetic_suite')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output-name', required=True)
    args = parser.parse_args()
    assert args.output_name and Path(args.output_name).name == args.output_name and args.output_name.startswith('cpu_')
    output = HERE / args.output_name
    assert not output.exists()
    import diagnostics
    import test_diagnostics
    paths = [HERE / name for name in ('diagnostics.py', 'test_diagnostics.py', 'run_cpu.py', 'README.zh.md')]
    paths += [test_diagnostics.SOURCE / name for name in diagnostics.SOURCE_PINS]
    before = snapshot(paths)
    socket.socket = forbidden
    socket.create_connection = forbidden
    subprocess.Popen = forbidden
    started = datetime.now(timezone.utc).isoformat()
    clock = time.perf_counter()
    log = io.StringIO()
    suite = unittest.defaultTestLoader.loadTestsFromModule(test_diagnostics)
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
    elapsed = time.perf_counter() - clock
    after = snapshot(paths)
    assert before == after
    receipt = {'schema_version': 'format-diagnostics-synthetic-cpu-v1', 'started_utc': started,
               'elapsed_seconds': elapsed, 'python': sys.version, 'tests_run': result.testsRun,
               'passed': result.wasSuccessful(), 'failures': len(result.failures), 'errors': len(result.errors),
               'skips': len(result.skipped), 'bindings': before, 'bindings_unchanged': True,
               'current_formal_raw_or_results_read': False, 'model_calls': 0, 'scorer_calls': 0,
               'actual_go_issued': False, 'actual_post_freeze_diagnostics_run': False,
               'fresh_independent_final_audit': 'not_performed', 'scope': 'synthetic-only in-memory fixtures and pinned pure source functions'}
    output.mkdir(mode=0o700)
    log_bytes = log.getvalue().encode()
    with (output / 'CPU_LOG.txt').open('xb') as stream:
        stream.write(log_bytes)
    receipt['log'] = {'path': str(output / 'CPU_LOG.txt'), 'sha256': hashlib.sha256(log_bytes).hexdigest(), 'bytes': len(log_bytes)}
    encoded = json.dumps(receipt, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
    with (output / 'receipt.json').open('xb') as stream:
        stream.write(encoded)
    print(json.dumps({'passed': result.wasSuccessful(), 'tests': result.testsRun,
                      'receipt_path': str(output / 'receipt.json'), 'receipt_sha256': hashlib.sha256(encoded).hexdigest()}))
    return 0 if result.wasSuccessful() else 2


if __name__ == '__main__':
    raise SystemExit(main())
