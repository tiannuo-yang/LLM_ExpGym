# 格式诊断候选：有限独立工程审阅

结论：本范围未发现阻断真实、正确封存 exporter 产品的具体错误；有一个低优先级异常接受集合差异，不能把本结论写成所有 Python 异常输入完全等价。没有运行真实诊断或最终 post-output/post-analysis 审计，没有读任何当前答案、分数、HTTP raw、key，没有评分、模型或网络调用。候选与生产源码未修改。

## 结论与证据

1. **计划分母及 unknown：通过。** `../format_diagnostics_candidate_v1/diagnostics.py:433` 绑定全部 783 records；444–451 选择全部 234 Search+78 Audit 池；472–501 只有完整 N4 terminal 才诊断，其他状态保留行、原因、refs、`structural=null`，独立计入 unavailable。492–493 在该分支前累计 312 池/1,248 agent，519–520 核 12 组完整分母。不把缺答 None 和基础设施未知混作零分。missing 计数只属于可诊断池，不能用它代表所有未完成 agent 的缺答率。

2. **正常字符串/None 的原解析与投票：通过本次有限核对。** Search 候选123–147与冻结 `source_cohorts/v5/LLM_ExpGym/expgym/task_restricted_search.py:162`、`poolact.py:141` 对照；JSON-list 与普通文本的 1–5 词过滤差异、整集合票、最早原字符串代表均保留。Audit 候选214–238与原 `task_evidence_audit.py:345` 的首次 JSON→末尾分号/fence 回退顺序相同；候选289–316与原 `poolact.py:317` 起的投票相比，先 label 胜出、再仅在该 label 支持者内对完整 evidence key 投票，两级平局均按原 agent 输入顺序。`scorer_evidence('12')={1,2}`、vote 非 list→空，以及坏成员整体 scorer 回空/vote 保留文本的历史差异未统一掉。逐 hypothesis 的数量只是答案 key union，gold 分母明确 null。

3. **原件来源：通过本次绑定核对。** 候选378–408 同时绑定 plan/execution/seal/closure；410–430 核 exporter 的恰好16个产品字节、manifest/records 哈希与相同 plan/execution；459–464 要求每个被消费原件同时出现在 record/source_index/export原件索引/seal。339–360 比较独立 agent 与 embedded terminal、agent顺序/seed/model/scenario/regime/strategy/selector。与冻结 exporter.py:372–383 的实际产物字段、seal.py:294–310 相容。这里信任外部 ROOT 已接受的完整 exporter/seal；不重新独立认证整个题库、重评分、当前 provider 静默或全部未读原件。

4. **无主指标替换/因果归因：通过。** 候选325–335 只用原报告的4个分数计算 MI 与原 MV−MI；515–518 按正/零/负和格式现象共现分账。既不另选解析器胜者也不评估替代分数。它不是 PoolAct−Naive 的主比较，更不能量化“提升多少由格式产生”。

5. **P2 文档限制，非成功终态阻断：异常接受集合比原函数宽。** 候选129、230 捕获 `ValueError`，原 Search parser:175、Search vote:148 及 Audit vote:310 捕获 `json.JSONDecodeError`/`TypeError`。当前 Python3.11 默认整数位数限制下，纯合成5000位裸整数使原 Search 两纯函数抛 `ValueError`，而候选回退并返回。见 `edge_case.py`：没有 gold/evaluator 调用。在同一整数限制的冻结运行协议下，**该反例不能穿过有效原 exporter+seal成为 diagnosed terminal**：原 `missing_final.py:154` 仍调用原 aggregate；`scripts/run_poolact.py:589` 在构造完整 result 前运行它；原 vote 抛错，不会被“缺答”政策投影成空答案。exporter.py:205–220 对 success 要求原 exit0、完整原件及原 CLI verified-resume；294将该未成功执行映射为非terminal。诊断器467–479对此只保留不可用行/refs，不调用 parser。因此候选 README 的“严格复制”应解释为**正确冻结生产/导出成功终态域内的解析与投票规则**，不是所有 helper 异常输入逐字等价。本范围不要求改变冻结实验、分母或重做候选；若未来要诊断原失败答案本身，必须另行处理这项边界，而不能沿用成功终态域保证。

## 小型独立 CPU 核对

`review.py` 四项：完整计划/不可用 null；65种合成 Search 解析集合和原代表；Audit 条件证据/两级早先平局；agent身份和 export→plan 绑定错误拒绝。仅抽取已 pin 源码的指定纯 parser/aggregate AST；aggregate 的 evaluator=None，无评分函数执行。没有重跑 owner 全测试、没有导入任务模块顶层。候选的内存 fixture 明确不是实际 launcher 或 exporter E2E。

- Python3.10：4 PASS/0 errors，0.06148s；`cpu_310_v1/RECEIPT.json` SHA `63cf31d382f9f2f95fa11ab42b4ac3ee5538dd2e6809dd56d5fb94795ac7af5b`。
- Python3.11：4 PASS/0 errors，0.05196s；`cpu_311_v1/RECEIPT.json` SHA `8ffae1f44fdfd444e1cd717c0fbbb02886c1fe9d58fe79f54bd5f1948e77a932`。
- 两次各9份保护源码/依赖 bytes、SHA、mode、mtime、inode/device 前后不变。没有触碰 candidate 文件。

## 仍需保留的界限

- `Reader` 64 MiB/单文件、8 GiB累计原字节硬限制（83–84、104–106）；超过会拒绝。它不是 JSON DOM 峰值内存保证，也没有测试真实最大产物可用性。不要根据小 fixture 宣称完整运行必定能读入。
- 外部 GO 的 post-freeze 承诺、完整原 exporter 和 run seal 是前提；仅本候选 source SHA 字段不能替代原产物的外部审阅。只按实际成功读取原字节核 hash，不保证所有未读文件或未来/恶意 change-and-revert。
- 这里不评估实际格式频次或成绩方向。不生成 ROOT GO、实际验收、真实诊断、重新评分或发布授权。最终正式输出和分析封存后仍须新独立复查。
