"""One authorized original GLM sealer invocation; logs only, no retries."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

WS = Path('/lustrefs/users/chufan.shi/codex_space_tn')
OP = WS / 'portable_eval_20260908/source_cohorts/v4/portable_eval_20260908/operations/restart_user_20260909'
HERE = Path(__file__).absolute().parent
RUN = OP.parents[1] / 'formal_runs/restart-20260909-v5-glm-5.3-formal'
OUT = OP / 'sealed_restart_runs_v1/glm-5.3-formal-completed-20260909'
PROGRAM = OP / 'seal_restart_v1/seal.py'
PY = WS / 'LLM_ExpGym/.venv/bin/python'
PLAN = OP / 'compiled_restart-20260909-v5-glm-5.3-formal/plan.json'
CONTROLS = [
    (OP / 'glm_formal_terminal_root_v1/ROOT_TERMINAL.json', '7298e516b2171c46085359320138513b6f9f7fb40b2ccd593f57b366f01c261a'),
    (OP / 'formal_monitor_v5/glm-5.3/observation.00606.json', 'ff24e0df34225ebfe84fd418d79ea93ba04c77e2c59f1f11318127ca86989cb6'),
    (OP / 'compiled_restart-20260909-v5-glm-5.3-formal/ROOT_GO.json', '86484659622bc3115232ac1f86cf5d18ae860647162c953038ecccc7482c3a30'),
    (OP / 'source_acceptance_v5_final.json', '0b1166cb5549ceb606bd98086809548cb0d83c3e94070e3570cc4783e1b1a744')]
INPUTS = [(PROGRAM, '1d30bf17c4cbe19fea21c2d65ab50e83db4aed9770ae6d1320c2fb3c34a424f2'),
          (PLAN, '8b9ed4a00674689f62aaca73cc35c84f1d88439fe5f75b636164bfe4d70e574b'),
          (RUN / 'execution.json', '16d4569396aa2dd95393013084b3d3b70eaff06e1a8d95d39dc35a36652344b2')] + CONTROLS
ARGV = [str(PY), '-B', str(PROGRAM), '--plan', str(PLAN), '--plan-sha256', INPUTS[1][1],
        '--execution', str(RUN / 'execution.json'), '--execution-sha256', INPUTS[2][1],
        '--run-root', str(RUN), '--output-dir', str(OUT)]
for p, digest in CONTROLS:
    ARGV += ['--control-ref', str(p), digest]

def utc():
    return datetime.now(timezone.utc).isoformat()

def write(name, value):
    raw = (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()
    with (HERE / name).open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    return {'path': str(HERE / name), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def digest_file(p):
    h = hashlib.sha256()
    with p.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

os.umask(0o077)
for p, expected in INPUTS:
    assert p.resolve() == p and p.is_file() and not p.is_symlink()
    assert digest_file(p) == expected
assert OUT.parent.is_dir() and not OUT.exists() and not OUT.is_symlink()
assert not Path('/proc/568846').exists()
started = utc()
t0 = time.monotonic()
intent = write('invocation.json', {'argv': ARGV, 'cwd': str(WS), 'operator_pid': os.getpid(),
    'operator_ppid': os.getppid(), 'operator_started_utc': started,
    'input_refs': [{'path': str(p), 'sha256': h} for p, h in INPUTS],
    'authorization': 'ROOT single sealer GO in task; not a model/export/score/service GO', 'automatic_retry': False})
with (HERE / 'stdout.log').open('xb') as stdout, (HERE / 'stderr.log').open('xb') as stderr:
    child = subprocess.Popen(ARGV, cwd=WS, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
    start = write('operator_start.json', {'invocation_ref': intent, 'child_pid': child.pid,
        'child_ppid': os.getpid(), 'child_pgid': os.getpgid(child.pid), 'child_session_id': os.getsid(child.pid),
        'child_spawn_observed_utc': utc(), 'original_model_parent_pid': 568846,
        'original_model_parent_absent_before_spawn': True})
    print(json.dumps({'operator_start': start, 'child_pid': child.pid}), flush=True)
    exit_code = child.wait()
    stdout.flush(); stderr.flush()
    os.fsync(stdout.fileno()); os.fsync(stderr.fileno())
finished = write('operator_finish.json', {'invocation_ref': intent, 'operator_start_ref': start,
    'child_pid': child.pid, 'actual_exit_code': exit_code, 'wait_returned': True,
    'finished_at_utc': utc(), 'elapsed_seconds_including_pre_spawn_metadata': time.monotonic()-t0,
    'stdout_ref': {'path': str(HERE / 'stdout.log'), 'sha256': digest_file(HERE / 'stdout.log'), 'bytes': (HERE / 'stdout.log').stat().st_size},
    'stderr_ref': {'path': str(HERE / 'stderr.log'), 'sha256': digest_file(HERE / 'stderr.log'), 'bytes': (HERE / 'stderr.log').stat().st_size},
    'automatic_retry': False, 'export_or_score_or_service_actions': False})
print(json.dumps({'operator_finish': finished, 'actual_exit_code': exit_code}), flush=True)
sys.exit(exit_code if exit_code >= 0 else 128-exit_code)
