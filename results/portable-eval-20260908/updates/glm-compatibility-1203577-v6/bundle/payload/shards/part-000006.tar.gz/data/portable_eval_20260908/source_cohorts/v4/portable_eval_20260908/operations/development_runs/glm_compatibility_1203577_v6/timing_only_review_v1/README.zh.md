# GLM 单次开发运行：仅计时复核

仅依据 `glm_compatibility_1203577_v6` 已完成运行的原件计时字段、请求用量、finish reason 和 owner 元数据；不读取或报告答案、质量分数、改善/下降方向。不是评分审查、协议接受或用户要求的最终分析后独立复审。独立 auditor 正在修正合法 Hugging Face 数据叶 symlink 的读取兼容问题，**本次未取得协议接受**。

## 观测结果

- 控制器原记录开始：2026-09-08 **15:42:43.565 UTC**；已有结束观测：**18:22:28 UTC**，跨度 **9,584.435 秒，约 2 小时 39 分 44 秒**。末端仅秒精度，不是精确 OS 退出时间。随后 drain 观测为 18:23:46 UTC；本报告未主动查询进程/服务。
- 15 个任务从首次 run_start 到最后推算 run 结束：**9,547.496 秒**。任务区间重叠峰 **8**；ExpGym 阶段峰 1，PoolAct 阶段峰 8。
- 三个 ExpGym 任务阶段跨度 **1,771.448 秒（29 分 31 秒）**；十二个 PoolAct 任务阶段跨度 **7,770.843 秒（2 小时 9 分 31 秒）**。这是运行阶段名称，不是比较质量。
- 475 条任务 HTTP attempt 的 UTC 跨度 **9,544.622 秒**，客户端同时在途峰 **26**；另 12 条 nonce 请求跨度 **26.204 秒**、峰 1。HTTP 在途含排队和客户端等待，不等于 GPU 同时解码数。
- 475 条任务的 provider 已知用量：输入 **17,219,392**、输出 **2,955,570**；其中 reasoning **2,869,475** 是输出子集，不能再加一次。nonce 另有输入 2,654、输出 1,010。该范围 prompt/completion 缺报数为 0，但不等于账单、全项目成本或 GPU 利用率审计。
- 任务 finish reason 计数仅作运行元数据：tool_calls 415、stop 51、length 9。它们不是任务正确性或协议通过证据。

## 15 个任务

下表保持原 execution results 顺序。秒数来自 `final_status.run.elapsed_seconds`，不是从日志文本或分数反推。Audit 的 0/2 按原 `question_index` 标记，不推断为 hypothesis order。CSV 提供完整 job_id、原 run_start 和推算终点；JSON 保留全部精度。

| 阶段 / 场景 / strategy | run 秒数 | 请求数 | 单任务客户端在途峰 |
|---|---:|---:|---:|
| ExpGym / Search moderate / single | 115.690 | 8 | 1 |
| ExpGym / Audit index 0 / single | 1,375.721 | 11 | 1 |
| ExpGym / Tuning / single | 272.497 | 7 | 1 |
| PoolAct / Search tight / naive | 52.792 | 22 | 4 |
| PoolAct / Search tight / cached | 79.611 | 24 | 4 |
| PoolAct / Search tight / poolact | 1,222.931 | 25 | 1 |
| PoolAct / Tuning / naive | 1,599.732 | 33 | 4 |
| PoolAct / Audit index 2 / naive | 1,907.603 | 44 | 4 |
| PoolAct / Audit index 0 / naive | 2,144.433 | 47 | 4 |
| PoolAct / Tuning / cached | 1,246.851 | 34 | 4 |
| PoolAct / Audit index 2 / cached | 2,617.822 | 50 | 4 |
| PoolAct / Audit index 0 / cached | 2,658.897 | 56 | 4 |
| PoolAct / Tuning / poolact | 2,303.085 | 24 | 1 |
| PoolAct / Audit index 2 / poolact | 5,966.745 | 45 | 1 |
| PoolAct / Audit index 0 / poolact | 7,769.744 | 45 | 1 |

单任务池内请求重叠峰差异是时间元数据观测；本次不根据它判断质量、算法缺陷或未经核实的串行化原因。

## 计时语义与四副本边界

冻结源码 `design/development_v4_candidate/real_entry.py:202–215`：run_start 是 Popen 前的墙钟；真正 elapsed 是后续单调时钟计时，包含整个 child、stdout 脱敏和日志写入/fsync，排除此前 identity、随后 score/resume/raw-check。run_start 与 monotonic 起点之间还有 start 文件落盘、环境准备，因此 **run_start + elapsed 是近似终点，不是独立记录的精确退出 UTC**。未建立这个间隔或时钟同步的误差上界。

`wire_child.py:26` 的 child_entry 原件只有 job_id/pid，**没有时间字段**。JSON 保留其文件系统 mtime 作为单独旁证，不把它冒充进程启动时刻。`execution_start` 在静态预检后、nonce 前写入（real_entry.py:283），因此总体跨度不包含环境部署、模型加载和前置静态校验。

冻结 client `LLM_ExpGym/expgym/llm_clients.py:656–662,347–348`：raw started/finished 是 UTC 墙钟；wall_time_seconds 是单 attempt 单调时钟，包含初始 dump、请求守卫、网络/服务排队/生成及解析，不能拆成纯 prefill/decode。本范围 raw 墙钟差与单调耗时差最大约 0.000104 秒；这不是跨机器时钟同步或任务端点误差上界。

四 serving 副本不支持直接按单副本耗时除以 4。实际编排是 nonce → ExpGym workers=1 → PoolAct workers=8（real_entry.py:288–300），存在阶段 barrier、串行依赖回合、工具等待、异质输出长度和长尾；客户端排队与批处理也不等同于副本忙碌度。没有同一工作负载的一副本对照，也未读取 per-replica GPU 时间线。所有任务 elapsed 相加约 8.704 小时仅是重叠 child 区间之和，**不是 GPU 小时**。

这里只保留一次 GLM 开发 scope 的观测。**不将 15 个样本外推全部 615 矩阵，不新建正式 M/R 方案；等待 K3 同 scope 的计时。**

## 原件与导航

- [timing.json](timing.json)：逐任务与整体计时、重叠、用量及全部限制。
- [per_task_timing.csv](per_task_timing.csv)：便于核对的 15 行时间表。
- [raw_timing_metadata.json](raw_timing_metadata.json)：487 条仅允许字段的窄投影；不复制 response message 或 request payload。
- [owner_context_metadata.json](owner_context_metadata.json)：PoolAct 顶层 owner 元数据补充；不声称完成 owner 链接审计。首投影的 owner_trace_path_count 只计非空 trace_path，不是 owner 总数。
- [input_manifest.json](input_manifest.json)：535 原件的 SHA256/bytes/mtime，读取前后逐字节哈希一致；包括 15×3 个 run/final/child-entry、487 raw、execution/start/completion 三件。
- [summarize.py](summarize.py)、[owner_metadata.py](owner_metadata.py)：仅离线读取和字段白名单投影；输出用新建模式，不发送请求，不调用模型/评分器。

外部指定 pins：execution `3b9b30690e5f947bc46b4ce0fc3e8025f963625108428c12ce73bbb0a226da11`；operator_completion `25a7023816a5c431b8ee26c4be4092e9a0463ac8704543ee5be6df9134c4e72b`。两者均实际重核。
