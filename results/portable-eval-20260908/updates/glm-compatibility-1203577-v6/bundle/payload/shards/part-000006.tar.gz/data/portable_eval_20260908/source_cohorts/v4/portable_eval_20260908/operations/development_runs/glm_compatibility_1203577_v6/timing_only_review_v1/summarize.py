"""Bounded timing-only projection; never select answers, scores, or audit verdicts."""
import csv
import hashlib
import io
import json
import math
import os
from pathlib import Path
import stat
from datetime import datetime, timezone
from collections import Counter

HERE = Path(__file__).resolve().parent
OP = HERE.parent
RUN = OP / "real_run"
PINS = {
    "real_run/execution.json": "3b9b30690e5f947bc46b4ce0fc3e8025f963625108428c12ce73bbb0a226da11",
    "operator_completion.json": "25a7023816a5c431b8ee26c4be4092e9a0463ac8704543ee5be6df9134c4e72b",
}
INPUTS = {}


def read(path):
    path = Path(path)
    assert path.is_relative_to(OP) and not path.is_relative_to(HERE)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
        with os.fdopen(fd, "rb", closefd=False) as stream:
            body = stream.read()
        after = os.fstat(fd)
        assert (before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns)
    finally:
        os.close(fd)
    ref = {"sha256": hashlib.sha256(body).hexdigest(), "bytes": len(body), "mtime_ns": after.st_mtime_ns}
    key = str(path.relative_to(OP))
    if key in PINS:
        assert ref["sha256"] == PINS[key], key
    if key in INPUTS:
        assert INPUTS[key] == ref, key
    INPUTS[key] = ref
    return json.loads(body)


def utc(value):
    return datetime.fromtimestamp(value, timezone.utc).isoformat(timespec="microseconds")


def stamp(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()


def number(value):
    assert type(value) in (int, float) and math.isfinite(value) and value >= 0
    return value


def intervals_summary(intervals):
    assert intervals and all(end >= start for start, end in intervals)
    events = sorted([(start, 1) for start, _ in intervals] + [(end, -1) for _, end in intervals])
    active = peak = 0
    previous = events[0][0]
    occupancy = Counter()
    for at, delta in events:
        occupancy[active] += at - previous
        active += delta  # Half-open intervals: an end precedes a simultaneous start.
        peak = max(peak, active)
        previous = at
    assert active == 0
    start, end = min(x[0] for x in intervals), max(x[1] for x in intervals)
    integral = sum(level * seconds for level, seconds in occupancy.items())
    return {"first_start_utc": utc(start), "last_end_utc": utc(end), "span_seconds": end - start,
            "peak_overlapping_intervals": peak, "summed_interval_seconds": integral,
            "union_busy_seconds": sum(seconds for level, seconds in occupancy.items() if level),
            "average_active_intervals_over_span": integral / (end - start) if end > start else None,
            "seconds_by_overlap_count": dict(sorted(occupancy.items()))}


def safe_usage(value):
    value = value if type(value) is dict else {}
    details = value.get("completion_tokens_details")
    details = details if type(details) is dict else {}
    reasoning = value.get("reasoning_tokens", details.get("reasoning_tokens"))
    result = {name: value.get(name) for name in ("prompt_tokens", "completion_tokens", "total_tokens")}
    result["reasoning_tokens_subset_not_added"] = reasoning
    for item in result.values():
        assert item is None or (type(item) is int and item >= 0)
    return result


def raw_metadata(path, group):
    value = read(path)
    response = value.get("response_json")
    response = response if type(response) is dict else {}
    choices = response.get("choices") or []
    # Never access message, content, reasoning_content, tool arguments, or request_payload.
    finish = choices[0].get("finish_reason") if choices else None
    assert finish is None or type(finish) is str
    context = value.get("context") or {}
    job = context.get("job") or {}
    metadata_keys = ("scenario", "cost_regime", "rep", "seed", "tuning_task", "question_index", "hypothesis_order", "agent_id")
    result = {"path": str(path.relative_to(OP)), "group": group, "request_id": value.get("request_id"),
              "generation_id": value.get("generation_id"), "attempt": value.get("attempt"),
              "started_at_utc": value["started_at_utc"], "finished_at_utc": value["finished_at_utc"],
              "wall_time_seconds": number(value["wall_time_seconds"]), "state": value.get("state"),
              "finish_reason": finish, "usage": safe_usage(response.get("usage")),
              "owner_trace_path": context.get("trace_path"),
              "owner_job_metadata": {key: job[key] for key in metadata_keys if key in job}}
    assert stamp(result["finished_at_utc"]) >= stamp(result["started_at_utc"])
    return result


def raw_summary(rows):
    if not rows:
        return {"records": 0}
    intervals = [(stamp(row["started_at_utc"]), stamp(row["finished_at_utc"])) for row in rows]
    result = intervals_summary(intervals)
    result.update(records=len(rows), distinct_generation_ids=len({r["generation_id"] for r in rows}),
                  states=dict(Counter(str(r["state"]) for r in rows)),
                  finish_reasons=dict(Counter(str(r["finish_reason"]) for r in rows)),
                  client_monotonic_attempt_seconds_sum=sum(r["wall_time_seconds"] for r in rows),
                  max_abs_wall_vs_monotonic_difference_seconds=max(abs((end-start)-row["wall_time_seconds"])
                      for row, (start, end) in zip(rows, intervals)),
                  owner_trace_path_count=len({r["owner_trace_path"] for r in rows if r["owner_trace_path"]}))
    result["usage"] = {key: {"known_sum": sum(row["usage"][key] for row in rows if row["usage"][key] is not None),
                            "unknown_record_count": sum(row["usage"][key] is None for row in rows)}
                       for key in rows[0]["usage"]}
    return result


def output(name, value):
    body = (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode()
    with (HERE / name).open("xb") as stream:
        stream.write(body)


def main():
    execution = read(RUN / "execution.json")
    completion = read(OP / "operator_completion.json")
    started = number(read(RUN / "execution_start.json")["started_unix"])
    # Only identifiers and run timings are selected from the controller receipt.
    stages = [(stage["stage"], result["job_id"], result["run"]["elapsed_seconds"])
              for stage in execution["stages"] for result in stage["results"]]
    assert len(stages) == len({job for _, job, _ in stages}) == 15
    assert {path.name for path in (RUN / "journal").iterdir() if path.is_dir()} == {job for _, job, _ in stages}
    tasks, raws = [], []
    for stage, job, embedded_elapsed in stages:
        directory = RUN / "journal" / job
        final = read(directory / "final_status.json")
        elapsed = number(final["run"]["elapsed_seconds"])
        assert final["job_id"] == job and elapsed == embedded_elapsed
        begin = number(read(directory / "run_start.json")["started_unix"])
        child = read(directory / "child_entry.json")
        assert child["job_id"] == job and set(child) == {"job_id", "pid"}
        child_ref = INPUTS[str((directory / "child_entry.json").relative_to(OP))]
        selected = [raw_metadata(path, job) for path in sorted((RUN / "raw" / job).glob("*.json"))]
        raws.extend(selected)
        tasks.append({"job_id": job, "stage": stage, "run_start_utc": utc(begin),
                      "run_start_unix": begin, "run_elapsed_seconds": elapsed,
                      "derived_run_end_utc": utc(begin + elapsed), "derived_run_end_unix": begin + elapsed,
                      "child_entry_recorded_timestamp": None,
                      "child_entry_filesystem_mtime_utc_not_process_start": utc(child_ref["mtime_ns"] / 1e9),
                      "raw": raw_summary(selected)})
    nonce = [raw_metadata(path, "nonce_protocol") for path in sorted((RUN / "protocol" / "glm-5.3" / "raw").glob("*.json"))]
    assert len(nonce) == 12
    all_raws = nonce + raws
    observation = completion["exit_observation"]
    observed_end = stamp(observation["execution_and_stdout_mtime_utc"])
    assert observation["controller_started_unix"] == started
    result = {
        "schema_version": "glm-development-timing-only-review-v1",
        "scope": "One completed GLM development run, 15 tasks plus 12 nonce requests; no quality fields selected",
        "classification": "development_timing_not_scoring_not_complete_audit",
        "protocol_acceptance_obtained": False,
        "independent_auditor_status": "Legal Hugging Face data-leaf symlink compatibility correction in progress; no protocol acceptance obtained",
        "controller": {"recorded_start_utc": utc(started), "terminal_observation_utc": utc(observed_end),
                       "observed_span_seconds": observed_end - started,
                       "terminal_observation_precision": observation["time_precision"],
                       "drain_observed_at": completion["process_completion"]["observed_at"]},
        "tasks": tasks,
        "task_intervals": intervals_summary([(r["run_start_unix"], r["derived_run_end_unix"]) for r in tasks]),
        "stages": {stage: intervals_summary([(r["run_start_unix"], r["derived_run_end_unix"])
                                             for r in tasks if r["stage"] == stage])
                   for stage in sorted({r["stage"] for r in tasks})},
        "task_raw": raw_summary(raws), "nonce_raw": raw_summary(nonce), "all_raw": raw_summary(all_raws),
        "limitations": [
            "No answers, model reasoning, tool arguments, outcomes, scores, quality directions, or scorer logs selected or reported.",
            "Raw files were hashed and JSON-decoded solely to project explicit timing/usage/finish/owner fields; response messages and request payloads were not accessed or copied.",
            "run elapsed is whole-child monotonic duration, not pure inference; includes tool/data waits and final run-log serialization, excludes identity and later resume/scoring/checks.",
            "Derived task endpoints combine recorded UTC start with monotonic duration; no clock-synchronization error bound is available.",
            "child_entry bytes contain no timestamp; filesystem mtime is explicitly ancillary, not a process start observation.",
            "Raw overlap is client in-flight HTTP attempt concurrency, not GPU active decode, batch occupancy, or per-replica utilization.",
            "Four replicas do not imply a fourfold speedup: serial nonce phase, serial ExpGym tasks, bounded PoolAct task stage, dependent per-agent turns, heterogeneous lengths, queueing, tools and stage barriers remain.",
            "No same-workload single-replica baseline or precise allocation occupancy is established; not GPU billing or theoretical throughput.",
            "Known usage is provider-reported; reasoning is an output subset and is never added to completion tokens.",
            "Single development scope, not representative formal repeats; no 15-to-615 extrapolation or new M/R design. Wait for K3 matched scope timing.",
        ],
    }
    for path in list(INPUTS):
        read(OP / path)
    output("timing.json", result)
    output("raw_timing_metadata.json", all_raws)
    output("input_manifest.json", {"originals_unchanged_on_reread": True, "files": INPUTS})
    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(["job_id", "run_start_utc", "run_elapsed_seconds", "derived_run_end_utc", "raw_records", "client_raw_peak"])
    for row in tasks:
        writer.writerow([row["job_id"], row["run_start_utc"], row["run_elapsed_seconds"], row["derived_run_end_utc"],
                         row["raw"]["records"], row["raw"].get("peak_overlapping_intervals", 0)])
    with (HERE / "per_task_timing.csv").open("x", newline="") as stream:
        stream.write(buffer.getvalue())
    print(json.dumps({"controller": result["controller"], "task_intervals": result["task_intervals"],
                      "stages": result["stages"], "task_raw": result["task_raw"], "nonce_raw": result["nonce_raw"],
                      "original_files_verified": len(INPUTS)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
