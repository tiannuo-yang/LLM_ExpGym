"""Explicit owner metadata supplement; no payload, message, or score fields."""
import json
import hashlib
from collections import defaultdict
import summarize as s


def main():
    original_manifest = json.loads((s.HERE / "input_manifest.json").read_bytes())["files"]
    projected = json.loads((s.HERE / "raw_timing_metadata.json").read_bytes())
    rows, owners = [], defaultdict(set)
    keys = ("runner", "scenario", "strategy", "cost_regime", "agent_id", "repeat_index",
            "repeats", "question_index", "seed", "tuning_task", "output_dir")
    for item in projected:
        path = item["path"]
        value = s.read(s.OP / path)
        assert s.INPUTS[path] == original_manifest[path]
        context = value.get("context") or {}
        selected = {key: context[key] for key in keys if key in context}
        # ExpGym keeps job metadata nested; this supplement records only the
        # top-level PoolAct owner metadata omitted from the first projection.
        rows.append({"path": path, "group": item["group"], "owner_context_metadata": selected})
        if "agent_id" in selected:
            owners[item["group"]].add(selected["agent_id"])
    for path in list(s.INPUTS):
        s.read(s.OP / path)
    s.output("owner_context_metadata.json", {
        "scope": "Metadata supplement only; no owner linkage or scientific audit claimed",
        "source_projection_sha256": hashlib.sha256((s.HERE / "raw_timing_metadata.json").read_bytes()).hexdigest(),
        "original_bytes_match_first_manifest_and_reread": True,
        "observed_agent_ids_by_task": {job: sorted(values) for job, values in sorted(owners.items())},
        "rows": rows,
    })
    print(json.dumps({"raw_records": len(rows), "observed_agent_ids_by_task":
                      {job: sorted(values) for job, values in sorted(owners.items())}}, indent=2))


if __name__ == "__main__":
    main()
