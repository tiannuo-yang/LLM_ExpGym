# 窄勘误：本地 PID 检查不等于 provider drain

原 README 第一条将 **18:23:46 UTC** 写成“随后 drain 观测”，表述不准确。原 `timing.json` 的 `controller.drain_observed_at` 也存在同一命名错误：它直接来自 `operator_completion.json` 的 `process_completion.observed_at`，实际只表示本地父进程和 15 个记录 child PID 的检查时间。原 operator 文档明确说 provider drain 未由 operator 探测，须另有外部 ROOT 收据。

应按下列独立字段解释，不混成同一个时刻：

| 更正后的字段语义 | 原记录时间（UTC） | 证据 |
|---|---|---|
| `local_recorded_pid_absence_observed_at` | 2026-09-08 18:23:46 | `operator_completion.json → process_completion.observed_at` |
| `provider_capture_started_at` | 2026-09-08 18:25:29.426850 | `ROOT_POST_DEVELOPMENT_DRAIN.json → root_observations.provider_capture.started_utc` |
| `provider_capture_finished_at` | 2026-09-08 18:25:29.605667 | 同上 `finished_utc` |
| `root_local_process_recheck_at` | 2026-09-08 18:30:52.054978 | `ROOT_POST_DEVELOPMENT_DRAIN.json → root_observations.process_recheck.at_utc` |

ROOT drain 收据 SHA256 为 `7b248356ce675c435c02d23deb3ba8544adf83be23812efed9fd772100f6109d`；本次已核该原件及 operator_completion 的既有 pin。provider 时间是对这份已封 ROOT 收据的归引，本勘误没有重新读取全部 provider capture 原件、发起 provider 探测或独立重做 drain 审计。

原 `controller.drain_observed_at` 字段保留作历史原件，但其含义由本勘误覆盖为 **本地 PID 检查时间，不能作为 provider/ROOT drain 时间**。原提取脚本的同名映射也是历史命名错误，不能据字段名扩大其证明范围。

这不是计时数值错误：控制器的 18:22:28 结束观测、9,584.435 秒跨度、15 个任务耗时、请求区间及重叠峰均不变。未重跑计时；原 README、CSV、JSON、脚本和 receipt 全部保留，未覆盖。没有新增质量分析、协议接受或最终研究审计结论。机器可查的更正见 [correction_receipt.json](correction_receipt.json)。
