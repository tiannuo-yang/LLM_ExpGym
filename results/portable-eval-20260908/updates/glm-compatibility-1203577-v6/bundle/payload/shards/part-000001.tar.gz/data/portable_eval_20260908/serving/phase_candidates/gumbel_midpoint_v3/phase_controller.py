#!/usr/bin/env python3
"""One owned allocation, one numerical attempt, three explicitly commanded loads.

No model request code. A load/metadata-ready state is not protocol/science GO.
Unexpected rank exit tears down only owned children and leaves a terminal HOLD.
"""
from __future__ import annotations

import argparse
import csv
import io
import json
import os
from pathlib import Path
import re
import secrets
import signal
import socket
import subprocess
import time

from phase_common import (BASE, STUDY, RUNTIME, VENV, IMAGE, GPU_SCRIPT, OLD_SERVING,
                          OLD_PYTHON, PHASES, check_environment, command_valid,
                          digest, read_regular, source_identity, utc, verify_pins, write_new)
from profile_contract import profile_sha256, randomness_contract, validate_profile
from checkpoint_preflight import audit as checkpoint_audit


def inventory_rows(raw):
    rows = []
    for fields in csv.reader(io.StringIO(raw.decode()), strict=True):
        if len(fields) != 6:
            raise ValueError("invalid inventory fields")
        index, name, uuid, total, free, driver = [field.strip() for field in fields]
        if not re.fullmatch(r"NVIDIA H200(?: [A-Za-z0-9_.+-]+)*", name):
            raise ValueError("non-H200 allocation")
        if not re.fullmatch(r"GPU-[0-9a-fA-F-]{36}", uuid):
            raise ValueError("invalid GPU UUID")
        rows.append({"index": int(index), "name": name, "uuid": uuid,
                     "total_mib": int(total), "free_mib": int(free), "driver": driver})
    if len(rows) != 8 or {row["index"] for row in rows} != set(range(8)) or len({row["uuid"] for row in rows}) != 8:
        raise ValueError("expected eight distinct physical GPUs")
    return rows


def srun_prefix(node, *, gpu_count=8, cpus=32, overlap=False):
    command = ["srun", "--nodes=1", "--ntasks=1", "--exact", "--cpus-per-task=" + str(cpus),
               "--gres=gpu:" + str(gpu_count), "--cpu-bind=none", "--kill-on-bad-exit=0",
               "--nodelist=" + node]
    if overlap:
        command.append("--overlap")
    return command


class Controller:
    def __init__(self, run, nodes, job_id, inputs):
        self.run, self.nodes, self.job_id, self.inputs = run, nodes, job_id, inputs
        self.children = []
        self.active = None
        self.next_phase = 0
        self.sequence = 1
        self.gpu_passed = False
        self.gpu_imports_passed = False
        self.initial_inventory = None
        self.terminal_failure = False
        self.finish = False

    def event(self, kind, **fields):
        with (self.run / "events.jsonl").open("a") as handle:
            handle.write(json.dumps({"utc": utc(), "kind": kind, **fields}, sort_keys=True) + "\n")
            handle.flush()
            os.fsync(handle.fileno())

    def capture(self, command, directory, stem, timeout=180):
        write_new(directory / (stem + ".command.json"), {"argv": command, "started_utc": utc()})
        started = time.monotonic()
        error = None
        code = None
        interruption = None
        with (directory / (stem + ".stdout")).open("xb") as out, (directory / (stem + ".stderr")).open("xb") as err:
            try:
                result = subprocess.run(command, stdout=out, stderr=err, timeout=timeout, check=False)
                code = result.returncode
            except BaseException as exc:
                error = type(exc).__name__
                if not isinstance(exc, Exception):
                    interruption = exc
        result = {"exit_code": code, "error": error, "elapsed_seconds": time.monotonic() - started,
                  "finished_utc": utc(), "stdout_sha256": digest(directory / (stem + ".stdout")),
                  "stderr_sha256": digest(directory / (stem + ".stderr"))}
        write_new(directory / (stem + ".exit.json"), result)
        if interruption is not None:
            raise interruption
        if code != 0 or error:
            raise RuntimeError("captured command failed: " + stem)
        return read_regular(directory / (stem + ".stdout"))

    def inventory(self, directory, *, minimum_free_mib):
        all_rows = []
        for index, node in enumerate(self.nodes):
            command = srun_prefix(node, cpus=2) + ["nvidia-smi",
                "--query-gpu=index,name,uuid,memory.total,memory.free,driver_version", "--format=csv,noheader,nounits"]
            rows = inventory_rows(self.capture(command, directory, "node%d-inventory" % index))
            if any(row["free_mib"] < minimum_free_mib for row in rows):
                raise ValueError("insufficient empty-card memory; no override/retry")
            all_rows.append({"node": node, "gpus": rows})
        if len({row["uuid"] for node in all_rows for row in node["gpus"]}) != 64:
            raise ValueError("GPU UUID overlap across nodes")
        write_new(directory / "inventory.json", {"job_id": self.job_id, "nodes": all_rows, "gpu_count": 64})
        return all_rows

    def numerical(self):
        directory = self.run / "gpu_numerical"
        directory.mkdir()
        try:
            inventory = self.inventory(directory, minimum_free_mib=8192)
            self.initial_inventory = inventory
            gpu_uuid = inventory[0]["gpus"][0]["uuid"]
            # Fixed reviewed original-vs-candidate comparison. Never edit/retry
            # a failed red assertion; this stage is consumed exactly once.
            # The empty-node step sees its eight allocated devices; the fixed
            # script selects exactly this recorded UUID before importing torch.
            # No second GPU receives tensors or a CUDA context from the test.
            command = srun_prefix(self.nodes[0], gpu_count=8, cpus=4) + [
                "--container-image=" + str(IMAGE),
                "--container-mounts=" + ",".join((str(STUDY) + ":" + str(STUDY) + ":ro",
                    str(directory) + ":" + str(directory), str(OLD_PYTHON) + ":" + str(OLD_PYTHON) + ":ro")),
                "bash", "-c", 'source "$1/runtime.sh"; exec python "$2" --expected-job-id "$3" --expected-gpu-uuid "$4" --output "$5"',
                "gpu-numerical", str(OLD_SERVING), str(GPU_SCRIPT), self.job_id, gpu_uuid, str(directory / "result")]
            self.capture(command, directory, "numerical", timeout=1200)
            receipt = json.loads(read_regular(directory / "result/receipt.json"))
            if receipt.get("passed") is not True:
                raise ValueError("GPU numerical receipt did not pass")
            self.gpu_passed = True
            self.event("gpu_numerical_passed_import_gate_pending", receipt_sha256=digest(directory / "result/receipt.json"))
        except Exception as exc:
            self.terminal_failure = True
            self.event("gpu_numerical_failed_terminal_hold", error=type(exc).__name__)

    def gpu_imports(self):
        if not self.gpu_passed or self.terminal_failure or self.initial_inventory is None:
            raise ValueError("numerical gate must pass before GPU imports")
        directory = self.run / "gpu_imports"
        directory.mkdir()
        try:
            uuid = self.initial_inventory[0]["gpus"][0]["uuid"]
            command = srun_prefix(self.nodes[0], gpu_count=8, cpus=4) + [
                "--container-image=" + str(IMAGE),
                "--container-mounts=" + str(STUDY) + ":" + str(STUDY) + ":ro," + str(directory) + ":" + str(directory),
                "bash", "-c", 'source "$1/runtime.sh"; exec "$2" "$1/gpu_import_validation.py" --expected-job-id "$3" --expected-node "$4" --expected-gpu-uuid "$5" --runtime-receipt "$6" --runtime-sha256 "$7" --output "$8"',
                "gpu-imports", str(BASE), str(VENV / "bin/python"), self.job_id, self.nodes[0], uuid,
                self.inputs["runtime_receipt"], self.inputs["runtime_receipt_sha256"], str(directory / "result")]
            self.capture(command, directory, "imports", timeout=1200)
            receipt = json.loads(read_regular(directory / "result/receipt.json"))
            from gpu_import_validation import check_result
            check_result(receipt, self.job_id, self.nodes[0], uuid, self.inputs["runtime_receipt_sha256"])
            self.gpu_imports_passed = True
            self.event("gpu_numerical_and_imports_passed_hold", receipt_sha256=digest(directory / "result/receipt.json"))
        except Exception as exc:
            self.terminal_failure = True
            self.event("gpu_imports_failed_terminal_hold", error=type(exc).__name__)

    def deployment(self, directory, phase, model):
        profile = json.loads((BASE / "model_profiles.json").read_text())["models"][model]
        validate_profile(model, profile)
        private = directory / "private"
        private.mkdir(mode=0o700)
        key_path = private / "router_api_key"
        descriptor = os.open(key_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(descriptor, "w") as handle:
            handle.write(secrets.token_urlsafe(48) + "\n")
        record = {"created_utc": utc(), "job_id": self.job_id, "phase": phase, "account": "k2p",
                  "nodes": self.nodes, "gpu_count": 64, "model": model, "profile": profile,
                  "profile_contract_sha256": profile_sha256(model, profile),
                  "randomness_contract": randomness_contract(model, profile),
                  "python_environment": str(VENV), "sampler_modified": True,
                  "runtime_receipt": self.inputs["runtime_receipt"],
                  "runtime_receipt_sha256": self.inputs["runtime_receipt_sha256"],
                  "base_url": "http://%s:30241/v1" % self.nodes[0],
                  "router_url": "http://%s:30241" % self.nodes[0], "router_api_key_file": str(key_path),
                  "source_sha256": source_identity(), "real_acceptance_status": "pending",
                  "network_security": "Router Bearer only. Direct replicas unauthenticated, trusted cluster network required. Key values never logged/hashed.",
                  "replicas": [{"replica": i, "nodes": self.nodes[2*i:2*i+2],
                                "url": "http://%s:30240" % self.nodes[2*i]} for i in range(4)]}
        write_new(directory / "deployment.json", record)
        return profile

    def spawn(self, command, directory, stem):
        write_new(directory / (stem + ".command.json"), {"argv": command, "started_utc": utc()})
        out = (directory / (stem + ".log")).open("xb")
        try:
            process = subprocess.Popen(command, stdout=out, stderr=subprocess.STDOUT)
        finally:
            out.close()
        self.children.append((stem, process, directory))

    def load(self):
        if not self.gpu_passed or not self.gpu_imports_passed or self.terminal_failure:
            raise ValueError("both real GPU gates are required before model load")
        phase, model = PHASES[self.next_phase]
        self.next_phase += 1  # Consumed before launch; failed phase is not replayed.
        directory = self.run / phase
        directory.mkdir()
        check_environment()
        verify_pins(self.inputs["source_sha256"])
        profile = json.loads((BASE / "model_profiles.json").read_text())["models"][model]
        checkpoint = checkpoint_audit(Path(profile["checkpoint"]))
        write_new(directory / "checkpoint_structural.json", checkpoint)
        if not checkpoint["ready_structurally"] or checkpoint.get("config.json", {}).get("architectures") != [profile["architecture"]]:
            raise ValueError("checkpoint structure/architecture failed; payload values not verified")
        self.inventory(directory, minimum_free_mib=100000)
        profile = self.deployment(directory, phase, model)
        mounts = ",".join((str(STUDY) + ":" + str(STUDY) + ":ro", str(directory) + ":" + str(directory),
                           profile["checkpoint"] + ":" + profile["checkpoint"] + ":ro"))
        self.active = phase
        for index, node in enumerate(self.nodes):
            replica, rank = index // 2, index % 2
            head = socket.gethostbyname(self.nodes[replica * 2])
            command = srun_prefix(node) + ["--container-image=" + str(IMAGE), "--container-mounts=" + mounts,
                "bash", "-c", 'source "$1/runtime.sh"; exec python "$1/serve_node.py" "$2" "$3" "$4" "$5" "$6"',
                "phase-rank", str(BASE), model, str(replica), str(rank), head, str(directory)]
            self.spawn(command, directory, "replica%d-rank%d" % (replica, rank))
        command = srun_prefix(self.nodes[0], gpu_count=0, cpus=2, overlap=True) + [
            "--container-image=" + str(IMAGE), "--container-mounts=" + mounts, "bash", "-c",
            'source "$1/runtime.sh"; exec python "$1/router.py" --deployment "$2/deployment.json"',
            "phase-router", str(BASE), str(directory)]
        self.spawn(command, directory, "router")
        self.event("load_started_not_ready", phase=phase, model=model, deployment=str(directory / "deployment.json"))
        print("OWNED_JOB=%s PHASE=%s MODEL=%s ENDPOINT=http://%s:30241/v1 RUN=%s" %
              (self.job_id, phase, model, self.nodes[0], directory), flush=True)

    def stop(self, reason):
        # These are only our Popen handles, never a process group or broad job.
        for _, child, _ in self.children:
            if child.poll() is None:
                child.terminate()
        deadline = time.monotonic() + 120
        for stem, child, directory in self.children:
            try:
                child.wait(timeout=max(0.01, deadline - time.monotonic()))
            except subprocess.TimeoutExpired:
                self.terminal_failure = True
                self.event("stop_timeout_terminal_hold", child=stem)
                continue  # Never claim drain or launch the next model.
            target = directory / (stem + ".exit.json")
            if not target.exists():
                write_new(target, {"exit_code": child.returncode, "finished_utc": utc(), "reason": reason})
        self.children = [(stem, child, directory) for stem, child, directory in self.children if child.poll() is None]
        if not self.children:
            self.active = None
        self.event("phase_stop_observed", reason=reason, remaining_children=len(self.children),
                   limitation="Local srun exits alone are not a model-call drain receipt; ROOT must separately drain callers before stop.")

    def loop(self):
        self.numerical()
        if self.gpu_passed and not self.terminal_failure:
            self.gpu_imports()
        while not self.finish:
            failed = [stem for stem, child, _ in self.children if child.poll() is not None]
            if failed:
                self.terminal_failure = True
                self.event("owned_process_exited_terminal_hold", children=failed)
                self.stop("unexpected_owned_process_exit")
            marker = self.run / "commands" / ("%04d.ready" % self.sequence)
            if marker.exists():
                path = marker.with_suffix(".json")
                try:
                    command = json.loads(read_regular(path))
                    action = command_valid(command, job_id=self.job_id, sequence=self.sequence,
                        active=self.active, next_phase=self.next_phase,
                        gpu_passed=self.gpu_passed and self.gpu_imports_passed and not self.terminal_failure)
                    self.event("operator_command_consumed", command=command, command_sha256=digest(path))
                    if action == "load":
                        self.load()
                    elif action == "stop":
                        self.stop("explicit_ROOT_operator_stop")
                    else:
                        self.stop("explicit_ROOT_operator_finish")
                        self.finish = True
                except Exception as exc:
                    self.terminal_failure = True
                    self.event("command_failed_terminal_hold", sequence=self.sequence, error=type(exc).__name__)
                    self.stop("command_failure")
                self.sequence += 1
            if not self.finish:
                time.sleep(2)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--inputs-sha256", required=True)
    parser.add_argument("--launch-reference", type=Path, required=True)
    args = parser.parse_args()
    if digest(args.inputs) != args.inputs_sha256:
        raise SystemExit("external phase inputs changed")
    inputs = json.loads(read_regular(args.inputs))
    for path_key, sha_key in (("runtime_receipt", "runtime_receipt_sha256"),
                              ("runtime_acceptance", "runtime_acceptance_sha256")):
        if digest(Path(inputs[path_key])) != inputs[sha_key]:
            raise SystemExit("external runtime evidence changed")
    if digest(args.launch_reference) != inputs["launch_reference_sha256"]:
        raise SystemExit("ROOT launch reference mismatch")
    verify_pins(inputs["source_sha256"])
    check_environment()
    job_id = os.environ.get("SLURM_JOB_ID", "")
    if not job_id.isdecimal() or job_id == "1203474" or os.environ.get("SLURM_JOB_ACCOUNT") != "k2p":
        raise SystemExit("not a new owned k2p allocation")
    nodes = subprocess.check_output(["scontrol", "show", "hostnames", os.environ["SLURM_JOB_NODELIST"]], text=True).splitlines()
    if len(nodes) != 8 or len(set(nodes)) != 8:
        raise SystemExit("expected exactly eight new owned nodes")
    run = BASE / "runs" / job_id
    run.mkdir(parents=True, exist_ok=False)
    (run / "commands").mkdir()
    write_new(run / "allocation.json", {"created_utc": utc(), "job_id": job_id, "nodes": nodes,
        "account": "k2p", "gpu_count_requested": 64, "inputs": str(args.inputs),
        "inputs_sha256": args.inputs_sha256, "root_launch_reference": str(args.launch_reference),
        "source_sha256": inputs["source_sha256"], "model_generation_performed_by_controller": False})
    controller = Controller(run, nodes, job_id, inputs)
    def interrupted(signum, frame):
        raise KeyboardInterrupt("allocation signal")
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    try:
        controller.loop()
    finally:
        controller.stop("controller_exit")


if __name__ == "__main__":
    main()
