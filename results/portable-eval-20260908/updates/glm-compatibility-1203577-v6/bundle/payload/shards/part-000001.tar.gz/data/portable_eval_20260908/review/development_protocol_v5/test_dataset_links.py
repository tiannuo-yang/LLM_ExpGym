"""Pinned static-data leaf-link scope only; no actual run/scorer/API calls."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest import mock

from common import HERE, STATIC, STUDY, Reader, sha


def reference(path, payload=b'cpu dataset'):
    return {'path': str(path), 'sha256': sha(payload), 'bytes': len(payload)}


class DatasetLinkTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.target = self.root / 'blob'
        self.target.write_bytes(b'cpu dataset')
        self.link = self.root / 'snapshot'
        self.link.symlink_to('blob')

    def test_regular_and_relative_absolute_leaf_links_pass(self):
        reader = Reader()
        for path in (self.target, self.link):
            self.assertEqual(reader.dataset_file(reference(path)), b'cpu dataset')
        absolute = self.root / 'absolute'; absolute.symlink_to(self.target)
        reader.dataset_file(reference(absolute)); reader.unchanged()
        self.assertEqual(reader.dataset_file_links[str(self.link)]['link_target'], 'blob')
        self.assertEqual(reader.dataset_file_links[str(self.link)]['canonical_target'], str(self.target))

    def test_parent_relative_leaf_like_hf_layout(self):
        directory = self.root / 'snapshots' / 'commit' / 'text'
        directory.mkdir(parents=True)
        path = directory / 'part'; path.symlink_to('../../../blob')
        reader = Reader(); reader.dataset_file(reference(path)); reader.unchanged()

    def test_general_evidence_remains_symlink_forbidden(self):
        with self.assertRaisesRegex(ValueError, 'symlink evidence forbidden'):
            Reader().bind(self.link, sha(b'cpu dataset'))

    def test_original_and_target_ancestors_remain_forbidden(self):
        alias = self.root / 'alias'; alias.symlink_to(self.root, target_is_directory=True)
        with self.assertRaises(ValueError): Reader().dataset_file(reference(alias / 'blob'))
        other = self.root / 'other'; other.symlink_to('alias/blob')
        with self.assertRaises(ValueError): Reader().dataset_file(reference(other))
        tricky = self.root / 'tricky'; tricky.symlink_to('alias/../' + self.root.name + '/blob')
        with self.assertRaises(ValueError): Reader().dataset_file(reference(tricky))

    def test_chain_dangling_loop_directory_rejected(self):
        chain = self.root / 'chain'; chain.symlink_to('snapshot')
        dangling = self.root / 'missing'; dangling.symlink_to('absent')
        loop = self.root / 'loop'; loop.symlink_to('loop')
        directory = self.root / 'directory'; directory.symlink_to(self.root, target_is_directory=True)
        for path in (chain, dangling, loop, directory):
            with self.assertRaises((ValueError, OSError, RuntimeError)):
                Reader().dataset_file(reference(path))

    def test_pins_shape_size_and_hash_are_mandatory(self):
        for patch in ({'sha256': '0' * 64}, {'bytes': 1}, {'bytes': True}, {'sha256': None}, {'extra': 1}):
            ref = dict(reference(self.link), **patch)
            with self.assertRaises(ValueError): Reader().dataset_file(ref)

    def test_target_switch_during_read_rejected_even_identical_bytes(self):
        second = self.root / 'second'; second.write_bytes(b'cpu dataset')
        reader = Reader(); original = reader.bind
        def switch(path, expected=None):
            body = original(path, expected)
            self.link.unlink(); self.link.symlink_to('second')
            return body
        with mock.patch.object(reader, 'bind', side_effect=switch):
            with self.assertRaisesRegex(ValueError, 'changed while reading'):
                reader.dataset_file(reference(self.link))

    def test_unchanged_rejects_link_switch_and_content_change(self):
        reader = Reader(); reader.dataset_file(reference(self.link))
        second = self.root / 'second'; second.write_bytes(b'cpu dataset')
        self.link.unlink(); self.link.symlink_to('second')
        with self.assertRaises(ValueError): reader.unchanged()
        plain = Reader(); plain.dataset_file(reference(self.target))
        self.target.write_bytes(b'changed data')
        with self.assertRaises(ValueError): plain.unchanged()

    def test_before_read_and_same_target_relink_change_rejected(self):
        reader = Reader(); reader.dataset_file(reference(self.link))
        # Same canonical file, different observable link text. An identical
        # unlink/recreate can reuse inode/coarse timestamps on this filesystem.
        self.link.unlink(); self.link.symlink_to('./blob')
        with self.assertRaises(ValueError): reader.dataset_file(reference(self.link))
        reader = Reader(); reader.dataset_file(reference(self.target))
        self.target.unlink(); self.target.symlink_to('snapshot')
        with self.assertRaises((ValueError, OSError, RuntimeError)): reader.unchanged()

    def test_all_126_original_static_refs_old_red_new_green(self):
        path = STUDY / 'validation/static_acceptance_v4.json'
        body = path.read_bytes(); self.assertEqual(sha(body), STATIC)
        data = json.loads(body)['data_binding']['files']
        self.assertEqual(len(data), 126)
        old_path = HERE.parent / 'development_protocol_v4/common.py'
        self.assertEqual(sha(old_path.read_bytes()), '5b347ab5c40fcca6d9b3e19c5f40c3ef4ffb293de64f49ca5009a58ce54264b9')
        spec = importlib.util.spec_from_file_location('old_v4_data_reader', old_path)
        old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
        reader, rejected = Reader(), 0
        for ref in data.values():
            path = Path(ref['path'])
            if path.is_symlink():
                with self.assertRaisesRegex(ValueError, 'symlink evidence forbidden'):
                    old.Reader().bind(path, ref['sha256'])
                rejected += 1
            self.assertEqual(len(reader.dataset_file(ref)), ref['bytes'])
        reader.unchanged()
        self.assertEqual(rejected, 27)
        print('DATASET_LINK_STATIC_JSON=' + json.dumps({'passed': True, 'static_sha256': STATIC,
            'static_refs': 126, 'old_rejected_leaf_links': rejected, 'new_verified_refs': len(reader.dataset_file_links),
            'dataset_file_links': reader.dataset_file_links, 'canonical_file_bindings': reader.files,
            'raw_results_or_scorers_read': False, 'new_model_API_calls': 0}, sort_keys=True), flush=True)


if __name__ == '__main__':
    unittest.main()
