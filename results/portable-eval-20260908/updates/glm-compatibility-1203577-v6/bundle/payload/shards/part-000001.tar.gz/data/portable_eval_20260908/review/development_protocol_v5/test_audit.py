"""Pure synthetic boundary tests; no authorization, runner, scorer or API."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

import audit
from common import Reader, canonical, inventory, sha, strict, write_new
from raw_checks import audit_rows, nonce_accounting

PROFILE = {'model': 'kimi-k3', 'temperature': 1.0, 'top_p': 1.0,
           'reasoning_effort': 'max', 'chat_template_kwargs': {'thinking': True}}
ENDPOINTS = {'job': ['http://cpu.invalid/v1/chat/completions']}


def sample(rid='a', generation='g', attempt=1):
    response = {'choices': [{'message': {'role': 'assistant', 'content': 'synthetic'}, 'finish_reason': 'stop'}],
                'usage': {'prompt_tokens': 3, 'completion_tokens': 2, 'total_tokens': 5, 'reasoning_tokens': 1}}
    payload = dict(PROFILE, max_tokens=32768, seed=1210, parallel_tool_calls=False,
                   tools=[{'type': 'function'}], messages=[{'role': 'user', 'content': 'synthetic'}], tool_choice='auto')
    return {'path': '/synthetic/job/' + rid + '.json', 'scope': 'job', 'raw': {
        'schema_version': 'expgym.api_attempt.v1', 'run_id': 'development-v4:synthetic',
        'request_id': rid, 'client_id': 'c', 'generation_id': generation, 'attempt': attempt, 'max_attempts': 3,
        'state': 'success', 'will_retry': False, 'error': None, 'http_status': None,
        'started_at_utc': '2026-01-01T00:00:01+00:00', 'finished_at_utc': '2026-01-01T00:00:02+00:00',
        'endpoint': ENDPOINTS['job'][0], 'request_payload': payload,
        'response_raw': json.dumps(response), 'response_json': response}}


def run(rows, expiry=1767225610):
    return audit_rows(rows, PROFILE, 'development-v4:synthetic', ENDPOINTS, expiry, 1767225600)


class RawTests(unittest.TestCase):
    def test_exact_success_and_known_usage(self):
        result = run([sample()])
        self.assertTrue(result['passed'], result)
        self.assertEqual(result['all_attempt_usage']['output_tokens']['complete_total'], 2)

    def test_expired_now_is_not_checked(self):
        self.assertTrue(run([sample()])['passed'])

    def test_finish_after_deadline_is_retained(self):
        result = run([sample()], 1767225601.5)
        self.assertTrue(result['passed'])
        self.assertEqual(result['warnings'][0]['kind'], 'authorized_start_finished_after_expiry')

    def test_start_at_deadline_fails_but_preserves_cost(self):
        result = run([sample()], 1767225601)
        self.assertFalse(result['passed'])
        self.assertEqual(result['all_attempt_usage']['input_tokens']['known_sum'], 3)

    def test_utc_absence_is_not_imputed(self):
        row = sample(); row['raw']['started_at_utc'] = '2026-01-01T00:00:01'
        self.assertFalse(run([row])['passed'])

    def test_response_null_parsed_conflict(self):
        row = sample(); row['raw']['response_json'] = None
        result = run([row])
        self.assertFalse(result['passed'])
        self.assertEqual(result['all_attempt_usage']['input_tokens']['known_sum'], 3)

    def test_abort_keeps_reported_usage(self):
        row = sample(); row['raw']['response_json']['choices'][0]['finish_reason'] = 'abort'
        row['raw']['response_raw'] = json.dumps(row['raw']['response_json'])
        result = run([row])
        self.assertFalse(result['passed'])
        self.assertEqual(result['finish_reasons'], {'abort': 1})
        self.assertEqual(result['all_attempt_usage']['reasoning_tokens']['known_sum'], 1)

    def test_retry_transient_preserves_unknown_first(self):
        first, last = sample(), sample('b', attempt=2)
        first['raw'].update(state='error', will_retry=True, http_status=502, response_raw=None,
            response_json=None, error={'type': 'HTTPError'}, retry_delay_seconds=3)
        last['raw']['started_at_utc'] = '2026-01-01T00:00:05+00:00'
        last['raw']['finished_at_utc'] = '2026-01-01T00:00:06+00:00'
        result = run([first, last])
        self.assertTrue(result['passed'], result)
        self.assertIsNone(result['all_attempt_usage']['input_tokens']['complete_total'])

    def test_nontransient_or_delivered_retry_rejected(self):
        first, last = sample(), sample('b', attempt=2)
        first['raw'].update(state='error', will_retry=True, http_status=400, error={'type': 'HTTPError'}, retry_delay_seconds=3)
        self.assertFalse(run([first, last])['passed'])

    def test_duplicate_ids_retained(self):
        result = run([sample(), sample()])
        self.assertFalse(result['passed'])
        self.assertEqual(result['attempt_count'], 2)
        self.assertEqual(result['all_attempt_usage']['input_tokens']['known_sum'], 6)

    def test_noncontiguous_retry_and_bool_attempt(self):
        row = sample(attempt=True)
        self.assertFalse(run([row])['passed'])
        self.assertFalse(run([sample(attempt=2)])['passed'])

    def test_hidden_extra_top_k_rejected(self):
        row = sample(); row['raw']['request_payload']['top_k'] = 1
        self.assertFalse(run([row])['passed'])

    def test_unpaired_history_rejected(self):
        row = sample(); row['raw']['request_payload']['messages'].append({'role': 'tool', 'tool_call_id': 'none', 'content': 'orphan'})
        self.assertFalse(run([row])['passed'])

    def test_reasoning_conflict_not_first_wins(self):
        row = sample(); row['raw']['response_json']['usage']['completion_tokens_details'] = {'reasoning_tokens': 2}
        row['raw']['response_raw'] = json.dumps(row['raw']['response_json'])
        result = run([row])
        self.assertIsNone(result['all_attempt_usage']['reasoning_tokens']['complete_total'])
        self.assertEqual(result['all_attempt_usage']['output_tokens']['known_sum'], 2)


class InventoryTests(unittest.TestCase):
    def test_duplicate_and_overflow_json_rejected(self):
        for text in ('{"a":1,"a":2}', '{"a":1e999}', '{"a":NaN}'):
            with self.assertRaises(ValueError): strict(text)

    def test_recursive_orphan_is_not_omitted(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'nested/deeper/orphan.json'; path.parent.mkdir(parents=True)
            path.write_text('{}')
            self.assertEqual(inventory(tmp), [path])

    def test_symlink_ancestor_and_descendant_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); (root / 'real').mkdir(); (root / 'alias').symlink_to(root / 'real', target_is_directory=True)
            with self.assertRaises(ValueError): inventory(root / 'alias')
            with self.assertRaises(ValueError): inventory(root)

    def test_changed_pinned_file_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'a.json'; path.write_text('{}')
            reader = Reader(); reader.read(path, sha(b'{}'))
            path.write_text('{"a":1}')
            with self.assertRaises(ValueError): reader.unchanged()

    def test_inventory_binding_requires_all_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'a.json'; path.write_text('{}')
            with self.assertRaises(ValueError): audit.inventory_binding({'files': []}, [path], Reader())

    def test_input_rejected_before_child(self):
        with mock.patch.object(audit, 'child', side_effect=AssertionError('no child')) as child:
            for spec in ({}, {'schema_version': 'development-v4-independent-audit-input-v1', 'evidence_kind': 'synthetic_fixture', 'drained': True}):
                with self.assertRaises(ValueError): audit.preflight(spec, Reader())
            child.assert_not_called()


class NonceAccountingTests(unittest.TestCase):
    def fixture(self):
        raw = sample()['raw']
        entry = {k: raw.get(k) for k in ('request_id', 'generation_id', 'attempt', 'state', 'http_status')}
        entry['usage'] = raw['response_json']['usage']
        slot = {'attempted': True, 'state': 'delivered', 'attempt_usage': [entry],
            'started_at_utc': '2026-01-01T00:00:00+00:00', 'finished_at_utc': '2026-01-01T00:00:03+00:00',
            'output': {'prompt_tokens': 3, 'completion_tokens': 2, 'cached_prompt_tokens': None, 'cache_write_prompt_tokens': None}}
        return {'replicas': [{'records': [slot]}]}, raw, slot, entry

    def test_actual_wire_usage_and_metadata(self):
        report, raw, unused, entry = self.fixture()
        self.assertTrue(nonce_accounting(report, [raw])['passed'])
        entry['generation_id'] = 'different'
        self.assertFalse(nonce_accounting(report, [raw])['passed'])


class OrchestrationTests(unittest.TestCase):
    fixture = NonceAccountingTests.fixture

    def test_bad_first_status_keeps_inventory_and_checks_second(self):
        # Only orchestration is exercised here. No synthetic scorer result is
        # admitted as original-source or real evidence; output must stay false.
        with tempfile.TemporaryDirectory() as tmp:
            root, output = Path(tmp) / 'run', Path(tmp) / 'review'
            jobs, statuses, artifacts = [], [], []
            for name in ('first', 'second'):
                folder = root / 'results' / name
                trace = folder / 'model/traces-v2/trace.json'; write_new(trace, {})
                row = {'path': str(trace), 'sha256': sha(trace.read_bytes()), 'bytes': trace.stat().st_size}
                artifacts.append(row)
                job = {'id': name, 'system': 'expgym', 'model': 'kimi-k3', 'expected_traces': 1,
                       'output_dir': str(folder), 'dump_dir': str(root / 'raw' / name)}
                jobs.append(job)
                journal = root / 'journal' / name
                write_new(journal / 'reserved.json', {'job_id': name})
                status = {'job_id': name, 'passed': True, 'inventory': {'files': [row]}}
                for label in ('identity', 'run', 'resume'):
                    log = journal / (label + '.log'); log.write_text('synthetic')
                    status[label] = {'exit_code': 0, 'log': str(log), 'log_sha256': sha(log.read_bytes())}
                status['identity']['receipt'] = {}
                write_new(journal / 'final_status.json', None if name == 'first' else status)
                if name == 'second': statuses.append(status)
            protocol = root / 'protocol/kimi-k3'
            nonce = {'replicas': [], 'plan': [], 'passed': False}
            endpoints = ['http://cpu.invalid:%d/v1/chat/completions' % i for i in range(4)]
            write_new(protocol / 'report.json', nonce)
            write_new(protocol / 'plan.json', {'model': 'kimi-k3', 'cases': [], 'endpoint_sources': endpoints})
            protocol_rows = [{'path': str(p), 'sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size} for p in inventory(protocol)]
            values = {'plan': {}, 'authority_ref': {'expires_unix': 1767225610, 'plan_sha256': 'x'}, 'nonce_report': nonce,
                'deployment': {'replicas': [{'replica': i, 'url': url} for i, url in enumerate(endpoints)], 'router_url': ENDPOINTS['job'][0]},
                'execution': {'passed': True, 'model': 'kimi-k3', 'stages': [{'results': statuses}],
                    'physical_inventory': {'files': artifacts}, 'protocol_inventory': {'files': protocol_rows}}}
            dummy = Path(tmp) / 'dummy.json'; write_new(dummy, {})
            ref = {'path': str(dummy), 'sha256': sha(dummy.read_bytes())}
            spec = dict({key: ref for key in audit.REFS}, model_id='kimi-k3', evidence_kind='synthetic_fixture', deployment_id='synthetic')
            spec_path = Path(tmp) / 'spec.json'; write_new(spec_path, spec)
            with mock.patch.object(audit, 'preflight', return_value=(None, values, root, jobs, PROFILE, 1767225600)), \
                 mock.patch.object(audit, 'audit_nonce', return_value={'passed': False}), \
                 mock.patch.object(audit, 'original_raw_guard', return_value={'passed': True}), \
                 mock.patch.object(audit, 'child', return_value={'passed': True, 'request_ids': []}) as child:
                result = audit.audit(spec_path, sha(spec_path.read_bytes()), output)
            self.assertFalse(result['passed'])
            self.assertFalse(result['checks']['full_attempt_coverage'])
            self.assertEqual(child.call_count, 1)
            self.assertFalse(result['scope_details']['job_rows'][0]['passed'])
            self.assertTrue(result['scope_details']['job_rows'][1]['passed'])
            self.assertTrue((output / 'raw_audit.json').is_file())
            self.assertTrue((output / 'audit.json').is_file())

    def test_scalar_and_ledger_usage_not_self_attested(self):
        report, raw, slot, entry = self.fixture()
        slot['output']['prompt_tokens'] = 0
        self.assertFalse(nonce_accounting(report, [raw])['passed'])
        slot['output']['prompt_tokens'] = 3
        entry['usage'] = None
        self.assertFalse(nonce_accounting(report, [raw])['passed'])

    def test_failed_non_json_bytes_remain_unknown(self):
        report, raw, slot, entry = self.fixture()
        raw.update(state='error', response_raw='bad gateway', response_json=None)
        entry.update(state='error', usage=None)
        slot.update(state='error', output=None)
        self.assertTrue(nonce_accounting(report, [raw])['passed'])

    def test_slot_timestamp_does_not_enclose_attempt(self):
        report, raw, slot, unused = self.fixture()
        slot['finished_at_utc'] = '2026-01-01T00:00:01+00:00'
        self.assertFalse(nonce_accounting(report, [raw])['passed'])


if __name__ == '__main__':
    unittest.main()
