# V5 数据叶链接独立窄复核

结论：在本次限定范围内通过，无新增确认阻断。它不是实际 development 审计通过，也不签发模型或审计 GO。

已完整读取新增 `common.py` 专用读取逻辑、`audit.py` 两处差异和十项新增测试。独立运行结果见 [receipt.json](run_v1/receipt.json)，SHA256 为 `3acb3614b9343eb94eba02c75ab1b51452d9ef8a980e96ec5b6b5850b1912437`；复跑脚本为 [review.py](review.py)。作者 freeze 原件 SHA 为 `dec52c52e2067da8e5f91fe342ffd650278914f02a12ad8d62348a57b207b750`。

- 10 项定向 CPU 测试通过，0 failure/error/skip。包括合法普通文件、相对/绝对叶链接、固定 SHA/大小、祖先/链式链接拒绝、读中或后续目标变化拒绝；通用 `bind` 仍拒链接。
- 126 条真实 static 数据引用共 234,519,740 字节，仅哈希读取，不解析数据内容。旧 reader 通过 99 个普通文件、拒绝 27 个 HF 叶链接；新 reader 全部原 SHA/bytes 通过，最终 `unchanged()` 通过。27 个链接仍不能经通用 `bind` 读取。
- 候选顶层 Python/Markdown 字节在独立运行前后相同；与旧目录共有 Python 文件中仅 `common.py`、`audit.py` 改变。原始请求、结果、评分和模型调用均未执行或读取；测试期间 socket/Popen 被阻断。

源码定位：新 `common.py:113` 起新增 `dataset_file`；`audit.py:71–72` 仅固定 static 数据循环改调用，`:306` 增加链接证据账。通用 `bind`/`inventory` 未放宽。

正式 auditor 不应机械套用同一修复：`source_cohorts/v4/portable_eval_20260908/design/formal_real_projection_auditor_candidate_v2/source_checks.py:47–48` 使用严格 reader，但 `design/formal_matrix_candidate/planner.py:96–102` 写入 `source_and_inputs.files` 前会 `Path.resolve()`，正常 HF 路径已变成普通 blob 路径。这里只确认源码合同，没有运行正式计划或审计。

边界：证明当前固定字节与观测到的链接文本/元数据稳定，不追认历史 inode，也不声称发现所有未被观测到的瞬态同字节重建。作者首次测试的同目标重建 fixture 失败及修正版单项证据保留；本次独立十项是最终冻结测试的新运行，不冒充原 86 项全套或 scorer 重跑。
