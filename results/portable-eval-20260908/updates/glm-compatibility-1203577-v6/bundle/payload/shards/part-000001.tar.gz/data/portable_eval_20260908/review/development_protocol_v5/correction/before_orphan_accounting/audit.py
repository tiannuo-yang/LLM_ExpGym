#!/usr/bin/env python3
"""Pinned post-drain development audit. No runner main/resume or model calls.

Only a ROOT-pinned input spec with a pinned drain observation can enter this
offline auditor. An input pin is not permission to generate or create authority.
"""
import argparse
import inspect
import os
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace

from common import (CANDIDATE, COMMON_SHA, DEVELOPMENT_SHA, ERRORS, HERE, PROFILE_PATH,
                    PROFILE_SHA, RAW_HELPER_SHA, REVIEW, SOURCE, STATIC, Reader, canonical,
                    development, helpers, inventory, load, require, safe, sha, strict, write_new)
from raw_checks import audit_rows, nonce_accounting
from nonce_checks import audit_nonce

REFS = ('plan', 'execution', 'nonce_report', 'authority_ref', 'deployment', 'profile',
        'source_acceptance_ref', 'drain_ref')


def preflight(spec, reader):
    require(type(spec) is dict and spec.get('schema_version') == 'development-v4-independent-audit-input-v1', 'input schema differs')
    require(spec.get('evidence_kind') == 'real_observation' and spec.get('drained') is True, 'explicit ROOT post-drain real scope required')
    values = {name: reader.ref(spec[name]) for name in REFS}
    plan, auth, deploy, static = [values[key] for key in ('plan', 'authority_ref', 'deployment', 'source_acceptance_ref')]
    d = development()
    reader.bind(CANDIDATE / 'development.py', DEVELOPMENT_SHA)
    reader.bind(REVIEW / 'audit_bc_common.py', COMMON_SHA)
    reader.bind(REVIEW / 'audit_bc_attempts_v3.py', RAW_HELPER_SHA)
    reader.bind(PROFILE_PATH, PROFILE_SHA)
    loader = load(PROFILE_PATH, PROFILE_SHA, 'development_independent_full_profile')
    profile = loader.validate_profile(values['profile'])
    model, config = spec['model_id'], plan['config']
    require(model in ('kimi-k3', 'glm-5.3') and profile['model'] == model, 'model differs')
    require(profile['temperature'] == 1.0 and profile['top_k'] is None and profile['reasoning_effort'] == 'max' and
            profile['randomness_contract'] == 'seed_labels_only', 'declared development full profile differs')
    require(canonical(config['profiles'][model]) == canonical({k: profile[k] for k in ('top_p', 'chat_template_kwargs')}), 'partial/full profile differs')
    require(auth.get('schema_version') == 'development-v4-root-go-v1' and auth.get('issuer') == 'ROOT' and
            auth.get('operation') == 'execute-development' and auth.get('model') == model and
            auth.get('source_tree_sha256') == SOURCE and auth.get('static_sha256') == STATIC and
            auth.get('plan_sha256') == sha(d.canonical(plan).encode()) and auth.get('output_dir') == config['output_dir'], 'historical authority scope differs')
    require(type(auth.get('expires_unix')) in (int, float) and auth['expires_unix'] > 0, 'finite historical deadline required')
    # strict parsing already rejects overflow/NaN. Deliberately no current time.
    require(type(auth.get('evidence')) is dict and set(auth['evidence']) == {'model_manifest', 'runtime', 'deployment', 'operation'}, 'authority evidence set differs')
    bound = {name: reader.ref(ref) for name, ref in auth['evidence'].items()}
    require(auth['evidence']['deployment'] == spec['deployment'], 'deployment external authority pin differs')
    manifest, operation = bound['model_manifest'], bound['operation']
    require(manifest.get('model') == model and manifest.get('source_tree_sha256') == SOURCE and
            canonical(manifest.get('profile')) == canonical(config['profiles'][model]) and
            manifest.get('runtime_sha256') == auth['evidence']['runtime']['sha256'] and
            manifest.get('deployment_sha256') == spec['deployment']['sha256'] and bound['runtime'].get('passed') is True,
            'historical model/runtime evidence differs')
    require(operation.get('approved') is True and operation.get('ready') is True and
            operation.get('development_plan_sha256') == auth['plan_sha256'] and
            operation.get('runtime_sha256') == auth['evidence']['runtime']['sha256'] and
            operation.get('deployment_sha256') == spec['deployment']['sha256'], 'historical operation evidence differs')
    require(deploy.get('model') == model and spec['deployment_id'] == 'slurm:' + str(deploy['job_id']) + ':' + deploy['phase'], 'deployment phase identity differs')
    require(type(deploy.get('replicas')) is list and len(deploy['replicas']) == 4 and
            all(type(row.get('replica')) is int for row in deploy['replicas']) and
            sorted(row['replica'] for row in deploy['replicas']) == list(range(4)), 'four distinct replicas required')
    require(config['endpoints'][model] == deploy['router_url'], 'router identity differs')
    require(spec['source_acceptance_ref']['sha256'] == STATIC and static['source_tree_sha256'] == SOURCE and len(static['files']) == 82,
            'v4 source acceptance differs')
    require(config['static_acceptance'] == spec['source_acceptance_ref']['path'], 'plan static reference differs')
    for name, expected in static['files'].items():
        reader.bind(Path(config['repo_root']) / name, expected)
    for row in static['data_binding']['files'].values():
        require(len(reader.bind(row['path'], row['sha256'])) == row['bytes'], 'data size differs')
    for row in plan['bindings']:
        if row['path'] == config['python']:
            reader.runtime(row['path'], row['sha256'])
        else:
            reader.bind(row['path'], row['sha256'])
    # This original fixed-plan verifier has no generation/runner execution.
    d.verify(plan)
    root = safe(config['output_dir'])
    require(canonical(reader.read(root / 'manifest.json')) == canonical(plan), 'run manifest differs from precommitted plan')
    require(reader.read(root / 'authority_binding.json') == spec['authority_ref'], 'run authority binding differs')
    require(reader.read(root / 'commands.json') == {job['id']: job['command'] for job in plan['jobs']}, 'commands differ')
    require(Path(spec['execution']['path']) == root / 'execution.json' and
            Path(spec['nonce_report']['path']) == root / 'protocol' / model / 'report.json', 'terminal receipt namespace differs')
    started = reader.read(root / 'execution_start.json')
    require(started['model'] == model and type(started['started_unix']) in (int, float) and started['started_unix'] < auth['expires_unix'], 'execution start differs')
    jobs = [job for job in plan['jobs'] if job['model'] == model]
    require(len(jobs) == 15 and sum(j['expected_traces'] for j in jobs) == 51 and
            len({j['id'] for j in jobs}) == 15, 'fixed 3 Exp + 12 N4 matrix differs')
    return d, values, root, jobs, profile, started['started_unix']


def original_raw_guard(d, plan, job, preflight):
    """Re-execute frozen per-invocation raw guard; never read wrapper raw_check."""
    module = d.load_helper(plan['config']['helper_dir'], 'poolact_pilot_timing.py' if job['system'] == 'poolact' else 'pilot_timing.py')
    source = inspect.getsource(module.dump_profile)
    substitutions = [('poolact-pilot-bc:', 'development-v4:')] if job['system'] == 'poolact' else [
        ('pilot-a21:', 'development-v4:'), ('"top_p": 1.0', '"top_p": args.development_profile["top_p"]'),
        ('settings(args)["chat_template_kwargs"]', 'args.development_profile["chat_template_kwargs"]')]
    for old, new in substitutions:
        require(source.count(old) == 1, 'frozen raw guard adapter shape changed')
        source = source.replace(old, new)
    namespace = dict(module.__dict__)
    exec(compile(source, str(HERE / 'audit.py') + ':frozen_readonly_raw_guard', 'exec'), namespace)
    selected = plan['config']['profiles'][job['model']]
    args = SimpleNamespace(repo_root=Path(plan['config']['repo_root']), output_dir=Path(plan['config']['output_dir']),
        model=job['model'], base_url=plan['config']['endpoints'][job['model']], seed=1210, development_profile=selected,
        _request_profile={'profile': dict(selected, model=job['model'], temperature=1.0, top_k=None, reasoning_effort='max')})
    return namespace['dump_profile'](args, dict(job, preflight=preflight), None)


def child(plan, job, preflight, paths, output):
    env = dict(os.environ)
    for key in list(env):
        if 'KEY' in key.upper() or 'TOKEN' in key.upper() or key.upper().endswith('PROXY') or key == 'PYTHONPATH':
            env.pop(key, None)
    repo = Path(plan['config']['repo_root'])
    env.update(PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
        MKL_NUM_THREADS='1', EXPGYM_HPO_THREADS='1', NO_PROXY='*', no_proxy='*',
        EXPGYM_API_DUMP_DIR='', EXPGYM_RUN_ID='development-v4:' + Path(plan['config']['output_dir']).name,
        HPOBENCH_ROOT=str(repo / 'data/hpo_tuning/HPOBench'), XDG_DATA_HOME=str(repo / 'data/hpo_tuning/hpobench_data'),
        XDG_CACHE_HOME=str(repo / 'data/hpo_tuning/hpobench_cache'),
        XDG_CONFIG_HOME=str(Path(plan['config']['legacy_runtime_dir']) / 'hpobench_config'))
    result = subprocess.run([job['command'][0], '-B', str(HERE / 'score_context_child.py')],
        input=canonical({'plan': plan, 'job': job, 'preflight': preflight, 'trace_paths': [str(p) for p in paths]}),
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, cwd=str(repo), env=env, timeout=600)
    log = Path(output) / 'children' / (job['id'] + '.log')
    log.parent.mkdir(parents=True, exist_ok=True)
    with log.open('xb') as stream:
        stream.write(result.stdout)
    prefix = b'DEV_INDEPENDENT_JSON='
    lines = [line[len(prefix):] for line in result.stdout.splitlines() if line.startswith(prefix)]
    require(len(lines) == 1, 'independent child receipt missing; see retained log')
    receipt = strict(lines[0])
    receipt.update(child_exit_code=result.returncode, child_log={'path': str(log), 'sha256': sha(result.stdout)})
    require(result.returncode == 0 and receipt.get('passed') is True, 'original score/context child rejected; see retained log')
    return receipt


def inventory_binding(value, paths, reader):
    rows = value['files']
    require(type(rows) is list and {row['path'] for row in rows} == {str(path) for path in paths}, 'original inventory file set differs')
    for row in rows:
        require('error_type' not in row and 'error' not in row and
                len(reader.bind(row['path'], row['sha256'])) == row['bytes'], 'original inventory bytes differ')


def audit(spec_path, spec_sha256, output):
    reader = Reader()
    own_files = ('audit.py', 'common.py', 'raw_checks.py', 'nonce_checks.py', 'score_context_child.py')
    own_identity = {name: sha(reader.bind(HERE / name)) for name in own_files}
    spec = reader.read(spec_path, spec_sha256)
    d, values, root, jobs, profile, started = preflight(spec, reader)
    output = safe(output)
    require(not output.exists() and output != root and root not in output.parents, 'new output outside original run required')
    output.mkdir(parents=True)
    errors, raw_rows, malformed, traces, job_rows = [], [], [], [], []
    sections = {name: inventory(root / name) for name in ('raw', 'results', 'protocol', 'journal')}
    # Snapshot all names and original bytes BEFORE any independent scorer.
    for paths in sections.values():
        for path in paths:
            try:
                reader.read(path)
            except ERRORS as exc:
                errors.append(str(path) + ': ' + type(exc).__name__)
    try:
        inventory_binding(values['execution']['physical_inventory'], sections['raw'] + sections['results'], reader)
        inventory_binding(values['execution']['protocol_inventory'], sections['protocol'], reader)
        require(values['execution']['model'] == spec['model_id'], 'execution selected model differs')
        for path in sections['journal']:
            relative = path.relative_to(root / 'journal')
            require(len(relative.parts) == 2 and relative.parts[0] in {job['id'] for job in jobs}, 'journal outside selected flat job namespace')
    except ERRORS as exc:
        errors.append('original controller/inventory: ' + str(exc))
    job_ids = {job['id'] for job in jobs}
    endpoints = {'protocol': [helpers()[0].normalized_endpoint(row['url']) for row in sorted(values['deployment']['replicas'], key=lambda r: r['replica'])]}
    for job in jobs:
        endpoints[job['id']] = [helpers()[0].normalized_endpoint(values['deployment']['router_url'])]
    raw_paths = list(sections['raw']) + [p for p in sections['protocol'] if 'raw' in p.relative_to(root / 'protocol').parts]
    for path in raw_paths:
        try:
            if path in sections['raw']:
                relative = path.relative_to(root / 'raw')
                require(len(relative.parts) == 2 and relative.parts[0] in job_ids, 'raw outside selected flat job')
                scope = relative.parts[0]
            else:
                require(path.parent == root / 'protocol' / spec['model_id'] / 'raw', 'protocol raw outside selected flat namespace')
                scope = 'protocol'
            raw_rows.append({'path': str(path), 'scope': scope, 'raw': reader.read(path)})
        except ERRORS as exc:
            malformed.append({'path': str(path), 'error': str(exc)})
    raw = audit_rows(raw_rows, profile, 'development-v4:' + root.name, endpoints, values['authority_ref']['expires_unix'], started)
    raw['unjoined_physical_files'] = malformed
    raw['passed'] = raw['passed'] and not malformed
    write_new(output / 'raw_audit.json', raw)
    protocol_raw = [row['raw'] for row in raw_rows if row['scope'] == 'protocol']
    nonce = audit_nonce(values['nonce_report'], protocol_raw, spec['model_id'], profile)
    nonce['independent_accounting'] = nonce_accounting(values['nonce_report'], protocol_raw)
    nonce['passed'] = nonce['passed'] and nonce['independent_accounting']['passed']
    write_new(output / 'nonce_audit.json', nonce)
    nonce_scope = root / 'protocol' / spec['model_id']
    expected_events, expected_starts = set(), set()
    try:
        for record in protocol_raw:
            replica = record['request_payload']['seed'] - 1210
            require(record.get('context') == {'development_replica': replica, 'plan_sha256': values['authority_ref']['plan_sha256']}, 'nonce historical plan context differs')
        for replica in values['nonce_report']['replicas']:
            for record in replica['records']:
                event = nonce_scope / 'events' / (record['case_id'] + '.json')
                expected_events.add(event)
                require(reader.read(event) == record, 'nonce event/report differs')
                if record['attempted'] is True:
                    start = nonce_scope / 'starts' / (record['case_id'] + '.json')
                    expected_starts.add(start)
                    require(reader.read(start)['client_metadata'] == record['client_metadata'], 'nonce start/client differs')
        expected_protocol = expected_events | expected_starts | {nonce_scope / 'plan.json', nonce_scope / 'report.json'} | {Path(r['path']) for r in raw_rows if r['scope'] == 'protocol'}
        require(set(sections['protocol']) == expected_protocol, 'protocol physical inventory differs')
        stored_plan = reader.read(nonce_scope / 'plan.json')
        require(stored_plan['model'] == spec['model_id'] and stored_plan['cases'] == values['nonce_report']['plan'] and
                stored_plan['endpoint_sources'] == endpoints['protocol'], 'nonce plan/endpoint differs')
    except ERRORS as exc:
        errors.append('nonce physical scope: ' + str(exc))
    expected_results, linked = set(), set()
    for job in jobs:
        row = {'job_id': job['id'], 'passed': False, 'expected_traces': job['expected_traces']}
        job_rows.append(row)
        folder = root / 'journal' / job['id']
        paths = sorted(Path(job['output_dir']).glob('*/traces-v2/*.json')) if job['system'] == 'expgym' else [Path(job['output_dir']) / job['strategy'] / 'agents' / ('agent_%d.json' % i) for i in range(4)]
        existing = [path for path in paths if path.is_file()]
        traces.extend(existing)
        actual_results = set(inventory(job['output_dir']))
        expected_results.update(actual_results)
        try:
            require(reader.read(folder / 'reserved.json') == {'job_id': job['id']}, 'job reservation differs')
            status = reader.read(folder / 'final_status.json')
            row['original_status_passed'] = status.get('passed')
            require(status.get('job_id') == job['id'], 'status job identity differs')
            inventory_binding(status['inventory'], list(actual_results) + inventory(job['dump_dir']), reader)
            retained_statuses = [r for stage in values['execution']['stages'] for r in stage['results'] if r['job_id'] == job['id']]
            require(len(retained_statuses) == 1 and canonical(retained_statuses[0]) == canonical(status), 'execution/final status differs')
            for label in ('identity', 'run', 'resume') + (('score',) if job['system'] == 'poolact' else ()):
                recorded = status[label]
                log = folder / (label + '.log')
                require(recorded['exit_code'] == 0 and type(recorded['exit_code']) is int and Path(recorded['log']) == log,
                        'original child failed or log namespace differs')
                reader.bind(log, recorded['log_sha256'])
            require(len(existing) == job['expected_traces'], 'complete canonical owner artifacts missing')
            if job['system'] == 'expgym':
                require(actual_results == set(existing), 'unexpected Exp result JSON')
            else:
                require(actual_results == set(existing) | {Path(job['output_dir']) / 'summary.json', Path(job['output_dir']) / job['strategy'] / 'result.json'}, 'N4 result/summary set differs')
            pre = status['identity']['receipt']
            guard = original_raw_guard(d, values['plan'], job, pre)
            row['original_raw_guard'] = guard
            require(guard.get('passed') is True, 'fresh original raw ledger/history guard rejected')
            scored = child(values['plan'], job, pre, existing, output)
            row['independent_child'] = scored
            expected_ids = {r['raw'].get('request_id') for r in raw_rows if r['scope'] == job['id']}
            require(set(scored['request_ids']) == expected_ids and not linked.intersection(expected_ids), 'independent child/raw request set differs')
            linked.update(expected_ids)
            require(not any(r['errors'] for r in raw['attempts'] if r['scope'] == job['id']), 'raw or authority failure affects entire job')
            require(status.get('passed') is True, 'original invocation failed; independent diagnostic cannot promote it')
            row['passed'] = True
        except ERRORS + (subprocess.SubprocessError,) as exc:
            row['error'] = str(exc)
    if expected_results != set(sections['results']):
        errors.append('results outside selected job namespaces')
    observed_ids = {row.get('request_id') for row in raw['attempts'] if row['scope'] != 'protocol'}
    full = len(traces) == 51 and all(row['passed'] for row in job_rows) and linked == observed_ids
    checks = {'native_tools': full and raw['passed'] and nonce['passed'],
              'rendered_task_context': full,
              'assistant_tool_history': full and raw['passed'] and nonce['passed'],
              'full_attempt_coverage': full and raw['passed'] and nonce['passed'] and not errors}
    for section, before in sections.items():
        require(inventory(root / section) == before, 'original namespace changed during audit')
    reader.unchanged()
    report = {'schema_version': 'development-v4-independent-protocol-audit-v1',
        'evidence_kind': spec['evidence_kind'], 'model_id': spec['model_id'], 'deployment_id': spec['deployment_id'],
        'source_tree_sha256': SOURCE, 'profile_sha256': sha(canonical(profile)),
        **{key: spec[key] for key in REFS}, 'input_ref': {'path': str(safe(spec_path)), 'sha256': spec_sha256},
        'checks': checks, 'score_checks_complete': full, 'strict_repeatability': None,
        'passed': all(checks.values()) and not errors and values['execution'].get('passed') is True and values['nonce_report'].get('passed') is True,
        'raw_artifacts': [{'path': str(p), 'sha256': reader.files[str(p)]['sha256']} for p in raw_paths],
        'trace_artifacts': [{'path': str(p), 'sha256': reader.files[str(p)]['sha256']} for p in traces],
        'scope_details': {'expected_jobs': 15, 'expected_task_traces': 51, 'observed_task_traces': len(traces),
                          'expected_nonce_slots': 12, 'job_rows': job_rows, 'nonce': nonce, 'errors': errors},
        'all_attempt_usage': raw['all_attempt_usage'], 'finish_reasons': raw['finish_reasons'],
        'field_definition': {'rendered_task_context': 'Independent original source to CLIENT request messages, including N4 stored graph syntax/schema-aware trim. NOT server tokenizer/chat-template rendering.',
            'full_attempt_coverage': 'Exact full 15-job/51-owner plus fixed 12-slot selected development scope; no formal-matrix or project-wide cost claim.',
            'historical_GO': 'Every retained attempt start checked against original expiry and execution-start observation. Finish after expiry is allowed and reported; current wall clock is not checked.'},
        'server_rendered_tokens_verified': False, 'transport_join_performed': False,
        'runtime_executable_links': reader.runtime_links,
        'auditor_source_files': own_identity, 'auditor_identity_sha256': sha(canonical(own_identity)),
        'limitations': ['Original repository scorers independently executed; not an independent scoring algorithm.',
            'N4 graph-owned syntax/history/trim checked, not a full concurrent graph/cache/clock causal replay.',
            'ROOT-pinned external drain observation consumed; no health, process, key, socket, model, runner main, or resume call by this auditor.',
            'Missing/retried provider usage stays unknown; reasoning is included in output, not added twice.',
            'Not the mandatory final fresh post-analysis logic audit.'],
        'file_bindings': sorted(reader.files.values(), key=lambda r: r['path'])}
    write_new(output / 'audit.json', report)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--spec', type=Path, required=True)
    parser.add_argument('--spec-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    report = audit(args.spec, args.spec_sha256, args.output)
    print(canonical({'passed': report['passed'], 'checks': report['checks'], 'score_checks_complete': report['score_checks_complete']}).decode())
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
