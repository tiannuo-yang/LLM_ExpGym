#!/usr/bin/env python3
"""One bounded offline acceptance: pure boundaries plus sealed source fixtures."""
import argparse
import os
from pathlib import Path
import subprocess
import sys

from common import CANDIDATE, HERE, Reader, canonical, sha, strict, write_new

WORK = HERE.parents[2]
CPU_SHA = 'dde4744634aa66bbde590793062ee8dea4d13277253caa621c2245e01e66300e'
TABLE_SHA = '99775738099ba65fe68c7f737e2be36797587ea85e0efd2b11909f8a1d172fd7'
TEST = """
import contextlib,os,socket,sys,unittest
from unittest import mock
def deny(*a,**k): raise AssertionError('independent validator forbids network')
with contextlib.ExitStack() as stack:
 for name in ('socket.create_connection','socket.getaddrinfo','socket.socket.connect','socket.socket.connect_ex'):
  stack.enter_context(mock.patch(name,side_effect=deny))
 suite=unittest.defaultTestLoader.loadTestsFromNames(['test_audit','test_nonce_checks','test_score_context_child','test_validator_parser','test_orphan_accounting','test_numeric_profile'])
 result=unittest.TextTestRunner(verbosity=2).run(suite)
 print('DEV_TEST_COUNTS',result.testsRun,len(result.errors),len(result.failures),len(result.skipped))
 raise SystemExit(not result.wasSuccessful())
"""


def extract_source_receipt(body):
    prefix = b'DEV_INDEPENDENT_SEALED_TEST_JSON='
    if body.count(prefix) != 1:
        raise ValueError('exactly one source receipt marker required')
    lines = [line.partition(prefix)[2] for line in body.splitlines() if prefix in line]
    if len(lines) != 1:
        raise ValueError('exactly one complete source receipt line required')
    # strict_json consumes the entire suffix; no trailing candidates tolerated.
    return strict(lines[0])


def run(output, reuse=None, reuse_sha256=None):
    output = Path(output).absolute()
    if output.exists():
        raise ValueError('new CPU evidence directory required')
    reader = Reader()
    code = {path.name: sha(reader.bind(path)) for path in sorted(HERE.glob('*.py'))}
    cpu = reader.read(CANDIDATE / 'validation/cpu_v4/receipt.json', CPU_SHA)
    table = reader.read(CANDIDATE / 'validation/cpu_v4/file_table.json', TABLE_SHA)
    if len(cpu['artifacts']) != 1987:
        raise ValueError('sealed original fixture inventory differs')
    for row in cpu['artifacts'] + table['files']:
        if len(reader.bind(row['path'], row['sha256'])) != row['bytes']:
            raise ValueError('sealed fixture byte length differs')
    output.mkdir(parents=True)
    prior = reader.read(Path(reuse) / 'receipt.json', reuse_sha256) if reuse else None
    if reuse and not reuse_sha256:
        raise ValueError('explicit original CPU receipt SHA required for no-rerun reseal')
    if prior:
        for name, expected in prior['code_files'].items():
            path = HERE / name
            if sha(path.read_bytes()) != expected:
                path = HERE / ('correction/cpu_v1_parser/validate_cpu.py' if name == 'validate_cpu.py' else 'correction/before_orphan_accounting/' + name)
            reader.bind(path, expected)
    env = {k: v for k, v in os.environ.items() if 'KEY' not in k.upper() and 'TOKEN' not in k.upper()
           and not k.upper().endswith('PROXY') and k != 'PYTHONPATH'}
    env.update(PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1',
               NO_PROXY='*', no_proxy='*')
    results = []
    for label, python in (('native', WORK / 'LLM_ExpGym/.venv/bin/python'),
                          ('legacy_pure', WORK / 'kimi_k3_eval/data_runtime/.venv-hpo/bin/python')):
        if label == 'native' and prior is None:
            env['DEV_INDEPENDENT_SEALED_ROOT'] = str(CANDIDATE / 'validation/cpu_v4/tmp')
        else:
            env.pop('DEV_INDEPENDENT_SEALED_ROOT', None)
        completed = subprocess.run([str(python), '-B', '-c', TEST], env=env, cwd=str(HERE), stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        body, exit_code = completed.stdout, completed.returncode
        log = output / (label + '.log')
        with log.open('xb') as stream:
            stream.write(body)
        counts = [line.decode().split()[1:] for line in body.splitlines() if line.startswith(b'DEV_TEST_COUNTS ')]
        expected = ['76', '0', '0', ('1' if prior else '0') if label == 'native' else '2']
        result = {'runtime': label, 'passed': exit_code == 0 and counts == [expected],
            'exit_code': exit_code, 'counts': counts, 'log': {'path': str(log), 'sha256': sha(body)}}
        if label == 'native':
            source_body = body
            if prior:
                original = next(row for row in prior['runs'] if row['runtime'] == 'native')
                source_body = reader.bind(original['log']['path'], original['log']['sha256'])
                require_counts = [line.decode().split()[1:] for line in source_body.splitlines() if line.startswith(b'DEV_TEST_COUNTS ')]
                if original['exit_code'] != 0 or require_counts != [['67', '0', '0', '0']]:
                    raise ValueError('original complete 67-test execution not proven')
                result['original_completed_source_test_log'] = original['log']
                result['original_completed_test_counts'] = require_counts
            prefix = b'DEV_INDEPENDENT_SEALED_TEST_JSON='
            # unittest's stderr progress can precede stdout on the same merged
            # line. The unique literal marker still delimits the complete JSON.
            result['source_marker_occurrences'] = source_body.count(prefix)
            result['capture_mode'] = 'original stdout/stderr merged by stderr=STDOUT; no separate streams retained'
            if source_body.count(prefix) != 1:
                result['passed'] = False
            else:
                source = extract_source_receipt(source_body)
                result['strict_JSON_complete_suffix_read'] = True
                write_new(output / 'sealed_source_recheck.json', source)
                result['source_routes'] = source['source_routes']
                result['source_recheck_passed'] = source['passed']
                result['passed'] = result['passed'] and source['passed'] is True and source['source_routes'] == 27
        results.append(result)
    reader.unchanged()
    receipt = {'schema_version': 'development-v4-independent-auditor-cpu-acceptance-v1',
        'classification': 'Static/fake validation', 'passed': all(row['passed'] for row in results),
        'code_files': code, 'runs': results, 'original_fixture_files': 1987,
        'original_fixture_bytes': sum(row['bytes'] for row in cpu['artifacts']), 'original_bytes_and_mtimes_unchanged': True,
        'bindings': sorted(reader.files.values(), key=lambda row: row['path']),
        'new_model_or_API_calls': 0, 'real_authorization_issued': False, 'real_development_audit_performed': False,
        'reused_original_test_logs': {'path': str(Path(reuse) / 'receipt.json'), 'sha256': reuse_sha256} if reuse else None,
        'validation_interpretation': 'Fresh current pure CPU boundaries plus parser-corrected original 67/67 log and 27 unchanged scorer/context routes. NOT a fresh post-change full source/scorer regression.' if reuse else 'Fresh CPU validation.',
        'limits': ['Pure synthetic entry/isolation tests do not create real authority or establish full real acceptance.',
            '27 original-source mock-wire fixtures are re-scored; actual source inputs stay synthetic. Native 3.11 only for real scorer paths.',
            'Legacy pure run skips the 3.11-specific filesystem guard and opt-in source replay; it does not claim ParamNet routes.',
            'Original source/scorer child subprocesses are expected; no generation/runner main/resume/network is run.',
            'Actual new development whole-run audit requires later ROOT GO and pinned original post-drain inputs.']}
    write_new(output / 'receipt.json', receipt)
    print(canonical({'passed': receipt['passed'], 'runs': [{k: v for k, v in row.items() if k != 'log'} for row in results],
                     'original_fixture_files': 1987, 'bindings': len(reader.files)}).decode())
    return receipt['passed']


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--reuse-test-logs', type=Path)
    parser.add_argument('--reuse-receipt-sha256')
    args = parser.parse_args()
    raise SystemExit(0 if run(args.output, args.reuse_test_logs, args.reuse_receipt_sha256) else 1)
