"""Pure in-memory adversarial tests; no producer, source client or transport."""
import copy
import json
import socket
import unittest
from unittest import mock

import nonce_checks as n


def fixture(model="kimi-k3"):
    report = {"schema_version": "development-v4-nonce-v1", "classification": "development_protocol_diagnostic",
              "plan": n._planned(), "planned_logical_calls": 12, "actual_logical_calls": 12,
              "skipped_logical_calls": 0, "replicas": [], "passed": True, "semantic_retries": 0}
    raws = []
    for replica in range(4):
        value = "synthetic_nonce_%02d_0123456789abcdef" % replica
        call = {"id": "nonce_call_%d" % replica, "type": "function", "function": {"name": "issue_nonce", "arguments": "{}"}}
        first_message = {"role": "assistant", "content": None, "tool_calls": [call],
                         "reasoning_content": "original reasoning", "provider_extra": {"nested": [1, None]}}
        prefix = copy.deepcopy(n.MESSAGES) + [copy.deepcopy(first_message), {"role": "tool", "name": "issue_nonce",
            "tool_call_id": call["id"], "content": n._canonical({"nonce": value})}]
        group = {"replica": replica, "seed": 1210 + replica, "nonce_generated": True,
                 "expected_nonce": value, "records": []}
        report["replicas"].append(group)
        for index, label in enumerate(n.LABELS):
            item = report["plan"][replica * 3 + index]
            case_id = item["case_id"]
            messages = copy.deepcopy(n.MESSAGES if label == "first" else prefix)
            if label == "second_none":
                messages.append({"role": "user", "content": n.FINAL_NOTE})
            content = json.dumps({"nonce": value})
            if label == "second_none":
                content = "Answer: " + content
            message = copy.deepcopy(first_message) if label == "first" else {"role": "assistant", "content": content}
            response = {"choices": [{"message": message, "finish_reason": "tool_calls" if label == "first" else "stop"}],
                        "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15}}
            metadata = {"schema_version": "expgym.api_attempt.v1", "client_id": "client_%d" % replica, "run_id": "synthetic"}
            attempt = {"request_id": case_id + "_attempt1", "generation_id": case_id + "_generation", "attempt": 1,
                       "state": "success", "http_status": None, "usage": response["usage"]}
            inputs = {"messages": messages, "tools": copy.deepcopy(n.TOOLS), "tool_choice": item["tool_choice"]}
            raw = dict(metadata, **attempt)
            raw.update(request_payload=dict(copy.deepcopy(inputs), model=model, seed=1210 + replica, parallel_tool_calls=False),
                       response_json=response, response_raw=json.dumps(response))
            output = n._decode(raw)
            output.update(attempt_usage=[copy.deepcopy(attempt)], request_attempts=1)
            record = dict(copy.deepcopy(item), state="delivered", attempted=True, input=inputs, output=output,
                          exception=None, attempt_usage=[copy.deepcopy(attempt)], client_metadata=metadata,
                          evaluation={"passed": True})
            if label != "first":
                record["expected_nonce"] = value
            group["records"].append(record)
            raws.append(raw)
    return report, raws, {"model": model}


def rows(report):
    return [row for replica in report["replicas"] for row in replica["records"]]


def set_response(report, raws, index, message=None, finish=None):
    raw, row = raws[index], rows(report)[index]
    if message is not None:
        raw["response_json"]["choices"][0]["message"] = message
    if finish is not None:
        raw["response_json"]["choices"][0]["finish_reason"] = finish
    raw["response_raw"] = json.dumps(raw["response_json"])
    row["output"].update(n._decode(raw))


def skip(report, raw_records, index, reason):
    row = rows(report)[index]
    request_ids = {item["request_id"] for item in row.get("attempt_usage") or []}
    raw_records[:] = [raw for raw in raw_records if raw["request_id"] not in request_ids]
    row.update(state="skipped", attempted=False, input=None, output=None, exception=None, attempt_usage=None, skip_reason=reason)
    row.pop("expected_nonce", None)
    report["actual_logical_calls"] -= 1
    report["skipped_logical_calls"] += 1


class NonceAuditTests(unittest.TestCase):
    def audit(self, report, raws, profile):
        before = copy.deepcopy((report, raws, profile))
        with mock.patch.object(socket.socket, "connect", side_effect=AssertionError("network forbidden")):
            value = n.audit_nonce(report, raws, profile["model"], profile)
        self.assertEqual((report, raws, profile), before)
        self.assertEqual(len(value["slotfacts"]), 12)
        return value

    def codes(self, result):
        return {issue["code"] for issue in result["issues"]}

    def test_both_models_happy_path(self):
        for model in ("kimi-k3", "glm-5.3"):
            with self.subTest(model=model):
                result = self.audit(*fixture(model))
                self.assertTrue(result["passed"], result["issues"])
                self.assertTrue(all(result["checks"].values()))

    def test_producer_passed_and_evaluation_are_not_evidence(self):
        report, raws, profile = fixture()
        report["passed"] = False
        for row in rows(report):
            row["evaluation"] = {"passed": False, "reason": "untrusted producer flag"}
        self.assertTrue(self.audit(report, raws, profile)["passed"])

    def test_wrong_answer_retained_even_with_producer_pass(self):
        report, raws, profile = fixture()
        set_response(report, raws, 1, {"role": "assistant", "content": '{"nonce":"wrong"}'})
        result = self.audit(report, raws, profile)
        self.assertFalse(result["passed"])
        self.assertFalse(result["checks"]["nonce_answers"])
        self.assertTrue(result["checks"]["raw_response_binding"])
        self.assertEqual(result["slotfacts"][1]["answer_reason"], "wrong_nonce_or_shape")

    def test_answer_prefix_only_allowed_in_none_branch(self):
        report, raws, profile = fixture()
        message = copy.deepcopy(raws[1]["response_json"]["choices"][0]["message"])
        message["content"] = "Answer: " + message["content"]
        set_response(report, raws, 1, message)
        result = self.audit(report, raws, profile)
        self.assertEqual(result["slotfacts"][1]["answer_reason"], "not_strict_json")

    def test_duplicate_answer_key_and_nonfinite_are_not_json_answers(self):
        for text in ('{"nonce":"a","nonce":"b"}', '{"nonce":1e999}', '{"nonce":NaN}'):
            report, raws, profile = fixture()
            set_response(report, raws, 1, {"role": "assistant", "content": text})
            self.assertEqual(self.audit(report, raws, profile)["slotfacts"][1]["answer_reason"], "not_strict_json")

    def test_entire_assistant_message_extras_must_survive(self):
        report, raws, profile = fixture()
        del raws[1]["request_payload"]["messages"][1]["provider_extra"]
        rows(report)[1]["input"] = {key: copy.deepcopy(raws[1]["request_payload"][key]) for key in ("messages", "tools", "tool_choice")}
        result = self.audit(report, raws, profile)
        self.assertIn("branch_full_history_missing_or_mismatch", self.codes(result))
        self.assertFalse(result["checks"]["assistant_tool_history"])

    def test_forced_final_note_and_auto_branch_isolation(self):
        report, raws, profile = fixture()
        raws[2]["request_payload"]["messages"].insert(3, {"role": "assistant", "content": "auto answer leaked"})
        rows(report)[2]["input"]["messages"] = copy.deepcopy(raws[2]["request_payload"]["messages"])
        self.assertFalse(self.audit(report, raws, profile)["checks"]["assistant_tool_history"])
        report, raws, profile = fixture()
        raws[2]["request_payload"]["messages"][-1]["content"] = "Answer now."
        rows(report)[2]["input"]["messages"] = copy.deepcopy(raws[2]["request_payload"]["messages"])
        self.assertFalse(self.audit(report, raws, profile)["checks"]["assistant_tool_history"])

    def test_structured_empty_arguments_preserve_original_history(self):
        report, raws, profile = fixture()
        message = copy.deepcopy(raws[0]["response_json"]["choices"][0]["message"])
        message["tool_calls"][0]["function"]["arguments"] = {}
        set_response(report, raws, 0, message)
        for index in (1, 2):
            raws[index]["request_payload"]["messages"][1] = copy.deepcopy(message)
            rows(report)[index]["input"]["messages"][1] = copy.deepcopy(message)
        self.assertTrue(self.audit(report, raws, profile)["passed"])

    def test_report_output_cannot_replace_original_raw(self):
        report, raws, profile = fixture()
        rows(report)[0]["output"]["assistant_message"]["reasoning_content"] = "tampered"
        result = self.audit(report, raws, profile)
        self.assertIn("recorded_output_differs_from_raw_assistant_message", self.codes(result))
        self.assertFalse(result["checks"]["raw_response_binding"])

    def test_answer_compared_to_actual_tool_payload_not_report_nonce(self):
        report, raws, profile = fixture()
        raws[1]["request_payload"]["messages"][2]["content"] = '{"nonce":"different_wire_nonce_0123456789"}'
        rows(report)[1]["input"]["messages"] = copy.deepcopy(raws[1]["request_payload"]["messages"])
        result = self.audit(report, raws, profile)
        self.assertFalse(result["checks"]["assistant_tool_history"])
        self.assertFalse(result["slotfacts"][1]["nonce_answer_exact"])

    def test_raw_response_json_must_match_original_string(self):
        report, raws, profile = fixture()
        raws[1]["response_json"]["choices"][0]["message"]["content"] = "changed parsed only"
        result = self.audit(report, raws, profile)
        self.assertIn("terminal_response_not_decodable", self.codes(result))

    def test_invalid_first_keeps_dependent_skips_and_later_replicas(self):
        report, raws, profile = fixture()
        message = copy.deepcopy(raws[0]["response_json"]["choices"][0]["message"])
        message["tool_calls"][0]["function"]["arguments"] = '{"extra":1}'
        set_response(report, raws, 0, message)
        skip(report, raws, 1, "first_native_call_not_valid")
        skip(report, raws, 2, "first_native_call_not_valid")
        report["replicas"][0].update(nonce_generated=False, expected_nonce=None)
        result = self.audit(report, raws, profile)
        self.assertFalse(result["passed"])
        self.assertTrue(result["checks"]["fixed_slots"])
        self.assertTrue(result["checks"]["raw_response_binding"])
        self.assertTrue(result["checks"]["no_semantic_resampling"])
        self.assertEqual(result["counts"]["skipped_logical_slots"], 2)

    def test_initial_external_stop_keeps_all_twelve(self):
        report, raws, profile = fixture()
        for index in range(12):
            skip(report, raws, index, "external_stop")
        for replica in report["replicas"]:
            replica.update(nonce_generated=False, expected_nonce=None)
        result = self.audit(report, raws, profile)
        self.assertFalse(result["passed"])
        self.assertTrue(result["checks"]["fixed_slots"])
        self.assertTrue(result["checks"]["raw_response_binding"])
        self.assertEqual(result["counts"]["retained_raw_attempts"], 0)

    def test_provider_abort_error_and_all_remaining_skipped(self):
        report, raws, profile = fixture()
        row = rows(report)[0]
        raw = raws[0]
        raw.update(state="error", error={"type": "APICompletionAbortedError"})
        raw["response_json"]["choices"][0]["finish_reason"] = "abort"
        raw["response_raw"] = json.dumps(raw["response_json"])
        row["attempt_usage"][0]["state"] = "error"
        row.update(state="error", output=None, exception={"type": "APICompletionAbortedError"})
        for index in range(1, 12):
            skip(report, raws, index, "external_stop")
        for replica in report["replicas"]:
            replica.update(nonce_generated=False, expected_nonce=None)
        result = self.audit(report, raws, profile)
        self.assertFalse(result["passed"])
        self.assertTrue(result["checks"]["fixed_slots"])
        self.assertTrue(result["checks"]["raw_response_binding"])
        self.assertTrue(result["checks"]["no_semantic_resampling"])
        self.assertEqual(result["slotfacts"][0]["exception_type"], "APICompletionAbortedError")

    def test_error_must_stop_new_slots(self):
        report, raws, profile = fixture()
        rows(report)[0].update(state="error", output=None, exception={"type": "APIClientError"})
        raws[0]["state"] = "error"
        result = self.audit(report, raws, profile)
        self.assertIn("attempt_after_stop_or_exception", self.codes(result))

    def test_missing_duplicate_unknown_slots_and_raws_fail_closed(self):
        for kind in ("missing_slot", "duplicate_slot", "extra_raw", "duplicate_raw", "missing_raw"):
            report, raws, profile = fixture()
            if kind == "missing_slot":
                report["replicas"][0]["records"].pop()
            elif kind == "duplicate_slot":
                report["replicas"][0]["records"][2] = copy.deepcopy(report["replicas"][0]["records"][1])
            elif kind == "extra_raw":
                raw = copy.deepcopy(raws[0]); raw["request_id"] = "orphan"; raws.append(raw)
            elif kind == "duplicate_raw":
                raws.append(copy.deepcopy(raws[0]))
            else:
                raws.pop()
            with self.subTest(kind=kind):
                self.assertFalse(self.audit(report, raws, profile)["passed"])

    def test_success_cannot_be_resampled_with_new_attempt(self):
        report, raws, profile = fixture()
        raw = copy.deepcopy(raws[0])
        raw.update(request_id="extra_attempt", attempt=2)
        raws.append(raw)
        row = rows(report)[0]
        extra = copy.deepcopy(row["attempt_usage"][0])
        extra.update(request_id="extra_attempt", attempt=2)
        row["attempt_usage"].append(extra)
        row["output"].update(attempt_usage=copy.deepcopy(row["attempt_usage"]), request_attempts=2)
        result = self.audit(report, raws, profile)
        self.assertIn("success_resampled", self.codes(result))

    def test_two_generations_in_one_slot_and_client_reuse_fail(self):
        report, raws, profile = fixture()
        raw = copy.deepcopy(raws[0])
        raw.update(request_id="extra_attempt", generation_id="new_generation", attempt=2)
        raws.append(raw)
        row = rows(report)[0]
        extra = copy.deepcopy(row["attempt_usage"][0])
        extra.update(request_id="extra_attempt", generation_id="new_generation", attempt=2)
        row["attempt_usage"].append(extra)
        self.assertIn("slot_does_not_bind_one_generation", self.codes(self.audit(report, raws, profile)))
        report, raws, profile = fixture()
        for index in range(3, 6):
            raws[index]["client_id"] = "client_0"
            rows(report)[index]["client_metadata"]["client_id"] = "client_0"
        self.assertIn("client_reused_across_replicas", self.codes(self.audit(report, raws, profile)))

    def test_generation_cannot_span_two_logical_slots(self):
        report, raws, profile = fixture()
        raws[1]["generation_id"] = raws[0]["generation_id"]
        rows(report)[1]["attempt_usage"][0]["generation_id"] = raws[0]["generation_id"]
        rows(report)[1]["output"]["attempt_usage"][0]["generation_id"] = raws[0]["generation_id"]
        result = self.audit(report, raws, profile)
        self.assertIn("generation_reused_across_slots", self.codes(result))

    def test_error_report_cannot_hide_success_raw(self):
        report, raws, profile = fixture()
        rows(report)[0].update(state="error", output=None, exception={"type": "APIClientError"})
        result = self.audit(report, raws, profile)
        self.assertIn("error_slot_without_terminal_error_raw", self.codes(result))

    def test_profile_model_seed_and_boolean_plan_identity_fail(self):
        report, raws, profile = fixture()
        raws[0]["request_payload"]["seed"] = True
        report["plan"][0]["replica"] = False
        result = self.audit(report, raws, profile)
        self.assertIn("raw_model_or_seed_mismatch", self.codes(result))
        self.assertIn("fixed_plan_mismatch", self.codes(result))
        result = n.audit_nonce(report, raws, "kimi-k3", {"model": "glm-5.3"})
        self.assertIn("validated_profile_model_mismatch", self.codes(result))

    def test_nonce_exposed_in_first_assistant_is_rejected(self):
        report, raws, profile = fixture()
        message = copy.deepcopy(raws[0]["response_json"]["choices"][0]["message"])
        message["reasoning_content"] = report["replicas"][0]["expected_nonce"]
        set_response(report, raws, 0, message)
        for index in (1, 2):
            raws[index]["request_payload"]["messages"][1] = copy.deepcopy(message)
            rows(report)[index]["input"]["messages"][1] = copy.deepcopy(message)
        self.assertIn("nonce_exposed_before_tool_result", self.codes(self.audit(report, raws, profile)))


if __name__ == "__main__":
    unittest.main()
