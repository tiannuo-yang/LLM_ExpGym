# GLM 初次加载：有限现场诊断

ROOT，2026-09-08 15:00 UTC；模型生成请求尚未开始。

此时没有 `Load weight end` 或 server ready，不能认定模型已经可用。但已有直接证据表明所查进程在短窗口内推进，不能将日志安静称为全部挂死。

- 14:55:56 的非阻塞 Python 栈：node267 / job1203577 / step18 / PID305225 / UID1071 / parent302851 身份匹配。主线程在 `deepseek_weight_loader.py:435` 等待 futures；32 个 worker 的顶层调用分别为 `layer.py:647`（15 个）与 `:727`（17 个）的 `expert_data.copy_(loaded_weight)`。
- 14:57:36–47 两次只读快照：PID starttime 相同，read_bytes 增加 203,743,232 字节，major faults 增加 52,016，CPU ticks 增加 622。ROOT从原始两行 JSON 独立复算，并逐个核对上述32个线程，全部有 CPU 与 major-fault 增量。两点分别有7/6个 `wait_on_page_bit_common` 和2个 `cl_sync_io_wait`。
- 两点 GPU 利用率均为0。首节点每卡约48GB只能称已分配/占用显存，参数先分配再复制，不能由此推出权重全部复制完成。
- 本次进度条完成不代表后续 tensor 拷贝任务全部返回。当前栈尚未到 `post_load_weights` 或外层量化后处理。具体iterator分支见下述15:07更正，不能只由同名日志判断。

结论只限一个进程、约10秒窗口的文件页读取/加载活动。它不量化整个64GPU部署的吞吐、完成比例、剩余时间，不排除其他线程/节点的问题，也不确证唯一性能瓶颈。暂不重启、不改加载线程数、采样或模型设置；继续等待实际 ready 或明确错误。

原件 SHA：

- `nonblocking_stack_snapshot_v1/stack.stdout`：`e586fc31a108a615d6c803a0defd73d493658e097dc4934ebcfcae4ac5ea3d33`
- `progress_delta_snapshot_v1/delta.stdout`：`ddcd61f5b320c2945f53ffd5e17779ae21852712ae4aca885acbdec305249646`
- `progress_delta_snapshot_v1/receipt.json`：`0b4706941f993131892dbfc75684b8e0856c9bd39fab546a8e0764d1a528087b`

此前只读设备快照v1缺少 `--cpu-bind=none` 而未启动命令；v2的gpu:0 step看不到GPU，均完整保留。v3在同作业一个已分配节点使用overlap/gpu:8，未申请新GPU、未执行额外GPU计算，查询成功。这些是诊断调用配置问题，不是模型生成失败。ROOT首次将差分stdout按单JSON解析得到Extra data；随后按两行JSON读取，原件未改。

最后的全结果/分析后独立逻辑复查尚未开始；此现场诊断不替代该验收。

## 15:07 源码分支归因更正

先前ROOT和只读reviewer由相同进度日志引用 `weight_utils.py:1055–1097` 的旧多线程函数，依据不足。沿实际installed `DefaultModelLoader._get_weights_iterator` 完整调用链复核，`:615–625` 接的是 `buffered_multi_thread_safetensors_weights_iterator`（`weight_utils.py:1099–1165`）。两函数打印相同日志；buffered使用deque按shard取future/yield并更新进度，但Deepseek另一层无界copy任务提交仍未等待。原动态栈/I/O数字及“141/141不等于copies完成”的结论不变，旧函数不能再作为本次实际路径依据。

原启动日志参数为load_format auto、model_loader_extra_config空对象，disable_mmap/prefetch/drop_cache均false。141个结构报告shard合计755,632,050,320字节（755.632十进制GB，703.737GiB），不是705十进制GB；未为此读取权重payload。在线额外顺序预读尚未授权或执行。源码的内置prefetch会配套回退单线程以避免共享存储争用，不能据此直接声称在当前多线程服务旁另加预读一定更快。

## 15:10 长窗口进展与内存观察

15:10:52 的独立轻量只读快照再次确认同PID/starttime。与14:57:47原件相比，read_bytes增加15,897,706,496字节，major faults增加3,858,367，CPU ticks增加43,008；ROOT用Python原JSON独立复算一致。单节点MemAvailable为1,823,731,344 kB，job memory.current为468,179,443,712字节、memory.max为1,950,351,360,000字节，job及step memory.events全部0，memory PSI avg10/60/300全部0。此时无所查内存压力或OOM证据。

节点级IO PSI some/full avg10分别87.76/77.39，不能冒充该PID或全部64GPU的指标，也不能据此确证唯一瓶颈。仍无完成比例或可靠ETA。原件`memory_io_snapshot_v1/memory_io.stdout` SHA256为`3d02bf0bba78e5e0b7bba8d679b64f8e3992f671d95bcfcbb8e3f1230a75d90c`，receipt为`3e5618bcd51b52b7e47e076fac95d8830eb1c411e193a734deae29030a38d29f`。

15:18时仅准备单节点、单顺序流、64 GiB/180秒上限的加载预读尝试；准备不等于已执行。任何实际执行与后续决定另留原件，不从页缓存或计数变化直接宣称因果提速，也不自动推广到其余节点。

## 15:32 有界预读原件与实际加载完成进展

全部预读仅node267、同job内一个CPU/零GPU overlap step、16 MiB单缓冲顺序读取，不输出或hash权重payload，不修改服务参数。读操作本身改变页缓存并消耗I/O；不是无缓存影响。三个执行原件均保留：

- `readonly_prefetch_trial_v1/actual_v1/receipt.json`（`2e5579ff116847468a31151a63afcd8edab7392f9c34c9c3be10e792d3f5134b`）：15:21:31 allocation_identity_mismatch，0 payload bytes。脚本短主机名比较不兼容已有硬件报告FQDN；本失败未记录比较两值，不能恢复原进程的环境值。新v2仅允许该精确短名/FQDN并在检查前记录实际值，旧文件不改。
- `actual_v2/receipt.json`（`246fc0ecc73d96025e22bc8c685599cdc0530f5cd32d7d449fa4ab2511188f7d`）：15:23:23.732–47.249，23.517秒，64 GiB，byte_limit，helper PID346658。文件1–12完整、13部分；24边界点无内存事件新增或memory PSI avg10非零。
- `actual_full_v1/receipt.json`（`38a1dc1df9fe647dc802fe67a21ac5a085ddd0c904ebe2dc00781339e778f6ad`）：另行批准的单次141文件全读，15:26:36.084–15:30:46.224，250.139651秒，755,632,050,320字节，byte_limit，helper PID349442。249边界点及终点无上述压力信号。前64 GiB重新读取的成本不扣除；两次辅助读取总824,351,527,056字节，不代表独特权重数或模型有效吞吐。ROOT逐文件sum、原件SHA和前后边界独立核对一致。

replica0/node267的TP0–7于15:30:46全部报告`Load weight end`；未接受预读的配对node268 TP8–15于15:31:29全部报告同事件。与预读存在时间关联，但无受控对照，不能作因果提速声明，更不推广到其他节点。

第一个副本15:31:34进入CUDA graph初始化，15:31:53进入DeepGEMM JIT编译/warmup；日志自身提示冷编译通常10–20分钟，不是本次剩余时间保证。此刻仍未取得四副本HTTP ready、metadata或模型生成结果。检查脚本的`passed=false`固定字段仅表示辅助读取不是资格gate，不是模型失败。
