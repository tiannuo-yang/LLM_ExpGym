"""One ROOT-authorized post-development metadata capture; no secret reads here."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
PHASE = HERE.parent
BASE = PHASE.parents[2]
GO = BASE / "ROOT_METADATA_POST_DEVELOPMENT_GLM_1203577.json"
GO_SHA = "e66da9377555cf4aa70fcc2bfe317c0b0e5ec928614aec746b649eebbd34b6d4"


def utc():
    return datetime.now(timezone.utc).isoformat()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def save(name, value):
    raw = value if isinstance(value, bytes) else (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()
    path = HERE / name
    with path.open("xb") as f:
        f.write(raw)
        f.flush()
        os.fsync(f.fileno())
    return {"path": str(path), "sha256": digest(raw), "bytes": len(raw)}


def command(name, argv):
    start = utc()
    save(name + ".command.json", {"argv": argv, "started_utc": start})
    env = dict(os.environ)
    for key in list(env):
        if key.lower().endswith("_proxy"):
            env.pop(key)
    env["NO_PROXY"] = env["no_proxy"] = "*"
    result = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
    stdout = save(name + ".stdout", result.stdout)
    stderr = save(name + ".stderr", result.stderr)
    exit_ref = save(name + ".exit.json", {"started_utc": start, "finished_utc": utc(),
                                            "returncode": result.returncode,
                                            "stdout": stdout, "stderr": stderr})
    if result.returncode:
        raise RuntimeError(name + " command failed")
    return result.stdout, exit_ref


def main():
    save("once_entry.json", {"started_utc": utc(), "operator_pid": os.getpid(),
                             "operator_source_sha256": digest(Path(__file__).read_bytes())})
    receipt = {"schema": "once-authorized-fixed-nine-metadata-operator-v1", "error": None}
    try:
        go_raw = GO.read_bytes()
        assert digest(go_raw) == GO_SHA
        go = json.loads(go_raw)
        assert datetime.now(timezone.utc) < datetime.fromisoformat(go["expires_utc"].replace("Z", "+00:00"))
        for name in ("deployment", "collector", "execution"):
            ref = go[name]
            assert digest(Path(ref["path"]).read_bytes()) == ref["sha256"]
        output = Path(go["output_dir"])
        assert output == PHASE / "metadata_post_development_v1" and not output.exists()
        execution = json.loads(Path(go["execution"]["path"]).read_bytes())
        stages = execution["stages"]
        assert execution["passed"] is True and execution["error_type"] is None
        assert len(stages) == 2 and sum(len(s["results"]) for s in stages) == 15
        assert all(not s["unsubmitted"] and all(r["passed"] is True for r in s["results"]) for s in stages)
        absent = {str(pid): not Path("/proc/%s" % pid).exists() for pid in (3490582, 3515672)}
        assert all(absent.values())
        raw_job, _ = command("pre_job", ["scontrol", "show", "job", "-o", "1203577"])
        fields = dict(item.split("=", 1) for item in raw_job.decode().split() if "=" in item)
        assert fields["JobId"] == "1203577" and fields["JobState"] == "RUNNING"
        assert fields["UserId"] == "chufan.shi(1071)" and fields["Account"] == "k2p"
        assert fields["NumNodes"] == "8" and "gres/gpu=64" in fields["AllocTRES"]
        assert fields["NodeList"] == "azure-uk-hpc-H200-instance-[267-274]"
        assert fields["Command"] == str(BASE / "phase_8nodes.sbatch")
        raw_steps, _ = command("pre_steps", ["squeue", "-h", "--steps", "-j", "1203577", "-o", "%i %j %N"])
        step_ids = {line.split()[0] for line in raw_steps.decode().splitlines()}
        assert {"1203577.%d" % i for i in range(18, 27)} <= step_ids
        event_path = PHASE.parent / "events.jsonl"
        events_raw = event_path.read_bytes()
        events = [json.loads(line) for line in events_raw.splitlines()]
        assert not any(any(word in row.get("kind", "") for word in ("failed", "failure", "unexpected_exit")) for row in events)
        heads = []
        for replica in range(4):
            p = PHASE / ("replica%d-rank0.log" % replica)
            raw = p.read_bytes()
            assert b"The server is fired up and ready to roll!" in raw
            assert b'GET /model_info HTTP/1.1" 200 OK' in raw
            heads.append({"path": str(p), "prefix_sha256": digest(raw), "prefix_bytes": len(raw)})
        save("preconditions.json", {"root_reference": {"path": str(GO), "sha256": GO_SHA},
                                    "refs": {k: go[k] for k in ("deployment", "collector", "execution")},
                                    "known_development_pids_absent": absent, "terminal_jobs": 15,
                                    "full_raw_independent_audit_complete": execution["full_raw_independent_audit_complete"],
                                    "heads_ready_seen_prefixes": heads,
                                    "controller_prefix": {"path": str(event_path), "sha256": digest(events_raw), "bytes": len(events_raw)},
                                    "fresh_provider_drain_not_yet_asserted": True})
        assert datetime.now(timezone.utc) < datetime.fromisoformat(go["expires_utc"].replace("Z", "+00:00"))
        stdout, exit_ref = command("metadata", ["python3", "-B", go["collector"]["path"],
            "--deployment", go["deployment"]["path"], "--output", str(output),
            "--root-reference", str(GO), "--root-reference-sha256", GO_SHA])
        capture_ref = json.loads(stdout)
        assert digest(Path(capture_ref["path"]).read_bytes()) == capture_ref["sha256"]
        receipt.update(capture=capture_ref, exit=exit_ref,
                       collector_unchanged=digest(Path(go["collector"]["path"]).read_bytes()) == go["collector"]["sha256"],
                       deployment_unchanged=digest(Path(go["deployment"]["path"]).read_bytes()) == go["deployment"]["sha256"],
                       execution_unchanged=digest(Path(go["execution"]["path"]).read_bytes()) == go["execution"]["sha256"])
    except BaseException as exc:
        receipt["error"] = type(exc).__name__
        raise
    finally:
        receipt["finished_utc"] = utc()
        receipt["limitations"] = ["Metadata capture is not protocol or scientific acceptance.",
            "Known parent/last-child absence is not by itself a whole-host process census.",
            "ROOT independently reviews terminal callers and provider observation before asserting drain."]
        print(json.dumps(save("receipt.json", receipt)))


if __name__ == "__main__":
    main()
