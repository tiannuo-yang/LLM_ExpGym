"""Actual old/new audit entry; only outer authority/score seams are synthetic."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

import audit
from common import HERE, Reader, inventory, sha, write_new
from test_audit import ENDPOINTS, PROFILE, sample


def previous():
    spec = importlib.util.spec_from_file_location('dev_pre_orphan_audit', HERE / 'correction/before_orphan_accounting/audit.py')
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module


def probe(module, unreadable=False):
    with tempfile.TemporaryDirectory() as tmp:
        root, output = Path(tmp) / 'run', Path(tmp) / 'review'
        rows = [sample(), sample('b', 'h')]
        rows[1]['raw']['client_id'] = 'd'
        rows[1]['raw']['response_json']['usage'] = {'prompt_tokens': 7, 'completion_tokens': 4, 'total_tokens': 11}
        rows[1]['raw']['response_raw'] = json.dumps(rows[1]['raw']['response_json'])
        paths = [root / 'raw/job/a.json', root / 'raw/job/deep/b.json']
        for path, row in zip(paths, rows):
            write_new(path, row['raw'])
        physical = [{'path': str(path), 'sha256': sha(path.read_bytes()), 'bytes': path.stat().st_size} for path in paths]
        protocol = root / 'protocol/kimi-k3'
        nonce = {'replicas': [], 'plan': [], 'passed': False}
        endpoints = ['http://cpu.invalid:%d/v1/chat/completions' % i for i in range(4)]
        write_new(protocol / 'report.json', nonce)
        write_new(protocol / 'plan.json', {'model': 'kimi-k3', 'cases': [], 'endpoint_sources': endpoints})
        protocol_rows = [{'path': str(path), 'sha256': sha(path.read_bytes()), 'bytes': path.stat().st_size} for path in inventory(protocol)]
        values = {'plan': {}, 'authority_ref': {'expires_unix': 1767225610, 'plan_sha256': 'x'}, 'nonce_report': nonce,
            'deployment': {'replicas': [{'replica': i, 'url': url} for i, url in enumerate(endpoints)], 'router_url': ENDPOINTS['job'][0]},
            'execution': {'passed': False, 'model': 'kimi-k3', 'stages': [],
                'physical_inventory': {'files': physical}, 'protocol_inventory': {'files': protocol_rows}}}
        jobs = [{'id': 'job', 'system': 'expgym', 'model': 'kimi-k3', 'expected_traces': 1,
                 'output_dir': str(root / 'results/job'), 'dump_dir': str(root / 'raw/job')}]
        dummy = Path(tmp) / 'dummy.json'; write_new(dummy, {})
        ref = {'path': str(dummy), 'sha256': sha(dummy.read_bytes())}
        spec = dict({key: ref for key in module.REFS}, model_id='kimi-k3', evidence_kind='synthetic_fixture', deployment_id='synthetic')
        spec_path = Path(tmp) / 'spec.json'; write_new(spec_path, spec)
        original_bind = Reader.bind
        def bind(self, path, expected=None):
            if unreadable and Path(path) == paths[1]:
                raise OSError('synthetic unreadable file')
            return original_bind(self, path, expected)
        with mock.patch.object(module, 'preflight', return_value=(None, values, root, jobs, PROFILE, 1767225600)), \
             mock.patch.object(module, 'audit_nonce', return_value={'passed': False}), \
             mock.patch.object(Reader, 'bind', bind), \
             mock.patch.object(module, 'child', side_effect=AssertionError('no scorer for incomplete synthetic job')):
            report = module.audit(spec_path, sha(spec_path.read_bytes()), output)
        raw = json.loads((output / 'raw_audit.json').read_text())
        return {'report_passed': report['passed'], 'raw_passed': raw['passed'], 'usage': raw['all_attempt_usage'],
                'unreadable': report.get('unreadable_raw_artifacts'), 'physical_raw_file_count': raw.get('physical_raw_file_count')}


class OrphanAccountingTests(unittest.TestCase):
    def test_old_counterexample_valid_deep_orphan_cost_omitted(self):
        result = probe(previous())
        self.assertFalse(result['report_passed'])
        self.assertEqual(result['usage']['input_tokens']['known_sum'], 3)
        self.assertEqual(result['usage']['input_tokens']['complete_total'], 3)

    def test_new_keeps_orphan_known_usage_without_qualifying_it(self):
        result = probe(audit)
        self.assertFalse(result['report_passed']); self.assertFalse(result['raw_passed'])
        self.assertEqual(result['usage']['input_tokens']['known_sum'], 10)
        self.assertEqual(result['usage']['input_tokens']['complete_total'], 10)
        self.assertEqual(result['physical_raw_file_count'], 2)

    def test_unreadable_file_old_crash_new_nullable_terminal_report(self):
        with self.assertRaises(KeyError): probe(previous(), True)
        result = probe(audit, True)
        self.assertFalse(result['report_passed'])
        self.assertEqual(result['usage']['input_tokens']['known_sum'], 3)
        self.assertIsNone(result['usage']['input_tokens']['complete_total'])
        self.assertEqual(len(result['unreadable']), 1)
        self.assertIsNone(result['unreadable'][0]['sha256'])


if __name__ == '__main__':
    unittest.main()
