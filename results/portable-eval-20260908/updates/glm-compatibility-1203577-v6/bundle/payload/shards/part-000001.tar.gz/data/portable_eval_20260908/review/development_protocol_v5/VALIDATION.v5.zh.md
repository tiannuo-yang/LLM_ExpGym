# V5 静态数据叶链接修正

这是 v4 审计器的独立 sibling，保留 v4 的源码、76 项测试、原失败和 CPU 收据不动。实际 GLM 审计首次仅进入 preflight，因静态验收数据的 HF snapshot 叶级 symlink 被通用证据规则拒绝而 exit 1；未创建预定输出、未进入 raw 盘点或 scorer。失败不是模型/数据质量结论。

只改两个生产文件：common.py 增加专用 Reader.dataset_file(ref)，audit.py 仅在已接受 static.data_binding 路由使用它，另输出 dataset_file_links 审计账。ref 必须是原 path/SHA/bytes 三字段；允许普通文件或单层叶链接，原/目标祖先和链接链一律拒绝。记录原 link 文本、lstat、最终普通 target、SHA/bytes；读前后及 unchanged() 再查。原 raw/result/general Reader.bind 和 inventory 的禁 symlink 规则未放宽。

记录的是本次读取时链接关系及其稳定性，不追认原模型运行期间的历史 inode/link 文本；原 static 的权威内容约束仍是文件 SHA/bytes。正式 formal planner 本来就把数据引用规范到 blob 普通路径，不属于这次修复范围，未修改 formal 相关模块。

实际 static79d52… 共 126 refs，27 个直接 HF 叶链接，0 祖先链接/链式链接；不需要扩大许可。定向测试只读取这些既定数据 refs，不读取实际模型输出；原 76 项测试单 Python 3.11 纯 CPU 复跑，原27 scorer route不再运行。输出 schema 仍 development-v4-independent-protocol-audit-v1；v5 是审计器实现版本，不是 source/science/protocol 变更。

此候选需 ROOT 独立接受后另给一次实际审计 GO；不能用当前 CPU 修正替代真实后验或最终分析冻结后的 fresh review。

首个86项CPU结果为84 pass、1 source skip、1新fixture fail，原件保留在 validation/cpu_v1。失败fixture要求识别完全同文本的unlink/recreate，但当前文件系统能复用inode/时间戳，原观察字段完全相同时无法区分历史删除重建。仅fixture改为同canonicaltarget、不同可观测link文本 './blob'，生产不改；单项补跑单独封存。不能宣称全面检测所有历史瞬态unlink；本工具核观察到的路径/内容/元数据与前后稳定性。
