"""Pure CPU regressions; optional sealed original-source fixtures are read only.

Set DEV_INDEPENDENT_SEALED_ROOT to the already frozen cpu_v4/tmp directory to
re-score its completed real_flow mock-wire fixtures (never dispatch a runner).
"""
import copy
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace
import unittest
from unittest import mock


MODULE_PATH = Path(__file__).with_name("score_context_child.py")
SPEC = importlib.util.spec_from_file_location("development_independent_score_child_tested", MODULE_PATH)
m = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = m
SPEC.loader.exec_module(m)


class PureTests(unittest.TestCase):
    def setUp(self):
        self.runtime = {"executable": "/selected/python", "version": "3.11.9 (test)", "prefix": "/selected",
                        "base_prefix": "/base", "machine": "x86_64"}
        self.job = {"dump_dir": "/synthetic/raw"}
        self.messages = [{"role": "system", "content": "system"}, {"role": "user", "content": "task"}]
        self.rid = "1" * 32
        self.schemas = [{"type": "function", "function": {"name": "tool", "parameters": {"type": "object"}}}]
        self.context = {"runner": "poolact", "agent_id": 0}
        self.loop = SimpleNamespace(_trim_messages=lambda messages, budget: messages, _estimate_tokens=lambda messages: 5)
        self.agent = {"messages": self.messages + [{"role": "assistant", "content": "Answer: zero"}],
                      "usage_attempts": [{"attempts": [{"request_id": self.rid}]}]}
        self.raw = {"request_payload": {"messages": self.messages, "tools": self.schemas, "tool_choice": "auto"},
                    "context": self.context}

    def pool(self, raw=None, agent=None, cap=1000):
        with mock.patch.object(m, "read", return_value=self.raw if raw is None else raw):
            return m.pool_inputs(self.agent if agent is None else agent, self.job, self.context, self.schemas, cap, self.loop, lambda value: value)

    def exp(self, raw=None, messages=None, calls=None):
        trace = {"llm_calls": calls if calls is not None else [{"id": "c1", "attempt_usage": [{"request_id": self.rid}]}]}
        trace_module = SimpleNamespace(materialize_llm_input=lambda trace, call: self.messages if messages is None else messages)
        with mock.patch.object(m, "read", return_value=self.raw if raw is None else raw):
            return m.exp_inputs(trace, self.job, self.context, "system", "task", self.schemas, trace_module, lambda value: value)

    def test_runtime_compares_only_exact_original_five_fields(self):
        self.assertTrue(m.runtime_check({"runtime": self.runtime}, ["/selected/python"], self.runtime))
        extended = dict(self.runtime, executable_sha256="a" * 64)
        self.assertFalse(m.runtime_check({"runtime": extended}, ["/selected/python"], self.runtime))

    def test_runtime_wrong_actual_version_or_executable_fails(self):
        self.assertFalse(m.runtime_check({"runtime": self.runtime}, ["/other/python"], self.runtime))
        old = dict(self.runtime, version="3.7.17")
        self.assertFalse(m.runtime_check({"runtime": old}, ["/selected/python"], old))

    def test_duplicate_and_missing_trace_paths_fail(self):
        with self.assertRaisesRegex(ValueError, "Trace set differs"):
            m.expected_paths(["/a", "/a"], ["/a", "/b"])
        with mock.patch.object(Path, "is_file", return_value=False):
            with self.assertRaisesRegex(ValueError, "Missing original"):
                m.expected_paths(["/a"], ["/a"])

    def test_reordered_exact_trace_set_has_canonical_agent_order(self):
        with mock.patch.object(Path, "is_file", return_value=True):
            self.assertEqual(m.expected_paths(["/b", "/a"], ["/a", "/b"]), [Path("/a"), Path("/b")])

    def test_request_path_traversal_and_absent_id_rejected_before_read(self):
        for rid in (None, "../escape", "abc", "G" * 32, "/" + "1" * 32):
            with mock.patch.object(m, "read") as reader:
                with self.assertRaisesRegex(ValueError, "request_id"):
                    m.request_record(self.job, {"request_id": rid})
                reader.assert_not_called()

    def test_pool_exact_source_prefix_and_schema_pass(self):
        result = self.pool()
        self.assertTrue(result["passed"])
        self.assertEqual(result["request_ids"], [self.rid])
        self.assertEqual(result["trimmed_generations_observed"], 0)

    def test_pool_schema_context_and_message_mutations_fail(self):
        for target in ("schema", "context", "messages"):
            raw = copy.deepcopy(self.raw)
            if target == "schema":
                raw["request_payload"]["tools"][0]["function"]["name"] = "other"
            elif target == "context":
                raw["context"]["agent_id"] = 3
            else:
                raw["request_payload"]["messages"][1]["content"] = "other task"
            self.assertFalse(self.pool(raw=raw)["passed"])

    def test_pool_trim_is_schema_aware_and_exact_wire_checked(self):
        observed = []
        self.loop._trim_messages = lambda messages, cap: observed.append(cap) or [messages[0]]
        raw = copy.deepcopy(self.raw)
        raw["request_payload"]["messages"] = self.messages[:1]
        result = self.pool(raw=raw, cap=100)
        self.assertTrue(result["passed"])
        self.assertEqual(observed, [100 - len(json.dumps(self.schemas, ensure_ascii=False, allow_nan=False)) // 3])
        self.assertEqual(result["trimmed_generations_observed"], 1)

    def test_pool_cap_overflow_fails(self):
        self.assertFalse(self.pool(cap=1)["passed"])

    def test_pool_empty_or_unmatched_ledger_fails_without_imputation(self):
        for agent in ({"messages": [], "usage_attempts": []}, dict(self.agent, usage_attempts=[]),
                      dict(self.agent, usage_attempts=[{"attempts": []}])):
            with self.assertRaises(ValueError):
                self.pool(agent=agent)

    def test_pool_duplicate_attempt_request_id_fails(self):
        agent = copy.deepcopy(self.agent)
        agent["usage_attempts"][0]["attempts"] *= 2
        self.assertFalse(self.pool(agent=agent)["passed"])

    def test_pool_unpaired_native_tool_input_fails(self):
        agent = copy.deepcopy(self.agent)
        agent["messages"].insert(2, {"role": "tool", "tool_call_id": "orphan", "content": "observation"})
        raw = copy.deepcopy(self.raw)
        raw["request_payload"]["messages"] = agent["messages"][:-1]
        self.assertFalse(self.pool(raw=raw, agent=agent)["passed"])

    def test_exp_exact_original_materialized_input_passes(self):
        self.assertTrue(self.exp()["passed"])

    def test_exp_edited_task_context_fails_even_when_raw_matches_edit(self):
        messages = copy.deepcopy(self.messages)
        messages[1]["content"] = "edited task"
        raw = copy.deepcopy(self.raw)
        raw["request_payload"]["messages"] = messages
        self.assertFalse(self.exp(raw=raw, messages=messages)["passed"])

    def test_exp_unpaired_or_repeated_system_history_fails(self):
        for extra in ({"role": "system", "content": "extra"}, {"role": "tool", "tool_call_id": "orphan", "content": "data"}):
            messages = self.messages + [extra]
            raw = copy.deepcopy(self.raw)
            raw["request_payload"]["messages"] = messages
            self.assertFalse(self.exp(raw=raw, messages=messages)["passed"])

    def test_exp_missing_and_duplicate_attempts_fail(self):
        for calls in ([], [{"id": "c1", "attempt_usage": []}]):
            with self.assertRaises(ValueError):
                self.exp(calls=calls)
        self.assertFalse(self.exp(calls=[{"id": "c1", "attempt_usage": [{"request_id": self.rid}] * 2}])["passed"])

    @unittest.skipUnless(sys.version_info[:2] == (3, 11), "development scorer offline guard is actual native Python 3.11 only")
    def test_offline_guard_blocks_network_subprocess_and_write(self):
        blocked = []
        with m.offline_guard(blocked):
            with self.assertRaisesRegex(RuntimeError, "NETWORK"):
                m.socket.getaddrinfo("never-contact.invalid", 80)
            with self.assertRaisesRegex(RuntimeError, "PROCESS"):
                subprocess.Popen(["never-execute"])
            with self.assertRaisesRegex(RuntimeError, "FILESYSTEM_WRITE"):
                Path("/this-file-must-never-be-created-dev-audit").write_text("forbidden")
        self.assertEqual(blocked, ["network", "process", "filesystem_write"])

    def test_malformed_spec_produces_explicit_failed_receipt(self):
        result = m.check({})
        self.assertFalse(result["passed"])
        self.assertFalse(result["score_checks_complete"])
        self.assertIsNone(result["original_score_receipt"])
        self.assertEqual(result["trace_rows"], [])
        self.assertFalse(result["server_rendered_tokens_verified"])

    def test_source_module_wrong_origin_rejected(self):
        with mock.patch.object(m.importlib, "import_module", return_value=SimpleNamespace(__file__="/other/expgym/tool_protocol.py")):
            with self.assertRaisesRegex(ValueError, "Wrong exact source module"):
                m.source_module(Path("/selected"), "expgym.tool_protocol")


@unittest.skipUnless(os.environ.get("DEV_INDEPENDENT_SEALED_ROOT"), "explicit existing sealed cpu_v4/tmp path required")
class SealedSourceTests(unittest.TestCase):
    def test_all_completed_sealed_real_flow_source_routes_read_only(self):
        root = Path(os.environ["DEV_INDEPENDENT_SEALED_ROOT"]).resolve()
        receipts = sorted(root.glob("development_v4_real_flow_cpu_*/*/not_created_run/journal/*/final_status.json"))
        self.assertTrue(receipts, "No sealed mock-wire original-source fixtures found")
        coverage = set()
        samples, bindings = [], {}
        def bind(path):
            path = Path(path).absolute()
            record = {"path": str(path), "sha256": m.sha(path), "bytes": path.stat().st_size,
                      "mtime_ns": path.stat().st_mtime_ns}
            if str(path) in bindings:
                self.assertEqual(bindings[str(path)], record, "Previously bound fixture changed")
            bindings[str(path)] = record
            return record
        for path in (MODULE_PATH, Path(__file__), root.parent / "receipt.json", root.parent / "file_table.json"):
            bind(path)
        for receipt_path in receipts:
            final = m.read(receipt_path)
            if final.get("passed") is not True:
                continue
            run_root = receipt_path.parents[2]
            plan = m.read(run_root / "manifest.json")
            job = next(row for row in plan["jobs"] if row["id"] == final["job_id"])
            cell = (job["model"], job["system"], job["scenario"], job["question_index"], job["strategy"])
            if cell in coverage:
                continue
            coverage.add(cell)
            output = Path(job["output_dir"])
            traces = list((output / job["strategy"] / "agents").glob("agent_*.json")) if job["system"] == "poolact" else list(output.glob("*/traces-v2/*.json"))
            before = {str(path): (m.sha(path), path.stat().st_mtime_ns) for path in list(output.rglob("*.json")) + list(Path(job["dump_dir"]).rglob("*.json"))}
            env = dict(os.environ)
            for key in list(env):
                if key.upper().endswith(("API_KEY", "API_TOKEN")) or key.upper() in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY"):
                    env.pop(key, None)
            env.update(EXPGYM_RUN_ID="development-v4:" + run_root.name, EXPGYM_API_DUMP_DIR="",
                       PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1", NO_PROXY="*", no_proxy="*",
                       OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1")
            specification = {"plan": plan, "job": job, "preflight": final["identity"]["receipt"], "trace_paths": [str(path) for path in traces]}
            original_refs = [bind(path) for path in [run_root / "manifest.json", receipt_path, Path(job["command"][0]),
                             Path(plan["config"]["helper_dir"]) / "pilot_timing.py"] + [Path(path) for path in before]]
            completed = subprocess.run([job["command"][0], "-B", str(MODULE_PATH)], input=json.dumps(specification),
                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env, cwd=plan["config"]["repo_root"], timeout=90)
            lines = [line[len(m.PREFIX):] for line in completed.stdout.splitlines() if line.startswith(m.PREFIX)]
            with self.subTest(cell=cell):
                self.assertEqual(len(lines), 1, completed.stderr[-1200:])
                result = json.loads(lines[0])
                samples.append({"cell": list(cell), "job_id": job["id"], "original_refs": original_refs,
                                "child_exit_code": completed.returncode, "child_receipt": result,
                                "all_fixture_assertions_passed": False,
                                "child_receipt_sha256": m.hashlib.sha256(lines[0].encode()).hexdigest()})
                self.assertTrue(result["passed"], result["errors"])
                self.assertEqual(completed.returncode, 0)
                self.assertEqual(result["model_or_network_attempts"], 0)
                self.assertEqual(result["blocked_actions"], [])
                self.assertEqual(len(result["trace_rows"]), job["expected_traces"])
                self.assertEqual(len(result["request_ids"]), 2 * job["expected_traces"])
                after = {str(path): (m.sha(path), path.stat().st_mtime_ns) for path in list(output.rglob("*.json")) + list(Path(job["dump_dir"]).rglob("*.json"))}
                self.assertEqual(before, after)
                for path in before:
                    bind(path)
                samples[-1]["all_fixture_assertions_passed"] = True
        receipt = {"schema_version": "development-v4-independent-score-context-cpu-tests-v1",
                   "evidence_kind": "sealed CPU synthetic source/model-wire fixtures only",
                   "passed": len(samples) == 27 and all(row["child_receipt"]["passed"] is True
                       and row["all_fixture_assertions_passed"] is True for row in samples),
                   "source_routes": len(samples), "real_model_calls": 0,
                   "samples": samples, "bindings": [bindings[path] for path in sorted(bindings)],
                   "scope": "Same-runtime original scorer/source-context recheck; no runner main/resume/generation, no live-ready or real-development acceptance."}
        print("DEV_INDEPENDENT_SEALED_TEST_JSON=" + json.dumps(receipt, sort_keys=True, allow_nan=False), flush=True)
        self.assertEqual(sum(cell[1] == "expgym" for cell in coverage), 3)
        self.assertEqual(sum(cell[1] == "poolact" for cell in coverage), 24)


if __name__ == "__main__":
    unittest.main(verbosity=2)
