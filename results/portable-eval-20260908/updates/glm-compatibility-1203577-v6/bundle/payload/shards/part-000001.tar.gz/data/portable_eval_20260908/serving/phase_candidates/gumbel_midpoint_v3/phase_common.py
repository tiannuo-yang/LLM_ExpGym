"""Small lifecycle helpers; this is not formal-study or model-call authority."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import stat
from datetime import datetime, timezone

BASE = Path(__file__).resolve().parent
STUDY = BASE.parents[2]
RUNTIME = STUDY / "serving/runtime_candidates/gumbel_midpoint_v1"
VENV = RUNTIME / ".venv"
IMAGE = Path("/lustrefs/users/chufan.shi/codex_space/Tau_vision/.images/sglang_k3_cu12.sqsh")
GPU_SCRIPT = STUDY / "patches/seeded_sampler_open_interval_v1/gpu_validation_v2/gpu_numerical.py"
GPU_SCRIPT_SHA = "86794617f45eda99d9d2b7238d8ede69c1d202648a4bb6a4fb67c99b8a3b3a8e"
OLD_SERVING = STUDY / "serving"
OLD_PYTHON = STUDY.parent / "kimi_k3_eval/serving/independent/python/cpython-3.12.13-linux-x86_64-gnu"
PHASES = (("glm_compatibility", "glm-5.3"), ("k3_formal", "kimi-k3"), ("glm_formal", "glm-5.3"))


def utc():
    return datetime.now(timezone.utc).isoformat()


def read_regular(path):
    fd = os.open(str(path), os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            raise ValueError("expected single-link regular evidence file")
        with os.fdopen(fd, "rb", closefd=False) as handle:
            return handle.read()
    finally:
        os.close(fd)


def digest(path):
    return hashlib.sha256(read_regular(path)).hexdigest()


def write_new(path, obj):
    with Path(path).open("x") as handle:
        json.dump(obj, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())


def source_identity():
    from profile_contract import SOURCE_FILES
    return {name: digest(BASE / name) for name in SOURCE_FILES}


def verify_pins(pins):
    if not isinstance(pins, dict) or not pins:
        raise ValueError("missing external source pins")
    if source_identity() != pins:
        raise ValueError("phase sources changed")
    if digest(GPU_SCRIPT) != GPU_SCRIPT_SHA:
        raise ValueError("GPU numerical script changed")


def check_environment():
    alias = BASE / "environments/k3_glm/.venv"
    if alias.resolve(strict=True) != VENV.resolve(strict=True):
        raise ValueError("runtime alias mismatch")
    config = (VENV / "pyvenv.cfg").read_text()
    if "include-system-site-packages = false" not in config:
        raise ValueError("environment is not independent")
    sampler = VENV / "lib/python3.12/site-packages/sglang/srt/layers/sampler.py"
    if digest(sampler) != "4f8ce718c6bfedb3271900b3066f77ef2ba2d94551ef63bd3dba0f53b1c450e7":
        raise ValueError("candidate sampler mismatch")


def command_valid(command, *, job_id, sequence, active, next_phase, gpu_passed):
    if set(command) != {"job_id", "sequence", "action", "phase", "root_reference", "root_reference_sha256"}:
        raise ValueError("unknown/missing lifecycle command field")
    if command["job_id"] != job_id or type(command["sequence"]) is not int or command["sequence"] != sequence:
        raise ValueError("lifecycle job/sequence mismatch")
    action = command["action"]
    if action not in ("load", "stop", "finish"):
        raise ValueError("unknown lifecycle action")
    if action == "load":
        if active or not gpu_passed or next_phase >= len(PHASES) or command["phase"] != PHASES[next_phase][0]:
            raise ValueError("load is not eligible")
    elif command["phase"] is not None or (action == "stop" and not active):
        raise ValueError("invalid stop/finish state")
    ref = Path(command["root_reference"])
    if not ref.is_absolute() or digest(ref) != command["root_reference_sha256"]:
        raise ValueError("ROOT operator reference bytes mismatch")
    # A pinned reference is attribution, NOT a cryptographic authorization or
    # scientific GO. Operator review remains external; no generation is here.
    return action
