"""Pure synthetic boundary checks: never invokes run(), srun, or checkpoint I/O."""
import copy
import stat
from types import SimpleNamespace
import unittest

import prefetch


def baseline():
    return {'meminfo_kib': {'MemAvailable': (1 << 40) // 1024},
            'cgroup': {k: {'current': 0, 'max': 512 << 30,
                          'events': dict(high=0, max=0, oom=0, oom_kill=0)} for k in ('job', 'step')},
            'pressure': {'memory': 'some avg10=0.00 avg60=0.00 avg300=0.00 total=5\nfull avg10=0.00 avg60=0.00 avg300=0.00 total=2\n'}}


class Tests(unittest.TestCase):
    def test_exact_thresholds_allowed(self):
        point = baseline()
        self.assertIsNone(prefetch.guard(point, copy.deepcopy(point)))

    def test_available_memory(self):
        point = baseline()
        old = copy.deepcopy(point)
        point['meminfo_kib']['MemAvailable'] -= 1
        self.assertEqual(prefetch.guard(point, old), 'mem_available_below_1tib')

    def test_job_margin_and_unknown(self):
        for maximum, current in [(None, 0), (512 << 30, 1)]:
            point = baseline()
            old = copy.deepcopy(point)
            point['cgroup']['job'].update(max=maximum, current=current)
            self.assertEqual(prefetch.guard(point, old), 'job_headroom_unknown_or_below_512gib')

    def test_every_event_and_both_groups(self):
        for group in ('job', 'step'):
            for event in ('high', 'max', 'oom', 'oom_kill'):
                point = baseline()
                old = copy.deepcopy(point)
                point['cgroup'][group]['events'][event] += 1
                self.assertEqual(prefetch.guard(point, old), 'memory_event_changed_' + group + '_' + event)

    def test_memory_psi_nonzero_or_unknown(self):
        for text in ('some avg10=0.01\nfull avg10=0.00\n', 'some avg10=0.00\n', ''):
            point = baseline()
            old = copy.deepcopy(point)
            point['pressure']['memory'] = text
            self.assertEqual(prefetch.guard(point, old), 'memory_pressure_nonzero_or_unknown')

    def test_file_identity_regular_size_mtime(self):
        row = {'bytes': 32, 'mtime_ns': 42}
        prefetch.same_file(SimpleNamespace(st_mode=stat.S_IFREG, st_size=32, st_mtime_ns=42), row)
        for mode, size, mtime in [(stat.S_IFLNK, 32, 42), (stat.S_IFIFO, 32, 42), (stat.S_IFREG, 31, 42), (stat.S_IFREG, 32, 41)]:
            with self.assertRaises(ValueError):
                prefetch.same_file(SimpleNamespace(st_mode=mode, st_size=size, st_mtime_ns=mtime), row)


if __name__ == '__main__':
    unittest.main()
