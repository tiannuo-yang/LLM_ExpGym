#!/usr/bin/env python3
"""Allocation-only, fail-closed 8 x H200 gate; import and injected tests are CPU-only.

Call ``check_hardware(receipt_path)`` immediately before serving. No environment,
arbitrary subprocess diagnostics, credentials, or model inputs enter the receipt.
"""
from __future__ import annotations

import csv
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import sys

NVIDIA_COMMAND = (
    "nvidia-smi", "--query-gpu=index,name,uuid,memory.total,driver_version",
    "--format=csv,noheader,nounits",
)
EXPECTED_DEVICES = 8
UUID_PATTERN = re.compile(r"(?:GPU-)?([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})\Z")
NAME_PATTERN = re.compile(r"[A-Za-z0-9][A-Za-z0-9 ()_.+-]{0,95}\Z")
H200_PATTERN = re.compile(r"NVIDIA H200(?: [A-Za-z0-9_.+-]+)*\Z")
VERSION_PATTERN = re.compile(r"[0-9]+(?:\.[0-9]+){1,3}(?:\+[A-Za-z0-9.]+)?\Z")


class HardwarePreflightError(RuntimeError):
    """Hardware was not accepted; an on-disk receipt is retained when writable."""


def _positive_integer(value):
    if isinstance(value, bool):
        raise ValueError("invalid positive integer")
    number = int(value)
    if number <= 0 or str(number) != str(value):
        raise ValueError("invalid positive integer")
    return number


def _uuid(value):
    if not isinstance(value, str) or not (match := UUID_PATTERN.fullmatch(value)):
        raise ValueError("invalid GPU UUID")
    return "GPU-" + match[1].lower()


def _name(value):
    if not isinstance(value, str) or not NAME_PATTERN.fullmatch(value):
        raise ValueError("invalid GPU name")
    return value


def _version(value):
    if not isinstance(value, str) or not VERSION_PATTERN.fullmatch(value):
        raise ValueError("invalid version")
    return value


def _nvidia_records(stdout):
    if not isinstance(stdout, str) or len(stdout) > 32768:
        raise ValueError("invalid NVIDIA output size")
    records = []
    for fields in csv.reader(io.StringIO(stdout), strict=True):
        if len(fields) != 5:
            raise ValueError("invalid NVIDIA field count")
        index, name, uuid, memory, driver = (value.strip() for value in fields)
        if not index.isascii() or not index.isdecimal():
            raise ValueError("invalid NVIDIA index")
        records.append({"index": int(index), "name": _name(name), "uuid": _uuid(uuid),
                        "memory_total_mib": _positive_integer(memory),
                        "driver_version": _version(driver)})
    return records


def _torch_records(result):
    # Copy only explicit allowlisted fields, never a caller's entire dictionary.
    if not isinstance(result, dict) or type(result.get("cuda_available")) is not bool:
        raise ValueError("invalid CUDA availability")
    count = result.get("device_count")
    if type(count) is not int or not 0 <= count <= 128:
        raise ValueError("invalid CUDA count")
    devices = result.get("devices")
    if not isinstance(devices, list) or len(devices) > 128:
        raise ValueError("invalid CUDA devices")
    record = {"cuda_available": result["cuda_available"], "device_count": count,
              "torch_version": _version(result["torch_version"]),
              "cuda_build_version": _version(result["cuda_build_version"]),
              "devices": []}
    for key in ("cuda_runtime_version", "cuda_driver_api_version"):
        value = result.get(key)
        record[key] = None if value is None else _positive_integer(value)
    for device in devices:
        index = device["index"]
        if type(index) is not int or not 0 <= index < 128:
            raise ValueError("invalid CUDA device index")
        record["devices"].append({"index": index, "name": _name(device["name"]),
                                   "uuid": _uuid(device["uuid"]),
                                   "memory_total_bytes": _positive_integer(device["memory_total_bytes"])})
    return record


def _local_torch_probe():
    """Runs only in the bounded child process inside the future allocation."""
    import ctypes
    import torch

    available = bool(torch.cuda.is_available())
    count = torch.cuda.device_count()
    result = {"torch_version": str(torch.__version__), "cuda_build_version": torch.version.cuda,
              "cuda_available": available, "device_count": count, "devices": [],
              "cuda_runtime_version": None, "cuda_driver_api_version": None}
    if available:
        for index in range(count):
            props = torch.cuda.get_device_properties(index)
            result["devices"].append({"index": index, "name": props.name, "uuid": str(props.uuid),
                                      "memory_total_bytes": props.total_memory})
        # These are the loaded runtime and driver's CUDA API versions, not the
        # CUDA compatibility label from the nvidia-smi human-readable banner.
        major = str(torch.version.cuda).split(".")[0]
        if not major.isascii() or not major.isdecimal():
            raise ValueError("invalid CUDA runtime major version")
        for library, function, key in (
            (f"libcudart.so.{major}", "cudaRuntimeGetVersion", "cuda_runtime_version"),
            ("libcuda.so.1", "cuDriverGetVersion", "cuda_driver_api_version"),
        ):
            getter = getattr(ctypes.CDLL(library), function)
            getter.argtypes = [ctypes.POINTER(ctypes.c_int)]
            getter.restype = ctypes.c_int
            version = ctypes.c_int()
            if getter(ctypes.byref(version)) != 0:
                raise RuntimeError("CUDA version query failed")
            result[key] = version.value
    return result


def _bounded_torch_probe():
    command = [sys.executable, str(Path(__file__).resolve()), "--torch-probe"]
    result = subprocess.run(command, capture_output=True, text=True, timeout=60, check=False)
    if result.returncode != 0 or len(result.stdout) > 65536:
        # Child stdout/stderr can contain library diagnostics. Never copy them.
        raise RuntimeError("torch hardware subprocess failed")
    return json.loads(result.stdout)


def check_hardware(receipt_path, *, nvidia_runner=None, torch_probe=None):
    """Return accepted receipt, otherwise raise; production probes require GPUs.

    Dependencies are injectable for CPU tests. Receipt is exclusively created;
    an existing receipt is never overwritten or reused as hardware acceptance.
    A pre-probe ``passed: false`` receipt is flushed before hardware is queried.
    """
    nvidia_runner = nvidia_runner or subprocess.run
    torch_probe = torch_probe or _bounded_torch_probe
    receipt_path = Path(receipt_path)
    report = {"schema_version": 1, "created_utc": datetime.now(timezone.utc).isoformat(),
              "node": socket.gethostname(), "passed": False, "state": "started",
              "expected_gpu_count": EXPECTED_DEVICES, "expected_gpu_family": "NVIDIA H200",
              "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "nvidia_smi": {"command": list(NVIDIA_COMMAND), "timeout_seconds": 30},
              "torch": {"timeout_seconds": 60}, "errors": [],
              "scope": "Local node physical inventory plus actual CUDA-visible devices; no model inference"}

    def persist(handle):
        handle.seek(0)
        json.dump(report, handle, indent=2)
        handle.write("\n")
        handle.truncate()
        handle.flush()
        os.fsync(handle.fileno())

    with receipt_path.open("x", encoding="utf-8") as handle:
        persist(handle)
        try:
            report["state"] = "probing_nvidia_smi"
            persist(handle)
            try:
                query = nvidia_runner(list(NVIDIA_COMMAND), capture_output=True, text=True,
                                      timeout=30, check=False)
                report["nvidia_smi"]["exit_code"] = query.returncode
                if query.returncode != 0:
                    raise RuntimeError("NVIDIA query failed")
                report["nvidia_smi"]["gpus"] = _nvidia_records(query.stdout)
            except Exception as error:
                report["errors"].append("nvidia_probe:" + type(error).__name__)
            report["state"] = "probing_torch"
            persist(handle)
            try:
                report["torch"].update(_torch_records(torch_probe()))
            except Exception as error:
                report["errors"].append("torch_probe:" + type(error).__name__)
            physical = report["nvidia_smi"].get("gpus", [])
            visible = report["torch"].get("devices", [])
            checks = {
                "nvidia_exactly_eight": len(physical) == EXPECTED_DEVICES,
                "nvidia_unique_uuids": len({g["uuid"] for g in physical}) == EXPECTED_DEVICES,
                "nvidia_unique_indices": len({g["index"] for g in physical}) == EXPECTED_DEVICES,
                "nvidia_all_h200": bool(physical) and all(H200_PATTERN.fullmatch(g["name"]) is not None for g in physical),
                "nvidia_consistent_driver": len({g["driver_version"] for g in physical}) == 1,
                "torch_cuda_available": report["torch"].get("cuda_available") is True,
                "torch_exactly_eight": report["torch"].get("device_count") == EXPECTED_DEVICES and len(visible) == EXPECTED_DEVICES,
                "torch_unique_uuids": len({g["uuid"] for g in visible}) == EXPECTED_DEVICES,
                "torch_indices_zero_to_seven": {g["index"] for g in visible} == set(range(EXPECTED_DEVICES)),
                "torch_all_h200": bool(visible) and all(H200_PATTERN.fullmatch(g["name"]) is not None for g in visible),
                "visible_matches_physical_uuids": bool(visible) and {g["uuid"] for g in visible} == {g["uuid"] for g in physical},
                "cuda_runtime_reported": report["torch"].get("cuda_runtime_version") is not None,
                "cuda_driver_api_reported": report["torch"].get("cuda_driver_api_version") is not None,
            }
            report["checks"] = checks
            report["errors"].extend(name for name, passed in checks.items() if not passed)
            report["passed"] = not report["errors"]
            report["state"] = "accepted" if report["passed"] else "rejected"
        except BaseException as error:
            report["passed"] = False
            report["state"] = "interrupted"
            report["errors"].append("interrupted:" + type(error).__name__)
            raise
        finally:
            report["finished_utc"] = datetime.now(timezone.utc).isoformat()
            persist(handle)
    if not report["passed"]:
        raise HardwarePreflightError(f"Hardware rejected; inspect receipt {receipt_path}")
    return report


if __name__ == "__main__":
    if sys.argv[1:] != ["--torch-probe"]:
        raise SystemExit("Internal allocation-only probe; import check_hardware from serve_node")
    try:
        print(json.dumps(_local_torch_probe()))
    except BaseException:
        # Suppress arbitrary import/library diagnostic tracebacks in stdout.
        raise SystemExit(2)
