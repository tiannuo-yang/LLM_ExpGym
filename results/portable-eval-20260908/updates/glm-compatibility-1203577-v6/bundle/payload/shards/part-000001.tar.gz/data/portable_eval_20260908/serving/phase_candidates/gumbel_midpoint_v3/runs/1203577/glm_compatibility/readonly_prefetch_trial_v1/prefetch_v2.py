"""One externally authorized, bounded sequential read; never a model/ready gate.

No payload is retained, printed, or hashed. A blocking read cannot be given a
hard deadline here. This helper does not authorize its own execution.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import time
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
PHASE = HERE.parent
CHECKPOINT = Path('/lustrefs/users/runner/chufan.shi/tau_vision/ckpts/GLM-5.3')
STRUCTURAL = PHASE / 'checkpoint_structural.json'
STRUCTURAL_SHA = '1beee786d41f080e9e5c400d06e159f5ec7de2628359a93c2f6108042e84a05b'
PID, STARTTIME = 305225, 818339552
LIMIT, BUFFER, SECONDS = 64 << 30, 16 << 20, 180
CGROUP = Path('/sys/fs/cgroup/system.slice/slurmstepd.scope/job_1203577')


def utc():
    return datetime.now(timezone.utc).isoformat()


def counters(path):
    return {k: int(v) for k, v in (s.split() for s in path.read_text().splitlines())}


def snapshot():
    p = Path('/proc') / str(PID)
    status = dict(s.split(':', 1) for s in (p / 'status').read_text().splitlines() if ':' in s)
    raw = (p / 'stat').read_text()
    v = raw[raw.rfind(')') + 2:].split()
    ps = {'state': v[0], 'minflt': int(v[7]), 'majflt': int(v[9]),
          'utime_ticks': int(v[11]), 'stime_ticks': int(v[12]), 'starttime_ticks': int(v[19])}
    cg = (p / 'cgroup').read_text().splitlines()
    identity = {'pid': PID, 'ppid': int(status['PPid']), 'uids': list(map(int, status['Uid'].split())),
                'comm': (p / 'comm').read_text().strip(), 'cgroup': cg, 'stat': ps}
    if (identity['ppid'] != 302851 or identity['uids'] != [1071] * 4
            or identity['comm'] != 'sglang::schedul' or ps['starttime_ticks'] != STARTTIME
            or not any(re.fullmatch(r'0::/system.slice/slurmstepd.scope/job_1203577/step_18(?:/.*)?', s) for s in cg)):
        raise ValueError('scheduler_identity_changed')
    wanted = {'MemTotal', 'MemAvailable', 'Cached', 'SwapTotal', 'SwapFree', 'AnonPages', 'Mapped', 'Dirty', 'Writeback'}
    mem = {k: int(value.split()[0]) for k, value in (s.split(':', 1) for s in Path('/proc/meminfo').read_text().splitlines()) if k in wanted}
    groups = {}
    for kind, path in [('job', CGROUP), ('step', CGROUP / 'step_18')]:
        maximum = (path / 'memory.max').read_text().strip()
        groups[kind] = {'current': int((path / 'memory.current').read_text()),
                        'max': None if maximum == 'max' else int(maximum),
                        'events': counters(path / 'memory.events')}
    return {'utc': utc(), 'identity': identity, 'meminfo_kib': mem, 'cgroup': groups,
            'io': {k: int(v) for k, v in (s.split(':', 1) for s in (p / 'io').read_text().splitlines())},
            'pressure': {k: Path('/proc/pressure', k).read_text() for k in ('memory', 'io')}}


def guard(current, baseline):
    if current['meminfo_kib']['MemAvailable'] * 1024 < 1 << 40:
        return 'mem_available_below_1tib'
    job = current['cgroup']['job']
    if job['max'] is None or job['max'] - job['current'] < 512 << 30:
        return 'job_headroom_unknown_or_below_512gib'
    for kind in ('job', 'step'):
        for name in ('high', 'max', 'oom', 'oom_kill'):
            if current['cgroup'][kind]['events'][name] != baseline['cgroup'][kind]['events'][name]:
                return 'memory_event_changed_' + kind + '_' + name
    lines = current['pressure']['memory'].splitlines()
    values = {s.split()[0]: float(dict(x.split('=') for x in s.split()[1:])['avg10']) for s in lines}
    if set(values) != {'some', 'full'} or any(v != 0 for v in values.values()):
        return 'memory_pressure_nonzero_or_unknown'
    return None


def loading_finished():
    ready = 0
    for replica in range(4):
        for rank in range(2):
            text = (PHASE / ('replica%d-rank%d.log' % (replica, rank))).read_text(errors='replace')
            if 'Load weight end' in text:
                return True
            ready += rank == 0 and 'The server is fired up and ready to roll!' in text
    return ready == 4


def same_file(info, row):
    if not stat.S_ISREG(info.st_mode) or info.st_size != row['bytes'] or info.st_mtime_ns != row['mtime_ns']:
        raise ValueError('checkpoint_file_stat_changed')


def run():
    output = HERE / 'actual_v2'
    output.mkdir()
    started = time.monotonic()
    report = {'schema': 'bounded-readonly-prefetch-trial-v1', 'passed': False, 'started_utc': utc(),
              'job_id': '1203577', 'node': 'azure-uk-hpc-H200-instance-267', 'bytes_read': 0,
              'helper_pid': os.getpid(), 'helper_ppid': os.getppid(), 'helper_uid': os.getuid(),
              'observed_node': os.uname().nodename, 'observed_slurm_job_id': os.environ.get('SLURM_JOB_ID'),
              'files': [], 'boundary_snapshots': [], 'payload_hashed': False,
              'helper_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'structural_sha256': STRUCTURAL_SHA, 'limit_bytes': LIMIT, 'limit_seconds': SECONDS,
              'limitations': ['Blocking reads can exceed the nominal deadline.',
                              'Cached is not attributed entirely to this model.',
                              'This uncontrolled trial cannot establish causal loading speedup.']}
    failure = None
    try:
        if (report['observed_slurm_job_id'] != '1203577' or report['observed_node'] not in
                ('azure-uk-hpc-H200-instance-267', 'azure-uk-hpc-H200-instance-267.core42.ai')):
            raise ValueError('allocation_identity_mismatch')
        raw = STRUCTURAL.read_bytes()
        if hashlib.sha256(raw).hexdigest() != STRUCTURAL_SHA:
            raise ValueError('structural_bytes_changed')
        audit = json.loads(raw)
        rows = audit['shards']
        expected = ['model-%05d-of-00141.safetensors' % i for i in range(1, 142)]
        if audit['checkpoint'] != str(CHECKPOINT) or audit['ready_structurally'] is not True or [r['name'] for r in rows] != expected:
            raise ValueError('structural_manifest_not_fixed_141')
        for row in rows:
            same_file(os.stat(CHECKPOINT / row['name'], follow_symlinks=False), row)
        before = snapshot()
        report['before'] = before
        reason = guard(before, before)
        if loading_finished():
            reason = 'loading_finished_cancelled_before_read'
        buffer = bytearray(BUFFER)
        last_check = -1.0
        for row in rows:
            if reason:
                break
            fd = os.open(CHECKPOINT / row['name'], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
            progress = {'name': row['name'], 'bytes_read': 0}
            report['files'].append(progress)
            try:
                same_file(os.fstat(fd), row)
                while True:
                    elapsed = time.monotonic() - started
                    if report['bytes_read'] >= LIMIT or elapsed >= SECONDS:
                        reason = 'byte_limit' if report['bytes_read'] >= LIMIT else 'time_limit'
                        break
                    if elapsed - last_check >= 1:
                        point = snapshot()
                        report['boundary_snapshots'].append(point)
                        reason = guard(point, before)
                        if loading_finished():
                            reason = 'loading_finished_cancelled'
                        last_check = time.monotonic() - started
                        if reason:
                            break
                    count = os.readv(fd, [memoryview(buffer)[:min(BUFFER, LIMIT - report['bytes_read'])]])
                    report['bytes_read'] += count
                    progress['bytes_read'] += count
                    if count == 0:
                        break
                same_file(os.fstat(fd), row)
            finally:
                os.close(fd)
        report['stop_reason'] = reason or 'file_list_exhausted'
    except BaseException as exc:
        report['stop_reason'] = 'exception'
        report['error_type'] = type(exc).__name__
        failure = exc
    finally:
        try:
            report['after'] = snapshot()
        except Exception as exc:
            report['after_error_type'] = type(exc).__name__
        report['elapsed_seconds'] = time.monotonic() - started
        report['finished_utc'] = utc()
        with (output / 'receipt.json').open('x') as handle:
            json.dump(report, handle, indent=2, sort_keys=True, allow_nan=False)
            handle.write('\n')
            handle.flush()
            os.fsync(handle.fileno())
    if failure is not None:
        raise failure
    print(json.dumps({'receipt': str(output / 'receipt.json'), 'stop_reason': report['stop_reason'], 'bytes_read': report['bytes_read']}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--execute-once', action='store_true', required=True)
    parser.parse_args()
    run()
