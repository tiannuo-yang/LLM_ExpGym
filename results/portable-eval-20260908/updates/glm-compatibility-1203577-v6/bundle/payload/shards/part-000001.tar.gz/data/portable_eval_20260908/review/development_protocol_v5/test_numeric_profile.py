"""Numeric-representation regression; original frozen nonce wire is read only."""
import importlib.util
import copy
import json
from pathlib import Path
import unittest

from common import CANDIDATE, HERE, STUDY, Reader, sha
from raw_checks import audit_rows, moment
from test_audit import sample, run


def previous():
    spec = importlib.util.spec_from_file_location('dev_before_numeric_raw', HERE / 'correction/before_numeric_profile/raw_checks.py')
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module


class NumericProfileTests(unittest.TestCase):
    def test_int_float_numeric_equivalence_only_for_temperature_top_p(self):
        for field in ('temperature', 'top_p'):
            row = sample(); row['raw']['request_payload'][field] = 1
            self.assertTrue(run([row])['passed'])
        row = copy.deepcopy(sample()); row['raw']['request_payload']['chat_template_kwargs']['thinking'] = 1
        self.assertFalse(run([row])['passed'])

    def test_bool_nonfinite_wrong_number_and_string_rejected(self):
        for field in ('temperature', 'top_p'):
            for value in (True, float('nan'), float('inf'), -float('inf'), .5, '1'):
                row = sample(); row['raw']['request_payload'][field] = value
                self.assertFalse(run([row])['passed'], (field, value))

    def test_both_models_actual_sealed_nonce_wire_old_red_new_green(self):
        cases = [('glm-5.3', 'development_v4_real_flow_cpu_7ia7mqe7',
                  '7760b95e34034f2eabc48110925a4c7263160040db82f2847ef1d20b417eabf3',
                  '1e090971c89964b658cf12abc987e25e10bb52bd7dc9efdc1e8c126ac1a7583c'),
                 ('kimi-k3', 'development_v4_real_flow_cpu_ijtgsr_h',
                  '625a1a78d0d33845103ad9df20484f0a63c0789b497f7f4f42c9bc9297d5cc0e',
                  'e7af613955f65b7cac104d90e02458dd05b5677fd3804592040e302de7f3a837')]
        reader, results = Reader(), []
        cpu = reader.read(CANDIDATE / 'validation/cpu_v4/receipt.json',
                          'dde4744634aa66bbde590793062ee8dea4d13277253caa621c2245e01e66300e')
        all_pins = {row['path']: row for row in cpu['artifacts']}
        old = previous()
        for model, directory, fixture_sha, profile_sha in cases:
            fixture = reader.read(CANDIDATE / 'validation/cpu_v4/tmp' / directory / 'protocol_fixture_receipt.json', fixture_sha)
            profile = reader.read(STUDY / 'profiles/development_declared_v1' / (model + '.json'), profile_sha)
            self.assertEqual(fixture['mode'], 'valid')
            records = []
            for ref in fixture['reported']['inventory']['files']:
                if ref['kind'] == 'dump_dir':
                    pin = all_pins[ref['path']]
                    raw = reader.read(ref['path'], pin['sha256'])
                    records.append({'path': ref['path'], 'scope': 'protocol', 'raw': raw})
            self.assertEqual(len(records), 12)
            self.assertTrue(all(type(row['raw']['request_payload']['temperature']) is int for row in records))
            endpoint_map = {row['raw']['context']['development_replica']: row['raw']['endpoint'] for row in records}
            endpoints = {'protocol': [endpoint_map[i] for i in range(4)]}
            begin = min(moment(row['raw']['started_at_utc']) for row in records) - 1
            end = max(moment(row['raw']['finished_at_utc']) for row in records) + 1
            arguments = (records, profile, records[0]['raw']['run_id'], endpoints, end, begin)
            before, after = old.audit_rows(*arguments), audit_rows(*arguments)
            self.assertFalse(before['passed'])
            self.assertTrue(all('profile differs' in error for error in before['errors']), before['errors'])
            self.assertTrue(after['passed'], after['errors'])
            self.assertEqual(before['all_attempt_usage'], after['all_attempt_usage'])
            results.append({'model': model, 'retained_raw_count': len(records), 'before_passed': before['passed'],
                'after_passed': after['passed'], 'before_errors': before['errors'], 'all_attempt_usage': after['all_attempt_usage']})
        reader.unchanged()
        print('DEV_NUMERIC_SEALED_JSON=' + json.dumps({'classification': 'Static/fake validation', 'passed': True,
            'results': results, 'bindings': list(reader.files.values()), 'original_bytes_and_mtimes_unchanged': True,
            'authority_test_scope': 'Synthetic enclosing timestamp bounds for numeric wire regression only; not real GO validation.',
            'new_model_API_calls': 0}, sort_keys=True, allow_nan=False), flush=True)


if __name__ == '__main__':
    unittest.main()
