"""Every retained physical attempt, including failures; no client construction."""
from collections import Counter, defaultdict
from datetime import datetime

from common import ERRORS, canonical, helpers, require, strict


def moment(value):
    require(type(value) is str, 'UTC missing')
    value = datetime.fromisoformat(value.replace('Z', '+00:00'))
    require(value.tzinfo is not None and value.utcoffset().total_seconds() == 0, 'explicit UTC required')
    return value.timestamp()


def nonce_accounting(report, raw_records):
    """Report scalars/attempt metadata must agree with original wire usage."""
    unused, old = helpers()
    errors, by_id = [], {r.get('request_id'): r for r in raw_records if type(r) is dict}
    try:
        for replica in report['replicas']:
            for slot in replica['records']:
                if slot['attempted'] is not True:
                    continue
                ledger = slot['attempt_usage']
                require(type(ledger) is list and ledger, 'nonce attempt ledger missing')
                last_usage = None
                for entry in ledger:
                    raw = by_id[entry['request_id']]
                    require(all(canonical(entry.get(key)) == canonical(raw.get(key)) for key in
                            ('request_id', 'generation_id', 'attempt', 'state', 'http_status')), 'nonce ledger/raw metadata differs')
                    try:
                        response = strict(raw['response_raw']) if type(raw.get('response_raw')) is str else None
                    except (ValueError, RecursionError):
                        require(raw.get('state') != 'success', 'nonce successful response not JSON')
                        response = None
                    last_usage = response.get('usage') if type(response) is dict else None
                    require(canonical(entry.get('usage')) == canonical(last_usage), 'nonce ledger/raw usage differs')
                    require(moment(slot['started_at_utc']) <= moment(raw['started_at_utc']) <= moment(raw['finished_at_utc']) <= moment(slot['finished_at_utc']), 'nonce slot/attempt time bounds differ')
                if slot['state'] == 'delivered':
                    counts = old.usage_values(last_usage)
                    for original, normalized in (('prompt_tokens', 'input_tokens'), ('completion_tokens', 'output_tokens'),
                            ('cached_prompt_tokens', 'cache_read_tokens'), ('cache_write_prompt_tokens', 'cache_write_tokens')):
                        require(canonical(slot['output'].get(original)) == canonical(counts[normalized]), 'nonce delivered usage scalar differs')
    except ERRORS as exc:
        errors.append(str(exc))
    return {'passed': not errors, 'errors': errors}


def audit_rows(rows, profile, run_id, endpoint_by_scope, expires, started):
    """rows={path,scope,raw}; malformed files are retained by the outer inventory.

    GO checked immediately before opening each request: start must precede expiry;
    a request legitimately finishing after expiry is retained, not reclassified.
    """
    base, old = helpers()
    facts, errors, warnings, usages = [], [], [], []
    ids, generations, clients = defaultdict(list), defaultdict(list), defaultdict(list)
    states, finishes = Counter(), Counter()
    for index, supplied in enumerate(rows):
        raw, problems = supplied['raw'], []
        row = {key: supplied[key] for key in ('path', 'scope')}
        row.update(errors=problems, usage=None, finish_reason=None)
        facts.append(row)
        # Accounting is read from retained wire bytes even when another
        # identity/profile/window check fails. Never erase known cost on failure.
        try:
            observed = strict(raw['response_raw']) if type(raw) is dict and type(raw.get('response_raw')) is str else None
            observed_usage = observed.get('usage') if type(observed) is dict else None
            require(observed_usage is None or type(observed_usage) is dict, 'usage object required')
            old.validate_usage(observed_usage)
            row['usage'] = observed_usage
        except ERRORS:
            warnings.append({'path': supplied['path'], 'kind': 'wire_usage_unavailable_or_invalid'})
        try:
            require(type(raw) is dict, 'raw object required')
            rid, cid, gid = [raw.get(key) for key in ('request_id', 'client_id', 'generation_id')]
            require(all(type(value) is str and value for value in (rid, cid, gid)), 'attempt identity missing')
            row.update(request_id=rid, client_id=cid, generation_id=gid, state=raw.get('state'))
            ids[rid].append(index); generations[gid].append(index); clients[cid].append(index)
            require(supplied['path'].endswith('/' + rid + '.json'), 'request filename differs')
            require(raw.get('schema_version') == 'expgym.api_attempt.v1' and raw.get('run_id') == run_id, 'raw schema/run differs')
            require(type(raw.get('attempt')) is int and 1 <= raw['attempt'] <= 3 and type(raw.get('max_attempts')) is int and raw['max_attempts'] == 3, 'retry bounds differ')
            states[str(raw.get('state'))] += 1
            require(raw.get('state') in ('success', 'error', 'malformed_response'), 'unfinished raw')
            begin, end = moment(raw.get('started_at_utc')), moment(raw.get('finished_at_utc'))
            require(started <= begin < expires and end >= begin, 'historical attempt outside authorized start window')
            if end >= expires:
                warnings.append({'path': supplied['path'], 'kind': 'authorized_start_finished_after_expiry'})
            payload = raw['request_payload']
            expected = {'model': profile['model'], 'temperature': profile['temperature'], 'top_p': profile['top_p'],
                        'reasoning_effort': profile['reasoning_effort'], 'chat_template_kwargs': profile['chat_template_kwargs'],
                        'max_tokens': 32768, 'parallel_tool_calls': False}
            require(type(payload) is dict and set(payload) == set(expected) | {'seed', 'messages', 'tools', 'tool_choice'}, 'exact development payload fields differ')
            require(all(canonical(payload[key]) == canonical(value) for key, value in expected.items()), 'profile differs')
            require(type(payload['seed']) is int and payload['seed'] in (1210, 1211, 1212, 1213), 'seed label differs')
            require(type(payload['tools']) is list and payload['tools'] and payload['tool_choice'] in ('auto', 'none'), 'native tools absent')
            require(type(payload['messages']) is list and base.valid_native_history(payload['messages']), 'unpaired request history')
            require(raw['endpoint'] in endpoint_by_scope[supplied['scope']], 'endpoint outside selected scope')
            if supplied['scope'] == 'protocol':
                replica = raw.get('context', {}).get('development_replica')
                require(type(replica) is int and 0 <= replica < 4 and payload['seed'] == 1210 + replica and
                        raw['endpoint'] == endpoint_by_scope['protocol'][replica], 'nonce replica/endpoint/seed identity differs')
            response, raw_text = None, raw.get('response_raw')
            if type(raw_text) is str:
                try:
                    response = strict(raw_text)
                except (ValueError, RecursionError):
                    require(raw.get('response_json') is None and raw['state'] != 'success', 'unparseable success/parsed conflict')
                    warnings.append({'path': supplied['path'], 'kind': 'non_JSON_error_usage_unknown'})
                else:
                    require(canonical(response) == canonical(raw.get('response_json')), 'response_raw/response_json differ')
            else:
                require(raw_text is None and raw.get('response_json') is None and raw['state'] != 'success', 'successful response bytes absent')
            usage = response.get('usage') if type(response) is dict else None
            require(usage is None or type(usage) is dict, 'usage object required')
            old.validate_usage(usage)
            row['usage'] = usage
            if type(response) is dict and type(response.get('choices')) is list:
                for choice in response['choices']:
                    reason = choice.get('finish_reason') if type(choice) is dict else None
                    finishes[str(reason)] += 1
                    row['finish_reason'] = reason
                    require(reason in ('stop', 'tool_calls', 'length'), 'provider abort/unknown finish retained as failure')
            if raw['state'] == 'success':
                require(type(response) is dict and type(response.get('choices')) is list and len(response['choices']) == 1 and
                        type(response['choices'][0].get('message')) is dict and raw.get('error') is None, 'success assistant envelope missing')
        except ERRORS as exc:
            problems.append(str(exc))
        usages.append(row['usage'])
    for rid, indices in ids.items():
        if len(indices) != 1:
            errors.append('duplicate physical request ID: ' + rid)
    for gid, indices in generations.items():
        try:
            ordered = sorted((rows[i] for i in indices), key=lambda r: r['raw']['attempt'])
            chain = [r['raw'] for r in ordered]
            require([r['attempt'] for r in chain] == list(range(1, len(chain) + 1)) and len(chain) <= 3, 'noncontiguous retry chain')
            require(len({(r['scope'], r['raw']['client_id']) for r in ordered}) == 1, 'generation crossed owner scope')
            require(all(canonical(r['request_payload']) == canonical(chain[0]['request_payload']) for r in chain), 'retry mutated payload')
            for first, following in zip(chain, chain[1:]):
                require(first.get('state') == 'error' and first.get('will_retry') is True and old.retry_is_transient(first), 'retry of delivered/nontransient decision')
                require(moment(following['started_at_utc']) >= moment(first['finished_at_utc']), 'overlapping retry chain')
            require(chain[-1].get('will_retry') is False, 'retry chain lacks terminal decision')
        except ERRORS as exc:
            errors.append(gid + ': ' + str(exc))
    for cid, indices in clients.items():
        scopes = {rows[i]['scope'] for i in indices}
        logical = {rows[i]['raw'].get('generation_id') for i in indices}
        if len(scopes) != 1 or len(indices) > (9 if scopes == {'protocol'} else 93) or len(logical) > (3 if scopes == {'protocol'} else 31):
            errors.append('client namespace/attempt ceiling differs: ' + cid)
    if len(rows) > 4779 or len(generations) > 1593:
        errors.append('fixed development total call ceiling exceeded')
    errors += [row['path'] + ': ' + problem for row in facts for problem in row['errors']]
    totals = old.usage_total(usages)
    if not usages or any(row['usage'] is None for row in facts):
        for value in totals.values():
            value['complete_total'] = None
    return {'passed': not errors, 'errors': errors, 'warnings': warnings, 'attempts': facts,
            'attempt_count': len(rows), 'client_count': len(clients), 'generation_count': len(generations),
            'states': dict(states), 'finish_reasons': dict(finishes), 'all_attempt_usage': totals,
            'transport_join_performed': False, 'current_GO_expiry_checked': False}
