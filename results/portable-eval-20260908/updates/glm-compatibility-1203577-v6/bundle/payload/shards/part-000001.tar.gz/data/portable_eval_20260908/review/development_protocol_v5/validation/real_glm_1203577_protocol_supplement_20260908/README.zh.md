# GLM 开发协议修复补充（效果保持封存）

原 51 条任务 trace 中共有 21 条循环内协议修复：9 条 provider `length`，12 条每次决策返回多个 native tool calls。后者已逐条核原响应确实超过一个调用。这不是 HTTP 重试：全轮 487 个原始请求均 attempt 1，对应 487 个独立 logical generation；原审计通过不表示“0 协议违规/修复”。

全部 21 条原 trace 引用、步骤、call index、请求/下一同 client 请求、provider usage 均在 [receipt.json](receipt.json)。不包含任务答案、评分值或效果方向；未重新调用 scorer、模型或服务，也未改原 audit/raw/trace。

首 ExpGym Audit 的 request `1fa48ec8a9d6448eb2c6cdd4cc3e89a3` 属于第 6 步 / `llm0006`，非 forced；15:59:18.987433 以 length 结束，input 23066、output 32768（内含 reasoning 32722）。完整同 client 顺序显示，紧随它的是 `10129d57b0c54d05b0b65914077f2401`：15:59:19.011864 开始，auto / attempt 1，新 generation，output 140 / tool_calls。

早期监控把 `a71aae…` 误称为该 length 紧接的下一同 client 请求。本补充按封存的完整请求时序纠正；该前缀确实对应另一个后续同 client 请求，不是紧接项。原监控保持原样，未覆盖。旧监控声明的依据为 ROOT 协调消息，未提供独立监控文件引用，因此 JSON 的该引用为 null，不伪造来源文件。

审计通过仅表示在已声明范围内原身份、历史、评分重建和允许的协议修复行为被核对；不是无协议失误、无工具成本，也不是最终全部实验与分析冻结后的 fresh 逻辑复查。usage 的 reasoning 已含在 completion 中，不能再次加总；未报告 cache 成本保持 unknown/null。
