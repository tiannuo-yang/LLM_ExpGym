"""Single-runtime bounded CPU supplement; no real audit or scorer execution."""
import argparse
import os
from pathlib import Path
import subprocess
import sys

from common import HERE, canonical, sha, strict, write_new
from validate_cpu import TEST


def main(output):
    output = Path(output).absolute()
    if output.exists():
        raise ValueError('new CPU output required')
    old = HERE.parent / 'development_protocol_v4'
    frozen_path = old / 'FREEZE_RECEIPT.v3.json'
    frozen_bytes = frozen_path.read_bytes()
    if sha(frozen_bytes) != 'f90971bb5bb1a7a08b7c681dc5cd9aba6063b58bae48e0ed10bfdc582a4b260c':
        raise ValueError('original accepted auditor freeze changed')
    bindings = strict(frozen_bytes)['bindings']
    protected = {row['path']: dict(row, mtime_ns=Path(row['path']).stat().st_mtime_ns) for row in bindings}
    own = {p.name: sha(p.read_bytes()) for p in sorted(HERE.glob('*.py'))}
    for row in protected.values():
        blob = Path(row['path']).read_bytes()
        if sha(blob) != row['sha256'] or len(blob) != row['bytes']:
            raise ValueError('original freeze binding mismatch')
    output.mkdir(parents=True)
    env = {key: value for key, value in os.environ.items() if 'KEY' not in key.upper() and 'TOKEN' not in key.upper()
           and not key.upper().endswith('PROXY') and key not in ('PYTHONPATH', 'DEV_INDEPENDENT_SEALED_ROOT')}
    env.update(PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
               MKL_NUM_THREADS='1', NO_PROXY='*', no_proxy='*')
    test = TEST.replace("'test_numeric_profile'", "'test_numeric_profile','test_dataset_links'")
    result = subprocess.run([sys.executable, '-B', '-c', test], cwd=str(HERE), env=env,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log = output / 'native.log'
    with log.open('xb') as stream:
        stream.write(result.stdout)
    counts = [line.decode().split()[1:] for line in result.stdout.splitlines() if line.startswith(b'DEV_TEST_COUNTS ')]
    marker = b'DATASET_LINK_STATIC_JSON='
    proof = None
    if result.stdout.count(marker) == 1:
        proof = strict(next(line.partition(marker)[2] for line in result.stdout.splitlines() if marker in line))
        write_new(output / 'static_dataset_verification.json', proof)
    for row in protected.values():
        path = Path(row['path']); blob = path.read_bytes()
        if sha(blob) != row['sha256'] or len(blob) != row['bytes'] or path.stat().st_mtime_ns != row['mtime_ns']:
            raise ValueError('original evidence changed during supplement')
    if own != {p.name: sha(p.read_bytes()) for p in sorted(HERE.glob('*.py'))}:
        raise ValueError('candidate source changed during supplement')
    passed = result.returncode == 0 and counts == [['86', '0', '0', '1']] and proof is not None and proof['passed'] is True
    receipt = {'schema_version': 'development-auditor-v5-dataset-link-cpu-v1', 'passed': passed,
        'classification': 'Static/fake validation and readonly accepted static-data verification',
        'runtime': sys.executable, 'test_counts': counts, 'exit_code': result.returncode, 'code_identity': own,
        'log': {'path': str(log), 'sha256': sha(result.stdout), 'bytes': len(result.stdout)},
        'original_auditor_bindings_unchanged': list(protected.values()),
        'original_76_tests_included': True, 'new_targeted_tests': 10, 'original_scorer_routes_reexecuted': False,
        'real_development_audit_performed': False, 'new_model_API_calls': 0,
        'static_dataset_proof': {'path': str(output / 'static_dataset_verification.json'),
            'sha256': sha((output / 'static_dataset_verification.json').read_bytes())} if proof is not None else None,
        'scope_note': 'Current link mapping/content stability only; not historical inode/link evidence. General raw/result evidence remains link-forbidden.'}
    write_new(output / 'receipt.json', receipt)
    print(canonical({'passed': passed, 'test_counts': counts, 'original_bindings_unchanged': len(protected),
                     'new_targeted_tests': 10, 'actual_scorer_routes_reexecuted': False}).decode())
    return 0 if passed else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    raise SystemExit(main(parser.parse_args().output))
