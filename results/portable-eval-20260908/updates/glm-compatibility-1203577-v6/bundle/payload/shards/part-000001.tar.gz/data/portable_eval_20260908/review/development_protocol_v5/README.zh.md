# V5 静态数据链接修正入口

当前 sibling 的变更、证据范围及最终入口说明见 [VALIDATION.v5.zh.md](VALIDATION.v5.zh.md)。下文为原 v4 使用合同与历史验收说明；原 v4 目录、收据和首次真实 preflight 失败均未改写。当前实现仅新增静态数据叶链接专用读取及 dataset_file_links 账，不改模型、原科学设置或输入/输出 schema。

# 原 V4 development 独立离线协议／评分审计说明

本工具只做 Static/fake validation 的开发与准备。实际开发数据尚未审计；不能据此签发模型运行 GO、五角色 live-ready 或正式矩阵通过。真正运行需 ROOT 另给一次离线审计 GO。

每个模型严格检查预先冻结的 3 ExpGym + 12 PoolAct N4＝51 个任务 trace，以及 4 副本 × 3 固定 nonce 槽＝12 槽。两个模型分属不同 GO/deployment/output；不会合并为一次授权。原 wrapper 的 `passed` 只作为不能矛盾的终态，不产生独立四声明。

## 入口

```bash
LLM_ExpGym/.venv/bin/python -B portable_eval_20260908/review/development_protocol_v4/audit.py \
  --spec /ABS/ROOT_POST_DRAIN_INPUT.json --spec-sha256 EXTERNAL_ROOT_SHA256 \
  --output /ABS/NEW_OUTSIDE_ORIGINAL_RUN
```

输入为 ROOT 外部 SHA pin 的 JSON：`schema_version=development-v4-independent-audit-input-v1`、`evidence_kind=real_observation`、`model_id`、`deployment_id=slurm:JOB:PHASE`、`drained=true`，以及下列 `{path,sha256}` 原 bytes 引用：

- `plan`、`execution`、`nonce_report`、`authority_ref`（原 development GO）；
- `deployment`、`profile`（ROOT 声明的完整十字段 request profile）、`source_acceptance_ref`；
- `drain_ref`（ROOT 实际排空观察）。

输入 pin 不创建授权。工具只消费 ROOT 对排空的外部确认，不发 health、tokenize、model API，不读 key。原 GO 只核历史：每条 raw 的明确 UTC 开始时刻必须不早于 execution-start 观察且严格早于原 expiry；完成时刻可晚于 expiry，单独警示。**不要求审计当下 GO 仍有效**；未知 UTC 不补造。开始/完成时间是客户端记录，不证明精确服务端调度时刻。

## 证据与约束

先递归盘点并严格读取原 raw/results/protocol/journal JSON，再启动离线原 scorer。拒绝 raw/result 目录祖先或后代 symlink、深层／其他模型 orphan、重复 JSON key、非有限数和重复请求 ID。唯一明确例外为原 plan 已 pin 的 venv Python 可执行文件 symlink：另绑定其真实目标与关系；不放宽结果路径。

逐条核对 request profile、原 response bytes 与 parsed JSON、状态、finish reason、UTC、重试链和已知／未知 usage。失败、abort、跳过仍保留；已知成本不因另一字段失败而丢掉，未报告值不补 0。`reasoning_tokens` 已包含在 output 中，不重复累加；冲突来源产生 nullable reasoning 总额。这里没有 router 双 SHA join，HTTP status 为 null 时不称 200。

nonce 使用独立 decoder 重建原 assistant 全字段、tool IDs、两分支共享完整 prefix、none 分支原 final-only note 和 exact nonce 答案。`passed/evaluation` 不作为证据；12 固定槽全部保留。另核 attempt ledger metadata/usage 与原 raw、delivered scalar 以及槽与 attempt 时间边界。

任务先重新执行冻结的只读 per-invocation raw guard（仅机械替换 namespace/已 pin profile）；再用每 job 实际 Python 3.11 在独立子进程重跑原 scorer 与 source context/schema/history→wire。不运行 runner main、resume 或生成。Exp 重建 trace-v2 input；Pool 重建每 agent 原上下文、N4 graph-owned 格式和 schema-aware trim。原评估／selector／配置／实现身份、每 agent 分数和 aggregate 均由原库重新算；合法 0 分不视为基础设施失败。

单任务损坏／异常不阻断其余任务的离线核验；已盘点 raw 留存，最终四检查为 false。缺 agent 不造部分性能或填 0。原 status、execution inventory 和实际 bytes 还要一致；新报告不能把原 failed invocation 推成成功。

## 输出和声明边界

输出新目录的 `audit.json`、`raw_audit.json`、`nonce_audit.json` 和逐 job 独立 child log。`audit.json` 使用已与 fresh-five-role producer 对齐的 `development-v4-independent-protocol-audit-v1`，包含原 refs、完整 raw/trace refs、`score_checks_complete` 和精确四 bool：`native_tools/rendered_task_context/assistant_tool_history/full_attempt_coverage`。

其中历史字段 `rendered_task_context` **只指 source→CLIENT request messages 的精确重建**，不是服务端 tokenizer/chat-template 的实际渲染证明；另明确 `server_rendered_tokens_verified=false`。Graph 校验也不是完整并发 graph/cache/lock/clock 因果重放。`strict_repeatability=null`，seed labels 不冒充可重复采样。全量指本次开发的 51＋12 范围，不是 formal 全矩阵或项目全部成本。

这不是用户要求在全部分析之后另做的 fresh final logic audit。

## CPU 复跑

```bash
LLM_ExpGym/.venv/bin/python -B portable_eval_20260908/review/development_protocol_v4/validate_cpu.py \
  --output /ABS/NEW_CPU_EVIDENCE
```

测试覆盖 nonce/原 raw/accounting/时窗/路径/异常隔离及真实原 scorer 接线，原件仅取已经封存的 v4 CPU mock-wire fixture。原 scorer 路由为 3 Exp + 24 双模型 Pool＝27 路由／99 traces／198 raw；不新跑 runner 或模型。原 1987 fixture artifacts 全部 SHA／bytes／mtime 复核。Python 3.7 只测纯逻辑；开发评分实际只走 Python 3.11。

开发过程发现的两处测试自身失误均已改正，未改原数据：初版 sealed Exp 发现器误用文件模式导致空 trace 集被 child 正确拒绝；新增测试类移动时少绑 fixture，导致三个纯测试 AttributeError。两者均非原 runner/provider 缺陷。

首次完整 CPU 的 native 67/67 和 legacy 65 pass＋2 skip 实际已完成，但 validator 将合并 stderr/stdout 的同一行当作纯 stdout，漏读前置 169 bytes 的唯一 JSON marker，因此原 `validation/cpu_v1/receipt.json` 保留为 false。旧 validator 原 bytes 留在 `correction/cpu_v1_parser/`。纠正只核唯一 marker（缺失／重复拒绝）并 strict 读取完整 JSON；新回执可用 `--reuse-test-logs .../cpu_v1 --reuse-receipt-sha256 ...` 重封原日志，不再跑 27 scorer。这是 parser 纠正，不是新一次全回归，也没有修改审计 core／原 score／原 raw。

随后 ROOT 的有限审查实证原 `audit.py` 错误输入边界：深层 orphan 的已知 usage 被排除在 accounting 之外；无法读取文件也可能在构造 ref 时触发 KeyError。原 core/tests/docs 完整留在 `correction/before_orphan_accounting/`，当前最小修改是所有发现 raw 先读并纳入 accounting，再做 namespace 资格判断。正常 3＋orphan 7 tokens 的原错误总额 3 变为 10，资格始终 false；不可读文件保留单独 `unreadable_raw_artifacts`（SHA 为 null，错误在 `raw_audit.unjoined_physical_files`），所有完整总量变 null、已知 3 保留，不混入可读取 refs。

最终 `validation/cpu_v2_supplement/receipt.json` 是 **当前纯测试 72 pass＋1 source skip（native）、71 pass＋2 skip（legacy）**，另严格重解析原完成 67/67 日志里的 27 个未变 scorer/context 路由；不是修改后重跑 27 scorer。新增 3 parser＋3 orphan 红绿测试都包含在当前纯测试中。原始 stdout/stderr 由当时 `stderr=STDOUT` 合并保存，没有伪造独立的两个流。两次中间 reseal 被原 SHA 防护拒绝（第一次辅助 archive 多一个尾换行，后恢复原 SHA；第二次遇上已获准的 accounting core 更新），未执行任何 scorer，新空输出目录仍保留。

后续 v3 窄修只纠正审计器的数值表示误拒：原 `run_protocol` 的温度是 JSON `1`，完整 profile loader 规范为 `1.0`。仅 `temperature/top_p` 接受有限、非 bool 的 int/float 数值相等；错误数值／字符串／NaN／Inf／bool 仍拒绝，其余结构（包括 template kwargs）仍精确比较。两模型封存的各 12 条 nonce wire 在旧函数明确红、新函数绿，usage 不变；未改 serving/science 设置。v2 全部字节保留在 `correction/before_numeric_profile/`，原 FREEZE_RECEIPT.json 不覆盖；最新入口锚为 `FREEZE_RECEIPT.v3.json` 与 `validation/cpu_v3_numeric_supplement/receipt.json`。当前纯测试 native 75 pass＋1 source skip、legacy 74 pass＋2 skip；27 scorer 仍复用已完成原证据、不重跑。新增 template-kwargs 反例的首版测试曾误共享可变 fixture，已改为 deepcopy，仅测试自身问题。
