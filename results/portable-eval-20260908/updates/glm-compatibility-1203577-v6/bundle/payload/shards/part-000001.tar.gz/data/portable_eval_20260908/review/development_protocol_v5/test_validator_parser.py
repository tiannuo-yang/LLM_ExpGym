"""Only the merged-output receipt parser; does not rerun scorers/tests."""
import unittest
from validate_cpu import extract_source_receipt

MARKER = b'DEV_INDEPENDENT_SEALED_TEST_JSON='


class ParserTests(unittest.TestCase):
    def test_original_169_byte_unittest_prefix(self):
        prefix = b'test_all_completed_sealed_real_flow_source_routes_read_only (test_score_context_child.SealedSourceTests.test_all_completed_sealed_real_flow_source_routes_read_only) ... '
        self.assertEqual(len(prefix), 169)
        self.assertEqual(extract_source_receipt(prefix + MARKER + b'{"passed":true}\nok\n'), {'passed': True})

    def test_missing_marker_rejected(self):
        with self.assertRaises(ValueError):
            extract_source_receipt(b'OK\n')

    def test_duplicate_markers_same_or_separate_line_rejected(self):
        for separator in (b'\n', b' '):
            with self.assertRaises(ValueError):
                extract_source_receipt(MARKER + b'{}' + separator + MARKER + b'{}')


if __name__ == '__main__':
    unittest.main()
