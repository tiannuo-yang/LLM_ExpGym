"""ROOT's one-shot ten-test data-reference check; no actual development audit."""
import argparse
import contextlib
import io
import json
import os
from pathlib import Path
import socket
import unittest
from unittest import mock

from common import HERE, Reader, canonical, sha, strict, write_new


def main(output, expected_test_sha):
    output = Path(output).absolute()
    if output.exists():
        raise ValueError('new output required')
    reader = Reader()
    pins = {
        'audit.py': '4ca965c9e6955720a15e62c194ae87190d4e7825067118f0cf77adb1db11bd49',
        'common.py': 'c39e8a0f2d50595a9f9f5916cb82b856f0d9afebb150587924e6202141e1e9a5',
        'test_dataset_links.py': expected_test_sha,
    }
    for name, expected in pins.items():
        reader.bind(HERE / name, expected)
    output.mkdir(parents=True)
    captured = io.StringIO()
    def deny(*args, **kwargs):
        raise AssertionError('ROOT data check forbids network')
    with contextlib.ExitStack() as stack:
        for name in ('socket.create_connection', 'socket.getaddrinfo', 'socket.socket.connect', 'socket.socket.connect_ex'):
            stack.enter_context(mock.patch(name, side_effect=deny))
        stack.enter_context(contextlib.redirect_stdout(captured))
        stack.enter_context(contextlib.redirect_stderr(captured))
        suite = unittest.defaultTestLoader.loadTestsFromName('test_dataset_links')
        result = unittest.TextTestRunner(verbosity=2).run(suite)
    raw = captured.getvalue().encode()
    with (output / 'test.log').open('xb') as handle:
        handle.write(raw)
    prefix = b'DATASET_LINK_STATIC_JSON='
    lines = [line.partition(prefix)[2] for line in raw.splitlines() if prefix in line]
    proof = strict(lines[0]) if len(lines) == 1 else None
    if proof is not None:
        write_new(output / 'dataset_proof.json', proof)
    reader.unchanged()
    passed = result.wasSuccessful() and result.testsRun == 10 and proof is not None and proof['passed'] is True
    report = {'passed': passed, 'tests_run': result.testsRun, 'errors': len(result.errors),
        'failures': len(result.failures), 'skipped': len(result.skipped), 'source_pins': pins,
        'test_log': {'path': str(output / 'test.log'), 'sha256': sha(raw)},
        'dataset_proof': {'path': str(output / 'dataset_proof.json'), 'sha256': sha((output / 'dataset_proof.json').read_bytes())} if proof else None,
        'current_static_refs_verified': 126 if proof else None,
        'actual_model_or_API_calls': 0, 'actual_development_audit_or_scorer_runs': 0,
        'limitations': ['Targeted data-reference tests, not a rerun of the original 76-test suite.',
                       'Checks observable current link identity and pinned bytes, not unobservable historic replacements.']}
    write_new(output / 'receipt.json', report)
    print(canonical({key: report[key] for key in ('passed', 'tests_run', 'errors', 'failures', 'skipped')}).decode())
    return 0 if passed else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True)
    parser.add_argument('--test-sha256', required=True)
    args = parser.parse_args()
    raise SystemExit(main(args.output, args.test_sha256))
