"""Offline, independent reconstruction of the fixed development nonce protocol.

Input raw_records is the complete, unmodified protocol raw-object list.  The
caller owns path/SHA/source/authority/deployment pins, strict file parsing,
request-profile validation and full retry/usage accounting.  This module never
imports or executes the protocol producer, an LLM client, or a transport.
"""
import copy
import json


FINAL_NOTE = ("System: Loop aborted (Maximum steps reached). "
              "Respond immediately with Answer: <your final choice> and no other text.")
TOOLS = [{"type": "function", "function": {
    "name": "issue_nonce", "description": "Obtain the unpredictable one-time nonce.",
    "parameters": {"type": "object", "properties": {}, "additionalProperties": False}}}]
MESSAGES = [{"role": "user", "content": (
    "Call issue_nonce exactly once with an empty argument object. The tool will "
    "supply a nonce which is not known yet. After receiving it, return only a JSON "
    "object with the single key nonce and the exact supplied value. Do not invent "
    "a nonce or call another tool.")}]
LABELS = ("first", "second_auto", "second_none")
CHECK_NAMES = ("fixed_slots", "native_tools", "assistant_tool_history", "nonce_answers",
               "raw_response_binding", "no_semantic_resampling")


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _same(left, right):
    try:
        return _canonical(left) == _canonical(right)
    except (TypeError, ValueError, OverflowError, RecursionError):
        return False


def _strict(text):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("duplicate JSON key")
            result[key] = value
        return result
    def constant(value):
        raise ValueError("nonfinite JSON constant")
    value = json.loads(text, object_pairs_hook=pairs, parse_constant=constant)
    _canonical(value)  # Also rejects numeric overflow such as 1e999.
    return value


def _planned():
    return [{"case_id": "replica_%02d_%s" % (replica, label), "replica": replica,
             "seed": 1210 + replica, "label": label,
             "tool_choice": "none" if label == "second_none" else "auto"}
            for replica in range(4) for label in LABELS]


def _decode(raw):
    """Reconstruct relevant source-client output without importing its decoder."""
    response = _strict(raw["response_raw"])
    if not _same(response, raw.get("response_json")) or type(response) is not dict:
        raise ValueError("raw JSON mismatch")
    choices = response.get("choices")
    if type(choices) is not list or not choices or type(choices[0]) is not dict:
        raise ValueError("missing first choice")
    message = choices[0].get("message")
    if type(message) is not dict or message.get("role", "assistant") != "assistant":
        raise ValueError("invalid assistant message")
    if not any(key in message for key in ("content", "tool_calls", "reasoning_content", "reasoning", "refusal")):
        raise ValueError("missing assistant response fields")
    original_calls = message.get("tool_calls")
    if original_calls is None:
        original_calls = []
    if type(original_calls) is not list:
        raise ValueError("tool calls not list")
    calls, seen = [], set()
    for call in original_calls:
        if type(call) is not dict or call.get("type") != "function":
            raise ValueError("invalid call type")
        call_id, function = call.get("id"), call.get("function")
        if type(call_id) is not str or not call_id.strip() or call_id in seen:
            raise ValueError("invalid call ID")
        if type(function) is not dict or type(function.get("name")) is not str or not function["name"].strip():
            raise ValueError("invalid function name")
        if "arguments" not in function:
            raise ValueError("missing arguments")
        seen.add(call_id)
        normalized = copy.deepcopy(call)
        if type(function["arguments"]) is not str:
            normalized["function"]["arguments"] = json.dumps(function["arguments"], ensure_ascii=False, allow_nan=False)
        calls.append(normalized)
    content = message.get("content")
    if type(content) is str:
        text = content.strip()
    elif type(content) is list:
        parts = []
        for part in content:
            if type(part) is dict and part.get("type") == "text":
                value = part.get("text", "")
                if type(value) is not str:
                    raise ValueError("invalid content part")
                parts.append(value)
        text = "\n".join(parts).strip()
    elif content is None:
        text = ""
    else:
        raise ValueError("invalid content")
    finish = choices[0].get("finish_reason")
    if finish is not None and type(finish) is not str:
        raise ValueError("invalid finish reason")
    if finish == "tool_calls" and not calls:
        raise ValueError("tool finish without calls")
    assistant = copy.deepcopy(message)
    assistant.setdefault("role", "assistant")
    return {"text": text, "tool_calls": calls, "assistant_message": assistant, "finish_reason": finish}


def _native(output):
    if not output or output["finish_reason"] != "tool_calls" or len(output["tool_calls"]) != 1:
        return None
    original = output["assistant_message"].get("tool_calls")
    if type(original) is not list or len(original) != 1:
        return None
    normalized = output["tool_calls"][0]
    try:
        for call in (normalized, original[0]):
            if call.get("type") != "function" or call["function"].get("name") != "issue_nonce":
                return None
            arguments = call["function"]["arguments"]
            if type(arguments) is str:
                arguments = _strict(arguments)
            if type(arguments) is not dict or arguments:
                return None
        if normalized["id"] != original[0]["id"]:
            return None
        return normalized["id"]
    except (KeyError, TypeError, ValueError, RecursionError, OverflowError):
        return None


def _answer(output, expected, label):
    if not output:
        return False, "not_delivered", False
    if output["tool_calls"]:
        return False, "unexpected_tool_call_not_executed", False
    if output["finish_reason"] != "stop":
        return False, "finish_reason_not_stop", False
    text = output["text"].strip()
    prefixed = label == "second_none" and text.startswith("Answer:")
    if prefixed:
        text = text[len("Answer:"):].strip()
    try:
        parsed = _strict(text)
    except (TypeError, ValueError, RecursionError, OverflowError):
        return False, "not_strict_json", prefixed
    valid = type(expected) is str and _same(parsed, {"nonce": expected})
    return valid, "exact_nonce" if valid else "wrong_nonce_or_shape", prefixed


def audit_nonce(report, raw_records, model, profile):
    """Return independent facts; producer passed/evaluation fields are ignored.

    A fully retained failed/aborted/skipped protocol remains a failed protocol.
    Its fixed-slot and response-binding checks may nevertheless pass. No check
    here claims cryptographic randomness, server token rendering or repeatability.
    """
    checks = {key: True for key in CHECK_NAMES}
    issues, facts, raw_by_id, mapped = [], [], {}, set()

    def fail(code, scope="report", affected=("fixed_slots",)):
        issues.append({"scope": scope, "code": code})
        for key in affected:
            checks[key] = False

    if type(report) is not dict:
        report = {}
        fail("report_not_object", affected=CHECK_NAMES)
    if type(profile) is not dict or profile.get("model") != model:
        fail("validated_profile_model_mismatch", affected=CHECK_NAMES)
    if type(raw_records) is not list:
        raw_records = []
        fail("raw_records_not_list", affected=("raw_response_binding",))
    for raw in raw_records:
        if type(raw) is not dict or type(raw.get("request_id")) is not str or not raw["request_id"]:
            fail("invalid_raw_request_id", affected=("raw_response_binding",))
            continue
        request_id = raw["request_id"]
        if request_id in raw_by_id:
            fail("duplicate_raw_request_id", request_id, ("raw_response_binding",))
        raw_by_id[request_id] = raw
    planned = _planned()
    if report.get("schema_version") != "development-v4-nonce-v1" or not _same(report.get("plan"), planned):
        fail("fixed_plan_mismatch")
    if report.get("classification") != "development_protocol_diagnostic":
        fail("classification_mismatch")
    replicas = report.get("replicas")
    if type(replicas) is not list or len(replicas) != 4:
        fail("four_replica_records_required")
        replicas = replicas if type(replicas) is list else []
    slots, replica_by_id = {}, {}
    for position, replica in enumerate(replicas):
        if type(replica) is not dict:
            fail("replica_not_object")
            continue
        if not _same(replica.get("replica"), position) or not _same(replica.get("seed"), 1210 + position):
            fail("replica_order_or_seed_mismatch")
        replica_by_id[position] = replica
        records = replica.get("records")
        if type(records) is not list or len(records) != 3:
            fail("three_slot_records_required", "replica_%02d" % position)
            records = records if type(records) is list else []
        for index, row in enumerate(records):
            if type(row) is not dict or type(row.get("case_id")) is not str:
                fail("slot_not_identified")
                continue
            case_id = row["case_id"]
            if position >= 4 or index >= 3 or case_id != planned[position * 3 + index]["case_id"]:
                fail("slot_order_or_membership_mismatch", case_id)
            if case_id in slots:
                fail("duplicate_slot", case_id)
            slots[case_id] = row
    expected_ids = {item["case_id"] for item in planned}
    if set(slots) != expected_ids:
        fail("fixed_twelve_slot_set_mismatch")

    decoded, payloads, client_ids, generation_owners, stop_seen = {}, {}, {}, {}, False
    actual, skipped = 0, 0
    for item in planned:
        case_id, replica = item["case_id"], item["replica"]
        row = slots.get(case_id)
        fact = dict(item, state="missing", raw_request_ids=[], output_reconstructed=False)
        facts.append(fact)
        if row is None:
            fail("missing_fixed_slot", case_id, CHECK_NAMES)
            continue
        if not _same({key: row.get(key) for key in item}, item):
            fail("slot_identity_mismatch", case_id)
        state = row.get("state")
        fact["state"] = state
        if state == "skipped":
            skipped += 1
            if row.get("attempted") is not False or any(row.get(key) is not None for key in ("input", "output", "exception", "attempt_usage")):
                fail("skipped_slot_has_attempt_data", case_id, ("fixed_slots", "raw_response_binding"))
            reason = row.get("skip_reason")
            fact["skip_reason"] = reason
            if reason not in ("external_stop", "first_native_call_not_valid"):
                fail("unrecognized_skip_reason", case_id)
            if reason == "external_stop":
                stop_seen = True
            elif stop_seen or item["label"] == "first":
                fail("skip_reason_inconsistent_with_stop_or_slot", case_id)
            continue
        if stop_seen:
            fail("attempt_after_stop_or_exception", case_id, ("no_semantic_resampling",))
        if state not in ("delivered", "error") or row.get("attempted") is not True:
            fail("invalid_attempted_slot_state", case_id, ("fixed_slots", "raw_response_binding"))
        actual += 1
        if state == "error":
            stop_seen = True  # The real wrapper's recorder stops all new slots.
            error = row.get("exception")
            fact["exception_type"] = error.get("type") if type(error) is dict else None
            if row.get("output") is not None or type(fact["exception_type"]) is not str or not fact["exception_type"]:
                fail("error_slot_not_preserved", case_id, ("raw_response_binding",))
        elif row.get("exception") is not None:
            fail("delivered_slot_has_exception", case_id, ("raw_response_binding",))
        inputs, metadata, ledger = row.get("input"), row.get("client_metadata"), row.get("attempt_usage")
        if type(inputs) is not dict or not _same(inputs.get("tools"), TOOLS) or inputs.get("tool_choice") != item["tool_choice"]:
            fail("slot_native_request_shape_mismatch", case_id, ("native_tools", "raw_response_binding"))
        if type(metadata) is not dict or type(metadata.get("client_id")) is not str or not metadata["client_id"]:
            fail("missing_client_identity", case_id, ("raw_response_binding",))
            metadata = {}
        else:
            client_ids.setdefault(replica, set()).add(metadata["client_id"])
        if type(ledger) is not list or not 1 <= len(ledger) <= 3:
            fail("missing_or_out_of_bounds_attempt_ledger", case_id, ("raw_response_binding", "no_semantic_resampling"))
            ledger = ledger if type(ledger) is list else []
        rows, generations = [], set()
        for index, attempt in enumerate(ledger):
            request_id = attempt.get("request_id") if type(attempt) is dict else None
            if type(request_id) is not str or request_id not in raw_by_id:
                fail("ledger_raw_missing", case_id, ("raw_response_binding",))
                continue
            fact["raw_request_ids"].append(request_id)
            if request_id in mapped:
                fail("raw_attempt_reused", case_id, ("raw_response_binding", "no_semantic_resampling"))
            mapped.add(request_id)
            raw = raw_by_id[request_id]
            rows.append(raw)
            generation = raw.get("generation_id")
            if type(generation) is not str or not generation:
                fail("missing_generation_id", case_id, ("raw_response_binding",))
            else:
                generations.add(generation)
                if generation in generation_owners and generation_owners[generation] != case_id:
                    fail("generation_reused_across_slots", case_id, ("raw_response_binding", "no_semantic_resampling"))
                generation_owners[generation] = case_id
            if not _same(raw.get("attempt"), index + 1):
                fail("nonsequential_attempt", case_id, ("raw_response_binding", "no_semantic_resampling"))
            if index < len(ledger) - 1 and raw.get("state") == "success":
                fail("success_resampled", case_id, ("no_semantic_resampling",))
            if raw.get("client_id") != metadata.get("client_id") or raw.get("run_id") != metadata.get("run_id"):
                fail("raw_client_identity_mismatch", case_id, ("raw_response_binding",))
            payload = raw.get("request_payload")
            if type(payload) is not dict:
                fail("raw_request_payload_missing", case_id, ("raw_response_binding", "native_tools"))
                continue
            if type(inputs) is not dict or not _same({key: payload.get(key) for key in ("messages", "tools", "tool_choice")}, inputs):
                fail("raw_input_not_equal_slot_input", case_id, ("raw_response_binding", "assistant_tool_history"))
            if payload.get("model") != model or not _same(payload.get("seed"), item["seed"]):
                fail("raw_model_or_seed_mismatch", case_id, ("raw_response_binding",))
            if not _same(payload.get("tools"), TOOLS) or payload.get("tool_choice") != item["tool_choice"] or payload.get("parallel_tool_calls") is not False:
                fail("raw_native_tool_profile_mismatch", case_id, ("native_tools",))
            if case_id in payloads and not _same(payloads[case_id], payload):
                fail("retry_payload_changed", case_id, ("no_semantic_resampling", "raw_response_binding"))
            payloads[case_id] = payload
        if len(generations) != 1:
            fail("slot_does_not_bind_one_generation", case_id, ("no_semantic_resampling", "raw_response_binding"))
        if state == "error" and rows and rows[-1].get("state") not in ("error", "malformed_response"):
            fail("error_slot_without_terminal_error_raw", case_id, ("raw_response_binding",))
        if state == "delivered":
            if not rows or rows[-1].get("state") != "success" or type(row.get("output")) is not dict:
                fail("delivered_slot_without_terminal_success", case_id, ("raw_response_binding",))
                continue
            try:
                output = _decode(rows[-1])
            except (KeyError, TypeError, ValueError, OverflowError, RecursionError):
                fail("terminal_response_not_decodable", case_id, ("raw_response_binding",))
                continue
            if output["finish_reason"] == "abort":
                fail("provider_abort_labeled_delivered", case_id, ("raw_response_binding",))
                continue
            decoded[case_id] = output
            fact["output_reconstructed"] = True
            fact["finish_reason"] = output["finish_reason"]
            for key, value in output.items():
                if not _same(row["output"].get(key), value):
                    fail("recorded_output_differs_from_raw_" + key, case_id, ("raw_response_binding",))
            if not _same(row["output"].get("attempt_usage"), ledger) or not _same(row["output"].get("request_attempts"), len(ledger)):
                fail("recorded_output_attempt_ledger_mismatch", case_id, ("raw_response_binding",))

    if set(raw_by_id) != mapped:
        fail("unmapped_protocol_raw_attempts", affected=("raw_response_binding", "no_semantic_resampling"))
    if any(len(values) != 1 for values in client_ids.values()):
        fail("more_than_one_client_per_replica", affected=("raw_response_binding", "no_semantic_resampling"))
    all_clients = [next(iter(values)) for values in client_ids.values() if len(values) == 1]
    if len(set(all_clients)) != len(all_clients):
        fail("client_reused_across_replicas", affected=("raw_response_binding",))
    if not _same(report.get("planned_logical_calls"), 12) or not _same(report.get("actual_logical_calls"), actual) or not _same(report.get("skipped_logical_calls"), skipped):
        fail("logical_call_counts_mismatch")
    if report.get("semantic_retries") != 0 or type(report.get("semantic_retries")) is not int:
        fail("declared_semantic_retries_not_zero", affected=("no_semantic_resampling",))

    for replica in range(4):
        base = "replica_%02d_" % replica
        first_id = base + "first"
        first, first_payload = decoded.get(first_id), payloads.get(first_id)
        native_id = _native(first)
        first_fact = facts[replica * 3]
        first_fact["valid_native_nonce_call"] = native_id is not None
        if not first_payload or not _same(first_payload.get("messages"), MESSAGES):
            fail("first_request_context_not_reconstructed", first_id, ("native_tools", "assistant_tool_history"))
        if native_id is None:
            fail("first_native_nonce_call_invalid_or_missing", first_id, ("native_tools", "assistant_tool_history"))
        replica_record = replica_by_id.get(replica, {})
        expected = replica_record.get("expected_nonce")
        generated = replica_record.get("nonce_generated")
        if generated is True:
            if native_id is None or type(expected) is not str or len(expected) < 24:
                fail("nonce_generated_without_valid_first_or_value", first_id, ("assistant_tool_history",))
            elif expected in _canonical({"messages": MESSAGES, "tools": TOOLS, "tool_choice": "auto"}) or expected in _canonical(first["assistant_message"]):
                fail("nonce_exposed_before_tool_result", first_id, ("assistant_tool_history", "nonce_answers"))
        elif generated is not False or expected is not None:
            fail("nonce_generation_fields_inconsistent", first_id, ("fixed_slots",))
        for offset, label in enumerate(LABELS[1:], 1):
            case_id, fact = base + label, facts[replica * 3 + offset]
            row, payload = slots.get(base + label, {}), payloads.get(base + label)
            state = row.get("state")
            history_valid = False
            wire_expected = None
            if payload:
                try:
                    tool_message = payload["messages"][2]
                    tool_result = _strict(tool_message["content"])
                    if (tool_message.get("role") == "tool" and tool_message.get("name") == "issue_nonce"
                            and tool_message.get("tool_call_id") == native_id and type(tool_result) is dict
                            and set(tool_result) == {"nonce"} and type(tool_result["nonce"]) is str):
                        wire_expected = tool_result["nonce"]
                except (IndexError, KeyError, TypeError, ValueError, OverflowError, RecursionError, AttributeError):
                    pass
            if native_id is not None and generated is True and type(expected) is str and payload:
                prefix = copy.deepcopy(MESSAGES) + [copy.deepcopy(first["assistant_message"]),
                    {"role": "tool", "tool_call_id": native_id, "name": "issue_nonce", "content": _canonical({"nonce": expected})}]
                wanted = prefix + ([{"role": "user", "content": FINAL_NOTE}] if label == "second_none" else [])
                history_valid = _same(payload.get("messages"), wanted) and _same(row.get("expected_nonce"), expected)
            fact["history_reconstructed"] = history_valid
            if not history_valid:
                fail("branch_full_history_missing_or_mismatch", case_id, ("assistant_tool_history",))
            if state == "skipped" and row.get("skip_reason") == "first_native_call_not_valid" and native_id is not None:
                fail("valid_first_followup_wrongly_skipped", case_id)
            if native_id is None and state in ("delivered", "error"):
                fail("followup_after_invalid_first", case_id, ("no_semantic_resampling", "native_tools"))
            valid, reason, prefix_removed = _answer(decoded.get(case_id), wire_expected, label)
            fact.update(nonce_answer_exact=valid, answer_reason=reason, answer_prefix_removed=prefix_removed)
            if not valid:
                fail("nonce_answer_" + reason, case_id, ("nonce_answers",))
            if reason == "unexpected_tool_call_not_executed":
                checks["native_tools"] = False

    return {"schema_version": "development-v4-independent-nonce-audit-v1", "model_id": model,
            "passed": not issues and all(checks.values()), "checks": checks, "issues": issues,
            "slotfacts": facts, "counts": {"planned_logical_slots": 12, "attempted_logical_slots": actual,
            "skipped_logical_slots": skipped, "retained_raw_attempts": len(raw_records),
            "mapped_raw_request_ids": len(mapped)},
            "limitations": ["Producer passed/evaluation flags are not evidence.",
                "Caller must independently pin and enumerate complete original files and audit retry, usage, profile and authority.",
                "Nonce bytes are checked against retained history, not proof of cryptographic randomness.",
                "Client request history is not server tokenizer/chat-template rendering or strict repeatability."]}
