#!/usr/bin/env python3
"""Bounded independent dataset-reader review; never runs audit/scorer/API."""
import argparse
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import socket
import subprocess
import sys
import time
import unittest
from unittest import mock


HERE = Path(__file__).resolve().parent
REVIEW = HERE.parent
CANDIDATE = REVIEW / 'development_protocol_v5'
PREVIOUS = REVIEW / 'development_protocol_v4'
STATIC = REVIEW.parent / 'source_cohorts/v4/portable_eval_20260908/validation/static_acceptance_v4.json'
STATIC_SHA = '79d52d587bc235a8ed35bcea6aaa39434b67f36a92950168427ccbcc875b98bb'


def sha(blob):
    return hashlib.sha256(blob).hexdigest()


def pin(path):
    blob = path.read_bytes()
    return {'path': str(path), 'sha256': sha(blob), 'bytes': len(blob)}


def identity():
    return {p.name: pin(p) for p in sorted(CANDIDATE.iterdir())
            if p.is_file() and p.suffix in ('.py', '.md')}


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, str(path))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def blocked(*args, **kwargs):
    raise AssertionError('network/process/scorer outside bounded reader review')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--owner-receipt', type=Path, required=True)
    parser.add_argument('--owner-receipt-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    owner = pin(args.owner_receipt)
    if owner['sha256'] != args.owner_receipt_sha256:
        raise ValueError('owner receipt differs')
    before = identity()
    old_pins = {p.name: pin(p) for p in sorted(PREVIOUS.glob('*.py'))}
    changes = [name for name, row in old_pins.items()
               if name in before and before[name]['sha256'] != row['sha256']]
    if sorted(changes) != ['audit.py', 'common.py']:
        raise ValueError('unexpected preexisting Python file change')
    static_blob = STATIC.read_bytes()
    if sha(static_blob) != STATIC_SHA:
        raise ValueError('static receipt differs')
    refs = json.loads(static_blob)['data_binding']['files']
    sys.path.insert(0, str(CANDIDATE))
    current = load(CANDIDATE / 'common.py', 'peer_dataset_current')
    previous = load(PREVIOUS / 'common.py', 'peer_dataset_previous')
    current_reader, previous_reader = current.Reader(), previous.Reader()
    report = {'scope': 'CPU reader-only; no audit/scorer/raw/result/model/GET/key access',
              'owner_receipt': owner, 'source_before': before, 'previous_source': old_pins,
              'static_receipt': pin(STATIC), 'changed_existing_python': changes,
              'datasets': [], 'errors': [], 'interpreter': sys.executable}
    start = time.monotonic()
    output = io.StringIO()
    with mock.patch.object(socket, 'socket', blocked), mock.patch.object(socket, 'create_connection', blocked), \
            mock.patch.object(subprocess, 'Popen', blocked):
        suite = unittest.defaultTestLoader.discover(str(CANDIDATE), pattern='test_dataset_links.py')
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
            result = unittest.TextTestRunner(stream=output, verbosity=2).run(suite)
        report['tests'] = {'run': result.testsRun, 'failures': len(result.failures),
                           'errors': len(result.errors), 'skipped': len(result.skipped),
                           'passed': result.wasSuccessful(), 'log': output.getvalue()}
        for label, ref in sorted(refs.items()):
            row = {'label': label, 'path': ref['path'], 'bytes': ref['bytes'],
                   'expected_sha256': ref['sha256'], 'leaf_link': Path(ref['path']).is_symlink()}
            try:
                previous_reader.bind(ref['path'], ref['sha256'])
                row['old_bind_accepted'] = True
            except ValueError as exc:
                row['old_bind_accepted'] = False
                row['old_error'] = str(exc)
            blob = current_reader.dataset_file(ref)
            row['new_verified'] = len(blob) == ref['bytes'] and sha(blob) == ref['sha256']
            if row['leaf_link']:
                try:
                    current.Reader().bind(ref['path'], ref['sha256'])
                    row['generic_bind_still_rejects'] = False
                except ValueError:
                    row['generic_bind_still_rejects'] = True
            report['datasets'].append(row)
        current_reader.unchanged()
    report['current_reference_ledger'] = current_reader.dataset_file_links
    report['source_after'] = identity()
    report['source_unchanged'] = before == report['source_after']
    rows = report['datasets']
    report['totals'] = {'references': len(rows), 'bytes': sum(r['bytes'] for r in rows),
                        'leaf_links': sum(r['leaf_link'] for r in rows),
                        'old_accepted': sum(r['old_bind_accepted'] for r in rows),
                        'new_verified': sum(r['new_verified'] for r in rows)}
    report['passed'] = (report['tests']['passed'] and report['source_unchanged'] and
        len(rows) == 126 and report['totals']['leaf_links'] == 27 and
        all(r['new_verified'] and r['old_bind_accepted'] == (not r['leaf_link']) and
            r.get('generic_bind_still_rejects', True) for r in rows))
    report['limits'] = ['Current pinned bytes and observed link stability only; no historical inode claim.',
                        'No full development or formal audit/scorer executed.',
                        'Formal planner resolves dataset paths before its strict reader; no formal code modified.']
    report['wall_seconds'] = time.monotonic() - start
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x') as stream:
        json.dump(report, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'passed': report['passed'], 'tests': report['tests']['run'],
                      'totals': report['totals'], 'output': pin(args.output)}))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    sys.exit(main())
