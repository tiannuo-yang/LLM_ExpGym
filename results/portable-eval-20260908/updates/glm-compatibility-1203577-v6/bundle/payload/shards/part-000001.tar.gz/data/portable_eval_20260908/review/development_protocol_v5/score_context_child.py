#!/usr/bin/env python3
"""Offline same-runtime v4 development score and source-to-wire context audit.

stdin: {plan, job, preflight, trace_paths}. stdout: DEV_INDEPENDENT_JSON=... .
The parent must pin/validate plan, source, runtime and the complete raw namespace.
This child invokes original read-only scorers, never runner main/resume/generation.
"""
from __future__ import annotations

import argparse
from contextlib import ExitStack, contextmanager, redirect_stdout
import copy
from dataclasses import asdict
import hashlib
import importlib
import importlib.util
from io import StringIO
import json
import os
from pathlib import Path
import platform
import re
import socket
import subprocess
import sys
from unittest import mock

PREFIX = "DEV_INDEPENDENT_JSON="
COMMON_SHA = "2ccc0af3f63b6768296ad554c407f96c74dcd8db5e7e670bb6d7786486df9672"
PILOT_SHA = "e7a512118fd786ee9aef4be3305f2a4efafc550cca69f5e6452b01807a54468a"
RUNTIME_FIELDS = ("executable", "version", "prefix", "base_prefix", "machine")
LIMITATIONS = [
    "Source-to-client task messages/schema/history only; server tokenizer or chat-template rendering is not verified.",
    "PoolAct graph checks cover original N4 renderer-owned syntax, not opaque state, visibility or concurrent causal replay.",
    "Original score consistency is not answer correctness, nonzero performance or complete full-matrix acceptance.",
    "Parent separately audits raw delivery/response-ledger bijection, retries, missingness and provider-abort quarantine.",
    "No credential is read. Deterministic secret-field redaction is reconstructed without secret substring replacement; a mismatch fails closed.",
]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_pinned(name, path, expected):
    path = Path(path).absolute()
    if sha(path) != expected:
        raise ValueError("Pinned helper differs: " + path.name)
    if name not in sys.modules:
        specification = importlib.util.spec_from_file_location(name, str(path))
        module = importlib.util.module_from_spec(specification)
        sys.modules[name] = module
        specification.loader.exec_module(module)
    module = sys.modules[name]
    if Path(module.__file__).resolve() != path.resolve():
        raise ValueError("Wrong helper origin: " + name)
    return module


def common():
    return load_pinned("development_independent_bc_common", Path(__file__).resolve().parents[1] / "audit_bc_common.py", COMMON_SHA)


def read(path):
    value = common().read(path)
    # Also reject numeric overflow (JSON 1e999), not only NaN constants.
    json.dumps(value, allow_nan=False)
    return value


def same(left, right):
    return common().same(left, right)


def source_module(repo, name):
    module = importlib.import_module(name)
    expected = repo.joinpath(*name.split("."))
    expected = expected / "__init__.py" if expected.is_dir() else expected.with_suffix(".py")
    if not getattr(module, "__file__", None) or Path(module.__file__).resolve() != expected.resolve():
        raise ValueError("Wrong exact source module origin: " + name)
    return module


def verify_loaded_source(repo):
    for name, module in list(sys.modules.items()):
        if name == "demo_experiment" or name == "expgym" or name.startswith("expgym.") or name.startswith("scripts.run_"):
            if getattr(module, "__file__", None):
                source_module(repo, name)


def runtime_record():
    return {"executable": sys.executable, "version": sys.version, "prefix": sys.prefix,
            "base_prefix": sys.base_prefix, "machine": platform.machine()}


def runtime_check(preflight, command, runtime=None):
    actual = runtime_record() if runtime is None else runtime
    recorded = preflight.get("runtime")
    return (isinstance(recorded, dict) and set(recorded) == set(RUNTIME_FIELDS)
            and same(actual, recorded) and actual["version"].startswith("3.11.")
            and actual["executable"] == command[0])


@contextmanager
def offline_guard(blocked):
    """No model, network, subprocess or filesystem mutation in scorer scope."""
    def deny(kind):
        def blocked_call(*args, **kwargs):
            blocked.append(kind)
            raise RuntimeError("DEV_INDEPENDENT_FORBIDDEN_" + kind.upper())
        return blocked_call
    active = [True]
    def audit(event, arguments):
        if not active[0]:
            return
        if event == "open":
            mode, flags = arguments[1], arguments[2]
            if (isinstance(mode, str) and any(char in mode for char in "wax+")) or (
                    isinstance(flags, int) and flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND)):
                deny("filesystem_write")()
        elif event in ("os.remove", "os.rename", "os.rmdir", "os.mkdir", "os.link", "os.symlink", "os.chmod", "os.truncate"):
            deny("filesystem_write")()
        elif event in ("subprocess.Popen", "os.system", "os.fork", "os.posix_spawn", "os.exec"):
            deny("process")()
    sys.addaudithook(audit)
    try:
        with ExitStack() as stack:
            for owner, attribute in ((socket, "create_connection"), (socket, "getaddrinfo"),
                                     (socket.socket, "connect"), (socket.socket, "connect_ex"),
                                     (socket.socket, "sendto"), (socket.socket, "sendmsg")):
                stack.enter_context(mock.patch.object(owner, attribute, deny("network")))
            stack.enter_context(mock.patch.object(subprocess, "Popen", deny("process")))
            stack.enter_context(mock.patch.object(os, "system", deny("process")))
            yield stack, deny
    finally:
        active[0] = False


def expected_paths(supplied, required):
    actual = [str(Path(path).absolute()) for path in supplied]
    wanted = [str(Path(path).absolute()) for path in required]
    if len(actual) != len(set(actual)) or sorted(actual) != sorted(wanted):
        raise ValueError("Trace set differs from exact selected original source paths")
    for path in wanted:
        if not Path(path).is_file():
            raise ValueError("Missing original selected trace: " + path)
    return [Path(path) for path in wanted]


def request_record(job, entry):
    rid = entry.get("request_id")
    if not isinstance(rid, str) or re.fullmatch(r"[0-9a-f]{32}", rid) is None:
        raise ValueError("Missing or unsafe request_id in original trace ledger")
    return rid, read(Path(job["dump_dir"]) / (rid + ".json"))


def pool_inputs(agent, job, namespace_context, schemas, max_context_tokens, loop, redact):
    """Original full-history prefix -> schema-aware trim -> retained wire."""
    errors, requests, choices = [], [], []
    messages, ledger = agent["messages"], agent["usage_attempts"]
    positions = [i for i, message in enumerate(messages) if message.get("role") == "assistant"]
    if not positions or len(positions) != len(ledger):
        raise ValueError("Agent assistant-message/logical-call ledger counts differ or are empty")
    schema_tokens = len(json.dumps(schemas, ensure_ascii=False, allow_nan=False)) // 3
    trimmed_count, maximum = 0, 0
    for call, position in zip(ledger, positions):
        prefix = copy.deepcopy(messages[:position])
        if not common().valid_native_history(prefix):
            errors.append("Stored native input history is unpaired")
        expected = loop._trim_messages(copy.deepcopy(prefix), max_context_tokens - schema_tokens)
        if not common().valid_native_history(expected):
            errors.append("Trimmed native input history is unpaired")
        trimmed_count += not same(expected, prefix)
        estimate = loop._estimate_tokens(expected) + schema_tokens
        maximum = max(maximum, estimate)
        if estimate > max_context_tokens:
            errors.append("Original schema-aware input admission cap exceeded")
        if not isinstance(call.get("attempts"), list) or not call["attempts"]:
            raise ValueError("Missing physical attempts for original logical call")
        for attempt in call["attempts"]:
            rid, raw = request_record(job, attempt)
            payload = raw["request_payload"]
            if not same(payload.get("messages"), redact(expected)) or not same(payload.get("tools"), redact(schemas)):
                errors.append("Exact original trimmed native input/schema differs: " + rid)
            if not same(raw.get("context"), redact(namespace_context)):
                errors.append("Original namespace/raw context differs: " + rid)
            requests.append(rid)
            choices.append(payload.get("tool_choice"))
    if len(requests) != len(set(requests)):
        errors.append("Repeated request_id in agent logical-call ledger")
    return {"passed": not errors, "errors": errors, "request_ids": requests,
            "trimmed_generations_observed": trimmed_count,
            "max_runner_estimated_input_tokens_including_schema": maximum,
            "observed_tool_choices": choices, "forced_none_required": False}


def exp_inputs(trace, job, namespace_context, system, context, schemas, trace_module, redact):
    errors, requests = [], []
    calls = trace["llm_calls"]
    if not calls:
        raise ValueError("ExpGym original trace has no logical calls")
    for call in calls:
        expected = trace_module.materialize_llm_input(trace, call["id"])
        if expected[:2] != [{"role": "system", "content": system}, {"role": "user", "content": context}]:
            errors.append("Source-owned complete system/task context differs: " + call["id"])
        if sum(message.get("role") == "system" for message in expected) != 1:
            errors.append("Original materialized input system count differs: " + call["id"])
        if not common().valid_native_history(expected):
            errors.append("Original materialized native input history is unpaired: " + call["id"])
        if not isinstance(call.get("attempt_usage"), list) or not call["attempt_usage"]:
            raise ValueError("Missing physical attempts for original ExpGym logical call")
        for attempt in call["attempt_usage"]:
            rid, raw = request_record(job, attempt)
            payload = raw["request_payload"]
            if not same(payload.get("messages"), redact(expected)) or not same(payload.get("tools"), redact(schemas)):
                errors.append("Original materialized input/native schema differs: " + rid)
            if not same(raw.get("context"), redact(namespace_context)):
                errors.append("Original selected job/raw context differs: " + rid)
            requests.append(rid)
    if len(requests) != len(set(requests)):
        errors.append("Repeated request_id in ExpGym logical-call ledger")
    return {"passed": not errors, "errors": errors, "request_ids": requests,
            "forced_call_count_observed": sum(call.get("forced") is True for call in calls),
            "forced_none_required": False}


def score_pool(specification, runner, demo, protocol, loop, graph_class, redact):
    job, preflight = specification["job"], specification["preflight"]
    parsed = runner.parse_args()
    if parsed.agents != 4 or parsed.repeats != 1 or parsed.strategies != [job["strategy"]] or parsed.questions is not None:
        raise ValueError("Expected one original strategy, N4, one repeat and one explicit item")
    item = runner._repeat_namespace(parsed, 0)
    item.question_index = parsed.question_index if parsed.question_index is not None else 0
    item.questions = None
    identity = runner.evaluation_identity(item, Path(specification["plan"]["config"]["repo_root"]))
    runner.bind_evaluation_identity(identity)
    item._evaluation_identity = identity
    base_cost = runner.resolve_base_cost(item.scenario, item)
    budget, modes = runner.resolve_cost_regime(item, base_cost)
    if len(modes) != 1:
        raise ValueError("Original selected PoolAct invocation has multiple cost modes")
    config = runner._resolved_config(item, budget)
    scenario = runner._SCENARIOS[item.scenario]
    tools = runner._resolve_tools(scenario, item)
    schemas = protocol.native_tool_schemas(tools)
    actual = {"evaluation_identity": identity, "config": config, "base_cost": base_cost,
              "native_tool_schemas": schemas,
              "agent_dump_contexts": [runner._agent_namespace(item, item.strategies[0], i, None)._api_dump_context for i in range(4)],
              "runtime": runtime_record()}
    identity_matches = same(actual, preflight) and runtime_check(preflight, job["command"])
    paths = expected_paths(specification["trace_paths"], [Path(job["output_dir"]) / job["strategy"] / "agents" / ("agent_%d.json" % i) for i in range(4)])
    evaluator = runner._resolve_answer_evaluator(scenario, item)
    # Identical original read-only loader/scorer path used by frozen BC score mode.
    selected = runner._load_resumable_result(item.output_dir / item.strategies[0] / "result.json",
        item_output_dir=item.output_dir, strategy=item.strategies[0], config=config,
        implementation=runner._implementation_manifest(), agents=4, answer_evaluator=evaluator, score_tools=tools)
    if selected is None:
        raise ValueError("Original PoolAct result/score/aggregate recomputation failed; no missing agent imputation")
    checks = [runner._score_check(agent, tools, evaluator) for agent in selected["agent_results"]]
    score_passed = len(checks) == 4 and all(row.get("ok") is True for row in checks)
    actual.update(score_checks=checks, aggregate_recomputed=selected["aggregate"])
    graph, errors, rows, requests = graph_class(n_agents=4, diversity_mode=True), [], [], []
    for agent_id, path in enumerate(paths):
        namespace = runner._agent_namespace(item, job["strategy"], agent_id, None)
        context = demo._resolve_context(scenario, modes[0] == "time_focus", namespace, argparse.Namespace(supports_native_tools=True)).strip()
        original_system = demo._resolve_system_prompt(scenario, modes[0] == "time_focus", namespace) or loop.build_system_prompt()
        system = protocol.native_system_prompt(original_system)
        agent_schemas = protocol.native_tool_schemas(demo._resolve_tools(scenario, namespace))
        agent = read(path)
        costs = common().cost_sanity(agent)
        prompt = common().trusted_stored_prompt(agent["messages"], system, context, job["strategy"], agent_id, graph)
        history = pool_inputs(agent, job, namespace._api_dump_context, agent_schemas, parsed.max_context_tokens, loop, redact)
        if not same(agent_schemas, schemas) or not same(namespace._api_dump_context, actual["agent_dump_contexts"][agent_id]):
            errors.append("Original agent-specific namespace/schema differs from identity")
        errors.extend(costs["errors"] + prompt["errors"] + history["errors"])
        requests.extend(history["request_ids"])
        rows.append({"agent_id": agent_id, "path": str(path), "sha256": sha(path),
                     "cost_sanity": costs, "prompt": prompt, "history": history})
    return {"identity_matches_preflight": identity_matches, "score_checks_complete": score_passed,
            "prompt_passed": all(row["prompt"]["passed"] for row in rows),
            "history_passed": all(row["history"]["passed"] for row in rows),
            "request_ids": requests, "trace_rows": rows, "original_score_receipt": actual, "errors": errors,
            "cost_regime": {"base_cost": base_cost, "budget": budget, "mode": modes[0]}}


def score_exp(specification, runner, demo, protocol, trace_module, redact):
    selected, preflight = specification["job"], specification["preflight"]
    args = runner.parse_args()
    jobs = runner._build_jobs(args)
    if len(jobs) != 1:
        raise ValueError("Expected exactly one original ExpGym trace")
    job = jobs[0]
    identity = runner._job_evaluation_identity(args, job)
    actual = {"job": asdict(job), "evaluation_identity": identity, "runtime": runtime_record()}
    identity_matches = same(actual, preflight) and runtime_check(preflight, selected["command"])
    paths = expected_paths(specification["trace_paths"], [runner._trace_path(args.output_dir, job, args.trace_format)])
    trace = read(paths[0])
    resume_valid = runner._resume_trace_is_valid(paths[0], args, job)
    namespace = runner._namespace_for_job(args, job, None)
    runner.bind_evaluation_identity(identity)
    scenario = runner._SCENARIOS[job.scenario]
    tools = runner._resolve_tools(scenario, namespace)
    evaluator = runner._resolve_answer_evaluator(scenario, namespace)
    score = runner._score_check(trace_module.result_for_score_check(trace), tools, evaluator)
    base_cost = runner.resolve_base_cost(job.scenario, namespace)
    budget, modes = runner.resolve_cost_regime(namespace, base_cost)
    if len(modes) != 1:
        raise ValueError("Original selected ExpGym invocation has multiple cost modes")
    context = demo._resolve_context(scenario, modes[0] == "time_focus", namespace, argparse.Namespace(supports_native_tools=True)).strip()
    system = protocol.native_system_prompt(demo._resolve_system_prompt(scenario, modes[0] == "time_focus", namespace))
    schemas = protocol.native_tool_schemas(tools)
    history = exp_inputs(trace, selected, namespace._api_dump_context, system, context, schemas, trace_module, redact)
    actual.update(score_check=score, resume_identity_score_valid=resume_valid)
    row = {"path": str(paths[0]), "sha256": sha(paths[0]), "history": history}
    return {"identity_matches_preflight": identity_matches,
            "score_checks_complete": resume_valid and score.get("ok") is True,
            "prompt_passed": history["passed"], "history_passed": history["passed"],
            "request_ids": history["request_ids"], "trace_rows": [row],
            "original_score_receipt": actual, "errors": history["errors"],
            "cost_regime": {"base_cost": base_cost, "budget": budget, "mode": modes[0]}}


def check(specification):
    blocked, result = [], {}
    try:
        sys.dont_write_bytecode = True
        plan, job = specification["plan"], specification["job"]
        config = plan["config"]
        repo = Path(config["repo_root"]).resolve()
        if job["runtime"] != "native" or job["model"] not in ("kimi-k3", "glm-5.3"):
            raise ValueError("Not a native selected v4 development model/job")
        if sum(same(row, job) for row in plan["jobs"]) != 1:
            raise ValueError("Selected job is not exactly present once in supplied plan")
        runner_name = {"expgym": "run_paper_sweep", "poolact": "run_poolact"}[job["system"]]
        if job["command"][0] != config["python"] or Path(job["command"][2]).resolve() != repo / "scripts" / (runner_name + ".py"):
            raise ValueError("Selected command runtime/source differs from plan config")
        if os.environ.get("EXPGYM_RUN_ID") != "development-v4:" + Path(config["output_dir"]).name:
            raise ValueError("Parent did not provide exact original development run-id environment")
        if not runtime_check(specification["preflight"], job["command"]):
            raise ValueError("Actual native Python/runtime differs from original five-field preflight")
        sys.path.insert(0, str(repo))
        with offline_guard(blocked) as (stack, deny), redirect_stdout(StringIO()):
            pilot = load_pinned("development_independent_v4_pilot", Path(config["helper_dir"]) / "pilot_timing.py", PILOT_SHA)
            demo = source_module(repo, "demo_experiment")
            clients = source_module(repo, "expgym.llm_clients")
            loop = source_module(repo, "expgym.react_loop")
            protocol = source_module(repo, "expgym.tool_protocol")
            for owner, attribute in ((demo, "build_llm"), (demo.FakeLLM, "__init__"), (demo.FakeLLM, "generate"),
                                     (clients.OpenAICompatibleLLM, "__init__"), (clients.OpenAICompatibleLLM, "generate")):
                stack.enter_context(mock.patch.object(owner, attribute, deny("model")))
            runner = source_module(repo, "scripts." + runner_name)
            for attribute in ("main", "build_llm", "_load_api_key", "run_react_loop"):
                stack.enter_context(mock.patch.object(runner, attribute, deny("model")))
            stack.enter_context(mock.patch.object(sys, "argv", job["command"][2:]))
            redact = lambda value: pilot.redact_wire(value, None, clients.OpenAICompatibleLLM._is_secret_field)
            verify_loaded_source(repo)
            if job["system"] == "poolact":
                graph = source_module(repo, "expgym.extras.parallel_cache").SharedExplorationGraph
                stack.enter_context(mock.patch.object(runner, "run_agents_parallel", deny("model")))
                result = score_pool(specification, runner, demo, protocol, loop, graph, redact)
            else:
                result = score_exp(specification, runner, demo, protocol, source_module(repo, "expgym.trace_v2"), redact)
            verify_loaded_source(repo)
        python = Path(job["command"][0])
        config_file = python.parent.parent / "pyvenv.cfg"
        result["actual_runtime_bindings"] = {"executable_sha256": sha(python),
            "pyvenv_config_sha256": sha(config_file) if config_file.is_file() else None}
        if len(result["request_ids"]) != len(set(result["request_ids"])):
            result["errors"].append("Repeated physical request_id across selected traces")
    except Exception as exc:
        result.setdefault("errors", []).append(type(exc).__name__ + ": " + str(exc)[:600])
        result["exception_type"] = type(exc).__name__
        result["passed"] = False
    for key in ("identity_matches_preflight", "score_checks_complete", "prompt_passed", "history_passed"):
        result.setdefault(key, False)
    for key in ("request_ids", "trace_rows", "errors"):
        result.setdefault(key, [])
    result.setdefault("original_score_receipt", None)
    if not result["errors"]:
        for key in ("identity_matches_preflight", "score_checks_complete", "prompt_passed", "history_passed"):
            if result[key] is not True:
                result["errors"].append("Independent check did not pass: " + key)
    result["model_or_network_attempts"] = sum(kind in ("model", "network") for kind in blocked)
    result["blocked_actions"] = blocked
    result["limitations"] = LIMITATIONS
    result["server_rendered_tokens_verified"] = False
    result["passed"] = (not result["errors"] and not blocked and all(result[key] is True for key in
        ("identity_matches_preflight", "score_checks_complete", "prompt_passed", "history_passed")))
    return result


def main():
    specification = common().strict_json(sys.stdin.read())
    json.dumps(specification, allow_nan=False)
    result = check(specification)
    print(PREFIX + json.dumps(result, ensure_ascii=False, sort_keys=True, allow_nan=False))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
