"""Small pinned, read-only v4 audit primitives (Python 3.7 compatible)."""
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import stat
import sys

HERE = Path(__file__).resolve().parent
REVIEW = HERE.parent
STUDY = REVIEW.parent / 'source_cohorts/v4/portable_eval_20260908'
CANDIDATE = STUDY / 'design/development_v4_candidate'
SOURCE = 'b280a0f640ffab8aa90bc74df4c9ecf3189b375cdd674094a005b3569bb4b608'
STATIC = '79d52d587bc235a8ed35bcea6aaa39434b67f36a92950168427ccbcc875b98bb'
DEVELOPMENT_SHA = '3988ecc4c1477f55aa3d64bad99242ebf330037e735b581f5fee2fb5a27cb8ae'
PROFILE_PATH = STUDY / 'patches/profile_parameterization_v2/candidate/harness/request_profile.py'
PROFILE_SHA = '64f19f0de7c36a0c8b461ae28056e481aa73f2980ba3d91cd8d34a40a4f6eb70'
COMMON_SHA = '2ccc0af3f63b6768296ad554c407f96c74dcd8db5e7e670bb6d7786486df9672'
RAW_HELPER_SHA = '69f3b4a43ef787dd1ce273a743af6df9231e5abca33223be87c24abe83df525a'
ERRORS = (ValueError, TypeError, KeyError, IndexError, AttributeError, OSError, OverflowError, RecursionError, RuntimeError)


def sha(blob):
    return hashlib.sha256(blob).hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def strict(blob):
    def pairs(rows):
        value = {}
        for key, item in rows:
            if key in value:
                raise ValueError('duplicate JSON key')
            value[key] = item
        return value
    def floating(text):
        value = float(text)
        if not math.isfinite(value):
            raise ValueError('nonfinite JSON number')
        return value
    def reject(unused):
        raise ValueError('nonfinite JSON constant')
    return json.loads(blob, object_pairs_hook=pairs, parse_float=floating, parse_constant=reject)


def require(value, rule):
    if not value:
        raise ValueError(rule)


def safe(path):
    path = Path(path).absolute()
    require('..' not in path.parts, 'noncanonical path')
    for parent in [path] + list(path.parents):
        require(not parent.is_symlink(), 'symlink evidence forbidden')
    require(path.name not in ('.env', 'id_rsa', 'id_ed25519') and 'router_api_key' not in path.name,
            'credential evidence forbidden')
    return path


def inventory(root):
    root = safe(root)
    if not root.exists():
        return []
    require(root.is_dir(), 'evidence root is not directory')
    for directory, directories, files in os.walk(root, followlinks=False):
        for name in directories + files:
            safe(Path(directory) / name)
    return sorted(root.rglob('*.json'))


class Reader:
    def __init__(self):
        self.files = {}
        self.runtime_links = {}
        self.dataset_file_links = {}

    def bind(self, path, expected=None):
        path = safe(path)
        before = path.stat()
        require(path.is_file(), 'regular evidence file required')
        blob = path.read_bytes()
        after = path.stat()
        row = {'path': str(path), 'sha256': sha(blob), 'bytes': len(blob), 'mtime_ns': after.st_mtime_ns}
        require((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), 'evidence changed while reading')
        require(expected is None or row['sha256'] == expected, 'external SHA mismatch')
        require(str(path) not in self.files or self.files[str(path)] == row, 'evidence changed between reads')
        self.files[str(path)] = row
        return blob

    def read(self, path, expected=None):
        return strict(self.bind(path, expected))

    def ref(self, ref):
        require(type(ref) is dict and set(ref) == {'path', 'sha256'} and
                type(ref['sha256']) is str and re.fullmatch('[a-f0-9]{64}', ref['sha256']), 'exact external reference required')
        return self.read(ref['path'], ref['sha256'])

    def unchanged(self):
        for row in list(self.files.values()):
            self.bind(row['path'], row['sha256'])
        for original, target in self.runtime_links.items():
            require(str(Path(original).resolve()) == target, 'runtime executable symlink target changed')
        for row in list(self.dataset_file_links.values()):
            self.dataset_file(row['static_ref'])

    def dataset_file(self, ref):
        """Only an accepted static data ref may use one pinned leaf link.

        General evidence bind()/inventory() stay link-forbidden. No target or
        original ancestor may be a link; link chains are not accepted.
        """
        require(type(ref) is dict and set(ref) == {'path', 'sha256', 'bytes'} and
                type(ref['path']) is str and Path(ref['path']).is_absolute() and
                type(ref['sha256']) is str and re.fullmatch('[a-f0-9]{64}', ref['sha256']) and
                type(ref['bytes']) is int and ref['bytes'] >= 0, 'exact pinned static data ref required')
        original = Path(ref['path'])

        def state():
            safe(original.parent)
            require('..' not in original.parts and original.name not in ('.env', 'id_rsa', 'id_ed25519') and
                    'router_api_key' not in original.name, 'unsafe static data path')
            info = original.lstat()
            require(stat.S_ISREG(info.st_mode) or stat.S_ISLNK(info.st_mode), 'static data file or leaf link required')
            link = os.readlink(original) if stat.S_ISLNK(info.st_mode) else None
            candidate = original.parent / link if link is not None else original
            if link is not None:
                # Check lexical ancestors before removing '..'; otherwise a
                # link/../ component could silently change traversal meaning.
                for parent in [candidate] + list(candidate.parents):
                    require(not parent.is_symlink(), 'static data target chain/ancestor link forbidden')
            target = safe(Path(os.path.abspath(candidate)))
            require(target.is_file(), 'static data target must be regular file')
            return {'original_path': str(original), 'link_target': link, 'canonical_target': str(target),
                    'link_or_file_stat': {'device': info.st_dev, 'inode': info.st_ino, 'mode': info.st_mode,
                        'bytes': info.st_size, 'mtime_ns': info.st_mtime_ns, 'ctime_ns': info.st_ctime_ns}}

        before = state()
        blob = self.bind(before['canonical_target'], ref['sha256'])
        require(len(blob) == ref['bytes'], 'static data size mismatch')
        require(state() == before, 'static data reference changed while reading')
        row = dict(before, static_ref=dict(ref), sha256=sha(blob), bytes=len(blob))
        require(str(original) not in self.dataset_file_links or self.dataset_file_links[str(original)] == row,
                'static data reference changed between reads')
        self.dataset_file_links[str(original)] = row
        return blob

    def runtime(self, path, expected):
        # venv/bin/python is a conventional pinned executable symlink, not a
        # raw/result namespace exception. Reject symlinked ancestor directories.
        original = Path(path).absolute()
        safe(original.parent)
        resolved = safe(original.resolve())
        self.runtime_links[str(original)] = str(resolved)
        return self.bind(resolved, expected)


def load(path, expected, name):
    path = safe(path)
    require(sha(path.read_bytes()) == expected, 'pinned helper changed')
    if name not in sys.modules:
        spec = importlib.util.spec_from_file_location(name, str(path))
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
    require(Path(sys.modules[name].__file__).resolve() == path, 'helper module origin mismatch')
    return sys.modules[name]


def helpers():
    if str(REVIEW) not in sys.path:
        sys.path.insert(0, str(REVIEW))
    base = load(REVIEW / 'audit_bc_common.py', COMMON_SHA, 'audit_bc_common')
    raw = load(REVIEW / 'audit_bc_attempts_v3.py', RAW_HELPER_SHA, 'audit_bc_attempts_v3')
    return base, raw


def development():
    return load(CANDIDATE / 'development.py', DEVELOPMENT_SHA, 'development_protocol_v4_source_plan')


def write_new(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
