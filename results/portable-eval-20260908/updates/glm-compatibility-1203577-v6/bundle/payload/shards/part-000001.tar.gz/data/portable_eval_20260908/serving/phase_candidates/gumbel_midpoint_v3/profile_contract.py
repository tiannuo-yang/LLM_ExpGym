"""Small, explicit contracts for the two reviewed serving candidates.

No GPU/network imports. A stochastic contract classifies seed semantics, never
claims independent generation or relaxes the original K3 deterministic gate.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path


MODELS = ("kimi-k3", "glm-5.3")
GLM_INITIALIZATION_SEEDS = (4200, 4201, 4202, 4203)


def _equal(actual, expected):
    # bool is an int in Python, but is never a valid TP size or sampler setting.
    if type(actual) is not type(expected):
        return False
    if isinstance(expected, dict):
        return actual.keys() == expected.keys() and all(_equal(actual[k], v) for k, v in expected.items())
    if isinstance(expected, list):
        return len(actual) == len(expected) and all(_equal(a, b) for a, b in zip(actual, expected))
    return actual == expected


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def validate_profile(model, profile):
    _require(model in MODELS and isinstance(profile, dict), "unknown or missing reviewed model/profile")
    for key, expected in (("replicas", 4), ("nodes_per_replica", 2), ("tp_size", 16), ("pp_size", 1)):
        _require(_equal(profile.get(key), expected), "profile mismatch: " + key)
    _require(profile.get("enabled_for_offline_validation") is True, "offline model validation disabled")
    _require(profile.get("gpu_candidate_enabled", True) is True, "GPU candidate explicitly disabled")
    _require(isinstance(profile.get("checkpoint"), str) and profile["checkpoint"].startswith("/"),
             "checkpoint must be an absolute path")
    _require(type(profile.get("context_length")) is int and profile["context_length"] > 0, "invalid context length")
    memory = profile.get("mem_fraction_static")
    _require(type(memory) in (int, float) and math.isfinite(memory) and 0 < memory < 1, "invalid memory fraction")
    args = profile.get("candidate_args")
    _require(isinstance(args, list) and all(isinstance(arg, str) for arg in args), "invalid candidate args")
    if model == "kimi-k3":
        expected = {
            "architecture": "KimiK3ForConditionalGeneration", "ep_size": 16,
            "reasoning_parser": "kimi_k3", "tool_call_parser": "kimi_k3",
            "chat_template_kwargs": {"thinking": True, "thinking_effort": "max"},
            "reasoning_effort": "max",
            "generation_proposal": {"temperature": 1.0, "top_p": 1.0, "top_k": -1, "min_p": 0.0},
            "candidate_args": ["--moe-runner-backend", "marlin", "--attention-backend", "fa3",
                               "--enable-deterministic-inference", "--random-seed", "42", "--enable-symm-mem"],
        }
        _require("randomness_contract" not in profile or profile["randomness_contract"] == "seed_control_candidate",
                 "K3 strict seed contract cannot be relaxed")
    else:
        expected = {
            "architecture": "GlmMoeDsaForCausalLM", "ep_size": 1,
            "gpu_candidate_enabled": True,
            "reasoning_parser": "glm45", "tool_call_parser": "glm47",
            "chat_template_kwargs": {"clear_thinking": False, "reasoning_effort": "max"},
            "reasoning_effort": "max",
            "generation_proposal": {"temperature": 1.0, "top_p": 0.95, "top_k": -1, "min_p": 0.0},
            "randomness_contract": "seed_labels_only",
            "initialization_seeds": list(GLM_INITIALIZATION_SEEDS),
            "candidate_args": ["--sampling-backend", "flashinfer", "--quantization", "fp8"],
        }
    for key, value in expected.items():
        _require(_equal(profile.get(key), value), "profile mismatch: " + key)
    return profile


def profile_sha256(model, profile):
    validate_profile(model, profile)
    return hashlib.sha256(json.dumps({"model": model, "profile": profile},
                                    sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def randomness_contract(model, profile):
    validate_profile(model, profile)
    return "seed_control_candidate" if model == "kimi-k3" else "seed_labels_only"


def expected_metadata(model, profile, replica):
    validate_profile(model, profile)
    _require(type(replica) is int and 0 <= replica < profile["replicas"], "invalid replica index")
    if model == "kimi-k3":
        # Preserve exactly the original router's K3 metadata predicate.
        return {"enable_deterministic_inference": True, "sampling_backend": "pytorch"}
    return {
        "model_path": profile["checkpoint"], "served_model_name": model,
        "tp_size": profile["tp_size"], "ep_size": profile["ep_size"],
        "pp_size": 1, "dp_size": 1,
        "nnodes": profile["nodes_per_replica"], "context_length": profile["context_length"],
        "reasoning_parser": profile["reasoning_parser"], "tool_call_parser": profile["tool_call_parser"],
        "enable_deterministic_inference": False, "sampling_backend": "flashinfer",
        "attention_backend": "dsa", "dsa_prefill_backend": "flashmla_sparse",
        "dsa_decode_backend": "fa3", "dsa_topk_backend": "sgl-kernel",
        "prefill_attention_backend": None, "decode_attention_backend": None,
        "quantization": "fp8", "kv_cache_dtype": "bfloat16",
        "random_seed": profile["initialization_seeds"][replica],
    }


def check_metadata(model, profile, replica, data, model_info=None):
    expected = expected_metadata(model, profile, replica)
    if not isinstance(data, dict):
        return {"passed": False, "errors": ["server_info is not an object"], "observed": {}}
    errors = ["missing_or_mismatched:" + key for key, value in expected.items()
              if key not in data or not _equal(data[key], value)]
    if model == "glm-5.3":
        states = data.get("internal_states")
        if not isinstance(states, list) or len(states) != 1 or not isinstance(states[0], dict):
            errors.append("missing_or_mismatched:internal_states")
        else:
            errors += ["internal_state_missing_or_mismatched:" + key for key, value in expected.items()
                       if key not in states[0] or not _equal(states[0][key], value)]
        expected_model = {"model_path": profile["checkpoint"], "architectures": [profile["architecture"]],
                          "is_generation": True}
        if not isinstance(model_info, dict):
            errors.append("missing_or_mismatched:model_info")
        else:
            errors += ["model_info_missing_or_mismatched:" + key for key, value in expected_model.items()
                       if key not in model_info or not _equal(model_info[key], value)]
    return {"passed": not errors, "errors": errors,
            "observed": {key: data.get(key) for key in expected},
            "randomness_contract": randomness_contract(model, profile),
            "seed_control_verified": False, "real_model_acceptance": False}


def validate_deployment(deployment):
    _require(isinstance(deployment, dict), "deployment is not an object")
    model, profile = deployment.get("model"), deployment.get("profile")
    digest = profile_sha256(model, profile)
    _require(deployment.get("profile_contract_sha256") == digest, "deployment/profile hash mismatch")
    replicas = deployment.get("replicas")
    _require(isinstance(replicas, list) and len(replicas) == profile["replicas"], "deployment must contain all four replicas")
    seen = set()
    urls = set()
    for replica in replicas:
        _require(isinstance(replica, dict), "invalid deployment replica")
        index = replica.get("replica")
        _require(type(index) is int and 0 <= index < profile["replicas"] and index not in seen,
                 "invalid/duplicate deployment replica")
        seen.add(index)
        _require(isinstance(replica.get("url"), str) and replica["url"].startswith("http://"),
                 "invalid deployment replica URL")
        _require(replica["url"] not in urls, "duplicate deployment replica URL")
        urls.add(replica["url"])
    return model, profile


SOURCE_FILES = ("model_profiles.json", "profile_contract.py", "serve_node.py",
                "phase_8nodes.sbatch", "phase_controller.py", "router.py",
                "runtime.sh", "hardware_preflight.py", "checkpoint_preflight.py",
                "phase_common.py", "queue_control.py", "gpu_import_validation.py")


def verify_deployment_sources(base, deployment):
    sources = deployment.get("source_sha256")
    _require(isinstance(sources, dict) and set(SOURCE_FILES).issubset(sources),
             "deployment source binding incomplete")
    for name in SOURCE_FILES:
        actual = hashlib.sha256((Path(base) / name).read_bytes()).hexdigest()
        _require(sources[name] == actual, "deployment source changed: " + name)


def build_command(base, model, profile, replica, rank, head_ip):
    validate_profile(model, profile)
    _require(type(replica) is int and 0 <= replica < 4, "invalid replica index")
    _require(type(rank) is int and rank in (0, 1), "invalid node rank")
    # Argument order/text remains byte-for-byte identical to K3's old launcher.
    command = [str(Path(base) / "environments/k3_glm/.venv/bin/sglang"), "serve",
               "--model-path", profile["checkpoint"], "--served-model-name", model,
               "--trust-remote-code", "--tp-size", str(profile["tp_size"]),
               "--ep-size", str(profile["ep_size"]), "--nnodes", str(profile["nodes_per_replica"]),
               "--node-rank", str(rank), "--dist-init-addr", f"{head_ip}:{50240 + replica}",
               "--reasoning-parser", profile["reasoning_parser"],
               "--tool-call-parser", profile["tool_call_parser"],
               "--context-length", str(profile["context_length"]),
               "--mem-fraction-static", str(profile["mem_fraction_static"]),
               "--max-running-requests", "64", "--cuda-graph-max-bs-decode", "64",
               "--enable-metrics", "--host", "0.0.0.0", "--port", "30240",
               *profile["candidate_args"]]
    if model == "glm-5.3":
        command += ["--random-seed", str(profile["initialization_seeds"][replica])]
    return command
