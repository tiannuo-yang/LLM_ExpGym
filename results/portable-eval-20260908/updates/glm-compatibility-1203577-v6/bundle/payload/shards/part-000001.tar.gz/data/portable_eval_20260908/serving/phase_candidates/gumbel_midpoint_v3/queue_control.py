#!/usr/bin/env python3
"""Publish one explicit lifecycle intent; does not create scientific/model GO."""
import argparse
import json
import os
from pathlib import Path
import tempfile

from phase_common import digest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--sequence", type=int, required=True)
    parser.add_argument("--action", choices=("load", "stop", "finish"), required=True)
    parser.add_argument("--phase", choices=("glm_compatibility", "k3_formal", "glm_formal"))
    parser.add_argument("--root-reference", type=Path, required=True)
    parser.add_argument("--root-reference-sha256", required=True)
    args = parser.parse_args()
    if digest(args.root_reference) != args.root_reference_sha256 or not args.root_reference.is_absolute():
        raise SystemExit("ROOT reference mismatch")
    allocation = json.loads((args.run / "allocation.json").read_text())
    if args.sequence < 1 or ((args.action == "load") != bool(args.phase)):
        raise SystemExit("invalid lifecycle action")
    command = {"job_id": allocation["job_id"], "sequence": args.sequence,
               "action": args.action, "phase": args.phase,
               "root_reference": str(args.root_reference), "root_reference_sha256": args.root_reference_sha256}
    directory = args.run / "commands"
    fd, temporary = tempfile.mkstemp(prefix=".publishing-", dir=directory)
    try:
        with os.fdopen(fd, "w") as handle:
            json.dump(command, handle, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        # No overwrite. Atomic publication after complete write, same directory.
        target = directory / ("%04d.json" % args.sequence)
        os.link(temporary, target)
        os.unlink(temporary)
        directory_fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
        # Reader waits for this marker, never observes the temporary two-link
        # publication state. A crash beforehand leaves an unconsumed command.
        with (directory / ("%04d.ready" % args.sequence)).open("x"):
            pass
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    print(str(target))


if __name__ == "__main__":
    main()
