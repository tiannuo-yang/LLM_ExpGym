"""Real single-GPU dependency imports; no model/server/generation entrypoint.

Trusted installed packages execute normal bootstrap code, including CUDA queries
and decorators. Offline variables are not proof of absence of all network I/O.
"""
import argparse
import importlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time

from phase_common import RUNTIME, VENV, digest, read_regular, utc, write_new
from hardware_preflight import _uuid

SITE = VENV / "lib/python3.12/site-packages"
MODULES = ("torch", "transformers", "sglang", "sglang.srt.entrypoints.openai.protocol",
           "sglang.srt.function_call.function_call_parser", "sglang.srt.function_call.kimik3_detector",
           "sglang.srt.function_call.glm47_moe_detector", "sglang.srt.server_args")
DEPENDENCIES = ("flashinfer", "sgl_kernel")


def expected_sources(report):
    if not (report.get("passed") is True and type(report.get("validation_version")) is int
            and report["validation_version"] == 6 and report.get("candidate") == str(RUNTIME)
            and report.get("cpu_only_two_imports") is True
            and report.get("all_eight_imports_passed") is False
            and report.get("gpu_import_validation_required_before_model_load") is True):
        raise ValueError("accepted version-6 CPU-only runtime evidence required")
    rows = report.get("required_gpu_imports", [])
    if [r.get("module") for r in rows] != list(MODULES):
        raise ValueError("all eight exact required GPU imports must be declared")
    expected = {}
    for row in rows:
        path = Path(row["path"])
        if not path.is_absolute() or not path.is_relative_to(SITE) or digest(path) != row["source_sha256"]:
            raise ValueError("required import source mismatch")
        expected[row["module"]] = {"path": str(path), "sha256": row["source_sha256"]}
    for name in DEPENDENCIES:
        path = SITE / name / "__init__.py"
        expected[name] = {"path": str(path), "sha256": digest(path)}
    return expected


def import_one(name, expected):
    module = importlib.import_module(name)
    path = Path(module.__file__).absolute()
    observed = {"module": name, "path": str(path), "sha256": digest(path), "import_completed": True}
    if str(path) != expected["path"] or observed["sha256"] != expected["sha256"]:
        raise ValueError("actual imported source mismatch: " + name)
    return module, observed


def cuda_observation(torch, expected_uuid):
    prop = torch.cuda.get_device_properties(0)  # Real CUDA initialization, never a stub.
    observed = {"visible_device_count": torch.cuda.device_count(), "current_device": torch.cuda.current_device(),
                "initialized": torch.cuda.is_initialized(), "raw_gpu_uuid": str(prop.uuid),
                "gpu_uuid": _uuid(str(prop.uuid)), "name": prop.name,
                "capability": list(torch.cuda.get_device_capability(0)), "total_memory_bytes": prop.total_memory}
    if not (observed["initialized"] is True and observed["visible_device_count"] == 1
            and observed["current_device"] == 0 and observed["gpu_uuid"] == _uuid(expected_uuid)
            and "H200" in observed["name"]):
        raise ValueError("CUDA state does not match the single allocated GPU UUID")
    return observed


def memory(uuid):
    command = ["nvidia-smi", "-i", uuid, "--query-gpu=uuid,name,memory.total,memory.used,memory.free", "--format=csv,noheader,nounits"]
    proc = subprocess.run(command, capture_output=True, check=False, timeout=30)
    if proc.returncode != 0:
        raise RuntimeError("nvidia-smi inventory failed")
    fields = [x.strip() for x in proc.stdout.decode().strip().split(",")]
    if len(fields) != 5 or fields[0].lower() != uuid.lower() or "H200" not in fields[1]:
        raise ValueError("GPU memory inventory mismatch")
    return {"argv": command, "stdout": proc.stdout.decode(), "uuid": fields[0], "name": fields[1],
            "total_mib": int(fields[2]), "used_mib": int(fields[3]), "free_mib": int(fields[4])}


def check_result(receipt, job, node, uuid, runtime_sha):
    canonical = _uuid(uuid)
    if not (receipt.get("passed") is True and receipt.get("job_id") == job and receipt.get("node") == node
            and receipt.get("runtime_receipt_sha256") == runtime_sha
            and receipt.get("gpu_uuid") == canonical
            and receipt.get("source_files_unchanged") is True):
        raise ValueError("GPU import receipt identity/finality mismatch")
    for key, names in (("modules", MODULES), ("required_dependencies", DEPENDENCIES)):
        if [row.get("module") for row in receipt.get(key, [])] != list(names):
            raise ValueError("GPU import receipt incomplete: " + key)
        if not all(row.get("import_completed") is True for row in receipt[key]):
            raise ValueError("GPU import did not complete: " + key)
    for key in ("cuda_before_dependency_imports", "cuda_after_imports"):
        state = receipt.get(key, {})
        if not (state.get("initialized") is True and state.get("visible_device_count") == 1
                and state.get("current_device") == 0 and state.get("gpu_uuid") == canonical
                and _uuid(state.get("raw_gpu_uuid")) == canonical):
            raise ValueError("real single-GPU CUDA state is required")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for flag in ("expected-job-id", "expected-node", "expected-gpu-uuid", "runtime-sha256"):
        parser.add_argument("--" + flag, required=True)
    parser.add_argument("--runtime-receipt", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if (os.environ.get("SLURM_JOB_ID") != args.expected_job_id
            or os.environ.get("SLURMD_NODENAME") != args.expected_node
            or socket.gethostname().split(".")[0] != args.expected_node.split(".")[0]
            or Path(sys.executable).absolute() != VENV / "bin/python"):
        raise ValueError("owned node/job/new interpreter mismatch")
    args.output.mkdir(parents=True, exist_ok=False)
    receipt = {"schema": "real-single-gpu-import-validation-v1", "passed": False, "started_utc": utc(),
               "job_id": args.expected_job_id, "step_id": os.environ.get("SLURM_STEP_ID"), "node": args.expected_node,
               "gpu_uuid": args.expected_gpu_uuid, "runtime_receipt": str(args.runtime_receipt),
               "runtime_receipt_sha256": args.runtime_sha256, "interpreter": str(sys.executable),
               "script_sha256": digest(Path(__file__)), "modules": [], "required_dependencies": [],
               "model_generation_explicitly_called": False, "model_loaded_by_script": False,
               "dependency_network_or_subprocess_behavior_fully_audited": False}
    started = time.monotonic()
    try:
        if digest(args.runtime_receipt) != args.runtime_sha256:
            raise ValueError("runtime receipt bytes changed")
        expected = expected_sources(json.loads(read_regular(args.runtime_receipt)))
        receipt["expected_sources"] = expected
        receipt["memory_before"] = memory(args.expected_gpu_uuid)
        if receipt["memory_before"]["free_mib"] < 8192:
            raise ValueError("less than approved 8 GiB free before imports")
        # Replace, do not inherit the CPU validator's empty visibility setting.
        os.environ["CUDA_VISIBLE_DEVICES"] = args.expected_gpu_uuid
        settings = {"CUDA_VISIBLE_DEVICES": args.expected_gpu_uuid, "HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1"}
        for key, folder in (("FLASHINFER_WORKSPACE_BASE", "flashinfer"), ("TRITON_CACHE_DIR", "triton"),
                            ("TORCHINDUCTOR_CACHE_DIR", "inductor"), ("CUDA_CACHE_PATH", "cuda"),
                            ("TORCH_EXTENSIONS_DIR", "extensions"), ("XDG_CACHE_HOME", "xdg"),
                            ("HF_MODULES_CACHE", "hf_modules"), ("TMPDIR", "tmp")):
            directory = args.output / folder
            directory.mkdir()
            settings[key] = str(directory)
        os.environ.update(settings)
        receipt["explicit_environment"] = settings  # Only these code-owned non-secret values.
        torch, item = import_one("torch", expected["torch"])
        receipt["modules"].append(item)
        receipt["torch_version"] = torch.__version__
        receipt["cuda_build_version"] = torch.version.cuda
        receipt["cuda_before_dependency_imports"] = cuda_observation(torch, args.expected_gpu_uuid)
        for name in MODULES[1:]:
            _, item = import_one(name, expected[name])
            receipt["modules"].append(item)
        # SGLang catches optional dependency exceptions; explicitly require both.
        for name in DEPENDENCIES:
            _, item = import_one(name, expected[name])
            receipt["required_dependencies"].append(item)
        receipt["cuda_after_imports"] = cuda_observation(torch, args.expected_gpu_uuid)
        receipt["memory_after_with_context_alive"] = memory(args.expected_gpu_uuid)
        receipt["torch_peak_allocated_bytes"] = torch.cuda.max_memory_allocated(0)
        receipt["torch_peak_reserved_bytes"] = torch.cuda.max_memory_reserved(0)
        receipt["source_files_unchanged"] = all(digest(Path(v["path"])) == v["sha256"] for v in expected.values())
        receipt["passed"] = True
        check_result(receipt, args.expected_job_id, args.expected_node, args.expected_gpu_uuid, args.runtime_sha256)
    except Exception as exc:
        receipt["passed"] = False
        receipt["error_type"] = type(exc).__name__
        receipt["error"] = str(exc)  # Trusted package traceback is also retained by the controller.
        import traceback
        traceback.print_exc()
    receipt.update(finished_utc=utc(), elapsed_seconds=time.monotonic() - started)
    write_new(args.output / "receipt.json", receipt)
    print(json.dumps({"passed": receipt["passed"], "receipt": str(args.output / "receipt.json"), "sha256": digest(args.output / "receipt.json")}))
    return 0 if receipt["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
