#!/usr/bin/env python3
"""Read-only safetensors/index audit; writes evidence only to a new output path.

Checks file structure and indexed tensor ownership, not tensor payload values or
their authenticity. Reads headers, never loads weights or imports GPU packages.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import struct
from datetime import datetime, timezone
from pathlib import Path


MODELS = ("Kimi-K3", "GLM-5.3", "Qwen3.8-2.4T-A95B-FP8")
METADATA = ("config.json", "generation_config.json", "tokenizer_config.json",
            "tokenizer.json", "chat_template.jinja", "README.md",
            "tokenization_kimi.py", "encoding_k3.py", "model.safetensors.index.json")
DTYPE_BITS = {"BOOL": 8, "U8": 8, "I8": 8, "F8_E4M3": 8, "F8_E5M2": 8,
              "F8_E4M3FN": 8, "F8_E8M0": 8, "F8_E8M0FNU": 8, "I16": 16,
              "U16": 16, "F16": 16, "BF16": 16, "I32": 32, "U32": 32,
              "F32": 32, "F64": 64, "I64": 64, "U64": 64}


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def header_audit(path: Path, expected: set[str]) -> dict:
    before = path.stat()
    errors: list[str] = []
    with path.open("rb") as fh:
        prefix = fh.read(8)
        if len(prefix) != 8:
            raise ValueError("missing safetensors header length")
        size = struct.unpack("<Q", prefix)[0]
        if size > 256 * 1024 * 1024 or size > before.st_size - 8:
            raise ValueError(f"invalid/oversized header length {size}")
        raw = fh.read(size)
    header = json.loads(raw)
    names = set(header) - {"__metadata__"}
    if names != expected:
        errors.append(f"index/header mismatch: missing={len(expected - names)}, extra={len(names - expected)}")
    intervals = []
    unknown_dtypes = set()
    dtype_counts: dict[str, int] = {}
    for name in sorted(names):
        tensor = header[name]
        start, end = tensor["data_offsets"]
        shape = tensor["shape"]
        dtype = tensor["dtype"]
        dtype_counts[dtype] = dtype_counts.get(dtype, 0) + 1
        if not (isinstance(start, int) and isinstance(end, int) and 0 <= start <= end):
            errors.append(f"invalid offsets: {name}")
            continue
        if any(not isinstance(dim, int) or dim < 0 for dim in shape):
            errors.append(f"invalid shape: {name}")
            continue
        if dtype in DTYPE_BITS:
            if end - start != math.prod(shape) * DTYPE_BITS[dtype] // 8:
                errors.append(f"shape/dtype byte mismatch: {name}")
        else:
            unknown_dtypes.add(dtype)
        intervals.append((start, end, name))
    previous_end = 0
    for start, end, name in sorted(intervals):
        if start != previous_end:
            errors.append(f"non-contiguous or overlapping data before {name}")
        previous_end = end
    if before.st_size != 8 + size + previous_end:
        errors.append(f"file length mismatch: actual={before.st_size}, expected={8 + size + previous_end}")
    after = path.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        errors.append("file changed during audit")
    return {"name": path.name, "bytes": before.st_size, "mtime_ns": before.st_mtime_ns,
            "header_bytes": size, "header_sha256": hashlib.sha256(raw).hexdigest(),
            "tensor_count": len(names), "dtype_counts": dtype_counts,
            "unverified_dtypes": sorted(unknown_dtypes), "errors": errors,
            "structural_ok": not errors and not unknown_dtypes}


def audit(path: Path) -> dict:
    result = {"checkpoint": str(path), "exists": path.is_dir(), "errors": [],
              "metadata": {}, "shards": [], "weight_payload_hashed": False}
    if not path.is_dir():
        result["errors"].append("checkpoint directory missing")
        result["ready_structurally"] = False
        return result
    for name in METADATA:
        p = path / name
        if p.is_file():
            result["metadata"][name] = {"bytes": p.stat().st_size, "sha256": digest(p)}
    for name in ("config.json", "generation_config.json", "tokenizer_config.json"):
        p = path / name
        if p.is_file():
            data = json.loads(p.read_text())
            keys = ("model_type", "architectures", "tokenizer_class", "auto_map",
                    "temperature", "top_p", "top_k", "min_p", "do_sample",
                    "max_position_embeddings", "eos_token_id")
            result[name] = {k: data[k] for k in keys if k in data}
    if "tokenizer_config.json" not in result["metadata"]:
        result["errors"].append("tokenizer_config.json missing")
    index_path = path / "model.safetensors.index.json"
    result["present_safetensors_files"] = len(list(path.glob("*.safetensors")))
    result["present_safetensors_bytes"] = sum(p.stat().st_size for p in path.glob("*.safetensors"))
    if not index_path.is_file():
        result["errors"].append("model.safetensors.index.json missing; expected tensor/shard ownership cannot be established")
        result["ready_structurally"] = False
        return result
    weight_map = json.loads(index_path.read_text())["weight_map"]
    expected: dict[str, set[str]] = {}
    for name, shard in weight_map.items():
        if Path(shard).name != shard:
            raise ValueError(f"unsafe shard path in index: {shard!r}")
        expected.setdefault(shard, set()).add(name)
    result["expected_tensor_count"] = len(weight_map)
    result["expected_shard_count"] = len(expected)
    for shard, names in sorted(expected.items()):
        p = path / shard
        if not p.is_file():
            result["errors"].append(f"missing shard: {shard}")
            continue
        try:
            item = header_audit(p, names)
        except (ValueError, KeyError, OSError, TypeError) as exc:
            item = {"name": shard, "structural_ok": False, "errors": [str(exc)]}
        result["shards"].append(item)
    result["ready_structurally"] = (not result["errors"]
        and len(result["shards"]) == len(expected)
        and all(s["structural_ok"] for s in result["shards"]))
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint-parent", type=Path,
                        default=Path("/lustrefs/users/runner/chufan.shi/tau_vision/ckpts"))
    parser.add_argument("--models", nargs="+", default=MODELS)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    results = {"created_utc": datetime.now(timezone.utc).isoformat(),
               "script_sha256": digest(Path(__file__)),
               "scope": "local index, metadata hashes, every indexed safetensors header, tensor ownership, offsets and exact file lengths",
               "limitations": ["Not a full weight-payload hash or publisher authenticity check.",
                   "Structural readiness does not prove tokenizer/engine/kernel compatibility or model quality.",
                   "This is a timestamped snapshot; recheck immediately before serving."],
               "models": [audit(args.checkpoint_parent / model) for model in args.models]}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x") as fh:
        json.dump(results, fh, indent=2, sort_keys=True)
        fh.write("\n")
    for model in results["models"]:
        print(json.dumps({k: v for k, v in model.items() if k not in ("shards", "metadata")}, sort_keys=True))


if __name__ == "__main__":
    main()
