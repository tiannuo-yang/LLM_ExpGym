# GLM compatibility 1203577：计划与静态检查

范围：Static/fake validation。本操作仅按冻结development入口生成一次完整30-job计划及CPU-only dry-run；不发送nonce或任务生成请求、不读取key内容、不签GO、不修改冻结source。

当前模型glm-5.3，phase glm_compatibility，allocation 1203577。真实deployment原件为 `/lustrefs/users/chufan.shi/codex_space_tn/portable_eval_20260908/serving/phase_candidates/gumbel_midpoint_v3/runs/1203577/glm_compatibility/deployment.json`，SHA `5d6a73c5716c33745ce5315c6071857ef022d582cdfd8aee49ff81d21e1b4e95`；router URL为 `http://azure-uk-hpc-H200-instance-267:30241`。该绑定不是模型ready证据。

运行时原件严格使用 `/lustrefs/users/chufan.shi/codex_space_tn/portable_eval_20260908/serving/runtime_candidates/gumbel_midpoint_v1/manifests/validation_v6.json`，SHA `6ae2baf43591acaad1be8b4f0dfe7fc705996313d1f588ce7cb63990cb892111`，实际passed=true；不使用旧validation.json别名或失败版本。

`plan.json`绑定待未来授权的`real_run/`（该目录必须保持不存在）；`dry/`独立保存全部30条静态检查。两模型计划保留不裁剪，当前只有GLM15个task invocations属于未来GO候选。各phase固定51 task agents+12 nonce slots；GLM在后续新deployment的重复资格检查不算正式outer/repeat，不替换此次失败。

未来真实执行仍需ROOT分别绑定model_manifest、runtime、deployment、operation四原件并签有限期限GO。计划字节SHA与canonicalSHA、dry实际结果在完成后另作观察收据；本文件不是成功收据或执行授权。
