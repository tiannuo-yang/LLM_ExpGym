#!/usr/bin/env python3
"""Allocation-owned rank; reviewed model command and pre-exec hardware gate."""
import json
import os
import sys
from pathlib import Path

from hardware_preflight import check_hardware
from phase_common import BASE, check_environment
from profile_contract import build_command, validate_deployment, verify_deployment_sources


def main():
    model, replica, rank, head_ip, directory = sys.argv[1:]
    run = Path(directory)
    deployment = json.loads((run / "deployment.json").read_text())
    accepted_model, profile = validate_deployment(deployment)
    verify_deployment_sources(BASE, deployment)
    check_environment()
    if accepted_model != model or deployment["job_id"] != os.environ.get("SLURM_JOB_ID"):
        raise SystemExit("owned deployment mismatch")
    command = build_command(BASE, model, profile, int(replica), int(rank), head_ip)
    hardware = run / ("replica%s-rank%s-hardware.json" % (replica, rank))
    check_hardware(hardware)
    record = {"job_id": deployment["job_id"], "phase": deployment["phase"],
              "replica": int(replica), "rank": int(rank), "command": command,
              "hardware_receipt": str(hardware), "sampler_modified": True,
              "runtime_receipt": deployment["runtime_receipt"],
              "runtime_receipt_sha256": deployment["runtime_receipt_sha256"],
              "claim": "Loaded candidate only, real protocol/science acceptance separate"}
    with (run / ("replica%s-rank%s-launch.json" % (replica, rank))).open("x") as handle:
        json.dump(record, handle, indent=2)
        handle.write("\n")
    tag = "portable_%s_%s_%s_%s" % (deployment["job_id"], deployment["phase"], replica, rank)
    os.environ.update(TRITON_CACHE_DIR="/tmp/" + tag + "_triton",
                      HF_MODULES_CACHE="/tmp/" + tag + "_hf_modules",
                      TVM_FFI_CACHE_DIR="/tmp/" + tag + "_tvm",
                      OMP_NUM_THREADS="8", PYTHONUNBUFFERED="1")
    print(json.dumps(record), flush=True)
    os.execv(command[0], command)


if __name__ == "__main__":
    main()
