"""Exactly one explicitly authorized normal GLM stop; no load or network calls."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

HERE = Path(__file__).resolve().parent
RUN = HERE.parent
BASE = RUN.parents[1]
PHASE = RUN / "glm_compatibility"
GO = BASE / "ROOT_STOP_GLM_1203577.json"
GO_SHA = "00fa9a122dd3cb38caa8ea1d6674074ca84da8f200acd2a1ff8f99ca9758ff81"
DEPLOYMENT_SHA = "5d6a73c5716c33745ce5315c6071857ef022d582cdfd8aee49ff81d21e1b4e95"
STEMS = ["replica%d-rank%d" % (i, j) for i in range(4) for j in range(2)] + ["router"]


def utc():
    return datetime.now(timezone.utc).isoformat()


def ref(path):
    raw = path.read_bytes()
    return {"path": str(path), "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}


def save(name, value):
    raw = value if isinstance(value, bytes) else (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()
    path = HERE / name
    with path.open("xb") as f:
        f.write(raw)
        f.flush()
        os.fsync(f.fileno())
    return ref(path)


def command(name, argv):
    started = utc()
    save(name + ".command.json", {"argv": argv, "started_utc": started})
    p = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    record = {"started_utc": started, "finished_utc": utc(), "returncode": p.returncode,
              "stdout": save(name + ".stdout", p.stdout), "stderr": save(name + ".stderr", p.stderr)}
    save(name + ".exit.json", record)
    assert p.returncode == 0, name + " command failed"
    return p.stdout


def event_rows():
    return [json.loads(line) for line in (RUN / "events.jsonl").read_bytes().splitlines()]


def main():
    save("once_entry.json", {"utc": utc(), "pid": os.getpid(), "source": ref(Path(__file__))})
    receipt = {"schema": "once-root-normal-phase-stop-operator-v1", "error": None,
               "job_id": "1203577", "sequence": 2, "action": "stop", "phase": "glm_compatibility",
               "new_load_performed": False, "model_or_metadata_calls": 0}
    try:
        assert ref(GO)["sha256"] == GO_SHA
        go = json.loads(GO.read_bytes())
        assert go["job_id"] == "1203577" and go["action"] == "stop" and go["sequence"] == 2 and go["phase"] is None
        assert datetime.now(timezone.utc) < datetime.fromisoformat(go["expires_start_utc"].replace("Z", "+00:00"))
        for item in go["evidence"].values():
            assert ref(Path(item["path"]))["sha256"] == item["sha256"]
        allocation = json.loads((RUN / "allocation.json").read_bytes())
        source_refs = {name: ref(BASE / name) for name in allocation["source_sha256"]}
        assert len(source_refs) == 12
        assert all(source_refs[name]["sha256"] == sha for name, sha in allocation["source_sha256"].items())
        assert ref(PHASE / "deployment.json")["sha256"] == DEPLOYMENT_SHA
        assert not (RUN / "commands/0002.json").exists() and not (RUN / "commands/0002.ready").exists()
        assert not (RUN / "k3_formal").exists()
        events = event_rows()
        assert [e["command"]["sequence"] for e in events if e["kind"] == "operator_command_consumed"] == [1]
        assert events[-1]["kind"] == "load_started_not_ready" and events[-1]["phase"] == "glm_compatibility"
        raw_job = command("pre_job", ["scontrol", "show", "job", "-o", "1203577"])
        fields = dict(p.split("=", 1) for p in raw_job.decode().split() if "=" in p)
        assert fields["JobId"] == "1203577" and fields["JobState"] == "RUNNING"
        assert fields["UserId"] == "chufan.shi(1071)" and fields["Account"] == "k2p"
        assert fields["NumNodes"] == "8" and "gres/gpu=64" in fields["AllocTRES"]
        assert fields["Command"] == str(BASE / "phase_8nodes.sbatch")
        raw_steps = command("pre_steps", ["squeue", "-h", "--steps", "-j", "1203577", "-o", "%i %j %N"])
        expected_steps = {"1203577.%d" % i for i in range(18, 27)}
        assert expected_steps <= {line.split()[0] for line in raw_steps.decode().splitlines()}
        receipt["preconditions"] = save("preconditions.json", {"root_reference": ref(GO), "evidence": go["evidence"],
            "sources": source_refs, "deployment": ref(PHASE / "deployment.json"),
            "controller_before": ref(RUN / "events.jsonl"), "router_requests_before": ref(PHASE / "router_requests.jsonl")})
        command("stop", ["python3", "-B", str(BASE / "queue_control.py"), "--run", str(RUN),
            "--sequence", "2", "--action", "stop", "--root-reference", str(GO), "--root-reference-sha256", GO_SHA])
        print(json.dumps({"stop_command_published": True, "utc": utc()}), flush=True)
        deadline = time.monotonic() + 170
        poll_index = 0
        while True:
            events = event_rows()
            failures = [e for e in events if any(s in e["kind"] for s in ("failed", "failure", "timeout", "unexpected", "owned_process_exited"))]
            assert not failures, "controller failure; no escalation or retry"
            stopped = [e for e in events if e["kind"] == "phase_stop_observed" and e.get("reason") == "explicit_ROOT_operator_stop"]
            if stopped and stopped[-1]["remaining_children"] == 0:
                assert all((PHASE / (stem + ".exit.json")).exists() for stem in STEMS)
                raw_steps = command("post_steps_%02d" % poll_index, ["squeue", "-h", "--steps", "-j", "1203577", "-o", "%i %j %N"])
                poll_index += 1
                if not expected_steps.intersection(line.split()[0] for line in raw_steps.decode().splitlines()):
                    receipt["phase_stop_observed"] = stopped[-1]
                    break
            assert time.monotonic() < deadline, "stop observation deadline; no forced action"
            time.sleep(2)
        command("post_job", ["scontrol", "show", "job", "-o", "1203577"])
        closed = [PHASE / (stem + suffix) for stem in STEMS for suffix in (".log", ".exit.json", ".command.json")]
        closed += [PHASE / "deployment.json", PHASE / "router_requests.jsonl", RUN / "commands/0002.json", RUN / "commands/0002.ready"]
        receipt["closed_originals"] = save("closed_originals.json", {"files": [ref(p) for p in closed],
            "sources": source_refs, "controller_prefix_after": ref(RUN / "events.jsonl")})
        receipt["all_nine_original_exit_receipts"] = [ref(PHASE / (stem + ".exit.json")) for stem in STEMS]
        receipt["all_original_steps_absent"] = True
        receipt["source_unchanged"] = all(ref(BASE / name)["sha256"] == sha for name, sha in allocation["source_sha256"].items())
    except BaseException as exc:
        receipt["error"] = type(exc).__name__
        raise
    finally:
        receipt["finished_utc"] = utc()
        receipt["limitation"] = "Local srun exit plus step absence is operational teardown, not a substitute for ROOT caller/provider drain or a bytewise KV/device-process attestation. Allocation remains owned; sequence3 requires new GO."
        print(json.dumps(save("receipt.json", receipt)), flush=True)


if __name__ == "__main__":
    main()
