#!/usr/bin/env bash
# New independent runtime only; no old environment modifications.
PORTABLE_SERVING=/lustrefs/users/chufan.shi/codex_space_tn/portable_eval_20260908/serving/phase_candidates/gumbel_midpoint_v3
PORTABLE_VENV=/lustrefs/users/chufan.shi/codex_space_tn/portable_eval_20260908/serving/runtime_candidates/gumbel_midpoint_v1/.venv
PORTABLE_SITE="$PORTABLE_VENV/lib/python3.12/site-packages"
PORTABLE_LIBS="$PORTABLE_SITE/torch/lib:$PORTABLE_SITE/tvm_ffi/lib"
for portable_vendor_lib in "$PORTABLE_SITE"/nvidia/*/lib; do
  if [[ -d "$portable_vendor_lib" ]]; then PORTABLE_LIBS="$portable_vendor_lib:$PORTABLE_LIBS"; fi
done
export LD_LIBRARY_PATH="$PORTABLE_LIBS${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export LIBRARY_PATH="$PORTABLE_SITE/nvidia/nccl/lib${LIBRARY_PATH:+:$LIBRARY_PATH}"
export PATH="$PORTABLE_VENV/bin:$PATH"
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 TOKENIZERS_PARALLELISM=false
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export HF_MODULES_CACHE="${PORTABLE_HF_MODULES_CACHE:-$PORTABLE_SERVING/cache/hf_modules}"
unset PYTHONPATH
