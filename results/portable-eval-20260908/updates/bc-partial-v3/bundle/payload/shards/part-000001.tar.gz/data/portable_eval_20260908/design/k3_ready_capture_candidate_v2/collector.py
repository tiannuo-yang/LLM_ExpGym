"""One-shot fixed K3 metadata capture. No model generation or evidence approval."""
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import socket
import stat
from urllib.error import HTTPError
from urllib.request import HTTPRedirectHandler, ProxyHandler, Request, build_opener


HERE = Path(__file__).resolve().parent
STUDY = HERE.parents[1]
DEPLOYMENT_PATH = STUDY / "serving/runs/1203474/deployment.json"
DEPLOYMENT_SHA = "328817157dc7005f8332cac718b4694b1f87129094e32cd99de91077edf72dc3"
ROUTER_SOURCE_SHA = "ac49e499c311a3c505b8e53b772d9e64ee7e5d954ad4ff7523afb49c19892987"
FINALIZER_SOURCE_SHA = "c285b23e3394a1881210ebf179de9002e31d73ab022dbc2a0ed8d8b11b11c03c"
KEY_PATH = STUDY / "serving/runs/1203474/private/router_api_key"
ENDPOINT = "http://azure-uk-hpc-H200-instance-267:30241/v1"
URLS = ("http://azure-uk-hpc-H200-instance-267:30241/health",) + tuple(
    "http://azure-uk-hpc-H200-instance-%d:30240/server_info" % node for node in (267, 269, 271, 273))
TIMEOUT_SECONDS = 15
MAX_BODY_BYTES = 2 * 1024 * 1024
GATE_FIELDS = {"schema_version", "approved", "stage", "evidence_kind", "deployment_sha256",
               "collector_sha256", "output_dir", "not_before_utc", "expires_utc",
               "BC_drain_reviewed_by_ROOT"}


def require(condition, code):
    if not condition:
        raise ValueError(code)


def sha(raw):
    require(type(raw) is bytes, "immutable_bytes_required")
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n").encode("utf-8")


def parse(raw):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "duplicate_json_key")
            result[key] = value
        return result
    def finite(text):
        value = float(text)
        require(math.isfinite(value), "nonfinite_json")
        return value
    def invalid(_):
        raise ValueError("nonfinite_json")
    value = json.loads(raw, object_pairs_hook=unique, parse_float=finite, parse_constant=invalid)
    require(type(value) is dict, "json_object_required")
    return value


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def moment(text):
    require(type(text) is str, "UTC_required")
    value = datetime.fromisoformat(text.replace("Z", "+00:00"))
    require(value.tzinfo is not None and value.utcoffset().total_seconds() == 0, "UTC_required")
    return value.timestamp()


def no_symlink_path(path):
    require(path.is_absolute() and ".." not in path.parts, "absolute_unaliased_path_required")
    for parent in [path] + list(path.parents):
        require(not stat.S_ISLNK(parent.lstat().st_mode), "symlink_path_forbidden")


def read_key():
    """Future real call only. Never hash, serialize or print key contents."""
    no_symlink_path(KEY_PATH.parent)
    fd = os.open(str(KEY_PATH), os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        info = os.fstat(fd)
        require(stat.S_ISREG(info.st_mode) and stat.S_IMODE(info.st_mode) == 0o600 and
                info.st_uid == os.getuid() and info.st_nlink == 1, "unsafe_key_file")
        with os.fdopen(fd, "rb", closefd=False) as stream:
            raw = stream.read(4097)
        require(len(raw) <= 4096, "unsafe_key_file")
        key = raw.strip()
        require(re.fullmatch(rb"[A-Za-z0-9_-]{32,256}", key) is not None, "unsafe_key_material")
        return key
    finally:
        os.close(fd)


class NoRedirect(HTTPRedirectHandler):
    def http_error_302(self, request, fp, code, msg, headers):
        # Intercept before urllib parses Location: preserve original URL/status/body.
        raise HTTPError(request.full_url, code, msg, headers, fp)

    http_error_301 = http_error_303 = http_error_307 = http_error_308 = http_error_302

    def redirect_request(self, request, fp, code, msg, headers, newurl):
        return None


def real_opener():
    # Explicit empty ProxyHandler suppresses environment proxy configuration.
    return build_opener(ProxyHandler({}), NoRedirect())


class ExclusiveOutput:
    def __init__(self, path):
        no_symlink_path(path.parent)
        self.path = path
        expected_parent = path.parent.stat()
        parent_fd = os.open(str(path.parent), os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            actual_parent = os.fstat(parent_fd)
            require((expected_parent.st_dev, expected_parent.st_ino) == (actual_parent.st_dev, actual_parent.st_ino),
                    "output_parent_identity_changed")
            os.mkdir(path.name, mode=0o700, dir_fd=parent_fd)
            self.fd = os.open(path.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent_fd)
        finally:
            os.close(parent_fd)

    def write(self, name, raw):
        require(re.fullmatch(r"[a-z0-9_.-]+", name) is not None, "unsafe_output_name")
        fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=self.fd)
        with os.fdopen(fd, "wb") as stream:
            stream.write(raw)
        return {"path": str(self.path / name), "sha256": sha(raw)}

    def close(self):
        os.close(self.fd)


def preflight(output_dir, gate_bytes, gate_sha256, expected_source_sha256, deployment_bytes, kind, now):
    require(sha(gate_bytes) == gate_sha256, "external_gate_pin_mismatch")
    gate = parse(gate_bytes)
    require(set(gate) == GATE_FIELDS and gate["schema_version"] == "k3-ready-capture-root-gate-v1",
            "exact_small_ROOT_gate_required")
    require(gate["approved"] is True and gate["stage"] in ("G6_after_BC_drain", "incident_partial_post_drain") and
            gate["BC_drain_reviewed_by_ROOT"] is True and gate["evidence_kind"] == kind,
            "ROOT_collection_gate_not_approved")
    source = Path(__file__).read_bytes()
    require(sha(source) == expected_source_sha256 == gate["collector_sha256"], "collector_source_pin_mismatch")
    require(sha(deployment_bytes) == DEPLOYMENT_SHA == gate["deployment_sha256"], "fixed_deployment_pin_mismatch")
    deployment = parse(deployment_bytes)
    require(deployment["model"] == "kimi-k3" and deployment["job_id"] == "1203474" and
            deployment["base_url"] == ENDPOINT and deployment["router_api_key_file"] == str(KEY_PATH) and
            deployment["source_sha256"]["router.py"] == ROUTER_SOURCE_SHA, "fixed_deployment_identity_mismatch")
    require([deployment["router_url"] + "/health"] + [r["url"] + "/server_info" for r in deployment["replicas"]]
            == list(URLS), "fixed_five_URLs_mismatch")
    output = Path(output_dir)
    require(output.is_absolute() and ".." not in output.parts and str(output) == gate["output_dir"], "output_gate_mismatch")
    if kind == "real_observation":
        require(output.parent == STUDY / "serving/reports" and
                re.fullmatch(r"ready_capture_[A-Za-z0-9_-]+", output.name) is not None,
                "real_output_scope_mismatch")
    else:
        require(any(part.startswith("SYNTHETIC_") for part in output.parts), "synthetic_output_namespace_required")
    begin, end = moment(gate["not_before_utc"]), moment(gate["expires_utc"])
    require(begin <= moment(now) <= end and 0 < end - begin <= 300, "collection_gate_time_window")
    return output, gate


def _collect(output_dir, gate_bytes, gate_sha256, expected_source_sha256, deployment_bytes,
             *, kind, opener_factory, key_reader, clock):
    started = clock()
    output, gate = preflight(output_dir, gate_bytes, gate_sha256, expected_source_sha256,
                             deployment_bytes, kind, started)
    # Before credentials/network, exclusive creation must succeed. No prior files overwritten.
    writer = ExclusiveOutput(output)
    records, key = [], None
    receipt = {"schema_version": "k3-ready-capture-collection-receipt-v1", "evidence_kind": kind,
               "collection_stage": gate["stage"], "formal_G6_collection": gate["stage"] == "G6_after_BC_drain",
               "observed_started_utc": started, "complete_five_observations": False,
               "observations_accepted": False, "drained_verified_by_collector": False,
               "ready_acceptance_created": False, "real_authorized": False,
               "model_generation_calls": 0, "request_attempts": 0, "retry_attempts": 0,
               "failure_code": None, "responses": records, "capture": None}
    try:
        key = key_reader()
        require(type(key) is bytes and re.fullmatch(rb"[A-Za-z0-9_-]{32,256}", key) is not None,
                "unsafe_key_material")
        require(key not in gate_bytes and key not in str(output).encode(), "secret_in_input_metadata")
        gate_ref = writer.write("root_collection_gate.json", gate_bytes)
        receipt["root_collection_gate"] = gate_ref
        receipt["collector_source"] = {"path": str(Path(__file__).resolve()), "sha256": expected_source_sha256}
        receipt["deployment"] = {"path": str(DEPLOYMENT_PATH), "sha256": DEPLOYMENT_SHA}
        opener = opener_factory()
        for index, url in enumerate(URLS):
            require(moment(gate["not_before_utc"]) <= moment(clock()) <= moment(gate["expires_utc"]), "collection_gate_time_window")
            headers = {"Authorization": "Bearer " + key.decode("ascii")} if index == 0 else {}
            request = Request(url, headers=headers, method="GET")
            row = {"method": "GET", "url": url, "http_status": None, "body": None, "parsed_json": None,
                   "observed_started_utc": clock(), "observed_finished_utc": None}
            if index:
                row["replica"] = index - 1
            require(moment(started) <= moment(row["observed_started_utc"]) <= moment(gate["expires_utc"]),
                    "collection_gate_time_window")
            records.append(row)
            receipt["request_attempts"] += 1
            response = None
            try:
                try:
                    response = opener.open(request, timeout=TIMEOUT_SECONDS)
                except HTTPError as error:
                    response = error  # Retain safe original error body; never follow/retry.
                require(response.geturl() == url, "redirect_or_URL_change_forbidden")
                status = response.getcode()
                require(type(status) is int and 100 <= status <= 599, "invalid_HTTP_status")
                row["http_status"] = status
                raw = response.read(MAX_BODY_BYTES + 1)
                require(type(raw) is bytes and len(raw) <= MAX_BODY_BYTES, "body_size_or_type_limit")
                require(key not in raw, "secret_reflected_body_suppressed")
                ascii_unescaped = re.sub(rb"\\u00([0-9A-Fa-f]{2})", lambda m: bytes([int(m.group(1), 16)]), raw)
                require(key not in ascii_unescaped, "secret_reflected_body_suppressed")
                # Error bodies need not be JSON objects; JSON also permits UTF-16/32.
                for encoding in ("utf-8", "utf-16-le", "utf-16-be", "utf-32-le", "utf-32-be"):
                    try:
                        text = raw.decode(encoding)
                    except UnicodeError:
                        continue
                    text = re.sub(r"\\u00([0-9A-Fa-f]{2})", lambda m: chr(int(m.group(1), 16)), text)
                    require(key.decode("ascii") not in text, "secret_reflected_body_suppressed")
                try:
                    body = parse(raw)
                except (ValueError, UnicodeError):
                    body = None
                # Detect valid JSON escaping of the same key before hashing/writing.
                require(body is None or key not in encoded(body), "secret_reflected_body_suppressed")
                row["body"] = writer.write("router.body.json" if index == 0 else "meta%d.body.json" % (index - 1), raw)
                row["parsed_json"] = body
                require(status == 200, "non_200_response_no_retry")
                require(body is not None, "invalid_JSON_body_no_retry")
            finally:
                row["observed_finished_utc"] = clock()
                if response is not None:
                    response.close()
        finished = clock()
        require(moment(started) <= moment(finished) <= moment(gate["expires_utc"]), "collection_gate_time_window")
        capture = {"schema_version": "k3-nongenerating-ready-capture-v1", "evidence_kind": kind,
                   "collection_stage": gate["stage"], "formal_G6_collection": receipt["formal_G6_collection"],
                   "model_id": "kimi-k3", "deployment_id": "slurm:1203474", "endpoint": ENDPOINT,
                   "observed_started_utc": started, "observed_finished_utc": finished,
                   "router": records[0], "replica_metadata": records[1:],
                   "root_collection_gate": gate_ref, "collector_source": receipt["collector_source"]}
        if kind == "synthetic_fixture":
            capture["fixture_only_not_real_health"] = True
        receipt["capture"] = writer.write("capture.json", encoded(capture))
        receipt["complete_five_observations"] = True
    except Exception as error:
        # Do not persist exception text/type names controlled by a remote endpoint.
        allowed = {"unsafe_key_file", "unsafe_key_material", "secret_in_input_metadata", "collection_gate_time_window",
                   "redirect_or_URL_change_forbidden", "invalid_HTTP_status", "body_size_or_type_limit",
                   "secret_reflected_body_suppressed", "non_200_response_no_retry", "invalid_JSON_body_no_retry"}
        message = error.args[0] if type(error) is ValueError and len(error.args) == 1 else None
        receipt["failure_code"] = message if type(message) is str and message in allowed else "transport_read_or_output_failure"
        if isinstance(error, (TimeoutError, socket.timeout)):
            receipt["failure_code"] = "transport_timeout_no_retry"
    finally:
        receipt["observed_finished_utc"] = clock()
        try:
            writer.write("collection_receipt.json", encoded(receipt))
        finally:
            writer.close()
        key = None  # No guaranteed secure erase of Python/HTTP library memory.
    return receipt


def collect(output_dir, *, gate_bytes, gate_sha256, expected_source_sha256, deployment_bytes):
    """Future ROOT-authorized real invocation only; no injected I/O or fake clock."""
    return _collect(output_dir, gate_bytes, gate_sha256, expected_source_sha256, deployment_bytes,
                    kind="real_observation", opener_factory=real_opener, key_reader=read_key, clock=utc_now)


def collect_synthetic(output_dir, *, gate_bytes, gate_sha256, expected_source_sha256,
                      deployment_bytes, opener, key_reader, clock):
    """CPU injection path. Cannot label observations as real or issue acceptance."""
    return _collect(output_dir, gate_bytes, gate_sha256, expected_source_sha256, deployment_bytes,
                    kind="synthetic_fixture", opener_factory=lambda: opener, key_reader=key_reader, clock=clock)
