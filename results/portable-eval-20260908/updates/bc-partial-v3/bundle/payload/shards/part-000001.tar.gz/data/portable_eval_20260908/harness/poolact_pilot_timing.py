#!/usr/bin/env python3
"""Fixed B168/C144 development timing pilot; default is no-model-call dry-run.

Real --execute --allow-real needs separate root authorization and a new plan.
This Python-3.7-compatible external shim never modifies the frozen repository.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import copy
from datetime import datetime
import fcntl
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import platform
import random
import runpy
import subprocess
import sys
import time
from urllib.parse import urlsplit

HERE = Path(__file__).resolve()
WORKSPACE = HERE.parents[2]
PORTABLE = HERE.parents[1]
PROFILE_PATH = PORTABLE / "patches/profile_parameterization_v2/candidate/harness/request_profile.py"
PINNED_HELPERS = {
    HERE.with_name("pilot_timing.py"): "e7a512118fd786ee9aef4be3305f2a4efafc550cca69f5e6452b01807a54468a",
    HERE.with_name("scenario_smoke.py"): "9c85d0f8545fcc364ce27d2cea01009db6e9eb4d525e58fb44b3b2f660c9eeb1",
    PROFILE_PATH: "64f19f0de7c36a0c8b461ae28056e481aa73f2980ba3d91cd8d34a40a4f6eb70",
}
STRATEGIES = ("naive", "cached", "poolact")
STAGES = ("B1_hpo", "B2_search_audit", "B3_nas101a_tight", "C_development_repeats")
PROBE_PREFIX = "POOLACT_PILOT_PROBE="


def digest_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_external(name, path):
    path = Path(path)
    if digest_file(path) != PINNED_HELPERS[path]:
        raise RuntimeError("Frozen external helper differs: " + path.name)
    if name in sys.modules:
        module = sys.modules[name]
        if Path(module.__file__).resolve() != path:
            raise RuntimeError("Wrong external helper origin")
        return module
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def helpers():
    return load_external("scenario_smoke", HERE.with_name("scenario_smoke.py"))


def pilot_helpers():
    return load_external("bc_pilot_a21_helpers", HERE.with_name("pilot_timing.py"))


def profiles():
    return load_external("bc_request_profiles", PROFILE_PATH)


def same_json(left, right):
    return json.dumps(left, sort_keys=True, allow_nan=False) == json.dumps(right, sort_keys=True, allow_nan=False)


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, default=WORKSPACE / "LLM_ExpGym")
    parser.add_argument("--python", type=Path)
    parser.add_argument("--legacy-runtime-dir", type=Path, default=WORKSPACE / "kimi_k3_eval/data_runtime")
    parser.add_argument("--static-acceptance", type=Path, default=PORTABLE / "validation/static_acceptance_v2.json")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--backend", choices=("fake", "openai"), default="fake")
    parser.add_argument("--model", default=None)
    parser.add_argument("--base-url")
    parser.add_argument("--api-key-file", type=Path)
    parser.add_argument("--workers", type=int, default=4, help="Fixed before dispatch; pool size remains four.")
    parser.add_argument("--seed", type=int, default=1206)
    parser.add_argument("--schedule-seed", type=int, default=20260908)
    parser.add_argument("--include-c", action="store_true", help="Precommit C before any B execution; never add C based on B scores.")
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--allow-real", action="store_true", help="Separate root authorization is still required.")
    profiles().add_arguments(parser)
    args = profiles().resolve(parser.parse_args(argv), parser)
    for key in ("repo_root", "legacy_runtime_dir", "static_acceptance", "output_dir", "api_key_file"):
        if getattr(args, key) is not None:
            setattr(args, key, getattr(args, key).expanduser().resolve())
    args.python = (args.python or args.repo_root / ".venv/bin/python").expanduser().absolute()
    if not 1 <= args.workers <= 64:
        parser.error("--workers must be between 1 and 64, frozen before execution")
    if args.model_alias is not None:
        parser.error("PoolAct jobs use fixed matrix IDs; --model-alias is not supported")
    if args.base_url:
        url = urlsplit(args.base_url)
        if url.scheme not in {"http", "https"} or not url.hostname or url.username is not None or url.password is not None or url.query or url.fragment:
            parser.error("Endpoint must be HTTP(S) without credentials/query/fragment")
    if args.backend == "fake" and (args.base_url or args.allow_real):
        parser.error("Fake validation must not carry an endpoint or --allow-real")
    if args.execute and args.backend == "openai" and (not args.allow_real or not args.base_url):
        parser.error("Real execution requires separate authorization, --allow-real and explicit --base-url")
    try:
        args.output_dir.relative_to(args.repo_root)
    except ValueError:
        pass
    else:
        parser.error("Pilot outputs must be outside the frozen repository")
    return args


def settings(args):
    selected = profiles().profile(args)
    return {
        "backend": args.backend, "base_url": args.base_url, "request_profile": profiles().identity(args),
        "seed": args.seed, "schedule_seed": args.schedule_seed, "workers": args.workers,
        "include_c_precommitted": args.include_c, "agents": 4, "repeats_per_job": 1,
        "max_steps": 30, "max_evals": 30, "max_tokens": 32768, "max_context_tokens": 131072,
        "tool_protocol": "auto" if args.backend == "fake" else "native", "max_protocol_retries": 1,
        "tuning_final_policy": "legacy", "search_data_source": "phantom_seed1", "cc_split": "cc-large",
        "audit_order": "repository default; no override", "prompt_cache_key": None,
        "request_timeout": 1800, "max_retries": 2, "retry_base_seconds": 3, "retry_max_seconds": 30,
        "randomness_contract": selected["randomness_contract"], "expected_metadata": selected["expected_metadata"],
        "server_metadata_verified_by_harness": False,
        "operator_declared_server_context_tokens": selected["server_context_tokens"],
        "randomness_observation": "Not measured here; independent protocol-smoke serving receipt required.",
        "schedule_rule": "Random(schedule_seed), shuffle within B1/B2/B3/C; fully drain each stage before the next",
        "outer_pool_seed_rule": "B outer=0; C outer=1..4; base_seed + outer*4 + agent_id; seed labels do not prove common random numbers or independence",
        "isolation": "one fresh authoritative runner process and one strategy per job; no cross-pool coordinator/cache/session",
        "semantic_zero_policy": "retain; never stop or retry on score", "failed_job_retry": False,
        "purpose": "Custom development runtime pilot; no confirmatory inference or formal-result reuse",
        "concurrency_bound": {"pool_jobs": args.workers, "agents_per_pool": 4,
                              "theoretical_agent_calls": args.workers * 4, "measured_peak": None},
    }


def build_jobs(args):
    tasks = pilot_helpers().TASKS
    cells = [(STAGES[0], "tuning", task, 0, "cost_moderate", 0) for task in tasks]
    cells += [(STAGES[1], scenario, None, index, regime, 0)
              for scenario, indices, regime in (("restricted_search", (0, 18), "cost_tight"),
                                                 ("evidence_audit", (0, 2), "cost_moderate")) for index in indices]
    cells += [(STAGES[2], "tuning", "hpobench:nasbench101:A", 0, "cost_tight", 0)]
    if args.include_c:
        cells += [(STAGES[3], scenario, task, 0, regime, outer)
                  for scenario, task, regime in (("restricted_search", None, "cost_tight"),
                                                  ("evidence_audit", None, "cost_moderate"),
                                                  ("tuning", "hpobench:nasbench101:A", "cost_tight"))
                  for outer in range(1, 5)]
    jobs, config = [], settings(args)
    for stage, scenario, task, index, regime, outer in cells:
        for strategy in STRATEGIES:
            runtime = "legacy_paramnet" if task and task.startswith("hpobench:paramnet:") else "native"
            python = args.legacy_runtime_dir / ".venv-hpo/bin/python" if runtime == "legacy_paramnet" else args.python
            selector = task.replace(":", "_") if task else str(index)
            job_id = "__".join((stage, scenario, selector, regime, strategy, "outer%d" % outer))
            output = args.output_dir / "results" / job_id
            seed = args.seed + outer * 4
            command = [str(python), "-u", str(args.repo_root / "scripts/run_poolact.py"),
                       "--backend", args.backend, "--model", args.model, "--output-dir", str(output),
                       "--seed", str(seed), "--max-steps", "30", "--max-evals", "30"]
            command += profiles().generation_arguments(args)
            command += ["--tool-protocol", config["tool_protocol"], "--max-protocol-retries", "1",
                        "--tuning-final-policy", "legacy", "--request-timeout", "1800", "--max-retries", "2",
                        "--retry-base-seconds", "3", "--retry-max-seconds", "30",
                        "--api-key-file", str(args.api_key_file or Path("/dev/null")),
                        "--scenario", scenario, "--cost-regime", regime, "--tuning-task", task or tasks[3],
                        "--question-index", str(index), "--data-source", "phantom_seed1", "--cc-split", "cc-large",
                        "--strategies", strategy, "--agents", "4", "--repeats", "1",
                        "--temperature", profiles().numeric_argument(profiles().profile(args)["temperature"]),
                        "--max-context-tokens", "131072"]
            if args.base_url:
                command += ["--base-url", args.base_url]
            jobs.append({"id": job_id, "stage": stage, "system": "poolact", "scenario": scenario,
                         "tuning_task": task, "question_index": index, "regime": regime, "strategy": strategy,
                         "outer_pool": outer, "seed": seed, "runtime": runtime, "expected_traces": 4,
                         "output_dir": str(output), "dump_dir": str(args.output_dir / "dumps" / job_id), "command": command})
    rng, ordered = random.Random(args.schedule_seed), []
    for stage in STAGES:
        selected = [job for job in jobs if job["stage"] == stage]
        rng.shuffle(selected)
        ordered.extend(selected)
    for index, job in enumerate(ordered):
        job["dispatch_index"] = index
    return ordered


def environment(args, job, secret=None):
    value = pilot_helpers().child_environment(args, job, secret)
    value["EXPGYM_RUN_ID"] = "poolact-pilot-bc:" + args.output_dir.name
    return value


def snapshot(job):
    return {"results": helpers().snapshot_dumps(Path(job["output_dir"])),
            "dumps": helpers().snapshot_dumps(Path(job["dump_dir"]))}


def no_change_json_writer(path, value):
    """Match official _atomic_json bytes exactly; no new or changed JSON writes."""
    serialized = (json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")
    if not Path(path).is_file() or Path(path).read_bytes() != serialized:
        raise RuntimeError("POOLACT_PILOT_READONLY_WRITE_FORBIDDEN")


def guard_command(job, mode):
    if mode not in ("identity", "score", "resume"):
        raise ValueError("Unknown guard mode")
    return job["command"][:2] + [str(HERE), "--_" + mode + "-guard"] + job["command"][2:] + (["--resume"] if mode == "resume" else [])


def guarded_runner(argv, mode):
    runner = Path(argv[0]).resolve()
    if runner.name != "run_poolact.py" or runner.parent.name != "scripts" or (mode == "resume" and "--resume" not in argv):
        raise RuntimeError("Expected authoritative single-pool runner")
    repo, a = runner.parent.parent, pilot_helpers()

    def forbidden(*unused, **kwargs):
        raise RuntimeError("POOLACT_PILOT_MODEL_CONSTRUCTION_OR_CALL_FORBIDDEN")

    demo = a.repository_module(repo, "demo_experiment")
    demo.build_llm = forbidden
    demo.FakeLLM.generate = forbidden
    client = a.repository_module(repo, "expgym.llm_clients")
    client.OpenAICompatibleLLM.__init__ = forbidden
    client.OpenAICompatibleLLM.generate = forbidden
    sys.argv = [str(runner)] + argv[1:]
    scope = runpy.run_path(str(runner), run_name="poolact_pilot_guarded_runner")
    parsed = scope["parse_args"]()
    if parsed.agents != 4 or parsed.repeats != 1 or len(parsed.strategies) != 1 or parsed.questions is not None:
        raise RuntimeError("Expected one strategy, four agents, one explicit item")
    if mode == "resume":
        scope["main"].__globals__["_atomic_json"] = no_change_json_writer
        code = scope["main"]()
        if code:
            raise RuntimeError("Guarded authoritative resume failed")
        return
    item = scope["_repeat_namespace"](parsed, 0)
    item.question_index = parsed.question_index if parsed.question_index is not None else 0
    item.questions = None
    identity = scope["evaluation_identity"](item, repo)
    scope["bind_evaluation_identity"](identity)
    item._evaluation_identity = identity
    base_cost = scope["resolve_base_cost"](item.scenario, item)
    budget, modes = scope["resolve_cost_regime"](item, base_cost)
    if len(modes) != 1:
        raise RuntimeError("Expected one budget regime")
    config = scope["_resolved_config"](item, budget)
    scenario = scope["_SCENARIOS"][item.scenario]
    tools = scope["_resolve_tools"](scenario, item)
    schemas = a.repository_module(repo, "expgym.tool_protocol").native_tool_schemas(tools)
    result = {"evaluation_identity": identity, "config": config, "base_cost": base_cost,
              "native_tool_schemas": schemas,
              "agent_dump_contexts": [scope["_agent_namespace"](item, item.strategies[0], agent, None)._api_dump_context for agent in range(4)],
              "runtime": {"executable": sys.executable, "version": sys.version, "prefix": sys.prefix,
                          "base_prefix": sys.base_prefix, "machine": platform.machine()}}
    if mode == "score":
        evaluator = scope["_resolve_answer_evaluator"](scenario, item)
        selected = scope["_load_resumable_result"](
            item.output_dir / item.strategies[0] / "result.json", item_output_dir=item.output_dir,
            strategy=item.strategies[0], config=config, implementation=scope["_implementation_manifest"](),
            agents=4, answer_evaluator=evaluator, score_tools=tools)
        if selected is None:
            raise RuntimeError("Independent PoolAct result/score/aggregate recomputation failed")
        checks = [scope["_score_check"](agent, tools, evaluator) for agent in selected["agent_results"]]
        if not all(check.get("ok") is True for check in checks):
            raise RuntimeError("Independent per-agent score recomputation failed")
        result["score_checks"] = checks
        result["aggregate_recomputed"] = selected["aggregate"]
    print(PROBE_PREFIX + json.dumps(result, sort_keys=True, allow_nan=False))


def run_child(args, job, command, log_name, secret=None):
    path = args.output_dir / "logs" / job["id"] / log_name
    if path.exists():
        raise FileExistsError("Refusing to retry an existing child invocation")
    started = time.monotonic()
    utc = helpers().utc_now()
    completed = subprocess.run(command, cwd=args.repo_root, env=environment(args, job, secret),
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False)
    output = completed.stdout.decode("utf-8", errors="replace")
    if secret:
        output = output.replace(secret, "[REDACTED]")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        stream.write(output)
    return {"exit_code": completed.returncode, "started_utc": utc, "finished_utc": helpers().utc_now(),
            "elapsed_seconds": time.monotonic() - started, "log": str(path), "log_sha256": digest_file(path)}, output


def parse_probe(output):
    lines = [line[len(PROBE_PREFIX):] for line in output.splitlines() if line.startswith(PROBE_PREFIX)]
    if len(lines) != 1:
        raise RuntimeError("Expected exactly one guarded identity/scoring receipt")
    return json.loads(lines[0])


def probe(args, job):
    completed = subprocess.run(guard_command(job, "identity"), cwd=args.repo_root, env=environment(args, job),
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False, text=True)
    if completed.returncode:
        raise RuntimeError("Guarded local identity probe failed: " + job["id"])
    result = parse_probe(completed.stdout)
    expected = "3.7." if job["runtime"] == "legacy_paramnet" else "3.11."
    if not result["runtime"]["version"].startswith(expected):
        raise RuntimeError("Unexpected selected interpreter version")
    interpreter = Path(job["command"][0])
    result["runtime"]["executable_sha256"] = digest_file(interpreter)
    config = interpreter.parent.parent / "pyvenv.cfg"
    result["runtime"]["pyvenv_config_sha256"] = digest_file(config) if config.is_file() else None
    return result


def validate_job(job, expected_source, backend):
    root, strategy = Path(job["output_dir"]), job["strategy"]
    errors, scores, terminals = [], [], []

    def require(condition, message):
        if not condition:
            errors.append(message)

    try:
        expected_files = {"summary.json", strategy + "/result.json"} | {strategy + "/agents/agent_%d.json" % i for i in range(4)}
        require({str(p.relative_to(root)) for p in root.rglob("*.json")} == expected_files, "Unexpected/missing PoolAct JSON artifacts")
        result = json.loads((root / strategy / "result.json").read_text())
        config = result.get("config")
        require(same_json(config, job["preflight"]["config"]), "Pool configuration/evaluation identity differs")
        require(result.get("implementation_sha256", {}).get("source_tree") == expected_source, "Source fingerprint differs")
        require(result.get("strategy") == strategy and type(result.get("agents")) is int and result["agents"] == 4, "Strategy/agent count differs")
        state = result.get("shared_state")
        require(state is None or isinstance(state, dict), "Shared state malformed")
        if isinstance(state, dict):
            for pending in (state.get("pending_claims", 0), state.get("graph", {}).get("pending_claims", 0)):
                require(type(pending) is int and pending == 0, "Pending claims must be integer zero")
        if strategy == "poolact":
            require(isinstance(state, dict) and isinstance(state.get("graph"), dict)
                    and type(state["graph"].get("pending_claims")) is int and state["graph"]["pending_claims"] == 0, "PoolAct graph completion missing")
        agents = result.get("agent_results", [])
        require(len(agents) == 4 and {a.get("agent_id") for a in agents} == set(range(4))
                and all(type(a.get("agent_id")) is int for a in agents), "Agent IDs differ")
        for agent in agents:
            require(same_json(json.loads((root / strategy / "agents" / ("agent_%d.json" % agent["agent_id"])).read_text()), agent), "Separate agent artifact differs")
            require(agent.get("score_check", {}).get("ok") is True, "Saved agent score check failed")
            require(agent.get("tool_protocol") == ("text" if backend == "fake" else "native"), "Resolved tool protocol differs")
            require(type(agent.get("seed")) is int and agent["seed"] == job["seed"] + agent["agent_id"], "Agent seed differs")
            require(agent.get("strategy") == strategy and agent.get("tuning_final_policy") == "legacy", "Agent policy/strategy differs")
            require(type(agent.get("repeat_index")) is int and agent["repeat_index"] == 0, "Per-process repeat index differs")
            score = agent.get("answer_perf")
            require(isinstance(score, (int, float)) and not isinstance(score, bool) and math.isfinite(score), "Nonfinite/missing agent score")
            if isinstance(score, (int, float)) and not isinstance(score, bool) and math.isfinite(score):
                scores.append(float(score))
            terminals.append({key: agent.get(key) for key in ("termination_reason", "answer_source", "answer_score_source")})
        aggregate = result.get("aggregate", {}).get("answer_perf")
        require(isinstance(aggregate, (int, float)) and not isinstance(aggregate, bool) and math.isfinite(aggregate), "Nonfinite aggregate")
        summary = json.loads((root / "summary.json").read_text())
        require(same_json(summary.get("config"), config), "Summary configuration differs")
        require(same_json(summary.get("implementation_sha256"), result.get("implementation_sha256")), "Summary source differs")
        require(same_json(summary.get("strategies"), {strategy: result.get("aggregate")}), "Summary strategy aggregate differs")
    except Exception as exc:
        errors.append("Artifact validation raised " + type(exc).__name__)
    return {"passed": not errors, "errors": errors, "trace_count": len(scores), "semantic_zero_count": sum(x == 0 for x in scores),
            "agent_scores": scores, "terminal_diagnostics": terminals,
            "interpretation": "Structural validation; separate guarded scorer recomputes each agent and aggregate. Valid zero retained."}


def dump_profile(args, job, secret=None):
    """Join every PoolAct attempt to its agent ledger and reconstructed input."""
    h, a = helpers(), pilot_helpers()
    coverage = h.validate_api_dumps(job, Path(job["dump_dir"]))
    errors, by_request, generations, attempts = list(coverage["errors"]), {}, {}, []
    clients = a.repository_module(args.repo_root, "expgym.llm_clients")
    loop = a.repository_module(args.repo_root, "expgym.react_loop")
    schemas = job["preflight"]["native_tool_schemas"]
    schema_tokens = len(json.dumps(schemas, ensure_ascii=False, allow_nan=False)) // 3
    agent_paths = sorted(Path(job["output_dir"]).glob("*/agents/agent_*.json"))
    agents = [json.loads(path.read_text()) for path in agent_paths]
    by_client = {agent["api_dump"]["client_id"]: agent for agent in agents}
    if len(by_client) != 4:
        errors.append("Expected four distinct agent client IDs")
    raw_paths = sorted(Path(job["dump_dir"]).glob("*.json"))
    if set(raw_paths) != set(Path(job["dump_dir"]).rglob("*.json")):
        errors.append("Nested raw JSON outside flat client namespace")
    for path in raw_paths:
        record = json.loads(path.read_text())
        payload = record.get("request_payload", {})
        agent = by_client.get(record.get("client_id"))
        if agent is None:
            errors.append("Raw client has no agent")
            continue
        errors.extend(profiles().wire_errors(payload, args, seed=agent["seed"]))
        if not same_json(payload.get("tools"), schemas) or payload.get("tool_choice") not in ("auto", "none") or payload.get("parallel_tool_calls") is not False:
            errors.append("Native schema/choice/parallel-tool contract differs")
        if "prompt_cache_key" in payload:
            errors.append("Unexpected prompt-cache key")
        if record.get("endpoint") != clients._normalize_chat_completions_url(args.base_url) or record.get("run_id") != "poolact-pilot-bc:" + args.output_dir.name:
            errors.append("Endpoint/run namespace differs")
        if not same_json(record.get("context"), job["preflight"]["agent_dump_contexts"][agent["agent_id"]]):
            errors.append("Raw agent job context differs")
        identifier, generation = record.get("request_id"), record.get("generation_id")
        if identifier in by_request:
            errors.append("Duplicate raw request ID")
        by_request[identifier] = record
        if not isinstance(generation, str) or not generation or type(record.get("attempt")) is not int or record.get("max_attempts") != 3:
            errors.append("Invalid generation/attempt metadata")
        else:
            generations.setdefault(generation, []).append(record)
        response = record.get("response_json")
        attempts.append({"request_id": identifier, "client_id": record.get("client_id"), "path": str(path),
                         "sha256": h.sha256(path), "state": record.get("state"), "wall_time_seconds": record.get("wall_time_seconds"),
                         "started_at_utc": record.get("started_at_utc"), "finished_at_utc": record.get("finished_at_utc"),
                         "usage": response.get("usage") if isinstance(response, dict) else None})
    for generation, records in generations.items():
        ordered = sorted(records, key=lambda r: r["attempt"])
        if [r["attempt"] for r in ordered] != list(range(1, len(ordered) + 1)) or len(ordered) > 3:
            errors.append("Noncontiguous/duplicate retry attempts")
        if any(r.get("will_retry") is not True for r in ordered[:-1]) or ordered[-1].get("will_retry") is not False:
            errors.append("Incomplete retry chain")
        if any(not same_json(r.get("request_payload"), ordered[0].get("request_payload")) for r in ordered[1:]):
            errors.append("Retry mutated payload")
    linked_requests, linked_generations = [], []
    for agent in agents:
        ledger = agent.get("usage_attempts", [])
        messages = agent.get("messages", [])
        assistant_indices = [i for i, message in enumerate(messages) if message.get("role") == "assistant"]
        if len(ledger) != agent.get("api_calls") or len(assistant_indices) != len(ledger):
            errors.append("Agent call/assistant/ledger counts differ")
        for number, (call, message_index) in enumerate(zip(ledger, assistant_indices), 1):
            entries = call.get("attempts", [])
            if call.get("llm_call_index") != number or not entries:
                errors.append("Missing/nonsequential agent attempt ledger")
                continue
            if [entry.get("attempt") for entry in entries] != list(range(1, len(entries) + 1)) or len(entries) > 3:
                errors.append("Agent retry ledger order differs")
            generation = entries[0].get("generation_id")
            linked_generations.append(generation)
            expected_messages = loop._trim_messages(copy.deepcopy(messages[:message_index]), 131072 - schema_tokens)
            if loop._estimate_tokens(expected_messages) + schema_tokens > 131072:
                errors.append("Reconstructed input violates frozen context admission cap")
            expected_messages = a.redact_wire(expected_messages, secret, clients.OpenAICompatibleLLM._is_secret_field)
            for entry in entries:
                request_id = entry.get("request_id")
                linked_requests.append(request_id)
                raw = by_request.get(request_id)
                if raw is None:
                    errors.append("Ledger request missing raw dump")
                    continue
                if raw.get("client_id") != agent["api_dump"]["client_id"] or entry.get("generation_id") != generation:
                    errors.append("Cross-agent/cross-generation ledger join")
                if any(not same_json(entry.get(k), raw.get(k)) for k in ("generation_id", "attempt", "state", "http_status")):
                    errors.append("Ledger/raw attempt metadata differs")
                if not same_json(raw.get("request_payload", {}).get("messages"), expected_messages):
                    errors.append("Reconstructed trimmed agent input differs from raw wire")
                response = raw.get("response_json")
                usage = response.get("usage") if isinstance(response, dict) else None
                if "usage_error" not in entry and not same_json(entry.get("usage"), usage):
                    errors.append("Ledger/raw usage differs")
            delivered = by_request.get(entries[-1].get("request_id"))
            if delivered is not None:
                response = delivered.get("response_json") or {}
                choices = response.get("choices", []) if isinstance(response, dict) else []
                message = choices[0].get("message") if choices and isinstance(choices[0], dict) else None
                if isinstance(message, dict):
                    message = dict(message)
                    message.setdefault("role", "assistant")
                if delivered.get("state") != "success" or not same_json(message, a.redact_wire(messages[message_index], secret, clients.OpenAICompatibleLLM._is_secret_field)):
                    errors.append("Delivered raw assistant differs from saved agent history")
    if len(set(linked_requests)) != len(linked_requests) or set(linked_requests) != set(by_request):
        errors.append("Raw requests and agent ledgers are not a bijection")
    if len(set(linked_generations)) != len(linked_generations) or set(linked_generations) != set(generations):
        errors.append("Raw generations and agent calls are not a bijection")
    return {"passed": not errors, "errors": errors, "coverage": coverage, "attempts": attempts,
            "observed_http_overlap": measured_overlap(attempts),
            "input_reconstruction": "Full saved agent message prefix before each assistant, frozen _trim_messages with fixed cap minus frozen native schema estimate, then client redaction; no instrumentation or tool re-execution.",
            "limitations": "PoolAct does not save per-call forced/finish flags. Raw tool_choice/finish_reason are retained, not falsely asserted to match absent trace fields. Provider usage missing is unknown, not zero."}


def measured_overlap(attempts):
    """Observed client HTTP intervals, not server scheduling or GPU occupancy."""
    if not attempts:
        return {"maximum": None, "valid_intervals": False, "limitation": "No covered HTTP intervals; unknown, not zero"}
    boundaries = []
    try:
        for attempt in attempts:
            start = datetime.fromisoformat(attempt["started_at_utc"].replace("Z", "+00:00")).timestamp()
            end = datetime.fromisoformat(attempt["finished_at_utc"].replace("Z", "+00:00")).timestamp()
            if end < start:
                raise ValueError("Clock interval reversed")
            if end > start:
                boundaries.extend(((start, 1), (end, -1)))
    except (KeyError, TypeError, ValueError, AttributeError):
        return {"maximum": None, "valid_intervals": False, "limitation": "Missing/malformed wall-clock intervals; unknown, not zero"}
    active = maximum = 0
    for _, delta in sorted(boundaries):
        active += delta
        maximum = max(maximum, active)
    return {"maximum": maximum, "valid_intervals": True,
            "limitation": "Client-side HTTP interval overlap only; host clock synchronization assumed; not GPU utilization or serving slot capacity"}


def retained_http_overlap(jobs, results):
    """Include retained failed-job attempts, never promote partial coverage to zero."""
    selected = {job["id"]: job for job in jobs}
    intervals, malformed = [], []
    for row in results:
        for path in sorted(Path(selected[row["job_id"]]["dump_dir"]).rglob("*.json")):
            try:
                record = json.loads(path.read_text())
                intervals.append({key: record.get(key) for key in ("started_at_utc", "finished_at_utc")})
            except (OSError, ValueError, TypeError, AttributeError):
                malformed.append(str(path))
    observed = measured_overlap(intervals)
    complete = bool(results) and not malformed and all(row.get("dump_validation", {}).get("passed") is True for row in results)
    return {"maximum": observed["maximum"] if complete else None,
            "maximum_observed_from_retained_raw": observed["maximum"],
            "complete_launched_job_coverage": complete, "raw_attempts": len(intervals), "malformed_raw_paths": malformed,
            "interval_receipt": observed,
            "limitation": "Includes failed-job raw intervals when retained; incomplete coverage is a lower bound, not a full measured peak. Unstarted jobs are excluded. Not server/GPU occupancy."}


def trace_timing(job):
    agents = [json.loads(path.read_text()) for path in sorted(Path(job["output_dir"]).glob("*/agents/agent_*.json"))]
    fields = ("agent_id", "seed", "wall_time_seconds", "llm_time", "eval_time", "total_overhead", "evaluations",
              "api_calls", "http_request_attempts", "prompt_tokens", "completion_tokens", "cached_prompt_tokens",
              "termination_reason", "answer_source", "answer_score_source", "protocol_failures", "protocol_retries", "agent_steps")
    return {"agents": [{key: agent.get(key) for key in fields} for agent in agents],
            "simulated_budget": job["preflight"]["config"]["time_budget"],
            "note": "Agent wall times overlap inside a pool; simulated feedback time is not GPU wall time."}


def run_bounded(jobs, worker, workers):
    if type(workers) is not int or not 1 <= workers <= 64:
        raise ValueError("Invalid fixed concurrency")
    pending, results, next_index, stopped = {}, [], 0, False
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        while pending or (next_index < len(jobs) and not stopped):
            while not stopped and next_index < len(jobs) and len(pending) < workers:
                job = jobs[next_index]
                pending[pool.submit(worker, job)] = job
                next_index += 1
            done, _ = concurrent.futures.wait(pending, return_when=concurrent.futures.FIRST_COMPLETED)
            for future in done:
                job = pending.pop(future)
                try:
                    result = future.result()
                except Exception as exc:
                    result = {"job_id": job["id"], "stage": job["stage"], "passed": False,
                              "error_type": type(exc).__name__, "retained_artifacts": snapshot(job)}
                results.append(result)
                stopped = stopped or result.get("passed") is not True
    return {"results": results, "unstarted": [j["id"] for j in jobs[next_index:]]}


def code_identity(args):
    h = helpers()
    for path, expected in PINNED_HELPERS.items():
        if h.sha256(path) != expected:
            raise RuntimeError("Frozen external helper changed")
    paths = [HERE, HERE.parent / "tests/test_poolact_pilot_timing.py", args.legacy_runtime_dir / "run_hpo.sh"] + list(PINNED_HELPERS)
    return {str(path): h.sha256(path) for path in paths}


def main(argv=None):
    args, h, a = parse_args(argv), helpers(), pilot_helpers()
    acceptance = a.verify_acceptance(args.repo_root, args.static_acceptance)
    code_hashes = code_identity(args)
    jobs = build_jobs(args)
    for job in jobs:
        job["environment_overrides"] = a.environment_overrides(args, job)
        job["environment_overrides"]["EXPGYM_RUN_ID"] = "poolact-pilot-bc:" + args.output_dir.name
        job["preflight"] = probe(args, job)
    identity = {"schema_version": "poolact-pilot-bc.v1", "static_acceptance": acceptance,
                "settings": settings(args), "repo_root": str(args.repo_root), "harness_files": code_hashes,
                "jobs": jobs, "counts": {"jobs": len(jobs), "agent_traces": len(jobs) * 4,
                "B_jobs": 42, "B_agent_traces": 168, "C_jobs": 36 if args.include_c else 0,
                "C_agent_traces": 144 if args.include_c else 0, "legacy_paramnet_jobs": 9},
                "credential_source": str(args.api_key_file) if args.api_key_file else "OPENAI_API_KEY (real only)",
                "resume_audit": "Official per-agent+aggregate recomputation under model-construction/generate guard; official JSON serialization byte-identical writes are no-ops, all other writes fail; every result/raw JSON set/SHA/size/mtime unchanged"}
    args.output_dir.mkdir(parents=True, exist_ok=True)
    with (args.output_dir / ".harness.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        phase = "execution" if args.execute else "dry_run"
        manifest = args.output_dir / "manifest.json"
        if manifest.exists():
            if not same_json(json.loads(manifest.read_text())["identity"], identity):
                raise RuntimeError("Immutable manifest differs; use a NEW output directory")
        elif any(path.name != ".harness.lock" for path in args.output_dir.iterdir()):
            raise RuntimeError("Unrecognized nonempty output directory")
        else:
            h.atomic_json(manifest, {"created_utc": h.utc_now(), "identity": identity})
            h.atomic_json(args.output_dir / "commands.json", {j["id"]: {"run": j["command"], "dry_run": j["command"] + ["--dry-run"],
                          "score_guard": guard_command(j, "score"), "resume_guard": guard_command(j, "resume")} for j in jobs})
        if any((args.output_dir / name).exists() for name in (phase + "_started.json", phase + ".json", "execution_started.json", "execution.json")):
            raise RuntimeError("Phase already started; no overwrite/retry/semantic resampling")
        if any(any(snapshot(job).values()) for job in jobs):
            raise RuntimeError("Existing result/raw JSON; refusing overwrite")
        secret = None
        if args.execute and args.backend == "openai":
            secret = args.api_key_file.read_text().strip() if args.api_key_file else os.environ.get("OPENAI_API_KEY", "").strip()
            if not secret:
                raise RuntimeError("Missing explicitly selected credential; no calls made")
        h.atomic_json(args.output_dir / (phase + "_started.json"), {"created_utc": h.utc_now(), "pid": os.getpid(), "manifest_sha256": h.sha256(manifest)})

        def unchanged():
            return (a.verify_acceptance(args.repo_root, args.static_acceptance) == acceptance
                    and code_identity(args) == code_hashes and profiles().unchanged(args))

        def worker(job):
            if not unchanged() or not same_json(probe(args, job), job["preflight"]):
                raise RuntimeError("Source/runtime/input identity changed before dispatch")
            run, output = run_child(args, job, job["command"] + ([] if args.execute else ["--dry-run"]), phase + ".log", secret)
            result = {"job_id": job["id"], "stage": job["stage"], "run": run, "passed": run["exit_code"] == 0}
            if args.execute and result["passed"]:
                result["validation"] = validate_job(job, acceptance["source_tree_sha256"], args.backend)
                result["passed"] = result["validation"]["passed"]
                before = snapshot(job)
                result["before_audit"] = before
                if result["passed"]:
                    scored, score_output = run_child(args, job, guard_command(job, "score"), "score.log", secret)
                    result["independent_score"] = scored
                    result["passed"] = scored["exit_code"] == 0
                    if result["passed"]:
                        result["independent_score"]["receipt"] = parse_probe(score_output)
                    if snapshot(job) != before:
                        result["passed"] = False
                        result["error"] = "Score audit mutated JSON"
                if args.backend == "openai":
                    result["dump_validation"] = dump_profile(args, job, secret)
                    result["passed"] = result["passed"] and result["dump_validation"]["passed"]
                elif before["dumps"]:
                    result["passed"] = False
                    result["error"] = "Fake unexpectedly produced raw HTTP dumps"
                if result["passed"]:
                    resumed, text = run_child(args, job, guard_command(job, "resume"), "resume.log", secret)
                    after = snapshot(job)
                    result["resume"] = {**resumed, "model_construction_and_calls_forbidden": True,
                                        "verified_skips": text.count("[resume]"), "all_json_before_equals_after": before == after, "after": after}
                    result["passed"] = resumed["exit_code"] == 0 and text.count("[resume]") == 1 and "rerun" not in text.lower() and before == after
                result["timing"] = trace_timing(job)
            if not unchanged() or not same_json(probe(args, job), job["preflight"]):
                result["passed"] = False
                result["error"] = "Source/runtime/input identity changed during dispatch"
            result["retained_artifacts"] = snapshot(job)
            h.atomic_json(args.output_dir / "logs" / job["id"] / (phase + "_status.json"), result)
            return result

        started, results, stages, unstarted = time.monotonic(), [], [], []
        for stage in STAGES:
            selected = [j for j in jobs if j["stage"] == stage]
            if any(row.get("passed") is not True for row in results):
                unstarted.extend(j["id"] for j in selected)
                continue
            stage_start = time.monotonic()
            report = run_bounded(selected, worker, args.workers)
            results.extend(report["results"])
            unstarted.extend(report["unstarted"])
            stages.append({"stage": stage, "jobs": len(selected), "elapsed_seconds_including_audits": time.monotonic() - stage_start})
        report = {"created_utc": h.utc_now(), "classification": "Custom study" if args.execute and args.backend == "openai" else "Static/fake validation",
                  "executed": args.execute, "passed": len(results) == len(jobs) and not unstarted and all(row.get("passed") is True for row in results),
                  "elapsed_seconds_including_audits": time.monotonic() - started,
                  "stages": stages, "results": results, "unstarted": unstarted,
                  "validated_trace_count": sum(row.get("validation", {}).get("trace_count", 0) for row in results),
                  "semantic_zero_count": sum(row.get("validation", {}).get("semantic_zero_count", 0) for row in results),
                  "observed_http_overlap": retained_http_overlap(jobs, results) if args.backend == "openai" and args.execute else None,
                  "timing_note": "Run wall includes child import/loading/scoring; stage wall includes separate identity/scoring/resume audits; no GPU-time claim from fake; all failures/zero scores retained."}
        h.atomic_json(args.output_dir / (phase + ".json"), report)
        print(json.dumps({k: report[k] for k in ("passed", "executed", "classification", "elapsed_seconds_including_audits", "validated_trace_count", "semantic_zero_count", "unstarted")}, indent=2))
        return 0 if report["passed"] else 1


if __name__ == "__main__":
    modes = {"--_identity-guard": "identity", "--_score-guard": "score", "--_resume-guard": "resume"}
    if len(sys.argv) > 1 and sys.argv[1] in modes:
        guarded_runner(sys.argv[2:], modes[sys.argv[1]])
    else:
        raise SystemExit(main())
