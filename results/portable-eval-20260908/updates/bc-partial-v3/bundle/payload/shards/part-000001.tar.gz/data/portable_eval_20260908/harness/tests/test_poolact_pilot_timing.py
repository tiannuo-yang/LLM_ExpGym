"""Independent B/C harness tests: CPU fixtures and in-memory transports only."""
from contextlib import redirect_stderr, redirect_stdout
import copy
import importlib.util
from io import StringIO
import json
import os
from pathlib import Path
import runpy
import sys
import tempfile
import threading
import time
import unittest
from unittest import mock

HARNESS = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("test_bc_harness", HARNESS / "poolact_pilot_timing.py")
bc = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = bc
spec.loader.exec_module(bc)
REPO = bc.WORKSPACE / "LLM_ExpGym"


class PoolActPilotTests(unittest.TestCase):
    def args(self, root="/tmp/unused-bc-test-plan", *extra):
        return bc.parse_args(["--repo-root", str(REPO), "--output-dir", str(root)] + list(extra))

    def test_fixed_b168_and_optional_c144(self):
        base = bc.build_jobs(self.args())
        full = bc.build_jobs(self.args("/tmp/unused-bc-test-plan", "--include-c"))
        self.assertEqual(len(base), 42)
        self.assertEqual(sum(j["expected_traces"] for j in base), 168)
        self.assertEqual(len(full), 78)
        self.assertEqual(sum(j["expected_traces"] for j in full), 312)
        self.assertEqual(base, full[:42])
        self.assertEqual(len({j["id"] for j in full}), 78)
        self.assertEqual([sum(j["stage"] == stage for j in full) for stage in bc.STAGES], [27, 12, 3, 36])
        self.assertEqual({j["tuning_task"] for j in base if j["stage"] == bc.STAGES[0]}, set(bc.pilot_helpers().TASKS))

    def test_single_strategy_n4_fixed_command_contract(self):
        for job in bc.build_jobs(self.args("/tmp/unused-bc-test-plan", "--include-c")):
            argv = job["command"]
            for flag, value in (("--agents", "4"), ("--repeats", "1"), ("--max-steps", "30"), ("--max-evals", "30"),
                                ("--max-context-tokens", "131072"), ("--max-tokens", "32768"), ("--tuning-final-policy", "legacy"),
                                ("--max-protocol-retries", "1"), ("--temperature", "1")):
                self.assertEqual(argv[argv.index(flag) + 1], value)
            self.assertEqual(argv[argv.index("--strategies") + 1], job["strategy"])
            self.assertNotIn("--questions", argv)
            self.assertNotIn("--prompt-cache-key", argv)
            self.assertEqual(job["seed"], 1206 + 4 * job["outer_pool"])

    def test_backend_runtime_and_seed_selection(self):
        jobs = bc.build_jobs(self.args("/tmp/unused-bc-test-plan", "--include-c"))
        self.assertEqual(sum(j["runtime"] == "legacy_paramnet" for j in jobs), 9)
        for job in jobs:
            legacy = (job["tuning_task"] or "").startswith("hpobench:paramnet:")
            self.assertEqual(".venv-hpo/bin/python" in job["command"][0], legacy)
            if job["stage"] == bc.STAGES[-1]:
                self.assertIn(job["outer_pool"], range(1, 5))
                self.assertEqual(job["question_index"], 0)
                self.assertEqual(job["runtime"], "native")

    def test_order_is_deterministic_and_stages_drained(self):
        first = bc.build_jobs(self.args())
        second = bc.build_jobs(self.args())
        changed = bc.build_jobs(self.args("/tmp/unused-bc-test-plan", "--schedule-seed", "17"))
        self.assertEqual(first, second)
        self.assertNotEqual([j["id"] for j in first], [j["id"] for j in changed])
        self.assertEqual({j["id"] for j in first}, {j["id"] for j in changed})
        stages = [bc.STAGES.index(j["stage"]) for j in first]
        self.assertEqual(stages, sorted(stages))
        self.assertEqual([j["dispatch_index"] for j in first], list(range(42)))

    def test_real_execution_requires_explicit_gate_but_dry_is_allowed(self):
        for flags in (("--backend", "openai", "--execute"), ("--backend", "openai", "--execute", "--base-url", "http://example.invalid/v1"),
                      ("--base-url", "http://example.invalid/v1"), ("--allow-real",)):
            with redirect_stderr(StringIO()), self.assertRaises(SystemExit):
                self.args("/tmp/unused-bc-test-plan", *flags)
        args = self.args("/tmp/unused-bc-test-plan", "--backend", "openai", "--base-url", "http://example.invalid/v1", "--execute", "--allow-real")
        self.assertEqual(bc.settings(args)["tool_protocol"], "native")
        self.assertFalse(self.args().execute)

    def test_workers_are_frozen_plan_parameters_not_measured_concurrency(self):
        for workers in (1, 4, 8, 16, 64):
            args = self.args("/tmp/unused-bc-test-plan", "--workers", str(workers))
            self.assertEqual(bc.settings(args)["concurrency_bound"]["pool_jobs"], workers)
            self.assertIsNone(bc.settings(args)["concurrency_bound"]["measured_peak"])
        for workers in (0, 65):
            with redirect_stderr(StringIO()), self.assertRaises(SystemExit):
                self.args("/tmp/unused-bc-test-plan", "--workers", str(workers))

    def test_profile_generation_is_bound_and_unknown_fields_rejected(self):
        with tempfile.TemporaryDirectory() as root:
            profile = copy.deepcopy(bc.profiles().DEFAULT_PROFILE)
            profile.update(model="glm-5.3", top_p=.95, top_k=-1, chat_template_kwargs={"clear_thinking": False, "reasoning_effort": "max"}, randomness_contract="seed_labels_only")
            path = Path(root) / "profile.json"
            path.write_text(json.dumps(profile))
            args = self.args(Path(root) / "output", "--request-profile", str(path))
            for job in bc.build_jobs(args):
                command = job["command"]
                self.assertEqual(command[command.index("--top-p") + 1], "0.95")
                self.assertEqual(command[command.index("--top-k") + 1], "-1")
            self.assertTrue(bc.profiles().unchanged(args))
            profile["top_p"] = .9
            path.write_text(json.dumps(profile))
            self.assertFalse(bc.profiles().unchanged(args))

    def test_environment_sanitized_without_modifying_parent(self):
        args, job = self.args(), bc.build_jobs(self.args())[0]
        with mock.patch.dict(os.environ, {"HTTP_PROXY": "secret-proxy", "OPENAI_API_KEY": "old", "EXPGYM_PROMPT_CACHE_KEY": "old"}):
            env = bc.environment(args, job, "new-test-secret")
            self.assertNotIn("HTTP_PROXY", env)
            self.assertNotIn("EXPGYM_PROMPT_CACHE_KEY", env)
            self.assertEqual(env["OPENAI_API_KEY"], "new-test-secret")
            self.assertEqual(env["NO_PROXY"], "*")
            self.assertEqual(env["EXPGYM_RUN_ID"], "poolact-pilot-bc:unused-bc-test-plan")
            self.assertEqual(os.environ["OPENAI_API_KEY"], "old")

    def test_readonly_json_writer_preserves_bytes_and_mtime(self):
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "summary.json"
            value = {"unicode": "测试", "score": 0, "nested": [True, {"a": 1}]}
            path.write_bytes((json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode())
            before = (path.read_bytes(), path.stat().st_mtime_ns)
            bc.no_change_json_writer(path, value)
            self.assertEqual((path.read_bytes(), path.stat().st_mtime_ns), before)

    def test_readonly_json_writer_rejects_bool_number_and_whitespace_equivalence(self):
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "summary.json"
            path.write_bytes(b'{\n  "value": true\n}\n')
            for value in ({"value": 1}, {"value": "true"}, {"value": False}):
                with self.assertRaises(RuntimeError):
                    bc.no_change_json_writer(path, value)
            path.write_text('{"value": true}')
            with self.assertRaises(RuntimeError):
                bc.no_change_json_writer(path, {"value": True})
            with self.assertRaises(RuntimeError):
                bc.no_change_json_writer(Path(root) / "new.json", {})
            self.assertFalse((Path(root) / "new.json").exists())

    def test_json_identity_does_not_equate_bool_and_number(self):
        self.assertFalse(bc.same_json({"x": True}, {"x": 1}))
        self.assertTrue(bc.same_json({"a": 1, "b": 2}, {"b": 2, "a": 1}))

    def test_snapshot_includes_summary_all_json_and_ignores_logs(self):
        with tempfile.TemporaryDirectory() as root:
            job = {"output_dir": root, "dump_dir": str(Path(root) / "dump")}
            (Path(root) / "summary.json").write_text('{}')
            (Path(root) / "log.txt").write_text('ignored')
            before = bc.snapshot(job)
            self.assertEqual(set(before["results"]), {"summary.json"})
            (Path(root) / "summary.json").write_text('{"changed":1}')
            self.assertNotEqual(before, bc.snapshot(job))

    def test_dispatch_failure_drains_running_jobs_and_stops_new(self):
        started, finished, barrier = [], [], threading.Barrier(2)
        def worker(job):
            started.append(job["id"])
            barrier.wait(timeout=5)
            if job["id"] == "j1":
                time.sleep(.03)
            finished.append(job["id"])
            return {"job_id": job["id"], "passed": job["id"] != "j0"}
        jobs = [{"id": "j%d" % i, "stage": "B1"} for i in range(6)]
        report = bc.run_bounded(jobs, worker, 2)
        self.assertEqual(set(started), {"j0", "j1"})
        self.assertEqual(set(finished), {"j0", "j1"})
        self.assertEqual(report["unstarted"], ["j2", "j3", "j4", "j5"])

    def test_verified_zeros_do_not_stop_dispatch(self):
        jobs = [{"id": str(i), "stage": "B1"} for i in range(9)]
        report = bc.run_bounded(jobs, lambda job: {"job_id": job["id"], "passed": True, "score": 0}, 8)
        self.assertEqual(len(report["results"]), 9)
        self.assertEqual(report["unstarted"], [])

    def test_frozen_external_helpers_and_new_source_test_are_bound(self):
        args = self.args()
        identity = bc.code_identity(args)
        self.assertIn(str(bc.HERE), identity)
        self.assertIn(str(Path(__file__).resolve()), identity)
        self.assertTrue(set(map(str, bc.PINNED_HELPERS)).issubset(identity))
        with mock.patch.object(bc, "PINNED_HELPERS", {**bc.PINNED_HELPERS, bc.HERE.with_name("pilot_timing.py"): "wrong"}):
            with self.assertRaises(RuntimeError):
                bc.code_identity(args)

    def test_measured_overlap_is_not_workers_times_agents(self):
        rows = [{"started_at_utc": "2026-09-08T00:00:0%d+00:00" % start,
                 "finished_at_utc": "2026-09-08T00:00:0%d+00:00" % end} for start, end in ((0, 2), (1, 3), (3, 4))]
        self.assertEqual(bc.measured_overlap(rows)["maximum"], 2)
        self.assertTrue(bc.measured_overlap(rows)["valid_intervals"])
        self.assertIsNone(bc.measured_overlap([{}])["maximum"])
        self.assertIsNone(bc.measured_overlap([])["maximum"])

    def test_failed_job_raw_overlap_is_retained_with_explicit_incomplete_coverage(self):
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "attempt.json"
            path.write_text(json.dumps({"started_at_utc": "2026-09-08T00:00:00+00:00", "finished_at_utc": "2026-09-08T00:00:01+00:00"}))
            jobs = [{"id": "failed", "dump_dir": root}]
            receipt = bc.retained_http_overlap(jobs, [{"job_id": "failed", "passed": False}])
            self.assertIsNone(receipt["maximum"])
            self.assertEqual(receipt["maximum_observed_from_retained_raw"], 1)
            self.assertFalse(receipt["complete_launched_job_coverage"])
            self.assertEqual(receipt["raw_attempts"], 1)

    def test_real_schema_long_native_tool_history_trim_exact_wire_join(self):
        client_module = bc.pilot_helpers().repository_module(REPO, "expgym.llm_clients")
        loop = bc.pilot_helpers().repository_module(REPO, "expgym.react_loop")
        protocol = bc.pilot_helpers().repository_module(REPO, "expgym.tool_protocol")
        with tempfile.TemporaryDirectory() as root:
            args = self.args(Path(root), "--backend", "openai", "--base-url", "http://example.invalid/v1")
            job = next(j for j in bc.build_jobs(args) if j["scenario"] == "tuning" and j["strategy"] == "naive")
            command = job["command"]
            command[command.index("--tuning-task") + 1] = "neural_network_training"
            command[0] = str(args.python)
            job["runtime"] = "native"
            job["preflight"] = bc.probe(args, job)
            schema = job["preflight"]["native_tool_schemas"][0]["function"]
            # Exact actual task schema, deterministic synthetic long observation.
            def long_result(argument):
                return ("LONG_OBSERVATION_" + "x" * 450000, .25, 1.0)
            long_result.__expgym_tool_schema__ = schema
            tools = {schema["name"]: long_result}
            self.assertEqual(protocol.native_tool_schemas(tools), job["preflight"]["native_tool_schemas"])
            def transport(request, timeout):
                payload = json.loads(request.data)
                if any(m["role"] == "tool" for m in payload["messages"]):
                    message, finish = {"role": "assistant", "content": '{"invalid_configuration":1}'}, "stop"
                else:
                    message = {"role": "assistant", "content": None, "tool_calls": [{"id": "long_call", "type": "function", "function": {"name": schema["name"], "arguments": '{}'}}]}
                    finish = "tool_calls"
                return json.dumps({"choices": [{"message": message, "finish_reason": finish}], "usage": {"prompt_tokens": 20, "completion_tokens": 10}}).encode()
            with mock.patch.dict(os.environ, bc.environment(args, job), clear=True):
                for agent_id in range(4):
                    client = client_module.OpenAICompatibleLLM(api_key="UNIT_TEST_SECRET", base_url=args.base_url, model=args.model,
                        temperature=1, top_p=1, seed=job["seed"] + agent_id, max_tokens=32768, reasoning_effort="max",
                        chat_template_kwargs=bc.profiles().profile(args)["chat_template_kwargs"], max_retries=2,
                        transport=transport, dump_context=job["preflight"]["agent_dump_contexts"][agent_id])
                    agent = loop.run_react_loop(llm=client, tools=tools, tool_protocol="native", max_steps=3, max_evals=3,
                                               context="Long native-tool trimming fixture", max_context_tokens=131072, max_protocol_retries=1)
                    agent.update(agent_id=agent_id, seed=job["seed"] + agent_id, api_dump=client.dump_metadata)
                    path = Path(job["output_dir"]) / "naive/agents" / ("agent_%d.json" % agent_id)
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.write_text(json.dumps(agent))
                    self.assertEqual(agent["api_calls"], 2)
                    self.assertTrue(any(len(m.get("content") or "") > 400000 for m in agent["messages"]))
            records = [json.loads(p.read_text()) for p in Path(job["dump_dir"]).glob("*.json")]
            self.assertTrue(any("[... truncated ...]" in json.dumps(r["request_payload"]["messages"]) for r in records))
            self.assertTrue(all(len(json.dumps(r["request_payload"]["messages"])) < 10000 for r in records))
            receipt = bc.dump_profile(args, job, "UNIT_TEST_SECRET")
            self.assertTrue(receipt["passed"], receipt["errors"])

    def test_guard_commands_use_selected_interpreter(self):
        for job in bc.build_jobs(self.args()):
            for mode in ("identity", "score", "resume"):
                command = bc.guard_command(job, mode)
                self.assertEqual(command[0], job["command"][0])
                self.assertEqual(command[2], str(bc.HERE))
                self.assertEqual("--resume" in command, mode == "resume")

    def test_new_manifest_rejects_late_c_workers_or_profile_changes_without_children(self):
        with tempfile.TemporaryDirectory() as root:
            output = Path(root) / "plan"
            flags = ["--output-dir", str(output)]
            fake_probe = {"config": {}, "evaluation_identity": {}, "runtime": {}}
            with mock.patch.object(bc, "probe", return_value=fake_probe), mock.patch.object(bc, "run_bounded", return_value={"results": [], "unstarted": []}), redirect_stdout(StringIO()):
                bc.main(flags)
                before = (output / "manifest.json").read_bytes()
                for extra in (("--include-c",), ("--workers", "8"), ("--seed", "55")):
                    with self.assertRaisesRegex(RuntimeError, "Immutable"):
                        bc.main(flags + list(extra))
                    self.assertEqual((output / "manifest.json").read_bytes(), before)

    def test_failure_stops_later_stages_without_selecting_on_scores(self):
        with tempfile.TemporaryDirectory() as root:
            flags = ["--output-dir", str(Path(root) / "failed"), "--include-c"]
            def failed_first(jobs, worker, workers):
                return {"results": [{"job_id": jobs[0]["id"], "passed": False}], "unstarted": [j["id"] for j in jobs[1:]]}
            with mock.patch.object(bc, "probe", return_value={}), mock.patch.object(bc, "run_bounded", side_effect=failed_first) as dispatch, redirect_stdout(StringIO()):
                self.assertEqual(bc.main(flags), 1)
            self.assertEqual(dispatch.call_count, 1)
            report = json.loads((Path(root) / "failed/dry_run.json").read_text())
            self.assertEqual(len(report["unstarted"]), 77)
            self.assertFalse(report["passed"])

    def test_actual_frozen_runner_mock_wire_and_guarded_rescore_resume(self):
        client_module = bc.pilot_helpers().repository_module(REPO, "expgym.llm_clients")
        original = client_module.OpenAICompatibleLLM.__init__
        with tempfile.TemporaryDirectory() as root:
            for strategy in bc.STRATEGIES:
                args = self.args(Path(root) / strategy, "--backend", "openai", "--base-url", "http://example.invalid/v1")
                job = next(j for j in bc.build_jobs(args) if j["strategy"] == strategy and j["scenario"] == "tuning")
                command = job["command"]
                command[command.index("--tuning-task") + 1] = "neural_network_training"
                job["tuning_task"] = "neural_network_training"
                job["runtime"] = "native"
                command[0] = str(args.python)
                job["preflight"] = bc.probe(args, job)

                def transport(request, timeout):
                    payload = json.loads(request.data)
                    if any(m["role"] == "tool" for m in payload["messages"]):
                        message, finish = {"role": "assistant", "content": '{"invalid_configuration": 1}', "reasoning_content": "mock final"}, "stop"
                    else:
                        message = {"role": "assistant", "content": None, "reasoning_content": "mock reasoning", "tool_calls": [{"id": "call_mock", "type": "function", "function": {"name": "evaluate_config", "arguments": '{"invalid":1}'}}]}
                        finish = "tool_calls"
                    return json.dumps({"choices": [{"message": message, "finish_reason": finish}], "usage": {"prompt_tokens": 10, "completion_tokens": 5}}).encode()

                wrapped = mock.Mock(side_effect=transport)
                def initialize(instance, *positional, **kwargs):
                    kwargs["transport"] = wrapped
                    original(instance, *positional, **kwargs)

                with mock.patch.dict(os.environ, bc.environment(args, job, "UNIT_TEST_SECRET"), clear=True), mock.patch.object(sys, "argv", command[2:]), mock.patch.object(client_module.OpenAICompatibleLLM, "__init__", new=initialize), redirect_stdout(StringIO()):
                    scope = runpy.run_path(command[2], run_name="bc_mock_runner")
                    self.assertEqual(scope["main"](), 0)
                self.assertEqual(wrapped.call_count, 8)
                source = scope["_implementation_manifest"]()["source_tree"]
                structural = bc.validate_job(job, source, "openai")
                self.assertTrue(structural["passed"], structural["errors"])
                self.assertEqual(structural["semantic_zero_count"], 4)
                wire = bc.dump_profile(args, job, "UNIT_TEST_SECRET")
                self.assertTrue(wire["passed"], wire["errors"])
                before = bc.snapshot(job)
                score, output = bc.run_child(args, job, bc.guard_command(job, "score"), "score.log", "UNIT_TEST_SECRET")
                self.assertEqual(score["exit_code"], 0, output)
                self.assertEqual(len(bc.parse_probe(output)["score_checks"]), 4)
                resume, output = bc.run_child(args, job, bc.guard_command(job, "resume"), "resume.log", "UNIT_TEST_SECRET")
                self.assertEqual(resume["exit_code"], 0, output)
                self.assertEqual(bc.snapshot(job), before)
                path = next(Path(job["dump_dir"]).glob("*.json"))
                original_bytes = path.read_bytes()
                for field, replacement in (("top_p", .5), ("seed", 9999), ("tools", []), ("messages", [])):
                    raw = json.loads(original_bytes)
                    raw["request_payload"][field] = replacement
                    path.write_text(json.dumps(raw))
                    self.assertFalse(bc.dump_profile(args, job, "UNIT_TEST_SECRET")["passed"], field)
                path.write_bytes(original_bytes)
                result_path = Path(job["output_dir"]) / strategy / "result.json"
                result = json.loads(result_path.read_text())
                result["agent_results"][0]["answer_perf"] = True
                result_path.write_text(json.dumps(result))
                self.assertFalse(bc.validate_job(job, source, "openai")["passed"])
                bad_score, output = bc.run_child(args, job, bc.guard_command(job, "score"), "bad_score.log", "UNIT_TEST_SECRET")
                self.assertNotEqual(bad_score["exit_code"], 0)


if __name__ == "__main__":
    unittest.main()
