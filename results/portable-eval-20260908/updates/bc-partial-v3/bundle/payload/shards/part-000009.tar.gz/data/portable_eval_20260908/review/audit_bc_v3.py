#!/usr/bin/env python3
"""Read-only post-drain B42 or precommitted B+C78 independent audit.

Does not authorize work, run runner main/resume, or select/replace model outputs.
The operator must establish drain and supply the external authorization SHA.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

from audit_bc_common import HARNESS, Reader, authority, load_harness, same, sha, strict_inventory

CHILD = Path(__file__).with_name("audit_bc_score_child.py")


def audit(run, authorization, authorization_sha256, raw_receipt):
    # Lexical check MUST precede resolve/evidence read/import.
    raw_paths = strict_inventory(run)
    artifact_paths = strict_inventory(run, "results")
    log_paths = strict_inventory(run, "logs")
    root, reader = Path(run).resolve(), Reader()
    auth = authority(root, authorization, authorization_sha256, reader)
    manifest = reader.read(root / "manifest.json", auth["manifest_sha256"])
    commands = reader.read(root / "commands.json", auth["commands_sha256"])
    execution = reader.read(root / "execution.json")
    started = reader.read(root / "execution_started.json")
    raw = reader.read(raw_receipt)
    bc = load_harness()
    args = bc.parse_args(auth["resolved_argv"][3:])
    identity, errors, rows = manifest["identity"], [], []
    def require(condition, message):
        if not condition:
            errors.append(message)
    if args.backend != "openai" or not args.execute or not args.allow_real or args.output_dir != root:
        raise ValueError("Authority does not select a real fixed B/C execution")
    for name in ("audit_bc_common.py", "audit_bc_attempts_v3.py", "audit_bc_score_child.py", "audit_bc_v3.py"):
        reader.bind(Path(__file__).with_name(name))
    require(identity["schema_version"] == "poolact-pilot-bc.v1", "Unknown B/C manifest version")
    require(same(bc.settings(args), identity["settings"]), "Frozen request/settings identity differs")
    acceptance = bc.pilot_helpers().verify_acceptance(args.repo_root, args.static_acceptance)
    require(same(acceptance, identity["static_acceptance"]) and acceptance["source_tree_sha256"] == auth["source_tree_sha256"], "Current accepted source/data identity differs")
    require(same(bc.code_identity(args), identity["harness_files"]) and len(identity["harness_files"]) == 6, "Frozen B/C helper identity differs")
    for path, checksum in identity["harness_files"].items():
        reader.bind(path, checksum)
    jobs, planned = identity["jobs"], bc.build_jobs(args)
    stripped = [{key: value for key, value in job.items() if key not in ("preflight", "environment_overrides")} for job in jobs]
    expected_pools = 78 if args.include_c else 42
    expected_counts = {"jobs": expected_pools, "agent_traces": expected_pools * 4, "B_jobs": 42, "B_agent_traces": 168,
                       "C_jobs": 36 if args.include_c else 0, "C_agent_traces": 144 if args.include_c else 0, "legacy_paramnet_jobs": 9}
    require(same(stripped, planned) and same(identity["counts"], expected_counts), "Precommitted B/C selection/order/seed/command scope differs")
    expected_ids = {job["id"] for job in jobs}
    planned_by_id = {job["id"]: job for job in planned}
    require(len(jobs) == len(expected_ids) == expected_pools, "Duplicate or missing pools")
    require(set(commands) == expected_ids and started.get("manifest_sha256") == sha(root / "manifest.json"), "Command/start receipt namespace differs")
    for section in ("results", "dumps"):
        require({p.name for p in (root / section).iterdir() if p.is_dir()} == expected_ids, section + " namespace differs")
    expected_artifacts = {root / "results" / job["id"] / suffix for job in jobs
                          for suffix in ["summary.json", job["strategy"] + "/result.json"] + [job["strategy"] + "/agents/agent_%d.json" % i for i in range(4)]}
    require(set(artifact_paths) == expected_artifacts, "Complete result JSON inventory differs")
    for path in artifact_paths:
        reader.read(path)  # Every result/summary also rejects duplicate keys.
    require(execution.get("passed") is True and execution.get("executed") is True and execution.get("classification") == "Custom study" and execution.get("unstarted") == [], "Execution incomplete/not accepted")
    status_rows = execution["results"]
    statuses = {row["job_id"]: row for row in status_rows}
    require(len(status_rows) == len(statuses) == expected_pools and set(statuses) == expected_ids, "Final status set differs")
    require(raw.get("passed") is True and raw.get("run_directory") == str(root) and raw.get("pool_count") == expected_pools and raw.get("trace_count") == expected_pools * 4, "Independent raw receipt scope not accepted")
    require(raw.get("manifest_sha256") == sha(root / "manifest.json") and raw.get("execution_sha256") == sha(root / "execution.json") and raw.get("authorization_sha256") == authorization_sha256, "Raw receipt bindings differ")
    require(raw.get("auditor_sha256") == sha(Path(__file__).with_name("audit_bc_attempts_v3.py")) and raw.get("common_sha256") == sha(Path(__file__).with_name("audit_bc_common.py")), "Raw auditor source differs")
    expected_raw_bindings = ({str(Path(authorization).resolve()), str(root / "manifest.json"), str(root / "commands.json"), str(root / "execution.json")}
                             | {str(Path(p).resolve()) for p in auth["file_bindings"]}
                             | {str(p) for p in raw_paths}
                             | {str(p) for p in artifact_paths if p.parent.name == "agents"})
    require({row["path"] for row in raw["file_hashes"]} == expected_raw_bindings and len(raw["file_hashes"]) == len(expected_raw_bindings), "Raw receipt binding inventory differs")
    for binding in raw["file_hashes"]:
        reader.bind(binding["path"], binding["sha256"])
        require(reader.files[binding["path"]]["bytes"] == binding["bytes"] and reader.files[binding["path"]]["mtime_ns"] == binding["mtime_ns"], "Raw audit file size/mtime changed")
    if errors:
        raise ValueError("Pre-scoring identity/authority gate failed: " + "; ".join(errors))
    snapshots, skips, zero_count, request_ids = {}, 0, 0, []
    for job in jobs:
        job_id, status = job["id"], statuses[job["id"]]
        require(Path(job["output_dir"]) == root / "results" / job_id and Path(job["dump_dir"]) == root / "dumps" / job_id, "Pool output namespace differs")
        expected_environment = bc.pilot_helpers().environment_overrides(args, job)
        expected_environment["EXPGYM_RUN_ID"] = "poolact-pilot-bc:" + root.name
        require(same(job["environment_overrides"], expected_environment), job_id + ": runtime/data environment differs")
        expected_commands = {"run": job["command"], "dry_run": job["command"] + ["--dry-run"],
                             "score_guard": bc.guard_command(job, "score"), "resume_guard": bc.guard_command(job, "resume")}
        require(same(commands[job_id], expected_commands), job_id + ": authoritative commands differ")
        require(status.get("passed") is True and type(status["run"].get("exit_code")) is int and status["run"]["exit_code"] == 0, job_id + ": runner failed")
        require(same(reader.read(root / "logs" / job_id / "execution_status.json"), status), job_id + ": final/local status differ")
        current = bc.snapshot(job)
        require(same(current, status["before_audit"]) and same(current, status["resume"]["after"]) and same(current, status["retained_artifacts"]), job_id + ": all result/raw JSON SHA/size/mtime changed")
        snapshots[job_id] = current
        structural = bc.validate_job(job, auth["source_tree_sha256"], "openai")
        require(structural["passed"] is True and same(structural, status["validation"]), job_id + ": artifact/config/aggregate summary differs")
        zero_count += structural["semantic_zero_count"]
        resume = status["resume"]
        require(resume.get("model_construction_and_calls_forbidden") is True and resume.get("all_json_before_equals_after") is True and type(resume.get("verified_skips")) is int and resume["verified_skips"] == 1, job_id + ": guarded skip contract differs")
        for record, filename in ((status["run"], "execution.log"), (status["independent_score"], "score.log"), (resume, "resume.log")):
            require(Path(record["log"]) == root / "logs" / job_id / filename, job_id + ": log namespace differs")
            reader.bind(record["log"], record["log_sha256"])
            require(type(record.get("exit_code")) is int and record["exit_code"] == 0, job_id + ": runner/score/resume exit differs")
        resume_text = Path(resume["log"]).read_text()
        require(resume_text.count("[resume]") == 1 and "rerun" not in resume_text.lower() and "FORBIDDEN" not in resume_text, job_id + ": skip log differs")
        skips += resume["verified_skips"]
        if errors:
            raise ValueError("Pre-scoring job gate failed: " + "; ".join(errors))
        command = [planned_by_id[job_id]["command"][0], "-B", str(CHILD)]
        completed = subprocess.run(command, input=json.dumps({"job": job, "harness_args": auth["resolved_argv"][3:]}),
                                   cwd=args.repo_root, env=bc.environment(args, job), stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, text=True, timeout=300, check=False)
        receipts = [line[len("BC_INDEPENDENT_JSON="):] for line in completed.stdout.splitlines() if line.startswith("BC_INDEPENDENT_JSON=")]
        if len(receipts) != 1:
            raise RuntimeError("No unique isolated scorer receipt: " + job_id + " (exit " + str(completed.returncode) + ")")
        child = json.loads(receipts[0])
        require(completed.returncode == 0 and child["passed"] is True and child["model_or_network_attempts"] == 0, job_id + ": independent same-runtime score/prompt check failed")
        version = "3.7." if job["runtime"] == "legacy_paramnet" else "3.11."
        require(child["original_score_receipt"]["runtime"]["version"].startswith(version), job_id + ": wrong actual interpreter")
        request_ids.extend(child["request_ids"])
        rows.append({"job_id": job_id, "runtime_kind": job["runtime"], "child_command": command,
                     "child_exit_code": completed.returncode, "stderr_sha256": hashlib.sha256(completed.stderr.encode()).hexdigest(),
                     "semantic_zero_count_preserved": structural["semantic_zero_count"], "result": child})
    expected_requests = {path.stem for path in raw_paths}
    require(len(request_ids) == len(set(request_ids)) == raw["attempt_count"] and set(request_ids) == expected_requests, "Full score/prompt/raw request coverage differs")
    require(skips == expected_pools and execution["validated_trace_count"] == expected_pools * 4 and execution["semantic_zero_count"] == zero_count, "Final pool/trace/skip/zero totals differ")
    for job in jobs:
        require(same(bc.snapshot(job), snapshots[job["id"]]), "Audit changed original evidence")
    require(strict_inventory(run) == raw_paths and strict_inventory(run, "results") == artifact_paths, "Full evidence inventory changed")
    require(strict_inventory(run, "logs") == log_paths, "Log namespace changed")
    require(same(bc.pilot_helpers().verify_acceptance(args.repo_root, args.static_acceptance), acceptance), "Source changed during audit")
    reader.unchanged()
    return {"schema_version": 1, "created_utc": datetime.now(timezone.utc).isoformat(), "passed": not errors,
            "classification": "Custom study; independent post-drain B/C integrity audit", "errors": errors,
            "run_directory": str(root), "authorization_sha256": authorization_sha256,
            "source_tree_sha256": auth["source_tree_sha256"], "include_c_precommitted": args.include_c,
            "pool_count": len(rows), "validated_traces": len(rows) * 4, "guarded_skips": skips,
            "runtime_pool_counts": dict(Counter(row["runtime_kind"] for row in rows)),
            "semantic_zero_count_preserved": zero_count, "raw_requests_prompt_checked": len(request_ids),
            "rows": rows, "file_bindings": {path: row["sha256"] for path, row in reader.files.items()},
            "limitations": ["Operator drain and serving authority are external prerequisites, not inferred from elapsed time or generated by this auditor.",
                            "Scores use original pinned evaluator/aggregation separately in each selected Python 3.7/3.11 runtime, not an independent metric implementation.",
                            "N4 graph-owned instructions/syntax checked on untrimmed stored messages before deterministic trim; graph data values/concurrent temporal visibility are not reconstructed.",
                            "Every result JSON including summary and every raw JSON is compared by set/SHA/size/mtime; official guarded resume made identical summary writes no-ops.",
                            "Raw usage and HTTP transport receipts remain separately bound. No forced-final per-agent requirement, semantic resampling, formal inference, or automatic C selection."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--authorization", type=Path, required=True)
    parser.add_argument("--authorization-sha256", required=True)
    parser.add_argument("--raw-receipt", type=Path, required=True)
    parser.add_argument("--receipt", type=Path, required=True)
    args = parser.parse_args()
    if args.receipt.exists() or args.run.resolve() in args.receipt.resolve().parents:
        raise ValueError("Receipt must be new and outside original run")
    sys.dont_write_bytecode = True
    result = audit(args.run, args.authorization, args.authorization_sha256, args.raw_receipt)
    with args.receipt.open("x") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({k: result[k] for k in ("passed", "errors", "pool_count", "validated_traces", "guarded_skips", "runtime_pool_counts", "semantic_zero_count_preserved", "raw_requests_prompt_checked")}))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
