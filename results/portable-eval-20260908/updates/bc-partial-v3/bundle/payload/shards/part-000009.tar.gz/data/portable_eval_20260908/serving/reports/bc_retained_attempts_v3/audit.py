#!/usr/bin/env python3
"""Post-drain, pinned, CPU-only B/C retained-attempt accounting; no dispatch."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import stat

HERE = Path(__file__).resolve().parent
STUDY = HERE.parents[2]
FROZEN = {
    "router": (STUDY / "serving/router.py", "ac49e499c311a3c505b8e53b772d9e64ee7e5d954ad4ff7523afb49c19892987"),
    "collector": (HERE.parent / "bc_router_rawjoin_v3/join.py", "0cf550e883cf0e345257cec8b04d45ec4827b404affff7f46359bdb927517ddf"),
    "raw_auditor": (STUDY / "review/audit_bc_attempts_v3.py", "69f3b4a43ef787dd1ce273a743af6df9231e5abca33223be87c24abe83df525a"),
    "raw_common": (STUDY / "review/audit_bc_common.py", "2ccc0af3f63b6768296ad554c407f96c74dcd8db5e7e670bb6d7786486df9672"),
}
HARNESS_SHA = "3315917340fcd204b5d74e99eba9709415a2ee76c4a76b6203078684f010bc3c"
FIELDS = ("input_tokens", "output_tokens", "provider_total_tokens", "reasoning_tokens", "cache_read_tokens", "cache_write_tokens")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def checksum(value):
    require(isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value), "External SHA256 missing/invalid")
    return value


def strict_json(data):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "Duplicate JSON key")
            result[key] = value
        return result
    def reject(value):
        raise ValueError("Nonfinite JSON constant: " + value)
    value = json.loads(data, object_pairs_hook=pairs, parse_constant=reject)
    json.dumps(value, allow_nan=False)  # Also rejects exponent overflow such as 1e999.
    return value


def same(a, b):
    return json.dumps(a, sort_keys=True, allow_nan=False) == json.dumps(b, sort_keys=True, allow_nan=False)


def safe_path(value):
    require(isinstance(value, (str, Path)), "Invalid path type")
    path = Path(value)
    require(path.is_absolute() and ".." not in path.parts, "Evidence path must be absolute without parent traversal")
    for part in list(path.parents) + [path]:
        require(not part.is_symlink(), "Unsafe symlink: " + str(part))
    return path


def finite(value):
    return type(value) in (int, float) and math.isfinite(value)


def timestamp(value):
    require(isinstance(value, str), "Missing timestamp")
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    require(parsed.tzinfo is not None, "Naive timestamp is not accepted")
    return parsed.timestamp()


class Reader:
    def __init__(self):
        self.files = {}

    def bind(self, path, expected=None, original=None):
        path = safe_path(path)
        before = path.stat()
        require(stat.S_ISREG(before.st_mode), "Evidence is not a regular file")
        data = path.read_bytes()
        after = path.stat()
        stamp = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns)
        require(stamp(before) == stamp(after), "Evidence changed during read")
        row = {"path": str(path), "sha256": digest(data), "bytes": len(data), "mtime_ns": after.st_mtime_ns}
        if expected is not None:
            require(row["sha256"] == checksum(expected), "SHA binding differs: " + str(path))
        if original is not None:
            require(all(row.get(k) == original.get(k) for k in ("path", "sha256", "bytes", "mtime_ns")), "Original audit binding changed: " + str(path))
        if str(path) in self.files:
            require(self.files[str(path)] == row, "Evidence changed between reads")
        self.files[str(path)] = row
        return data

    def read(self, binding):
        require(isinstance(binding, dict) and set(binding) == {"path", "sha256"}, "Expected exact path/SHA binding")
        return strict_json(self.bind(binding["path"], binding["sha256"]))

    def unchanged(self):
        for row in list(self.files.values()):
            self.bind(row["path"], row["sha256"], row)


def dump_inventory(root):
    directory = safe_path(root / "dumps")
    require(directory.is_dir(), "Missing dump directory")
    found = []
    for current, dirs, files in os.walk(directory, followlinks=False):
        for name in dirs + files:
            path = safe_path(Path(current) / name)
            require(path.is_dir() or stat.S_ISREG(path.stat().st_mode), "Nonregular dump entry")
        for name in files:
            path = Path(current) / name
            relative = path.relative_to(directory)
            require(len(relative.parts) == 2 and path.suffix == ".json", "Unexpected/temporary/nested dump file: " + str(path))
            found.append(path)
    return sorted(found)


def usage_values(usage):
    require(usage is None or isinstance(usage, dict), "Usage must be object or unknown")
    usage = usage or {}
    for field in ("prompt_tokens_details", "input_tokens_details", "completion_tokens_details", "output_tokens_details"):
        require(usage.get(field) is None or isinstance(usage[field], dict), "Invalid usage details")
    sources = defaultdict(dict)
    for key, field in (("prompt_tokens", "input_tokens"), ("input_tokens", "input_tokens"),
                       ("completion_tokens", "output_tokens"), ("output_tokens", "output_tokens"),
                       ("total_tokens", "provider_total_tokens"), ("reasoning_tokens", "reasoning_tokens")):
        if usage.get(key) is not None:
            sources[field][key] = usage[key]
    for detail in ("prompt_tokens_details", "input_tokens_details"):
        for key, field in (("cached_tokens", "cache_read_tokens"), ("cache_write_tokens", "cache_write_tokens")):
            value = (usage.get(detail) or {}).get(key)
            if value is not None:
                sources[field][detail + "." + key] = value
    for detail in ("completion_tokens_details", "output_tokens_details"):
        value = (usage.get(detail) or {}).get("reasoning_tokens")
        if value is not None:
            sources["reasoning_tokens"][detail + ".reasoning_tokens"] = value
    for values in sources.values():
        require(all(type(v) is int and v >= 0 for v in values.values()), "Reported usage must be nonnegative integers, not bool")
    result, conflicts = {}, {}
    for field in FIELDS:
        values = list(sources[field].values())
        if len(set(values)) > 1:
            result[field], conflicts[field] = None, dict(sources[field])
        else:
            result[field] = values[0] if values else None
    if all(result[k] is not None for k in FIELDS[:3]):
        require(result["provider_total_tokens"] == result["input_tokens"] + result["output_tokens"], "Provider token total differs")
    if result["output_tokens"] is not None:
        require(all(v <= result["output_tokens"] for v in sources["reasoning_tokens"].values()), "Reasoning exceeds completion-token subset")
    return result, conflicts, dict(sources)


def totals(rows, complete=True):
    return {key: {"known_sum": sum(row[key] for row in rows if row[key] is not None),
                  "known_count": sum(row[key] is not None for row in rows),
                  "unknown_count": sum(row[key] is None for row in rows),
                  "complete_total": sum(row[key] for row in rows) if complete and all(row[key] is not None for row in rows) else None}
            for key in FIELDS}


def contained(row, start, end, skew):
    return start - skew <= row["started_unix"] and row["started_unix"] + row["elapsed_seconds"] <= end + skew


def closed(row):
    return (row.get("complete") is True and row.get("upstream_close_started") is True
            and row.get("upstream_close_completed") is True and row.get("upstream_close_error") is None
            and row.get("error") is None)


def router_generated(row, raw):
    absent = ("response_sha256", "http_status", "upstream_close_started", "upstream_close_completed", "upstream_close_error")
    if not (row.get("complete") is False and row.get("error") == "RemoteProtocolError" and all(k not in row for k in absent)):
        return False
    # Starlette JSONResponse's UTF-8 bytes: default insertion order, compact separators.
    expected = json.dumps({"error": "upstream transport failure", "detail": "RemoteProtocolError", "replica": row["replica"]},
                          ensure_ascii=False, allow_nan=False, separators=(",", ":"))
    return raw.get("response_raw") == expected and raw.get("http_status") == 502


def legacy_inventory(raws, router, root):
    """Rebuild only the frozen collector's inventory/first-success errors verbatim."""
    pairs, matched, inventory, errors = defaultdict(list), set(), [], []
    for index, row in enumerate(router):
        pairs[(row.get("payload_sha256"), row.get("response_sha256"))].append(index)
    for path, raw in raws:
        payload = digest(json.dumps(raw["request_payload"]).encode("utf-8"))
        response = digest(raw["response_raw"].encode("utf-8")) if raw.get("response_raw") is not None else None
        candidates = pairs.get((payload, response), [])
        item = {"dump": str(path), "dump_sha256": digest(path.read_bytes()),
                "client_request_id": raw["request_id"], "generation_id": raw.get("generation_id"),
                "context": raw.get("context", {}), "job_id": path.parent.name,
                "state": raw["state"], "attempt": raw.get("attempt"), "will_retry": raw.get("will_retry"),
                "http_status": raw.get("http_status"), "started_at_utc": raw["started_at_utc"],
                "finished_at_utc": raw.get("finished_at_utc"), "reconstructed_payload_sha256": payload,
                "response_raw_utf8_sha256": response, "router_candidate_count": len(candidates)}
        if len(candidates) != 1:
            errors.append({"kind": "missing_or_ambiguous_byte_join", "dump": str(path), "candidate_count": len(candidates)})
        else:
            index = candidates[0]
            if index in matched:
                errors.append({"kind": "router_row_reused", "router_index": index})
            matched.add(index)
            item.update(router_line_1based=index + 1, router_receipt=router[index], payload_bytes_match=True, response_bytes_match=True)
            # Match the frozen collector exactly here, including its omission
            # of the generic error field; the new association is stricter below.
            old_closed = (router[index].get("complete") is True and router[index].get("upstream_close_started") is True
                          and router[index].get("upstream_close_completed") is True and not router[index].get("upstream_close_error"))
            if not old_closed or router[index].get("http_status") != 200:
                errors.append({"kind": "router_completion_or_http_failure", "router_index": index})
        if raw["state"] != "success" or raw.get("http_status") not in (None, 200):
            errors.append({"kind": "client_not_success", "dump": str(path), "state": raw["state"]})
        if raw.get("will_retry") is not False or type(raw.get("attempt")) is not int or raw["attempt"] != 1:
            errors.append({"kind": "client_retry_or_noninitial_attempt", "dump": str(path), "attempt": raw.get("attempt"), "will_retry": raw.get("will_retry")})
        inventory.append(item)
    window = [min(timestamp(r["started_at_utc"]) for _, r in raws), max(timestamp(r["finished_at_utc"]) for _, r in raws)]
    unmatched = []
    for index, row in enumerate(router):
        if index not in matched:
            in_window = window[0] - 1 <= row["started_unix"] <= window[1] + 1
            unmatched.append({"router_line_1based": index + 1, "within_scenario_time_window": in_window, "router_receipt": row})
            if in_window:
                errors.append({"kind": "unmatched_router_inside_scenario_window", "router_index": index})
    return inventory, errors, unmatched, window


def audit(pins_path, pins_sha256):
    reader = Reader()
    reader.bind(HERE / "audit.py")
    reader.bind(HERE / "CONTRACT.zh.md")
    pins = strict_json(reader.bind(pins_path, checksum(pins_sha256)))
    require(pins.get("schema_version") == "portable_eval.bc_retained_attempts_pins.v1", "Unknown pins contract")
    root = safe_path(pins["run_directory"])
    inputs = pins["inputs"]
    require(set(inputs) == {"strict_receipt", "raw_audit_receipt", "completion", "authorization", "router_snapshot", "inventory"}, "Incomplete/unrecognized input pins")
    loaded = {key: reader.read(value) for key, value in inputs.items() if key not in ("router_snapshot", "inventory")}
    for value in inputs.values():
        require(isinstance(value, dict) and set(value) == {"path", "sha256"}, "Expected exact path/SHA binding")
    snapshot = reader.bind(inputs["router_snapshot"]["path"], inputs["router_snapshot"]["sha256"])
    inventory_bytes = reader.bind(inputs["inventory"]["path"], inputs["inventory"]["sha256"])
    require(not snapshot or snapshot.endswith(b"\n"), "Unfinished router snapshot line")
    router = [strict_json(line) for line in snapshot.splitlines() if line.strip()]
    inventory = [strict_json(line) for line in inventory_bytes.splitlines() if line.strip()]
    skew = pins["clock_skew_seconds"]
    require(finite(skew) and 0 <= skew <= 1, "Explicit bounded clock skew [0,1] required")
    drain = pins["drain"]
    require(drain.get("confirmed") is True and drain.get("completion_sha256") == inputs["completion"]["sha256"]
            and drain.get("router_snapshot_sha256") == inputs["router_snapshot"]["sha256"], "External post-drain attestation mismatch")
    drained_at = timestamp(drain["confirmed_at_utc"])
    strict, raw_audit, completion, auth = (loaded[k] for k in ("strict_receipt", "raw_audit_receipt", "completion", "authorization"))
    for path, expected in FROZEN.values():
        reader.bind(path, expected)
    require(raw_audit.get("auditor_sha256") == FROZEN["raw_auditor"][1] and raw_audit.get("common_sha256") == FROZEN["raw_common"][1], "Unrecognized independent raw auditor")
    require(raw_audit.get("schema_version") == 1 and raw_audit.get("passed") is True and raw_audit.get("errors") == [], "Independent raw audit must pass without errors")
    require(raw_audit.get("run_directory") == str(root) and raw_audit.get("authorization_sha256") == inputs["authorization"]["sha256"], "Raw audit run/authorization mismatch")
    bindings = raw_audit["file_hashes"]
    require(isinstance(bindings, list) and bindings and len({r["path"] for r in bindings}) == len(bindings), "Invalid original audit file bindings")
    for binding in bindings:
        reader.bind(binding["path"], binding["sha256"], binding)
    original_paths = {r["path"] for r in bindings}
    require(auth.get("authorized") is True and isinstance(auth.get("authorization_kind"), str) and auth["authorization_kind"]
            and auth.get("output_dir") == str(root) and auth.get("harness_sha256") == HARNESS_SHA, "Authorization scope/harness mismatch")
    require(isinstance(auth.get("file_bindings"), dict) and auth["file_bindings"], "Missing authorization file bindings")
    for path, expected in auth["file_bindings"].items():
        reader.bind(path, expected)
        require(path in original_paths, "Authorization binding absent from independent audit")
    require(inputs["authorization"]["path"] in original_paths, "Authorization not bound by raw auditor")
    manifest_path, execution_path = root / "manifest.json", root / "execution.json"
    manifest = strict_json(reader.bind(manifest_path, auth["manifest_sha256"]))
    reader.bind(root / "commands.json", auth["commands_sha256"])
    require(inputs["completion"]["path"] == str(execution_path) and raw_audit.get("execution_sha256") == inputs["completion"]["sha256"], "Completion identity mismatch")
    require(raw_audit.get("manifest_sha256") == auth["manifest_sha256"], "Manifest raw audit binding mismatch")
    for path in (manifest_path, execution_path, root / "commands.json"):
        require(str(path) in original_paths, "Original audit lacks required run file")
    require(strict.get("schema_version") == "portable_eval.bc_router_raw_byte_join.v1" and strict.get("status") in ("FAIL", "PASS"), "Invalid frozen strict receipt")
    require(strict.get("scenario_namespace") == str(root), "Strict run differs")
    require(strict.get("mode") == "offline_no_network_no_generation", "Strict collector mode differs")
    require(set(strict["bound_sources"]) == {"manifest", "completion_receipt", "static_acceptance", "client_source", "router_source", "capacity_receipt", "collector"}, "Strict source binding set differs")
    require(set(strict["artifacts"]) == {"router_snapshot", "inventory", "unmatched_router"}, "Strict artifact binding set differs")
    require(timestamp(strict["observed_utc"]) >= drained_at, "Strict collector predates ROOT drain confirmation")
    for key, binding in strict["bound_sources"].items():
        reader.bind(binding["path"], binding["sha256"])
    require(strict["bound_sources"]["collector"] == {"path": str(FROZEN["collector"][0]), "sha256": FROZEN["collector"][1]}, "Strict collector not frozen")
    require(strict["bound_sources"]["router_source"] == {"path": str(FROZEN["router"][0]), "sha256": FROZEN["router"][1]}, "Router source not frozen")
    require(strict["bound_sources"]["manifest"] == {"path": str(manifest_path), "sha256": auth["manifest_sha256"]}
            and strict["bound_sources"]["completion_receipt"] == inputs["completion"], "Strict manifest/completion binding differs")
    for key, binding in strict["artifacts"].items():
        reader.bind(binding["path"], binding["sha256"])
    require(strict["artifacts"]["router_snapshot"] == inputs["router_snapshot"] and strict["artifacts"]["inventory"] == inputs["inventory"], "Copied router/inventory binding mismatch")
    identity, jobs = manifest["identity"], manifest["identity"]["jobs"]
    settings = identity["settings"]
    include_c = settings.get("include_c_precommitted")
    require(type(include_c) is bool, "C precommit flag must be bool")
    count = 78 if include_c else 42
    expected_counts = {"jobs": count, "agent_traces": count * 4, "B_jobs": 42, "B_agent_traces": 168,
                       "C_jobs": 36 if include_c else 0, "C_agent_traces": 144 if include_c else 0,
                       "legacy_paramnet_jobs": 9}
    require(identity.get("counts") == expected_counts and sum(j.get("runtime") == "legacy_paramnet" for j in jobs) == 9, "Fixed matrix counts/runtime differ")
    stages = {"B1_hpo": 27, "B2_search_audit": 12, "B3_nas101a_tight": 3}
    if include_c:
        stages["C_development_repeats"] = 36
    require(len(jobs) == count and len({j["id"] for j in jobs}) == count and Counter(j["stage"] for j in jobs) == Counter(stages), "Not fixed B/C matrix")
    job_ids = {j["id"] for j in jobs}
    require(settings.get("backend") == "openai" and settings.get("tool_protocol") == "native" and type(settings.get("agents")) is int and settings["agents"] == 4, "Not real authorized native N4 scope")
    require(type(settings.get("workers")) is int and 1 <= settings["workers"] <= 64, "Invalid authorized worker count")
    argv = auth["resolved_argv"]
    require(isinstance(argv, list) and len(argv) >= 4 and argv[1] in ("-B", "-u") and argv.count("--include-c") == int(include_c)
            and str(safe_path(argv[2])) == str(STUDY / "harness/poolact_pilot_timing.py"), "Authorized argv/C precommit differs")
    require(all(j.get("system") == "poolact" and type(j.get("expected_traces")) is int and j["expected_traces"] == 4
                and j["dump_dir"] == str(root / "dumps" / j["id"]) for j in jobs), "Job trace/dump scope differs")
    require(len(identity["harness_files"]) == 6 and strict.get("bound_harness_files") == identity["harness_files"], "Six frozen harness bindings required")
    for path, expected in identity["harness_files"].items():
        reader.bind(path, expected)
    acceptance_binding = identity["static_acceptance"]
    require(strict["bound_sources"]["static_acceptance"] == {k: acceptance_binding[k] for k in ("path", "sha256")}, "Static acceptance binding differs")
    acceptance = strict_json(reader.bind(acceptance_binding["path"], acceptance_binding["sha256"]))
    require(auth["source_tree_sha256"] == raw_audit.get("source_tree_sha256", auth["source_tree_sha256"]) == strict["source_tree_sha256"] == acceptance_binding["source_tree_sha256"] == acceptance["source_tree_sha256"], "Source tree identities differ")
    require(acceptance["files"]["expgym/llm_clients.py"] == strict["bound_sources"]["client_source"]["sha256"], "Frozen client source differs")
    require(completion.get("executed") is True and completion.get("passed") is True and completion.get("unstarted") == [] and not completion.get("failed"), "Run not complete/drained")
    completed = completion["results"]
    require(len(completed) == count and {r["job_id"] for r in completed} == job_ids
            and all(r.get("passed") is True and type(r["run"].get("exit_code")) is int and r["run"]["exit_code"] == 0 for r in completed), "Incomplete completion job set")
    require(completion.get("validated_trace_count") == count * 4 and raw_audit.get("pool_count") == count
            and raw_audit.get("trace_count") == count * 4, "N4 completion/raw audit count differs")
    paths = dump_inventory(root)
    require(paths and {str(p) for p in paths} == {p for p in original_paths if root / "dumps" in Path(p).parents}, "Original audit/raw dump set mismatch")
    raws, by_id, by_generation = [], {}, defaultdict(list)
    for path in paths:
        raw = strict_json(reader.bind(path))
        rid = raw.get("request_id")
        require(isinstance(rid, str) and rid and path.stem == rid and rid not in by_id and path.parent.name in job_ids, "Raw request namespace/uniqueness differs")
        require(raw.get("schema_version") == "expgym.api_attempt.v1" and raw.get("run_id") == "poolact-pilot-bc:" + root.name, "Raw schema/run differs")
        require(isinstance(raw.get("client_id"), str) and raw["client_id"] and isinstance(raw.get("generation_id"), str) and raw["generation_id"], "Missing raw client/generation")
        require(type(raw.get("attempt")) is int and 1 <= raw["attempt"] <= 3 and type(raw.get("max_attempts")) is int and raw["max_attempts"] == 3, "Raw retry bounds invalid")
        require(raw.get("state") in ("success", "error", "malformed_response"), "Late/in-progress raw attempt")
        start, end = timestamp(raw["started_at_utc"]), timestamp(raw["finished_at_utc"])
        require(start <= end <= drained_at and finite(raw.get("wall_time_seconds")) and raw["wall_time_seconds"] >= 0, "Raw interval reversed/late/nonfinite")
        require(isinstance(raw.get("request_payload"), dict), "Invalid payload object")
        raws.append((path, raw)); by_id[rid] = (path, raw); by_generation[(raw["client_id"], raw["generation_id"])].append(raw)
    require(len(raws) == raw_audit["attempt_count"], "Raw audit attempt count differs")
    ledger_ids, ledger_clients, ledger_generations = [], set(), set()
    trace_rows = raw_audit["trace_rows"]
    require(len(trace_rows) == count * 4 and {(r["job_id"], r["agent_id"]) for r in trace_rows} == {(j, a) for j in job_ids for a in range(4)}, "Independent raw N4 ledger coverage differs")
    for trace in trace_rows:
        cid = trace["client_id"]
        require(cid not in ledger_clients, "Raw audit client reused")
        ledger_clients.add(cid)
        require(trace["path"] in original_paths, "Raw audit agent path is not bound")
        require(isinstance(trace["request_ids"], list) and trace["request_ids"], "Empty raw audit client ledger")
        seen = set()
        for rid in trace["request_ids"]:
            require(rid in by_id and by_id[rid][0].parent.name == trace["job_id"] and by_id[rid][1]["client_id"] == cid, "Cross-client/job ledger request")
            seen.add(by_id[rid][1]["generation_id"])
        require(set(trace["generation_ids"]) == seen and not seen.intersection(ledger_generations), "Raw audit generation ledger differs/reused")
        ledger_generations.update(seen); ledger_ids.extend(trace["request_ids"])
    require(len(ledger_ids) == len(set(ledger_ids)) == len(raws) and set(ledger_ids) == set(by_id), "Raw/independent ledger is not a bijection")
    errors, chains, retry_ids = [], [], set()
    for (cid, gid), records in sorted(by_generation.items()):
        records.sort(key=lambda r: r["attempt"])
        valid = [r["attempt"] for r in records] == list(range(1, len(records) + 1)) and len(records) <= 3
        payloads = [json.dumps(r["request_payload"]).encode("utf-8") for r in records]
        valid = valid and all(p == payloads[0] for p in payloads)
        for index, raw in enumerate(records):
            if index == len(records) - 1:
                valid = valid and raw["state"] == "success" and raw.get("will_retry") is False and raw.get("error") is None and raw.get("retry_delay_seconds") is None
            else:
                delay = raw.get("retry_delay_seconds")
                valid = valid and raw["state"] == "error" and raw.get("will_retry") is True and (raw.get("error") or {}).get("type") == "HTTPError" and type(raw.get("http_status")) is int and raw["http_status"] in (429, 500, 502, 503, 504)
                valid = valid and finite(delay) and 0 <= delay <= 30
                if finite(delay):
                    # ISO timestamps have microsecond resolution; no fitted skew
                    # or millisecond grace is used for this same-client clock.
                    valid = valid and timestamp(records[index + 1]["started_at_utc"]) + 0.000001 >= timestamp(raw["finished_at_utc"]) + delay
        if not valid:
            errors.append({"kind": "retry_chain_not_proven_by_this_supplement", "client_id": cid, "generation_id": gid,
                           "interpretation": "Evidence not covered/consistent here; not a claim that the frozen client forbids other transient transports, and never permission to resample."})
        elif len(records) > 1:
            retry_ids.update(r["request_id"] for r in records)
        chains.append({"client_id": cid, "generation_id": gid, "request_ids": [r["request_id"] for r in records], "attempts": len(records), "passed": valid})
    require(len(by_generation) == raw_audit["generation_count"] and len(ledger_clients) == raw_audit["client_count"], "Independent generation/client counts differ")
    for row in router:
        require(isinstance(row, dict) and finite(row.get("started_unix")) and finite(row.get("elapsed_seconds")) and row["elapsed_seconds"] >= 0
                and type(row.get("replica")) is int and 0 <= row["replica"] <= 3 and type(row.get("complete")) is bool, "Invalid/in-progress router row")
        checksum(row.get("payload_sha256"))
    require(all(isinstance(r.get("request_id"), str) and r["request_id"] for r in router) and len({r["request_id"] for r in router}) == len(router), "Router request IDs missing/reused")
    expected_inventory, expected_strict_errors, unmatched, window = legacy_inventory(raws, router, root)
    require(same(inventory, expected_inventory), "Frozen strict inventory differs from original raw/router bytes")
    require(same(strict.get("errors"), expected_strict_errors), "Unexpected strict errors or error evidence differs; no global waiver")
    require(strict["status"] == ("FAIL" if expected_strict_errors else "PASS"), "Frozen strict status inconsistent")
    require(strict.get("client_attempt_count") == len(raws) and strict.get("router_snapshot_count") == len(router)
            and same(strict.get("scenario_window_unix"), window), "Strict inventory/window counts differ")
    require(strict.get("job_count") == count and strict.get("expected_trace_count") == count * 4
            and strict.get("client_states") == dict(Counter(r["state"] for _, r in raws))
            and strict.get("attempts_per_job") == dict(Counter(p.parent.name for p, _ in raws)), "Strict manifest/state/job counts differ")
    require(same(strict_json(reader.bind(strict["artifacts"]["unmatched_router"]["path"])), unmatched), "Strict unmatched inventory differs")
    pairs = defaultdict(list)
    for index, row in enumerate(router):
        pairs[(row.get("payload_sha256"), row.get("response_sha256"))].append(index)
    joins, matched, values, warnings = [], {}, [], []
    for path, raw in raws:
        rid = raw["request_id"]
        start, end = timestamp(raw["started_at_utc"]), timestamp(raw["finished_at_utc"])
        payload_sha = digest(json.dumps(raw["request_payload"]).encode("utf-8"))
        body = raw.get("response_raw")
        response_sha = digest(body.encode("utf-8")) if isinstance(body, str) else None
        parsed = None
        if isinstance(body, str):
            try:
                parsed = strict_json(body)
            except ValueError:
                require(raw.get("response_json") is None and raw["state"] != "success", "Non-strict response or parsed/wire mismatch")
            else:
                require(same(parsed, raw.get("response_json")), "Parsed response differs from response_raw")
        else:
            require(body is None and raw.get("response_json") is None and raw["state"] != "success", "Missing successful wire response")
        usage = parsed.get("usage") if isinstance(parsed, dict) else None
        counted, conflicts, reported = usage_values(usage)
        values.append(counted)
        if conflicts:
            warnings.append({"request_id": rid, "kind": "conflicting_usage_unknown", "sources": conflicts})
        candidates = pairs.get((payload_sha, response_sha), []) if response_sha is not None else []
        evidence = "unmatched"
        if len(candidates) == 1 and contained(router[candidates[0]], start, end, skew):
            row = router[candidates[0]]
            if closed(row) and type(row.get("http_status")) is int:
                if raw["state"] == "success" and raw.get("http_status") in (None, 200) and row["http_status"] == 200:
                    evidence = "response_double_sha_http200_closed"
                elif raw["state"] == "error" and row["http_status"] != 200 and raw.get("http_status") == row["http_status"]:
                    evidence = "response_double_sha_upstream_http_error_closed"
        if evidence == "unmatched" and raw["state"] == "error" and response_sha is not None:
            candidates = [i for i, row in enumerate(router) if row["payload_sha256"] == payload_sha
                          and contained(row, start, end, skew) and router_generated(row, raw)]
            if len(candidates) == 1:
                evidence = "request_only_association_router_generated_502"
        index = candidates[0] if evidence != "unmatched" else None
        if index is None or index in matched:
            errors.append({"kind": "missing_ambiguous_or_reused_router_association", "request_id": rid, "candidate_lines": [i + 1 for i in candidates]})
        else:
            matched[index] = rid
        joins.append({"request_id": rid, "dump": str(path), "dump_sha256": reader.files[str(path)]["sha256"],
                      "state": raw["state"], "client_http_status": raw.get("http_status"), "attempt": raw["attempt"],
                      "client_id": raw["client_id"], "generation_id": raw["generation_id"],
                      "evidence": evidence, "router_line_1based": None if index is None else index + 1,
                      "request_payload_sha256": payload_sha, "client_retained_response_sha256": response_sha,
                      "router_response_sha256": router[index].get("response_sha256") if index is not None else None,
                      "upstream_generation_and_billable_cost": "unknown" if evidence.startswith("request_only") else "not_independently_metered",
                      "nonempty_reasoning_content_responses": sum(bool((c.get("message") or {}).get("reasoning_content")) for c in (parsed.get("choices", []) if isinstance(parsed, dict) else []) if isinstance(c, dict)),
                      "usage": counted, "reported_usage_sources": reported, "usage_conflicts": conflicts})
    outside, orphans = [], []
    for index, row in enumerate(router):
        if index not in matched:
            item = {"router_line_1based": index + 1, "router_receipt": row}
            overlaps = row["started_unix"] <= window[1] + skew and row["started_unix"] + row["elapsed_seconds"] >= window[0] - skew
            (orphans if overlaps else outside).append(item)
    if orphans:
        errors.append({"kind": "orphan_router_rows_intersect_batch", "lines": [r["router_line_1based"] for r in orphans]})
    by_path = {j["dump"]: j for j in joins}
    explained = []
    for error in expected_strict_errors:
        row = by_path.get(error.get("dump"))
        if row is None and type(error.get("router_index")) is int:
            rid = matched.get(error["router_index"])
            row = next((r for r in joins if r["request_id"] == rid), None)
        kind = error["kind"]
        ok = row is not None and row["request_id"] in retry_ids and row["evidence"] != "unmatched"
        if kind in ("missing_or_ambiguous_byte_join", "unmatched_router_inside_scenario_window"):
            ok = ok and row["evidence"].startswith("request_only")
        elif kind == "router_completion_or_http_failure":
            ok = ok and row["evidence"] == "response_double_sha_upstream_http_error_closed"
        elif kind not in ("client_not_success", "client_retry_or_noninitial_attempt"):
            ok = False
        explained.append({"original_error": error, "explained_by_authorized_retained_retry": bool(ok),
                          "request_id": row["request_id"] if row is not None else None})
        if not ok:
            errors.append({"kind": "unexplained_strict_error", "original_error": error})
    require(dump_inventory(root) == paths, "Dump namespace changed during audit")
    reader.unchanged()
    usage = totals(values, complete=not errors)
    request_only = sum(j["evidence"].startswith("request_only") for j in joins)
    byte_count = sum(j["evidence"].startswith("response_double") for j in joins)
    usage_complete = not errors and all(v["complete_total"] is not None for v in usage.values())
    return {"schema_version": "portable_eval.bc_retained_attempts.v1", "created_utc": datetime.now(timezone.utc).isoformat(),
            "classification": "Custom study; retained-attempt offline accounting, no scores or model calls",
            "status": "FAIL" if errors else "COMPLETE" if usage_complete and not request_only else "INCOMPLETE",
            "accounting_integrity": "FAIL" if errors else "PASS", "run_directory": str(root),
            "root_pins": {"path": str(pins_path), "sha256": pins_sha256}, "root_drain_attestation": drain,
            "clock_skew_seconds": skew, "scenario_window_unix": window,
            "pool_count": count, "trace_count": count * 4, "attempt_count": len(raws),
            "client_states": dict(Counter(r["state"] for _, r in raws)),
            "dimensions": {"received_byte_fidelity": {"double_sha_attempts": byte_count, "request_only_attempts": request_only, "all_attempts_double_sha": byte_count == len(raws) and not errors},
                           "router_error_attribution": {"request_only_associations": request_only, "response_or_close_evidence_for_generated_502": False},
                           "authorized_retry_chains": {"passed": all(c["passed"] for c in chains), "retry_chains": sum(c["attempts"] > 1 for c in chains)},
                           "all_attempt_usage_completeness": {"complete": usage_complete, "provider_reported_only": True}},
            "all_attempt_usage": usage, "attempts": joins, "retry_chains": chains,
            "strict_receipt_preserved": {"binding": inputs["strict_receipt"], "status": strict["status"], "errors": strict["errors"], "per_error_explanation": explained},
            "unmatched_router_inside_batch": orphans, "router_rows_outside_batch": outside,
            "errors": errors, "warnings": warnings, "file_hashes": sorted(reader.files.values(), key=lambda r: r["path"]),
            "limitations": ["ROOT drain is an externally pinned attestation, not measured here.",
                            "Router-generated 502 has request-only association; upstream work, billable tokens and close are unknown.",
                            "Unknown counts remain unknown after a successful retry; reasoning is a subset of output and is not added twice.",
                            "This supplement covers HTTPError retries only. Valid URLError/TimeoutError policies may be unproven here, not unauthorized; never resample to fill missing evidence.",
                            "INCOMPLETE describes transport/usage evidence only, not independently accepted model scoring or matrix completion; never generate again to fill unknown costs.",
                            "Original strict FAIL is unchanged. No semantic scoring, prompt acceptance, continuous health, deterministic replay or new authorization is claimed."]}


def write_report(report, out):
    out = safe_path(out)
    root = Path(report["run_directory"])
    require(out != root and root not in out.parents, "Output must be outside original run")
    require(all(out != Path(r["path"]) and out not in Path(r["path"]).parents for r in report["file_hashes"]), "Output overlaps original evidence")
    out.mkdir(parents=True, exist_ok=False)
    path = out / "receipt.json"
    with path.open("x", encoding="utf-8") as handle:
        json.dump(report, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")
    return {"path": str(path), "sha256": digest(path.read_bytes()), "status": report["status"], "accounting_integrity": report["accounting_integrity"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pins", type=Path, required=True)
    parser.add_argument("--pins-sha256", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    report = audit(args.pins, args.pins_sha256)
    print(json.dumps(write_report(report, args.out)))
    return 1 if report["errors"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
