"""Shared read-only B/C audit primitives (Python 3.7 compatible)."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import sys
from urllib.parse import urlparse, urlunparse

ROOT = Path(__file__).resolve().parents[1]
HARNESS = ROOT / "harness/poolact_pilot_timing.py"
HARNESS_SHA = "3315917340fcd204b5d74e99eba9709415a2ee76c4a76b6203078684f010bc3c"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def strict_json(text):
    def unique(pairs):
        value = {}
        for key, item in pairs:
            if key in value:
                raise ValueError("Duplicate JSON key")
            value[key] = item
        return value
    def reject(value):
        raise ValueError("Nonfinite JSON constant")
    return json.loads(text, object_pairs_hook=unique, parse_constant=reject)


def read(path):
    return strict_json(Path(path).read_bytes())


def same(left, right):
    return json.dumps(left, sort_keys=True, allow_nan=False) == json.dumps(right, sort_keys=True, allow_nan=False)


def normalized_endpoint(base_url):
    """Frozen client's endpoint normalization, kept pure/no model construction."""
    parsed = urlparse(base_url.rstrip("/"))
    path = parsed.path.rstrip("/")
    if path.endswith("/chat/completions"):
        return urlunparse(parsed)
    if path in ("", "/"):
        path = "/v1/chat/completions"
    elif path.endswith(("/v1", "/api/v1", "/openai")):
        path += "/chat/completions"
    else:
        return base_url
    return urlunparse(parsed._replace(path=path))


def load_harness():
    if sha(HARNESS) != HARNESS_SHA:
        raise ValueError("Frozen B/C harness differs")
    name = "bc_independent_frozen_harness"
    if name not in sys.modules:
        spec = importlib.util.spec_from_file_location(name, HARNESS)
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
    if Path(sys.modules[name].__file__).resolve() != HARNESS:
        raise ValueError("Unexpected harness module origin")
    return sys.modules[name]


def strict_inventory(run, section="dumps"):
    """Inspect lexical ancestors before resolve; reject every descendant symlink."""
    root = Path(run).absolute() / section
    for path in list(root.parents) + [root]:
        if path.is_symlink():
            raise ValueError("Evidence ancestor symlink")
    if not root.is_dir():
        raise ValueError("Missing evidence directory: " + section)
    for directory, directories, files in os.walk(root, followlinks=False):
        for name in directories + files:
            if (Path(directory) / name).is_symlink():
                raise ValueError("Evidence descendant symlink")
    found = sorted(root.rglob("*.json"))
    if any(not path.is_file() for path in found):
        raise ValueError("Non-file JSON evidence")
    if section == "dumps" and found != sorted(root.glob("*/*.json")):
        raise ValueError("Raw JSON outside flat job namespace")
    return found


class Reader:
    def __init__(self):
        self.files = {}

    def bind(self, path, expected=None):
        path = Path(path).resolve()
        before = path.stat()
        data = path.read_bytes()
        after = path.stat()
        row = {"path": str(path), "sha256": hashlib.sha256(data).hexdigest(),
               "bytes": len(data), "mtime_ns": after.st_mtime_ns}
        if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
            raise ValueError("Evidence changed while reading: " + str(path))
        if str(path) in self.files and self.files[str(path)] != row:
            raise ValueError("Evidence changed between reads: " + str(path))
        if expected is not None and row["sha256"] != expected:
            raise ValueError("SHA binding differs: " + str(path))
        self.files[str(path)] = row
        return data

    def read(self, path, expected=None):
        return strict_json(self.bind(path, expected))

    def unchanged(self):
        for row in list(self.files.values()):
            self.bind(row["path"], row["sha256"])


def authority(run, path, expected_sha, reader):
    if not isinstance(expected_sha, str) or not re.fullmatch(r"[0-9a-f]{64}", expected_sha):
        raise ValueError("Explicit externally supplied authorization SHA required")
    auth = reader.read(path, expected_sha)
    if auth.get("authorized") is not True or not isinstance(auth.get("authorization_kind"), str) or not auth["authorization_kind"]:
        raise ValueError("Explicit scoped authority missing")
    if Path(auth["output_dir"]) != Path(run).resolve():
        raise ValueError("Authorized output directory differs")
    if auth["harness_sha256"] != HARNESS_SHA:
        raise ValueError("Authority binds another harness")
    argv = auth["resolved_argv"]
    if len(argv) < 4 or argv[1] not in ("-B", "-u") or Path(argv[2]).resolve() != HARNESS:
        raise ValueError("Authority command does not select this frozen harness")
    if not isinstance(auth.get("file_bindings"), dict) or not auth["file_bindings"]:
        raise ValueError("Authority file bindings absent")
    for bound, checksum in auth["file_bindings"].items():
        reader.bind(bound, checksum)
    return auth


def valid_native_history(messages):
    pending = []
    for message in messages:
        if message.get("role") == "assistant":
            if pending:
                return False
            pending = [call.get("id") for call in message.get("tool_calls") or []]
            if any(not isinstance(i, str) or not i for i in pending) or len(pending) != len(set(pending)):
                return False
        elif message.get("role") == "tool":
            identifier = message.get("tool_call_id")
            if identifier not in pending:
                return False
            pending.remove(identifier)
        elif pending:
            return False
    return not pending


def cost_sanity(agent):
    """Basic stored cost-domain checks only; not a concurrent cost replay."""
    def valid(value):
        return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and value >= 0
    errors = ["Invalid nonnegative finite cost: " + key for key in ("total_overhead", "eval_time", "llm_time", "wall_time_seconds") if not valid(agent.get(key))]
    if agent.get("answer_overhead") is not None and not valid(agent["answer_overhead"]):
        errors.append("Invalid answer_overhead")
    for record in agent.get("eval_records", []):
        if not isinstance(record, (list, tuple)) or len(record) != 4 or not valid(record[3]):
            errors.append("Invalid stored evaluation cost")
    return {"passed": not errors, "errors": errors,
            "scope": "Finite/nonnegative stored cost domain only; no independent runtime/simulated clock or shared-cache cost replay."}


def graph_suffix_check(text, graph, agent_id):
    """N4 unified renderer-owned syntax; opaque data rows, not state/causality."""
    template = graph._format_unified({}, {}, {}, {}, {}, agent_id=agent_id)
    header = "\n".join(template.splitlines()[:5]) + "\n"
    # Renderer data is deliberately NOT escaped: queries, claim payloads and
    # titles may contain newlines (even section-like literals). DOTALL preserves
    # that legal language instead of requiring every data continuation to indent.
    progress = r"(?:  None\.|  .+ \[agent [0-3]\])"
    explored = r"(?:  None completed yet\.|  .+ \[agents [0-3](?:,[0-3])*\](?: \(you\))?)"
    paths = r"(?:  No multi-step paths recorded yet\.|  .+ --> .+ \[(?:[1-9][0-9]*x, )?agents [0-3](?:,[0-3])*\])"
    gap = (r"(?:  No valid configuration found yet\.|  Select an action not listed above\.|"
           r"  [0-9]+ NDAs attempted so far\.|  [0-9]+ unique configs evaluated, best: -?[0-9]+\.[0-9]{6}|"
           r"  [0-9]+ queries explored so far\.\n  (?:Try a query not listed above\.|Unfetched leads: \[[0-9]+(?:,[0-9]+)*\]))")
    pattern = (re.escape(header) + r"== In Progress ==\n" + progress + r"\n\n== Already Explored ==\n" + explored +
               r"\n\n== Exploration Paths ==\n" + paths + r"\n\n== Coverage Gap ==\n" + gap)
    return re.fullmatch(pattern, text, flags=re.DOTALL) is not None


def trusted_stored_prompt(messages, system, context, strategy, agent_id, graph):
    errors, suffixes = [], []
    if not messages or messages[0] != {"role": "system", "content": system} or sum(m.get("role") == "system" for m in messages) != 1:
        errors.append("Source-owned system differs")
    if len(messages) < 2 or messages[1].get("role") != "user" or not isinstance(messages[1].get("content"), str):
        return {"passed": False, "errors": errors + ["Initial task context absent"], "graph_suffixes": []}
    marker = "\n\n[Parallel Exploration — Agent {} of 4]\n".format(agent_id)
    initial = messages[1]["content"]
    if initial != context:
        suffix = initial[len(context) + 2:] if initial.startswith(context + marker) else None
        if strategy != "poolact" or suffix is None or not graph_suffix_check(suffix, graph, agent_id):
            errors.append("Source-owned complete initial context/graph differs")
    if strategy == "poolact":
        for index, message in enumerate(messages[1:], 1):
            content = message.get("content")
            if message.get("role") not in ("user", "tool") or not isinstance(content, str):
                continue
            if index == 1 and content == context:
                continue
            candidates = [match.start() + 2 for match in re.finditer(r"\n\n\[Parallel Exploration — ", content)]
            if candidates:
                # An empty visible graph legitimately appends nothing. If a
                # graph-shaped suffix IS present, do not ignore a wrong N/id.
                # Try complete suffixes so a header-like literal nested inside
                # opaque data cannot hide the enclosing valid renderer block.
                valid_suffixes = [content[start:] for start in candidates if graph_suffix_check(content[start:], graph, agent_id)]
                valid = bool(valid_suffixes)
                suffix = valid_suffixes[0] if valid else content[candidates[0]:]
                suffixes.append({"message_index": index, "passed": valid,
                                 "sha256": hashlib.sha256(suffix.encode()).hexdigest()})
                if not valid:
                    errors.append("Stored N4 graph-owned syntax differs: " + str(index))
    return {"passed": not errors, "errors": errors, "graph_suffixes": suffixes,
            "graph_scope": "Renderer-owned N4 instructions/section syntax only; no graph suffix is legal when no visible state exists. Data remains opaque/multiline. Exact header literals embedded in arbitrary data cannot be independently attributed without graph-state capture; no simulated visibility or concurrent causal reconstruction."}
