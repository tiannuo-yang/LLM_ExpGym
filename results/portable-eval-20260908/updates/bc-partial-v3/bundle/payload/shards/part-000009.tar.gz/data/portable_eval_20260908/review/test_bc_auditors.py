"""CPU-only independent B/C auditor regression fixtures; never a model request."""
import copy
from datetime import datetime
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parent))
import audit_bc_common as common
import audit_bc_attempts_v3 as raw_audit
import audit_bc_v3 as main_audit

REPO = common.ROOT.parent / "LLM_ExpGym"
sys.path.insert(0, str(REPO))
from expgym.extras.parallel_cache import SharedExplorationGraph
from expgym.react_loop import _trim_messages


class CommonTests(unittest.TestCase):
    def test_duplicate_and_nonfinite_json_rejected(self):
        for value in ('{"a":1,"a":2}', '{"x":NaN}', '{"x":Infinity}'):
            with self.assertRaises(ValueError):
                common.strict_json(value)

    def test_raw_namespace_orphan_deep_and_symlink(self):
        with tempfile.TemporaryDirectory() as temp:
            run = Path(temp) / "run"
            (run / "dumps/job").mkdir(parents=True)
            expected = run / "dumps/job/one.json"
            expected.write_text("{}")
            self.assertEqual(common.strict_inventory(run), [expected])
            for relative in ("orphan.json", "job/deep/extra.json"):
                path = run / "dumps" / relative
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text("{}")
                with self.assertRaises(ValueError):
                    common.strict_inventory(run)
                path.unlink()
            link = run / "dumps/job/not-json-link"
            link.symlink_to(expected)
            with self.assertRaises(ValueError):
                common.strict_inventory(run)

    def test_main_alias_rejected_before_evidence_read(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "run/dumps").mkdir(parents=True)
            (root / "alias").symlink_to(root / "run", target_is_directory=True)
            with mock.patch.object(common.Reader, "read", side_effect=AssertionError("Evidence read too early")):
                with self.assertRaisesRegex(ValueError, "ancestor symlink"):
                    main_audit.audit(root / "alias", root / "auth", "a" * 64, root / "raw")

    def test_authority_sha_not_inferred(self):
        with self.assertRaises(ValueError):
            common.authority("/tmp/no-read", "/tmp/no-read", None, common.Reader())
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "auth.json"
            path.write_text('{"authorized":true}')
            with self.assertRaisesRegex(ValueError, "SHA binding"):
                common.authority(temp, path, "0" * 64, common.Reader())

    def test_authority_checks_explicit_argv_harness(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            anchor = root / "anchor"
            anchor.write_text("fixture")
            auth = {"authorized": True, "authorization_kind": "test-only", "output_dir": str(root),
                    "harness_sha256": common.HARNESS_SHA, "resolved_argv": [sys.executable, "-B", str(common.HARNESS), "--execute"],
                    "file_bindings": {str(anchor): common.sha(anchor)}}
            path = root / "auth.json"
            path.write_text(json.dumps(auth))
            self.assertEqual(common.authority(root, path, common.sha(path), common.Reader()), auth)
            auth["resolved_argv"][2] = "/tmp/another_harness.py"
            path.write_text(json.dumps(auth))
            with self.assertRaisesRegex(ValueError, "command"):
                common.authority(root, path, common.sha(path), common.Reader())

    def test_reader_detects_size_mtime_and_byte_changes(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "one"
            path.write_text("123")
            reader = common.Reader()
            reader.bind(path)
            path.write_text("321")
            with self.assertRaises(ValueError):
                reader.unchanged()

    def test_native_pairing_rejects_drop_duplicate_and_orphan(self):
        messages = [{"role": "assistant", "tool_calls": [{"id": "one"}]}, {"role": "tool", "tool_call_id": "one", "content": "ok"}]
        self.assertTrue(common.valid_native_history(messages))
        self.assertFalse(common.valid_native_history(messages[:1]))
        self.assertFalse(common.valid_native_history(messages[1:]))
        self.assertFalse(common.valid_native_history(messages + [messages[1]]))
        changed = copy.deepcopy(messages)
        changed[0]["tool_calls"].append({"id": "one"})
        self.assertFalse(common.valid_native_history(changed))

    def test_all_four_agents_actual_graph_and_literal_action_data(self):
        graph = SharedExplorationGraph(n_agents=4, diversity_mode=True)
        for agent in range(4):
            text = graph._format_unified({}, {}, {}, {}, {}, agent_id=agent)
            self.assertTrue(common.graph_suffix_check(text, graph, agent))
            context = "Dataset quote: Action: search is literal data"
            messages = [{"role": "system", "content": "native-system"}, {"role": "user", "content": context + "\n\n" + text}]
            self.assertTrue(common.trusted_stored_prompt(messages, "native-system", context, "poolact", agent, graph)["passed"])
            self.assertFalse(common.trusted_stored_prompt(messages, "native-system", context, "cached", agent, graph)["passed"])
            self.assertFalse(common.graph_suffix_check(text.replace(" of 4]", " of 2]"), graph, agent))

    def test_full_context_not_prefix_and_graph_instruction_not_mutable(self):
        graph = SharedExplorationGraph(n_agents=4, diversity_mode=True)
        text = graph._format_unified({}, {}, {}, {}, {}, agent_id=3)
        messages = [{"role": "system", "content": "native"}, {"role": "user", "content": "task\nextra"}]
        self.assertFalse(common.trusted_stored_prompt(messages, "native", "task", "poolact", 3, graph)["passed"])
        messages[1]["content"] = "task\n\n" + text
        self.assertTrue(common.trusted_stored_prompt(messages, "native", "task", "poolact", 3, graph)["passed"])
        messages[1]["content"] = messages[1]["content"].replace("== In Progress ==", "== Free instruction ==")
        self.assertFalse(common.trusted_stored_prompt(messages, "native", "task", "poolact", 3, graph)["passed"])

    def test_trim_after_stored_graph_validation_keeps_original(self):
        graph = SharedExplorationGraph(n_agents=4, diversity_mode=True)
        suffix = graph._format_unified({}, {}, {}, {}, {}, agent_id=0)
        messages = [{"role": "system", "content": "native"}, {"role": "user", "content": "task"},
                    {"role": "assistant", "tool_calls": [{"id": "one"}]},
                    {"role": "tool", "tool_call_id": "one", "content": "Observation:" + "x" * 450000 + "\n\n" + suffix}]
        original = copy.deepcopy(messages)
        self.assertTrue(common.trusted_stored_prompt(messages, "native", "task", "poolact", 0, graph)["passed"])
        wire = _trim_messages(copy.deepcopy(messages), 131000)
        self.assertNotEqual(wire, messages)
        self.assertEqual(messages, original)
        self.assertTrue(common.valid_native_history(wire))
        self.assertIn("truncated", wire[-1]["content"])

    def test_populated_n4_graphs_for_all_three_families(self):
        for family in ("search", "audit", "tuning"):
            graph = SharedExplorationGraph(n_agents=4, diversity_mode=True)
            if family == "search":
                graph.record_search(3, "Action: literal query", "article", completion_time=1)
                graph.record_search(3, "follow-up", "next", completion_time=2)
            elif family == "audit":
                graph.record_evaluate_config(3, "nda0", "nda:0 hypotheses", .7, 1, completion_time=1)
            else:
                graph.record_evaluate_config(3, "config0", "config 0", .9, 1, completion_time=1)
            graph.record_claim("evaluate_config", "{}", 2, start_time=0)
            for agent in range(4):
                text = graph.format_for_injection(visible_before=3, agent_id=agent)
                self.assertTrue(common.graph_suffix_check(text, graph, agent), family + text)

    @unittest.skipIf(sys.version_info < (3, 8), "Search/Audit context integration belongs to pinned Python3.11; ParamNet3.7 is checked by the separate actual pool scorer preparation")
    def test_actual_native_task_contexts_and_instruction_changes(self):
        import demo_experiment as demo
        from expgym.tool_protocol import native_system_prompt
        from expgym.react_loop import build_system_prompt
        graph = SharedExplorationGraph(n_agents=4, diversity_mode=True)
        for scenario_name in ("tuning", "restricted_search", "evidence_audit"):
            scenario = demo._SCENARIOS[scenario_name]
            args = SimpleNamespace(scenario=scenario_name, question_index=0, data_source="phantom_seed1",
                                   cc_split="cc-large", hypothesis_order=None, tuning_task="hpobench:nasbench101:A",
                                   seed=1209, system_prompt=None, tool_protocol="native")
            context = demo._resolve_context(scenario, False, args, SimpleNamespace(supports_native_tools=True)).strip()
            system = native_system_prompt(demo._resolve_system_prompt(scenario, False, args) or build_system_prompt())
            messages = [{"role": "system", "content": system}, {"role": "user", "content": context}]
            self.assertTrue(common.trusted_stored_prompt(messages, system, context, "naive", 3, graph)["passed"])
            messages[1]["content"] += "\nAction format: text actions only."
            self.assertFalse(common.trusted_stored_prompt(messages, system, context, "naive", 3, graph)["passed"])

    def test_frozen_b_or_precommitted_c_exact_scope(self):
        bc = common.load_harness()
        args = bc.parse_args(["--output-dir", "/tmp/bc-auditor-unit-no-execute"])
        b = bc.build_jobs(args)
        args.include_c = True
        both = bc.build_jobs(args)
        self.assertEqual((len(b), len(both)), (42, 78))
        self.assertEqual(b, both[:42])
        self.assertEqual(sum(j["runtime"] == "legacy_paramnet" for j in both), 9)
        self.assertEqual(sum(j["expected_traces"] for j in both), 312)

    def test_usage_unknown_and_reasoning_not_added_twice(self):
        usage = {"prompt_tokens": 10, "completion_tokens": 20, "total_tokens": 30, "reasoning_tokens": 15}
        raw_audit.validate_usage(usage)
        total = raw_audit.usage_total([usage])
        self.assertEqual(total["output_tokens"]["complete_total"], 20)
        self.assertIsNone(total["cache_read_tokens"]["complete_total"])
        for value in ({"prompt_tokens": True}, {"completion_tokens": -1}, {"prompt_tokens": 1, "completion_tokens": 2, "total_tokens": 4}):
            with self.assertRaises(ValueError):
                raw_audit.validate_usage(value)

    def test_normalized_endpoint_matches_frozen_client(self):
        from expgym.llm_clients import _normalize_chat_completions_url
        for url in ("http://example.invalid", "http://example.invalid/v1/", "http://example.invalid/api/v1",
                    "http://example.invalid/openai", "http://example.invalid/v1/chat/completions", "http://example.invalid/custom"):
            self.assertEqual(common.normalized_endpoint(url), _normalize_chat_completions_url(url))

    def test_wrong_agent_or_population_graph_not_ignored_and_empty_legal(self):
        graph = SharedExplorationGraph(n_agents=4, diversity_mode=True)
        base = [{"role": "system", "content": "native"}, {"role": "user", "content": "task"}]
        self.assertTrue(common.trusted_stored_prompt(base, "native", "task", "poolact", 0, graph)["passed"])
        for suffix in (graph._format_unified({}, {}, {}, {}, {}, agent_id=1),
                       graph._format_unified({}, {}, {}, {}, {}, agent_id=0).replace(" of 4]", " of 2]")):
            messages = base + [{"role": "tool", "content": "Observation: result\n\n" + suffix}]
            self.assertFalse(common.trusted_stored_prompt(messages, "native", "task", "poolact", 0, graph)["passed"])

    def test_actual_renderer_multiline_query_claim(self):
        graph = SharedExplorationGraph(n_agents=4, diversity_mode=True)
        graph.record_claim("search", json.dumps({"query": "alpha\nbeta"}), 1, start_time=0)
        text = graph.format_for_injection(visible_before=0, agent_id=0, completion_before=100)
        self.assertTrue(common.graph_suffix_check(text, graph, 0))

    def test_conflicting_reasoning_unknown_not_first_wins_complete(self):
        usage = {"prompt_tokens": 3, "completion_tokens": 2, "total_tokens": 5,
                 "reasoning_tokens": 1, "completion_tokens_details": {"reasoning_tokens": 2}}
        raw_audit.validate_usage(usage)
        total = raw_audit.usage_total([usage])
        self.assertIsNone(total["reasoning_tokens"]["complete_total"])
        self.assertEqual(total["reasoning_tokens"]["unknown_count"], 1)
        self.assertEqual(total["output_tokens"]["complete_total"], 2)

    def test_stored_cost_domain_rejects_invalid_without_clock_claim(self):
        value = {"total_overhead": 1, "eval_time": 1, "llm_time": 2, "wall_time_seconds": 3,
                 "answer_overhead": None, "eval_records": [["x", "x", .2, 1]]}
        self.assertTrue(common.cost_sanity(value)["passed"])
        for key in ("total_overhead", "eval_time", "answer_overhead"):
            for invalid in (-1, float("nan"), True):
                changed = dict(value, **{key: invalid})
                self.assertFalse(common.cost_sanity(changed)["passed"])


class RawFixtureTests(unittest.TestCase):
    """A full-size 42x4 single-decision synthetic collection; no real plan."""
    pool_count = 42
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / "run"
        self.root.mkdir()
        self.jobs = []
        self.schemas = [{"type": "function", "function": {"name": "test", "parameters": {"type": "object"}}}]
        for n in range(self.pool_count):
            jid = "unit_%02d" % n
            out, dump = self.root / "results" / jid, self.root / "dumps" / jid
            (out / "naive/agents").mkdir(parents=True)
            dump.mkdir(parents=True)
            contexts = [{"job": jid, "agent_id": i} for i in range(4)]
            job = {"id": jid, "strategy": "naive", "output_dir": str(out), "dump_dir": str(dump), "seed": 1206,
                   "preflight": {"native_tool_schemas": self.schemas, "agent_dump_contexts": contexts}}
            self.jobs.append(job)
            for i in range(4):
                rid, cid, gid = jid + "_r%d" % i, jid + "_c%d" % i, jid + "_g%d" % i
                messages = [{"role": "system", "content": "native"}, {"role": "user", "content": "task"}]
                answer = {"role": "assistant", "content": "Answer: x"}
                usage = {"prompt_tokens": 3, "completion_tokens": 2, "total_tokens": 5}
                response = {"choices": [{"message": answer, "finish_reason": "stop"}], "usage": usage}
                record = {"schema_version": "expgym.api_attempt.v1", "request_id": rid, "client_id": cid,
                          "generation_id": gid, "attempt": 1, "max_attempts": 3, "run_id": "poolact-pilot-bc:run",
                          "state": "success", "will_retry": False, "error": None, "http_status": None,
                          "started_at_utc": "2026-09-08T00:00:00+00:00", "finished_at_utc": "2026-09-08T00:00:01+00:00",
                          "response_raw": json.dumps(response), "response_json": response,
                          "endpoint": "http://example.invalid/v1/chat/completions", "context": contexts[i],
                          "request_payload": {"messages": messages, "tools": self.schemas, "tool_choice": "auto", "parallel_tool_calls": False, "seed": 1206 + i}}
                (dump / (rid + ".json")).write_text(json.dumps(record))
                entry = {k: record[k] for k in ("request_id", "generation_id", "attempt", "state", "http_status")}
                entry["usage"] = usage
                agent = {"agent_id": i, "seed": 1206 + i, "api_dump": {"client_id": cid, "run_id": "poolact-pilot-bc:run"},
                         "messages": messages + [answer], "usage_attempts": [{"llm_call_index": 1, "attempts": [entry]}],
                         "api_calls": 1, "http_request_attempts": 1, "prompt_tokens": 3, "completion_tokens": 2, "cached_prompt_tokens": 0}
                (out / "naive/agents" / ("agent_%d.json" % i)).write_text(json.dumps(agent))
        self.settings = {"fixture": True}
        (self.root / "manifest.json").write_text(json.dumps({"identity": {"jobs": self.jobs, "settings": self.settings}}))
        (self.root / "commands.json").write_text("{}")
        (self.root / "execution.json").write_text(json.dumps({"passed": True, "executed": True, "unstarted": [], "results": [{"job_id": j["id"], "passed": True} for j in self.jobs]}))
        self.auth = Path(self.tmp.name) / "auth.json"
        self.auth.write_text(json.dumps({"authorized": True, "authorization_kind": "synthetic-test-only", "output_dir": str(self.root),
                                        "harness_sha256": common.HARNESS_SHA, "resolved_argv": [sys.executable, "-B", str(common.HARNESS), "--execute"],
                                        "file_bindings": {str(self.root / "manifest.json"): common.sha(self.root / "manifest.json")},
                                        "manifest_sha256": common.sha(self.root / "manifest.json"), "commands_sha256": common.sha(self.root / "commands.json")}))
        args = SimpleNamespace(backend="openai", execute=True, allow_real=True, include_c=self.pool_count == 78, base_url="http://example.invalid/v1")
        fake_profile = SimpleNamespace(wire_errors=lambda p, a, seed: [] if p["seed"] == seed else ["seed"])
        self.bc = SimpleNamespace(parse_args=lambda x: args, settings=lambda a: self.settings,
                                  build_jobs=lambda a: [{k: v for k, v in j.items() if k != "preflight"} for j in self.jobs],
                                  profiles=lambda: fake_profile)

    def tearDown(self):
        self.tmp.cleanup()

    def run_audit(self):
        with mock.patch.object(raw_audit, "load_harness", return_value=self.bc):
            return raw_audit.audit(self.root, self.auth, common.sha(self.auth))

    def mutate_raw(self, callback):
        path = self.root / "dumps/unit_00/unit_00_r0.json"
        value = json.loads(path.read_text())
        callback(value)
        path.write_text(json.dumps(value))

    def test_full_fixture_and_null_http_cache(self):
        result = self.run_audit()
        self.assertTrue(result["passed"], result["errors"])
        self.assertEqual((result["pool_count"], result["trace_count"], result["attempt_count"]), (self.pool_count, self.pool_count * 4, self.pool_count * 4))
        self.assertEqual(result["http_status_counts"], {"unknown": self.pool_count * 4})
        self.assertIsNone(result["all_attempt_usage"]["cache_read_tokens"]["complete_total"])

    def test_response_json_usage_mismatch_fails(self):
        self.mutate_raw(lambda r: r["response_json"]["usage"].update(prompt_tokens=999))
        self.assertFalse(self.run_audit()["passed"])

    def test_authoritative_seed_not_joint_mutable(self):
        self.mutate_raw(lambda r: r["request_payload"].update(seed=33))
        path = self.root / "results/unit_00/naive/agents/agent_0.json"
        agent = json.loads(path.read_text())
        agent["seed"] = 33
        path.write_text(json.dumps(agent))
        self.assertFalse(self.run_audit()["passed"])

    def test_orphan_json_failclosed(self):
        (self.root / "dumps/orphan.json").write_text("{}")
        with self.assertRaises(ValueError):
            self.run_audit()

    def test_boolean_attempt_is_not_one(self):
        self.mutate_raw(lambda r: r.update(attempt=True))
        self.assertFalse(self.run_audit()["passed"])

    def test_unfinished_attempt_retained_and_fails(self):
        self.mutate_raw(lambda r: r.update(state="in_progress"))
        result = self.run_audit()
        self.assertFalse(result["passed"])
        self.assertEqual(result["dump_states"]["in_progress"], 1)

    def test_delivered_assistant_changed_fails(self):
        def mutation(r):
            r["response_json"]["choices"][0]["message"]["content"] = "different"
            r["response_raw"] = json.dumps(r["response_json"])
        self.mutate_raw(mutation)
        self.assertFalse(self.run_audit()["passed"])

    def add_transport_retry(self):
        path = self.root / "dumps/unit_00/unit_00_r0.json"
        first = json.loads(path.read_text())
        second = copy.deepcopy(first)
        second.update(request_id="unit_00_r0_retry", attempt=2)
        (path.parent / "unit_00_r0_retry.json").write_text(json.dumps(second))
        first.update(state="error", error={"type": "URLError", "message": "synthetic transport failure"}, will_retry=True, retry_delay_seconds=3,
                     response_raw=None, response_json=None)
        path.write_text(json.dumps(first))
        agent_path = self.root / "results/unit_00/naive/agents/agent_0.json"
        agent = json.loads(agent_path.read_text())
        ledger = []
        for record in (first, second):
            entry = {key: record[key] for key in ("request_id", "generation_id", "attempt", "state", "http_status")}
            entry["usage"] = record["response_json"]["usage"] if record["response_json"] else None
            ledger.append(entry)
        agent["usage_attempts"][0]["attempts"] = ledger
        agent["http_request_attempts"] = 2
        agent_path.write_text(json.dumps(agent))

    def test_transport_retry_preserved_not_removed_from_usage(self):
        self.add_transport_retry()
        result = self.run_audit()
        self.assertTrue(result["passed"], result["errors"])
        self.assertEqual(result["attempt_count"], self.pool_count * 4 + 1)
        self.assertEqual(result["dump_states"], {"error": 1, "success": self.pool_count * 4})
        self.assertEqual(result["all_attempt_usage"]["input_tokens"]["unknown_count"], 1)
        self.assertIsNone(result["all_attempt_usage"]["input_tokens"]["complete_total"])

    def test_retry_mutated_prompt_fails(self):
        self.add_transport_retry()
        path = self.root / "dumps/unit_00/unit_00_r0_retry.json"
        second = json.loads(path.read_text())
        second["request_payload"]["messages"][1]["content"] = "changed retry"
        path.write_text(json.dumps(second))
        self.assertFalse(self.run_audit()["passed"])

    def test_null_parsed_object_does_not_hide_retained_wire_usage(self):
        self.mutate_raw(lambda record: record.update(response_json=None))
        path = self.root / "results/unit_00/naive/agents/agent_0.json"
        agent = json.loads(path.read_text())
        agent["usage_attempts"][0]["attempts"][0]["usage"] = None
        agent["prompt_tokens"] = agent["completion_tokens"] = 0
        path.write_text(json.dumps(agent))
        result = self.run_audit()
        self.assertFalse(result["passed"])
        self.assertEqual(result["all_attempt_usage"]["input_tokens"]["known_sum"], self.pool_count * 12)

    def test_nontransient_http_retry_fails(self):
        self.add_transport_retry()
        self.mutate_raw(lambda record: record.update(http_status=400, error={"type": "HTTPError", "message": "Bad Request"}))
        path = self.root / "results/unit_00/naive/agents/agent_0.json"
        agent = json.loads(path.read_text())
        agent["usage_attempts"][0]["attempts"][0]["http_status"] = 400
        path.write_text(json.dumps(agent))
        self.assertFalse(self.run_audit()["passed"])


class PrecommittedCRawFixtureTests(RawFixtureTests):
    """Same full raw adversarial matrix at precommitted B+C78 / N4."""
    pool_count = 78


if __name__ == "__main__":
    unittest.main()
