"""Partial B/C observations; no discovery, authority, scoring or model calls.

The caller pins the frozen helpers/harness and supplies every discovered safe
regular JSON path. All paths, including duplicates and orphans, survive in
file_rows. Physical-file usage sums are observations, never billing totals or
proof that the live namespace is final. This module never declares completion.
"""
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

from audit_bc_attempts_v3 import retry_is_transient, usage_total, usage_values, validate_usage
from audit_bc_common import normalized_endpoint, same, strict_json, valid_native_history


ERRORS = (ValueError, TypeError, KeyError, IndexError, AttributeError, OSError,
          OverflowError, RecursionError)
ALLOWED_FINISH = frozenset(('stop', 'tool_calls', 'length'))
TERMINAL = frozenset(('success', 'error', 'malformed_response'))


def _text(value):
    return value if type(value) is str else '<unknown-or-invalid>'


def _nonempty(value):
    return type(value) is str and bool(value)


def _totals(values, uncertain=False):
    result = usage_total(values)
    if uncertain or not values:
        for item in result.values():
            item['complete_total'] = None
    return result


def audit_raw(paths, jobs, args, bc, root, reader):
    """Audit all physical files without requiring any final agent artifact.

    records contains only unique, nonempty request IDs; it must NOT be used to
    count physical files or costs. In particular duplicate IDs remove every
    occurrence from that join index while file_rows retains each observation.
    """
    root = Path(root)
    expected_run = 'poolact-pilot-bc:' + root.name
    rows, global_errors, warnings = [], [], []
    job_errors = {jid: [] for jid in jobs}
    states, finishes, statuses = Counter(), Counter(), Counter()
    by_id, by_generation, by_client = defaultdict(list), defaultdict(list), defaultdict(list)
    parsed, abort_jobs = {}, set()

    def issue(row, rule, global_issue=False):
        if rule not in row['errors']:
            row['errors'].append(rule)
            entry = {'path': row['path'], 'rule': rule}
            if row['job_id'] in job_errors:
                job_errors[row['job_id']].append(entry)
            if global_issue or row['job_id'] is None:
                global_errors.append(entry)

    for supplied in paths:
        path = Path(supplied)
        row = {'path': str(path), 'request_id': None, 'client_id': None, 'generation_id': None,
               'job_id': None, 'agent_id': None, 'state': None, 'terminal': False,
               'finish_reason': None, 'finish_reasons': [], 'parsed_usage': None,
               'usage': usage_values(None), 'errors': [], 'sha256': None, 'bytes': None}
        rows.append(row)
        try:
            relative = path.relative_to(root / 'dumps')
            if relative.parts and relative.parts[0] in jobs:
                row['job_id'] = relative.parts[0]
            if len(relative.parts) != 2 or row['job_id'] is None or path.suffix != '.json':
                issue(row, 'raw_outside_exact_flat_job_namespace', True)
        except ValueError:
            issue(row, 'raw_outside_dump_root', True)
        try:
            blob = reader.bind(path)
            pin = reader.files.get(str(path), {})
            row.update(sha256=pin.get('sha256'), bytes=pin.get('bytes'))
            record = strict_json(blob)
            if type(record) is not dict:
                raise ValueError('raw_object_required')
            # strict_json rejects constants; same also rejects float overflow.
            same(record, record)
        except ERRORS as exc:
            issue(row, 'raw_read_or_parse_failed:' + type(exc).__name__)
            states['unreadable_or_invalid'] += 1
            continue
        parsed[len(rows) - 1] = record
        rid, cid, gid = (record.get(k) for k in ('request_id', 'client_id', 'generation_id'))
        row.update(request_id=rid if _nonempty(rid) else None,
                   client_id=cid if _nonempty(cid) else None,
                   generation_id=gid if _nonempty(gid) else None,
                   state=record.get('state') if type(record.get('state')) is str else None)
        state = row['state']
        row['terminal'] = state in TERMINAL
        states[_text(state)] += 1
        statuses[str(record.get('http_status')) if type(record.get('http_status')) is int else 'unknown'] += 1
        if not _nonempty(rid) or path.stem != rid:
            issue(row, 'raw_request_id_or_filename_invalid')
        if _nonempty(rid):
            by_id[rid].append(len(rows) - 1)
        if not _nonempty(cid) or not _nonempty(gid):
            issue(row, 'raw_client_or_generation_identity_missing')
        if _nonempty(cid):
            by_client[cid].append(len(rows) - 1)
        if _nonempty(gid):
            by_generation[gid].append(len(rows) - 1)
        if record.get('schema_version') != 'expgym.api_attempt.v1' or record.get('run_id') != expected_run:
            issue(row, 'raw_schema_or_run_mismatch')
        if (type(record.get('attempt')) is not int or not 1 <= record['attempt'] <= 3 or
                type(record.get('max_attempts')) is not int or record['max_attempts'] != 3):
            issue(row, 'raw_retry_bounds_mismatch')
        if state not in TERMINAL | {'in_progress'}:
            issue(row, 'raw_state_invalid')
        if not row['terminal']:
            issue(row, 'raw_attempt_unfinished')
        try:
            start = datetime.fromisoformat(record['started_at_utc'])
            end = record.get('finished_at_utc')
            if row['terminal']:
                if type(end) is not str or datetime.fromisoformat(end) < start:
                    issue(row, 'raw_incomplete_or_reversed_time')
            elif end is not None:
                issue(row, 'pending_raw_has_finish_time')
        except ERRORS:
            issue(row, 'raw_time_unknown_or_invalid')

        response, response_parsed = None, False
        raw_text = record.get('response_raw')
        if type(raw_text) is str:
            try:
                response = strict_json(raw_text)
                same(response, response)
                response_parsed = True
            except ERRORS:
                if record.get('response_json') is not None or state == 'success':
                    issue(row, 'unparseable_success_or_parsed_response_conflict')
                warnings.append({'path': str(path), 'rule': 'non_json_response_usage_unknown'})
            if response_parsed and not same(response, record.get('response_json')):
                issue(row, 'raw_response_json_conflict')
        elif raw_text is not None or record.get('response_json') is not None or state == 'success':
            issue(row, 'missing_response_bytes_or_parsed_response_conflict')
        candidate_usage = response.get('usage') if type(response) is dict else None
        try:
            if candidate_usage is not None and type(candidate_usage) is not dict:
                raise ValueError('usage_object_required')
            validate_usage(candidate_usage)
            row['usage'] = usage_values(candidate_usage)
            row['parsed_usage'] = candidate_usage
            if candidate_usage:
                sources = [candidate_usage.get('reasoning_tokens')]
                for field in ('completion_tokens_details', 'output_tokens_details'):
                    value = candidate_usage.get(field)
                    if type(value) is dict:
                        sources.append(value.get('reasoning_tokens'))
                observed = [v for v in sources if v is not None]
                if len(set(observed)) > 1:
                    warnings.append({'path': str(path), 'rule': 'reasoning_conflict_remains_unknown'})
        except ERRORS:
            issue(row, 'provider_usage_invalid_remains_unknown')
        choices = response.get('choices') if type(response) is dict else None
        if type(choices) is list:
            for choice in choices:
                if type(choice) is not dict:
                    issue(row, 'response_choice_not_object')
                    continue
                reason = choice.get('finish_reason')
                row['finish_reasons'].append(reason if type(reason) is str else None)
                finishes[_text(reason)] += 1
                if type(reason) is not str or reason not in ALLOWED_FINISH:
                    issue(row, 'disallowed_or_unknown_raw_finish_reason')
                    if reason == 'abort' and row['job_id'] is not None:
                        abort_jobs.add(row['job_id'])
            if len(choices) == 1 and type(choices[0]) is dict:
                row['finish_reason'] = choices[0].get('finish_reason') if type(choices[0].get('finish_reason')) is str else None
        if state == 'success' and (type(choices) is not list or len(choices) != 1 or
                type(choices[0]) is not dict or type(choices[0].get('message')) is not dict):
            issue(row, 'success_without_one_complete_assistant_choice')

        payload = record.get('request_payload')
        if type(payload) is not dict:
            issue(row, 'request_payload_not_object')
            continue
        if any(k.lower().replace('-', '_') in {'authorization', 'api_key', 'headers', 'extra_headers'}
               for k in set(record) | set(payload)):
            issue(row, 'credential_or_header_field_in_raw')
        try:
            if record.get('endpoint') != normalized_endpoint(args.base_url):
                issue(row, 'endpoint_mismatch')
            if row['job_id'] is None:
                continue
            job = jobs[row['job_id']]
            if (Path(job['dump_dir']) != root / 'dumps' / row['job_id'] or
                    Path(job['output_dir']) != root / 'results' / row['job_id']):
                issue(row, 'planned_job_namespace_mismatch')
            contexts = job['preflight']['agent_dump_contexts']
            if type(contexts) is not list or len(contexts) != 4:
                raise ValueError('exact_N4_contexts_required')
            matches = [i for i, value in enumerate(contexts) if same(record.get('context'), value)]
            if len(matches) != 1:
                issue(row, 'raw_context_not_one_planned_agent')
            else:
                row['agent_id'] = matches[0]
                if bc.profiles().wire_errors(payload, args, seed=job['seed'] + matches[0]):
                    issue(row, 'raw_profile_or_seed_mismatch')
            if (payload.get('parallel_tool_calls') is not False or payload.get('tool_choice') not in ('auto', 'none') or
                    not same(payload.get('tools'), job['preflight']['native_tool_schemas']) or 'prompt_cache_key' in payload):
                issue(row, 'raw_native_wire_contract_mismatch')
        except ERRORS as exc:
            issue(row, 'raw_profile_context_check_failed:' + type(exc).__name__)

    for rid, indices in by_id.items():
        if len(indices) > 1:
            for index in indices:
                issue(rows[index], 'duplicate_request_id:' + rid, True)
    for cid, indices in by_client.items():
        memberships = {(rows[i]['job_id'], rows[i]['agent_id']) for i in indices}
        configs = [{k: v for k, v in parsed[i].get('request_payload', {}).items() if k not in ('messages', 'tool_choice')}
                   for i in indices if type(parsed[i].get('request_payload')) is dict]
        for index in indices:
            if len(memberships) != 1:
                issue(rows[index], 'client_reused_across_job_or_agent', True)
            if configs and any(not same(configs[0], item) for item in configs[1:]):
                issue(rows[index], 'per_client_profile_changed')
    for gid, indices in by_generation.items():
        members = {(rows[i]['job_id'], rows[i]['client_id'], rows[i]['agent_id']) for i in indices}
        valid_attempts = all(type(parsed[i].get('attempt')) is int for i in indices)
        ordered = sorted(indices, key=lambda i: parsed[i]['attempt']) if valid_attempts else indices
        sequence = [parsed[i].get('attempt') for i in ordered]
        bad_sequence = not valid_attempts or len(indices) > 3 or sequence != list(range(1, len(indices) + 1))
        for index in indices:
            if len(members) != 1:
                issue(rows[index], 'generation_reused_across_client_or_job', True)
            if bad_sequence:
                issue(rows[index], 'noncontiguous_generation_attempts')
        first_payload = parsed[ordered[0]].get('request_payload')
        for position, index in enumerate(ordered):
            record, row = parsed[index], rows[index]
            if not same(record.get('request_payload'), first_payload):
                issue(row, 'retry_payload_changed')
            if position < len(ordered) - 1:
                try:
                    transient = retry_is_transient(record)
                except ERRORS:
                    transient = False
                if record.get('state') != 'error' or record.get('will_retry') is not True or not transient:
                    issue(row, 'retry_outside_frozen_transient_policy')
            elif record.get('state') != 'success':
                issue(row, 'generation_has_no_final_success')
            elif record.get('will_retry') is not False or record.get('error') is not None:
                issue(row, 'final_success_retry_or_error_conflict')
    records = {}
    for rid, indices in by_id.items():
        if len(indices) == 1:
            index = indices[0]
            row = rows[index]
            records[rid] = {'path': row['path'], 'job_id': row['job_id'], 'agent_id': row['agent_id'],
                            'record': parsed[index], 'parsed_usage': row['parsed_usage'],
                            'errors': list(row['errors']), 'finish_reasons': list(row['finish_reasons'])}
    errors_present = bool(global_errors or any(row['errors'] for row in rows))
    return {'schema_version': 'bc-partial-raw-observations-v3', 'complete': False,
            'run_id': expected_run, 'root': str(root), 'file_rows': rows, 'records': records,
            'usage_totals': _totals([row['parsed_usage'] for row in rows], errors_present),
            'usage_scope': 'All physical JSON file observations, including duplicates; not unique requests, final provider usage or billing.',
            'states': dict(states), 'http_statuses': dict(statuses), 'finish_reasons': dict(finishes),
            'abort_job_ids': sorted(abort_jobs), 'job_errors': job_errors,
            'global_errors': global_errors, 'warnings': warnings,
            'all_raw_bound': all(row['sha256'] is not None for row in rows)}


def check_agent(agent, path, job, agent_id, rawreport, reader):
    """Retained ledger/assistant joins only; no full prompt, trim or scorer.

    A failed/missing ledger stays failed even if a stored local result says
    passed or reports a natural answer. Raw finish reasons remain authoritative.
    """
    errors, request_ids, delivered, finishes = [], [], [], Counter()
    client = None

    def require(value, rule):
        if not value:
            errors.append(rule)

    def report():
        return {'passed': not errors, 'errors': errors, 'request_ids': request_ids,
                'client_id': client, 'finish_reasons': dict(finishes),
                'delivered_usage': _totals(delivered, bool(errors)),
                'full_prompt_and_trim_verified': False}

    try:
        require(same(reader.read(path), agent), 'agent_argument_differs_from_bound_original')
        if type(agent) is not dict:
            raise ValueError('agent_object_required')
        require(Path(path) == Path(job['output_dir']) / job['strategy'] / 'agents' / ('agent_%d.json' % agent_id),
                'agent_path_not_exact_planned_N4')
        dump = agent.get('api_dump')
        if type(dump) is not dict:
            raise ValueError('agent_dump_identity_missing')
        client = dump.get('client_id')
        require(_nonempty(client) and dump.get('run_id') == rawreport['run_id'], 'agent_client_or_run_identity')
        require(type(agent.get('agent_id')) is int and agent['agent_id'] == agent_id and
                type(agent.get('seed')) is int and agent['seed'] == job['seed'] + agent_id, 'agent_N4_id_or_seed')
        ledger, messages = agent.get('usage_attempts'), agent.get('messages')
        if type(ledger) is not list or type(messages) is not list or any(type(m) is not dict for m in messages):
            raise ValueError('agent_ledger_or_messages_shape')
        positions = [i for i, message in enumerate(messages) if message.get('role') == 'assistant']
        require(type(agent.get('api_calls')) is int and len(ledger) == len(positions) == agent['api_calls'] and
                1 <= len(ledger) <= 31, 'generation_assistant_count_or_bound')
        require(type(agent.get('http_request_attempts')) is int and 1 <= agent['http_request_attempts'] <= 93,
                'agent_HTTP_attempt_bound')
        seen_generations = set()
        for call_index, call in enumerate(ledger, 1):
            try:
                if type(call) is not dict or type(call.get('attempts')) is not list:
                    raise ValueError('call_attempts_shape')
                entries = call['attempts']
                require(type(call.get('llm_call_index')) is int and call['llm_call_index'] == call_index,
                        'call_index_not_sequential')
                require(1 <= len(entries) <= 3 and all(type(e) is dict and type(e.get('attempt')) is int for e in entries)
                        and [e['attempt'] for e in entries] == list(range(1, len(entries) + 1)), 'ledger_retry_chain_not_contiguous')
                gids = {e.get('generation_id') for e in entries if type(e) is dict and _nonempty(e.get('generation_id'))}
                require(len(gids) == 1 and not seen_generations.intersection(gids), 'ledger_generation_missing_or_reused')
                seen_generations.update(gids)
                position = positions[call_index - 1] if call_index <= len(positions) else None
                require(position is not None and valid_native_history(messages[:position]), 'stored_native_prefix_unpaired')
                joined = []
                for entry in entries:
                    if type(entry) is not dict:
                        raise ValueError('ledger_entry_object_required')
                    rid = entry.get('request_id')
                    require(_nonempty(rid) and rid not in request_ids, 'ledger_request_missing_or_reused')
                    if _nonempty(rid):
                        request_ids.append(rid)
                    item = rawreport['records'].get(rid) if _nonempty(rid) else None
                    if item is None:
                        errors.append('ledger_request_not_unique_in_full_raw')
                        continue
                    raw = item['record']
                    require(item['job_id'] == job['id'] and item['agent_id'] == agent_id and raw.get('client_id') == client,
                            'ledger_cross_job_agent_or_client_join')
                    require(not item['errors'], 'raw_attempt_not_qualified:' + str(rid))
                    require(all(same(entry.get(k), raw.get(k)) for k in ('request_id', 'generation_id', 'attempt', 'state', 'http_status')),
                            'ledger_raw_attempt_metadata_conflict')
                    require(same(entry.get('usage'), item['parsed_usage']), 'ledger_raw_usage_conflict')
                    joined.append(item)
                if len(joined) == len(entries) and joined:
                    final = joined[-1]
                    raw = final['record']
                    require(raw.get('state') == 'success' and raw.get('will_retry') is False and raw.get('error') is None,
                            'ledger_has_no_final_successful_delivery')
                    if raw.get('state') == 'success':
                        response = strict_json(raw['response_raw'])
                        message = dict(response['choices'][0]['message'])
                        message.setdefault('role', 'assistant')
                        require(position is not None and same(message, messages[position]), 'raw_delivered_assistant_vs_stored_history')
                        reason = response['choices'][0].get('finish_reason')
                        finishes[_text(reason)] += 1
                        require(type(reason) is str and reason in ALLOWED_FINISH, 'disallowed_raw_finish_reason')
                        delivered.append(final['parsed_usage'])
            except ERRORS as exc:
                errors.append('agent_call_check_failed:' + type(exc).__name__)
        owned = [r for r in rawreport['file_rows'] if r['client_id'] == client and client is not None]
        require(len(request_ids) == len(set(request_ids)) == len(owned) and
                set(request_ids) == {r['request_id'] for r in owned} and len(request_ids) == agent.get('http_request_attempts'),
                'agent_ledger_not_exact_all_raw_client_attempts')
        totals = usage_total(delivered)
        for field, key in (('prompt_tokens', 'input_tokens'), ('completion_tokens', 'output_tokens'), ('cached_prompt_tokens', 'cache_read_tokens')):
            require(type(agent.get(field)) is int and agent[field] == totals[key]['known_sum'], 'legacy_delivered_counter_mismatch:' + field)
    except ERRORS as exc:
        errors.append('agent_check_failed:' + type(exc).__name__)
    return report()
