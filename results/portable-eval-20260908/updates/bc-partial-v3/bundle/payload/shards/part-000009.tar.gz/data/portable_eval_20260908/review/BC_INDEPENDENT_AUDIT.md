# B/C 独立后验审计

只读工具，不创建模型计划、授权或请求。必须先由 ROOT/runner 确认全部子进程和请求 drain；不能把此工具当作启动许可。

接受冻结 B42 / 168 agents，或运行前已经写入 `--include-c` 的 B+C78 / 312 agents。每池单策略 N4、30 steps/evals；不把 A21/场景 smoke 的计数或逐 agent forced-final 门槛套过来。

在 workspace 根执行；所有输出必须是运行目录外的新文件。以下占位符必须由 ROOT 提供，尤其授权 SHA 不能从将要验收的文件自行推定为许可。

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 \
  LLM_ExpGym/.venv/bin/python -B portable_eval_20260908/review/audit_bc_attempts_v3.py \
  --run-dir RUN_DIRECTORY --authorization ROOT_AUTHORIZATION_JSON \
  --authorization-sha256 ROOT_SUPPLIED_SHA256 --output-json NEW_RAW_RECEIPT_JSON

PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 \
  OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 \
  LLM_ExpGym/.venv/bin/python -B portable_eval_20260908/review/audit_bc_v3.py \
  --run RUN_DIRECTORY --authorization ROOT_AUTHORIZATION_JSON \
  --authorization-sha256 ROOT_SUPPLIED_SHA256 \
  --raw-receipt NEW_RAW_RECEIPT_JSON --receipt NEW_FINAL_RECEIPT_JSON
```

授权必须有 `authorized`、非空 `authorization_kind`、`output_dir`、`manifest_sha256`、`commands_sha256`、`source_tree_sha256`、`harness_sha256`、完整 `resolved_argv` 和非空 `file_bindings`。前三 argv 为 Python、`-B` 或 `-u`、冻结 B/C harness 路径。完整矩阵与参数从 argv 和冻结 `build_jobs` 重建，不从结果分数决定选择。

主要检查：完整递归原始 dump 范围/无软链接，4-agent 请求与重试 bijection，原始 response 严格 JSON 对账，usage 未报告或 reasoning 来源冲突记 unknown，限定真实 HTTP/transport 重试；全部 result/summary 严格 JSON 与日志命名；每 job 实际 pinned Python 3.7/3.11 的原评分/聚合/identity；完整 source-owned 初始 context/system/schema，stored N4 图指令语法，之后按冻结 schema-aware `_trim_messages` 重建每次真实 wire；全部 JSON 路径/SHA/size/mtime 和 guarded resume 证据。

边界：图数据可多行、保持原文；空可见图允许无后缀；任意数据若恰含完整同名图 header，没有独立 graph snapshot 无法绝对归因。此工具不重建并发图因果/可见时刻；费用仅做 finite/nonnegative domain 检查，不声称独立重放所有共享 cache 时钟。逐 agent 是否自然终答、forced-final、零分或协议异常都保留，不重抽。HTTP 200/连接关闭另由 ROOT router 双 SHA 收据证明；client `http_status=null` 仍是 unknown。

准备证据：[bc_independent_auditor_preparation_v1.json](../validation/bc_independent_auditor_preparation_v1.json)。Python 3.11 41 tests 全过；3.7 40 tests 过、1 个仅适用于 Search/Audit 的 3.11 集成测试显式跳过，原越 runtime 测试缺 pyarrow 的失败原因保留。另对已封存的 6 个 fake pools / 24 agents 做实际 runtime 原评分+identity+cost-domain 复核，文件字节与 mtime 未变；fake text 正确不能通过 native prompt gate。没有生成模型请求，不能把这些准备检查当作真实 B/C 结果。
