# B/C 全尝试离线补充审计合同

分类：CPU-only preparation / 后验 transport accounting；不生成、不读分数、不启动 runner，不调用网络、health 或 Slurm。冻结的 `bc_router_rawjoin_v3`、原 strict FAIL 和所有原件不修改。本工具不是评分、授权、排空检测或严格复现验收。

## 外部信任根与只读范围

ROOT 在确认所有进程/请求 drained 后提供新的 pins JSON，并从文件外提供其 SHA256。pins 中必须明确绑定最终 strict receipt、其 copied router snapshot 和 inventory、独立 raw audit receipt、completion、authorization 的绝对路径及 SHA。`drain` 是 ROOT 的外部声明，须含 `confirmed=true`、`confirmed_at_utc`、completion 和 router snapshot 的 SHA；工具不把扫描静止或 receipt.passed 当作排空证明。`clock_skew_seconds` 必须显式给出，范围 [0,1]，默认建议 0；不是自动拟合偏移。

所有绑定先检查 lexical ancestor/descendant 无 symlink、无 `..`、regular file、稳定 dev/inode/size/mtime 和 SHA。独立 raw receipt 的全部 `file_hashes`（包括 bytes/mtime）、授权 `file_bindings`、strict receipt 的所有 source/artifact/harness bindings 都重新读取核验；结果文件只核字节，不解析其分数。独立审计器/common、旧 collector、router 的 SHA 由本工具冻结常量核对，不执行这些脚本。只扫描最终 run 的 dumps；所有非预期文件、临时文件、嵌套文件、orphan、漏项、重复和在读取中变化均阻断或列为不完整。旧窗口外 router 行单列，不计本 batch；与本 batch 窗口相交的未配对行不得忽略。

只接受外部授权中预承诺 B42/N4=168 或 B+C78/N4=312，核验完整 manifest/completion job 集、阶段计数、6 个 harness pins；独立 raw receipt 必须 passed、errors=[]，其 trace_rows 对 raw request/client/generation 是完整双射。授权 SHA 必须与 raw receipt 一致。

## 证据等级（不能互相替代）

1. 成功请求：request payload 默认 `json.dumps(...).encode('utf-8')` SHA 与 response_raw UTF-8 SHA 均唯一匹配；router HTTP 200、complete=true、close started/completed=true、无 close error，并完整落入该 client 时间窗（仅使用 pins 给出的有界 skew）。client 成功的 http_status=null 仍报告为未知，200 来自 router。
2. 上游 HTTP 错误：双 SHA、明确 non-200、完整关闭；仍是失败请求，成本按收到的 provider usage 留存。
3. 冻结 router 自生成 502：仅接受冻结 `RemoteProtocolError` 分支的 exact compact JSON bytes，字段和值必须为 `error=upstream transport failure`、`detail=RemoteProtocolError`、实际 replica。router 行必须 complete=false/error=RemoteProtocolError，且 **不存在** response_sha256/http_status/upstream_close_* 字段。仅凭 exact request SHA + 完整时间包含 + 唯一、一对一候选建立 `request_only_association`。没有 response 双 SHA 或连接关闭证据；不伪造这些字段，不断言请求是否到达/是否生成/是否计费，不凭短时延记 0。
4. 重试：独立 raw 审计证明之外，再按 client+generation 校验 payload 字节相同、attempt 连续 1…N（N<=3）、max_attempts=3、前序 transient HTTP error+will_retry=true、末次 success+will_retry=false、时间有序且包含记录的 sleep（仅容许 ISO 时间精度的 1 微秒舍入）。没有可独立关联 router 的纯连接错误保持阻断；模型/malformed response 重抽永不接受。

相同 payload 的重试不能按日志顺序猜配；完整时间窗候选不唯一、同一 router 行被复用、success 双 SHA 不唯一均阻断。原 strict errors 全量原样输出，仅对本工具逐条重建且归属于已验明 retry 链的 first-success 限制类别标注 explained；任何其他类别或字段差异保持阻断。原 strict status 永不改写。

本版只覆盖 HTTPError 429/500/502/503/504 重试的 router 证据；冻结 client 原授权还允许 URLError、TimeoutError 等瞬时 transport 错误。本补充无法证实这些无响应字节的复杂关联时，表示 **本补充证据未覆盖**，不表示该重试违反原授权，不授权重抽、换请求或删失败。

## 用量与输出

只从 `response_raw` strict JSON 提取 usage，拒绝重复 key、NaN/Inf/溢出，必须与 response_json 全量 strict-JSON 相同；错误无 JSON 时仅保留原始字节并明确 unknown。所有被报告 token 字段必须是 nonnegative integer（bool 不合法）；total=input+output；reasoning 是 output 子集，不再相加。并存 alias/来源冲突记 unknown 且保留各原值；缺失 cache 或 failed-response usage 不填 0。每项输出 known_sum/known_count/unknown_count/complete_total；任何范围不完整使完整总额 null；router 自生成 502 不因最终 retry 成功而补足成本。

新 receipt 分开输出 received-byte fidelity、router error attribution、authorized retry chains、all-attempt usage completeness。`accounting_integrity=PASS` 可表示证据按合同完整保留，但不表示每次 HTTP 成功；存在 request-only association 或未知成本时 overall 为 INCOMPLETE，而非全成功。不可把此状态升格为 benchmark/连续健康/确定性/计费验收。输出必须是运行目录和所有证据文件之外的新目录。

这里的 overall INCOMPLETE **仅属于 transport/usage 证据维度**，不等于另经独立审计通过的模型评分或实验矩阵不完整。不得为了补齐未知 token/cache/计费信息再次生成模型响应；未知成本只能继续保留未知。

接口只有离线 `audit.py --pins ROOT_PINS_JSON --pins-sha256 ROOT_EXTERNAL_SHA --out NEW_DIRECTORY`；没有 real dispatch 参数。实际调用必须等待 ROOT 提供最终 pins，本目录的 synthetic receipt 不是实际 B/C 结果。
