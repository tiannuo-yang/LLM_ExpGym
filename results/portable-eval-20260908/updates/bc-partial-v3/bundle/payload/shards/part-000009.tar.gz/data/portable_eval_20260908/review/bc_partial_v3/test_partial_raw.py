"""Only invented memory bytes; no active B/C evidence or real harness calls."""
import copy
import hashlib
import json
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from audit_bc_common import same, strict_json
from partial_raw import audit_raw, check_agent


class MemoryReader:
    def __init__(self):
        self.memory, self.files = {}, {}

    def put(self, path, value):
        self.memory[str(path)] = value if type(value) is bytes else json.dumps(value, allow_nan=False).encode()
        return Path(path)

    def bind(self, path, expected=None):
        body = self.memory[str(path)]
        digest = hashlib.sha256(body).hexdigest()
        if expected is not None and digest != expected:
            raise ValueError('private_memory_pin')
        self.files[str(path)] = {'path': str(path), 'sha256': digest, 'bytes': len(body), 'mtime_ns': 0}
        return body

    def read(self, path, expected=None):
        return strict_json(self.bind(path, expected))


class Fixture:
    def __init__(self):
        self.root = Path('/__synthetic_bc_partial__/run')
        self.reader = MemoryReader()
        self.args = SimpleNamespace(base_url='http://private.invalid/v1')
        self.schemas = [{'type': 'function', 'function': {'name': 'private_tool', 'parameters': {}}}]
        self.jobs = {jid: {'id': jid, 'seed': 10, 'strategy': 'poolact',
                          'output_dir': str(self.root / 'results' / jid),
                          'dump_dir': str(self.root / 'dumps' / jid),
                          'preflight': {'native_tool_schemas': self.schemas,
                              'agent_dump_contexts': [{'job': jid, 'agent': i} for i in range(4)]}}
                     for jid in ('job0', 'job1')}
        profile = SimpleNamespace(wire_errors=lambda payload, args, seed:
                                  [] if payload.get('seed') == seed else ['private_seed_mismatch'])
        self.bc = SimpleNamespace(profiles=lambda: profile)
        self.paths = []

    def raw(self, rid='r1', *, jid='job0', cid='c1', gid='g1', attempt=1,
            state='success', finish='stop', usage='default', agent=0):
        payload = {'model': 'private', 'seed': 10 + agent, 'tools': self.schemas,
                   'parallel_tool_calls': False, 'tool_choice': 'auto',
                   'messages': [{'role': 'system', 'content': 'private'}, {'role': 'user', 'content': 'task'}]}
        value = {'schema_version': 'expgym.api_attempt.v1', 'run_id': 'poolact-pilot-bc:run',
                 'request_id': rid, 'client_id': cid, 'generation_id': gid, 'attempt': attempt, 'max_attempts': 3,
                 'state': state, 'started_at_utc': '2026-09-08T00:00:00+00:00',
                 'finished_at_utc': None if state == 'in_progress' else '2026-09-08T00:00:01+00:00',
                 'endpoint': 'http://private.invalid/v1/chat/completions', 'context': {'job': jid, 'agent': agent},
                 'request_payload': payload, 'response_raw': None, 'response_json': None,
                 'http_status': None, 'will_retry': False, 'retry_delay_seconds': None, 'error': None}
        if state == 'success':
            usage = {'prompt_tokens': 2, 'completion_tokens': 3, 'total_tokens': 5} if usage == 'default' else usage
            response = {'choices': [{'message': {'role': 'assistant', 'content': 'answer'}, 'finish_reason': finish}], 'usage': usage}
            value.update(response_raw=json.dumps(response), response_json=response)
        return value

    def add(self, value, path=None):
        path = path or self.root / 'dumps' / value['context']['job'] / (value['request_id'] + '.json')
        self.paths.append(self.reader.put(path, value))
        return path

    def audit(self):
        result = audit_raw(self.paths, self.jobs, self.args, self.bc, self.root, self.reader)
        json.dumps(result, allow_nan=False)
        return result

    def agent(self, report, request_ids=('r1',), *, local_passed=True):
        raw = report['records'][request_ids[-1]]['record']
        response = strict_json(raw['response_raw']) if raw['response_raw'] is not None else None
        usage = response.get('usage') if type(response) is dict else None
        message = response['choices'][0]['message'] if type(response) is dict and response.get('choices') else {'role': 'assistant', 'content': 'failed local answer'}
        entries = []
        for rid in request_ids:
            item = report['records'][rid]
            entry = {k: item['record'].get(k) for k in ('request_id', 'generation_id', 'attempt', 'state', 'http_status')}
            entries.append(dict(entry, usage=item['parsed_usage']))
        agent = {'agent_id': 0, 'seed': 10, 'api_dump': {'client_id': 'c1', 'run_id': 'poolact-pilot-bc:run'},
                 'api_calls': 1, 'http_request_attempts': len(entries),
                 'messages': [{'role': 'system', 'content': 'private'}, {'role': 'user', 'content': 'task'}, message],
                 'usage_attempts': [{'llm_call_index': 1, 'attempts': entries}],
                 'prompt_tokens': (usage or {}).get('prompt_tokens', 0),
                 'completion_tokens': (usage or {}).get('completion_tokens', 0), 'cached_prompt_tokens': 0,
                 'passed': local_passed, 'protocol_failures': 0, 'answer': 'Natural answer'}
        path = self.root / 'results/job0/poolact/agents/agent_0.json'
        self.reader.put(path, agent)
        return agent, path

    def check(self, report, agent=None, path=None):
        if agent is None:
            agent, path = self.agent(report)
        result = check_agent(agent, path, self.jobs['job0'], 0, report, self.reader)
        json.dumps(result, allow_nan=False)
        return result


class PartialRawTests(unittest.TestCase):
    def test_valid_raw_and_bound_agent_without_completion_claim(self):
        f = Fixture()
        f.add(f.raw())
        result = f.audit()
        self.assertFalse(result['complete'])
        self.assertEqual(result['job_errors']['job0'], [])
        self.assertTrue(result['all_raw_bound'])
        self.assertEqual(result['records']['r1']['agent_id'], 0)
        self.assertTrue(f.check(result)['passed'])

    def test_502_unknown_then_success_keeps_both_attempt_costs(self):
        f = Fixture()
        first = f.raw(state='error')
        first.update(http_status=502, error={'type': 'HTTPError'}, will_retry=True, retry_delay_seconds=1)
        f.add(first)
        f.add(f.raw('r2', attempt=2))
        result = f.audit()
        self.assertEqual(result['states'], {'error': 1, 'success': 1})
        self.assertEqual(result['job_errors']['job0'], [])
        self.assertEqual(result['usage_totals']['input_tokens']['known_sum'], 2)
        self.assertEqual(result['usage_totals']['input_tokens']['unknown_count'], 1)
        self.assertIsNone(result['usage_totals']['input_tokens']['complete_total'])
        agent, path = f.agent(result, ('r1', 'r2'))
        self.assertTrue(f.check(result, agent, path)['passed'])

    def test_pending_is_bound_counted_unknown_and_not_qualified(self):
        f = Fixture()
        f.add(f.raw(state='in_progress'))
        result = f.audit()
        self.assertEqual(result['states']['in_progress'], 1)
        self.assertFalse(result['file_rows'][0]['terminal'])
        self.assertEqual(result['usage_totals']['output_tokens']['unknown_count'], 1)
        self.assertTrue(result['job_errors']['job0'])

    def test_raw_abort_downgrades_locally_passed_natural_answer(self):
        f = Fixture()
        f.add(f.raw(finish='abort'))
        result = f.audit()
        self.assertEqual(result['abort_job_ids'], ['job0'])
        self.assertEqual(result['finish_reasons'], {'abort': 1})
        agent, path = f.agent(result, local_passed=True)
        self.assertEqual(agent['protocol_failures'], 0)
        checked = f.check(result, agent, path)
        self.assertFalse(checked['passed'])
        self.assertEqual(checked['finish_reasons'], {'abort': 1})

    def test_unknown_or_other_invalid_finish_is_not_observed_abort(self):
        for finish in (None, 'unknown', 'provider-specific-invalid'):
            with self.subTest(finish=finish):
                f = Fixture()
                f.add(f.raw(finish=finish))
                result = f.audit()
                self.assertEqual(result['abort_job_ids'], [])
                self.assertTrue(result['job_errors']['job0'])
                self.assertIn('disallowed_or_unknown_raw_finish_reason', result['file_rows'][0]['errors'])
                self.assertFalse(f.check(result)['passed'])

    def test_parsed_null_conflict_never_uses_fabricated_response_json_usage(self):
        f = Fixture()
        raw = f.raw(state='malformed_response')
        raw.update(response_raw='null', response_json={'usage': {'prompt_tokens': 999}})
        f.add(raw)
        result = f.audit()
        self.assertIn('raw_response_json_conflict', result['file_rows'][0]['errors'])
        self.assertEqual(result['usage_totals']['input_tokens']['known_sum'], 0)
        self.assertEqual(result['usage_totals']['input_tokens']['unknown_count'], 1)

    def test_duplicate_ids_do_not_overwrite_or_hide_physical_usage(self):
        f = Fixture()
        raw = f.raw()
        f.add(raw)
        f.add(raw, f.root / 'dumps/job0/deeper/r1.json')
        result = f.audit()
        self.assertEqual(len(result['file_rows']), 2)
        self.assertNotIn('r1', result['records'])
        self.assertEqual(result['usage_totals']['input_tokens']['known_sum'], 4)
        self.assertIsNone(result['usage_totals']['input_tokens']['complete_total'])
        self.assertTrue(all(any(e.startswith('duplicate_request_id:') for e in row['errors']) for row in result['file_rows']))

    def test_nested_orphan_and_outside_paths_all_remain_bound(self):
        f = Fixture()
        for index, path in enumerate((f.root / 'dumps/job0/deeper/r0.json', f.root / 'dumps/orphan/r1.json', f.root / 'other/r2.json')):
            f.add(f.raw('r%d' % index, gid='g%d' % index, cid='c%d' % index), path)
        result = f.audit()
        self.assertEqual(len(result['file_rows']), 3)
        self.assertEqual(len(result['records']), 3)
        self.assertTrue(result['all_raw_bound'])
        self.assertTrue(all(row['errors'] for row in result['file_rows']))
        self.assertTrue(result['global_errors'])

    def test_missing_usage_and_reasoning_conflict_stay_unknown(self):
        for usage in (None, {'prompt_tokens': 2, 'completion_tokens': 3, 'total_tokens': 5,
                             'reasoning_tokens': 1, 'completion_tokens_details': {'reasoning_tokens': 2}}):
            with self.subTest(usage=usage):
                f = Fixture()
                f.add(f.raw(usage=usage))
                result = f.audit()
                self.assertEqual(result['usage_totals']['reasoning_tokens']['unknown_count'], 1)
                self.assertIsNone(result['usage_totals']['reasoning_tokens']['complete_total'])
                self.assertEqual(result['usage_totals']['cache_read_tokens']['unknown_count'], 1)

    def test_nontransient_HTTP_status_cannot_authorize_retry(self):
        f = Fixture()
        raw = f.raw(state='error')
        raw.update(http_status=400, error={'type': 'HTTPError'}, will_retry=True, retry_delay_seconds=1)
        f.add(raw)
        f.add(f.raw('r2', attempt=2))
        result = f.audit()
        self.assertIn('retry_outside_frozen_transient_policy', result['file_rows'][0]['errors'])

    def test_retry_gap_or_payload_mutation_is_rejected(self):
        for gap in (False, True):
            with self.subTest(gap=gap):
                f = Fixture()
                raw = f.raw(state='error')
                raw.update(error={'type': 'TimeoutError'}, will_retry=True, retry_delay_seconds=1)
                f.add(raw)
                final = f.raw('r2', attempt=3 if gap else 2)
                if not gap:
                    final['request_payload']['messages'][1]['content'] = 'changed retry'
                f.add(final)
                result = f.audit()
                wanted = 'noncontiguous_generation_attempts' if gap else 'retry_payload_changed'
                self.assertTrue(any(wanted in row['errors'] for row in result['file_rows']))

    def test_failed_agent_ledger_does_not_become_success_from_local_passed(self):
        f = Fixture()
        raw = f.raw(state='error')
        raw.update(http_status=502, error={'type': 'HTTPError'})
        f.add(raw)
        result = f.audit()
        agent, path = f.agent(result)
        self.assertTrue(agent['passed'])
        self.assertFalse(f.check(result, agent, path)['passed'])

    def test_bad_JSON_and_invalid_profile_do_not_erase_other_rows(self):
        f = Fixture()
        f.paths.append(f.reader.put(f.root / 'dumps/job0/broken.json', b'{"duplicate":1,"duplicate":2}'))
        raw = f.raw()
        raw['request_payload']['seed'] = 999
        f.add(raw)
        result = f.audit()
        self.assertEqual(len(result['file_rows']), 2)
        self.assertTrue(result['all_raw_bound'])
        self.assertIn('r1', result['records'])
        self.assertIn('raw_profile_or_seed_mismatch', result['records']['r1']['errors'])
        self.assertEqual(result['usage_totals']['input_tokens']['unknown_count'], 1)


if __name__ == '__main__':
    unittest.main(verbosity=2)
