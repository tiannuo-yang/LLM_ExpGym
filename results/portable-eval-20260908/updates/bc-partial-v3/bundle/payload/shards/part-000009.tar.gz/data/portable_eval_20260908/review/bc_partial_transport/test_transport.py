"""Ten CPU-only transport tests using invented dictionaries, never live logs."""
import copy
from datetime import datetime, timezone
import hashlib
import json
import unittest

from transport import associate, parsed_usage


def digest(body):
    return hashlib.sha256(body).hexdigest()


def raw_response(*, start=100, end=110, state='success', finish='stop', usage=None):
    response = {'choices': [{'message': {'role': 'assistant', 'content': 'private answer'},
                             'finish_reason': finish}], 'usage': usage}
    return {'request_payload': {'model': 'private', 'messages': [{'role': 'user', 'content': '中'}]},
            'started_at_utc': datetime.fromtimestamp(start, timezone.utc).isoformat(),
            'finished_at_utc': datetime.fromtimestamp(end, timezone.utc).isoformat(),
            'state': state, 'http_status': None if state == 'success' else 503,
            'response_raw': json.dumps(response), 'response_json': response}


def router_response(raw, *, start=101, elapsed=5, status=200):
    return {'request_id': 'private-router-request', 'replica': 0,
            'payload_sha256': digest(json.dumps(raw['request_payload']).encode('utf-8')),
            'response_sha256': digest(raw['response_raw'].encode('utf-8')),
            'started_unix': start, 'elapsed_seconds': elapsed, 'http_status': status,
            'complete': True, 'upstream_close_started': True,
            'upstream_close_completed': True, 'upstream_close_error': None, 'error': None}


class TransportTests(unittest.TestCase):
    def test_closed_double_hash_success_and_upstream_HTTP_error(self):
        for status, state, evidence in ((200, 'success', 'response_double_sha_http200_closed'),
                                       (503, 'error', 'response_double_sha_upstream_http_error_closed')):
            with self.subTest(status=status):
                raw = raw_response(state=state)
                row = router_response(raw, status=status)
                matched = set()
                result = associate(raw, [row], matched)
                self.assertEqual(result['evidence'], evidence)
                self.assertEqual(result['router_line_1based'], 1)
                self.assertEqual(result['candidate_lines'], [1])
                self.assertEqual(result['errors'], [])
                self.assertEqual(result['payload_sha256'], row['payload_sha256'])
                self.assertEqual(result['response_sha256'], row['response_sha256'])
                self.assertEqual(matched, {0})

    def test_identical_payload_and_response_retries_use_distinct_time_windows(self):
        first = raw_response(start=100, end=110)
        second = raw_response(start=200, end=210)
        self.assertEqual(first['response_raw'], second['response_raw'])
        router = [router_response(first), router_response(second, start=201)]
        matched = set()
        one, two = associate(first, router, matched), associate(second, router, matched)
        self.assertEqual(one['candidate_lines'], [1])
        self.assertEqual(two['candidate_lines'], [2])
        self.assertEqual(two['router_line_1based'], 2)
        self.assertEqual(matched, {0, 1})

    def test_overlapping_double_hash_candidates_remain_ambiguous(self):
        raw = raw_response()
        rows = [router_response(raw), router_response(raw, start=102)]
        matched = set()
        result = associate(raw, rows, matched)
        self.assertEqual(result['evidence'], 'unmatched')
        self.assertEqual(result['candidate_lines'], [1, 2])
        self.assertIsNone(result['router_line_1based'])
        self.assertTrue(result['errors'])
        self.assertEqual(matched, set())

    def test_a_router_line_cannot_be_reused_by_another_attempt(self):
        raw, matched = raw_response(), set()
        rows = [router_response(raw)]
        self.assertEqual(associate(raw, rows, matched)['router_line_1based'], 1)
        result = associate(copy.deepcopy(raw), rows, matched)
        self.assertEqual(result['evidence'], 'unmatched')
        self.assertIsNone(result['router_line_1based'])
        self.assertEqual(result['errors'], ['router_row_reused'])
        self.assertEqual(result['candidate_lines'], [1])
        self.assertEqual(matched, {0})

    def test_router_generated_502_is_request_only_and_usage_unknown(self):
        raw = raw_response(state='error')
        response = {'error': 'upstream transport failure', 'detail': 'RemoteProtocolError', 'replica': 0}
        raw.update(http_status=502, response_json=response,
                   response_raw=json.dumps(response, ensure_ascii=False, allow_nan=False, separators=(',', ':')))
        row = {'request_id': 'private-generated-502', 'replica': 0, 'complete': False,
               'error': 'RemoteProtocolError', 'started_unix': 101, 'elapsed_seconds': 5,
               'payload_sha256': digest(json.dumps(raw['request_payload']).encode('utf-8'))}
        matched = set()
        result = associate(raw, [row], matched)
        self.assertEqual(result['evidence'], 'request_only_association_router_generated_502')
        self.assertEqual(result['router_line_1based'], 1)
        self.assertNotIn('response_sha256', row)
        self.assertEqual(matched, {0})
        values, conflicts, sources = parsed_usage(raw)
        self.assertTrue(all(value is None for value in values.values()))
        self.assertEqual(conflicts, {})
        self.assertTrue(all(not value for value in sources.values()))

    def test_abort_HTTP200_transport_success_makes_no_semantic_claim(self):
        raw = raw_response(finish='abort')
        before = copy.deepcopy(raw)
        result = associate(raw, [router_response(raw)], set())
        self.assertEqual(result['evidence'], 'response_double_sha_http200_closed')
        self.assertEqual(result['errors'], [])
        self.assertNotIn('semantic_passed', result)
        self.assertNotIn('pool_passed', result)
        self.assertEqual(raw, before)
        self.assertEqual(raw['response_json']['choices'][0]['finish_reason'], 'abort')

    def test_unclosed_HTTP_or_close_exception_cannot_claim_closed_evidence(self):
        for changed in ({'complete': False}, {'upstream_close_started': False},
                        {'upstream_close_completed': False}, {'upstream_close_error': 'PrivateCloseError'},
                        {'error': 'PrivateReadError'}, {'http_status': True}):
            with self.subTest(changed=changed):
                raw = raw_response()
                row = dict(router_response(raw), **changed)
                matched = set()
                result = associate(raw, [row], matched)
                self.assertEqual(result['evidence'], 'unmatched')
                self.assertIsNone(result['router_line_1based'])
                self.assertEqual(result['candidate_lines'], [1])
                self.assertTrue(result['errors'])
                self.assertEqual(matched, set())

    def test_parsed_response_conflict_null_and_missing_success_body_rejected(self):
        for body, parsed, state in (('null', {'usage': {'prompt_tokens': 999}}, 'error'),
                                    ('{"usage":null}', None, 'success'),
                                    (None, None, 'success'), (None, {}, 'error')):
            with self.subTest(body=body, parsed=parsed, state=state):
                raw = raw_response(state=state)
                raw.update(response_raw=body, response_json=parsed)
                with self.assertRaises(ValueError):
                    parsed_usage(raw)
        values, conflicts, _ = parsed_usage({'state': 'error', 'response_raw': 'null', 'response_json': None})
        self.assertTrue(all(value is None for value in values.values()))
        self.assertEqual(conflicts, {})

    def test_unknown_and_conflicting_usage_preserve_sources_not_zero(self):
        unknown, conflicts, _ = parsed_usage(raw_response())
        self.assertTrue(all(value is None for value in unknown.values()))
        self.assertEqual(conflicts, {})
        usage = {'prompt_tokens': 2, 'input_tokens': 4, 'completion_tokens': 3, 'total_tokens': 5,
                 'reasoning_tokens': 1, 'completion_tokens_details': {'reasoning_tokens': 2}}
        values, conflicts, sources = parsed_usage(raw_response(usage=usage))
        self.assertIsNone(values['input_tokens'])
        self.assertIsNone(values['reasoning_tokens'])
        self.assertIsNone(values['cache_read_tokens'])
        self.assertEqual(values['output_tokens'], 3)
        self.assertEqual(conflicts['input_tokens'], {'prompt_tokens': 2, 'input_tokens': 4})
        self.assertEqual(sources['reasoning_tokens'], {'reasoning_tokens': 1, 'completion_tokens_details.reasoning_tokens': 2})

    def test_missing_pair_and_outside_full_interval_are_retained_unmatched(self):
        raw = raw_response()
        altered = router_response(raw)
        altered['response_sha256'] = '0' * 64
        # Merely overlapping is insufficient: either endpoint exceeds +/-1s.
        for rows in ([], [altered], [router_response(raw, start=98.9)],
                     [router_response(raw, start=109, elapsed=2.1)]):
            with self.subTest(rows=rows):
                matched = set()
                result = associate(raw, rows, matched)
                self.assertEqual(result['evidence'], 'unmatched')
                self.assertIsNone(result['router_line_1based'])
                self.assertEqual(result['candidate_lines'], [])
                self.assertTrue(result['errors'])
                self.assertEqual(matched, set())
        boundary = associate(raw, [router_response(raw, start=99, elapsed=12)], set())
        self.assertEqual(boundary['evidence'], 'response_double_sha_http200_closed')


if __name__ == '__main__':
    unittest.main(verbosity=2)
