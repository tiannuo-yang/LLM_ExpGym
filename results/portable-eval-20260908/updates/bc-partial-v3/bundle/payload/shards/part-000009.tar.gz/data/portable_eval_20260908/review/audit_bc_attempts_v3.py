#!/usr/bin/env python3
"""Independent B42/C78 post-drain raw/usage audit; no model or scoring calls."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime
import json
import math
from pathlib import Path

from audit_bc_common import Reader, authority, load_harness, normalized_endpoint, same, sha, strict_inventory, strict_json, valid_native_history


def usage_values(value):
    value = value or {}
    detail = value.get("prompt_tokens_details") or value.get("input_tokens_details") or {}
    completion = value.get("completion_tokens_details") or {}
    output = value.get("output_tokens_details") or {}
    def first(a, b):
        return a if a is not None else b
    reasoning = [n for n in (value.get("reasoning_tokens"), completion.get("reasoning_tokens"), output.get("reasoning_tokens")) if n is not None]
    reasoning_count = reasoning[0] if reasoning and all(n == reasoning[0] for n in reasoning) else None
    return {"input_tokens": first(value.get("prompt_tokens"), value.get("input_tokens")),
            "output_tokens": first(value.get("completion_tokens"), value.get("output_tokens")),
            "provider_total_tokens": value.get("total_tokens"),
            "reasoning_tokens": reasoning_count,
            "cache_read_tokens": detail.get("cached_tokens"), "cache_write_tokens": detail.get("cache_write_tokens")}


def usage_total(values):
    rows = [usage_values(value) for value in values]
    return {key: {"known_sum": sum(r[key] for r in rows if r[key] is not None),
                  "known_count": sum(r[key] is not None for r in rows),
                  "unknown_count": sum(r[key] is None for r in rows),
                  "complete_total": sum(r[key] for r in rows) if all(r[key] is not None for r in rows) else None}
            for key in usage_values({})}


def validate_usage(usage):
    values = usage_values(usage)
    if any(value is not None and (type(value) is not int or value < 0) for value in values.values()):
        raise ValueError("Provider usage is not a nonnegative integer or unknown")
    usage = usage or {}
    sources = [usage.get("reasoning_tokens")]
    for field in ("completion_tokens_details", "output_tokens_details"):
        if isinstance(usage.get(field), dict):
            sources.append(usage[field].get("reasoning_tokens"))
    if any(value is not None and (type(value) is not int or value < 0) for value in sources):
        raise ValueError("Invalid provider reasoning source count")
    if all(values[key] is not None for key in ("input_tokens", "output_tokens", "provider_total_tokens")):
        if values["input_tokens"] + values["output_tokens"] != values["provider_total_tokens"]:
            raise ValueError("Provider token total differs")


def retry_is_transient(record):
    """Frozen urllib client retry boundary; never a delivered/model retry."""
    error = record.get("error") or {}
    status, delay = record.get("http_status"), record.get("retry_delay_seconds")
    if not isinstance(delay, (int, float)) or isinstance(delay, bool) or not math.isfinite(delay) or not 0 <= delay <= 30:
        return False
    if error.get("type") == "HTTPError":
        return type(status) is int and status in (429, 500, 502, 503, 504)
    return status is None and error.get("type") in (
        "URLError", "TimeoutError", "ConnectionError", "BrokenPipeError", "ConnectionAbortedError", "ConnectionRefusedError", "ConnectionResetError")


def audit(run_dir, authorization, authorization_sha256):
    paths = strict_inventory(run_dir)
    artifact_paths = strict_inventory(run_dir, "results")
    root, reader = Path(run_dir).resolve(), Reader()
    auth = authority(root, authorization, authorization_sha256, reader)
    manifest = reader.read(root / "manifest.json", auth["manifest_sha256"])
    reader.read(root / "commands.json", auth["commands_sha256"])
    execution = reader.read(root / "execution.json")
    bc = load_harness()
    args = bc.parse_args(auth["resolved_argv"][3:])
    jobs, settings = manifest["identity"]["jobs"], manifest["identity"]["settings"]
    planned = bc.build_jobs(args)
    stripped = [{k: v for k, v in j.items() if k not in ("preflight", "environment_overrides")} for j in jobs]
    if not same(stripped, planned) or not same(settings, bc.settings(args)) or args.backend != "openai" or not args.execute or not args.allow_real:
        raise ValueError("Exact authorized real B/C plan/settings differ")
    expected_pools = 78 if args.include_c else 42
    if len(jobs) != expected_pools or len({j["id"] for j in jobs}) != expected_pools:
        raise ValueError("Unexpected precommitted B/C job count")
    expected_ids = {j["id"] for j in jobs}
    if execution.get("passed") is not True or execution.get("executed") is not True or execution.get("unstarted") != []:
        raise ValueError("No complete final execution receipt; do not replace failures")
    if len(execution["results"]) != expected_pools or {r["job_id"] for r in execution["results"]} != expected_ids or any(r.get("passed") is not True for r in execution["results"]):
        raise ValueError("Incomplete executed job set")
    errors, warnings, by_request, by_client = [], [], {}, defaultdict(list)
    states, statuses, choices = Counter(), Counter(), Counter()
    expected_run = "poolact-pilot-bc:" + root.name
    def require(condition, message):
        if not condition:
            errors.append(message)
    for path in paths:
        record = reader.read(path)
        rid, cid = record.get("request_id"), record.get("client_id")
        require(path.parent.name in expected_ids and path.stem == rid and rid not in by_request, "Unexpected raw job/request namespace: " + str(path))
        require(record.get("schema_version") == "expgym.api_attempt.v1" and record.get("run_id") == expected_run, "Raw schema/run differs: " + str(rid))
        require(isinstance(cid, str) and bool(cid) and isinstance(record.get("generation_id"), str) and bool(record["generation_id"]), "Raw client/generation absent")
        require(type(record.get("attempt")) is int and 1 <= record["attempt"] <= 3 and type(record.get("max_attempts")) is int and record["max_attempts"] == 3, "Raw retry bounds differ")
        require(record.get("state") in ("success", "error", "malformed_response"), "Raw unfinished state")
        start, end = record.get("started_at_utc"), record.get("finished_at_utc")
        require(isinstance(start, str) and isinstance(end, str) and datetime.fromisoformat(end) >= datetime.fromisoformat(start), "Raw incomplete/reversed time interval")
        parsed_response = None
        if isinstance(record.get("response_raw"), str):
            try:
                parsed_response = strict_json(record["response_raw"])
            except (ValueError, RecursionError):
                require(record.get("response_json") is None and record.get("state") != "success", "Unparseable successful/parsed response")
                warnings.append({"request_id": rid, "kind": "non_json_failed_response_retained", "usage": None})
            else:
                require(same(parsed_response, record.get("response_json")), "Exact raw response JSON differs: " + str(rid))
        else:
            require(record.get("response_raw") is None and record.get("response_json") is None and record.get("state") != "success", "Missing successful response bytes/parsed mismatch")
        usage = parsed_response.get("usage") if isinstance(parsed_response, dict) else None
        validate_usage(usage)
        record["_audit_usage"] = usage
        if usage:
            sources = {"top_level": usage.get("reasoning_tokens")}
            for key in ("completion_tokens_details", "output_tokens_details"):
                if isinstance(usage.get(key), dict):
                    sources[key] = usage[key].get("reasoning_tokens")
            sources = {key: value for key, value in sources.items() if value is not None}
            if len(set(sources.values())) > 1:
                warnings.append({"request_id": rid, "kind": "conflicting_provider_reasoning_counts", "sources": sources,
                                 "policy": "conflict makes reasoning count unknown; no first-source complete total"})
        require(not any(k.lower().replace("-", "_") in {"authorization", "api_key", "headers", "extra_headers"} for k in set(record) | set(record["request_payload"])), "Credential/header field in raw")
        states[record.get("state")] += 1
        statuses[str(record.get("http_status")) if record.get("http_status") is not None else "unknown"] += 1
        choices[record["request_payload"].get("tool_choice")] += 1
        by_request[rid] = (path, record)
        by_client[cid].append(rid)
    used_clients, used_requests, used_generations, rows = set(), set(), set(), []
    for job in jobs:
        require(Path(job["output_dir"]) == root / "results" / job["id"] and Path(job["dump_dir"]) == root / "dumps" / job["id"], "Job output namespace differs")
        paths_agent = [Path(job["output_dir"]) / job["strategy"] / "agents" / ("agent_%d.json" % i) for i in range(4)]
        for agent_id, path in enumerate(paths_agent):
            agent = reader.read(path)
            cid = agent["api_dump"]["client_id"]
            require(cid not in used_clients and agent["api_dump"]["run_id"] == expected_run, "Duplicate/cross-run client")
            used_clients.add(cid)
            require(type(agent.get("agent_id")) is int and agent["agent_id"] == agent_id and type(agent.get("seed")) is int and agent["seed"] == job["seed"] + agent_id, "Authoritative N4 agent/seed differs")
            ledger, messages = agent["usage_attempts"], agent["messages"]
            positions = [i for i, m in enumerate(messages) if m.get("role") == "assistant"]
            require(type(agent.get("api_calls")) is int and len(ledger) == len(positions) == agent["api_calls"] and 1 <= len(ledger) <= 31, "Pool generation/assistant count bound differs")
            require(type(agent.get("http_request_attempts")) is int and agent["http_request_attempts"] <= 93, "Pool HTTP attempt bound differs")
            request_ids, generation_ids, delivered_usage, finishes, nonempty = [], [], [], Counter(), 0
            configs = None
            for call_index, (call, position) in enumerate(zip(ledger, positions), 1):
                entries = call["attempts"]
                require(type(call.get("llm_call_index")) is int and call["llm_call_index"] == call_index, "Nonsequential call index")
                require(1 <= len(entries) <= 3 and all(type(e.get("attempt")) is int for e in entries) and [e["attempt"] for e in entries] == list(range(1, len(entries) + 1)), "Noncontiguous retry chain")
                gids = {entry["generation_id"] for entry in entries}
                require(len(gids) == 1 and not gids.intersection(used_generations), "Generation identity reused")
                used_generations.update(gids)
                generation_ids.extend(gids)
                require(valid_native_history(messages[:position]), "Unpaired native tool history in stored full prefix")
                original = None
                for i, entry in enumerate(entries):
                    rid = entry["request_id"]
                    require(rid not in used_requests, "Request reused by multiple calls")
                    used_requests.add(rid)
                    request_ids.append(rid)
                    raw_path, raw = by_request[rid]
                    require(raw_path.parent.name == job["id"] and raw["client_id"] == cid, "Cross-job/client raw join")
                    require(all(same(entry.get(k), raw.get(k)) for k in ("request_id", "generation_id", "attempt", "state", "http_status")), "Ledger/raw attempt metadata differs")
                    require(same(entry.get("usage"), raw["_audit_usage"]), "Ledger/raw usage differs")
                    payload = raw["request_payload"]
                    require(not bc.profiles().wire_errors(payload, args, seed=job["seed"] + agent_id), "Raw request profile/seed differs")
                    require(payload.get("parallel_tool_calls") is False and payload.get("tool_choice") in ("auto", "none") and same(payload.get("tools"), job["preflight"]["native_tool_schemas"]), "Native wire tool contract differs")
                    require("prompt_cache_key" not in payload, "Unexpected prompt-cache key")
                    current_config = {k: v for k, v in payload.items() if k not in ("messages", "tool_choice")}
                    if configs is not None:
                        require(same(current_config, configs), "Per-client generation/schema changed")
                    configs = current_config
                    require(raw["endpoint"] == normalized_endpoint(args.base_url), "Endpoint differs")
                    require(same(raw.get("context"), job["preflight"]["agent_dump_contexts"][agent_id]), "Selected agent dump context differs")
                    if original is not None:
                        require(same(original, payload), "Retry mutated request")
                    original = payload
                    if i < len(entries) - 1:
                        require(raw["state"] == "error" and raw.get("will_retry") is True, "Model/malformed output resampled or broken retry")
                        require(retry_is_transient(raw), "Retry outside frozen transient HTTP/transport policy")
                    else:
                        require(raw["state"] == "success" and raw.get("will_retry") is False and raw.get("error") is None, "No final successful delivery")
                response = strict_json(raw["response_raw"])
                message = dict(response["choices"][0]["message"])
                message.setdefault("role", "assistant")
                require(same(message, messages[position]), "Delivered raw assistant differs from stored history")
                finishes[response["choices"][0].get("finish_reason")] += 1
                nonempty += bool(message.get("reasoning_content"))
                delivered_usage.append(raw["_audit_usage"])
            require(set(request_ids) == set(by_client[cid]) and len(request_ids) == agent["http_request_attempts"], "Agent attempt ledger/raw set differs")
            delivered = usage_total(delivered_usage)
            for old, key in (("prompt_tokens", "input_tokens"), ("completion_tokens", "output_tokens"), ("cached_prompt_tokens", "cache_read_tokens")):
                require(agent.get(old) == delivered[key]["known_sum"], "Legacy delivered usage counter differs: " + old)
            rows.append({"job_id": job["id"], "agent_id": agent_id, "client_id": cid, "path": str(path),
                         "request_ids": request_ids, "generation_ids": generation_ids, "finish_reasons": dict(finishes),
                         "reasoning_content_nonempty": nonempty, "delivered_usage": delivered,
                         "protocol_failures": agent.get("protocol_failures"), "protocol_retries": agent.get("protocol_retries")})
    require(used_clients == set(by_client), "Orphan raw clients remain; preserve all failures")
    require(used_requests == set(by_request), "Raw attempts and ledgers are not a bijection")
    require(len(rows) == expected_pools * 4, "N4 trace coverage differs")
    require(strict_inventory(run_dir) == paths and strict_inventory(run_dir, "results") == artifact_paths, "Evidence namespace changed")
    reader.unchanged()
    values = [record["_audit_usage"] for _, record in by_request.values()]
    successes = [record["_audit_usage"] for _, record in by_request.values() if record["state"] == "success"]
    return {"schema_version": 1, "passed": not errors, "errors": errors, "warnings": warnings,
            "classification": "Custom study; independent B/C raw audit", "run_directory": str(root),
            "manifest_sha256": sha(root / "manifest.json"), "execution_sha256": sha(root / "execution.json"),
            "authorization_sha256": authorization_sha256, "pool_count": expected_pools, "trace_count": len(rows),
            "attempt_count": len(by_request), "generation_count": len(used_generations), "client_count": len(used_clients),
            "dump_states": dict(states), "http_status_counts": dict(statuses), "tool_choice_counts": dict(choices),
            "all_attempt_usage": usage_total(values), "delivered_usage": usage_total(successes),
            "trace_rows": rows, "file_hashes": sorted(reader.files.values(), key=lambda r: r["path"]),
            "auditor_sha256": sha(__file__), "common_sha256": sha(Path(__file__).with_name("audit_bc_common.py")),
            "limitations": ["Transport HTTP status/closure comes from separate router join; client null status is unknown.",
                            "Schema/profile/raw-response/ledger and all stored assistant deliveries checked here. Complete source-owned prompts and deterministic trim-to-wire are checked by the separate same-runtime child.",
                            "Provider-reported usage is not independently metered; reasoning is included in output, cache missing stays null.",
                            "No forced-none requirement, semantic resampling, model request, new authorization, or confirmation claim."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--authorization", type=Path, required=True)
    parser.add_argument("--authorization-sha256", required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    args = parser.parse_args()
    if args.output_json.exists() or args.run_dir.resolve() in args.output_json.resolve().parents:
        raise ValueError("Receipt must be new and outside original run")
    result = audit(args.run_dir, args.authorization, args.authorization_sha256)
    with args.output_json.open("x") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({k: result[k] for k in ("passed", "errors", "pool_count", "trace_count", "attempt_count", "dump_states", "all_attempt_usage")}))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
