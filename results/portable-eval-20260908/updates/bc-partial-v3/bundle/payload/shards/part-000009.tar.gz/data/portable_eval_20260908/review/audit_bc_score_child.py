#!/usr/bin/env python3
"""Python-3.7-compatible B/C same-runtime score and stored-context checker.

Input: stdin JSON {job, harness_args}. Output: one prefixed JSON receipt.
Only frozen score/probe helpers execute; no runner main/resume, model or socket.
"""
from __future__ import annotations

import argparse
from contextlib import redirect_stdout
import copy
from io import StringIO
import json
from pathlib import Path
import runpy
import socket
import sys

from audit_bc_common import cost_sanity, load_harness, read, same, sha, trusted_stored_prompt, valid_native_history


def check(specification):
    blocked = []
    def deny(*args, **kwargs):
        blocked.append(True)
        raise RuntimeError("BC_INDEPENDENT_NO_MODEL_OR_NETWORK")
    socket.socket.connect = socket.socket.connect_ex = socket.create_connection = deny
    sys.dont_write_bytecode = True
    bc = load_harness()
    args = bc.parse_args(specification["harness_args"])
    job = specification["job"]
    sys.path.insert(0, str(args.repo_root))
    import demo_experiment as demo
    from expgym import llm_clients as clients
    from expgym import react_loop as loop
    from expgym import tool_protocol as protocol
    from expgym.extras.parallel_cache import SharedExplorationGraph
    demo.build_llm = demo.FakeLLM.generate = deny
    clients.OpenAICompatibleLLM.__init__ = clients.OpenAICompatibleLLM.generate = deny
    out = StringIO()
    with redirect_stdout(out):
        bc.guarded_runner(job["command"][2:], "score")
    scored = bc.parse_probe(out.getvalue())
    python = Path(job["command"][0])
    scored["runtime"]["executable_sha256"] = sha(python)
    config_file = python.parent.parent / "pyvenv.cfg"
    scored["runtime"]["pyvenv_config_sha256"] = sha(config_file) if config_file.is_file() else None
    identity = {key: value for key, value in scored.items() if key not in ("score_checks", "aggregate_recomputed")}
    identity_matches = same(identity, job["preflight"])
    sys.argv = job["command"][2:]
    scope = runpy.run_path(job["command"][2], run_name="bc_independent_context_scope")
    parsed = scope["parse_args"]()
    item = scope["_repeat_namespace"](parsed, 0)
    item.question_index = parsed.question_index if parsed.question_index is not None else 0
    item.questions = None
    item._evaluation_identity = identity["evaluation_identity"]
    scope["bind_evaluation_identity"](item._evaluation_identity)
    base_cost = scope["resolve_base_cost"](item.scenario, item)
    budget, modes = scope["resolve_cost_regime"](item, base_cost)
    if len(modes) != 1:
        raise ValueError("Expected one fixed B/C regime")
    include_overhead = modes[0] == "time_focus"
    scenario = scope["_SCENARIOS"][item.scenario]
    graph = SharedExplorationGraph(n_agents=4, diversity_mode=True)
    errors, rows, all_requests = [], [], []
    for agent_id in range(4):
        namespace = scope["_agent_namespace"](item, job["strategy"], agent_id, None)
        context = demo._resolve_context(scenario, include_overhead, namespace, argparse.Namespace(supports_native_tools=True)).strip()
        original_system = demo._resolve_system_prompt(scenario, include_overhead, namespace) or loop.build_system_prompt()
        system = protocol.native_system_prompt(original_system)
        schemas = protocol.native_tool_schemas(demo._resolve_tools(scenario, namespace))
        path = Path(job["output_dir"]) / job["strategy"] / "agents" / ("agent_%d.json" % agent_id)
        agent = read(path)
        costs = cost_sanity(agent)
        errors.extend(costs["errors"])
        if not same(namespace._api_dump_context, job["preflight"]["agent_dump_contexts"][agent_id]) or not same(schemas, job["preflight"]["native_tool_schemas"]):
            errors.append("Actual agent namespace/schema differs from preflight")
        prompt = trusted_stored_prompt(agent["messages"], system, context, job["strategy"], agent_id, graph)
        errors.extend(prompt["errors"])
        schema_tokens = len(json.dumps(schemas, ensure_ascii=False, allow_nan=False)) // 3
        positions = [i for i, message in enumerate(agent["messages"]) if message.get("role") == "assistant"]
        calls = agent["usage_attempts"]
        if len(positions) != len(calls):
            raise ValueError("Agent message/ledger counts differ")
        trimmed_count, request_ids, max_estimate, choices = 0, [], 0, []
        for call, position in zip(calls, positions):
            prefix = copy.deepcopy(agent["messages"][:position])
            if not valid_native_history(prefix):
                errors.append("Stored untrimmed native history is unpaired")
            expected = loop._trim_messages(copy.deepcopy(prefix), parsed.max_context_tokens - schema_tokens)
            trimmed_count += not same(expected, prefix)
            estimate = loop._estimate_tokens(expected) + schema_tokens
            max_estimate = max(max_estimate, estimate)
            if estimate > parsed.max_context_tokens:
                errors.append("Trimmed input violates frozen schema-aware admission cap")
            # Secret-field redaction is deterministic; no credential file is read.
            expected = bc.pilot_helpers().redact_wire(expected, None, clients.OpenAICompatibleLLM._is_secret_field)
            for entry in call["attempts"]:
                rid = entry["request_id"]
                record = read(Path(job["dump_dir"]) / (rid + ".json"))
                payload = record["request_payload"]
                if not same(payload.get("messages"), expected) or not same(payload.get("tools"), schemas):
                    errors.append("Deterministically trimmed native wire/schema differs: " + rid)
                if not same(record.get("context"), namespace._api_dump_context):
                    errors.append("Actual namespace/raw context differs: " + rid)
                request_ids.append(rid)
                choices.append(payload.get("tool_choice"))
        all_requests.extend(request_ids)
        rows.append({"agent_id": agent_id, "path": str(path), "sha256": sha(path), "prompt": prompt,
                     "cost_sanity": costs,
                     "request_ids": request_ids, "trimmed_generations_observed": trimmed_count,
                     "max_runner_estimated_input_tokens_including_schema": max_estimate,
                     "observed_tool_choices": choices, "forced_none_required": False})
    return {"passed": identity_matches and not errors and not blocked,
            "identity_matches_preflight": identity_matches, "original_score_receipt": scored,
            "errors": errors, "agent_rows": rows, "request_ids": all_requests,
            "model_or_network_attempts": len(blocked), "cost_regime": {"base_cost": base_cost, "budget": budget, "mode": modes[0]},
            "scope": "Original frozen per-agent/aggregate score and identity recomputation, plus exact native source context and N4 graph-owned syntax on stored full history, followed by frozen schema-aware trim and exact raw comparison."}


def main():
    result = check(json.load(sys.stdin))
    print("BC_INDEPENDENT_JSON=" + json.dumps(result, ensure_ascii=False, sort_keys=True, allow_nan=False))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
