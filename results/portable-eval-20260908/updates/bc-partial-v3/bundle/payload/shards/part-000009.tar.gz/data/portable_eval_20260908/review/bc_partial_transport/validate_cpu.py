#!/usr/bin/env python3
"""Run only synthetic unit tests under both existing runtimes, preserving output."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]


def identity():
    return {str(p): {"sha256": hashlib.sha256(p.read_bytes()).hexdigest(), "bytes": p.stat().st_size,
                     "mtime_ns": p.stat().st_mtime_ns} for p in sorted(HERE.iterdir()) if p.suffix in (".py", ".md")}


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output-dir", required=True, type=Path)
    out = p.parse_args().output_dir.absolute()
    out.mkdir(parents=True, exist_ok=False)
    before, runs = identity(), []
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    for name, python in (("native", WORK / "LLM_ExpGym/.venv/bin/python"),
                         ("legacy", WORK / "kimi_k3_eval/data_runtime/.venv-hpo/bin/python")):
        command = [str(python), "-B", "-m", "unittest", "discover", "-s", str(HERE), "-p", "test_transport.py", "-v"]
        r = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, env=env, check=False)
        with (out / (name + ".log")).open("x") as stream:
            stream.write(r.stdout)
        runs.append({"runtime": name, "command": command, "exit_code": r.returncode,
                     "log_sha256": hashlib.sha256(r.stdout.encode()).hexdigest(),
                     "ten_tests_passed": r.returncode == 0 and "Ran 10 tests" in r.stdout and r.stdout.rstrip().endswith("OK")})
    result = {"schema_version": "partial-transport-cpu-preparation-v1", "production_and_tests": before,
              "source_bytes_and_mtime_unchanged": before == identity(), "runs": runs,
              "passed": before == identity() and all(r["ten_tests_passed"] for r in runs),
              "real_router_reads": 0, "real_raw_reads": 0, "new_scorer_or_model_or_api_calls": 0}
    with (out / "receipt.json").open("x") as stream:
        json.dump(result, stream, indent=2, sort_keys=True); stream.write("\n")
    print(json.dumps(result))
    raise SystemExit(0 if result["passed"] else 1)
