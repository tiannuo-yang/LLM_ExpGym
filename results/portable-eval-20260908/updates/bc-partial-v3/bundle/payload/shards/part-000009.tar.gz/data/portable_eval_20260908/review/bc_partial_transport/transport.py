#!/usr/bin/env python3
"""Pinned partial B/C transport association; no completion forgery or execution."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path
import stat

HERE = Path(__file__).resolve().parent
STUDY = HERE.parents[1]
HELPER = STUDY / "serving/reports/bc_retained_attempts_v3/audit.py"
HELPER_SHA = "2aa3a3066060e2a39a9af933ba1af915dff81a8670d8b2a2ebadd42b56b17d3f"
import hashlib
if hashlib.sha256(HELPER.read_bytes()).hexdigest() != HELPER_SHA:
    raise ValueError("Frozen retained-attempt helper changed")
spec = importlib.util.spec_from_file_location("frozen_retained_transport", HELPER)
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)


def parsed_usage(raw):
    body = raw.get("response_raw")
    if body is None:
        h.require(raw.get("response_json") is None and raw.get("state") != "success", "Missing successful wire response")
        return h.usage_values(None)
    h.require(isinstance(body, str), "Non-string response_raw")
    parsed = h.strict_json(body)
    h.require(h.same(parsed, raw.get("response_json")), "Parsed response differs from original response_raw")
    return h.usage_values(parsed.get("usage") if isinstance(parsed, dict) else None)


def associate(raw, router, matched, skew=1.0):
    h.require(h.finite(skew) and 0 <= skew <= 1, "Invalid explicit time skew")
    start, end = h.timestamp(raw["started_at_utc"]), h.timestamp(raw["finished_at_utc"])
    h.require(start <= end, "Reversed client interval")
    payload = h.digest(json.dumps(raw["request_payload"]).encode("utf-8"))
    body = raw.get("response_raw")
    response = h.digest(body.encode("utf-8")) if isinstance(body, str) else None
    candidates = [i for i, r in enumerate(router) if response is not None and r.get("payload_sha256") == payload
                  and r.get("response_sha256") == response and h.contained(r, start, end, skew)]
    evidence = "unmatched"
    if len(candidates) == 1:
        row = router[candidates[0]]
        if h.closed(row) and type(row.get("http_status")) is int:
            if raw["state"] == "success" and raw.get("http_status") in (None, 200) and row["http_status"] == 200:
                evidence = "response_double_sha_http200_closed"
            elif raw["state"] == "error" and raw.get("http_status") == row["http_status"] != 200:
                evidence = "response_double_sha_upstream_http_error_closed"
    if not candidates and raw["state"] == "error" and response is not None:
        candidates = [i for i, r in enumerate(router) if r.get("payload_sha256") == payload
                      and h.contained(r, start, end, skew) and h.router_generated(r, raw)]
        if len(candidates) == 1:
            evidence = "request_only_association_router_generated_502"
    index = candidates[0] if evidence != "unmatched" else None
    errors = []
    if index is None:
        errors.append("missing_ambiguous_or_unclosed_router_association")
    elif index in matched:
        errors.append("router_row_reused")
        index, evidence = None, "unmatched"
    else:
        matched.add(index)
    return {"evidence": evidence, "router_line_1based": None if index is None else index + 1,
            "candidate_lines": [i + 1 for i in candidates], "errors": errors,
            "payload_sha256": payload, "response_sha256": response}


def stamp(path):
    path = h.safe_path(path)
    s = path.stat()
    h.require(stat.S_ISREG(s.st_mode) and s.st_nlink == 1, "Snapshot/source must be single-link regular file")
    return {"bytes": s.st_size, "mtime_ns": s.st_mtime_ns, "inode": s.st_ino, "device": s.st_dev}


def write_new(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def audit(partial_path, partial_sha, drain_path, drain_sha, router_path, output):
    reader = h.Reader()
    partial = h.strict_json(reader.bind(partial_path, partial_sha))
    h.require(partial.get("schema_version") == "bc78-partial-independent-evidence-v1" and partial.get("audit_completed") is True
              and partial.get("overall_complete") is False and partial.get("global_errors") == [], "Not a sealed partial evidence receipt")
    root = h.safe_path(partial["run_directory"])
    drain = h.strict_json(reader.bind(drain_path, drain_sha))
    h.require(h.safe_path(Path(partial["ROOT_drain_receipt"]["path"]).absolute()) == drain_path
              and partial["ROOT_drain_receipt"]["sha256"] == drain_sha
              and drain.get("drained") is True and drain.get("run_directory") == str(root), "External ROOT drain mismatch")
    for binding in partial["file_bindings"].values():
        reader.bind(binding["path"], binding["sha256"], binding)
    raw_report = reader.read(partial["raw_report"])
    paths = h.dump_inventory(root)
    expected = {p for p in partial["file_bindings"] if root / "dumps" in Path(p).parents}
    h.require({str(p) for p in paths} == expected == {r["path"] for r in raw_report["file_rows"]}, "Full raw namespace changed")
    for path, sha in h.FROZEN.values():
        reader.bind(path, sha)
    reader.bind(HELPER, HELPER_SHA)
    reader.bind(Path(__file__))
    output = h.safe_path(output)
    h.require(router_path == STUDY / "serving/runs/1203474/router_requests.jsonl", "Unexpected router log namespace")
    h.require(output != root and root not in output.parents and not output.exists(), "Output overlaps original run or exists")
    output.mkdir(parents=True, exist_ok=False)
    before = stamp(router_path)
    router_bytes = router_path.read_bytes()
    after_read = stamp(router_path)
    snapshot = output / "router_requests_snapshot.jsonl"
    with snapshot.open("xb") as stream:
        stream.write(router_bytes)
    stamp(snapshot)
    reader.bind(snapshot)
    errors, warnings = [], []
    if before != after_read or len(router_bytes) != after_read["bytes"]:
        errors.append({"kind": "router_log_changed_during_snapshot"})
    if router_bytes and not router_bytes.endswith(b"\n"):
        errors.append({"kind": "unterminated_router_snapshot_line"})
    h.require(all(line.strip() for line in router_bytes.splitlines()), "Blank router line would change physical line numbering")
    router = [h.strict_json(line) for line in router_bytes.splitlines() if line.strip()]
    for row in router:
        h.require(isinstance(row, dict) and h.finite(row.get("started_unix")) and h.finite(row.get("elapsed_seconds"))
                  and row["elapsed_seconds"] >= 0 and type(row.get("replica")) is int and 0 <= row["replica"] <= 3
                  and type(row.get("complete")) is bool, "Invalid router receipt")
        h.checksum(row.get("payload_sha256"))
    h.require(all(isinstance(r.get("request_id"), str) and r["request_id"] for r in router)
              and len({r["request_id"] for r in router}) == len(router), "Router IDs missing/reused")
    matched, attempts, usage, starts, ends = set(), [], [], [], []
    for path in paths:
        raw = h.strict_json(reader.bind(path))
        values, conflicts, sources = parsed_usage(raw)
        usage.append(values)
        if conflicts:
            warnings.append({"request_id": raw["request_id"], "usage_conflicts": conflicts})
        row = associate(raw, router, matched)
        errors.extend({"kind": e, "request_id": raw["request_id"]} for e in row["errors"])
        starts.append(h.timestamp(raw["started_at_utc"])); ends.append(h.timestamp(raw["finished_at_utc"]))
        row.update(request_id=raw["request_id"], client_id=raw["client_id"], generation_id=raw["generation_id"], attempt=raw["attempt"],
                   will_retry=raw["will_retry"], state=raw["state"], job_id=path.parent.name, dump=reader.files[str(path)],
                   usage=values, reported_usage_sources=sources, usage_conflicts=conflicts,
                   finish_reasons=[c.get("finish_reason") for c in (raw.get("response_json") or {}).get("choices", [])])
        attempts.append(row)
    window = [min(starts), max(ends)]
    unmatched = [{"router_line_1based": i + 1, "router_receipt": r,
                  "overlaps_batch_window": r["started_unix"] <= window[1] + 1 and r["started_unix"] + r["elapsed_seconds"] >= window[0] - 1}
                 for i, r in enumerate(router) if i not in matched]
    orphans = [r["router_line_1based"] for r in unmatched if r["overlaps_batch_window"]]
    if orphans:
        errors.append({"kind": "unmatched_router_intersects_batch", "lines": orphans})
    final_bytes = router_path.read_bytes()
    observation = {"path": str(router_path), "before": before, "after_snapshot_read": after_read, "after_join": stamp(router_path),
                   "snapshot_sha256": h.digest(router_bytes), "final_observed_sha256": h.digest(final_bytes),
                   "original_snapshot_prefix_unchanged": final_bytes[:len(router_bytes)] == router_bytes,
                   "byte_identical_at_final_observation": final_bytes == router_bytes}
    if not observation["original_snapshot_prefix_unchanged"]:
        errors.append({"kind": "router_snapshot_prefix_changed"})
    if final_bytes != router_bytes:
        errors.append({"kind": "router_bytes_changed_after_snapshot_unexamined_suffix_or_rewrite"})
    final_usage = h.totals(usage)
    h.require(h.same(final_usage, raw_report["usage_totals"]), "Fresh original-wire usage differs from sealed partial raw audit")
    h.require(h.dump_inventory(root) == paths, "Original raw set changed")
    reader.unchanged()
    evidence = dict(Counter(a["evidence"] for a in attempts))
    report = {"schema_version": "bc-partial-retained-transport-v1", "created_utc": datetime.now(timezone.utc).isoformat(),
              "association_integrity": "FAIL" if errors else "PASS", "whole_matrix_complete": False,
              "all_attempts_double_sha": not errors and all(a["evidence"].startswith("response_double_sha") for a in attempts),
              "all_usage_fields_complete": not errors and all(v["complete_total"] is not None for v in final_usage.values()),
              "run_directory": str(root), "partial_receipt": {"path": str(partial_path), "sha256": partial_sha},
              "ROOT_drain_receipt": {"path": str(drain_path), "sha256": drain_sha}, "router_source_observation": observation,
              "fixed_clock_skew_seconds": 1.0, "scenario_window_unix": window, "raw_attempts": len(attempts),
              "snapshot_router_rows": len(router), "matched_router_rows": len(matched), "evidence_counts": evidence,
              "attempts": attempts, "all_attempt_usage": final_usage, "unmatched_router_rows": unmatched,
              "errors": errors, "warnings": warnings, "file_bindings": reader.files, "new_model_or_network_calls": 0,
              "limits": ["Fixed +/-1 second is an association assumption, not exact independently synchronized service timing.",
                         "Generated 502 has request-only association; response/close/upstream generation and billable cost remain unknown.",
                         "HTTP200 abort response can match bytes while its entire pool remains quarantined by the original partial audit.",
                         "The whole original 78-pool matrix stays incomplete; no frozen strict-complete collector was run or altered.",
                         "Unknown usage remains null. Router snapshot change observations do not claim continuous inactivity or health."]}
    write_new(output / "receipt.json", report)
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ("partial", "drain", "router", "output"):
        parser.add_argument("--" + key, required=True, type=lambda value: Path(value).absolute())
    for key in ("partial-sha256", "drain-sha256"):
        parser.add_argument("--" + key, required=True)
    a = parser.parse_args()
    result = audit(a.partial, a.partial_sha256, a.drain, a.drain_sha256, a.router, a.output)
    print(json.dumps({"association_integrity": result["association_integrity"], "raw_attempts": result["raw_attempts"],
                      "evidence_counts": result["evidence_counts"], "all_attempts_double_sha": result["all_attempts_double_sha"]}))
