"""CPU-only synthetic fixtures; frozen collector really runs, no model/runner does."""
import copy
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("retained_audit", HERE / "audit.py")
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, allow_nan=False) + "\n")


def binding(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def original(path):
    return dict(binding(path), bytes=path.stat().st_size, mtime_ns=path.stat().st_mtime_ns)


def utc(value):
    return datetime.fromtimestamp(value, timezone.utc).isoformat()


class RetainedAttempts(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="bc-retained-cpu-")
        self.addCleanup(temporary.cleanup)
        self.tmp = Path(temporary.name)
        self.root = self.tmp / "synthetic-final-bc"
        self.count = 42
        self.error_retry = True

    def prepare(self, include_c=False):
        self.count = 78 if include_c else 42
        source = self.tmp / "synthetic-client.py"
        source.write_text("# synthetic, never imported\n")
        capacity = self.tmp / "synthetic-capacity.json"
        write(capacity, {"synthetic": True})
        harness = {str(audit.STUDY / "harness/poolact_pilot_timing.py"): audit.HARNESS_SHA}
        for index in range(5):
            path = self.tmp / ("harness-%d.txt" % index)
            path.write_text("synthetic binding %d\n" % index)
            harness[str(path)] = binding(path)["sha256"]
        self.acceptance = self.tmp / "synthetic-acceptance.json"
        write(self.acceptance, {"source_tree_sha256": "a" * 64, "files": {"expgym/llm_clients.py": binding(source)["sha256"]}})
        stages = ["B1_hpo"] * 27 + ["B2_search_audit"] * 12 + ["B3_nas101a_tight"] * 3
        if include_c:
            stages += ["C_development_repeats"] * 36
        jobs = [{"id": "job-%02d" % i, "stage": stage, "system": "poolact", "expected_traces": 4,
                 "runtime": "legacy_paramnet" if i < 9 else "current", "strategy": "naive", "seed": 1206,
                 "dump_dir": str(self.root / "dumps" / ("job-%02d" % i)),
                 "output_dir": str(self.root / "results" / ("job-%02d" % i))} for i, stage in enumerate(stages)]
        self.manifest = {"identity": {"jobs": jobs, "settings": {"include_c_precommitted": include_c, "backend": "openai", "tool_protocol": "native", "agents": 4, "workers": 4},
                        "counts": {"jobs": self.count, "agent_traces": self.count * 4, "B_jobs": 42, "B_agent_traces": 168,
                                   "C_jobs": 36 if include_c else 0, "C_agent_traces": 144 if include_c else 0, "legacy_paramnet_jobs": 9},
                        "harness_files": harness, "static_acceptance": dict(binding(self.acceptance), source_tree_sha256="a" * 64)}}
        write(self.root / "manifest.json", self.manifest)
        write(self.root / "commands.json", {"synthetic": True})
        self.completion = {"executed": True, "passed": True, "unstarted": [], "failed": [], "validated_trace_count": self.count * 4,
                           "elapsed_seconds_including_audits": self.count * 12 + 20,
                           "results": [{"job_id": j["id"], "passed": True, "run": {"exit_code": 0}} for j in jobs]}
        write(self.root / "execution.json", self.completion)
        self.auth_path = self.tmp / "synthetic-root-authorization.json"
        self.auth = {"authorized": True, "authorization_kind": "CPU synthetic fixture only, not a real launch", "output_dir": str(self.root),
                     "manifest_sha256": binding(self.root / "manifest.json")["sha256"], "commands_sha256": binding(self.root / "commands.json")["sha256"],
                     "source_tree_sha256": "a" * 64, "harness_sha256": audit.HARNESS_SHA,
                     "resolved_argv": [sys.executable, "-B", str(audit.STUDY / "harness/poolact_pilot_timing.py")] + (["--include-c"] if include_c else []) + ["--synthetic-never-executed"],
                     "file_bindings": harness}
        write(self.auth_path, self.auth)
        self.raws, self.router, self.trace_rows = [], [], []
        base = 1788825600.0
        for index, job in enumerate(jobs):
            for agent_id in range(4):
                n = index * 4 + agent_id
                cid, gid = "client-%03d" % n, "generation-%03d" % n
                start = base + n * 3
                payload = {"model": "synthetic-no-network", "unique": n, "max_tokens": 32768, "tool_choice": "auto"}
                response = {"id": "response-%03d" % n, "choices": [{"finish_reason": "stop", "message": {"role": "assistant", "content": "synthetic"}}],
                            "usage": {"prompt_tokens": 10, "completion_tokens": 4, "reasoning_tokens": 3, "total_tokens": 14, "prompt_tokens_details": None}}
                ids = []
                for attempt in range(1, (3 if n == 0 and self.error_retry else 2)):
                    failed = n == 0 and self.error_retry and attempt == 1
                    rid = "request-%03d-%d" % (n, attempt)
                    body = json.dumps({"error": "upstream transport failure", "detail": "RemoteProtocolError", "replica": 3}, separators=(",", ":")) if failed else json.dumps(response)
                    end = start + (0.01 if failed else 1.0)
                    raw = {"schema_version": "expgym.api_attempt.v1", "request_id": rid, "generation_id": gid, "client_id": cid,
                           "run_id": "poolact-pilot-bc:" + self.root.name, "context": {"synthetic_agent": agent_id},
                           "state": "error" if failed else "success", "attempt": attempt, "max_attempts": 3,
                           "started_at_utc": utc(start), "finished_at_utc": utc(end), "wall_time_seconds": end - start,
                           "request_payload": copy.deepcopy(payload), "response_raw": body, "response_json": json.loads(body),
                           "http_status": 502 if failed else None, "error": {"type": "HTTPError", "message": "HTTP Error 502"} if failed else None,
                           "will_retry": failed, "retry_delay_seconds": 0.25 if failed else None}
                    path = self.root / "dumps" / job["id"] / (rid + ".json")
                    row = {"request_id": "router-" + rid, "replica": 3 if failed else n % 4, "started_unix": start + .002,
                           "elapsed_seconds": .001 if failed else .9, "method": "POST", "path": "v1/chat/completions",
                           "payload_sha256": audit.digest(json.dumps(payload).encode()), "complete": not failed}
                    if failed:
                        row["error"] = "RemoteProtocolError"
                    else:
                        row.update(response_sha256=audit.digest(body.encode()), http_status=200, upstream_close_started=True, upstream_close_completed=True)
                    self.raws.append((path, raw)); self.router.append(row); ids.append(rid)
                    start = end + .25
                agent_path = self.root / "results" / job["id"] / "naive/agents" / ("agent_%d.json" % agent_id)
                write(agent_path, {"synthetic": True, "no_scores": True})
                self.trace_rows.append({"job_id": job["id"], "agent_id": agent_id, "client_id": cid, "generation_ids": [gid], "request_ids": ids, "path": str(agent_path)})
        self.source, self.capacity = source, capacity

    def seal(self):
        for path, raw in self.raws:
            write(path, raw)
        self.router_path = self.tmp / "synthetic-router-final.jsonl"
        self.router_path.write_text("".join(json.dumps(row) + "\n" for row in self.router))
        self.strict_dir = self.tmp / "strict-final"
        command = [sys.executable, "-B", str(audit.FROZEN["collector"][0]), "--scenario-root", str(self.root),
                   "--router-jsonl", str(self.router_path), "--completion-receipt", str(self.root / "execution.json"),
                   "--static-acceptance", str(self.acceptance), "--client-source", str(self.source),
                   "--router-source", str(audit.FROZEN["router"][0]), "--capacity-receipt", str(self.capacity), "--out", str(self.strict_dir)]
        result = subprocess.run(command, text=True, capture_output=True)
        self.assertIn(result.returncode, (0, 1), result.stderr)
        self.assertTrue((self.strict_dir / "receipt.json").exists(), result.stderr)
        original_paths = [p for p, _ in self.raws] + [Path(r["path"]) for r in self.trace_rows]
        original_paths += [self.root / "manifest.json", self.root / "commands.json", self.root / "execution.json", self.auth_path]
        original_paths += [Path(p) for p in self.auth["file_bindings"]]
        receipt = {"schema_version": 1, "passed": True, "errors": [], "run_directory": str(self.root),
                   "manifest_sha256": self.auth["manifest_sha256"], "execution_sha256": binding(self.root / "execution.json")["sha256"],
                   "authorization_sha256": binding(self.auth_path)["sha256"], "pool_count": self.count, "trace_count": self.count * 4,
                   "attempt_count": len(self.raws), "generation_count": self.count * 4, "client_count": self.count * 4,
                   "trace_rows": self.trace_rows, "file_hashes": [original(p) for p in sorted(set(original_paths))],
                   "auditor_sha256": audit.FROZEN["raw_auditor"][1], "common_sha256": audit.FROZEN["raw_common"][1]}
        self.raw_receipt = self.tmp / "synthetic-independent-raw-audit.json"
        write(self.raw_receipt, receipt)
        self.pins = {"schema_version": "portable_eval.bc_retained_attempts_pins.v1", "run_directory": str(self.root), "clock_skew_seconds": 0,
                     "inputs": {"strict_receipt": binding(self.strict_dir / "receipt.json"), "raw_audit_receipt": binding(self.raw_receipt),
                                "completion": binding(self.root / "execution.json"), "authorization": binding(self.auth_path),
                                "router_snapshot": binding(self.strict_dir / "router_requests_snapshot.jsonl"), "inventory": binding(self.strict_dir / "response_inventory.jsonl")}}
        self.pins["drain"] = {"confirmed": True, "confirmed_at_utc": utc(1788825600 + self.count * 12 + 5),
                              "completion_sha256": self.pins["inputs"]["completion"]["sha256"], "router_snapshot_sha256": self.pins["inputs"]["router_snapshot"]["sha256"]}
        self.pins_path = self.tmp / "ROOT-synthetic-pins.json"
        write(self.pins_path, self.pins)

    def check(self):
        return audit.audit(self.pins_path, binding(self.pins_path)["sha256"])

    def test_generated_502_then_success_unknown_cost_strict_fail_unchanged(self):
        self.prepare(); self.seal()
        before = original(self.strict_dir / "receipt.json")
        report = self.check()
        self.assertEqual(report["accounting_integrity"], "PASS", report["errors"])
        self.assertEqual(report["status"], "INCOMPLETE")
        self.assertEqual(report["strict_receipt_preserved"]["status"], "FAIL")
        self.assertEqual(report["attempt_count"], 169)
        self.assertEqual(report["client_states"], {"error": 1, "success": 168})
        self.assertEqual(report["all_attempt_usage"]["input_tokens"], {"known_sum": 1680, "known_count": 168, "unknown_count": 1, "complete_total": None})
        failed = next(row for row in report["attempts"] if row["state"] == "error")
        self.assertTrue(failed["evidence"].startswith("request_only"))
        self.assertIsNone(failed["router_response_sha256"])
        self.assertEqual(before, original(self.strict_dir / "receipt.json"))
        self.assertTrue(all(r["explained_by_authorized_retained_retry"] for r in report["strict_receipt_preserved"]["per_error_explanation"]))

    def test_full_bc_78_pools_312_agents(self):
        self.prepare(True); self.seal(); report = self.check()
        self.assertEqual((report["pool_count"], report["trace_count"], report["attempt_count"]), (78, 312, 313))
        self.assertEqual(report["accounting_integrity"], "PASS", report["errors"])

    def test_success_only_first_attempts_keep_strict_pass(self):
        self.error_retry = False; self.prepare(); self.seal(); report = self.check()
        self.assertEqual(report["strict_receipt_preserved"]["status"], "PASS")
        self.assertEqual(report["all_attempt_usage"]["input_tokens"]["complete_total"], 1680)
        self.assertIsNone(report["all_attempt_usage"]["cache_read_tokens"]["complete_total"])

    def test_upstream_503_closed_dual_sha_failure_is_retained(self):
        self.prepare()
        raw, router = self.raws[0][1], self.router[0]
        raw["http_status"] = 503
        raw["response_json"] = {"error": "upstream busy", "usage": {"prompt_tokens": 5, "completion_tokens": 1, "reasoning_tokens": 0, "total_tokens": 6}}
        raw["response_raw"] = json.dumps(raw["response_json"])
        router.pop("error"); router.update(complete=True, http_status=503, response_sha256=audit.digest(raw["response_raw"].encode()), upstream_close_started=True, upstream_close_completed=True)
        self.seal(); report = self.check()
        self.assertEqual(report["accounting_integrity"], "PASS", report["errors"])
        self.assertEqual(report["all_attempt_usage"]["input_tokens"]["complete_total"], 1685)
        self.assertEqual(report["client_states"]["error"], 1)

    def test_duplicate_request_only_time_association_is_rejected(self):
        self.prepare(); row = copy.deepcopy(self.router[0]); row["request_id"] = "ambiguous-copy"; self.router.append(row)
        self.seal(); report = self.check()
        self.assertEqual(report["accounting_integrity"], "FAIL")
        self.assertTrue(report["unmatched_router_inside_batch"])

    def test_same_payload_different_error_windows_match_uniquely(self):
        self.prepare()
        failed_path, failed = self.raws[0]
        again = copy.deepcopy(failed); again.update(request_id="request-000-mid", attempt=2, started_at_utc=utc(1788825600.26), finished_at_utc=utc(1788825600.27))
        successful = self.raws[1][1]; successful.update(attempt=3, started_at_utc=utc(1788825600.52), finished_at_utc=utc(1788825601.52))
        self.router[1]["started_unix"] = 1788825600.522
        newrow = copy.deepcopy(self.router[0]); newrow.update(request_id="router-second-error", started_unix=1788825600.262)
        self.raws.append((failed_path.parent / (again["request_id"] + ".json"), again)); self.router.append(newrow)
        self.trace_rows[0]["request_ids"].insert(1, again["request_id"])
        self.seal(); report = self.check()
        self.assertEqual(report["accounting_integrity"], "PASS", report["errors"])
        self.assertEqual(report["dimensions"]["router_error_attribution"]["request_only_associations"], 2)

    def test_in_progress_attempt_rejected(self):
        self.prepare(); self.raws[0][1].update(state="in_progress", finished_at_utc=None); self.seal()
        with self.assertRaises(ValueError): self.check()

    def test_late_attempt_after_drain_rejected(self):
        self.prepare(); self.seal(); self.pins["drain"]["confirmed_at_utc"] = utc(1788825600.001); write(self.pins_path, self.pins)
        with self.assertRaisesRegex(ValueError, "late"): self.check()

    def test_wrong_bytes_pin_rejected(self):
        self.prepare(); self.seal(); self.raws[0][0].write_text("{}")
        with self.assertRaisesRegex(ValueError, "SHA binding"): self.check()

    def test_raw_audit_receipt_must_use_external_pin(self):
        self.prepare(); self.seal(); self.pins["inputs"]["raw_audit_receipt"]["sha256"] = "0" * 64; write(self.pins_path, self.pins)
        with self.assertRaisesRegex(ValueError, "SHA binding"): self.check()

    def test_unsafe_symlink_pin_rejected(self):
        self.prepare(); self.seal(); link = self.tmp / "unsafe-link.json"; link.symlink_to(self.raw_receipt)
        self.pins["inputs"]["raw_audit_receipt"]["path"] = str(link); write(self.pins_path, self.pins)
        with self.assertRaisesRegex(ValueError, "symlink"): self.check()

    def test_wire_usage_mismatch_rejected(self):
        self.prepare(); self.raws[1][1]["response_json"]["usage"]["prompt_tokens"] += 1000; self.seal()
        with self.assertRaisesRegex(ValueError, "Parsed response differs"): self.check()

    def test_reasoning_conflict_remains_unknown(self):
        self.prepare(); raw = self.raws[1][1]
        raw["response_json"]["usage"]["completion_tokens_details"] = {"reasoning_tokens": 2}
        raw["response_raw"] = json.dumps(raw["response_json"]); self.router[1]["response_sha256"] = audit.digest(raw["response_raw"].encode())
        self.seal(); report = self.check()
        self.assertEqual(report["accounting_integrity"], "PASS")
        self.assertEqual(report["all_attempt_usage"]["reasoning_tokens"]["unknown_count"], 2)
        self.assertTrue(report["warnings"])

    def test_invalid_usage_domain_and_reasoning_subset(self):
        for value in (True, -1, 4.5, 5):
            with self.subTest(value=value), self.assertRaises(ValueError):
                audit.usage_values({"completion_tokens": 4, "reasoning_tokens": value})
        for text in ('{"usage": NaN}', '{"usage": 1e999}', '{"x":1,"x":2}'):
            with self.assertRaises(ValueError): audit.strict_json(text)

    def test_alias_boolean_is_not_hidden_by_preferred_integer(self):
        for usage in ({"prompt_tokens": 10, "input_tokens": True},
                      {"completion_tokens": 4, "output_tokens": False},
                      {"reasoning_tokens": 3, "completion_tokens_details": {"reasoning_tokens": True}},
                      {"prompt_tokens_details": {"cached_tokens": 2}, "input_tokens_details": {"cached_tokens": True}}):
            with self.subTest(usage=usage), self.assertRaises(ValueError): audit.usage_values(usage)
        values, conflicts, sources = audit.usage_values({"prompt_tokens": 10, "input_tokens": 11})
        self.assertIsNone(values["input_tokens"])
        self.assertEqual(conflicts["input_tokens"], {"prompt_tokens": 10, "input_tokens": 11})
        self.assertFalse(audit.same({"x": 1}, {"x": True}))

    def test_unrecognized_independent_auditor_source_pin_rejected(self):
        self.prepare(); self.seal()
        raw_audit = json.loads(self.raw_receipt.read_text()); raw_audit["auditor_sha256"] = "0" * 64
        write(self.raw_receipt, raw_audit)
        self.pins["inputs"]["raw_audit_receipt"] = binding(self.raw_receipt); write(self.pins_path, self.pins)
        with self.assertRaisesRegex(ValueError, "Unrecognized independent raw auditor"): self.check()

    def test_router_full_interval_not_just_start_must_fit(self):
        self.prepare(); self.router[0]["elapsed_seconds"] = .1
        self.seal(); self.assertEqual(self.check()["accounting_integrity"], "FAIL")

    def test_success_dual_sha_must_fit_its_own_interval(self):
        self.prepare(); self.router[1]["started_unix"] += 3
        self.seal(); self.assertEqual(self.check()["accounting_integrity"], "FAIL")

    def test_orphan_router_inside_batch_blocks(self):
        self.prepare(); row = copy.deepcopy(self.router[4]); row.update(request_id="orphan", payload_sha256="f" * 64); self.router.append(row)
        self.seal(); report = self.check()
        self.assertEqual(report["accounting_integrity"], "FAIL")

    def test_router_old_outside_window_is_listed_not_counted(self):
        self.prepare(); row = copy.deepcopy(self.router[-1]); row.update(request_id="historic-only", started_unix=1788825500.0, payload_sha256="e" * 64); self.router.append(row)
        self.seal(); report = self.check()
        self.assertEqual(report["accounting_integrity"], "PASS")
        self.assertEqual(len(report["router_rows_outside_batch"]), 1)

    def test_orphan_raw_added_after_independent_audit_blocks(self):
        self.prepare(); self.seal(); path, raw = self.raws[0]; extra = copy.deepcopy(raw); extra["request_id"] = "orphan"; write(path.parent / "orphan.json", extra)
        with self.assertRaisesRegex(ValueError, "dump set mismatch"): self.check()

    def test_temp_raw_file_blocks(self):
        self.prepare(); self.seal(); (self.raws[0][0].parent / ".pending.tmp").write_text("pending")
        with self.assertRaisesRegex(ValueError, "temporary"): self.check()

    def test_retry_payload_change_blocks(self):
        self.prepare(); raw = self.raws[1][1]; raw["request_payload"]["mutated"] = True
        self.router[1]["payload_sha256"] = audit.digest(json.dumps(raw["request_payload"]).encode())
        self.seal(); self.assertEqual(self.check()["accounting_integrity"], "FAIL")

    def test_retry_delay_overlap_blocks(self):
        self.prepare(); self.raws[0][1]["retry_delay_seconds"] = 3
        self.seal(); self.assertEqual(self.check()["accounting_integrity"], "FAIL")

    def test_unclosed_success_cannot_be_waived(self):
        self.prepare(); self.router[1]["upstream_close_completed"] = False
        self.seal(); report = self.check()
        self.assertEqual(report["accounting_integrity"], "FAIL")
        self.assertTrue(any(e["kind"] == "unexplained_strict_error" for e in report["errors"]))

    def test_fixed_router_error_body_must_match_exact_bytes(self):
        self.prepare(); raw = self.raws[0][1]; raw["response_raw"] = json.dumps(raw["response_json"])
        self.seal(); self.assertEqual(self.check()["accounting_integrity"], "FAIL")

    def test_nonretry_strict_error_cannot_be_ignored(self):
        self.prepare(); self.seal()
        receipt_path = self.strict_dir / "receipt.json"
        receipt = json.loads(receipt_path.read_text())
        receipt["errors"].append({"kind": "capacity_or_source_untrusted"})
        write(receipt_path, receipt)
        self.pins["inputs"]["strict_receipt"] = binding(receipt_path); write(self.pins_path, self.pins)
        with self.assertRaisesRegex(ValueError, "Unexpected strict errors"): self.check()

    def test_closed_success_hash_duplicate_is_not_resolved_by_order(self):
        self.prepare(); row = copy.deepcopy(self.router[1]); row["request_id"] = "duplicate-success"; self.router.append(row)
        self.seal(); self.assertEqual(self.check()["accounting_integrity"], "FAIL")

    def test_ancestor_crossing_router_interval_is_orphan_even_if_start_outside(self):
        self.prepare(); row = copy.deepcopy(self.router[-1]); row.update(request_id="overlap-orphan", payload_sha256="d" * 64, started_unix=1788825590, elapsed_seconds=20); self.router.append(row)
        self.seal(); report = self.check()
        self.assertEqual(report["accounting_integrity"], "FAIL")
        self.assertEqual(len(report["unmatched_router_inside_batch"]), 1)

    def test_explicit_clock_skew_is_bounded_not_fitted(self):
        self.prepare(); self.router[0]["started_unix"] -= .1; self.seal()
        self.assertEqual(self.check()["accounting_integrity"], "FAIL")
        self.pins["clock_skew_seconds"] = .11; write(self.pins_path, self.pins)
        self.assertEqual(self.check()["accounting_integrity"], "PASS")
        self.pins["clock_skew_seconds"] = 1.01; write(self.pins_path, self.pins)
        with self.assertRaisesRegex(ValueError, "bounded clock skew"): self.check()

    def test_response_byte_corruption_without_parsed_change_blocks(self):
        self.prepare(); self.raws[1][1]["response_raw"] += " "
        self.seal(); self.assertEqual(self.check()["accounting_integrity"], "FAIL")

    def test_independent_original_nonraw_binding_is_rehashed(self):
        self.prepare(); self.seal(); Path(self.trace_rows[0]["path"]).write_text('{"changed":true}')
        with self.assertRaisesRegex(ValueError, "SHA binding"): self.check()

    def test_reading_changed_namespace_is_failclosed(self):
        self.prepare(); self.seal()
        raw_path = self.raws[0][0]
        raw_path.rename(raw_path.with_suffix(".tmp"))
        with self.assertRaises((ValueError, FileNotFoundError)): self.check()

    def test_new_output_only_and_preserve_all_input_bytes(self):
        self.prepare(); self.seal(); report = self.check(); out = self.tmp / "new-supplement"
        result = audit.write_report(report, out)
        self.assertEqual(result["sha256"], binding(out / "receipt.json")["sha256"])
        with self.assertRaises(FileExistsError): audit.write_report(report, out)
        with self.assertRaises(ValueError): audit.write_report(report, self.root / "bad-output")
        for row in report["file_hashes"]:
            self.assertEqual(original(Path(row["path"])), row)


if __name__ == "__main__":
    unittest.main(verbosity=2)
