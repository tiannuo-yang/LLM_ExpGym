# B/C 中止后的部分证据审计

这是独立新工具，不修改原 78-pool 审计器，不创建缺失的 `execution.json`，不启动/重试 runner 或模型。实际读取原件前，必须提供原 B+C 授权、单父 PID 停派收据以及 ROOT 最终排空收据的外部 SHA。ROOT 排空包装至少有 `run_directory` 和 `drained: true`；其进程/health/router 详细证据是外部前提，本工具不会自行请求 health 或停止进程。

保留原计划全部 78 个池；实际启动、状态、文件及未观察执行数量来自封存原件，不硬填 47/31。先盘点全递归 dumps/results/logs，再读取结果状态；目录外层或更深 raw、重复请求、未终态、错误与未知 usage 均留存。unsafe 对象不打开，成本完整值降为 null。raw 报告保留每条路径/摘要/状态/usage，不重复复制全部 prompt/response 正文。

逐条严格核对 response_raw 与 response_json、原 retry 边界、profile/context、原 agent ledger 与 assistant 消息。`abort` 或其他不支持的 finish reason 使所在整个池不具备 performance qualification，即使原 local status 为 passed、Natural answer 或 0 protocol failures。原分数和状态不改写；只有结构与原状态/快照闭合的池才调用冻结 `audit_bc_score_child.py`，用其实际 3.7/3.11 运行时离线复核原评分、native context/schema、stored history 和确定性 trim-to-wire。abort 池可以保留原 scorer 一致性，但不被升级为合格表现。

最终 `overall_complete` 与 `performance_matrix_complete` 恒为 false。B 与 C 子集分别报告覆盖和 qualification；缺失/失败不填 0。原 502 重试链中没有 reported usage 的 attempt 保留 unknown。这里没有做全量 router 请求/响应双 SHA join，不能称 transport 已独立闭合，也不宣称真实计费或全并发 graph/cache/clock 因果已证明。

纯 CPU 测试：

```sh
PYTHONDONTWRITEBYTECODE=1 LLM_ExpGym/.venv/bin/python -B -m unittest discover \
  -s portable_eval_20260908/review/bc_partial_v3 -p 'test_*.py'
```

实际 CLI 仅待 ROOT 最终 drain 和明确运行批准后使用；输出目录必须全新且在原 run 之外。无需模型 key 或真实 API。
