#!/usr/bin/env python3
"""Transparent least-inflight router; metadata health checks generate no tokens."""
from __future__ import annotations

import argparse
import asyncio
import contextlib
import hashlib
import json
import secrets
import stat
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path

import httpx
import anyio
import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse

CLOSE_TIMEOUT_SECONDS = 5.0
HEALTH_INTERVAL_SECONDS = 10.0


def build_app(deployment: dict, receipt_path: Path, api_key: str | None = None):
    backends = [{**r, "healthy": False, "inflight": 0, "last_used": 0.0,
                 "health_error": "not_checked", "cleanup_quarantined": False}
                for r in deployment["replicas"]]
    client = httpx.AsyncClient(timeout=httpx.Timeout(3600.0, connect=10.0), trust_env=False,
                              limits=httpx.Limits(max_connections=256, max_keepalive_connections=64))

    async def refresh_health():
        async def check(backend):
            try:
                # /health and /health_generate perform generation in this engine.
                # /server_info asks the scheduler for state; it does not sample.
                response = await client.get(backend["url"] + "/server_info", timeout=10)
                data = response.json() if response.status_code == 200 else {}
                seed_active = (data.get("enable_deterministic_inference") is True
                               and data.get("sampling_backend") == "pytorch")
                backend["healthy"] = (response.status_code == 200 and seed_active
                                      and not backend["cleanup_quarantined"])
                backend["health_error"] = ("upstream_cleanup_failed_quarantined" if backend["cleanup_quarantined"]
                                           else None if backend["healthy"] else "metadata_or_seed_gate_failed")
            except (httpx.HTTPError, ValueError):
                backend["healthy"] = False
                backend["health_error"] = "metadata_rpc_unavailable"
        while True:
            await asyncio.gather(*(check(backend) for backend in backends))
            await asyncio.sleep(HEALTH_INTERVAL_SECONDS)

    @asynccontextmanager
    async def lifespan(app):
        task = asyncio.create_task(refresh_health())
        yield
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task
        await client.aclose()

    app = FastAPI(lifespan=lifespan)

    @app.middleware("http")
    async def authenticate(request: Request, call_next):
        if api_key is not None and not secrets.compare_digest(
            request.headers.get("authorization", ""), "Bearer " + api_key
        ):
            return JSONResponse({"error": "Unauthorized"}, status_code=401)
        return await call_next(request)

    @app.get("/health")
    async def health():
        healthy = sum(b["healthy"] for b in backends)
        return JSONResponse({"healthy_replicas": healthy, "total_replicas": len(backends),
                             "job_id": deployment["job_id"], "backends": backends,
                             "health_kind": "non-generating scheduler metadata plus seed flag check",
                             "real_model_acceptance": "separate_required_gate"},
                            status_code=200 if healthy == len(backends) else 503)

    @app.api_route("/{path:path}", methods=["GET", "POST"])
    async def proxy(path: str, request: Request):
        # Read before reserving an inflight slot: a caller disconnecting while
        # uploading must not leak a permanent reservation on a replica.
        payload = await request.body()
        choices = [b for b in backends if b["healthy"]]
        if not choices:
            return JSONResponse({"error": "No replica has passed scheduler metadata/seed flag check"}, status_code=503)
        backend = min(choices, key=lambda b: (b["inflight"], b["last_used"]))
        request_id = uuid.uuid4().hex
        started = time.time()
        headers = {k: v for k, v in request.headers.items()
                   if k.lower() not in {"host", "content-length", "connection", "authorization"}}
        url = backend["url"] + "/" + path
        if request.url.query:
            url += "?" + request.url.query
        receipt = {"request_id": request_id, "replica": backend["replica"],
                   "started_unix": started, "method": request.method, "path": path,
                   "payload_sha256": hashlib.sha256(payload).hexdigest(), "complete": False}
        released = False

        def release():
            nonlocal released
            if released:
                return
            released = True
            backend["inflight"] -= 1
            receipt["elapsed_seconds"] = time.time() - started
            with receipt_path.open("a") as fh:
                fh.write(json.dumps(receipt) + "\n")

        async def start_proxy():
            upstream = await client.send(client.build_request(request.method, url,
                content=payload, headers=headers), stream=True)
            original_stream = upstream.stream

            class ManagedUpstreamStream(httpx.AsyncByteStream):
                """Protect both httpx EOF-close and our explicit finalizer.

                Response.aclose sets is_closed *before* awaiting its stream, so
                merely retrying that method after cancellation can skip cleanup.
                Keep one idempotent shielded close on the actual stream instead.
                """
                def __init__(self):
                    self.lock = anyio.Lock()
                    self.close_finished = False

                async def __aiter__(self):
                    async for chunk in original_stream:
                        yield chunk

                async def aclose(self):
                    with anyio.CancelScope(shield=True):
                        async with self.lock:
                            if self.close_finished:
                                return
                            receipt["upstream_close_started"] = True
                            receipt["upstream_close_completed"] = False
                            try:
                                with anyio.move_on_after(CLOSE_TIMEOUT_SECONDS) as close_scope:
                                    await original_stream.aclose()
                                    receipt["upstream_close_completed"] = True
                                if close_scope.cancel_called:
                                    receipt["upstream_close_error"] = "cleanup_timeout"
                            except Exception as exc:
                                receipt["upstream_close_error"] = type(exc).__name__
                            finally:
                                self.close_finished = True
                                if not receipt["upstream_close_completed"]:
                                    # Do not call this replica again when cleanup
                                    # is uncertain, even if metadata stays healthy.
                                    backend["cleanup_quarantined"] = True
                                    backend["healthy"] = False
                                    backend["health_error"] = "upstream_cleanup_failed_quarantined"
                                    receipt["complete"] = False

            managed_stream = ManagedUpstreamStream()
            upstream.stream = managed_stream

            async def finish_upstream():
                # Bypass Response.is_closed if httpx already set it at EOF.
                # Keep the slot until protected close has completed or failed
                # closed with an explicit quarantined-backend receipt.
                await managed_stream.aclose()
                release()

            try:
                receipt["http_status"] = upstream.status_code
                result_headers = {"X-Eval-Replica": str(backend["replica"]), "X-Eval-Request-ID": request_id}
                for name in ("content-type", "content-encoding"):
                    if name in upstream.headers:
                        result_headers[name] = upstream.headers[name]

                async def stream():
                    digest = hashlib.sha256()
                    try:
                        async for chunk in upstream.aiter_raw():
                            digest.update(chunk)
                            yield chunk
                        receipt["response_sha256"] = digest.hexdigest()
                        receipt["complete"] = receipt.get("upstream_close_completed", False)
                    except BaseException as exc:
                        receipt["error"] = type(exc).__name__
                        raise
                    finally:
                        await finish_upstream()

                class LeasedStreamingResponse(StreamingResponse):
                    async def __call__(self, scope, receive, send):
                        # Cover cancellation before the body iterator starts.
                        try:
                            await super().__call__(scope, receive, send)
                        finally:
                            await finish_upstream()
                return LeasedStreamingResponse(stream(), status_code=upstream.status_code, headers=result_headers)
            except BaseException:
                await finish_upstream()
                raise

        # No await between lease acquisition and the encompassing exception
        # guard. Ownership transfers only when a response object is returned.
        backend["inflight"] += 1
        backend["last_used"] = time.time()
        try:
            return await start_proxy()
        except httpx.HTTPError as exc:
            backend["healthy"] = False
            receipt["error"] = type(exc).__name__
            release()
            return JSONResponse({"error": "upstream transport failure", "detail": type(exc).__name__,
                                 "replica": backend["replica"]}, status_code=502)
        except BaseException as exc:
            # CancelledError is a BaseException. Never replay a model request.
            receipt["error"] = type(exc).__name__
            release()
            raise

    return app


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--deployment", type=Path, required=True)
    args = parser.parse_args()
    deployment = json.loads(args.deployment.read_text())
    key_path = Path(deployment["router_api_key_file"])
    if stat.S_IMODE(key_path.stat().st_mode) & 0o077:
        raise SystemExit("Router API key file must not be group/world readable")
    api_key = key_path.read_text().strip()
    if len(api_key) < 32:
        raise SystemExit("Router API key missing/too short")
    app = build_app(deployment, args.deployment.parent / "router_requests.jsonl", api_key=api_key)
    uvicorn.run(app, host="0.0.0.0", port=30241, log_level="info")


if __name__ == "__main__":
    main()
