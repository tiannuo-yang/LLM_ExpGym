# 中断 B/C 的逐 attempt 传输核账

新包装只复用冻结 `bc_retained_attempts_v3/audit.py` 的纯函数与只读 Reader，不调用其整批 audit、legacy inventory 或旧 78-complete collector；原文件均不改。以已封存 partial/raw/ROOT drain SHA 为输入，复核原 2302 bindings、完整 raw 集合，再先复制完整 router JSONL 原字节到新单链接快照，之后才执行关联。

每个 attempt 以冻结 client 的 `json.dumps(payload).encode("utf-8")` 和 `response_raw.encode("utf-8")` 重建 SHA，候选再限制在 client 开始至结束时间的固定 ±1 秒内；必须唯一且 router 行不可复用。该 1 秒是预先固定的关联假设，不是独立精确服务时钟。重复 payload/response 的不同时间请求可区分，时间重叠歧义不任意分配。

router 自建 502 仅按原 helper 的请求 SHA、时间和错误模板关联；不声称上游响应 SHA、close、实际生成量或账单已知。abort 即使被 HTTP 200 双 SHA 关联，其所在整个池仍按 partial audit 隔离。每条 raw、未匹配 router 行、窗外 router 行均保留；不删除重试，不重抽。用量从原 response_raw 严格解析后独立与原 response_json/已封 raw 审计对账；未报告保持 null，reasoning 不再次加到 output。

快照源的读前、读后、关联后 length/mtime/inode 与 SHA/prefix 变化明确记录；任何字节变化使此关联不通过，而不是宣称日志始终静止。工具不请求 health，不读服务 key，不调用 scorer/runner/API，完整矩阵始终不完整。它也不执行用户要求的未来全项目逻辑复审。

实际执行需使用 ROOT 已批准的固定日志 `serving/runs/1203474/router_requests.jsonl`，输出必须是原 run 之外的新目录。CPU 测试不读真实日志或模型数据。
