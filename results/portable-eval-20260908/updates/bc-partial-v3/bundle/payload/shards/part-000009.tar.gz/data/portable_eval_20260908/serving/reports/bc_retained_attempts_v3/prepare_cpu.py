#!/usr/bin/env python3
"""Run only CPU synthetic checks and retain a clearly synthetic example receipt."""
import argparse
from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("bc_retained_cpu_tests", HERE / "test_audit.py")
tests = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tests)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--python", type=Path, action="append", dest="pythons")
    args = parser.parse_args()
    out = tests.audit.safe_path(args.out)
    out.mkdir(parents=True, exist_ok=False)
    frozen_paths = [path for path, _sha in tests.audit.FROZEN.values()]
    frozen_paths += [HERE.parent / "bc_router_rawjoin_v3" / name for name in ("summarize_usage.py", "test_collectors.py", "README.zh.md")]
    before = [tests.original(path) for path in frozen_paths]
    runs = []
    for index, python in enumerate(args.pythons or [Path(sys.executable)]):
        # A uv virtualenv executable is normally a symlink. It is a CPU test
        # launcher, not evidence; do not weaken audit.safe_path for this case.
        if not python.is_absolute() or ".." in python.parts or not python.is_file():
            raise ValueError("CPU test Python must be an existing absolute executable path")
        command = [str(python), "-B", str(HERE / "test_audit.py")]
        started = time.monotonic()
        result = subprocess.run(command, text=True, capture_output=True)
        stdout, stderr = out / ("tests-%d.stdout.log" % index), out / ("tests-%d.stderr.log" % index)
        stdout.write_text(result.stdout); stderr.write_text(result.stderr)
        runs.append({"argv": command, "returncode": result.returncode, "elapsed_seconds": time.monotonic() - started,
                     "stdout": tests.binding(stdout), "stderr": tests.binding(stderr)})
    fixture = tests.RetainedAttempts()
    fixture.tmp = out / "SYNTHETIC_FIXTURE_ONLY"
    fixture.tmp.mkdir()
    fixture.root = fixture.tmp / "synthetic-final-bc"
    fixture.error_retry = True
    fixture.prepare(include_c=True)
    fixture.seal()
    report = fixture.check()
    retained = tests.audit.write_report(report, out / "SYNTHETIC_SUPPLEMENT_ONLY")
    unchanged = before == [tests.original(path) for path in frozen_paths]
    receipt = {
        "schema_version": "portable_eval.bc_retained_attempts_cpu_preparation.v1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "classification": "CPU synthetic preparation only; no actual B/C data or authority",
        "passed": all(r["returncode"] == 0 for r in runs) and unchanged and report["accounting_integrity"] == "PASS",
        "real_raw_read": False, "model_health_slurm_calls": 0, "frozen_sources_unchanged": unchanged,
        "test_runs": runs,
        "source_files": [tests.binding(HERE / name) for name in ("audit.py", "test_audit.py", "prepare_cpu.py", "CONTRACT.zh.md")],
        "frozen_originals": before,
        "synthetic_supplement": retained,
        "synthetic_root_pins": tests.binding(fixture.pins_path),
        "synthetic_summary": {key: report[key] for key in ("status", "accounting_integrity", "pool_count", "trace_count", "attempt_count", "client_states", "all_attempt_usage", "dimensions")},
        "interpretation": "Synthetic authorization/raw-auditor receipts are fixtures, NOT actual independent audits or permission to execute. Original strict collector actually ran on synthetic bytes and its FAIL is retained unchanged. Real acceptance requires ROOT-pinned final drained inputs and independent re-review."
    }
    tests.write(out / "cpu_preparation.json", receipt)
    print(json.dumps(dict(tests.binding(out / "cpu_preparation.json"), passed=receipt["passed"], synthetic_supplement=retained), indent=2))
    return 0 if receipt["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
