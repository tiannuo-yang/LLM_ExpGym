"""CPU-only preparation; no original run files, scorer or network calls."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

import audit_partial

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[2]
RUNTIMES = {"native": WORKSPACE / "LLM_ExpGym/.venv/bin/python",
            "legacy": WORKSPACE / "kimi_k3_eval/data_runtime/.venv-hpo/bin/python"}


def meta(path):
    info = path.stat()
    return {"sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "bytes": info.st_size, "mtime_ns": info.st_mtime_ns}


def run(output):
    output = Path(output).absolute()
    audit_partial.require(HERE in output.parents and not output.exists(), "New CPU preparation output required")
    code = {str(path): meta(path) for path in sorted(HERE.iterdir()) if path.suffix in (".py", ".md")}
    frozen = {str(audit_partial.FROZEN / name): meta(audit_partial.FROZEN / name) for name in audit_partial.PINS}
    audit_partial.require(all(row["sha256"] == audit_partial.PINS[Path(path).name] for path, row in frozen.items()), "Frozen source pin differs")
    output.mkdir(parents=True)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1", OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1")
    tests = []
    for label, python in RUNTIMES.items():
        command = [str(python), "-B", "-m", "unittest", "discover", "-s", str(HERE), "-p", "test_*.py", "-v"]
        process = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env, timeout=120)
        for stream, value in (("stdout", process.stdout), ("stderr", process.stderr)):
            with (output / (label + "." + stream + ".log")).open("xb") as target:
                target.write(value)
        result = re.search(r"Ran (\d+) tests in ([0-9.]+)s", process.stderr.decode())
        audit_partial.require(process.returncode == 0 and result is not None and result[1] == "21" and
            re.search(r"^OK$", process.stderr.decode(), re.MULTILINE), "All 21 CPU tests without skips required")
        tests.append({"runtime": label, "command": command, "tests": 21, "skips": 0, "exit_code": 0, "elapsed_seconds": float(result[2])})
    audit_partial.require(all(meta(Path(path)) == value for path, value in dict(code, **frozen).items()), "Preparation changed source bytes/mtime")
    receipt = {"schema_version": "bc-partial-auditor-CPU-preparation-v1", "passed": True,
        "classification": "CPU helper contract tests only; not B/C result acceptance", "tests": tests,
        "candidate_files": code, "frozen_helpers": frozen,
        "output_logs": {str(path): meta(path) for path in sorted(output.glob("*.log"))},
        "original_real_run_read": False, "scorer_calls": 0, "model_calls": 0, "network_calls": 0,
        "actual_partial_audit_performed": False, "requires_final_ROOT_drain_and_explicit_GO": True,
        "limits": ["Frozen complete-78 auditors are unchanged and never represented as passing partial execution.",
            "No full router request/response join here; abort quarantines the whole pool; unknown cost remains unknown.",
            "These CPU tests exercise helper boundaries, not a fabricated real 78-job execution or real authority."]}
    audit_partial.safe_write(output / "receipt.json", receipt)
    return receipt


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", required=True)
    result = run(parser.parse_args().output_dir)
    print(json.dumps({"passed": result["passed"], "native_tests": 21, "legacy_tests": 21, "actual_partial_audit_performed": False}))
