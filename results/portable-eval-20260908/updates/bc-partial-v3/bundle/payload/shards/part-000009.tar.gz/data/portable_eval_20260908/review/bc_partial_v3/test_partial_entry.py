"""CPU-only partial entry helpers; no real run or scoring is inspected."""
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

import audit_partial as partial


class MemoryReader:
    def __init__(self):
        self.files = {}

    def bind(self, path):
        path = Path(path)
        body = path.read_bytes()
        self.files[str(path.resolve())] = {"path": str(path.resolve()), "sha256": partial.hashlib.sha256(body).hexdigest(),
            "bytes": len(body), "mtime_ns": path.stat().st_mtime_ns}
        return body


class PartialEntryTests(unittest.TestCase):
    def test_recursive_extra_raw_retained_and_unsafe_not_opened(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "dumps/job/deeper").mkdir(parents=True)
            (root / "dumps/orphan.json").write_text("{}")
            (root / "dumps/job/deeper/raw.json").write_text("{}")
            (root / "dumps/unsafe.json").symlink_to(root / "absent-private-target")
            result = partial.inventory(root, "dumps", MemoryReader())
            self.assertEqual(set(result["files"]), {"orphan.json", "job/deeper/raw.json"})
            self.assertEqual(len(result["unsafe"]), 1)
            self.assertFalse(result["unsafe"][0]["read"])

    def test_lexical_alias_rejected_before_evidence(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "actual").mkdir()
            (root / "alias").symlink_to(root / "actual", target_is_directory=True)
            with self.assertRaisesRegex(ValueError, "ancestor"):
                partial.inventory(root / "alias", "dumps", MemoryReader())

    def test_missing_execution_does_not_create_or_zero(self):
        jobs = {"one": {}, "two": {}}
        snapshots = {section: {"files": {}} for section in ("results", "dumps", "logs")}
        snapshots["logs"]["files"]["one/execution_status.json"] = {}
        observations = partial.observed_jobs(jobs, snapshots)
        self.assertTrue(observations["one"]["execution_observed"])
        self.assertFalse(observations["two"]["execution_observed"])
        self.assertNotIn("performance", observations["two"])
        self.assertNotIn("execution.json", snapshots["logs"]["files"])

    def test_abort_overrides_original_local_pass(self):
        agents = [{"passed": True}] * 4
        self.assertTrue(partial.qualified_pool(True, True, True, agents, []))
        self.assertFalse(partial.qualified_pool(True, True, True, agents, ["provider_finish_reason_abort"]))
        self.assertFalse(partial.qualified_pool(True, True, True, agents[:3], []))

    def test_source_scoring_consistency_does_not_override_failed_agent(self):
        self.assertFalse(partial.qualified_pool(True, True, True, [{"passed": True}] * 3 + [{"passed": False}], []))
        self.assertFalse(partial.qualified_pool(True, True, False, [{"passed": True}] * 4, []))

    def test_subset_counts_use_real_B1_stage_and_do_not_upgrade_C(self):
        jobs = {"one": {"stage": "B1_tuning"}, "two": {"stage": "C_development_repeats"}}
        rows = [{"job_id": iid, "performance_qualified": iid == "one", "observation": {
            "execution_observed": iid == "one", "status_present": iid == "one"}} for iid in jobs]
        result = partial.subset_summary(rows, jobs, [])
        self.assertTrue(result["B"]["all_subset_pools_qualified"])
        self.assertFalse(result["C"]["all_subset_pools_qualified"])
        self.assertFalse(partial.subset_summary(rows, jobs, ["orphan raw"])["B"]["all_subset_pools_qualified"])

    def test_wrong_external_auth_rejected_before_harness_or_child(self):
        with mock.patch.object(partial.subprocess, "run", side_effect=AssertionError("must not launch")):
            with self.assertRaisesRegex(ValueError, "authorization"):
                partial.preflight(Path("/private"), "auth", "0" * 64, "stop", partial.STOP_SHA,
                    "drain", "1" * 64, object(), object())

    def test_external_drain_must_be_explicit_and_match_namespace(self):
        reader = SimpleNamespace(read=lambda path, expected: {"drained": False, "run_directory": "/private"})
        common = SimpleNamespace(authority=lambda *args: {})
        with self.assertRaisesRegex(ValueError, "ROOT final drain"):
            partial.preflight(Path("/private"), "auth", partial.AUTH_SHA, "stop", partial.STOP_SHA,
                "drain", "1" * 64, reader, common)


if __name__ == "__main__":
    unittest.main()
