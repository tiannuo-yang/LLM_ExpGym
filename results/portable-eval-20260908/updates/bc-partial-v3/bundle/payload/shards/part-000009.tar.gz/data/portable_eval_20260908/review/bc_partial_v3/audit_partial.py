"""Post-drain partial B/C evidence audit; never repairs or completes a study."""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys

HERE = Path(__file__).resolve().parent
FROZEN = HERE.parent
PINS = {
    "audit_bc_common.py": "2ccc0af3f63b6768296ad554c407f96c74dcd8db5e7e670bb6d7786486df9672",
    "audit_bc_attempts_v3.py": "69f3b4a43ef787dd1ce273a743af6df9231e5abca33223be87c24abe83df525a",
    "audit_bc_score_child.py": "6ba6dd3d2af3e4c15208eae9b8a733ead04c822843d8e68299398d995e56d559",
    "audit_bc_v3.py": "1f9a1ce25bcef056d9aeffe651f26345733793a62c5132e06d3930a88ccf7b4b",
}
AUTH_SHA = "c10660b32363cd3b2261f2e32d07e859d5768da68cb00b0438a4da5ca547511b"
STOP_SHA = "15bbab050595d4c9137cd971f5201f42900d4da2856a0b822b65f9bb1b374de2"
ERRORS = (ValueError, TypeError, AttributeError, LookupError, OSError, RuntimeError, OverflowError, subprocess.TimeoutExpired)


def require(ok, message):
    if not ok:
        raise ValueError(message)


def check_ancestors(path):
    path = Path(path).absolute()
    require(all(not part.is_symlink() for part in [path] + list(path.parents)), "Evidence lexical ancestor symlink")
    return path


def dependencies():
    for name, expected in PINS.items():
        path = check_ancestors(FROZEN / name)
        require(hashlib.sha256(path.read_bytes()).hexdigest() == expected, "Frozen auditor source changed: " + name)
    sys.path.insert(0, str(FROZEN))
    import audit_bc_common as common
    import partial_raw
    require(Path(common.__file__).resolve() == FROZEN / "audit_bc_common.py", "Wrong common module origin")
    return common, partial_raw


def inventory(run, section, reader):
    """All files, including unsafe objects; never follows symlinks or hides extras."""
    root = check_ancestors(Path(run) / section)
    result = {"section": section, "present": root.is_dir(), "files": {}, "unsafe": [], "json_paths": []}
    if not root.exists():
        return result
    require(root.is_dir(), "Section is not a directory")
    for directory, dirs, files in os.walk(root, followlinks=False):
        for name in sorted(list(dirs) + files):
            path = Path(directory) / name
            info = path.lstat()
            relative = str(path.relative_to(root))
            if stat.S_ISDIR(info.st_mode):
                continue
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                result["unsafe"].append({"relative_path": relative, "mode": info.st_mode,
                    "nlink": info.st_nlink, "sha256": None, "bytes": None, "read": False})
                continue
            reader.bind(path)
            result["files"][relative] = dict(reader.files[str(path.resolve())])
            if path.suffix == ".json":
                result["json_paths"].append(str(path))
    result["json_paths"].sort()
    result["unsafe"].sort(key=lambda item: item["relative_path"])
    return result


def safe_write(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, sort_keys=True, ensure_ascii=False, allow_nan=False, indent=2)
        stream.write("\n")


def observed_jobs(jobs, inventories):
    observations = {}
    for iid in jobs:
        result_names = [name for name in inventories["results"]["files"] if name.startswith(iid + "/")]
        raw_names = [name for name in inventories["dumps"]["files"] if name.startswith(iid + "/")]
        log_names = set(inventories["logs"]["files"])
        status = iid + "/execution_status.json" in log_names
        execution_log = iid + "/execution.log" in log_names
        observations[iid] = {"status_present": status, "execution_log_present": execution_log,
            "result_files": result_names, "raw_files": raw_names,
            "execution_observed": status or execution_log or bool(result_names) or bool(raw_names)}
    return observations


def qualified_pool(local_passed, structure_passed, child_passed, agent_reports, reasons):
    return local_passed is True and structure_passed is True and child_passed is True and \
        len(agent_reports) == 4 and all(row["passed"] is True for row in agent_reports) and not reasons


def subset_summary(results, jobs, global_errors):
    groups = {}
    for subset in ("B", "C"):
        members = [row for row in results if jobs[row["job_id"]]["stage"].startswith(subset)]
        groups[subset] = {"planned_pools": len(members), "execution_observed": sum(row["observation"]["execution_observed"] for row in members),
            "status_present": sum(row["observation"]["status_present"] for row in members),
            "performance_qualified": sum(row["performance_qualified"] for row in members),
            "all_subset_pools_qualified": bool(members) and all(row["performance_qualified"] for row in members) and not global_errors}
    return groups


def preflight(run, authorization, auth_sha, stop_receipt, stop_sha, drain_receipt, drain_sha, reader, common):
    require(auth_sha == AUTH_SHA and stop_sha == STOP_SHA, "Explicit original B/C authorization and stop pins required")
    auth = common.authority(run, authorization, auth_sha, reader)
    reader.read(stop_receipt, stop_sha)
    drain = reader.read(drain_receipt, drain_sha)
    require(type(drain) is dict and drain.get("drained") is True and drain.get("run_directory") == str(run),
            "Externally pinned ROOT final drain required")
    manifest = reader.read(run / "manifest.json", auth["manifest_sha256"])
    commands = reader.read(run / "commands.json", auth["commands_sha256"])
    started = reader.read(run / "execution_started.json")
    bc = common.load_harness()
    args = bc.parse_args(auth["resolved_argv"][3:])
    require(args.backend == "openai" and args.execute and args.allow_real and args.include_c and args.output_dir == run,
            "Original precommitted real B+C execution only")
    identity = manifest["identity"]
    jobs, planned = identity["jobs"], bc.build_jobs(args)
    stripped = [{key: value for key, value in job.items() if key not in ("preflight", "environment_overrides")} for job in jobs]
    require(common.same(stripped, planned) and len(jobs) == 78 and len({job["id"] for job in jobs}) == 78,
            "Exact original 78-job plan required before scorer")
    require(identity["counts"] == {"jobs": 78, "agent_traces": 312, "B_jobs": 42, "B_agent_traces": 168,
        "C_jobs": 36, "C_agent_traces": 144, "legacy_paramnet_jobs": 9}, "Original full planned counts differ")
    require(common.same(bc.settings(args), identity["settings"]), "Original settings differ")
    acceptance = bc.pilot_helpers().verify_acceptance(args.repo_root, args.static_acceptance)
    require(common.same(acceptance, identity["static_acceptance"]) and acceptance["source_tree_sha256"] == auth["source_tree_sha256"],
            "Original source/data acceptance differs")
    require(common.same(bc.code_identity(args), identity["harness_files"]), "Original helper identity differs")
    require(started["manifest_sha256"] == common.sha(run / "manifest.json") and set(commands) == {job["id"] for job in jobs},
            "Original start/command inventory differs")
    for job in jobs:
        iid = job["id"]
        require(Path(job["output_dir"]) == run / "results" / iid and Path(job["dump_dir"]) == run / "dumps" / iid, "Fixed job namespace differs")
        expected_env = bc.pilot_helpers().environment_overrides(args, job)
        expected_env["EXPGYM_RUN_ID"] = "poolact-pilot-bc:" + run.name
        require(common.same(job["environment_overrides"], expected_env), "Fixed job runtime environment differs")
        expected_commands = {"run": job["command"], "dry_run": job["command"] + ["--dry-run"],
            "score_guard": bc.guard_command(job, "score"), "resume_guard": bc.guard_command(job, "resume")}
        require(common.same(commands[iid], expected_commands), "Fixed command family differs")
    return auth, manifest, jobs, args, bc, acceptance


def check_closed_job(job, status, reader, bc, common):
    iid, reasons = job["id"], []
    require(type(status) is dict and status.get("job_id") == iid, "Malformed or cross-job original status")
    current = bc.snapshot(job)
    for key in ("before_audit", "retained_artifacts"):
        require(common.same(current, status[key]), "Original status artifact snapshot differs: " + key)
    require(common.same(current, status["resume"]["after"]), "Original after-resume snapshot differs")
    for row, filename in ((status["run"], "execution.log"), (status["independent_score"], "score.log"), (status["resume"], "resume.log")):
        path = Path(job["output_dir"]).parents[1] / "logs" / iid / filename
        require(Path(row["log"]) == path, "Cross-job original log reference")
        reader.bind(path, row["log_sha256"])
        require(type(row.get("exit_code")) is int and row["exit_code"] == 0, "Original run/score/resume exit is not zero")
    resume = status["resume"]
    require(resume.get("model_construction_and_calls_forbidden") is True and resume.get("all_json_before_equals_after") is True and
            type(resume.get("verified_skips")) is int and resume["verified_skips"] == 1, "Original guarded-resume evidence incomplete")
    text = reader.bind(resume["log"]).decode("utf-8")
    require(text.count("[resume]") == 1 and "rerun" not in text.lower() and "FORBIDDEN" not in text, "Original guarded skip log differs")
    if status.get("passed") is not True:
        reasons.append("original_local_status_not_passed")
    return reasons, current


def audit(run, authorization, auth_sha, stop_receipt, stop_sha, drain_receipt, drain_sha, output):
    run, output = check_ancestors(run), check_ancestors(output)
    require(not output.exists() and run not in output.parents, "New evidence directory outside original run required")
    common, raw_module = dependencies()
    class EvidenceReader(common.Reader):
        def bind(self, path, expected=None):
            lexical = Path(path).absolute()
            if lexical == run or run in lexical.parents:
                check_ancestors(lexical)
                info = lexical.lstat()
                require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1, "Unsafe original evidence object cannot be opened")
            return super().bind(path, expected)
    reader = EvidenceReader()
    auth, manifest, jobs, args, bc, acceptance = preflight(run, authorization, auth_sha, stop_receipt, stop_sha, drain_receipt, drain_sha, reader, common)
    output.mkdir(parents=True)
    for path in list(HERE.glob("*.py")) + [FROZEN / name for name in PINS]:
        reader.bind(path)
    snapshots = {section: inventory(run, section, reader) for section in ("dumps", "results", "logs")}
    safe_write(output / "original_namespace_inventory.json", snapshots)
    jobs_by_id = {job["id"]: job for job in jobs}
    raw = raw_module.audit_raw([Path(path) for path in snapshots["dumps"]["json_paths"]], jobs_by_id, args, bc, run, reader)
    raw["unreadable_objects_not_opened"] = snapshots["dumps"]["unsafe"]
    if snapshots["dumps"]["unsafe"]:
        for value in raw["usage_totals"].values():
            value["complete_total"] = None
        raw["global_errors"].append("unsafe_raw_objects_make_complete_cost_unknown")
    # Keep raw bytes in their original files; the persisted report binds and
    # describes every path without making another copy of prompts/responses.
    safe_write(output / "raw_partial.json", {key: value for key, value in raw.items() if key != "records"})
    observations = observed_jobs(jobs_by_id, snapshots)
    global_errors, results = list(raw["global_errors"]), []
    for section, snap in snapshots.items():
        global_errors.extend("unsafe_" + section + ":" + item["relative_path"] for item in snap["unsafe"])
        for relative in snap["files"]:
            if relative.split("/")[0] not in jobs_by_id:
                global_errors.append("unplanned_" + section + ":" + relative)
    final_execution = {"present": (run / "execution.json").exists(), "value": None}
    if final_execution["present"]:
        final_execution["value"] = reader.read(run / "execution.json")
    for job in jobs:
        iid, observation = job["id"], observations[job["id"]]
        row = {"job_id": iid, "original_status_passed": None, "observation": observation, "infra_qualified": False,
            "performance_qualified": False, "score_consistency": None, "guarded_skips": None,
            "abort_observed": iid in raw["abort_job_ids"], "reasons": list(raw["job_errors"].get(iid, []))}
        if row["abort_observed"]:
            row["reasons"].append("provider_finish_reason_abort_entire_pool_quarantined")
        if not observation["execution_observed"]:
            row["classification"] = "no_execution_evidence_observed"
            row["reasons"].append("no_execution_evidence_not_a_zero_score")
            results.append(row)
            continue
        if not observation["status_present"]:
            row["classification"] = "partial_missing_original_status"
            row["reasons"].append("original_status_missing")
            results.append(row)
            continue
        try:
            status = reader.read(run / "logs" / iid / "execution_status.json")
            row["original_status_passed"] = status.get("passed") if isinstance(status, dict) else None
            local_reasons, before = check_closed_job(job, status, reader, bc, common)
            row["reasons"].extend(local_reasons)
            expected = {"summary.json", job["strategy"] + "/result.json"} | {job["strategy"] + "/agents/agent_%d.json" % i for i in range(4)}
            actual = {name[len(iid) + 1:] for name in observation["result_files"]}
            require(actual == expected, "Exact N4 result/summary namespace differs")
            for path in sorted(expected):
                reader.read(Path(job["output_dir"]) / path)
            structure = bc.validate_job(job, auth["source_tree_sha256"], "openai")
            require(structure["passed"] is True and common.same(structure, status["validation"]), "Original artifact/config/aggregate validation differs")
            agents = []
            for agent_id in range(4):
                path = Path(job["output_dir"]) / job["strategy"] / "agents" / ("agent_%d.json" % agent_id)
                agents.append(raw_module.check_agent(reader.read(path), path, job, agent_id, raw, reader))
            row["agent_raw_checks"] = agents
            consumed_requests = [rid for agent in agents for rid in agent["request_ids"]]
            pool_requests = [rid for rid, item in raw["records"].items() if item["job_id"] == iid]
            if len(consumed_requests) != len(set(consumed_requests)) or set(consumed_requests) != set(pool_requests):
                row["reasons"].append("whole_pool_raw_agent_ledger_bijection_failed")
            child_command = [job["command"][0], "-B", str(FROZEN / "audit_bc_score_child.py")]
            completed = subprocess.run(child_command, input=json.dumps({"job": job, "harness_args": auth["resolved_argv"][3:]}),
                cwd=args.repo_root, env=bc.environment(args, job), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=300, check=False)
            for stream, body in (("stdout", completed.stdout), ("stderr", completed.stderr)):
                path = output / (iid + "." + stream + ".log")
                with path.open("x") as target:
                    target.write(body)
                reader.bind(path)
            prefix = "BC_INDEPENDENT_JSON="
            lines = [line[len(prefix):] for line in completed.stdout.splitlines() if line.startswith(prefix)]
            require(len(lines) == 1, "No unique frozen child score receipt")
            child = common.strict_json(lines[0])
            child_ok = completed.returncode == 0 and child.get("passed") is True and child.get("model_or_network_attempts") == 0
            expected_version = "3.7." if job["runtime"] == "legacy_paramnet" else "3.11."
            require(child["original_score_receipt"]["runtime"]["version"].startswith(expected_version), "Wrong actual scorer runtime")
            require(common.same(bc.snapshot(job), before), "Independent scoring changed originals")
            row.update(classification="closed_original_pool", guarded_skips=status["resume"]["verified_skips"],
                score_consistency=child_ok, child_command=child_command, independent_child=child,
                retained_semantic_zero_count=structure["semantic_zero_count"])
            row["infra_qualified"] = qualified_pool(status.get("passed"), structure["passed"], child_ok, agents, row["reasons"])
            row["performance_qualified"] = row["infra_qualified"]
        except ERRORS as exc:
            row["classification"] = "partial_or_failed_original_pool"
            row["reasons"].append(type(exc).__name__ + ": " + str(exc))
        results.append(row)
    after = {section: inventory(run, section, reader) for section in snapshots}
    require(common.same(after, snapshots), "Original full namespace changed during audit")
    require(common.same(bc.pilot_helpers().verify_acceptance(args.repo_root, args.static_acceptance), acceptance), "Original source/data changed")
    reader.unchanged()
    subsets = subset_summary(results, jobs_by_id, global_errors)
    result = {"schema_version": "bc78-partial-independent-evidence-v1", "audit_completed": True, "overall_complete": False,
        "performance_matrix_complete": False, "classification": "Interrupted partial B/C; not a 78-pool acceptance",
        "original_execution_receipt": final_execution, "original_78_plan_retained": True,
        "run_directory": str(run), "authorization_sha256": auth_sha,
        "stop_receipt": {"path": str(stop_receipt), "sha256": stop_sha}, "ROOT_drain_receipt": {"path": str(drain_receipt), "sha256": drain_sha},
        "source_tree_sha256": auth["source_tree_sha256"], "subsets": subsets, "rows": results,
        "classifications": dict(Counter(row.get("classification") for row in results)), "global_errors": global_errors,
        "raw_report": {"path": str(output / "raw_partial.json"), "sha256": common.sha(output / "raw_partial.json")},
        "file_bindings": reader.files, "originals_unchanged": True, "model_calls": 0, "runner_main_or_resume_calls": 0,
        "limits": ["ROOT drain and authority are externally pinned prerequisites; this auditor does not issue health requests or termination.",
            "No full router request/response dual-SHA join performed here; client null HTTP status and unknown upstream cost remain unknown.",
            "Recovered 502 attempts remain in all-attempt accounting; abort invalidates the whole pool even if original local status passed.",
            "Original scorer/identity/context/trim independently executed in each actual runtime, not an independent metric algorithm.",
            "Stored graph syntax/history is not a proof of full concurrent graph/cache/clock causality; performance missingness is never zero."]}
    safe_write(output / "receipt.json", result)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("run", "authorization", "stop-receipt", "drain-receipt", "output-dir"):
        parser.add_argument("--" + name, required=True, type=Path)
    for name in ("authorization-sha256", "stop-sha256", "drain-sha256"):
        parser.add_argument("--" + name, required=True)
    options = parser.parse_args()
    value = audit(options.run, options.authorization, options.authorization_sha256, options.stop_receipt,
        options.stop_sha256, options.drain_receipt, options.drain_sha256, options.output_dir)
    print(json.dumps({"audit_completed": value["audit_completed"], "overall_complete": False, "subsets": value["subsets"]}))
