# B/C 中断批次：独立离线部分审计

本次审计执行完毕，原件未变；**完整 78 池矩阵未完成，不能宣称全量通过**。没有补造原本缺失的 `execution.json`，没有运行模型、API、runner main 或 resume。

| 原计划子集 | 计划池数 | 观察到已执行且闭合 | 本审计合格池数 | 结论 |
|---|---:|---:|---:|---|
| B | 42 | 42 | 42 | B 子集满足本次有限证据合同 |
| C | 36 | 5 | 4 | 1 池隔离，31 池无执行证据；不完整 |

47 个原池、188 份 agent 记录均经冻结 scorer 重新校验一致；9 池实际使用 Python 3.7，38 池使用 Python 3.11，运行时身份均与原 preflight 一致。47 个原 guarded skips 及原评分保留。原始可信提示、工具 schema、存储 history 与确定性 trim-to-wire 一并核验；这不等于已证明完整并发 graph/cache/clock 因果语义。

整个 `C_development_repeats__tuning__hpobench_nasbench101_A__cost_tight__poolact__outer1` 池隔离：其 agent 3 收到 provider `finish_reason=abort`。原 local PASS、Natural answer 和 scorer 一致性不构成可用表现证据。此池原始 1 个零分保留，但不计作合格语义零分；其余 46 个合格池保留 14 个原始零分。

完整盘点保留 1,532 个 raw JSON、282 个结果 JSON 及 344 个日志目录文件；无 unsafe 对象或全局 namespace 错误。1531 个 client success 包括 1 个 abort；另 1 个 HTTP 502 后由原 attempt 2 恢复。finish reasons 为 tool_calls 1343、stop 187、abort 1。全部 raw/parsed response 严格一致，全部请求保留并与原 agent ledger 逐条对应。

所有请求的已报告用量为 input 14,686,457、output 1,829,866（其中 reasoning 1,438,618）、provider total 16,516,323。502 未报告用量，因此完整总额为 null；缓存读写也未报告，不能记作完整 0。这里没有重新执行全量 router 双 SHA join，不能将 client success 的 null HTTP status 自行解释成 HTTP 200，也不宣称未知上游成本为 0。

主要证据：

- [独立审计收据](receipt.json)：`c53de465cdbff775f772d3c3d9a1cf5011976e2a06fb63a140f85489e43f3e4f`
- [全 raw 部分审计](raw_partial.json)：`61a49e92e8773a1c932027ae02cc9aada18ef373daa2fe2789483517b47fe14f`
- [原 namespace 盘点](original_namespace_inventory.json)：`106dffd60996f357025776bf81b065083f1bc3ce1746e589df534f5af4f022b6`
- [收据后只读复核](postcheck.json)：全部 2302 个绑定的 SHA、字节数及 mtime 再核一致，启动/闭合/隔离/无执行证据集合与 operator 封存原件精确一致。

授权、单父 PID 停派和 ROOT 排空/运行时前置检查均以外部 SHA 绑定；本审计未重新请求 health。此报告只是已中断 B/C 的部分证据验收，不代替用户要求的所有结果与分析冻结后全项目最终逻辑复审。
