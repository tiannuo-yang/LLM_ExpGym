# B/C 部分批次：1,532 次请求的路由关联

在预先固定 ±1 秒时间容差下，全部 1,532 次原 attempt 均唯一关联到路由日志；没有复用路由行，也没有批次时间窗内的未匹配路由记录。该容差是关联假设，不代表独立校准的精确服务时间。

| 证据类别 | 次数 | 可以确认的范围 |
|---|---:|---|
| 请求与响应双 SHA、HTTP 200、上游 close 完成 | 1531 | 包括 abort 响应；传输匹配不证明模型回答有效 |
| 路由器自建 502 的请求 SHA + 时间关联 | 1 | 上游响应、close、生成量和账单仍未知 |

原 502 attempt `c6674f1209ab40ea9316c0808fab5eeb` 对应快照第 661 行，原恢复重试不删除。abort attempt `e4ed92c3c29a4808809c4adf62ec34aa` 对应第 2018 行，其整个池依然隔离，不因 HTTP 200 或双 SHA 通过而解除。

完整路由快照为 2071 行、963048 字节；另外 539 行都在批次时间窗外并完整保留。源日志在此次读前、快照读后和关联后的 size/mtime/inode/bytes SHA/prefix 一致，不据此宣称持续健康或其他时段没有请求。收据内 2307 个文件绑定在审计后再次核对 SHA/bytes/mtime，无变化。

从原 `response_raw` 重算并与原 parsed response、独立 raw 审计精确对账：input known 14,686,457、output known 1,829,866（包含 reasoning 1,438,618）、provider total known 16,516,323。502 的未报告量保留为 null，所有完整总额仍未知；缓存读写亦未报告。**all-attempt double SHA=false、usage completeness=false、完整 78 池矩阵完成=false。**

证据入口：

- [逐 attempt 收据](receipt.json)，SHA `9de144fe7d2ac535663bbfba7a8c7225826c7c55977f80bf169d6f89a3dbc0f0`
- [完整路由原字节快照](router_requests_snapshot.jsonl)，SHA `2f7a45054f045554aa6f008ee60c812bba8eff203cc2765ee7f47a2a23af7c39`
- [独立部分评分/原件审计](../bc_partial_independent_20260908T1046Z/README.zh.md)
- [新工具及复用边界](../../review/bc_partial_transport/README.zh.md)
- [10×2 纯 CPU 验收](../../review/bc_partial_transport/validation/cpu_preparation_v1/receipt.json)，SHA `1593d0385e26b57fef80914e8d4ed0dd7b3abe221fff04b0f390f65456af5339`

仅运行一次新离线关联，无模型/API/health/key/scorer/runner 调用，没有运行或改写旧 78-complete collector。此证据不是全项目最终逻辑复审。
