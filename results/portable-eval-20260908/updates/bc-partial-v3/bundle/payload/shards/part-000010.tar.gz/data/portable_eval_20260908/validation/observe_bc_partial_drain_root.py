"""One-shot ROOT post-interruption observation; never starts generation."""
from datetime import datetime, timedelta, timezone
import hashlib
import importlib.util
import json
from pathlib import Path

STUDY = Path(__file__).resolve().parents[1]
RUN = STUDY / 'pilot_runs/k3_bc312_1203474_v3'
PIDS = (2533615, 3032786, 3032793, 3032795, 3040519)
COLLECTOR_SHA = '06e28635f2e45ebfc55269142a270efbf5b0fd330a863b2f1a2d952350fd6292'
FILES = {}


def bind(path, expected=None):
    path = Path(path).absolute()
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    assert expected is None or digest == expected, str(path)
    FILES[str(path)] = {'sha256': digest, 'bytes': len(raw)}
    return raw


def process_check():
    assert all(not Path('/proc/%d' % pid).exists() for pid in PIDS)
    matches = []
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit():
            continue
        try:
            argv = (entry / 'cmdline').read_bytes().split(b'\0')
        except (FileNotFoundError, PermissionError, ProcessLookupError):
            continue
        if any(RUN.name.encode() in arg for arg in argv) and any(
                term in arg for arg in argv for term in
                (b'run_poolact.py', b'poolact_pilot_timing.py', b'guard_runner.py')):
            matches.append(int(entry.name))
    assert not matches, matches
    return {'original_parent_and_children_absent': list(PIDS), 'namespace_process_matches': matches}


def main():
    target = STUDY / 'validation/bc_partial_root_drain_20260908T1045Z.json'
    assert not target.exists()
    operator_path = RUN / 'operator_interrupted_partial_receipt.json'
    operator = json.loads(bind(operator_path, '8a455a46af97c35a34c91f2a49e26b8b76a3bbd15d488447c2810918ec88bfd6'))
    for ref in operator['control_bindings']:
        bind(ref['path'], ref['sha256'])
    manifest = json.loads(bind(RUN / 'manifest.json'))
    runtimes = {}
    for job in manifest['identity']['jobs']:
        runtime = job['preflight']['runtime']
        bind(runtime['executable'], runtime['executable_sha256'])
        bind(Path(runtime['prefix']) / 'pyvenv.cfg', runtime['pyvenv_config_sha256'])
        runtimes[runtime['executable']] = runtime
    before = process_check()
    assert not (RUN / 'execution.json').exists()
    raw_paths = sorted((RUN / 'dumps').glob('*/*.json'))
    states = {}
    for path in raw_paths:
        record = json.loads(bind(path))
        state = record.get('state')
        assert state in ('success', 'error', 'malformed_response')
        assert record.get('finished_at_utc') is not None
        states[state] = states.get(state, 0) + 1
    code = STUDY / 'design/k3_ready_capture_candidate_v2/collector.py'
    bind(code, COLLECTOR_SHA)
    bind(code.parent / 'CPU_RECEIPT.json', '88f47b5435e5931f70c8b85a3c190d4629bb543112f4cf100959f5ee5bc59107')
    spec = importlib.util.spec_from_file_location('root_incident_collector', code)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    now = datetime.now(timezone.utc)
    output = STUDY / 'serving/reports/ready_capture_partial_20260908T1045Z'
    gate = {'schema_version': 'k3-ready-capture-root-gate-v1', 'approved': True,
            'stage': 'incident_partial_post_drain', 'evidence_kind': 'real_observation',
            'deployment_sha256': module.DEPLOYMENT_SHA, 'collector_sha256': COLLECTOR_SHA,
            'output_dir': str(output), 'not_before_utc': now.isoformat(),
            'expires_utc': (now + timedelta(seconds=180)).isoformat(), 'BC_drain_reviewed_by_ROOT': True}
    gate_bytes = module.encoded(gate)
    receipt = module.collect(output, gate_bytes=gate_bytes, gate_sha256=module.sha(gate_bytes),
                             expected_source_sha256=COLLECTOR_SHA,
                             deployment_bytes=bind(module.DEPLOYMENT_PATH, module.DEPLOYMENT_SHA))
    assert receipt['complete_five_observations'] and not receipt['formal_G6_collection']
    capture = json.loads(bind(receipt['capture']['path'], receipt['capture']['sha256']))
    for row in [capture['router']] + capture['replica_metadata']:
        assert json.loads(bind(row['body']['path'], row['body']['sha256'])) == row['parsed_json']
    health = capture['router']['parsed_json']
    assert health['job_id'] == '1203474' and health['healthy_replicas'] == health['total_replicas'] == 4
    assert len(health['backends']) == 4 and all(
        row['healthy'] is True and row['inflight'] == 0 and row['cleanup_quarantined'] is False
        for row in health['backends'])
    after = process_check()
    bind(output / 'collection_receipt.json')
    bind(output / 'root_collection_gate.json')
    bind(__file__)
    result = {'schema_version': 'ROOT-interrupted-partial-drain-v1', 'created_utc': datetime.now(timezone.utc).isoformat(),
              'run_directory': str(RUN), 'drained': True, 'before': before, 'after': after,
              'raw_terminal_states': states, 'raw_files': len(raw_paths), 'runtime_preflight_rehashed': runtimes,
              'operator_partial_receipt': str(operator_path), 'capture': receipt['capture'], 'bindings': FILES,
              'model_calls': 0, 'metadata_GETs': receipt['request_attempts'], 'overall_BC_complete': False,
              'normal_execution_json_created': False, 'formal_G6_complete': False,
              'limits': ['Drain/terminality observation only; independent partial raw/scorer audit follows.',
                         'Original client success includes one abort; neither performance qualification nor serving fix is implied.']}
    with target.open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps({'path': str(target), 'sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
                      'drained': True, 'raw_files': len(raw_paths), 'metadata_GETs': receipt['request_attempts']}))


if __name__ == '__main__':
    main()
